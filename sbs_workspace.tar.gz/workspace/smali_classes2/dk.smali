.class public interface abstract Ldk;
.super Ljava/lang/Object;
# generated-22617
.source "exwwmyhj.java"

# ep-qbxiayavqvsz

# virtual methods
.method public abstract a()V
.end method
