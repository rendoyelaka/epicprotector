.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
.source "zpsiofnd.java"
# ep-icmvdrgqpzpn
# generated-91203
# compiled-82315


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
