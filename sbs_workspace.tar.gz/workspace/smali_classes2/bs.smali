.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "xqgzklxw.java"
# ep-pxggbvqbxebo

# verified-83326
# compiled-79001

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
