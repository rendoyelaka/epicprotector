.class public interface abstract Ld0$a;
# ep-imtsawjghhjn
.super Ljava/lang/Object;
# processed-16656
# optimised-17621
# generated-81643
.source "chdoedml.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
