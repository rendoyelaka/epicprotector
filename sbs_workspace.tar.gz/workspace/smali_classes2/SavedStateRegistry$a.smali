.class public interface abstract LSavedStateRegistry$a;
# ep-ipzmqyimgiur
.super Ljava/lang/Object;
.source "ojpdxqrg.java"
# generated-35420
# verified-68352
# validated-23317


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
