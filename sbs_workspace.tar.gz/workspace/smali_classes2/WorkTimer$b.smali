.class public interface abstract LWorkTimer$b;
.super Ljava/lang/Object;
# compiled-39610
# validated-28273
# optimised-43965
.source "npziakjm.java"
# ep-eeikwocbdkgc


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
