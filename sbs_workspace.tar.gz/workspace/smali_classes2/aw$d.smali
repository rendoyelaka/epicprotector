.class public interface abstract Law$d;
.super Ljava/lang/Object;
.source "evvcfxrm.java"
# optimised-58695
# generated-58890
# processed-28713
# ep-lrgpawjeitoz


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Law;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()V
.end method

.method public abstract c()V
.end method

.method public abstract d(Law;)V
.end method

.method public abstract e()V
.end method
