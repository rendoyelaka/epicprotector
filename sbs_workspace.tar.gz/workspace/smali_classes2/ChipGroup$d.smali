.class public interface abstract LChipGroup$d;
.super Ljava/lang/Object;
# processed-92155
.source "rtyntscy.java"

# ep-xvtxtsjxecqz

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
