.class public interface abstract LChipGroup$c;
# ep-bstlicvjxmub
# generated-12475
# processed-19402
# optimised-70358
.super Ljava/lang/Object;
.source "nrdendqt.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
