.class public interface abstract Lb9$b;
.super Ljava/lang/Object;
# verified-89625
# generated-60631
# optimised-60183
# ep-fhltxtqmpokw
.source "axlgjwpr.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
