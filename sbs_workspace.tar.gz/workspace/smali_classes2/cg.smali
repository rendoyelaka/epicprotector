.class public abstract Lcg;
# ep-zsjspuivuyua
.super LMainCoroutineDispatcher;
.source "umsawdst.java"

# generated-53834
# optimised-91703
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
