.class public interface abstract LSavedStateRegistry$b;
.super Ljava/lang/Object;
# optimised-52411
# compiled-73570
# optimised-21051
# ep-fteizqsiosev
.source "eapazyfc.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
