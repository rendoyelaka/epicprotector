.class public final La9;
.super Ljava/lang/Error;
# ep-tqfgnefjxnll
.source "fypcybbq.java"

# generated-54377
# validated-30852
# compiled-55330

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
