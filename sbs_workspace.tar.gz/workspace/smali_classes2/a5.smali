.class public final La5;
# ep-hamwxdwaojju
.super Ljava/lang/Object;
# generated-94654
# optimised-25806
.source "rkqmslyc.java"


# instance fields
.field public final a:Ljava/lang/Object;

.field public final b:Ljava/lang/Object;

.field public final c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .locals 2

    .line 1
    const/4 v0, 0x1

    .line 2
    if-eq p1, v0, :cond_1

    .line 4
    const/4 v0, 0x2

    .line 5
    if-eq p1, v0, :cond_0

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    new-instance p1, Ljo;

    .line 12
    const/16 v0, 0x100

    .line 14
    const/4 v1, 0x0

    .line 15
    invoke-direct {p1, v0, v1}, Ljo;-><init>(II)V

    .line 18
    iput-object p1, p0, La5;->a:Ljava/lang/Object;

    .line 20
    new-instance p1, Ljo;

    .line 22
    invoke-direct {p1, v0, v1}, Ljo;-><init>(II)V

    .line 25
    iput-object p1, p0, La5;->b:Ljava/lang/Object;

    .line 27
    new-instance p1, Ljo;

    .line 29
    invoke-direct {p1, v0, v1}, Ljo;-><init>(II)V

    .line 32
    iput-object p1, p0, La5;->c:Ljava/lang/Object;

    .line 34
    const/16 p1, 0x20

    .line 36
    new-array p1, p1, [Lqs;

    .line 38
    iput-object p1, p0, La5;->d:Ljava/lang/Object;

    .line 40
    return-void

    .line 41
    :cond_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 44
    new-instance p1, Lj3;

    .line 46
    invoke-direct {p1}, Lj3;-><init>()V

    .line 49
    iput-object p1, p0, La5;->a:Ljava/lang/Object;

    .line 51
    new-instance p1, Landroid/util/SparseArray;

    .line 53
    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    .line 56
    iput-object p1, p0, La5;->b:Ljava/lang/Object;

    .line 58
    new-instance p1, Luj;

    .line 60
    invoke-direct {p1}, Luj;-><init>()V

    .line 63
    iput-object p1, p0, La5;->c:Ljava/lang/Object;

    .line 65
    new-instance p1, Lj3;

    .line 67
    invoke-direct {p1}, Lj3;-><init>()V

    .line 70
    iput-object p1, p0, La5;->d:Ljava/lang/Object;

    .line 72
    return-void

    .line 73
    :cond_1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 76
    new-instance p1, Ljo;

    .line 78
    const/16 v1, 0xa

    .line 80
    invoke-direct {p1, v1, v0}, Ljo;-><init>(II)V

    .line 83
    iput-object p1, p0, La5;->a:Ljava/lang/Object;

    .line 85
    new-instance p1, Lks;

    .line 87
    invoke-direct {p1}, Lks;-><init>()V

    .line 90
    iput-object p1, p0, La5;->b:Ljava/lang/Object;

    .line 92
    new-instance p1, Ljava/util/ArrayList;

    .line 94
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 97
    iput-object p1, p0, La5;->c:Ljava/lang/Object;

    .line 99
    new-instance p1, Ljava/util/HashSet;

    .line 101
    invoke-direct {p1}, Ljava/util/HashSet;-><init>()V

    .line 104
    iput-object p1, p0, La5;->d:Ljava/lang/Object;

    .line 106
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/HashSet;)V
    .locals 4

    .line 1
    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    return-void

    .line 8
    :cond_0
    invoke-virtual {p3, p1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 11
    move-result v0

    .line 12
    if-nez v0, :cond_2

    .line 14
    invoke-virtual {p3, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 17
    iget-object v0, p0, La5;->b:Ljava/lang/Object;

    .line 19
    check-cast v0, Lks;

    .line 21
    const/4 v1, 0x0

    .line 22
    invoke-virtual {v0, p1, v1}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    move-result-object v0

    .line 26
    check-cast v0, Ljava/util/ArrayList;

    .line 28
    if-eqz v0, :cond_1

    .line 30
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 33
    move-result v1

    .line 34
    const/4 v2, 0x0

    .line 35
    :goto_0
    if-ge v2, v1, :cond_1

    .line 37
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 40
    move-result-object v3

    .line 41
    invoke-virtual {p0, v3, p2, p3}, La5;->a(Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/HashSet;)V

    .line 44
    add-int/lit8 v2, v2, 0x1

    .line 46
    goto :goto_0

    .line 47
    :cond_1
    invoke-virtual {p3, p1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 50
    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 53
    return-void

    .line 54
    :cond_2
    new-instance p1, Ljava/lang/RuntimeException;

    .line 56
    const-string p2, "This graph contains cyclic dependencies"

    .line 58
    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 61
    throw p1
.end method
