.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
# ep-jmnzhfnfsouu
.source "cffjeyel.java"

# verified-28141
# processed-57392

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
