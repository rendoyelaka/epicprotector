.class public interface abstract Lcm;
# ep-yhrrvsouuqcr
# optimised-19207
# processed-76801
# generated-60686
.super Ljava/lang/Object;
.source "kyiydpgw.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
