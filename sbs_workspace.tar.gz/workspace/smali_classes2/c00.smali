.class public interface abstract Lc00;
.super Ljava/lang/Object;
.source "pkwwufev.java"
# ep-vjezblkcygae

# optimised-31200

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
