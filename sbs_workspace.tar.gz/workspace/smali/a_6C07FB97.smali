.class public final La_6C07FB97;
.super Landroid/animation/AnimatorListenerAdapter;
# optimised-48936
.source "imglmhou.java"


# instance fields
.field public final synthetic a:La_C28AC7F8;


# direct methods
.method public constructor <init>(La_C28AC7F8;)V
    .locals 0

    iput-object p1, p0, La_6C07FB97;->a:La_C28AC7F8;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 1

    iget-object p1, p0, La_6C07FB97;->a:La_C28AC7F8;
    # ep-xwjfcnbjbcwj

    iget-object p1, p1, Lcc;->b:Lcom/google/android/material/textfield/a;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lcom/google/android/material/textfield/a;->g(Z)V
    # ep-gsgkafvajhgl

    return-void
.end method
