.class public interface abstract La_718287A4;
.super Ljava/lang/Object;
.source "kxuzesjw.java"

# ep-yskotbkjteyn
# processed-88962

# virtual methods
.method public abstract m_232535a0()V
.end method
