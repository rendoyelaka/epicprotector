.class public final La_14AAF745;
.super Ljava/lang/Object;
.source "iknsyzqf.java"
# ep-gjxmdiwtgpzz
# processed-85999


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "o"
.end annotation


# direct methods
.method public static a(Landroid/view/View;)[Ljava/lang/String;
    .locals 0

    invoke-static {p0}, La_F80A868D;->o(Landroid/view/View;)[Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static b(Landroid/view/View;La_50334AF1;)La_50334AF1;
    .locals 1

    .line 1
    iget-object v0, p1, La_50334AF1;->a:La_F3196EE8;

    .line 3
    invoke-interface {v0}, La_F3196EE8;->c()Landroid/view/ContentInfo;

    .line 6
    move-result-object v0

    .line 7
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    invoke-static {p0, v0}, La_F80A868D;->g(Landroid/view/View;Landroid/view/ContentInfo;)Landroid/view/ContentInfo;

    .line 13
    move-result-object p0

    .line 14
    if-nez p0, :cond_0

    .line 16
    const/4 p0, 0x0

    .line 17
    return-object p0

    .line 18
    :cond_0
    if-ne p0, v0, :cond_1

    .line 20
    return-object p1

    .line 21
    :cond_1
    new-instance p1, La_50334AF1;

    .line 23
    new-instance v0, La_90068634;

    .line 25
    invoke-direct {v0, p0}, La_90068634;-><init>(Landroid/view/ContentInfo;)V

    .line 28
    invoke-direct {p1, v0}, La_50334AF1;-><init>(La_F3196EE8;)V

    .line 31
    return-object p1
.end method

.method public static c(Landroid/view/View;[Ljava/lang/String;Ljn;)V
    .locals 1

    .line 1
    if-nez p2, :cond_0

    .line 3
    invoke-static {p0, p1}, La_F80A868D;->m(Landroid/view/View;[Ljava/lang/String;)V

    .line 6
    goto :goto_0

    .line 7
    :cond_0
    new-instance v0, La_0DB98814;

    .line 9
    invoke-direct {v0, p2}, La_0DB98814;-><init>(Ljn;)V

    .line 12
    invoke-static {p0, p1, v0}, La_F80A868D;->n(Landroid/view/View;[Ljava/lang/String;La_0DB98814;)V

    .line 15
    :goto_0
    return-void
.end method
