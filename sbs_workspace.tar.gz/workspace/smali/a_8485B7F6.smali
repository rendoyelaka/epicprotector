.class public final La_8485B7F6;
.super Ljava/lang/Object;
.source "jcecwkkc.java"

# processed-48560
# validated-17495

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_6D39E7CC;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/app/Activity;)V
    # ep-alfoymoibuay
    .locals 0

    # ep-lkwqeldmxzui
    invoke-virtual {p0}, Landroid/app/Activity;->finishAffinity()V

    # ep-yliufzahegxb
    return-void
.end method

.method public static b(Landroid/app/Activity;Landroid/content/Intent;ILandroid/os/Bundle;)V
    # ep-kxubfypcboqi
    .locals 0
    # ep-xdrblvocaauf

    invoke-virtual {p0, p1, p2, p3}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;ILandroid/os/Bundle;)V
    # ep-qtxlprskqhng

    return-void
.end method

    # ep-qxnbkonvxmlj
.method public static c(Landroid/app/Activity;Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V
    # ep-fvswfucylqrd
    .locals 0
    # ep-bstfzyiiardw

    invoke-virtual/range {p0 .. p7}, Landroid/app/Activity;->startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V

    return-void
.end method
