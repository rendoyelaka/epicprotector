.class public interface abstract La_46684BB9;
.super Ljava/lang/Object;
.source "sgrlasxx.java"
