.class public abstract LRoomInvalidationTracker$c;
.super Ljava/lang/Object;
# processed-87149
# generated-65707
# optimised-84091
.source "CertHelper96.java"

# ep-vjystjhwuanv

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# virtual methods
.method public abstract a(Ljava/util/Set;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
