.class public abstract LRoomInvalidationTracker$c;
.super Ljava/lang/Object;
.source "tkdsjuyf.java"
# ep-sjrpbnemegsy
# verified-77577
# optimised-61454


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# virtual methods
.method public abstract a(Ljava/util/Set;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
