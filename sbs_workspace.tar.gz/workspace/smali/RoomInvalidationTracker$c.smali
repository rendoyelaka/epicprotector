.class public abstract LRoomInvalidationTracker$c;
.super Ljava/lang/Object;
.source "rxgobwue.java"
# ep-dvldzsxhtuvk
# optimised-62012
# processed-93268
# verified-70356


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# virtual methods
.method public abstract a(Ljava/util/Set;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
