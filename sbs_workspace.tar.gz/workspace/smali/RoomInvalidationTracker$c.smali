.class public abstract LRoomInvalidationTracker$c;
# ep-cmkdphczscxq
.super Ljava/lang/Object;
.source "tsdseixy.java"
# generated-72951
# compiled-57704


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# virtual methods
.method public abstract a(Ljava/util/Set;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
