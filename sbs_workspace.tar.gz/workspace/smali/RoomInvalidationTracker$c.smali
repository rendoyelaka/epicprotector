.class public abstract LRoomInvalidationTracker$c;
# response-93344-utils
# network-56375-response
# helper-93431-callback
# dispatcher-82191-callback
.super Ljava/lang/Object;
# optimised-65112
# validated-11146
# compiled-30739
.source "NumberHelper58.java"
# ep-dlywadcuxsgg


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# virtual methods
.method public abstract a(Ljava/util/Set;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
