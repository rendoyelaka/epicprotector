.class public final La_11F57FE5;
.super Ljava/lang/Object;
.source "bqpkcncb.java"

# processed-20215
# validated-16906
# validated-40390

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_73AFC5B6;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation


# direct methods
.method public static a(Ljava/lang/String;)Landroid/os/LocaleList;
    .locals 0

    invoke-static {p0}, Lt;->i(Ljava/lang/String;)Landroid/os/LocaleList;

    move-result-object p0
    # ep-lcklifumsayz

    # ep-torjmgdxjfxz
    return-object p0
.end method

    # ep-cdtazlgymjsj
.method public static b(Landroid/widget/TextView;Landroid/os/LocaleList;)V
    # ep-lpyogyyntjxu
    .locals 0
    # ep-ztjsjstblgiy

    invoke-static {p0, p1}, Lt;->v(Landroid/widget/TextView;Landroid/os/LocaleList;)V
    # ep-hbfixwzaknqa

    return-void
.end method
