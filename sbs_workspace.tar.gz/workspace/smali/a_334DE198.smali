.class public final La_334DE198;
.super Ldw;
# ep-mxfddjetfatw
.source "nvapxmfr.java"

# verified-38896
# validated-87356
# processed-13134

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_C9954420;->k(Landroid/view/ViewGroup;Lhw;Lhw;)Landroid/animation/Animator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public a:Z

.field public final synthetic b:Landroid/view/ViewGroup;


# direct methods
.method public constructor <init>(Landroid/view/ViewGroup;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_334DE198;->b:Landroid/view/ViewGroup;

    .line 3
    invoke-direct {p0}, Ldw;-><init>()V

    .line 6
    const/4 p1, 0x0

    .line 7
    iput-boolean p1, p0, La_334DE198;->a:Z

    .line 9
    return-void
.end method


# virtual methods
.method public final b()V
    .locals 2

    iget-object v0, p0, La_334DE198;->b:Landroid/view/ViewGroup;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lxx;->a(Landroid/view/ViewGroup;Z)V

    return-void
.end method

.method public final c()V
    .locals 2

    iget-object v0, p0, La_334DE198;->b:Landroid/view/ViewGroup;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lxx;->a(Landroid/view/ViewGroup;Z)V

    return-void
.end method

.method public final d(Law;)V
    .locals 2

    .line 1
    iget-boolean v0, p0, La_334DE198;->a:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, La_334DE198;->b:Landroid/view/ViewGroup;

    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-static {v0, v1}, Lxx;->a(Landroid/view/ViewGroup;Z)V

    .line 11
    :cond_0
    invoke-virtual {p1, p0}, Law;->v(La_A8D05313;)V

    .line 14
    return-void
.end method

.method public final e()V
    .locals 2

    .line 1
    iget-object v0, p0, La_334DE198;->b:Landroid/view/ViewGroup;

    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-static {v0, v1}, Lxx;->a(Landroid/view/ViewGroup;Z)V

    .line 7
    const/4 v0, 0x1

    .line 8
    iput-boolean v0, p0, La_334DE198;->a:Z

    .line 10
    return-void
.end method
