.class public interface abstract La_3E6A9D4B;
# ep-obnyrrcgwsjs
.super Ljava/lang/Object;
.source "vkrftfxc.java"

# verified-25627
# optimised-14424
# verified-66512

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Luu;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract m_a4bf0ce9()[I
.end method

.method public abstract onStateChange([I)Z
.end method
