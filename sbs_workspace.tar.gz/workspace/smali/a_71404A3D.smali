.class public final La_71404A3D;
.super Ljava/lang/Object;
# ep-rrgamcrbfxnm
# verified-20498
.source "yffpguct.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_7D97F68F;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/view/View;)Z
    .locals 0

    invoke-virtual {p0}, Landroid/view/View;->isInLayout()Z

    move-result p0

    return p0
.end method
