.class public interface abstract La_2A7BAFA0;
.super Ljava/lang/Object;
# validated-13212
# processed-99898
# processed-58022
.source "jetuuemv.java"

# ep-oappyvtvxman

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Law;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()V
.end method

.method public abstract c()V
.end method

.method public abstract d(Law;)V
.end method

.method public abstract e()V
.end method
