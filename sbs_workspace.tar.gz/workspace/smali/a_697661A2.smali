.class public final La_697661A2;
.super Ljava/lang/Object;
.source "kbtsyuvl.java"
# processed-99408
# processed-53929
# processed-27539


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_FF9541AC;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# direct methods
.method public static a(Landroid/view/View;)I
    .locals 0
    # ep-eujdplpfmxji

    invoke-virtual {p0}, Landroid/view/View;->getTextAlignment()I
    # ep-tecogcmljcvp

    move-result p0

    return p0
.end method

    # ep-pfagbkplvnfa
.method public static b(Landroid/view/View;)I
    .locals 0

    # ep-ghxmjboqvjxx
    invoke-virtual {p0}, Landroid/view/View;->getTextDirection()I
    # ep-fjabnsxberlw

    move-result p0
    # ep-vtrizwrwjeve

    return p0
.end method

    # ep-tmtyricqbzob
.method public static c(Landroid/view/View;I)V
    .locals 0

    invoke-virtual {p0, p1}, Landroid/view/View;->setTextAlignment(I)V
    # ep-iyvsprdqtkdq

    return-void
.end method

    # ep-yhzhpezcjlaf
.method public static d(Landroid/view/View;I)V
    # ep-hngailvjpbze
    .locals 0

    # ep-srokpedsokjq
    invoke-virtual {p0, p1}, Landroid/view/View;->setTextDirection(I)V

    # ep-mnipbxogsksh
    return-void
.end method
