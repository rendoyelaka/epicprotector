.class public final Ldh;
.super Ljava/lang/Object;
.source "lvwwofrp.java"

# ep-ieiaapvwozzd
# compiled-98156

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldh$c;,
        Ldh$a;,
        Ldh$b;
    }
.end annotation


# instance fields
.field public a:J

.field public b:J

.field public final c:I

.field public final d:LHttp2Connection;

.field public e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lgg;",
            ">;"
        }
    .end annotation
.end field

.field public final f:Ldh$b;

.field public final g:Ldh$a;

.field public final h:Ldh$c;

.field public final i:Ldh$c;

.field public j:I


# direct methods
.method public constructor <init>(ILHttp2Connection;ZZLjava/util/ArrayList;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const-wide/16 v0, 0x0

    .line 6
    iput-wide v0, p0, Ldh;->a:J

    .line 8
    new-instance p5, Ldh$c;

    .line 10
    invoke-direct {p5, p0}, Ldh$c;-><init>(Ldh;)V

    .line 13
    iput-object p5, p0, Ldh;->h:Ldh$c;

    .line 15
    new-instance p5, Ldh$c;

    .line 17
    invoke-direct {p5, p0}, Ldh$c;-><init>(Ldh;)V

    .line 20
    iput-object p5, p0, Ldh;->i:Ldh$c;

    .line 22
    const/4 p5, 0x0

    .line 23
    iput p5, p0, Ldh;->j:I

    .line 25
    if-eqz p2, :cond_0

    .line 27
    iput p1, p0, Ldh;->c:I

    .line 29
    iput-object p2, p0, Ldh;->d:LHttp2Connection;

    .line 31
    iget-object p1, p2, LHttp2Connection;->o:Lur;

    .line 33
    invoke-virtual {p1}, Lur;->a()I

    .line 36
    move-result p1

    .line 37
    int-to-long v0, p1

    .line 38
    iput-wide v0, p0, Ldh;->b:J

    .line 40
    new-instance p1, Ldh$b;

    .line 42
    iget-object p2, p2, LHttp2Connection;->n:Lur;

    .line 44
    invoke-virtual {p2}, Lur;->a()I

    .line 47
    move-result p2

    .line 48
    int-to-long v0, p2

    .line 49
    invoke-direct {p1, p0, v0, v1}, Ldh$b;-><init>(Ldh;J)V

    .line 52
    iput-object p1, p0, Ldh;->f:Ldh$b;

    .line 54
    new-instance p2, Ldh$a;

    .line 56
    invoke-direct {p2, p0}, Ldh$a;-><init>(Ldh;)V

    .line 59
    iput-object p2, p0, Ldh;->g:Ldh$a;

    .line 61
    iput-boolean p4, p1, Ldh$b;->g:Z

    .line 63
    iput-boolean p3, p2, Ldh$a;->e:Z

    .line 65
    return-void

    .line 66
    :cond_0
    new-instance p1, Ljava/lang/NullPointerException;

    .line 68
    const-string p2, "connection == null"

    .line 70
    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 73
    throw p1
.end method


# virtual methods
.method public final a()V
    .locals 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, Ldh;->f:Ldh$b;

    .line 4
    iget-boolean v1, v0, Ldh$b;->g:Z

    .line 6
    if-nez v1, :cond_1

    .line 8
    iget-boolean v0, v0, Ldh$b;->f:Z

    .line 10
    if-eqz v0, :cond_1

    .line 12
    iget-object v0, p0, Ldh;->g:Ldh$a;

    .line 14
    iget-boolean v1, v0, Ldh$a;->e:Z

    .line 16
    if-nez v1, :cond_0

    .line 18
    iget-boolean v0, v0, Ldh$a;->d:Z

    .line 20
    if-eqz v0, :cond_1

    .line 22
    :cond_0
    const/4 v0, 0x1

    .line 23
    goto :goto_0

    .line 24
    :cond_1
    const/4 v0, 0x0

    .line 25
    :goto_0
    invoke-virtual {p0}, Ldh;->e()Z

    .line 28
    move-result v1

    .line 29
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 30
    if-eqz v0, :cond_2

    .line 32
    const/4 v0, 0x6

    .line 33
    invoke-virtual {p0, v0}, Ldh;->c(I)V

    .line 36
    goto :goto_1

    .line 37
    :cond_2
    if-nez v1, :cond_3

    .line 39
    iget-object v0, p0, Ldh;->d:LHttp2Connection;

    .line 41
    iget v1, p0, Ldh;->c:I

    .line 43
    invoke-virtual {v0, v1}, LHttp2Connection;->s(I)Ldh;

    .line 46
    :cond_3
    :goto_1
    return-void

    .line 47
    :catchall_0
    move-exception v0

    .line 48
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 49
    throw v0
.end method

.method public final b()V
    .locals 2

    .line 1
    iget-object v0, p0, Ldh;->g:Ldh$a;

    .line 3
    iget-boolean v1, v0, Ldh$a;->d:Z

    .line 5
    if-nez v1, :cond_2

    .line 7
    iget-boolean v0, v0, Ldh$a;->e:Z

    .line 9
    if-nez v0, :cond_1

    .line 11
    iget v0, p0, Ldh;->j:I

    .line 13
    if-nez v0, :cond_0

    .line 15
    return-void

    .line 16
    :cond_0
    new-instance v0, Lgt;

    .line 18
    iget v1, p0, Ldh;->j:I

    .line 20
    invoke-direct {v0, v1}, Lgt;-><init>(I)V

    .line 23
    throw v0

    .line 24
    :cond_1
    new-instance v0, Ljava/io/IOException;

    .line 26
    const-string v1, "stream finished"

    .line 28
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 31
    throw v0

    .line 32
    :cond_2
    new-instance v0, Ljava/io/IOException;

    .line 34
    const-string v1, "stream closed"

    .line 36
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 39
    throw v0
.end method

.method public final c(I)V
    .locals 2

    .line 1
    invoke-virtual {p0, p1}, Ldh;->d(I)Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_0

    .line 7
    return-void

    .line 8
    :cond_0
    iget-object v0, p0, Ldh;->d:LHttp2Connection;

    .line 10
    iget-object v0, v0, LHttp2Connection;->r:Leh;

    .line 12
    iget v1, p0, Ldh;->c:I

    .line 14
    invoke-virtual {v0, v1, p1}, Leh;->v(II)V

    .line 17
    return-void
.end method

.method public final d(I)Z
    .locals 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget v0, p0, Ldh;->j:I

    .line 4
    const/4 v1, 0x0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    monitor-exit p0

    .line 8
    return v1

    .line 9
    :cond_0
    iget-object v0, p0, Ldh;->f:Ldh$b;

    .line 11
    iget-boolean v0, v0, Ldh$b;->g:Z

    .line 13
    if-eqz v0, :cond_1

    .line 15
    iget-object v0, p0, Ldh;->g:Ldh$a;

    .line 17
    iget-boolean v0, v0, Ldh$a;->e:Z

    .line 19
    if-eqz v0, :cond_1

    .line 21
    monitor-exit p0

    .line 22
    return v1

    .line 23
    :cond_1
    iput p1, p0, Ldh;->j:I

    .line 25
    invoke-virtual {p0}, Ljava/lang/Object;->notifyAll()V

    .line 28
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 29
    iget-object p1, p0, Ldh;->d:LHttp2Connection;

    .line 31
    iget v0, p0, Ldh;->c:I

    .line 33
    invoke-virtual {p1, v0}, LHttp2Connection;->s(I)Ldh;

    .line 36
    const/4 p1, 0x1

    .line 37
    return p1

    .line 38
    :catchall_0
    move-exception p1

    .line 39
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 40
    throw p1
.end method

.method public final declared-synchronized e()Z
    .locals 3

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget v0, p0, Ldh;->j:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 4
    const/4 v1, 0x0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    monitor-exit p0

    .line 8
    return v1

    .line 9
    :cond_0
    :try_start_1
    iget-object v0, p0, Ldh;->f:Ldh$b;

    .line 11
    iget-boolean v2, v0, Ldh$b;->g:Z

    .line 13
    if-nez v2, :cond_1

    .line 15
    iget-boolean v0, v0, Ldh$b;->f:Z

    .line 17
    if-eqz v0, :cond_3

    .line 19
    :cond_1
    iget-object v0, p0, Ldh;->g:Ldh$a;

    .line 21
    iget-boolean v2, v0, Ldh$a;->e:Z

    .line 23
    if-nez v2, :cond_2

    .line 25
    iget-boolean v0, v0, Ldh$a;->d:Z

    .line 27
    if-eqz v0, :cond_3

    .line 29
    :cond_2
    iget-object v0, p0, Ldh;->e:Ljava/util/List;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 31
    if-eqz v0, :cond_3

    .line 33
    monitor-exit p0

    .line 34
    return v1

    .line 35
    :cond_3
    monitor-exit p0

    .line 36
    const/4 v0, 0x1

    .line 37
    return v0

    .line 38
    :catchall_0
    move-exception v0

    .line 39
    monitor-exit p0

    .line 40
    throw v0
.end method

.method public final f()V
    .locals 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, Ldh;->f:Ldh$b;

    .line 4
    const/4 v1, 0x1

    .line 5
    iput-boolean v1, v0, Ldh$b;->g:Z

    .line 7
    invoke-virtual {p0}, Ldh;->e()Z

    .line 10
    move-result v0

    .line 11
    invoke-virtual {p0}, Ljava/lang/Object;->notifyAll()V

    .line 14
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 15
    if-nez v0, :cond_0

    .line 17
    iget-object v0, p0, Ldh;->d:LHttp2Connection;

    .line 19
    iget v1, p0, Ldh;->c:I

    .line 21
    invoke-virtual {v0, v1}, LHttp2Connection;->s(I)Ldh;

    .line 24
    :cond_0
    return-void

    .line 25
    :catchall_0
    move-exception v0

    .line 26
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 27
    throw v0
.end method

.method public final g(Ljava/util/ArrayList;)V
    .locals 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, Ldh;->e:Ljava/util/List;

    .line 4
    if-nez v0, :cond_0

    .line 6
    iput-object p1, p0, Ldh;->e:Ljava/util/List;

    .line 8
    invoke-virtual {p0}, Ldh;->e()Z

    .line 11
    move-result p1

    .line 12
    invoke-virtual {p0}, Ljava/lang/Object;->notifyAll()V

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    .line 18
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 21
    iget-object v1, p0, Ldh;->e:Ljava/util/List;

    .line 23
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 26
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 29
    iput-object v0, p0, Ldh;->e:Ljava/util/List;

    .line 31
    const/4 p1, 0x1

    .line 32
    :goto_0
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 33
    if-nez p1, :cond_1

    .line 35
    iget-object p1, p0, Ldh;->d:LHttp2Connection;

    .line 37
    iget v0, p0, Ldh;->c:I

    .line 39
    invoke-virtual {p1, v0}, LHttp2Connection;->s(I)Ldh;

    .line 42
    :cond_1
    return-void

    .line 43
    :catchall_0
    move-exception p1

    .line 44
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 45
    throw p1
.end method

.method public final declared-synchronized h(I)V
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget v0, p0, Ldh;->j:I

    .line 4
    if-nez v0, :cond_0

    .line 6
    iput p1, p0, Ldh;->j:I

    .line 8
    invoke-virtual {p0}, Ljava/lang/Object;->notifyAll()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    :cond_0
    monitor-exit p0

    .line 12
    return-void

    .line 13
    :catchall_0
    move-exception p1

    .line 14
    monitor-exit p0

    .line 15
    throw p1
.end method
