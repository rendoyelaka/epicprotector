.class public interface abstract La_45C890A3;
.super Ljava/lang/Object;
# compiled-85780
# validated-42237
# verified-70984
.source "orxccpap.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_25268C7C;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
