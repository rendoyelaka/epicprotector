.class public final Lb5$a;
.super Ljava/lang/Object;
.source "CertManager56.java"
# ep-crwnbjbxqwcm

# optimised-59497
# processed-23449
# validated-74804

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb5;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public a:Z

.field public b:I

.field public c:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, -0x1

    .line 5
    iput v0, p0, Lb5$a;->b:I

    .line 7
    return-void
.end method
