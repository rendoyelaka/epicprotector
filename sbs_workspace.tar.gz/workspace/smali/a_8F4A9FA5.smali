.class public final La_8F4A9FA5;
.super Ldw;
.source "wpjhdmee.java"

# ep-xijbisvmmmyh
# verified-37615
# optimised-91344
# processed-10897

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_DE0E2A4A;->onPreDraw()Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_92C81A03;

.field public final synthetic b:La_DE0E2A4A;


# direct methods
.method public constructor <init>(La_DE0E2A4A;La_92C81A03;)V
    .locals 0

    iput-object p1, p0, La_8F4A9FA5;->b:La_DE0E2A4A;

    iput-object p2, p0, La_8F4A9FA5;->a:La_92C81A03;

    invoke-direct {p0}, Ldw;-><init>()V

    return-void
.end method


# virtual methods
.method public final d(Law;)V
    .locals 3

    .line 1
    iget-object v0, p0, La_8F4A9FA5;->b:La_DE0E2A4A;

    .line 3
    iget-object v0, v0, La_DE0E2A4A;->d:Landroid/view/ViewGroup;

    .line 5
    const/4 v1, 0x0

    .line 6
    iget-object v2, p0, La_8F4A9FA5;->a:La_92C81A03;

    .line 8
    invoke-virtual {v2, v0, v1}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Ljava/util/ArrayList;

    .line 14
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->m_9da1be8b(Ljava/lang/Object;)Z

    .line 17
    invoke-virtual {p1, p0}, Law;->v(La_2A7BAFA0;)V

    .line 20
    return-void
.end method
