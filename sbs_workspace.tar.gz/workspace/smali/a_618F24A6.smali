.class public final La_618F24A6;
.super Ljava/lang/Object;
.source "oqehtjue.java"

# validated-27908
# generated-64153
# verified-47268
# ep-utqficnucvih
# interfaces
.implements Lyi;
.implements La_6914F142;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lyi<",
        "Ljava/lang/Object;",
        ">;",
        "La_6914F142;"
    }
.end annotation


# static fields
.field public static final b:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Class<",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final a:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 11

    .line 1
    const/16 v0, 0x17

    .line 3
    new-array v0, v0, [Ljava/lang/Class;

    .line 5
    const/4 v1, 0x0

    .line 6
    const-class v2, Lwe;

    .line 8
    aput-object v2, v0, v1

    .line 10
    const/4 v2, 0x1

    .line 11
    const-class v3, Lhf;

    .line 13
    aput-object v3, v0, v2

    .line 15
    const-class v2, Llf;

    .line 17
    const/4 v3, 0x2

    .line 18
    aput-object v2, v0, v3

    .line 20
    const/4 v2, 0x3

    .line 21
    const-class v3, Lmf;

    .line 23
    aput-object v3, v0, v2

    .line 25
    const/4 v2, 0x4

    .line 26
    const-class v3, Lnf;

    .line 28
    aput-object v3, v0, v2

    .line 30
    const/4 v2, 0x5

    .line 31
    const-class v3, Lof;

    .line 33
    aput-object v3, v0, v2

    .line 35
    const/4 v2, 0x6

    .line 36
    const-class v3, Lpf;

    .line 38
    aput-object v3, v0, v2

    .line 40
    const/4 v2, 0x7

    .line 41
    const-class v3, Lqf;

    .line 43
    aput-object v3, v0, v2

    .line 45
    const/16 v2, 0x8

    .line 47
    const-class v3, Lrf;

    .line 49
    aput-object v3, v0, v2

    .line 51
    const/16 v2, 0x9

    .line 53
    const-class v3, Lsf;

    .line 55
    aput-object v3, v0, v2

    .line 57
    const-class v2, Lxe;

    .line 59
    const/16 v3, 0xa

    .line 61
    aput-object v2, v0, v3

    .line 63
    const/16 v2, 0xb

    .line 65
    const-class v3, Lye;

    .line 67
    aput-object v3, v0, v2

    .line 69
    const/16 v2, 0xc

    .line 71
    const-class v3, Lze;

    .line 73
    aput-object v3, v0, v2

    .line 75
    const/16 v2, 0xd

    .line 77
    const-class v3, Laf;

    .line 79
    aput-object v3, v0, v2

    .line 81
    const/16 v2, 0xe

    .line 83
    const-class v3, Lbf;

    .line 85
    aput-object v3, v0, v2

    .line 87
    const/16 v2, 0xf

    .line 89
    const-class v3, Lcf;

    .line 91
    aput-object v3, v0, v2

    .line 93
    const/16 v2, 0x10

    .line 95
    const-class v3, Ldf;

    .line 97
    aput-object v3, v0, v2

    .line 99
    const/16 v2, 0x11

    .line 101
    const-class v3, Lef;

    .line 103
    aput-object v3, v0, v2

    .line 105
    const/16 v2, 0x12

    .line 107
    const-class v3, Lff;

    .line 109
    aput-object v3, v0, v2

    .line 111
    const/16 v2, 0x13

    .line 113
    const-class v3, Lgf;

    .line 115
    aput-object v3, v0, v2

    .line 117
    const/16 v2, 0x14

    .line 119
    const-class v3, Lif;

    .line 121
    aput-object v3, v0, v2

    .line 123
    const/16 v2, 0x15

    .line 125
    const-class v3, Ljf;

    .line 127
    aput-object v3, v0, v2

    .line 129
    const/16 v2, 0x16

    .line 131
    const-class v3, Lkf;

    .line 133
    aput-object v3, v0, v2

    .line 135
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 138
    move-result-object v0

    .line 139
    const-string v2, "asList(this)"

    .line 141
    invoke-static {v2, v0}, Lqi;->c(Ljava/lang/String;Ljava/lang/Object;)V

    .line 144
    new-instance v2, Ljava/util/ArrayList;

    .line 146
    invoke-interface {v0}, Ljava/util/Collection;->m_79017b7d()I

    .line 149
    move-result v3

    .line 150
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 153
    invoke-interface {v0}, Ljava/lang/Iterable;->m_722a5b0b()Ljava/util/Iterator;

    .line 156
    move-result-object v0

    .line 157
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->m_f2527d92()Z

    .line 160
    move-result v3

    .line 161
    if-eqz v3, :cond_1

    .line 163
    invoke-interface {v0}, Ljava/util/Iterator;->m_474c1ec6()Ljava/lang/Object;

    .line 166
    move-result-object v3

    .line 167
    add-int/lit8 v4, v1, 0x1

    .line 169
    if-ltz v1, :cond_0

    .line 171
    check-cast v3, Ljava/lang/Class;

    .line 173
    invoke-static {v1}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 176
    move-result-object v1

    .line 177
    new-instance v5, Lsn;

    .line 179
    invoke-direct {v5, v3, v1}, Lsn;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 182
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 185
    move v1, v4

    .line 186
    goto :goto_0

    .line 187
    :cond_0
    new-instance v0, Ljava/lang/ArithmeticException;

    .line 189
    const-string v1, "Index overflow has happened."

    .line 191
    invoke-direct {v0, v1}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    .line 194
    throw v0

    .line 195
    :cond_1
    invoke-static {v2}, Lbk;->f0(Ljava/util/ArrayList;)Ljava/util/Map;

    .line 198
    move-result-object v0

    .line 199
    sput-object v0, La_618F24A6;->b:Ljava/util/Map;

    .line 201
    new-instance v0, Ljava/util/HashMap;

    .line 203
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 206
    const-string v1, "boolean"

    .line 208
    const-string v2, "kotlin.Boolean"

    .line 210
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 213
    const-string v1, "char"

    .line 215
    const-string v3, "kotlin.Char"

    .line 217
    invoke-virtual {v0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 220
    const-string v1, "byte"

    .line 222
    const-string v4, "kotlin.Byte"

    .line 224
    invoke-virtual {v0, v1, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 227
    const-string v1, "short"

    .line 229
    const-string v5, "kotlin.Short"

    .line 231
    invoke-virtual {v0, v1, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 234
    const-string v1, "int"

    .line 236
    const-string v6, "kotlin.Int"

    .line 238
    invoke-virtual {v0, v1, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 241
    const-string v1, "float"

    .line 243
    const-string v7, "kotlin.Float"

    .line 245
    invoke-virtual {v0, v1, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 248
    const-string v1, "long"

    .line 250
    const-string v8, "kotlin.Long"

    .line 252
    invoke-virtual {v0, v1, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 255
    const-string v1, "double"

    .line 257
    const-string v9, "kotlin.Double"

    .line 259
    invoke-virtual {v0, v1, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 262
    new-instance v1, Ljava/util/HashMap;

    .line 264
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 267
    const-string v10, "java.lang.Boolean"

    .line 269
    invoke-virtual {v1, v10, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 272
    const-string v2, "java.lang.Character"

    .line 274
    invoke-virtual {v1, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 277
    const-string v2, "java.lang.Byte"

    .line 279
    invoke-virtual {v1, v2, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 282
    const-string v2, "java.lang.Short"

    .line 284
    invoke-virtual {v1, v2, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 287
    const-string v2, "java.lang.Integer"

    .line 289
    invoke-virtual {v1, v2, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 292
    const-string v2, "java.lang.Float"

    .line 294
    invoke-virtual {v1, v2, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 297
    const-string v2, "java.lang.Long"

    .line 299
    invoke-virtual {v1, v2, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 302
    const-string v2, "java.lang.Double"

    .line 304
    invoke-virtual {v1, v2, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 307
    new-instance v2, Ljava/util/HashMap;

    .line 309
    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 312
    const-string v3, "java.lang.Object"

    .line 314
    const-string v4, "kotlin.Any"

    .line 316
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 319
    const-string v3, "java.lang.String"

    .line 321
    const-string v4, "kotlin.String"

    .line 323
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 326
    const-string v3, "java.lang.CharSequence"

    .line 328
    const-string v4, "kotlin.CharSequence"

    .line 330
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 333
    const-string v3, "java.lang.Throwable"

    .line 335
    const-string v4, "kotlin.Throwable"

    .line 337
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 340
    const-string v3, "java.lang.Cloneable"

    .line 342
    const-string v4, "kotlin.Cloneable"

    .line 344
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 347
    const-string v3, "java.lang.Number"

    .line 349
    const-string v4, "kotlin.Number"

    .line 351
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 354
    const-string v3, "java.lang.Comparable"

    .line 356
    const-string v4, "kotlin.Comparable"

    .line 358
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 361
    const-string v3, "java.lang.Enum"

    .line 363
    const-string v4, "kotlin.Enum"

    .line 365
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 368
    const-string v3, "java.lang.annotation.Annotation"

    .line 370
    const-string v4, "kotlin.Annotation"

    .line 372
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 375
    const-string v3, "java.lang.Iterable"

    .line 377
    const-string v4, "kotlin.collections.Iterable"

    .line 379
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 382
    const-string v3, "java.util.Iterator"

    .line 384
    const-string v4, "kotlin.collections.Iterator"

    .line 386
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 389
    const-string v3, "java.util.Collection"

    .line 391
    const-string v4, "kotlin.collections.Collection"

    .line 393
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 396
    const-string v3, "java.util.List"

    .line 398
    const-string v4, "kotlin.collections.List"

    .line 400
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 403
    const-string v3, "java.util.Set"

    .line 405
    const-string v4, "kotlin.collections.Set"

    .line 407
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 410
    const-string v3, "java.util.ListIterator"

    .line 412
    const-string v4, "kotlin.collections.ListIterator"

    .line 414
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 417
    const-string v3, "java.util.Map"

    .line 419
    const-string v4, "kotlin.collections.Map"

    .line 421
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 424
    const-string v3, "java.util.Map$Entry"

    .line 426
    const-string v4, "kotlin.collections.Map.Entry"

    .line 428
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 431
    const-string v3, "kotlin.jvm.internal.StringCompanionObject"

    .line 433
    const-string v4, "kotlin.String.Companion"

    .line 435
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 438
    const-string v3, "kotlin.jvm.internal.EnumCompanionObject"

    .line 440
    const-string v4, "kotlin.Enum.Companion"

    .line 442
    invoke-virtual {v2, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 445
    invoke-virtual {v2, v0}, Ljava/util/HashMap;->m_6d3f85f3(Ljava/util/Map;)V

    .line 448
    invoke-virtual {v2, v1}, Ljava/util/HashMap;->m_6d3f85f3(Ljava/util/Map;)V

    .line 451
    invoke-virtual {v0}, Ljava/util/HashMap;->m_1378ba9f()Ljava/util/Collection;

    .line 454
    move-result-object v0

    .line 455
    const-string v1, "primitiveFqNames.values"

    .line 457
    invoke-static {v1, v0}, Lqi;->c(Ljava/lang/String;Ljava/lang/Object;)V

    .line 460
    invoke-interface {v0}, Ljava/lang/Iterable;->m_722a5b0b()Ljava/util/Iterator;

    .line 463
    move-result-object v0

    .line 464
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->m_f2527d92()Z

    .line 467
    move-result v1

    .line 468
    if-eqz v1, :cond_2

    .line 470
    invoke-interface {v0}, Ljava/util/Iterator;->m_474c1ec6()Ljava/lang/Object;

    .line 473
    move-result-object v1

    .line 474
    check-cast v1, Ljava/lang/String;

    .line 476
    new-instance v3, Ljava/lang/StringBuilder;

    .line 478
    const-string v4, "kotlin.jvm.internal."

    .line 480
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 483
    const-string v4, "kotlinName"

    .line 485
    invoke-static {v4, v1}, Lqi;->c(Ljava/lang/String;Ljava/lang/Object;)V

    .line 488
    invoke-static {v1}, Lkt;->i0(Ljava/lang/String;)Ljava/lang/String;

    .line 491
    move-result-object v4

    .line 492
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 495
    const-string v4, "CompanionObject"

    .line 497
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 500
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 503
    move-result-object v3

    .line 504
    const-string v4, ".Companion"

    .line 506
    invoke-virtual {v1, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 509
    move-result-object v1

    .line 510
    invoke-virtual {v2, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 513
    goto :goto_1

    .line 514
    :cond_2
    sget-object v0, La_618F24A6;->b:Ljava/util/Map;

    .line 516
    invoke-interface {v0}, Ljava/util/Map;->m_534fa476()Ljava/util/Set;

    .line 519
    move-result-object v0

    .line 520
    invoke-interface {v0}, Ljava/util/Set;->m_722a5b0b()Ljava/util/Iterator;

    .line 523
    move-result-object v0

    .line 524
    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->m_f2527d92()Z

    .line 527
    move-result v1

    .line 528
    if-eqz v1, :cond_3

    .line 530
    invoke-interface {v0}, Ljava/util/Iterator;->m_474c1ec6()Ljava/lang/Object;

    .line 533
    move-result-object v1

    .line 534
    check-cast v1, Ljava/util/Map$Entry;

    .line 536
    invoke-interface {v1}, Ljava/util/Map$Entry;->m_5f0274a8()Ljava/lang/Object;

    .line 539
    move-result-object v3

    .line 540
    check-cast v3, Ljava/lang/Class;

    .line 542
    invoke-interface {v1}, Ljava/util/Map$Entry;->m_9a086b7a()Ljava/lang/Object;

    .line 545
    move-result-object v1

    .line 546
    check-cast v1, Ljava/lang/Number;

    .line 548
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 551
    move-result v1

    .line 552
    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 555
    move-result-object v3

    .line 556
    new-instance v4, Ljava/lang/StringBuilder;

    .line 558
    const-string v5, "kotlin.Function"

    .line 560
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 563
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 566
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 569
    move-result-object v1

    .line 570
    invoke-virtual {v2, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 573
    goto :goto_2

    .line 574
    :cond_3
    new-instance v0, Ljava/util/LinkedHashMap;

    .line 576
    invoke-virtual {v2}, Ljava/util/HashMap;->m_79017b7d()I

    .line 579
    move-result v1

    .line 580
    invoke-static {v1}, La_2C13166E;->m_767412bd(I)I

    .line 583
    move-result v1

    .line 584
    invoke-direct {v0, v1}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 587
    invoke-virtual {v2}, Ljava/util/HashMap;->m_534fa476()Ljava/util/Set;

    .line 590
    move-result-object v1

    .line 591
    invoke-interface {v1}, Ljava/lang/Iterable;->m_722a5b0b()Ljava/util/Iterator;

    .line 594
    move-result-object v1

    .line 595
    :goto_3
    invoke-interface {v1}, Ljava/util/Iterator;->m_f2527d92()Z

    .line 598
    move-result v2

    .line 599
    if-eqz v2, :cond_4

    .line 601
    invoke-interface {v1}, Ljava/util/Iterator;->m_474c1ec6()Ljava/lang/Object;

    .line 604
    move-result-object v2

    .line 605
    check-cast v2, Ljava/util/Map$Entry;

    .line 607
    invoke-interface {v2}, Ljava/util/Map$Entry;->m_5f0274a8()Ljava/lang/Object;

    .line 610
    move-result-object v3

    .line 611
    invoke-interface {v2}, Ljava/util/Map$Entry;->m_9a086b7a()Ljava/lang/Object;

    .line 614
    move-result-object v2

    .line 615
    check-cast v2, Ljava/lang/String;

    .line 617
    invoke-static {v2}, Lkt;->i0(Ljava/lang/String;)Ljava/lang/String;

    .line 620
    move-result-object v2

    .line 621
    invoke-interface {v0, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 624
    goto :goto_3

    .line 625
    :cond_4
    return-void
.end method

.method public constructor <init>(Ljava/lang/Class;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)V"
        }
    .end annotation

    .line 1
    const-string v0, "jClass"

    .line 3
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    iput-object p1, p0, La_618F24A6;->a:Ljava/lang/Class;

    .line 11
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Class;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    iget-object v0, p0, La_618F24A6;->a:Ljava/lang/Class;

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    instance-of v0, p1, La_618F24A6;

    if-eqz v0, :cond_0

    invoke-static {p0}, La_2C13166E;->m_8461ad83(Lyi;)Ljava/lang/Class;

    move-result-object v0

    check-cast p1, Lyi;

    invoke-static {p1}, La_2C13166E;->m_8461ad83(Lyi;)Ljava/lang/Class;

    move-result-object p1

    invoke-static {v0, p1}, Lqi;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final hashCode()I
    .locals 1

    invoke-static {p0}, La_2C13166E;->m_8461ad83(Lyi;)Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, La_618F24A6;->a:Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/Class;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " (Kotlin reflection is not available)"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
