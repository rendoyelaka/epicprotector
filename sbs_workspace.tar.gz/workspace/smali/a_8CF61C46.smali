.class public final La_8CF61C46;
.super Ljava/lang/Object;
# ep-gfscvnjwbdyd
.source "tvbtbzcr.java"

# validated-63733
# generated-48905
# compiled-30896
# interfaces
.implements Landroid/view/View$OnApplyWindowInsetsListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_8BEC52A9;->u(Landroid/view/View;Lfn;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public a:Lwz;

.field public final synthetic b:Landroid/view/View;

.field public final synthetic c:Lfn;


# direct methods
.method public constructor <init>(Landroid/view/View;Lfn;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_8CF61C46;->b:Landroid/view/View;

    .line 3
    iput-object p2, p0, La_8CF61C46;->c:Lfn;

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    const/4 p1, 0x0

    .line 9
    iput-object p1, p0, La_8CF61C46;->a:Lwz;

    .line 11
    return-void
.end method


# virtual methods
.method public onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .locals 5

    .line 1
    invoke-static {p1, p2}, Lwz;->h(Landroid/view/View;Landroid/view/WindowInsets;)Lwz;

    .line 4
    move-result-object v0

    .line 5
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 7
    iget-object v2, p0, La_8CF61C46;->c:Lfn;

    .line 9
    const/16 v3, 0x1e

    .line 11
    if-ge v1, v3, :cond_0

    .line 13
    iget-object v4, p0, La_8CF61C46;->b:Landroid/view/View;

    .line 15
    invoke-static {p2, v4}, La_8BEC52A9;->a(Landroid/view/WindowInsets;Landroid/view/View;)V

    .line 18
    iget-object p2, p0, La_8CF61C46;->a:Lwz;

    .line 20
    invoke-virtual {v0, p2}, Lwz;->equals(Ljava/lang/Object;)Z

    .line 23
    move-result p2

    .line 24
    if-eqz p2, :cond_0

    .line 26
    invoke-interface {v2, p1, v0}, Lfn;->a(Landroid/view/View;Lwz;)Lwz;

    .line 29
    move-result-object p1

    .line 30
    invoke-virtual {p1}, Lwz;->g()Landroid/view/WindowInsets;

    .line 33
    move-result-object p1

    .line 34
    return-object p1

    .line 35
    :cond_0
    iput-object v0, p0, La_8CF61C46;->a:Lwz;

    .line 37
    invoke-interface {v2, p1, v0}, Lfn;->a(Landroid/view/View;Lwz;)Lwz;

    .line 40
    move-result-object p2

    .line 41
    if-lt v1, v3, :cond_1

    .line 43
    invoke-virtual {p2}, Lwz;->g()Landroid/view/WindowInsets;

    .line 46
    move-result-object p1

    .line 47
    return-object p1

    .line 48
    :cond_1
    sget-object v0, Lqx;->a:Ljava/util/WeakHashMap;

    .line 50
    invoke-static {p1}, La_09F7FDBC;->c(Landroid/view/View;)V

    .line 53
    invoke-virtual {p2}, Lwz;->g()Landroid/view/WindowInsets;

    .line 56
    move-result-object p1

    .line 57
    return-object p1
.end method
