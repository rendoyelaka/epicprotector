.class public final La_745F9654;
.super Ljava/lang/Object;
.source "kpcsokys.java"
# processed-13631
# compiled-39947


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_65148E78;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public a:Z

.field public b:I

.field public c:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, -0x1

    .line 5
    iput v0, p0, La_745F9654;->b:I

    .line 7
    return-void
.end method
