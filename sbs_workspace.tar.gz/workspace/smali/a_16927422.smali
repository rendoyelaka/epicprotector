.class public final La_16927422;
.super Ljava/lang/Object;
.source "eyqbnodn.java"
# ep-pzlkvgmuhvuw

# verified-90500
# processed-59006
# optimised-42482
# interfaces
.implements La_F3196EE8;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_50334AF1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "f"
.end annotation


# instance fields
.field public final a:Landroid/content/ClipData;

.field public final b:I

.field public final c:I

.field public final d:Landroid/net/Uri;

.field public final e:Landroid/os/Bundle;


# direct methods
.method public constructor <init>(La_9CD323E7;)V
    .locals 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iget-object v0, p1, La_9CD323E7;->a:Landroid/content/ClipData;

    .line 6
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    iput-object v0, p0, La_16927422;->a:Landroid/content/ClipData;

    .line 11
    const/4 v0, 0x1

    .line 12
    const/4 v1, 0x0

    .line 13
    iget v2, p1, La_9CD323E7;->b:I

    .line 15
    const/4 v3, 0x5

    .line 16
    const-string v4, "source"

    .line 18
    const/4 v5, 0x2

    .line 19
    const/4 v6, 0x3

    .line 20
    if-ltz v2, :cond_2

    .line 22
    if-gt v2, v3, :cond_1

    .line 24
    iput v2, p0, La_16927422;->b:I

    .line 26
    iget v1, p1, La_9CD323E7;->c:I

    .line 28
    and-int/lit8 v2, v1, 0x1

    .line 30
    if-ne v2, v1, :cond_0

    .line 32
    iput v1, p0, La_16927422;->c:I

    .line 34
    iget-object v0, p1, La_9CD323E7;->d:Landroid/net/Uri;

    .line 36
    iput-object v0, p0, La_16927422;->d:Landroid/net/Uri;

    .line 38
    iget-object p1, p1, La_9CD323E7;->e:Landroid/os/Bundle;

    .line 40
    iput-object p1, p0, La_16927422;->e:Landroid/os/Bundle;

    .line 42
    return-void

    .line 43
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 45
    new-instance v2, Ljava/lang/StringBuilder;

    .line 47
    const-string v3, "Requested flags 0x"

    .line 49
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 52
    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 55
    move-result-object v1

    .line 56
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    const-string v1, ", but only 0x"

    .line 61
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 67
    move-result-object v0

    .line 68
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 71
    const-string v0, " are allowed"

    .line 73
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 76
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 79
    move-result-object v0

    .line 80
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 83
    throw p1

    .line 84
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 86
    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 88
    new-array v6, v6, [Ljava/lang/Object;

    .line 90
    aput-object v4, v6, v1

    .line 92
    invoke-static {v1}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 95
    move-result-object v1

    .line 96
    aput-object v1, v6, v0

    .line 98
    invoke-static {v3}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 101
    move-result-object v0

    .line 102
    aput-object v0, v6, v5

    .line 104
    const-string v0, "%s is out of range of [%d, %d] (too high)"

    .line 106
    invoke-static {v2, v0, v6}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 109
    move-result-object v0

    .line 110
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 113
    throw p1

    .line 114
    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 116
    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 118
    new-array v6, v6, [Ljava/lang/Object;

    .line 120
    aput-object v4, v6, v1

    .line 122
    invoke-static {v1}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 125
    move-result-object v1

    .line 126
    aput-object v1, v6, v0

    .line 128
    invoke-static {v3}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 131
    move-result-object v0

    .line 132
    aput-object v0, v6, v5

    .line 134
    const-string v0, "%s is out of range of [%d, %d] (too low)"

    .line 136
    invoke-static {v2, v0, v6}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 139
    move-result-object v0

    .line 140
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 143
    throw p1
.end method


# virtual methods
.method public final a()Landroid/content/ClipData;
    .locals 1

    iget-object v0, p0, La_16927422;->a:Landroid/content/ClipData;

    return-object v0
.end method

.method public final b()I
    .locals 1

    iget v0, p0, La_16927422;->c:I

    return v0
.end method

.method public final c()Landroid/view/ContentInfo;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final d()I
    .locals 1

    iget v0, p0, La_16927422;->b:I

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 5

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    const-string v1, "ContentInfoCompat{clip="

    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 8
    iget-object v1, p0, La_16927422;->a:Landroid/content/ClipData;

    .line 10
    invoke-virtual {v1}, Landroid/content/ClipData;->getDescription()Landroid/content/ClipDescription;

    .line 13
    move-result-object v1

    .line 14
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 17
    const-string v1, ", source="

    .line 19
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 22
    iget v1, p0, La_16927422;->b:I

    .line 24
    if-eqz v1, :cond_5

    .line 26
    const/4 v2, 0x1

    .line 27
    if-eq v1, v2, :cond_4

    .line 29
    const/4 v2, 0x2

    .line 30
    if-eq v1, v2, :cond_3

    .line 32
    const/4 v2, 0x3

    .line 33
    if-eq v1, v2, :cond_2

    .line 35
    const/4 v2, 0x4

    .line 36
    if-eq v1, v2, :cond_1

    .line 38
    const/4 v2, 0x5

    .line 39
    if-eq v1, v2, :cond_0

    .line 41
    invoke-static {v1}, Ljava/lang/String;->m_446e0ad6(I)Ljava/lang/String;

    .line 44
    move-result-object v1

    .line 45
    goto :goto_0

    .line 46
    :cond_0
    const-string v1, "SOURCE_PROCESS_TEXT"

    .line 48
    goto :goto_0

    .line 49
    :cond_1
    const-string v1, "SOURCE_AUTOFILL"

    .line 51
    goto :goto_0

    .line 52
    :cond_2
    const-string v1, "SOURCE_DRAG_AND_DROP"

    .line 54
    goto :goto_0

    .line 55
    :cond_3
    const-string v1, "SOURCE_INPUT_METHOD"

    .line 57
    goto :goto_0

    .line 58
    :cond_4
    const-string v1, "SOURCE_CLIPBOARD"

    .line 60
    goto :goto_0

    .line 61
    :cond_5
    const-string v1, "SOURCE_APP"

    .line 63
    :goto_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    const-string v1, ", flags="

    .line 68
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 71
    iget v1, p0, La_16927422;->c:I

    .line 73
    and-int/lit8 v2, v1, 0x1

    .line 75
    if-eqz v2, :cond_6

    .line 77
    const-string v1, "FLAG_CONVERT_TO_PLAIN_TEXT"

    .line 79
    goto :goto_1

    .line 80
    :cond_6
    invoke-static {v1}, Ljava/lang/String;->m_446e0ad6(I)Ljava/lang/String;

    .line 83
    move-result-object v1

    .line 84
    :goto_1
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 87
    const-string v1, ""

    .line 89
    iget-object v2, p0, La_16927422;->d:Landroid/net/Uri;

    .line 91
    if-nez v2, :cond_7

    .line 93
    move-object v2, v1

    .line 94
    goto :goto_2

    .line 95
    :cond_7
    new-instance v3, Ljava/lang/StringBuilder;

    .line 97
    const-string v4, ", hasLinkUri("

    .line 99
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 102
    invoke-virtual {v2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 105
    move-result-object v2

    .line 106
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 109
    move-result v2

    .line 110
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 113
    const-string v2, ")"

    .line 115
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 118
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 121
    move-result-object v2

    .line 122
    :goto_2
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 125
    iget-object v2, p0, La_16927422;->e:Landroid/os/Bundle;

    .line 127
    if-nez v2, :cond_8

    .line 129
    goto :goto_3

    .line 130
    :cond_8
    const-string v1, ", hasExtras"

    .line 132
    :goto_3
    const-string v2, "}"

    .line 134
    invoke-static {v0, v1, v2}, Lps;->e(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 137
    move-result-object v0

    .line 138
    return-object v0
.end method
