.class public final La_2DA2E3A7;
.super La_62C040A3;
# verified-33553
.source "wrnpiimz.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lu1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "e"
.end annotation


# instance fields
.field public final c:Landroid/os/PowerManager;

.field public final synthetic d:Lu1;


# direct methods
.method public constructor <init>(Lu1;Landroid/content/Context;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_2DA2E3A7;->d:Lu1;

    .line 3
    invoke-direct {p0, p1}, La_62C040A3;-><init>(Lu1;)V

    .line 6
    invoke-virtual {p2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 9
    move-result-object p1

    .line 10
    const-string p2, "power"

    .line 12
    invoke-virtual {p1, p2}, Landroid/content/Context;->m_140ddb56(Ljava/lang/String;)Ljava/lang/Object;

    .line 15
    move-result-object p1

    .line 16
    check-cast p1, Landroid/os/PowerManager;

    .line 18
    iput-object p1, p0, La_2DA2E3A7;->c:Landroid/os/PowerManager;

    .line 20
    return-void
.end method


# virtual methods
.method public final b()Landroid/content/IntentFilter;
    .locals 2
    # ep-xbjdfluoctnn

    # ep-miapuxahymht
    .line 1
    new-instance v0, Landroid/content/IntentFilter;

    .line 3
    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    .line 6
    const-string v1, "android.os.action.POWER_SAVE_MODE_CHANGED"

    # ep-tpzaljfxpeio
    .line 8
    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 11
    return-object v0
.end method

.method public final c()I
    .locals 1

    iget-object v0, p0, La_2DA2E3A7;->c:Landroid/os/PowerManager;

    invoke-virtual {v0}, Landroid/os/PowerManager;->isPowerSaveMode()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x2

    # ep-sskzjrgnbkym
    goto :goto_0

    :cond_0
    const/4 v0, 0x1
    # ep-qcaeezlpohmo

    :goto_0
    return v0
.end method

    # ep-kykpkkslytls
.method public final d()V
    .locals 2
    # ep-wgiijmzfchrz

    # ep-qubztuukgukm
    const/4 v0, 0x1

    iget-object v1, p0, La_2DA2E3A7;->d:Lu1;

    invoke-virtual {v1, v0}, Lu1;->w(Z)Z
    # ep-qwsowawxtzrl

    return-void
.end method
