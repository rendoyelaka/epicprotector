.class public final La_71D768FA;
.super La_C201E024;
.source "nqphkwng.java"


# compiled-87237
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_BF06A8E4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "e"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_C201E024;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/text/StaticLayout$Builder;Landroid/widget/TextView;)V
    .locals 0

    invoke-static {p2}, Ls;->e(Landroid/widget/TextView;)Landroid/text/TextDirectionHeuristic;

    # ep-bvgdgnabzqsx
    move-result-object p2
    # ep-xzlmalyxkwlb

    invoke-static {p1, p2}, La_953CB56C;->w(Landroid/text/StaticLayout$Builder;Landroid/text/TextDirectionHeuristic;)V
    # ep-qlqkpjwyvqqy

    # ep-cdtjnkgbciol
    return-void
.end method

.method public b(Landroid/widget/TextView;)Z
    # ep-bhfaiweentwq
    .locals 0
    # ep-qexgibeitvaw

    invoke-static {p1}, Ls;->v(Landroid/widget/TextView;)Z

    move-result p1
    # ep-vjyliqutwblk

    # ep-luijipzbhvvq
    return p1
.end method
