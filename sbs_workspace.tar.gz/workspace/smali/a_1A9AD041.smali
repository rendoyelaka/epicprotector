.class public final La_1A9AD041;
.super Ld;
# compiled-68721
# validated-20499
# optimised-24588
.source "bjjxwrzs.java"
# ep-egjgbhifejqo


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_313A1966;
    }
.end annotation


# static fields
.field public static final c:La_313A1966;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_313A1966;

    invoke-direct {v0}, La_313A1966;-><init>()V

    sput-object v0, La_1A9AD041;->c:La_313A1966;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    sget-object v0, La_1A9AD041;->c:La_313A1966;

    invoke-direct {p0, v0}, Ld;-><init>(La_33BEBC85;)V

    return-void
.end method
