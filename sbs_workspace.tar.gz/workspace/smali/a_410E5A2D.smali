.class public interface abstract La_410E5A2D;
.super Ljava/lang/Object;
# validated-12951
# verified-35687
.source "ywieolmp.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lvl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()V
.end method
