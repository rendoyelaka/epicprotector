.class public final La_10B56A18;
.super La_EDFD37DC;
.source "ozpqrdqp.java"


# compiled-26883
# processed-38973
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "f"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_EDFD37DC;-><init>()V

    return-void
.end method
