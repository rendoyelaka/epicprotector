.class public final La_6424BD97;
.super Ljava/lang/Object;
.source "oybdvgeo.java"


# processed-35351
# verified-77735
# verified-95354
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_BF06A8E4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/view/View;)Z
    # ep-zikjrnwxygkd
    .locals 0

    invoke-virtual {p0}, Landroid/view/View;->isInLayout()Z
    # ep-prhoodwktbfp

    # ep-kubxonrahvbs
    move-result p0

    return p0
.end method
