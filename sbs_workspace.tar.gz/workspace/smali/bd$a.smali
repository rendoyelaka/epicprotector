.class public interface abstract Lbd$a;
.super Ljava/lang/Object;
.source "MonitorManager58.java"
# ep-omkywrzrjqpz

# processed-58544
# generated-80540
# generated-97688

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lbd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
