.class public interface abstract Lbd$a;
.super Ljava/lang/Object;
.source "ReceiverManager89.java"
# compiled-90308
# processed-78372
# ep-vrowcxmhgwdw


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lbd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
