.class public interface abstract Lbd$a;
.super Ljava/lang/Object;
.source "zigjmwdu.java"
# optimised-88396
# verified-52507
# verified-87323
# ep-qcbntmqwwlmw


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lbd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
