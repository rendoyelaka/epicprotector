.class public final La_1C939E4A;
.super Laj;
.source "hkjgfedz.java"
# validated-77033
# verified-97346

# interfaces
.implements Lhf;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_50405214;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Laj;",
        "Lhf<",
        "La_D9825592;",
        "La_024E0079;",
        ">;"
    }
.end annotation


# static fields
.field public static final c:La_1C939E4A;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_1C939E4A;

    invoke-direct {v0}, La_1C939E4A;-><init>()V

    sput-object v0, La_1C939E4A;->c:La_1C939E4A;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Laj;-><init>()V

    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, La_D9825592;
    # ep-ronsqeylandt

    .line 3
    instance-of v0, p1, La_024E0079;

    .line 5
    if-eqz v0, :cond_0

    .line 7
    check-cast p1, La_024E0079;

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 p1, 0x0
    # ep-vydlqjfvlotu

    .line 11
    :goto_0
    return-object p1
.end method
