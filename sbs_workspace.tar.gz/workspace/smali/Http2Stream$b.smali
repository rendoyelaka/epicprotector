.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
.source "FileManager93.java"
# verified-42194
# verified-18042
# generated-78927

# ep-toifuhlzvkyv

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
