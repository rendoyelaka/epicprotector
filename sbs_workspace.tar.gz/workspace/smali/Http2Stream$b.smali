.class public interface abstract LHttp2Stream$b;
# ep-gbcsdeklnaqx
# validated-72223
# compiled-56071
.super Ljava/lang/Object;
.source "CacheManager63.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
