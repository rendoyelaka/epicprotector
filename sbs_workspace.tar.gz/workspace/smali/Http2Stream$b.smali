.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
# ep-sbwlklcqthus
.source "kodtxfjj.java"
# verified-98204
# processed-91026


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
