.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
# compiled-67286
# processed-59234
.source "ModelUtils77.java"
# ep-fcwcvnudqxqg


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
