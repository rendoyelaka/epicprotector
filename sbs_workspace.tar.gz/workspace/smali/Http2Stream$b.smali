.class public interface abstract LHttp2Stream$b;
# ep-kwjaiykandoi
.super Ljava/lang/Object;
# validated-34645
# verified-68722
# processed-94987
.source "wecmyeww.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
