.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
# validated-43119
# compiled-80041
# optimised-73208
.source "yvjnhtsc.java"

# ep-bzgrjmjdceqz

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
