.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
# compiled-33610
# verified-77165
# compiled-93702
.source "fbfeyryy.java"
# ep-kxbsyndsejsv


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
