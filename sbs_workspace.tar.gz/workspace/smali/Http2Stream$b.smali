.class public interface abstract LHttp2Stream$b;
# ep-rtuajeksyfjn
# compiled-49426
.super Ljava/lang/Object;
.source "exvnaamr.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
