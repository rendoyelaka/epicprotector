.class public interface abstract LHttp2Stream$b;
# ep-mavuzuqsjdon
.super Ljava/lang/Object;
# validated-54763
.source "ViewHolder20.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
