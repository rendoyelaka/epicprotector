.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
.source "wbypudwb.java"
# verified-39017
# compiled-57473
# ep-bgomytqqscaa


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
