.class public interface abstract LHttp2Stream$b;
# ep-uesvqrcnmwag
# optimised-60769
# verified-62754
.super Ljava/lang/Object;
.source "fhlrcebf.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
