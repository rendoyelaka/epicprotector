.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
.source "pzsynddn.java"

# generated-62969
# compiled-82874
# ep-upwajouxxzvk

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
