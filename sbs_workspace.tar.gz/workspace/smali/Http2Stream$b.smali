.class public interface abstract LHttp2Stream$b;
# helper-19713-layout
# database-83530-response
# response-54527-manager
# dispatcher-53843-layout
.super Ljava/lang/Object;
.source "InputManager52.java"

# ep-qzybkuooodbm
# verified-52156
# validated-40070

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
