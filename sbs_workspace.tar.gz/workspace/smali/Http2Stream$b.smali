.class public interface abstract LHttp2Stream$b;
# ep-lmdikjddolmx
# compiled-77469
# verified-16541
# optimised-89445
.super Ljava/lang/Object;
.source "yavauvbh.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
