.class public interface abstract LHttp2Stream$b;
# ep-uiglxckzqmhp
.super Ljava/lang/Object;
.source "sfmmdetl.java"

# verified-41618
# generated-16299
# optimised-54553

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
