.class public interface abstract LHttp2Stream$b;
# ep-cmzeqfpjhuui
# verified-59188
.super Ljava/lang/Object;
.source "twnuhebt.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
