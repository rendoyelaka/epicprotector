.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
.source "slbpwmxl.java"

# verified-42013
# verified-50240
# compiled-39316
# ep-zyuzntlljkib

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
