.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
# processed-63222
# generated-73573
# ep-gzuszptavyka
.source "xlwyekjx.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
