.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
# optimised-14324
# optimised-64395
# compiled-66614
.source "xxorbgam.java"

# ep-sjrnjsozutzy

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
