.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
# ep-xomtbmcnpcsj
.source "yyeulnoh.java"

# generated-99226
# verified-75622
# verified-51998

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
