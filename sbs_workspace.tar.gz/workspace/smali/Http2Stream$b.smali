.class public interface abstract LHttp2Stream$b;
# ep-rfcxpzuivfkm
.super Ljava/lang/Object;
# processed-90491
.source "mwbmslyn.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
