.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
# processed-52745
# validated-22165
# compiled-30196
.source "vttpbyel.java"

# ep-tzhvsmlnqhlm

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
