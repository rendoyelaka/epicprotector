.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
# verified-51256
# verified-28585
.source "sqesviot.java"
# ep-qskhgmxibget


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
