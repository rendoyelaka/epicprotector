.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
# optimised-54850
# validated-61040
# processed-17756
.source "uhtugjrz.java"

# ep-nqwyijgiiiko

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
