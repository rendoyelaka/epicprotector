.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
# ep-lzfvvqeryczw
# validated-40553
# validated-81010
# verified-31469
.source "mjhejidx.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
