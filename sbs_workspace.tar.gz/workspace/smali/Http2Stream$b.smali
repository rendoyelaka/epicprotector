.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
.source "ukwfhryj.java"
# ep-wzktofttpoxy

# validated-86295
# optimised-92703
# verified-79342

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
