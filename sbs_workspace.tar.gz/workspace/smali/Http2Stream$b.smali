.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
.source "jmmwzfwz.java"

# optimised-45422
# processed-10184
# ep-idqpdrgfccsw

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
