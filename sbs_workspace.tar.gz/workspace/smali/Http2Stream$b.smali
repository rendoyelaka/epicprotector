.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
.source "lspkdcqr.java"
# ep-mbhdfpucsbln

# verified-57465
# optimised-63981

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
