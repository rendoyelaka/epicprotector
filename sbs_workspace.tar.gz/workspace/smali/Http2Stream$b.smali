.class public interface abstract LHttp2Stream$b;
# ep-weijcyguudrc
.super Ljava/lang/Object;
# processed-40896
# optimised-16390
# generated-33183
.source "iqpienpa.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
