.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
# compiled-31848
# generated-21243
# generated-85631
# ep-nfexlsjflmzf
.source "wcufdxes.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
