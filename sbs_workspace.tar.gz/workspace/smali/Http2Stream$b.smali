.class public interface abstract LHttp2Stream$b;
# ep-zdhjxygwgpeb
.super Ljava/lang/Object;
# processed-29385
# generated-63154
# validated-34212
.source "kchbbldv.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
