.class public interface abstract LHttp2Stream$b;
# ep-cdaixgmmiqcy
.super Ljava/lang/Object;
# validated-66047
# generated-57970
# optimised-91670
.source "llohbdel.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
