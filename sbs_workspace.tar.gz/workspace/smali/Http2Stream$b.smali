.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
.source "jrjjeucd.java"

# processed-23255
# optimised-51182
# generated-10926
# ep-kbepwrlilivg

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
