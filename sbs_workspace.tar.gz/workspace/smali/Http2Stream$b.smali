.class public interface abstract LHttp2Stream$b;
.super Ljava/lang/Object;
.source "vzfiecum.java"

# ep-pfwekyarekkx
# validated-19050
# processed-23368

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
