.class public final La_511C96D2;
.super Ljava/lang/Object;
# verified-69902
.source "rewubkbh.java"

# interfaces
.implements La_B801007C;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_A9404FF7;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field public final a:Landroid/content/ClipData;

.field public final b:I

.field public c:I

.field public d:Landroid/net/Uri;

.field public e:Landroid/os/Bundle;


# direct methods
.method public constructor <init>(Landroid/content/ClipData;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_511C96D2;->a:Landroid/content/ClipData;

    .line 6
    iput p2, p0, La_511C96D2;->b:I

    .line 8
    return-void
.end method


# virtual methods
.method public final a(Landroid/net/Uri;)V
    # ep-zxqnnihdcjls
    .locals 0

    # ep-cvqrmiehowpd
    iput-object p1, p0, La_511C96D2;->d:Landroid/net/Uri;
    # ep-lzkhrxwvzmoh

    # ep-bwrarlmpdqsk
    return-void
.end method

    # ep-qixtzsloditw
.method public final b(I)V
    .locals 0

    # ep-frrvhgruchzy
    iput p1, p0, La_511C96D2;->c:I

    return-void
.end method

.method public final m_51cc275b()La_A9404FF7;
    .locals 2

    new-instance v0, La_A9404FF7;
    # ep-lbmedrikcnec

    new-instance v1, La_E3318954;

    invoke-direct {v1, p0}, La_E3318954;-><init>(La_511C96D2;)V

    # ep-vcupikhhhsbc
    invoke-direct {v0, v1}, La_A9404FF7;-><init>(La_44A18E48;)V

    return-object v0
.end method

.method public final m_fe581fe7(Landroid/os/Bundle;)V
    # ep-aivfdebupvyi
    .locals 0

    # ep-wtcghfjzcwso
    iput-object p1, p0, La_511C96D2;->e:Landroid/os/Bundle;

    # ep-mkmwumlgomnp
    return-void
.end method
