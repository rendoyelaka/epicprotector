.class public final Lak$e;
.super Ljava/lang/Object;
.source "ndgffote.java"

# verified-39007
# optimised-27856
# verified-82874
# ep-giuqzgmfjoop
# interfaces
.implements Ljava/util/Collection;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lak;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "e"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Collection<",
        "TV;>;"
    }
.end annotation


# instance fields
.field public final synthetic c:Lak;


# direct methods
.method public constructor <init>(Lak;)V
    .locals 0

    iput-object p1, p0, Lak$e;->c:Lak;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final add(Ljava/lang/Object;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;)Z"
        }
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final addAll(Ljava/util/Collection;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "+TV;>;)Z"
        }
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final clear()V
    .locals 1

    iget-object v0, p0, Lak$e;->c:Lak;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_ronh67u3
    goto :ep_s_ronh67u3
    :ep_d_ronh67u3
    nop
    :ep_s_ronh67u3
    invoke-virtual {v0}, Lak;->a()V

    return-void
.end method

.method public final contains(Ljava/lang/Object;)Z
    .locals 1

    iget-object v0, p0, Lak$e;->c:Lak;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_6t73rilu
    goto :ep_s_6t73rilu
    :ep_d_6t73rilu
    nop
    :ep_s_6t73rilu
    invoke-virtual {v0, p1}, Lak;->f(Ljava/lang/Object;)I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_4bhay56o
    goto :ep_s_4bhay56o
    :ep_d_4bhay56o
    nop
    :ep_s_4bhay56o
    move-result p1

    if-ltz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final containsAll(Ljava/util/Collection;)Z
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "*>;)Z"
        }
    .end annotation

    .line 1
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 4
    move-result-object p1

    .line 5
    :cond_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_1

    .line 11
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {p0, v0}, Lak$e;->contains(Ljava/lang/Object;)Z

    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_0

    .line 21
    const/4 p1, 0x0

    .line 22
    return p1

    .line 23
    :cond_1
    const/4 p1, 0x1

    .line 24
    return p1
.end method

.method public final isEmpty()Z
    .locals 1

    iget-object v0, p0, Lak$e;->c:Lak;

    invoke-virtual {v0}, Lak;->d()I

    move-result v0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_zbfq3fhf
    goto :ep_s_zbfq3fhf
    :ep_d_zbfq3fhf
    nop
    :ep_s_zbfq3fhf
    if-nez v0, :cond_0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_a3a1yvu1
    goto :ep_s_a3a1yvu1
    :ep_d_a3a1yvu1
    nop
    :ep_s_a3a1yvu1
    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final iterator()Ljava/util/Iterator;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TV;>;"
        }
    .end annotation

    new-instance v0, Lak$a;

    const/4 v2, 0x1
    if-ne v2, v2, :ep_d_wwd4yovp
    goto :ep_s_wwd4yovp
    :ep_d_wwd4yovp
    nop
    :ep_s_wwd4yovp
    iget-object v1, p0, Lak$e;->c:Lak;

    const/4 v2, 0x1
    if-ne v2, v2, :ep_d_1n2puvx5
    goto :ep_s_1n2puvx5
    :ep_d_1n2puvx5
    nop
    :ep_s_1n2puvx5
    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lak$a;-><init>(Lak;I)V

    return-object v0
.end method

.method public final remove(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    iget-object v0, p0, Lak$e;->c:Lak;

    .line 3
    invoke-virtual {v0, p1}, Lak;->f(Ljava/lang/Object;)I

    .line 6
    move-result p1

    .line 7
    if-ltz p1, :cond_0

    .line 9
    invoke-virtual {v0, p1}, Lak;->h(I)V

    .line 12
    const/4 p1, 0x1

    .line 13
    return p1

    .line 14
    :cond_0
    const/4 p1, 0x0

    .line 15
    return p1
.end method

.method public final removeAll(Ljava/util/Collection;)Z
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "*>;)Z"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lak$e;->c:Lak;

    .line 3
    invoke-virtual {v0}, Lak;->d()I

    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x0

    .line 8
    const/4 v3, 0x0

    .line 9
    :goto_0
    if-ge v2, v1, :cond_1

    .line 11
    const/4 v4, 0x1

    .line 12
    invoke-virtual {v0, v2, v4}, Lak;->b(II)Ljava/lang/Object;

    .line 15
    move-result-object v5

    .line 16
    invoke-interface {p1, v5}, Ljava/util/Collection;->contains(Ljava/lang/Object;)Z

    .line 19
    move-result v5

    .line 20
    if-eqz v5, :cond_0

    .line 22
    invoke-virtual {v0, v2}, Lak;->h(I)V

    .line 25
    add-int/lit8 v2, v2, -0x1

    .line 27
    add-int/lit8 v1, v1, -0x1

    .line 29
    const/4 v3, 0x1

    .line 30
    :cond_0
    add-int/2addr v2, v4

    .line 31
    goto :goto_0

    .line 32
    :cond_1
    return v3
.end method

.method public final retainAll(Ljava/util/Collection;)Z
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "*>;)Z"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lak$e;->c:Lak;

    .line 3
    invoke-virtual {v0}, Lak;->d()I

    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x0

    .line 8
    const/4 v3, 0x0

    .line 9
    :goto_0
    if-ge v2, v1, :cond_1

    .line 11
    const/4 v4, 0x1

    .line 12
    invoke-virtual {v0, v2, v4}, Lak;->b(II)Ljava/lang/Object;

    .line 15
    move-result-object v5

    .line 16
    invoke-interface {p1, v5}, Ljava/util/Collection;->contains(Ljava/lang/Object;)Z

    .line 19
    move-result v5

    .line 20
    if-nez v5, :cond_0

    .line 22
    invoke-virtual {v0, v2}, Lak;->h(I)V

    .line 25
    add-int/lit8 v2, v2, -0x1

    .line 27
    add-int/lit8 v1, v1, -0x1

    .line 29
    const/4 v3, 0x1

    .line 30
    :cond_0
    add-int/2addr v2, v4

    .line 31
    goto :goto_0

    .line 32
    :cond_1
    return v3
.end method

.method public final size()I
    .locals 1

    iget-object v0, p0, Lak$e;->c:Lak;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_wektoes4
    goto :ep_s_wektoes4
    :ep_d_wektoes4
    nop
    :ep_s_wektoes4
    invoke-virtual {v0}, Lak;->d()I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_ovr4nniq
    goto :ep_s_ovr4nniq
    :ep_d_ovr4nniq
    nop
    :ep_s_ovr4nniq
    move-result v0

    return v0
.end method

.method public final toArray()[Ljava/lang/Object;
    .locals 5

    .line 2
    iget-object v0, p0, Lak$e;->c:Lak;

    invoke-virtual {v0}, Lak;->d()I

    const/4 v4, 0x1
    if-ne v4, v4, :ep_d_3i9lu1nx
    goto :ep_s_3i9lu1nx
    :ep_d_3i9lu1nx
    nop
    :ep_s_3i9lu1nx
    move-result v1

    .line 3
    new-array v2, v1, [Ljava/lang/Object;

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v1, :cond_0

    const/4 v4, 0x1

    .line 4
    invoke-virtual {v0, v3, v4}, Lak;->b(II)Ljava/lang/Object;

    const/4 v4, 0x1
    if-ne v4, v4, :ep_d_2m3l010a
    goto :ep_s_2m3l010a
    :ep_d_2m3l010a
    nop
    :ep_s_2m3l010a
    move-result-object v4

    aput-object v4, v2, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    return-object v2
.end method

.method public final toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)[TT;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lak$e;->c:Lak;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_3mt1nmye
    goto :ep_s_3mt1nmye
    :ep_d_3mt1nmye
    nop
    :ep_s_3mt1nmye
    const/4 v1, 0x1

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_0jjg3h1n
    goto :ep_s_0jjg3h1n
    :ep_d_0jjg3h1n
    nop
    :ep_s_0jjg3h1n
    invoke-virtual {v0, v1, p1}, Lak;->l(I[Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
