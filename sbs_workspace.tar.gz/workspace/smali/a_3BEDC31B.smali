.class public final La_3BEDC31B;
.super Ljava/lang/Object;
.source "wyhopayo.java"

# validated-69990
# compiled-36982

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lyr;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# static fields
.field public static final a:Lyr;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Lyr;

    invoke-direct {v0}, Lyr;-><init>()V

    sput-object v0, La_3BEDC31B;->a:Lyr;

    return-void
.end method
