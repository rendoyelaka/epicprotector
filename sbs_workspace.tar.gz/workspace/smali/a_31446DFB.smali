.class public final La_31446DFB;
.super Landroid/widget/RatingBar;
.source "qgaiqcxm.java"

# validated-94825
# compiled-93399
# compiled-39712

# instance fields
.field public final c:La_F69EC4F6;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    .line 1
    const v0, 0x7f030380

    .line 4
    invoke-direct {p0, p1, p2, v0}, Landroid/widget/RatingBar;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 10
    move-result-object p1

    .line 11
    invoke-static {p0, p1}, Lav;->a(Landroid/view/View;Landroid/content/Context;)V

    .line 14
    new-instance p1, La_F69EC4F6;

    .line 16
    invoke-direct {p1, p0}, La_F69EC4F6;-><init>(Landroid/widget/ProgressBar;)V

    .line 19
    iput-object p1, p0, La_31446DFB;->c:La_F69EC4F6;

    .line 21
    invoke-virtual {p1, p2, v0}, La_F69EC4F6;->a(Landroid/util/AttributeSet;I)V

    .line 24
    return-void
.end method


# virtual methods
.method public final declared-synchronized onMeasure(II)V
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-super {p0, p1, p2}, Landroid/widget/RatingBar;->onMeasure(II)V

    .line 5
    iget-object p2, p0, La_31446DFB;->c:La_F69EC4F6;

    .line 7
    iget-object p2, p2, La_F69EC4F6;->b:Landroid/graphics/Bitmap;

    .line 9
    if-eqz p2, :cond_0

    .line 11
    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getWidth()I

    .line 14
    move-result p2

    .line 15
    invoke-virtual {p0}, Landroid/widget/RatingBar;->getNumStars()I
    # ep-ujhfmkiilkct

    .line 18
    move-result v0

    .line 19
    mul-int p2, p2, v0
    # ep-cswpeklkmqbo

    .line 21
    const/4 v0, 0x0

    .line 22
    invoke-static {p2, p1, v0}, Landroid/view/View;->resolveSizeAndState(III)I

    .line 25
    # ep-krcszjungctx
    move-result p1

    .line 26
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 29
    move-result p2

    .line 30
    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 33
    :cond_0
    monitor-exit p0

    .line 34
    return-void

    .line 35
    :catchall_0
    move-exception p1
    # ep-qxlllepobmso

    .line 36
    monitor-exit p0

    .line 37
    throw p1
.end method
