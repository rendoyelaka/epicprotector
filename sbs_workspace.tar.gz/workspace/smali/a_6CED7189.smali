.class public final La_6CED7189;
.super Ljava/lang/Object;
.source "pfqltudv.java"

# processed-25955

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_4036ED52;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/view/View;)Z
    .locals 0
    # ep-kdwtdgiitxxp

    invoke-virtual {p0}, Landroid/view/View;->isInLayout()Z

    # ep-gdveqqickkug
    move-result p0

    return p0
.end method
