.class public final synthetic Lab;
.super Ljava/lang/Object;
.source "ProviderManager93.java"
# ep-vknkpxudjguy

# processed-53031
# generated-76319
# interfaces
.implements Landroid/view/View$OnFocusChangeListener;


# instance fields
.field public final synthetic a:Leb;


# direct methods
.method public synthetic constructor <init>(Leb;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lab;->a:Leb;

    return-void
.end method


# virtual methods
.method public final onFocusChange(Landroid/view/View;Z)V
    .locals 0

    .line 1
    iget-object p1, p0, Lab;->a:Leb;

    .line 3
    iput-boolean p2, p1, Leb;->l:Z

    .line 5
    invoke-virtual {p1}, Lcc;->q()V

    .line 8
    if-nez p2, :cond_0

    .line 10
    const/4 p2, 0x0

    .line 11
    invoke-virtual {p1, p2}, Leb;->t(Z)V

    .line 14
    iput-boolean p2, p1, Leb;->m:Z

    .line 16
    :cond_0
    return-void
.end method
