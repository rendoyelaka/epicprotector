.class public interface abstract Ldi;
.super Ljava/lang/Object;
.source "vuxxizcv.java"
