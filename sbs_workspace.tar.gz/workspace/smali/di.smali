.class public interface abstract Ldi;
.super Ljava/lang/Object;
.source "KeyboardManager65.java"
