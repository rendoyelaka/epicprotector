.class public interface abstract Ldi;
.super Ljava/lang/Object;
.source "CallbackUtils30.java"
