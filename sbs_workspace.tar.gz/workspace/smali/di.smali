.class public interface abstract Ldi;
.super Ljava/lang/Object;
.source "EntityHelper51.java"
