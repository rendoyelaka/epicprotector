.class public interface abstract Ldi;
.super Ljava/lang/Object;
.source "XmlUtils54.java"
