.class public interface abstract Ldi;
.super Ljava/lang/Object;
.source "BindingManager30.java"
