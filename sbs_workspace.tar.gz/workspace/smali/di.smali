.class public interface abstract Ldi;
.super Ljava/lang/Object;
.source "TimeoutHelper17.java"
