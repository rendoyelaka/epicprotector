.class public final LWorkSpecDao$e;
.super Lcs;
# compiled-84136
.source "ccihcqml.java"
# ep-geykcxghzewj


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 2

    const-string v1, "8ly61tYtwP/i2HOjmanKDBITZ9NQDutvbyBFPNMaaHbEY4v59lWS/eP1eaSdqcRcNQlQnFcV8Rs/dGYR+zhZCc5ow6g="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
