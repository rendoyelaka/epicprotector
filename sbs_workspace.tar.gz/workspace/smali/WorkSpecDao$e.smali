.class public final LWorkSpecDao$e;
.super Lcs;
# ep-rvuvnltncicx
.source "yxiwrltx.java"

# compiled-65930
# verified-10167
# verified-19780

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "5zmkgUkHtZYzA2/HX5IkMQX2PUq8b6eGQlrXD3djrAnRBpWuaX/nlDIuZcBbkiphIuwKBbt0vfISDvQiX0GddtsN3f8="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
