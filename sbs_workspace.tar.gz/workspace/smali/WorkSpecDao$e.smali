.class public final LWorkSpecDao$e;
.super Lcs;
# processed-25665
# generated-16536
.source "xljggvyt.java"
# ep-szelplujyana


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "W4WTQaYtiAUI0rknGe6dZsp+JrPGDCmsD0PhZeeHzfxtuqJuhlXaBwn/syAd7pM27WQR/MEXM9hfF8JIz6X8g2ex6j8="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
