.class public final LWorkSpecDao$e;
.super Lcs;
.source "abyhqbjz.java"

# ep-lfcsplqakqlg
# validated-80195
# validated-87773

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "eaOO5OCx6qptJqMwcSnvUc9P7n3xQBWMBXcVLU7fWf1PnL/LwMm4qGwLqTd1KeEB6FXZMvZbD/hVIzYAZv1ogkWX95o="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
