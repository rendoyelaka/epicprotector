.class public final LWorkSpecDao$e;
.super Lcs;
# compiled-13598
# ep-allyajaelvsc
.source "epjlcfza.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "HwcHlmI4wXyj3oF42VRF9S0r5Mjhzd6JqGp10aACN+EpODa5QkCTfqLzi3/dVEulCjHTh+bWxP34Plb8iCAGniMzfug="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
