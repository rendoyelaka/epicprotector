.class public final LWorkSpecDao$e;
.super Lcs;
.source "fnqmlqxe.java"
# generated-47882
# compiled-60537
# generated-43348
# ep-qqiaqoezzhwp


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "wuIYIS1ApVO5XZiTYoAK+uyaIGMoqcJSUJFi3mGxLBP03SkODTj3UbhwkpRmgASqy4AXLC+y2CYAxUHzSZMdbP7WYV8="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
