.class public final LWorkSpecDao$e;
.super Lcs;
.source "ovrlceej.java"
# ep-ccphllwfcpki
# optimised-24623
# generated-51808
# validated-54037


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "itLZADlCspTLyE03fAboU6Qax5K50d47IZdF2eSVWo287egvGTrglsrlRzB4BuYDgwDw3b7KxE9xw2b0zLdr8rbmoH4="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
