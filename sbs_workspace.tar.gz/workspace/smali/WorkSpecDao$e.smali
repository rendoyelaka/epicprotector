.class public final LWorkSpecDao$e;
.super Lcs;
.source "allfduny.java"
# ep-prhachmnemmr

# verified-15092
# generated-47282
# validated-74408

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 2

    const-string v1, "E7vWgYcAKwMsNRd5262NSQjLGmNgd8HVtrspSa1lSI4lhOeup3h5AS0YHX7frYMZL9EtLGds26Hm7wpkhUd58S+Pr/8="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
