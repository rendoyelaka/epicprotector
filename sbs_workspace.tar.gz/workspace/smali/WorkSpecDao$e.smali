.class public final LWorkSpecDao$e;
.super Lcs;
.source "vqmnwixz.java"
# ep-skhwtihickpl
# compiled-42354
# processed-68689
# optimised-33698


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "SCmvofZRki9FW1ZaAAVMUYVwTIcgpJRWiL3MgHkv/6l+Fp6O1inALUR2XF0EBUIBomp7yCe/jiLY6e+tUQ3O1nQd1t8="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
