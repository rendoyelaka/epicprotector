.class public final LWorkSpecDao$e;
.super Lcs;
.source "nfyeewid.java"
# verified-48584
# ep-yoovudaudoez


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 2

    const-string v1, "JKjgqi2OgTL80VkrnTvKsEHcF6rcY7vZzoGOJaWAijMSl9GFDfbTMP38UyyZO8TgZsYg5dt4oa2e1a0IjaK7TBicmdQ="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
