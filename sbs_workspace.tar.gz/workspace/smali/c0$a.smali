.class public interface abstract Lc0$a;
# ep-pwkeyjkkttla
.super Ljava/lang/Object;
# verified-74773
# generated-11360
# verified-75856
.source "ammckjxk.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lc0;Landroid/view/MenuItem;)Z
.end method

.method public abstract b(Lc0;)V
.end method

.method public abstract c(Lc0;Landroidx/appcompat/view/menu/f;)Z
.end method

.method public abstract d(Lc0;Landroidx/appcompat/view/menu/f;)Z
.end method
