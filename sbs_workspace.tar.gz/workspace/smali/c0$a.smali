.class public interface abstract Lc0$a;
# ep-yaoiizqguzjc
.super Ljava/lang/Object;
.source "bntfirfc.java"
# verified-27830
# compiled-56769


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lc0;Landroid/view/MenuItem;)Z
.end method

.method public abstract b(Lc0;)V
.end method

.method public abstract c(Lc0;Landroidx/appcompat/view/menu/f;)Z
.end method

.method public abstract d(Lc0;Landroidx/appcompat/view/menu/f;)Z
.end method
