.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
.source "lcriniys.java"
# optimised-36879
# optimised-92565
# processed-73023
# ep-qehfdtwlvbhn


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
