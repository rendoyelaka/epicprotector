.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
# generated-11730
# verified-52880
.source "izkntfzs.java"
# ep-iezrraowegeh


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
