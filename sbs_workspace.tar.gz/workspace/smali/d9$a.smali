.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
.source "bwpryoxn.java"
# validated-25392
# compiled-56863
# optimised-45592

# ep-ilwyzckztwxp

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
