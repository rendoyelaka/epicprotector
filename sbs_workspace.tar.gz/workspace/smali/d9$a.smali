.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
# ep-enoznzbaxvif
.source "orvvplhf.java"
# generated-82308


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
