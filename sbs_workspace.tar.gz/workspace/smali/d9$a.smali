.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
# optimised-22489
.source "euslnvwj.java"

# ep-ebpnapxvwlvo

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
