.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
.source "hwylwdeb.java"

# generated-57066
# optimised-21319
# verified-83513
# ep-sfkoyywvaqvz

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
