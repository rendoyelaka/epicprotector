.class public interface abstract Ld9$a;
# ep-lezgqmkdgdcy
.super Ljava/lang/Object;
.source "sjvjxqpn.java"
# generated-56061


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
