.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
.source "sseastec.java"
# verified-62893
# validated-89644

# ep-xsluzwkpvhlz

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
