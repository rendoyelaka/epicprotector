.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
.source "TimerUtils44.java"
# compiled-70561

# ep-rbnwdzhbnlgl

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
