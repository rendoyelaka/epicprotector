.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
# compiled-72550
# verified-36682
# compiled-40401
.source "ydezcqcy.java"

# ep-cnrjlrjjoqep

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
