.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
.source "fbkxfrnj.java"

# ep-kehitnnekzkj
# processed-24901
# generated-50825
# optimised-91459

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
