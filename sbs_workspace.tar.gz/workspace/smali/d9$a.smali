.class public interface abstract Ld9$a;
# ep-kvtvmkbnqwkr
.super Ljava/lang/Object;
# verified-47448
# optimised-39685
.source "baalzdqt.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
