.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
.source "bwmfhspv.java"
# processed-38339
# optimised-22431
# ep-iplaxdtfcjmd


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
