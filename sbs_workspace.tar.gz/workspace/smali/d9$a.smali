.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
# ep-fbnsiuxmiedu
# processed-33855
# verified-71922
.source "zoxqjngn.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
