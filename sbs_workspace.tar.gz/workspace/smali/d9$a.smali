.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
.source "ndqxgqfi.java"
# ep-wfwcbxyyjaqe
# verified-27546
# generated-29797
# optimised-50476


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
