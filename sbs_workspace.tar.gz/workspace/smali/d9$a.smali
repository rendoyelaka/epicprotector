.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
# ep-yxmlrhgdrxbr
.source "nliugxop.java"
# processed-73496
# generated-55404
# optimised-54816


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
