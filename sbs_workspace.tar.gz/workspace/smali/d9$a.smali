.class public interface abstract Ld9$a;
.super Ljava/lang/Object;
.source "ibohpyxl.java"
# validated-92195

# ep-gpzrehndltds

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
