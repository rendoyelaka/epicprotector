.class public interface abstract Ld9$a;
# ep-ceqlvgkkehsv
.super Ljava/lang/Object;
# optimised-11251
# compiled-17934
.source "ncupwrbq.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
