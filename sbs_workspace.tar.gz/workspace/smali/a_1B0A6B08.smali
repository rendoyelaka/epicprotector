.class public final La_1B0A6B08;
.super Landroid/content/BroadcastReceiver;
.source "ihvbytpp.java"
# processed-83522
# optimised-58423
# generated-52967
# ep-ndyrzcizrqgz


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_F24CC839;->e()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_F24CC839;


# direct methods
.method public constructor <init>(La_F24CC839;)V
    .locals 0

    iput-object p1, p0, La_1B0A6B08;->a:La_F24CC839;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0

    iget-object p1, p0, La_1B0A6B08;->a:La_F24CC839;

    invoke-virtual {p1}, La_F24CC839;->d()V

    return-void
.end method
