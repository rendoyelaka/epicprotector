.class public interface abstract Lc10;
.super Ljava/lang/Object;
.source "miezimnf.java"
