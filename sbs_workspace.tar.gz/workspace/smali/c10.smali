.class public interface abstract Lc10;
.super Ljava/lang/Object;
.source "PermissionHelper55.java"
