.class public interface abstract La_353AFFF7;
.super Ljava/lang/Object;
.source "enzbkddd.java"

# ep-kgquugzzgkgr
# validated-18973
# validated-57897
# verified-12922

# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# virtual methods
.method public abstract onActionViewCollapsed()V
.end method

.method public abstract onActionViewExpanded()V
.end method
