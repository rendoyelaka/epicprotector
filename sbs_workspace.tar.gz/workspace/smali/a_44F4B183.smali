.class public interface abstract La_44F4B183;
.super Ljava/lang/Object;
.source "lffevsbs.java"

# validated-57540
# verified-13933
# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<S:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()Ljava/lang/String;
.end method

.method public abstract c()I
.end method

    # ep-kpfsarwkdxba
.method public abstract d()Ljava/util/Collection;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
    # ep-cmuuvsksigjg
            "Ljava/util/Collection<",
    # ep-noqblqgveqlg
            "Ltn<",
            "Ljava/lang/Long;",
    # ep-yabprpeknmkq
            "Ljava/lang/Long;",
            ">;>;"
        }
    .end annotation
.end method

.method public abstract f()Z
.end method

.method public abstract g()Ljava/lang/String;
.end method

    # ep-fzazoetcqmpi
.method public abstract h()Ljava/util/Collection;
    # ep-cqmtyllsmjun
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end method

    # ep-ijyqxmenqzyt
.method public abstract i()Ljava/lang/Object;
    # ep-amtrhnqkmnne
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TS;"
    # ep-fvtifzzxtact
        }
    .end annotation
.end method

.method public abstract j()Landroid/view/View;
.end method

.method public abstract k()Ljava/lang/String;
.end method
