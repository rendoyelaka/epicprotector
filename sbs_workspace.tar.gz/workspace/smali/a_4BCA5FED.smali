.class public interface abstract La_4BCA5FED;
.super Ljava/lang/Object;
.source "kjdhxosp.java"
# generated-27744
# validated-61836


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract m_75e66980(Ljava/lang/Object;)V
    # ep-zmsylrzxhopw
    .annotation system Ldalvik/annotation/Signature;
    # ep-mjycemkkdkhe
        value = {
    # ep-iwggkwcxumnf
            "(TT;)V"
        }
    # ep-hxtkhoxxnebp
    .end annotation
.end method
