.class public final La_63FD67AD;
.super Ljava/lang/Object;
.source "bbhtrhhg.java"
# processed-17019

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lpp;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:La_4BCA5FED;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(La_4BCA5FED;Ljava/lang/Object;)V
    .locals 0

    iput-object p1, p0, La_63FD67AD;->c:La_4BCA5FED;

    iput-object p2, p0, La_63FD67AD;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    # ep-oafvgbxmjxsr
    .locals 2

    iget-object v0, p0, La_63FD67AD;->c:La_4BCA5FED;

    iget-object v1, p0, La_63FD67AD;->d:Ljava/lang/Object;
    # ep-aclcrogryrsg

    invoke-interface {v0, v1}, La_4BCA5FED;->m_75e66980(Ljava/lang/Object;)V
    # ep-chmrfaxufnri

    return-void
.end method
