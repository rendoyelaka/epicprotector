.class public final La_5EFEFFA7;
.super La_2C13166E;
# generated-66052
# generated-76897
# compiled-64025
# ep-lompvjttgqgo
.source "jscvvtka.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lsz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic f_d27c7b86:Lsz;


# direct methods
.method public constructor <init>(Lsz;)V
    .locals 0

    iput-object p1, p0, La_5EFEFFA7;->f_d27c7b86:Lsz;

    invoke-direct {p0}, La_2C13166E;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 4

    .line 1
    iget-object v0, p0, La_5EFEFFA7;->f_d27c7b86:Lsz;

    .line 3
    iget-boolean v1, v0, Lsz;->p:Z

    .line 5
    if-eqz v1, :cond_0

    .line 7
    iget-object v1, v0, Lsz;->g:Landroid/view/View;

    .line 9
    if-eqz v1, :cond_0

    .line 11
    const/4 v2, 0x0

    .line 12
    invoke-virtual {v1, v2}, Landroid/view/View;->setTranslationY(F)V

    .line 15
    iget-object v1, v0, Lsz;->d:Landroidx/appcompat/widget/ActionBarContainer;

    .line 17
    invoke-virtual {v1, v2}, Landroid/view/View;->setTranslationY(F)V

    .line 20
    :cond_0
    iget-object v1, v0, Lsz;->d:Landroidx/appcompat/widget/ActionBarContainer;

    .line 22
    const/16 v2, 0x8

    .line 24
    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/ActionBarContainer;->setVisibility(I)V

    .line 27
    iget-object v1, v0, Lsz;->d:Landroidx/appcompat/widget/ActionBarContainer;

    .line 29
    const/4 v2, 0x0

    .line 30
    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/ActionBarContainer;->setTransitioning(Z)V

    .line 33
    const/4 v1, 0x0

    .line 34
    iput-object v1, v0, Lsz;->t:Lly;

    .line 36
    iget-object v2, v0, Lsz;->k:La_0678B093;

    .line 38
    if-eqz v2, :cond_1

    .line 40
    iget-object v3, v0, Lsz;->j:La_84FCF01A;

    .line 42
    invoke-interface {v2, v3}, La_0678B093;->b(La_E1261EED;)V

    .line 45
    iput-object v1, v0, Lsz;->j:La_84FCF01A;

    .line 47
    iput-object v1, v0, Lsz;->k:La_0678B093;

    .line 49
    :cond_1
    iget-object v0, v0, Lsz;->c:Landroidx/appcompat/widget/ActionBarOverlayLayout;

    .line 51
    if-eqz v0, :cond_2

    .line 53
    sget-object v1, Lqx;->a:Ljava/util/WeakHashMap;

    .line 55
    invoke-static {v0}, La_0449D4C3;->c(Landroid/view/View;)V

    .line 58
    :cond_2
    return-void
.end method
