.class public final La_11ABE53C;
.super Ljava/lang/Object;
.source "nkryshum.java"
# compiled-85006
# verified-94332
# ep-kmpcwfwhxylg


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_F45CFC0D;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation


# instance fields
.field public a:F

.field public b:F

.field public c:F


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(FFF)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p1, p0, La_11ABE53C;->a:F

    .line 3
    iput p2, p0, La_11ABE53C;->b:F

    .line 4
    iput p3, p0, La_11ABE53C;->c:F

    return-void
.end method
