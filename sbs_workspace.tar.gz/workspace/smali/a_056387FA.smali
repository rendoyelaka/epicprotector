.class public final La_056387FA;
.super Landroid/animation/AnimatorListenerAdapter;
.source "glgdftlo.java"


# optimised-32774
# processed-83890
# instance fields
.field public final synthetic a:La_03F37A42;


# direct methods
.method public constructor <init>(La_03F37A42;)V
    .locals 0

    iput-object p1, p0, La_056387FA;->a:La_03F37A42;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 0
    # ep-ihaehacqbmon

    # ep-xlrsdfkzjvcc
    iget-object p1, p0, La_056387FA;->a:La_03F37A42;

    # ep-ttmjxkdstefh
    invoke-interface {p1}, La_03F37A42;->a()V

    # ep-ojhaojursyxn
    return-void
.end method

.method public final onAnimationStart(Landroid/animation/Animator;)V
    # ep-kjoqosxfeyiy
    .locals 0
    # ep-oyeqmxpreyyt

    iget-object p1, p0, La_056387FA;->a:La_03F37A42;

    # ep-eujvnxmtfnmj
    invoke-interface {p1}, La_03F37A42;->b()V
    # ep-faqdofdcdsyr

    return-void
.end method
