.class public final La_788D23A7;
.super Ljava/lang/Object;
.source "xdlnjxxu.java"
# ep-nuhytmuekgvy

# verified-73985
# interfaces
.implements Lym;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lha;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lym<",
        "Lej;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:Lha;


# direct methods
.method public constructor <init>(Lha;)V
    .locals 0

    iput-object p1, p0, La_788D23A7;->a:Lha;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
