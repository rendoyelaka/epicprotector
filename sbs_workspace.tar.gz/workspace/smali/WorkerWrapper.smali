.class public final LWorkerWrapper;
.super Ljava/lang/Object;
# ep-vjyhxogokuap
.source "qyltomxd.java"

# compiled-70880
# validated-84431
# compiled-38218
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LWorkerWrapper$a;
    }
.end annotation


# static fields
.field public static final synthetic u:I


# instance fields
.field public final c:Landroid/content/Context;

.field public final d:Ljava/lang/String;

.field public final e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lhr;",
            ">;"
        }
    .end annotation
.end field

.field public f:LWorkSpec;

.field public g:Landroidx/work/ListenableWorker;

.field public final h:Lnu;

.field public i:Landroidx/work/ListenableWorker$a;

.field public final j:Landroidx/work/a;

.field public final k:Lpd;

.field public final l:Landroidx/work/impl/WorkDatabase;

.field public final m:Lz00;

.field public final n:Laa;

.field public final o:Lc10;

.field public p:Ljava/util/ArrayList;

.field public q:Ljava/lang/String;

.field public final r:Ltr;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltr<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public s:Loj;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Loj<",
            "Landroidx/work/ListenableWorker$a;",
            ">;"
        }
    .end annotation
.end field

.field public volatile t:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "WorkerWrapper"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(LWorkerWrapper$a;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Landroidx/work/ListenableWorker$a$a;

    .line 6
    invoke-direct {v0}, Landroidx/work/ListenableWorker$a$a;-><init>()V

    .line 9
    iput-object v0, p0, LWorkerWrapper;->i:Landroidx/work/ListenableWorker$a;

    .line 11
    new-instance v0, Ltr;

    .line 13
    invoke-direct {v0}, Ltr;-><init>()V

    .line 16
    iput-object v0, p0, LWorkerWrapper;->r:Ltr;

    .line 18
    const/4 v0, 0x0

    .line 19
    iput-object v0, p0, LWorkerWrapper;->s:Loj;

    .line 21
    iget-object v1, p1, LWorkerWrapper$a;->a:Landroid/content/Context;

    .line 23
    iput-object v1, p0, LWorkerWrapper;->c:Landroid/content/Context;

    .line 25
    iget-object v1, p1, LWorkerWrapper$a;->c:Lnu;

    .line 27
    iput-object v1, p0, LWorkerWrapper;->h:Lnu;

    .line 29
    iget-object v1, p1, LWorkerWrapper$a;->b:Lpd;

    .line 31
    iput-object v1, p0, LWorkerWrapper;->k:Lpd;

    .line 33
    iget-object v1, p1, LWorkerWrapper$a;->f:Ljava/lang/String;

    .line 35
    iput-object v1, p0, LWorkerWrapper;->d:Ljava/lang/String;

    .line 37
    iget-object v1, p1, LWorkerWrapper$a;->g:Ljava/util/List;

    .line 39
    iput-object v1, p0, LWorkerWrapper;->e:Ljava/util/List;

    .line 41
    iget-object v1, p1, LWorkerWrapper$a;->h:Landroidx/work/WorkerParameters$a;

    .line 43
    iput-object v0, p0, LWorkerWrapper;->g:Landroidx/work/ListenableWorker;

    .line 45
    iget-object v0, p1, LWorkerWrapper$a;->d:Landroidx/work/a;

    .line 47
    iput-object v0, p0, LWorkerWrapper;->j:Landroidx/work/a;

    .line 49
    iget-object p1, p1, LWorkerWrapper$a;->e:Landroidx/work/impl/WorkDatabase;

    .line 51
    iput-object p1, p0, LWorkerWrapper;->l:Landroidx/work/impl/WorkDatabase;

    .line 53
    invoke-virtual {p1}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 56
    move-result-object v0

    .line 57
    iput-object v0, p0, LWorkerWrapper;->m:Lz00;

    .line 59
    invoke-virtual {p1}, Landroidx/work/impl/WorkDatabase;->i()Laa;

    .line 62
    move-result-object v0

    .line 63
    iput-object v0, p0, LWorkerWrapper;->n:Laa;

    .line 65
    invoke-virtual {p1}, Landroidx/work/impl/WorkDatabase;->o()Lc10;

    .line 68
    move-result-object p1

    .line 69
    iput-object p1, p0, LWorkerWrapper;->o:Lc10;

    .line 71
    return-void
.end method


# virtual methods
.method public final a(Landroidx/work/ListenableWorker$a;)V
    .locals 11

    .line 1
    instance-of v0, p1, Landroidx/work/ListenableWorker$a$c;

    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    if-eqz v0, :cond_3

    .line 7
    invoke-static {}, Ltj;->c()Ltj;

    .line 10
    move-result-object p1

    .line 11
    new-array v0, v1, [Ljava/lang/Object;

    .line 13
    iget-object v3, p0, LWorkerWrapper;->q:Ljava/lang/String;

    .line 15
    aput-object v3, v0, v2

    .line 17
    const-string v3, "Worker result SUCCESS for %s"

    .line 19
    invoke-static {v3, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 22
    new-array v0, v2, [Ljava/lang/Throwable;

    .line 24
    invoke-virtual {p1, v0}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 27
    iget-object p1, p0, LWorkerWrapper;->f:LWorkSpec;

    .line 29
    invoke-virtual {p1}, LWorkSpec;->c()Z

    .line 32
    move-result p1

    .line 33
    if-eqz p1, :cond_0

    .line 35
    invoke-virtual {p0}, LWorkerWrapper;->e()V

    .line 38
    goto/16 :goto_1

    .line 40
    :cond_0
    iget-object p1, p0, LWorkerWrapper;->n:Laa;

    .line 42
    iget-object v0, p0, LWorkerWrapper;->d:Ljava/lang/String;

    .line 44
    iget-object v3, p0, LWorkerWrapper;->m:Lz00;

    .line 46
    iget-object v4, p0, LWorkerWrapper;->l:Landroidx/work/impl/WorkDatabase;

    .line 48
    invoke-virtual {v4}, Ljq;->c()V

    .line 51
    :try_start_0
    sget-object v5, LWorkInfo_State;->e:LWorkInfo_State;

    .line 53
    new-array v6, v1, [Ljava/lang/String;

    .line 55
    aput-object v0, v6, v2

    .line 57
    move-object v7, v3

    .line 58
    check-cast v7, LWorkSpecDao;

    .line 60
    invoke-virtual {v7, v5, v6}, LWorkSpecDao;->m(LWorkInfo_State;[Ljava/lang/String;)I

    .line 63
    iget-object v5, p0, LWorkerWrapper;->i:Landroidx/work/ListenableWorker$a;

    .line 65
    check-cast v5, Landroidx/work/ListenableWorker$a$c;

    .line 67
    iget-object v5, v5, Landroidx/work/ListenableWorker$a$c;->a:Landroidx/work/b;

    .line 69
    move-object v6, v3

    .line 70
    check-cast v6, LWorkSpecDao;

    .line 72
    invoke-virtual {v6, v0, v5}, LWorkSpecDao;->k(Ljava/lang/String;Landroidx/work/b;)V

    .line 75
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 78
    move-result-wide v5

    .line 79
    move-object v7, p1

    .line 80
    check-cast v7, Lba;

    .line 82
    invoke-virtual {v7, v0}, Lba;->a(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 85
    move-result-object v0

    .line 86
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 89
    move-result-object v0

    .line 90
    :cond_1
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 93
    move-result v7

    .line 94
    if-eqz v7, :cond_2

    .line 96
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 99
    move-result-object v7

    .line 100
    check-cast v7, Ljava/lang/String;

    .line 102
    move-object v8, v3

    .line 103
    check-cast v8, LWorkSpecDao;

    .line 105
    invoke-virtual {v8, v7}, LWorkSpecDao;->f(Ljava/lang/String;)LWorkInfo_State;

    .line 108
    move-result-object v8

    .line 109
    sget-object v9, LWorkInfo_State;->g:LWorkInfo_State;

    .line 111
    if-ne v8, v9, :cond_1

    .line 113
    move-object v8, p1

    .line 114
    check-cast v8, Lba;

    .line 116
    invoke-virtual {v8, v7}, Lba;->b(Ljava/lang/String;)Z

    .line 119
    move-result v8

    .line 120
    if-eqz v8, :cond_1

    .line 122
    invoke-static {}, Ltj;->c()Ltj;

    .line 125
    move-result-object v8

    .line 126
    const-string v9, "Setting status to enqueued for %s"

    .line 128
    new-array v10, v1, [Ljava/lang/Object;

    .line 130
    aput-object v7, v10, v2

    .line 132
    invoke-static {v9, v10}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 135
    new-array v9, v2, [Ljava/lang/Throwable;

    .line 137
    invoke-virtual {v8, v9}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 140
    sget-object v8, LWorkInfo_State;->c:LWorkInfo_State;

    .line 142
    new-array v9, v1, [Ljava/lang/String;

    .line 144
    aput-object v7, v9, v2

    .line 146
    move-object v10, v3

    .line 147
    check-cast v10, LWorkSpecDao;

    .line 149
    invoke-virtual {v10, v8, v9}, LWorkSpecDao;->m(LWorkInfo_State;[Ljava/lang/String;)I

    .line 152
    move-object v8, v3

    .line 153
    check-cast v8, LWorkSpecDao;

    .line 155
    invoke-virtual {v8, v7, v5, v6}, LWorkSpecDao;->l(Ljava/lang/String;J)V

    .line 158
    goto :goto_0

    .line 159
    :cond_2
    invoke-virtual {v4}, Ljq;->h()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 162
    invoke-virtual {v4}, Ljq;->f()V

    .line 165
    invoke-virtual {p0, v2}, LWorkerWrapper;->f(Z)V

    .line 168
    goto :goto_1

    .line 169
    :catchall_0
    move-exception p1

    .line 170
    invoke-virtual {v4}, Ljq;->f()V

    .line 173
    invoke-virtual {p0, v2}, LWorkerWrapper;->f(Z)V

    .line 176
    throw p1

    .line 177
    :cond_3
    instance-of p1, p1, Landroidx/work/ListenableWorker$a$b;

    .line 179
    if-eqz p1, :cond_4

    .line 181
    invoke-static {}, Ltj;->c()Ltj;

    .line 184
    move-result-object p1

    .line 185
    new-array v0, v1, [Ljava/lang/Object;

    .line 187
    iget-object v1, p0, LWorkerWrapper;->q:Ljava/lang/String;

    .line 189
    aput-object v1, v0, v2

    .line 191
    const-string v1, "Worker result RETRY for %s"

    .line 193
    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 196
    new-array v0, v2, [Ljava/lang/Throwable;

    .line 198
    invoke-virtual {p1, v0}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 201
    invoke-virtual {p0}, LWorkerWrapper;->d()V

    .line 204
    goto :goto_1

    .line 205
    :cond_4
    invoke-static {}, Ltj;->c()Ltj;

    .line 208
    move-result-object p1

    .line 209
    new-array v0, v1, [Ljava/lang/Object;

    .line 211
    iget-object v1, p0, LWorkerWrapper;->q:Ljava/lang/String;

    .line 213
    aput-object v1, v0, v2

    .line 215
    const-string v1, "Worker result FAILURE for %s"

    .line 217
    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 220
    new-array v0, v2, [Ljava/lang/Throwable;

    .line 222
    invoke-virtual {p1, v0}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 225
    iget-object p1, p0, LWorkerWrapper;->f:LWorkSpec;

    .line 227
    invoke-virtual {p1}, LWorkSpec;->c()Z

    .line 230
    move-result p1

    .line 231
    if-eqz p1, :cond_5

    .line 233
    invoke-virtual {p0}, LWorkerWrapper;->e()V

    .line 236
    goto :goto_1

    .line 237
    :cond_5
    invoke-virtual {p0}, LWorkerWrapper;->h()V

    .line 240
    :goto_1
    return-void
.end method

.method public final b(Ljava/lang/String;)V
    .locals 5

    .line 1
    new-instance v0, Ljava/util/LinkedList;

    .line 3
    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    .line 6
    invoke-virtual {v0, p1}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z

    .line 9
    :goto_0
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 12
    move-result p1

    .line 13
    if-nez p1, :cond_1

    .line 15
    invoke-virtual {v0}, Ljava/util/LinkedList;->remove()Ljava/lang/Object;

    .line 18
    move-result-object p1

    .line 19
    check-cast p1, Ljava/lang/String;

    .line 21
    iget-object v1, p0, LWorkerWrapper;->m:Lz00;

    .line 23
    check-cast v1, LWorkSpecDao;

    .line 25
    invoke-virtual {v1, p1}, LWorkSpecDao;->f(Ljava/lang/String;)LWorkInfo_State;

    .line 28
    move-result-object v2

    .line 29
    sget-object v3, LWorkInfo_State;->h:LWorkInfo_State;

    .line 31
    if-eq v2, v3, :cond_0

    .line 33
    sget-object v2, LWorkInfo_State;->f:LWorkInfo_State;

    .line 35
    const/4 v3, 0x1

    .line 36
    new-array v3, v3, [Ljava/lang/String;

    .line 38
    const/4 v4, 0x0

    .line 39
    aput-object p1, v3, v4

    .line 41
    invoke-virtual {v1, v2, v3}, LWorkSpecDao;->m(LWorkInfo_State;[Ljava/lang/String;)I

    .line 44
    :cond_0
    iget-object v1, p0, LWorkerWrapper;->n:Laa;

    .line 46
    check-cast v1, Lba;

    .line 48
    invoke-virtual {v1, p1}, Lba;->a(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 51
    move-result-object p1

    .line 52
    invoke-virtual {v0, p1}, Ljava/util/LinkedList;->addAll(Ljava/util/Collection;)Z

    .line 55
    goto :goto_0

    .line 56
    :cond_1
    return-void
.end method

.method public final c()V
    .locals 7

    .line 1
    invoke-virtual {p0}, LWorkerWrapper;->i()Z

    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, LWorkerWrapper;->d:Ljava/lang/String;

    .line 7
    iget-object v2, p0, LWorkerWrapper;->l:Landroidx/work/impl/WorkDatabase;

    .line 9
    if-nez v0, :cond_4

    .line 11
    invoke-virtual {v2}, Ljq;->c()V

    .line 14
    :try_start_0
    iget-object v0, p0, LWorkerWrapper;->m:Lz00;

    .line 16
    check-cast v0, LWorkSpecDao;

    .line 18
    invoke-virtual {v0, v1}, LWorkSpecDao;->f(Ljava/lang/String;)LWorkInfo_State;

    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {v2}, Landroidx/work/impl/WorkDatabase;->m()Lt00;

    .line 25
    move-result-object v3

    .line 26
    check-cast v3, Lu00;

    .line 28
    iget-object v4, v3, Lu00;->a:Ljq;

    .line 30
    invoke-virtual {v4}, Ljq;->b()V

    .line 33
    iget-object v3, v3, Lu00;->b:Lu00$a;

    .line 35
    invoke-virtual {v3}, Lcs;->a()Lue;

    .line 38
    move-result-object v5

    .line 39
    const/4 v6, 0x1

    .line 40
    if-nez v1, :cond_0

    .line 42
    invoke-virtual {v5, v6}, Lte;->s(I)V

    .line 45
    goto :goto_0

    .line 46
    :cond_0
    invoke-virtual {v5, v1, v6}, Lte;->t(Ljava/lang/String;I)V

    .line 49
    :goto_0
    invoke-virtual {v4}, Ljq;->c()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 52
    :try_start_1
    invoke-virtual {v5}, Lue;->u()I

    .line 55
    invoke-virtual {v4}, Ljq;->h()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 58
    :try_start_2
    invoke-virtual {v4}, Ljq;->f()V

    .line 61
    invoke-virtual {v3, v5}, Lcs;->c(Lue;)V

    .line 64
    if-nez v0, :cond_1

    .line 66
    const/4 v0, 0x0

    .line 67
    invoke-virtual {p0, v0}, LWorkerWrapper;->f(Z)V

    .line 70
    goto :goto_1

    .line 71
    :cond_1
    sget-object v3, LWorkInfo_State;->d:LWorkInfo_State;

    .line 73
    if-ne v0, v3, :cond_2

    .line 75
    iget-object v0, p0, LWorkerWrapper;->i:Landroidx/work/ListenableWorker$a;

    .line 77
    invoke-virtual {p0, v0}, LWorkerWrapper;->a(Landroidx/work/ListenableWorker$a;)V

    .line 80
    goto :goto_1

    .line 81
    :cond_2
    invoke-virtual {v0}, LWorkInfo_State;->a()Z

    .line 84
    move-result v0

    .line 85
    if-nez v0, :cond_3

    .line 87
    invoke-virtual {p0}, LWorkerWrapper;->d()V

    .line 90
    :cond_3
    :goto_1
    invoke-virtual {v2}, Ljq;->h()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 93
    invoke-virtual {v2}, Ljq;->f()V

    .line 96
    goto :goto_2

    .line 97
    :catchall_0
    move-exception v0

    .line 98
    :try_start_3
    invoke-virtual {v4}, Ljq;->f()V

    .line 101
    invoke-virtual {v3, v5}, Lcs;->c(Lue;)V

    .line 104
    throw v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 105
    :catchall_1
    move-exception v0

    .line 106
    invoke-virtual {v2}, Ljq;->f()V

    .line 109
    throw v0

    .line 110
    :cond_4
    :goto_2
    iget-object v0, p0, LWorkerWrapper;->e:Ljava/util/List;

    .line 112
    if-eqz v0, :cond_6

    .line 114
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 117
    move-result-object v3

    .line 118
    :goto_3
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 121
    move-result v4

    .line 122
    if-eqz v4, :cond_5

    .line 124
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 127
    move-result-object v4

    .line 128
    check-cast v4, Lhr;

    .line 130
    invoke-interface {v4, v1}, Lhr;->b(Ljava/lang/String;)V

    .line 133
    goto :goto_3

    .line 134
    :cond_5
    iget-object v1, p0, LWorkerWrapper;->j:Landroidx/work/a;

    .line 136
    invoke-static {v1, v2, v0}, LSchedulers;->a(Landroidx/work/a;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V

    .line 139
    :cond_6
    return-void
.end method

.method public final d()V
    .locals 7

    .line 1
    iget-object v0, p0, LWorkerWrapper;->d:Ljava/lang/String;

    .line 3
    iget-object v1, p0, LWorkerWrapper;->m:Lz00;

    .line 5
    iget-object v2, p0, LWorkerWrapper;->l:Landroidx/work/impl/WorkDatabase;

    .line 7
    invoke-virtual {v2}, Ljq;->c()V

    .line 10
    const/4 v3, 0x1

    .line 11
    :try_start_0
    sget-object v4, LWorkInfo_State;->c:LWorkInfo_State;

    .line 13
    new-array v5, v3, [Ljava/lang/String;

    .line 15
    const/4 v6, 0x0

    .line 16
    aput-object v0, v5, v6

    .line 18
    move-object v6, v1

    .line 19
    check-cast v6, LWorkSpecDao;

    .line 21
    invoke-virtual {v6, v4, v5}, LWorkSpecDao;->m(LWorkInfo_State;[Ljava/lang/String;)I

    .line 24
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 27
    move-result-wide v4

    .line 28
    move-object v6, v1

    .line 29
    check-cast v6, LWorkSpecDao;

    .line 31
    invoke-virtual {v6, v0, v4, v5}, LWorkSpecDao;->l(Ljava/lang/String;J)V

    .line 34
    check-cast v1, LWorkSpecDao;

    .line 36
    const-wide/16 v4, -0x1

    .line 38
    invoke-virtual {v1, v0, v4, v5}, LWorkSpecDao;->j(Ljava/lang/String;J)I

    .line 41
    invoke-virtual {v2}, Ljq;->h()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 44
    invoke-virtual {v2}, Ljq;->f()V

    .line 47
    invoke-virtual {p0, v3}, LWorkerWrapper;->f(Z)V

    .line 50
    return-void

    .line 51
    :catchall_0
    move-exception v0

    .line 52
    invoke-virtual {v2}, Ljq;->f()V

    .line 55
    invoke-virtual {p0, v3}, LWorkerWrapper;->f(Z)V

    .line 58
    throw v0
.end method

.method public final e()V
    .locals 8

    .line 1
    iget-object v0, p0, LWorkerWrapper;->d:Ljava/lang/String;

    .line 3
    iget-object v1, p0, LWorkerWrapper;->m:Lz00;

    .line 5
    iget-object v2, p0, LWorkerWrapper;->l:Landroidx/work/impl/WorkDatabase;

    .line 7
    invoke-virtual {v2}, Ljq;->c()V

    .line 10
    const/4 v3, 0x0

    .line 11
    :try_start_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 14
    move-result-wide v4

    .line 15
    move-object v6, v1

    .line 16
    check-cast v6, LWorkSpecDao;

    .line 18
    invoke-virtual {v6, v0, v4, v5}, LWorkSpecDao;->l(Ljava/lang/String;J)V

    .line 21
    sget-object v4, LWorkInfo_State;->c:LWorkInfo_State;

    .line 23
    const/4 v5, 0x1

    .line 24
    new-array v6, v5, [Ljava/lang/String;

    .line 26
    aput-object v0, v6, v3

    .line 28
    move-object v7, v1

    .line 29
    check-cast v7, LWorkSpecDao;

    .line 31
    invoke-virtual {v7, v4, v6}, LWorkSpecDao;->m(LWorkInfo_State;[Ljava/lang/String;)I

    .line 34
    move-object v4, v1

    .line 35
    check-cast v4, LWorkSpecDao;

    .line 37
    iget-object v6, v4, LWorkSpecDao;->a:Ljq;

    .line 39
    invoke-virtual {v6}, Ljq;->b()V

    .line 42
    iget-object v4, v4, LWorkSpecDao;->g:LWorkSpecDao$f;

    .line 44
    invoke-virtual {v4}, Lcs;->a()Lue;

    .line 47
    move-result-object v7

    .line 48
    if-nez v0, :cond_0

    .line 50
    invoke-virtual {v7, v5}, Lte;->s(I)V

    .line 53
    goto :goto_0

    .line 54
    :cond_0
    invoke-virtual {v7, v0, v5}, Lte;->t(Ljava/lang/String;I)V

    .line 57
    :goto_0
    invoke-virtual {v6}, Ljq;->c()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 60
    :try_start_1
    invoke-virtual {v7}, Lue;->u()I

    .line 63
    invoke-virtual {v6}, Ljq;->h()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 66
    :try_start_2
    invoke-virtual {v6}, Ljq;->f()V

    .line 69
    invoke-virtual {v4, v7}, Lcs;->c(Lue;)V

    .line 72
    check-cast v1, LWorkSpecDao;

    .line 74
    const-wide/16 v4, -0x1

    .line 76
    invoke-virtual {v1, v0, v4, v5}, LWorkSpecDao;->j(Ljava/lang/String;J)I

    .line 79
    invoke-virtual {v2}, Ljq;->h()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 82
    invoke-virtual {v2}, Ljq;->f()V

    .line 85
    invoke-virtual {p0, v3}, LWorkerWrapper;->f(Z)V

    .line 88
    return-void

    .line 89
    :catchall_0
    move-exception v0

    .line 90
    :try_start_3
    invoke-virtual {v6}, Ljq;->f()V

    .line 93
    invoke-virtual {v4, v7}, Lcs;->c(Lue;)V

    .line 96
    throw v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 97
    :catchall_1
    move-exception v0

    .line 98
    invoke-virtual {v2}, Ljq;->f()V

    .line 101
    invoke-virtual {p0, v3}, LWorkerWrapper;->f(Z)V

    .line 104
    throw v0
.end method

.method public final f(Z)V
    .locals 5

    .line 1
    iget-object v0, p0, LWorkerWrapper;->l:Landroidx/work/impl/WorkDatabase;

    .line 3
    invoke-virtual {v0}, Ljq;->c()V

    .line 6
    :try_start_0
    iget-object v0, p0, LWorkerWrapper;->l:Landroidx/work/impl/WorkDatabase;

    .line 8
    invoke-virtual {v0}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 11
    move-result-object v0

    .line 12
    check-cast v0, LWorkSpecDao;

    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    const-string v1, "SELECT COUNT(*) > 0 FROM workspec WHERE state NOT IN (2, 3, 5) LIMIT 1"

    .line 19
    const/4 v2, 0x0

    .line 20
    invoke-static {v1, v2}, Llq;->r(Ljava/lang/String;I)Llq;

    .line 23
    move-result-object v1

    .line 24
    iget-object v0, v0, LWorkSpecDao;->a:Ljq;

    .line 26
    invoke-virtual {v0}, Ljq;->b()V

    .line 29
    invoke-virtual {v0, v1}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 32
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 33
    :try_start_1
    invoke-interface {v0}, Landroid/database/Cursor;->moveToFirst()Z

    .line 36
    move-result v3

    .line 37
    const/4 v4, 0x1

    .line 38
    if-eqz v3, :cond_0

    .line 40
    invoke-interface {v0, v2}, Landroid/database/Cursor;->getInt(I)I

    .line 43
    move-result v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 44
    if-eqz v3, :cond_0

    .line 46
    const/4 v3, 0x1

    .line 47
    goto :goto_0

    .line 48
    :cond_0
    const/4 v3, 0x0

    .line 49
    :goto_0
    :try_start_2
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 52
    invoke-virtual {v1}, Llq;->v()V

    .line 55
    if-nez v3, :cond_1

    .line 57
    iget-object v0, p0, LWorkerWrapper;->c:Landroid/content/Context;

    .line 59
    const-class v1, Landroidx/work/impl/background/systemalarm/RescheduleReceiver;

    .line 61
    invoke-static {v0, v1, v2}, Lqn;->a(Landroid/content/Context;Ljava/lang/Class;Z)V

    .line 64
    :cond_1
    if-eqz p1, :cond_2

    .line 66
    iget-object v0, p0, LWorkerWrapper;->m:Lz00;

    .line 68
    sget-object v1, LWorkInfo_State;->c:LWorkInfo_State;

    .line 70
    new-array v3, v4, [Ljava/lang/String;

    .line 72
    iget-object v4, p0, LWorkerWrapper;->d:Ljava/lang/String;

    .line 74
    aput-object v4, v3, v2

    .line 76
    check-cast v0, LWorkSpecDao;

    .line 78
    invoke-virtual {v0, v1, v3}, LWorkSpecDao;->m(LWorkInfo_State;[Ljava/lang/String;)I

    .line 81
    iget-object v0, p0, LWorkerWrapper;->m:Lz00;

    .line 83
    iget-object v1, p0, LWorkerWrapper;->d:Ljava/lang/String;

    .line 85
    check-cast v0, LWorkSpecDao;

    .line 87
    const-wide/16 v2, -0x1

    .line 89
    invoke-virtual {v0, v1, v2, v3}, LWorkSpecDao;->j(Ljava/lang/String;J)I

    .line 92
    :cond_2
    iget-object v0, p0, LWorkerWrapper;->f:LWorkSpec;

    .line 94
    if-eqz v0, :cond_3

    .line 96
    iget-object v0, p0, LWorkerWrapper;->g:Landroidx/work/ListenableWorker;

    .line 98
    if-eqz v0, :cond_3

    .line 100
    invoke-virtual {v0}, Landroidx/work/ListenableWorker;->a()Z

    .line 103
    move-result v0

    .line 104
    if-eqz v0, :cond_3

    .line 106
    iget-object v0, p0, LWorkerWrapper;->k:Lpd;

    .line 108
    iget-object v1, p0, LWorkerWrapper;->d:Ljava/lang/String;

    .line 110
    check-cast v0, Luo;

    .line 112
    iget-object v2, v0, Luo;->m:Ljava/lang/Object;

    .line 114
    monitor-enter v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 115
    :try_start_3
    iget-object v3, v0, Luo;->h:Ljava/util/HashMap;

    .line 117
    invoke-virtual {v3, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 120
    invoke-virtual {v0}, Luo;->i()V

    .line 123
    monitor-exit v2

    .line 124
    goto :goto_1

    .line 125
    :catchall_0
    move-exception p1

    .line 126
    monitor-exit v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 127
    :try_start_4
    throw p1

    .line 128
    :cond_3
    :goto_1
    iget-object v0, p0, LWorkerWrapper;->l:Landroidx/work/impl/WorkDatabase;

    .line 130
    invoke-virtual {v0}, Ljq;->h()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 133
    iget-object v0, p0, LWorkerWrapper;->l:Landroidx/work/impl/WorkDatabase;

    .line 135
    invoke-virtual {v0}, Ljq;->f()V

    .line 138
    iget-object v0, p0, LWorkerWrapper;->r:Ltr;

    .line 140
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 143
    move-result-object p1

    .line 144
    invoke-virtual {v0, p1}, Ltr;->i(Ljava/lang/Object;)Z

    .line 147
    return-void

    .line 148
    :catchall_1
    move-exception p1

    .line 149
    :try_start_5
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 152
    invoke-virtual {v1}, Llq;->v()V

    .line 155
    throw p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 156
    :catchall_2
    move-exception p1

    .line 157
    iget-object v0, p0, LWorkerWrapper;->l:Landroidx/work/impl/WorkDatabase;

    .line 159
    invoke-virtual {v0}, Ljq;->f()V

    .line 162
    throw p1
.end method

.method public final g()V
    .locals 6

    .line 1
    iget-object v0, p0, LWorkerWrapper;->m:Lz00;

    .line 3
    check-cast v0, LWorkSpecDao;

    .line 5
    iget-object v1, p0, LWorkerWrapper;->d:Ljava/lang/String;

    .line 7
    invoke-virtual {v0, v1}, LWorkSpecDao;->f(Ljava/lang/String;)LWorkInfo_State;

    .line 10
    move-result-object v0

    .line 11
    sget-object v2, LWorkInfo_State;->d:LWorkInfo_State;

    .line 13
    const/4 v3, 0x1

    .line 14
    const/4 v4, 0x0

    .line 15
    if-ne v0, v2, :cond_0

    .line 17
    invoke-static {}, Ltj;->c()Ltj;

    .line 20
    move-result-object v0

    .line 21
    new-array v2, v3, [Ljava/lang/Object;

    .line 23
    aput-object v1, v2, v4

    .line 25
    const-string v1, "Status for %s is RUNNING;not doing any work and rescheduling for later execution"

    .line 27
    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 30
    new-array v1, v4, [Ljava/lang/Throwable;

    .line 32
    invoke-virtual {v0, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 35
    invoke-virtual {p0, v3}, LWorkerWrapper;->f(Z)V

    .line 38
    goto :goto_0

    .line 39
    :cond_0
    invoke-static {}, Ltj;->c()Ltj;

    .line 42
    move-result-object v2

    .line 43
    const/4 v5, 0x2

    .line 44
    new-array v5, v5, [Ljava/lang/Object;

    .line 46
    aput-object v1, v5, v4

    .line 48
    aput-object v0, v5, v3

    .line 50
    const-string v0, "Status for %s is %s; not doing any work"

    .line 52
    invoke-static {v0, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 55
    new-array v0, v4, [Ljava/lang/Throwable;

    .line 57
    invoke-virtual {v2, v0}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 60
    invoke-virtual {p0, v4}, LWorkerWrapper;->f(Z)V

    .line 63
    :goto_0
    return-void
.end method

.method public final h()V
    .locals 5

    .line 1
    iget-object v0, p0, LWorkerWrapper;->d:Ljava/lang/String;

    .line 3
    iget-object v1, p0, LWorkerWrapper;->l:Landroidx/work/impl/WorkDatabase;

    .line 5
    invoke-virtual {v1}, Ljq;->c()V

    .line 8
    const/4 v2, 0x0

    .line 9
    :try_start_0
    invoke-virtual {p0, v0}, LWorkerWrapper;->b(Ljava/lang/String;)V

    .line 12
    iget-object v3, p0, LWorkerWrapper;->i:Landroidx/work/ListenableWorker$a;

    .line 14
    check-cast v3, Landroidx/work/ListenableWorker$a$a;

    .line 16
    iget-object v3, v3, Landroidx/work/ListenableWorker$a$a;->a:Landroidx/work/b;

    .line 18
    iget-object v4, p0, LWorkerWrapper;->m:Lz00;

    .line 20
    check-cast v4, LWorkSpecDao;

    .line 22
    invoke-virtual {v4, v0, v3}, LWorkSpecDao;->k(Ljava/lang/String;Landroidx/work/b;)V

    .line 25
    invoke-virtual {v1}, Ljq;->h()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 28
    invoke-virtual {v1}, Ljq;->f()V

    .line 31
    invoke-virtual {p0, v2}, LWorkerWrapper;->f(Z)V

    .line 34
    return-void

    .line 35
    :catchall_0
    move-exception v0

    .line 36
    invoke-virtual {v1}, Ljq;->f()V

    .line 39
    invoke-virtual {p0, v2}, LWorkerWrapper;->f(Z)V

    .line 42
    throw v0
.end method

.method public final i()Z
    .locals 5

    .line 1
    iget-boolean v0, p0, LWorkerWrapper;->t:Z

    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_1

    .line 6
    invoke-static {}, Ltj;->c()Ltj;

    .line 9
    move-result-object v0

    .line 10
    const/4 v2, 0x1

    .line 11
    new-array v3, v2, [Ljava/lang/Object;

    .line 13
    iget-object v4, p0, LWorkerWrapper;->q:Ljava/lang/String;

    .line 15
    aput-object v4, v3, v1

    .line 17
    const-string v4, "Work interrupted for %s"

    .line 19
    invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 22
    new-array v3, v1, [Ljava/lang/Throwable;

    .line 24
    invoke-virtual {v0, v3}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 27
    iget-object v0, p0, LWorkerWrapper;->m:Lz00;

    .line 29
    iget-object v3, p0, LWorkerWrapper;->d:Ljava/lang/String;

    .line 31
    check-cast v0, LWorkSpecDao;

    .line 33
    invoke-virtual {v0, v3}, LWorkSpecDao;->f(Ljava/lang/String;)LWorkInfo_State;

    .line 36
    move-result-object v0

    .line 37
    if-nez v0, :cond_0

    .line 39
    invoke-virtual {p0, v1}, LWorkerWrapper;->f(Z)V

    .line 42
    goto :goto_0

    .line 43
    :cond_0
    invoke-virtual {v0}, LWorkInfo_State;->a()Z

    .line 46
    move-result v0

    .line 47
    xor-int/2addr v0, v2

    .line 48
    invoke-virtual {p0, v0}, LWorkerWrapper;->f(Z)V

    .line 51
    :goto_0
    return v2

    .line 52
    :cond_1
    return v1
.end method

.method public final run()V
    .locals 17

    .line 1
    move-object/from16 v1, p0

    .line 3
    iget-object v0, v1, LWorkerWrapper;->o:Lc10;

    .line 5
    check-cast v0, Ld10;

    .line 7
    iget-object v2, v1, LWorkerWrapper;->d:Ljava/lang/String;

    .line 9
    invoke-virtual {v0, v2}, Ld10;->a(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 12
    move-result-object v0

    .line 13
    iput-object v0, v1, LWorkerWrapper;->p:Ljava/util/ArrayList;

    .line 15
    new-instance v3, Ljava/lang/StringBuilder;

    .line 17
    const-string v4, "Work [ id="

    .line 19
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 22
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    const-string v4, ", tags={ "

    .line 27
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 33
    move-result-object v0

    .line 34
    const/4 v4, 0x1

    .line 35
    const/4 v5, 0x1

    .line 36
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 39
    move-result v6

    .line 40
    const/4 v7, 0x0

    .line 41
    if-eqz v6, :cond_1

    .line 43
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 46
    move-result-object v6

    .line 47
    check-cast v6, Ljava/lang/String;

    .line 49
    if-eqz v5, :cond_0

    .line 51
    const/4 v5, 0x0

    .line 52
    goto :goto_1

    .line 53
    :cond_0
    const-string v7, ", "

    .line 55
    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 58
    :goto_1
    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 61
    goto :goto_0

    .line 62
    :cond_1
    const-string v0, " } ]"

    .line 64
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 67
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 70
    move-result-object v0

    .line 71
    iput-object v0, v1, LWorkerWrapper;->q:Ljava/lang/String;

    .line 73
    iget-object v3, v1, LWorkerWrapper;->m:Lz00;

    .line 75
    invoke-virtual/range {p0 .. p0}, LWorkerWrapper;->i()Z

    .line 78
    move-result v0

    .line 79
    if-eqz v0, :cond_2

    .line 81
    goto/16 :goto_c

    .line 83
    :cond_2
    iget-object v5, v1, LWorkerWrapper;->l:Landroidx/work/impl/WorkDatabase;

    .line 85
    invoke-virtual {v5}, Ljq;->c()V

    .line 88
    :try_start_0
    move-object v0, v3

    .line 89
    check-cast v0, LWorkSpecDao;

    .line 91
    invoke-virtual {v0, v2}, LWorkSpecDao;->h(Ljava/lang/String;)LWorkSpec;

    .line 94
    move-result-object v0

    .line 95
    iput-object v0, v1, LWorkerWrapper;->f:LWorkSpec;

    .line 97
    if-nez v0, :cond_3

    .line 99
    invoke-static {}, Ltj;->c()Ltj;

    .line 102
    move-result-object v0

    .line 103
    const-string v3, "Didn\'t find WorkSpec for id %s"

    .line 105
    new-array v4, v4, [Ljava/lang/Object;

    .line 107
    aput-object v2, v4, v7

    .line 109
    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 112
    new-array v2, v7, [Ljava/lang/Throwable;

    .line 114
    invoke-virtual {v0, v2}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 117
    invoke-virtual {v1, v7}, LWorkerWrapper;->f(Z)V

    .line 120
    invoke-virtual {v5}, Ljq;->h()V

    .line 123
    goto/16 :goto_4

    .line 125
    :cond_3
    iget-object v6, v0, LWorkSpec;->b:LWorkInfo_State;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    .line 127
    sget-object v8, LWorkInfo_State;->c:LWorkInfo_State;

    .line 129
    if-eq v6, v8, :cond_4

    .line 131
    :try_start_1
    invoke-virtual/range {p0 .. p0}, LWorkerWrapper;->g()V

    .line 134
    invoke-virtual {v5}, Ljq;->h()V

    .line 137
    invoke-static {}, Ltj;->c()Ltj;

    .line 140
    move-result-object v0

    .line 141
    const-string v2, "%s is not in ENQUEUED state. Nothing more to do."

    .line 143
    new-array v3, v4, [Ljava/lang/Object;

    .line 145
    iget-object v4, v1, LWorkerWrapper;->f:LWorkSpec;

    .line 147
    iget-object v4, v4, LWorkSpec;->c:Ljava/lang/String;

    .line 149
    aput-object v4, v3, v7

    .line 151
    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 154
    new-array v2, v7, [Ljava/lang/Throwable;

    .line 156
    invoke-virtual {v0, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 159
    goto :goto_4

    .line 160
    :cond_4
    invoke-virtual {v0}, LWorkSpec;->c()Z

    .line 163
    move-result v0

    .line 164
    if-nez v0, :cond_6

    .line 166
    iget-object v0, v1, LWorkerWrapper;->f:LWorkSpec;

    .line 168
    iget-object v6, v0, LWorkSpec;->b:LWorkInfo_State;

    .line 170
    if-ne v6, v8, :cond_5

    .line 172
    iget v0, v0, LWorkSpec;->k:I

    .line 174
    if-lez v0, :cond_5

    .line 176
    const/4 v0, 0x1

    .line 177
    goto :goto_2

    .line 178
    :cond_5
    const/4 v0, 0x0

    .line 179
    :goto_2
    if-eqz v0, :cond_8

    .line 181
    :cond_6
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 184
    move-result-wide v9

    .line 185
    iget-object v0, v1, LWorkerWrapper;->f:LWorkSpec;

    .line 187
    iget-wide v11, v0, LWorkSpec;->n:J

    .line 189
    const-wide/16 v13, 0x0

    .line 191
    cmp-long v6, v11, v13

    .line 193
    if-nez v6, :cond_7

    .line 195
    const/4 v6, 0x1

    .line 196
    goto :goto_3

    .line 197
    :cond_7
    const/4 v6, 0x0

    .line 198
    :goto_3
    if-nez v6, :cond_8

    .line 200
    invoke-virtual {v0}, LWorkSpec;->a()J

    .line 203
    move-result-wide v11

    .line 204
    cmp-long v0, v9, v11

    .line 206
    if-gez v0, :cond_8

    .line 208
    invoke-static {}, Ltj;->c()Ltj;

    .line 211
    move-result-object v0

    .line 212
    const-string v2, "Delaying execution for %s because it is being executed before schedule."

    .line 214
    new-array v3, v4, [Ljava/lang/Object;

    .line 216
    iget-object v6, v1, LWorkerWrapper;->f:LWorkSpec;

    .line 218
    iget-object v6, v6, LWorkSpec;->c:Ljava/lang/String;

    .line 220
    aput-object v6, v3, v7

    .line 222
    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 225
    new-array v2, v7, [Ljava/lang/Throwable;

    .line 227
    invoke-virtual {v0, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 230
    invoke-virtual {v1, v4}, LWorkerWrapper;->f(Z)V

    .line 233
    invoke-virtual {v5}, Ljq;->h()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    .line 236
    :goto_4
    invoke-virtual {v5}, Ljq;->f()V

    .line 239
    goto/16 :goto_c

    .line 241
    :cond_8
    :try_start_2
    invoke-virtual {v5}, Ljq;->h()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    .line 244
    invoke-virtual {v5}, Ljq;->f()V

    .line 247
    iget-object v0, v1, LWorkerWrapper;->f:LWorkSpec;

    .line 249
    invoke-virtual {v0}, LWorkSpec;->c()Z

    .line 252
    move-result v0

    .line 253
    iget-object v6, v1, LWorkerWrapper;->j:Landroidx/work/a;

    .line 255
    if-eqz v0, :cond_9

    .line 257
    iget-object v0, v1, LWorkerWrapper;->f:LWorkSpec;

    .line 259
    iget-object v0, v0, LWorkSpec;->e:Landroidx/work/b;

    .line 261
    :goto_5
    move-object v11, v0

    .line 262
    goto/16 :goto_9

    .line 264
    :cond_9
    iget-object v0, v6, Landroidx/work/a;->d:Lgi;

    .line 266
    iget-object v9, v1, LWorkerWrapper;->f:LWorkSpec;

    .line 268
    iget-object v9, v9, LWorkSpec;->d:Ljava/lang/String;

    .line 270
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 273
    sget v0, Lfi;->a:I

    .line 275
    :try_start_3
    invoke-static {v9}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 278
    move-result-object v0

    .line 279
    invoke-virtual {v0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    .line 282
    move-result-object v0

    .line 283
    check-cast v0, Lfi;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    .line 285
    goto :goto_6

    .line 286
    :catch_0
    move-exception v0

    .line 287
    invoke-static {}, Ltj;->c()Ltj;

    .line 290
    move-result-object v9

    .line 291
    new-array v10, v4, [Ljava/lang/Throwable;

    .line 293
    aput-object v0, v10, v7

    .line 295
    sget v0, Lfi;->a:I

    .line 297
    invoke-virtual {v9, v10}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 300
    const/4 v0, 0x0

    .line 301
    :goto_6
    if-nez v0, :cond_a

    .line 303
    invoke-static {}, Ltj;->c()Ltj;

    .line 306
    move-result-object v0

    .line 307
    new-array v2, v4, [Ljava/lang/Object;

    .line 309
    iget-object v3, v1, LWorkerWrapper;->f:LWorkSpec;

    .line 311
    iget-object v3, v3, LWorkSpec;->d:Ljava/lang/String;

    .line 313
    aput-object v3, v2, v7

    .line 315
    const-string v3, "Could not create Input Merger %s"

    .line 317
    invoke-static {v3, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 320
    new-array v2, v7, [Ljava/lang/Throwable;

    .line 322
    invoke-virtual {v0, v2}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 325
    invoke-virtual/range {p0 .. p0}, LWorkerWrapper;->h()V

    .line 328
    goto/16 :goto_c

    .line 330
    :cond_a
    new-instance v9, Ljava/util/ArrayList;

    .line 332
    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    .line 335
    iget-object v10, v1, LWorkerWrapper;->f:LWorkSpec;

    .line 337
    iget-object v10, v10, LWorkSpec;->e:Landroidx/work/b;

    .line 339
    invoke-virtual {v9, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 342
    move-object v10, v3

    .line 343
    check-cast v10, LWorkSpecDao;

    .line 345
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 348
    const-string v11, "SELECT output FROM workspec WHERE id IN (SELECT prerequisite_id FROM dependency WHERE work_spec_id=?)"

    .line 350
    invoke-static {v11, v4}, Llq;->r(Ljava/lang/String;I)Llq;

    .line 353
    move-result-object v11

    .line 354
    if-nez v2, :cond_b

    .line 356
    invoke-virtual {v11, v4}, Llq;->t(I)V

    .line 359
    goto :goto_7

    .line 360
    :cond_b
    invoke-virtual {v11, v2, v4}, Llq;->u(Ljava/lang/String;I)V

    .line 363
    :goto_7
    iget-object v10, v10, LWorkSpecDao;->a:Ljq;

    .line 365
    invoke-virtual {v10}, Ljq;->b()V

    .line 368
    invoke-virtual {v10, v11}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 371
    move-result-object v10

    .line 372
    :try_start_4
    new-instance v12, Ljava/util/ArrayList;

    .line 374
    invoke-interface {v10}, Landroid/database/Cursor;->getCount()I

    .line 377
    move-result v13

    .line 378
    invoke-direct {v12, v13}, Ljava/util/ArrayList;-><init>(I)V

    .line 381
    :goto_8
    invoke-interface {v10}, Landroid/database/Cursor;->moveToNext()Z

    .line 384
    move-result v13

    .line 385
    if-eqz v13, :cond_c

    .line 387
    invoke-interface {v10, v7}, Landroid/database/Cursor;->getBlob(I)[B

    .line 390
    move-result-object v13

    .line 391
    invoke-static {v13}, Landroidx/work/b;->a([B)Landroidx/work/b;

    .line 394
    move-result-object v13

    .line 395
    invoke-virtual {v12, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 398
    goto :goto_8

    .line 399
    :cond_c
    invoke-interface {v10}, Landroid/database/Cursor;->close()V

    .line 402
    invoke-virtual {v11}, Llq;->v()V

    .line 405
    invoke-virtual {v9, v12}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 408
    invoke-virtual {v0, v9}, Lfi;->a(Ljava/util/ArrayList;)Landroidx/work/b;

    .line 411
    move-result-object v0

    .line 412
    goto/16 :goto_5

    .line 414
    :goto_9
    new-instance v0, Landroidx/work/WorkerParameters;

    .line 416
    invoke-static {v2}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    .line 419
    move-result-object v10

    .line 420
    iget-object v12, v1, LWorkerWrapper;->p:Ljava/util/ArrayList;

    .line 422
    iget-object v9, v1, LWorkerWrapper;->f:LWorkSpec;

    .line 424
    iget v9, v9, LWorkSpec;->k:I

    .line 426
    iget-object v13, v6, Landroidx/work/a;->a:Ljava/util/concurrent/ExecutorService;

    .line 428
    iget-object v6, v6, Landroidx/work/a;->c:Lg10;

    .line 430
    new-instance v9, Lv00;

    .line 432
    new-instance v15, Ll00;

    .line 434
    iget-object v9, v1, LWorkerWrapper;->k:Lpd;

    .line 436
    iget-object v14, v1, LWorkerWrapper;->h:Lnu;

    .line 438
    invoke-direct {v15, v5, v9, v14}, Ll00;-><init>(Landroidx/work/impl/WorkDatabase;Lpd;Lnu;)V

    .line 441
    move-object v9, v0

    .line 442
    move-object/from16 v16, v14

    .line 444
    move-object v14, v6

    .line 445
    invoke-direct/range {v9 .. v15}, Landroidx/work/WorkerParameters;-><init>(Ljava/util/UUID;Landroidx/work/b;Ljava/util/List;Ljava/util/concurrent/ExecutorService;Lg10;Ll00;)V

    .line 448
    iget-object v9, v1, LWorkerWrapper;->g:Landroidx/work/ListenableWorker;

    .line 450
    if-nez v9, :cond_d

    .line 452
    iget-object v9, v1, LWorkerWrapper;->f:LWorkSpec;

    .line 454
    iget-object v9, v9, LWorkSpec;->c:Ljava/lang/String;

    .line 456
    iget-object v10, v1, LWorkerWrapper;->c:Landroid/content/Context;

    .line 458
    invoke-virtual {v6, v10, v9, v0}, Lh10;->a(Landroid/content/Context;Ljava/lang/String;Landroidx/work/WorkerParameters;)Landroidx/work/ListenableWorker;

    .line 461
    move-result-object v6

    .line 462
    iput-object v6, v1, LWorkerWrapper;->g:Landroidx/work/ListenableWorker;

    .line 464
    :cond_d
    iget-object v6, v1, LWorkerWrapper;->g:Landroidx/work/ListenableWorker;

    .line 466
    if-nez v6, :cond_e

    .line 468
    invoke-static {}, Ltj;->c()Ltj;

    .line 471
    move-result-object v0

    .line 472
    new-array v2, v4, [Ljava/lang/Object;

    .line 474
    iget-object v3, v1, LWorkerWrapper;->f:LWorkSpec;

    .line 476
    iget-object v3, v3, LWorkSpec;->c:Ljava/lang/String;

    .line 478
    aput-object v3, v2, v7

    .line 480
    const-string v3, "Could not create Worker %s"

    .line 482
    invoke-static {v3, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 485
    new-array v2, v7, [Ljava/lang/Throwable;

    .line 487
    invoke-virtual {v0, v2}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 490
    invoke-virtual/range {p0 .. p0}, LWorkerWrapper;->h()V

    .line 493
    goto/16 :goto_c

    .line 495
    :cond_e
    iget-boolean v9, v6, Landroidx/work/ListenableWorker;->f:Z

    .line 497
    if-eqz v9, :cond_f

    .line 499
    invoke-static {}, Ltj;->c()Ltj;

    .line 502
    move-result-object v0

    .line 503
    new-array v2, v4, [Ljava/lang/Object;

    .line 505
    iget-object v3, v1, LWorkerWrapper;->f:LWorkSpec;

    .line 507
    iget-object v3, v3, LWorkSpec;->c:Ljava/lang/String;

    .line 509
    aput-object v3, v2, v7

    .line 511
    const-string v3, "Received an already-used Worker %s; WorkerFactory should return new instances"

    .line 513
    invoke-static {v3, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 516
    new-array v2, v7, [Ljava/lang/Throwable;

    .line 518
    invoke-virtual {v0, v2}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 521
    invoke-virtual/range {p0 .. p0}, LWorkerWrapper;->h()V

    .line 524
    goto/16 :goto_c

    .line 526
    :cond_f
    iput-boolean v4, v6, Landroidx/work/ListenableWorker;->f:Z

    .line 528
    invoke-virtual {v5}, Ljq;->c()V

    .line 531
    :try_start_5
    move-object v6, v3

    .line 532
    check-cast v6, LWorkSpecDao;

    .line 534
    invoke-virtual {v6, v2}, LWorkSpecDao;->f(Ljava/lang/String;)LWorkInfo_State;

    .line 537
    move-result-object v6

    .line 538
    if-ne v6, v8, :cond_11

    .line 540
    sget-object v6, LWorkInfo_State;->d:LWorkInfo_State;

    .line 542
    new-array v8, v4, [Ljava/lang/String;

    .line 544
    aput-object v2, v8, v7

    .line 546
    move-object v7, v3

    .line 547
    check-cast v7, LWorkSpecDao;

    .line 549
    invoke-virtual {v7, v6, v8}, LWorkSpecDao;->m(LWorkInfo_State;[Ljava/lang/String;)I

    .line 552
    check-cast v3, LWorkSpecDao;

    .line 554
    iget-object v6, v3, LWorkSpecDao;->a:Ljq;

    .line 556
    invoke-virtual {v6}, Ljq;->b()V

    .line 559
    iget-object v3, v3, LWorkSpecDao;->f:LWorkSpecDao$e;

    .line 561
    invoke-virtual {v3}, Lcs;->a()Lue;

    .line 564
    move-result-object v7

    .line 565
    if-nez v2, :cond_10

    .line 567
    invoke-virtual {v7, v4}, Lte;->s(I)V

    .line 570
    goto :goto_a

    .line 571
    :cond_10
    invoke-virtual {v7, v2, v4}, Lte;->t(Ljava/lang/String;I)V

    .line 574
    :goto_a
    invoke-virtual {v6}, Ljq;->c()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 577
    :try_start_6
    invoke-virtual {v7}, Lue;->u()I

    .line 580
    invoke-virtual {v6}, Ljq;->h()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 583
    :try_start_7
    invoke-virtual {v6}, Ljq;->f()V

    .line 586
    invoke-virtual {v3, v7}, Lcs;->c(Lue;)V

    .line 589
    goto :goto_b

    .line 590
    :catchall_0
    move-exception v0

    .line 591
    invoke-virtual {v6}, Ljq;->f()V

    .line 594
    invoke-virtual {v3, v7}, Lcs;->c(Lue;)V

    .line 597
    throw v0

    .line 598
    :cond_11
    const/4 v4, 0x0

    .line 599
    :goto_b
    invoke-virtual {v5}, Ljq;->h()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 602
    invoke-virtual {v5}, Ljq;->f()V

    .line 605
    if-eqz v4, :cond_13

    .line 607
    invoke-virtual/range {p0 .. p0}, LWorkerWrapper;->i()Z

    .line 610
    move-result v2

    .line 611
    if-eqz v2, :cond_12

    .line 613
    goto :goto_c

    .line 614
    :cond_12
    new-instance v2, Ltr;

    .line 616
    invoke-direct {v2}, Ltr;-><init>()V

    .line 619
    new-instance v9, Lj00;

    .line 621
    iget-object v4, v1, LWorkerWrapper;->c:Landroid/content/Context;

    .line 623
    iget-object v5, v1, LWorkerWrapper;->f:LWorkSpec;

    .line 625
    iget-object v6, v1, LWorkerWrapper;->g:Landroidx/work/ListenableWorker;

    .line 627
    iget-object v7, v0, Landroidx/work/WorkerParameters;->e:Lrd;

    .line 629
    iget-object v8, v1, LWorkerWrapper;->h:Lnu;

    .line 631
    move-object v3, v9

    .line 632
    invoke-direct/range {v3 .. v8}, Lj00;-><init>(Landroid/content/Context;LWorkSpec;Landroidx/work/ListenableWorker;Lrd;Lnu;)V

    .line 635
    move-object/from16 v14, v16

    .line 637
    check-cast v14, Lp00;

    .line 639
    iget-object v0, v14, Lp00;->c:Lp00$a;

    .line 641
    invoke-virtual {v0, v9}, Lp00$a;->execute(Ljava/lang/Runnable;)V

    .line 644
    new-instance v0, Li10;

    .line 646
    iget-object v3, v9, Lj00;->c:Ltr;

    .line 648
    invoke-direct {v0, v1, v3, v2}, Li10;-><init>(LWorkerWrapper;Ltr;Ltr;)V

    .line 651
    iget-object v4, v14, Lp00;->c:Lp00$a;

    .line 653
    invoke-virtual {v3, v0, v4}, Lf;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 656
    iget-object v0, v1, LWorkerWrapper;->q:Ljava/lang/String;

    .line 658
    new-instance v3, Lj10;

    .line 660
    invoke-direct {v3, v1, v2, v0}, Lj10;-><init>(LWorkerWrapper;Ltr;Ljava/lang/String;)V

    .line 663
    iget-object v0, v14, Lp00;->a:Lsr;

    .line 665
    invoke-virtual {v2, v3, v0}, Lf;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 668
    goto :goto_c

    .line 669
    :cond_13
    invoke-virtual/range {p0 .. p0}, LWorkerWrapper;->g()V

    .line 672
    :goto_c
    return-void

    .line 673
    :catchall_1
    move-exception v0

    .line 674
    invoke-virtual {v5}, Ljq;->f()V

    .line 677
    throw v0

    .line 678
    :catchall_2
    move-exception v0

    .line 679
    invoke-interface {v10}, Landroid/database/Cursor;->close()V

    .line 682
    invoke-virtual {v11}, Llq;->v()V

    .line 685
    throw v0

    .line 686
    :catchall_3
    move-exception v0

    .line 687
    invoke-virtual {v5}, Ljq;->f()V

    .line 690
    throw v0
.end method
