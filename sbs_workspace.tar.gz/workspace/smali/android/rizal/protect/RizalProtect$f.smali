.class public Landroid/rizal/protect/RizalProtect$f;
.super Ljava/io/FilterInputStream;
.source "a.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/rizal/protect/RizalProtect;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x21
    name = "f"
.end annotation


# instance fields
.field private b:[B

.field protected buf:[B

.field private closed:Z

.field protected inf:Ljava/util/zip/Inflater;

.field protected len:I

.field private reachEOF:Z

.field private singleByteBuf:[B

.field private final this$0:Landroid/rizal/protect/RizalProtect;

.field usesDefaultInflater:Z


# direct methods
.method public constructor <init>(Landroid/rizal/protect/RizalProtect;Ljava/io/InputStream;)V
    .locals 1

    .prologue
    .line 896
    new-instance v0, Ljava/util/zip/Inflater;

    invoke-direct {v0}, Ljava/util/zip/Inflater;-><init>()V

    invoke-direct {p0, p1, p2, v0}, Landroid/rizal/protect/RizalProtect$f;-><init>(Landroid/rizal/protect/RizalProtect;Ljava/io/InputStream;Ljava/util/zip/Inflater;)V

    .line 897
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/rizal/protect/RizalProtect$f;->usesDefaultInflater:Z

    return-void
.end method

.method public constructor <init>(Landroid/rizal/protect/RizalProtect;Ljava/io/InputStream;Ljava/util/zip/Inflater;)V
    .locals 1

    .prologue
    .line 888
    const/16 v0, 0x200

    invoke-direct {p0, p1, p2, p3, v0}, Landroid/rizal/protect/RizalProtect$f;-><init>(Landroid/rizal/protect/RizalProtect;Ljava/io/InputStream;Ljava/util/zip/Inflater;I)V

    return-void
.end method

.method public constructor <init>(Landroid/rizal/protect/RizalProtect;Ljava/io/InputStream;Ljava/util/zip/Inflater;I)V
    .locals 2

    .prologue
    const/4 v0, 0x0

    .line 872
    invoke-direct {p0, p2}, Ljava/io/FilterInputStream;-><init>(Ljava/io/InputStream;)V

    iput-object p1, p0, Landroid/rizal/protect/RizalProtect$f;->this$0:Landroid/rizal/protect/RizalProtect;

    iput-boolean v0, p0, Landroid/rizal/protect/RizalProtect$f;->closed:Z

    iput-boolean v0, p0, Landroid/rizal/protect/RizalProtect$f;->reachEOF:Z

    iput-boolean v0, p0, Landroid/rizal/protect/RizalProtect$f;->usesDefaultInflater:Z

    const/4 v0, 0x1

    new-array v0, v0, [B

    iput-object v0, p0, Landroid/rizal/protect/RizalProtect$f;->singleByteBuf:[B

    const/16 v0, 0x200

    new-array v0, v0, [B

    iput-object v0, p0, Landroid/rizal/protect/RizalProtect$f;->b:[B

    .line 873
    if-eqz p2, :cond_0

    if-nez p3, :cond_1

    .line 875
    :cond_0
    new-instance v0, Ljava/lang/NullPointerException;

    invoke-direct {v0}, Ljava/lang/NullPointerException;-><init>()V

    throw v0

    .line 877
    :cond_1
    if-gtz p4, :cond_2

    .line 879
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, ""

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 881
    :cond_2
    iput-object p3, p0, Landroid/rizal/protect/RizalProtect$f;->inf:Ljava/util/zip/Inflater;

    .line 882
    new-array v0, p4, [B

    iput-object v0, p0, Landroid/rizal/protect/RizalProtect$f;->buf:[B

    return-void
.end method

.method static access$0(Landroid/rizal/protect/RizalProtect$f;)Landroid/rizal/protect/RizalProtect;
    .locals 1

    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$f;->this$0:Landroid/rizal/protect/RizalProtect;

    return-object v0
.end method

.method static synthetic access$Ljava$io$FilterInputStream$1(Landroid/rizal/protect/RizalProtect$f;)Ljava/io/InputStream;
    .locals 1

    iget-object v0, p0, Ljava/io/FilterInputStream;->in:Ljava/io/InputStream;

    return-object v0
.end method

.method static synthetic access$Sjava$io$FilterInputStream$1(Landroid/rizal/protect/RizalProtect$f;Ljava/io/InputStream;)V
    .locals 0

    iput-object p1, p0, Ljava/io/FilterInputStream;->in:Ljava/io/InputStream;

    return-void
.end method

.method private ensureOpen()V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V^",
            "Ljava/io/IOException;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    .line 864
    iget-boolean v0, p0, Landroid/rizal/protect/RizalProtect$f;->closed:Z

    if-eqz v0, :cond_0

    .line 866
    new-instance v0, Ljava/io/IOException;

    const-string v1, ""

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_0
    return-void
.end method


# virtual methods
.method public available()I
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    .line 949
    invoke-direct {p0}, Landroid/rizal/protect/RizalProtect$f;->ensureOpen()V

    .line 950
    iget-boolean v0, p0, Landroid/rizal/protect/RizalProtect$f;->reachEOF:Z

    if-eqz v0, :cond_0

    .line 952
    const/4 v0, 0x0

    .line 956
    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x1

    goto :goto_0
.end method

.method public close()V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V^",
            "Ljava/io/IOException;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    .line 991
    iget-boolean v0, p0, Landroid/rizal/protect/RizalProtect$f;->closed:Z

    if-nez v0, :cond_1

    .line 993
    iget-boolean v0, p0, Landroid/rizal/protect/RizalProtect$f;->usesDefaultInflater:Z

    if-eqz v0, :cond_0

    .line 994
    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$f;->inf:Ljava/util/zip/Inflater;

    invoke-virtual {v0}, Ljava/util/zip/Inflater;->end()V

    .line 995
    :cond_0
    iget-object v0, p0, Ljava/io/FilterInputStream;->in:Ljava/io/InputStream;

    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    .line 996
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/rizal/protect/RizalProtect$f;->closed:Z

    :cond_1
    return-void
.end method

.method protected fill()V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V^",
            "Ljava/io/IOException;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    const/4 v3, 0x0

    .line 1002
    invoke-direct {p0}, Landroid/rizal/protect/RizalProtect$f;->ensureOpen()V

    .line 1003
    iget-object v0, p0, Ljava/io/FilterInputStream;->in:Ljava/io/InputStream;

    iget-object v1, p0, Landroid/rizal/protect/RizalProtect$f;->buf:[B

    iget-object v2, p0, Landroid/rizal/protect/RizalProtect$f;->buf:[B

    array-length v2, v2

    invoke-virtual {v0, v1, v3, v2}, Ljava/io/InputStream;->read([BII)I

    move-result v0

    iput v0, p0, Landroid/rizal/protect/RizalProtect$f;->len:I

    .line 1004
    iget v0, p0, Landroid/rizal/protect/RizalProtect$f;->len:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    .line 1006
    new-instance v0, Ljava/io/EOFException;

    const-string v1, ""

    invoke-direct {v0, v1}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 1008
    :cond_0
    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$f;->inf:Ljava/util/zip/Inflater;

    iget-object v1, p0, Landroid/rizal/protect/RizalProtect$f;->buf:[B

    iget v2, p0, Landroid/rizal/protect/RizalProtect$f;->len:I

    invoke-virtual {v0, v1, v3, v2}, Ljava/util/zip/Inflater;->setInput([BII)V

    return-void
.end method

.method public declared-synchronized mark(I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    monitor-enter p0

    monitor-exit p0

    return-void
.end method

.method public markSupported()Z
    .locals 1

    .prologue
    .line 1013
    const/4 v0, 0x0

    return v0
.end method

.method public read()I
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    const/4 v3, 0x0

    const/4 v0, -0x1

    .line 904
    invoke-direct {p0}, Landroid/rizal/protect/RizalProtect$f;->ensureOpen()V

    .line 905
    iget-object v1, p0, Landroid/rizal/protect/RizalProtect$f;->singleByteBuf:[B

    const/4 v2, 0x1

    invoke-virtual {p0, v1, v3, v2}, Landroid/rizal/protect/RizalProtect$f;->read([BII)I

    move-result v1

    if-ne v1, v0, :cond_0

    :goto_0
    return v0

    :cond_0
    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$f;->singleByteBuf:[B

    aget-byte v0, v0, v3

    invoke-static {v0}, Ljava/lang/Byte;->toUnsignedInt(B)I

    move-result v0

    goto :goto_0
.end method

.method public read([BII)I
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    .line 910
    invoke-direct {p0}, Landroid/rizal/protect/RizalProtect$f;->ensureOpen()V

    .line 911
    if-nez p1, :cond_0

    .line 913
    new-instance v0, Ljava/lang/NullPointerException;

    invoke-direct {v0}, Ljava/lang/NullPointerException;-><init>()V

    throw v0

    .line 915
    :cond_0
    if-ltz p2, :cond_1

    if-ltz p3, :cond_1

    array-length v0, p1

    sub-int/2addr v0, p2

    if-le p3, v0, :cond_2

    .line 917
    :cond_1
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    invoke-direct {v0}, Ljava/lang/IndexOutOfBoundsException;-><init>()V

    throw v0

    .line 919
    :cond_2
    if-nez p3, :cond_6

    .line 921
    const/4 v0, 0x0

    .line 938
    :goto_0
    return v0

    .line 928
    :cond_3
    :try_start_0
    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$f;->inf:Ljava/util/zip/Inflater;

    invoke-virtual {v0}, Ljava/util/zip/Inflater;->finished()Z

    move-result v0

    if-nez v0, :cond_4

    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$f;->inf:Ljava/util/zip/Inflater;

    invoke-virtual {v0}, Ljava/util/zip/Inflater;->needsDictionary()Z

    move-result v0

    if-eqz v0, :cond_5

    .line 930
    :cond_4
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/rizal/protect/RizalProtect$f;->reachEOF:Z

    .line 931
    const/4 v0, -0x1

    goto :goto_0

    .line 933
    :cond_5
    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$f;->inf:Ljava/util/zip/Inflater;

    invoke-virtual {v0}, Ljava/util/zip/Inflater;->needsInput()Z

    move-result v0

    if-eqz v0, :cond_6

    .line 935
    invoke-virtual {p0}, Landroid/rizal/protect/RizalProtect$f;->fill()V

    .line 926
    :cond_6
    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$f;->inf:Ljava/util/zip/Inflater;

    invoke-virtual {v0, p1, p2, p3}, Ljava/util/zip/Inflater;->inflate([BII)I
    :try_end_0
    .catch Ljava/util/zip/DataFormatException; {:try_start_0 .. :try_end_0} :catch_0

    move-result v0

    if-eqz v0, :cond_3

    goto :goto_0

    .line 938
    :catch_0
    move-exception v0

    .line 942
    invoke-virtual {v0}, Ljava/util/zip/DataFormatException;->getMessage()Ljava/lang/String;

    move-result-object v0

    .line 943
    new-instance v1, Ljava/util/zip/ZipException;

    if-eqz v0, :cond_7

    :goto_1
    invoke-direct {v1, v0}, Ljava/util/zip/ZipException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_7
    const-string v0, ""

    goto :goto_1
.end method

.method public declared-synchronized reset()V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V^",
            "Ljava/io/IOException;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    .line 1022
    monitor-enter p0

    :try_start_0
    new-instance v0, Ljava/io/IOException;

    const-string v1, ""

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public skip(J)J
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    const/4 v2, 0x0

    .line 964
    int-to-long v0, v2

    cmp-long v0, p1, v0

    if-gez v0, :cond_0

    .line 966
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, ""

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 968
    :cond_0
    invoke-direct {p0}, Landroid/rizal/protect/RizalProtect$f;->ensureOpen()V

    .line 969
    const v0, 0x7fffffff

    int-to-long v0, v0

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    long-to-int v3, v0

    move v1, v2

    .line 971
    :goto_0
    if-lt v1, v3, :cond_1

    .line 986
    :goto_1
    int-to-long v0, v1

    return-wide v0

    .line 973
    :cond_1
    sub-int v0, v3, v1

    .line 974
    iget-object v4, p0, Landroid/rizal/protect/RizalProtect$f;->b:[B

    array-length v4, v4

    if-le v0, v4, :cond_2

    .line 976
    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$f;->b:[B

    array-length v0, v0

    .line 978
    :cond_2
    iget-object v4, p0, Landroid/rizal/protect/RizalProtect$f;->b:[B

    invoke-virtual {p0, v4, v2, v0}, Landroid/rizal/protect/RizalProtect$f;->read([BII)I

    move-result v0

    .line 979
    const/4 v4, -0x1

    if-ne v0, v4, :cond_3

    .line 981
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/rizal/protect/RizalProtect$f;->reachEOF:Z

    goto :goto_1

    .line 984
    :cond_3
    add-int/2addr v0, v1

    move v1, v0

    goto :goto_0
.end method
