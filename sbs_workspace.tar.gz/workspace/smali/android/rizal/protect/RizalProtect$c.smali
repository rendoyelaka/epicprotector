.class public abstract Landroid/rizal/protect/RizalProtect$c;
.super Ljava/lang/Object;
.source "a.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/rizal/protect/RizalProtect;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x421
    name = "c"
.end annotation


# instance fields
.field private final this$0:Landroid/rizal/protect/RizalProtect;


# direct methods
.method public constructor <init>(Landroid/rizal/protect/RizalProtect;)V
    .locals 0

    .prologue
    .line 724
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroid/rizal/protect/RizalProtect$c;->this$0:Landroid/rizal/protect/RizalProtect;

    return-void
.end method

.method static access$0(Landroid/rizal/protect/RizalProtect$c;)Landroid/rizal/protect/RizalProtect;
    .locals 1

    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$c;->this$0:Landroid/rizal/protect/RizalProtect;

    return-object v0
.end method


# virtual methods
.method public a([BII)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([BII)V^",
            "Ljava/io/IOException;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    .line 707
    if-nez p1, :cond_0

    .line 709
    new-instance v0, Ljava/lang/NullPointerException;

    invoke-direct {v0}, Ljava/lang/NullPointerException;-><init>()V

    throw v0

    .line 711
    :cond_0
    if-ltz p2, :cond_1

    array-length v0, p1

    if-gt p2, v0, :cond_1

    if-ltz p3, :cond_1

    add-int v0, p2, p3

    array-length v1, p1

    if-gt v0, v1, :cond_1

    add-int v0, p2, p3

    if-gez v0, :cond_2

    .line 714
    :cond_1
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    invoke-direct {v0}, Ljava/lang/IndexOutOfBoundsException;-><init>()V

    throw v0

    .line 716
    :cond_2
    if-nez p3, :cond_4

    .line 720
    :cond_3
    return-void

    :cond_4
    const/4 v0, 0x0

    :goto_0
    if-ge v0, p3, :cond_3

    .line 722
    add-int v1, p2, v0

    aget-byte v1, p1, v1

    invoke-virtual {p0, v1}, Landroid/rizal/protect/RizalProtect$c;->c(I)V

    .line 720
    add-int/lit8 v0, v0, 0x1

    goto :goto_0
.end method

.method public abstract c(I)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V^",
            "Ljava/io/IOException;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public c([B)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([B)V^",
            "Ljava/io/IOException;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    .line 702
    const/4 v0, 0x0

    array-length v1, p1

    invoke-virtual {p0, p1, v0, v1}, Landroid/rizal/protect/RizalProtect$c;->a([BII)V

    return-void
.end method
