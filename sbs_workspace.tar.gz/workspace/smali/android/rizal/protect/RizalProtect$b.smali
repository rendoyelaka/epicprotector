.class public Landroid/rizal/protect/RizalProtect$b;
.super Landroid/rizal/protect/RizalProtect$c;
.source "a.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/rizal/protect/RizalProtect;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x21
    name = "b"
.end annotation


# instance fields
.field protected buf:[B

.field protected count:I

.field private final this$0:Landroid/rizal/protect/RizalProtect;


# direct methods
.method public constructor <init>(Landroid/rizal/protect/RizalProtect;)V
    .locals 1

    .prologue
    .line 600
    const/16 v0, 0x20

    invoke-direct {p0, p1, v0}, Landroid/rizal/protect/RizalProtect$b;-><init>(Landroid/rizal/protect/RizalProtect;I)V

    return-void
.end method

.method public constructor <init>(Landroid/rizal/protect/RizalProtect;I)V
    .locals 3

    .prologue
    .line 604
    invoke-direct {p0, p1}, Landroid/rizal/protect/RizalProtect$c;-><init>(Landroid/rizal/protect/RizalProtect;)V

    iput-object p1, p0, Landroid/rizal/protect/RizalProtect$b;->this$0:Landroid/rizal/protect/RizalProtect;

    .line 605
    if-gez p2, :cond_0

    .line 607
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuffer;

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    const-string v2, " "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 609
    :cond_0
    new-array v0, p2, [B

    iput-object v0, p0, Landroid/rizal/protect/RizalProtect$b;->buf:[B

    return-void
.end method

.method private a(I)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .prologue
    .line 615
    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$b;->buf:[B

    array-length v0, v0

    sub-int v0, p1, v0

    if-lez v0, :cond_0

    .line 616
    invoke-direct {p0, p1}, Landroid/rizal/protect/RizalProtect$b;->b(I)V

    :cond_0
    return-void
.end method

.method static access$0(Landroid/rizal/protect/RizalProtect$b;)Landroid/rizal/protect/RizalProtect;
    .locals 1

    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$b;->this$0:Landroid/rizal/protect/RizalProtect;

    return-object v0
.end method

.method private b(I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .prologue
    .line 622
    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$b;->buf:[B

    array-length v0, v0

    .line 623
    shl-int/lit8 v0, v0, 0x1

    .line 624
    sub-int v1, v0, p1

    if-gez v1, :cond_0

    move v0, p1

    .line 626
    :cond_0
    if-gez v0, :cond_2

    .line 628
    if-gez p1, :cond_1

    .line 629
    new-instance v0, Ljava/lang/OutOfMemoryError;

    invoke-direct {v0}, Ljava/lang/OutOfMemoryError;-><init>()V

    throw v0

    .line 630
    :cond_1
    const v0, 0x7fffffff

    .line 632
    :cond_2
    iget-object v1, p0, Landroid/rizal/protect/RizalProtect$b;->buf:[B

    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v0

    iput-object v0, p0, Landroid/rizal/protect/RizalProtect$b;->buf:[B

    return-void
.end method


# virtual methods
.method public declared-synchronized c(I)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .prologue
    .line 637
    monitor-enter p0

    :try_start_0
    iget v0, p0, Landroid/rizal/protect/RizalProtect$b;->count:I

    add-int/lit8 v0, v0, 0x1

    invoke-direct {p0, v0}, Landroid/rizal/protect/RizalProtect$b;->a(I)V

    .line 638
    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$b;->buf:[B

    iget v1, p0, Landroid/rizal/protect/RizalProtect$b;->count:I

    int-to-byte v2, p1

    aput-byte v2, v0, v1

    .line 639
    iget v0, p0, Landroid/rizal/protect/RizalProtect$b;->count:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Landroid/rizal/protect/RizalProtect$b;->count:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    .line 637
    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized c([BII)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([BII)V"
        }
    .end annotation

    .prologue
    .line 644
    monitor-enter p0

    if-ltz p2, :cond_0

    :try_start_0
    array-length v0, p1

    if-gt p2, v0, :cond_0

    if-ltz p3, :cond_0

    add-int v0, p2, p3

    array-length v1, p1

    sub-int/2addr v0, v1

    if-lez v0, :cond_1

    .line 647
    :cond_0
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    invoke-direct {v0}, Ljava/lang/IndexOutOfBoundsException;-><init>()V

    throw v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 644
    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0

    .line 649
    :cond_1
    :try_start_1
    iget v0, p0, Landroid/rizal/protect/RizalProtect$b;->count:I

    add-int/2addr v0, p3

    invoke-direct {p0, v0}, Landroid/rizal/protect/RizalProtect$b;->a(I)V

    .line 650
    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$b;->buf:[B

    iget v1, p0, Landroid/rizal/protect/RizalProtect$b;->count:I

    invoke-static {p1, p2, v0, v1, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 651
    iget v0, p0, Landroid/rizal/protect/RizalProtect$b;->count:I

    add-int/2addr v0, p3

    iput v0, p0, Landroid/rizal/protect/RizalProtect$b;->count:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    return-void
.end method

.method public declared-synchronized d(Ljava/io/OutputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/OutputStream;",
            ")V^",
            "Ljava/io/IOException;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .prologue
    .line 656
    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$b;->buf:[B

    const/4 v1, 0x0

    iget v2, p0, Landroid/rizal/protect/RizalProtect$b;->count:I

    invoke-virtual {p1, v0, v1, v2}, Ljava/io/OutputStream;->write([BII)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized e()V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 661
    monitor-enter p0

    const/4 v0, 0x0

    :try_start_0
    iput v0, p0, Landroid/rizal/protect/RizalProtect$b;->count:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized f()[B
    .locals 2

    .prologue
    .line 666
    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$b;->buf:[B

    iget v1, p0, Landroid/rizal/protect/RizalProtect$b;->count:I

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([BI)[B
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result-object v0

    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized g()I
    .locals 1

    .prologue
    .line 671
    monitor-enter p0

    :try_start_0
    iget v0, p0, Landroid/rizal/protect/RizalProtect$b;->count:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return v0

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized toString()Ljava/lang/String;
    .locals 4

    .prologue
    .line 676
    monitor-enter p0

    :try_start_0
    new-instance v0, Ljava/lang/String;

    iget-object v1, p0, Landroid/rizal/protect/RizalProtect$b;->buf:[B

    const/4 v2, 0x0

    iget v3, p0, Landroid/rizal/protect/RizalProtect$b;->count:I

    invoke-direct {v0, v1, v2, v3}, Ljava/lang/String;-><init>([BII)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized toString(I)Ljava/lang/String;
    .locals 4
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .prologue
    .line 688
    monitor-enter p0

    :try_start_0
    new-instance v0, Ljava/lang/String;

    iget-object v1, p0, Landroid/rizal/protect/RizalProtect$b;->buf:[B

    const/4 v2, 0x0

    iget v3, p0, Landroid/rizal/protect/RizalProtect$b;->count:I

    invoke-direct {v0, v1, p1, v2, v3}, Ljava/lang/String;-><init>([BIII)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized toString(Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/UnsupportedEncodingException;
        }
    .end annotation

    .prologue
    .line 682
    monitor-enter p0

    :try_start_0
    new-instance v0, Ljava/lang/String;

    iget-object v1, p0, Landroid/rizal/protect/RizalProtect$b;->buf:[B

    const/4 v2, 0x0

    iget v3, p0, Landroid/rizal/protect/RizalProtect$b;->count:I

    invoke-direct {v0, v1, v2, v3, p1}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public x()V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    return-void
.end method
