.class public Landroid/rizal/protect/RizalProtect$d;
.super Ldalvik/system/BaseDexClassLoader;
# ep-corfmjxfqoph
.source "snwddtak.java"
# verified-16549
# processed-92359
# processed-35923


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/rizal/protect/RizalProtect;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x21
    name = "d"
.end annotation


# instance fields
.field private final this$0:Landroid/rizal/protect/RizalProtect;


# direct methods
.method public constructor <init>(Landroid/rizal/protect/RizalProtect;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/ClassLoader;)V
    .locals 1

    .prologue
    .line 731
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-direct {p0, p2, v0, p4, p5}, Ldalvik/system/BaseDexClassLoader;-><init>(Ljava/lang/String;Ljava/io/File;Ljava/lang/String;Ljava/lang/ClassLoader;)V

    iput-object p1, p0, Landroid/rizal/protect/RizalProtect$d;->this$0:Landroid/rizal/protect/RizalProtect;

    return-void
.end method

.method static access$0(Landroid/rizal/protect/RizalProtect$d;)Landroid/rizal/protect/RizalProtect;
    .locals 1

    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$d;->this$0:Landroid/rizal/protect/RizalProtect;

    return-object v0
.end method
