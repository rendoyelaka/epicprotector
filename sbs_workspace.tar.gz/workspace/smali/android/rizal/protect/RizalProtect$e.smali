.class public Landroid/rizal/protect/RizalProtect$e;
# ep-hgvvjrnrzgoo
.super Ljava/lang/Object;
.source "zoftcome.java"

# compiled-29755
# compiled-96634
# interfaces
.implements Ljava/security/spec/KeySpec;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/rizal/protect/RizalProtect;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x21
    name = "e"
.end annotation


# static fields
.field public static final DES_KEY_LEN:I = 0x8

.field private static final WEAK_KEYS:[[B


# instance fields
.field private key:[B

.field private final this$0:Landroid/rizal/protect/RizalProtect;


# direct methods
.method static final constructor <clinit>()V
    .locals 4

    const/16 v3, 0x8

    const/16 v0, 0x10

    new-array v0, v0, [[B

    const/4 v1, 0x0

    new-array v2, v3, [B

    fill-array-data v2, :array_0

    aput-object v2, v0, v1

    const/4 v1, 0x1

    new-array v2, v3, [B

    fill-array-data v2, :array_1

    aput-object v2, v0, v1

    const/4 v1, 0x2

    new-array v2, v3, [B

    fill-array-data v2, :array_2

    aput-object v2, v0, v1

    const/4 v1, 0x3

    new-array v2, v3, [B

    fill-array-data v2, :array_3

    aput-object v2, v0, v1

    const/4 v1, 0x4

    new-array v2, v3, [B

    fill-array-data v2, :array_4

    aput-object v2, v0, v1

    const/4 v1, 0x5

    new-array v2, v3, [B

    fill-array-data v2, :array_5

    aput-object v2, v0, v1

    const/4 v1, 0x6

    new-array v2, v3, [B

    fill-array-data v2, :array_6

    aput-object v2, v0, v1

    const/4 v1, 0x7

    new-array v2, v3, [B

    fill-array-data v2, :array_7

    aput-object v2, v0, v1

    new-array v1, v3, [B

    fill-array-data v1, :array_8

    aput-object v1, v0, v3

    const/16 v1, 0x9

    new-array v2, v3, [B

    fill-array-data v2, :array_9

    aput-object v2, v0, v1

    const/16 v1, 0xa

    new-array v2, v3, [B

    fill-array-data v2, :array_a

    aput-object v2, v0, v1

    const/16 v1, 0xb

    new-array v2, v3, [B

    fill-array-data v2, :array_b

    aput-object v2, v0, v1

    const/16 v1, 0xc

    new-array v2, v3, [B

    fill-array-data v2, :array_c

    aput-object v2, v0, v1

    const/16 v1, 0xd

    new-array v2, v3, [B

    fill-array-data v2, :array_d

    aput-object v2, v0, v1

    const/16 v1, 0xe

    new-array v2, v3, [B

    fill-array-data v2, :array_e

    aput-object v2, v0, v1

    const/16 v1, 0xf

    new-array v2, v3, [B

    fill-array-data v2, :array_f

    aput-object v2, v0, v1

    sput-object v0, Landroid/rizal/protect/RizalProtect$e;->WEAK_KEYS:[[B

    return-void

    nop

    :array_0
    .array-data 1
        0x1t
        0x1t
        0x1t
        0x1t
        0x1t
        0x1t
        0x1t
        0x1t
    .end array-data

    :array_1
    .array-data 1
        -0x2t
        -0x2t
        -0x2t
        -0x2t
        -0x2t
        -0x2t
        -0x2t
        -0x2t
    .end array-data

    :array_2
    .array-data 1
        0x1ft
        0x1ft
        0x1ft
        0x1ft
        0xet
        0xet
        0xet
        0xet
    .end array-data

    :array_3
    .array-data 1
        -0x20t
        -0x20t
        -0x20t
        -0x20t
        -0xft
        -0xft
        -0xft
        -0xft
    .end array-data

    :array_4
    .array-data 1
        0x1t
        -0x2t
        0x1t
        -0x2t
        0x1t
        -0x2t
        0x1t
        -0x2t
    .end array-data

    :array_5
    .array-data 1
        0x1ft
        -0x20t
        0x1ft
        -0x20t
        0xet
        -0xft
        0xet
        -0xft
    .end array-data

    :array_6
    .array-data 1
        0x1t
        -0x20t
        0x1t
        -0x20t
        0x1t
        -0xft
        0x1t
        -0xft
    .end array-data

    :array_7
    .array-data 1
        0x1ft
        -0x2t
        0x1ft
        -0x2t
        0xet
        -0x2t
        0xet
        -0x2t
    .end array-data

    :array_8
    .array-data 1
        0x1t
        0x1ft
        0x1t
        0x1ft
        0x1t
        0xet
        0x1t
        0xet
    .end array-data

    :array_9
    .array-data 1
        -0x20t
        -0x2t
        -0x20t
        -0x2t
        -0xft
        -0x2t
        -0xft
        -0x2t
    .end array-data

    :array_a
    .array-data 1
        -0x2t
        0x1t
        -0x2t
        0x1t
        -0x2t
        0x1t
        -0x2t
        0x1t
    .end array-data

    :array_b
    .array-data 1
        -0x20t
        0x1ft
        -0x20t
        0x1ft
        -0xft
        0xet
        -0xft
        0xet
    .end array-data

    :array_c
    .array-data 1
        -0x20t
        0x1t
        -0x20t
        0x1t
        -0xft
        0x1t
        -0xft
        0x1t
    .end array-data

    :array_d
    .array-data 1
        -0x2t
        0x1ft
        -0x2t
        0x1ft
        -0x2t
        0xet
        -0x2t
        0xet
    .end array-data

    :array_e
    .array-data 1
        0x1ft
        0x1t
        0x1ft
        0x1t
        0xet
        0x1t
        0xet
        0x1t
    .end array-data

    :array_f
    .array-data 1
        -0x2t
        -0x20t
        -0x2t
        -0x20t
        -0x2t
        -0xft
        -0x2t
        -0xft
    .end array-data
.end method

.method public constructor <init>(Landroid/rizal/protect/RizalProtect;[B)V
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/security/InvalidKeyException;
        }
    .end annotation

    .prologue
    .line 776
    const/4 v0, 0x0

    invoke-direct {p0, p1, p2, v0}, Landroid/rizal/protect/RizalProtect$e;-><init>(Landroid/rizal/protect/RizalProtect;[BI)V

    return-void
.end method

.method public constructor <init>(Landroid/rizal/protect/RizalProtect;[BI)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/security/InvalidKeyException;
        }
    .end annotation

    .prologue
    const/16 v2, 0x8

    .line 780
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroid/rizal/protect/RizalProtect$e;->this$0:Landroid/rizal/protect/RizalProtect;

    .line 781
    array-length v0, p2

    sub-int/2addr v0, p3

    if-ge v0, v2, :cond_0

    .line 783
    new-instance v0, Ljava/security/InvalidKeyException;

    const-string v1, ""

    invoke-direct {v0, v1}, Ljava/security/InvalidKeyException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 785
    :cond_0
    new-array v0, v2, [B

    iput-object v0, p0, Landroid/rizal/protect/RizalProtect$e;->key:[B

    .line 786
    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$e;->key:[B

    const/4 v1, 0x0

    invoke-static {p2, p3, v0, v1, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-void
.end method

.method static access$0(Landroid/rizal/protect/RizalProtect$e;)Landroid/rizal/protect/RizalProtect;
    .locals 1

    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$e;->this$0:Landroid/rizal/protect/RizalProtect;

    return-object v0
.end method


# virtual methods
.method public getKey()[B
    .locals 1

    .prologue
    .line 791
    iget-object v0, p0, Landroid/rizal/protect/RizalProtect$e;->key:[B

    invoke-virtual {v0}, [B->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [B

    return-object v0
.end method

.method public isParityAdjusted([BI)Z
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/security/InvalidKeyException;
        }
    .end annotation

    .prologue
    const/16 v4, 0x8

    const/4 v0, 0x0

    .line 797
    if-nez p1, :cond_0

    .line 799
    new-instance v0, Ljava/security/InvalidKeyException;

    const-string v1, ""

    invoke-direct {v0, v1}, Ljava/security/InvalidKeyException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 801
    :cond_0
    array-length v1, p1

    sub-int/2addr v1, p2

    if-ge v1, v4, :cond_1

    .line 803
    new-instance v0, Ljava/security/InvalidKeyException;

    const-string v1, ""

    invoke-direct {v0, v1}, Ljava/security/InvalidKeyException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    move v1, v0

    .line 807
    :goto_0
    if-lt v1, v4, :cond_3

    .line 817
    const/4 v0, 0x1

    :cond_2
    return v0

    .line 809
    :cond_3
    add-int/lit8 v2, p2, 0x1

    aget-byte v3, p1, p2

    and-int/lit16 v3, v3, 0xff

    invoke-static {v3}, Ljava/lang/Integer;->bitCount(I)I

    move-result v3

    .line 810
    and-int/lit8 v3, v3, 0x1

    if-eqz v3, :cond_2

    .line 807
    add-int/lit8 v1, v1, 0x1

    move p2, v2

    goto :goto_0
.end method

.method public isWeak([BI)Z
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/security/InvalidKeyException;
        }
    .end annotation

    .prologue
    const/16 v6, 0x8

    const/4 v1, 0x0

    .line 823
    if-nez p1, :cond_0

    .line 825
    new-instance v0, Ljava/security/InvalidKeyException;

    const-string v1, ""

    invoke-direct {v0, v1}, Ljava/security/InvalidKeyException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 827
    :cond_0
    array-length v0, p1

    sub-int/2addr v0, p2

    if-ge v0, v6, :cond_1

    .line 829
    new-instance v0, Ljava/security/InvalidKeyException;

    const-string v1, ""

    invoke-direct {v0, v1}, Ljava/security/InvalidKeyException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    move v0, v1

    .line 831
    :goto_0
    sget-object v2, Landroid/rizal/protect/RizalProtect$e;->WEAK_KEYS:[[B

    array-length v2, v2

    if-lt v0, v2, :cond_3

    move v2, v1

    .line 846
    :cond_2
    return v2

    .line 833
    :cond_3
    const/4 v2, 0x1

    move v3, v1

    .line 834
    :goto_1
    if-ge v3, v6, :cond_4

    if-nez v2, :cond_5

    .line 841
    :cond_4
    if-nez v2, :cond_2

    .line 831
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 836
    :cond_5
    sget-object v4, Landroid/rizal/protect/RizalProtect$e;->WEAK_KEYS:[[B

    aget-object v4, v4, v0

    aget-byte v4, v4, v3

    add-int v5, v3, p2

    aget-byte v5, p1, v5

    if-eq v4, v5, :cond_6

    move v2, v1

    .line 834
    :cond_6
    add-int/lit8 v3, v3, 0x1

    goto :goto_1
.end method
