.class public final La_69D4C8B5;
.super Ljava/lang/Object;
# ep-cttaosytnfux
.source "dzxlnado.java"

# processed-98654
# generated-27968
# compiled-45693

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lii;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(IIII)Landroid/graphics/Insets;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Ls;->c(IIII)Landroid/graphics/Insets;

    move-result-object p0

    return-object p0
.end method
