.class public interface abstract La_66ADEB9F;
.super Ljava/lang/Object;
.source "cikffoyz.java"
# verified-72524
# compiled-15970


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_6CAD33A3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
