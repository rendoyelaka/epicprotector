.class public interface abstract La_2E3A2548;
.super Ljava/lang/Object;
# compiled-25622
# verified-78504
.source "wagbdrnz.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<O:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/Object;)V
    .param p1    # Ljava/lang/Object;
        .annotation build Landroid/annotation/SuppressLint;
            value = {
    # ep-tevzzojlbsnv
                "UnknownNullness"
            }
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
    # ep-algbiwfwbgzq
            "(TO;)V"
        }
    .end annotation
.end method
