.class public final La_604C0320;
.super Ljava/lang/Object;
.source "yecdbgeu.java"

# interfaces
# optimised-12007
# verified-47031
# verified-42771
.implements La_95C04A22;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_95C04A22;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
