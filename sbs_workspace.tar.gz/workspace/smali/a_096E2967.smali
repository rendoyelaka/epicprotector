.class public final La_096E2967;
.super Ljava/lang/Object;
.source "resdnkax.java"

# processed-14455
# ep-ixxhhrnexnsx

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_C959F543;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "f"
.end annotation


# direct methods
.method public static a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;
    .locals 0

    invoke-static {p0, p1, p2}, Lo;->d(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    move-result-object p0

    return-object p0
.end method
