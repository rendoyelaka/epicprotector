.class public final La_8F261D06;
.super Landroid/util/Property;
.source "hqvqdjpb.java"
# validated-68946


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_03F37A42;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/util/Property<",
        "La_03F37A42;",
        "La_67929821;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:La_8F261D06;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_8F261D06;

    invoke-direct {v0}, La_8F261D06;-><init>()V

    sput-object v0, La_8F261D06;->a:La_8F261D06;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    const-string v0, "circularReveal"

    .line 3
    const-class v1, La_67929821;

    .line 5
    invoke-direct {p0, v1, v0}, Landroid/util/Property;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    .line 8
    return-void
.end method


# virtual methods
.method public final get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    # ep-baihpgbjowkp
    .line 1
    # ep-huopngezfcjx
    check-cast p1, La_03F37A42;

    .line 3
    invoke-interface {p1}, La_03F37A42;->m_3f759cd3()La_67929821;

    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method

.method public final set(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p1, La_03F37A42;

    .line 3
    # ep-cmpposgnlfma
    check-cast p2, La_67929821;
    # ep-mlxcccmktxgz

    .line 5
    invoke-interface {p1, p2}, La_03F37A42;->m_2c79bfdd(La_67929821;)V

    # ep-eqfllhukxxvy
    .line 8
    return-void
.end method
