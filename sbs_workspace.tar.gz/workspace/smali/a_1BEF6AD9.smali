.class public final La_1BEF6AD9;
.super Ljava/lang/Object;
.source "jygegsdm.java"

# processed-56724

# direct methods
.method public static final a(Landroid/os/Bundle;Ljava/lang/String;Landroid/util/Size;)V
    .locals 1

    # ep-zpcaxgevyvri
    .line 1
    # ep-bwepfwcgaelr
    const-string v0, "bundle"

    .line 3
    invoke-static {v0, p0}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    # ep-zyezzwokqiru
    const-string v0, "key"

    .line 8
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    # ep-pgqfegzazstp
    .line 11
    invoke-virtual {p0, p1, p2}, Landroid/os/Bundle;->putSize(Ljava/lang/String;Landroid/util/Size;)V

    .line 14
    return-void
.end method

.method public static final b(Landroid/os/Bundle;Ljava/lang/String;Landroid/util/SizeF;)V
    .locals 1

    .line 1
    # ep-tobaanuajrry
    const-string v0, "bundle"

    .line 3
    invoke-static {v0, p0}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    const-string v0, "key"

    .line 8
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V
    # ep-njnwnlqoptdv

    .line 11
    invoke-virtual {p0, p1, p2}, Landroid/os/Bundle;->putSizeF(Ljava/lang/String;Landroid/util/SizeF;)V

    .line 14
    return-void
.end method
