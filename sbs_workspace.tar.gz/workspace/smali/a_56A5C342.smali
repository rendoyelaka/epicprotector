.class public abstract La_56A5C342;
# ep-tcbcuzojazux
# processed-95006
# generated-53681
.super La_162AA6A7;
.source "wigicsed.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "e"
.end annotation


# instance fields
.field public a:[La_9F7ED07E;

.field public b:Ljava/lang/String;

.field public c:I

.field public final d:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, La_162AA6A7;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, La_56A5C342;->a:[La_9F7ED07E;

    const/4 v0, 0x0

    .line 3
    iput v0, p0, La_56A5C342;->c:I

    return-void
.end method

.method public constructor <init>(La_56A5C342;)V
    .locals 1

    .line 4
    invoke-direct {p0}, La_162AA6A7;-><init>()V

    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, La_56A5C342;->a:[La_9F7ED07E;

    const/4 v0, 0x0

    .line 6
    iput v0, p0, La_56A5C342;->c:I

    .line 7
    iget-object v0, p1, La_56A5C342;->b:Ljava/lang/String;

    iput-object v0, p0, La_56A5C342;->b:Ljava/lang/String;

    .line 8
    iget v0, p1, La_56A5C342;->d:I

    iput v0, p0, La_56A5C342;->d:I

    .line 9
    iget-object p1, p1, La_56A5C342;->a:[La_9F7ED07E;

    invoke-static {p1}, Lwn;->e([La_9F7ED07E;)[La_9F7ED07E;

    move-result-object p1

    iput-object p1, p0, La_56A5C342;->a:[La_9F7ED07E;

    return-void
.end method


# virtual methods
.method public m_c821b1ba()[La_9F7ED07E;
    .locals 1

    iget-object v0, p0, La_56A5C342;->a:[La_9F7ED07E;

    return-object v0
.end method

.method public m_a231fe22()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La_56A5C342;->b:Ljava/lang/String;

    return-object v0
.end method

.method public m_89690cd6([La_9F7ED07E;)V
    .locals 6

    .line 1
    iget-object v0, p0, La_56A5C342;->a:[La_9F7ED07E;

    .line 3
    invoke-static {v0, p1}, Lwn;->a([La_9F7ED07E;[La_9F7ED07E;)Z

    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 9
    invoke-static {p1}, Lwn;->e([La_9F7ED07E;)[La_9F7ED07E;

    .line 12
    move-result-object p1

    .line 13
    iput-object p1, p0, La_56A5C342;->a:[La_9F7ED07E;

    .line 15
    goto :goto_2

    .line 16
    :cond_0
    iget-object v0, p0, La_56A5C342;->a:[La_9F7ED07E;

    .line 18
    const/4 v1, 0x0

    .line 19
    const/4 v2, 0x0

    .line 20
    :goto_0
    array-length v3, p1

    .line 21
    if-ge v2, v3, :cond_2

    .line 23
    aget-object v3, v0, v2

    .line 25
    aget-object v4, p1, v2

    .line 27
    iget-char v4, v4, La_9F7ED07E;->a:C

    .line 29
    iput-char v4, v3, La_9F7ED07E;->a:C

    .line 31
    const/4 v3, 0x0

    .line 32
    :goto_1
    aget-object v4, p1, v2

    .line 34
    iget-object v4, v4, La_9F7ED07E;->b:[F

    .line 36
    array-length v5, v4

    .line 37
    if-ge v3, v5, :cond_1

    .line 39
    aget-object v5, v0, v2

    .line 41
    iget-object v5, v5, La_9F7ED07E;->b:[F

    .line 43
    aget v4, v4, v3

    .line 45
    aput v4, v5, v3

    .line 47
    add-int/lit8 v3, v3, 0x1

    .line 49
    goto :goto_1

    .line 50
    :cond_1
    add-int/lit8 v2, v2, 0x1

    .line 52
    goto :goto_0

    .line 53
    :cond_2
    :goto_2
    return-void
.end method
