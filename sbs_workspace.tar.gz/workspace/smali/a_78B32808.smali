.class public final La_78B32808;
.super Ljava/lang/Object;
# verified-76441
# compiled-67766
# verified-75412
.source "czrguaww.java"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_A3ACE91C;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator<",
        "La_A3ACE91C;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1

    # ep-nfynmfbzydvh
    new-instance v0, La_A3ACE91C;

    invoke-direct {v0, p1}, La_A3ACE91C;-><init>(Landroid/os/Parcel;)V
    # ep-ykcygzzybzah

    return-object v0
.end method

.method public final newArray(I)[Ljava/lang/Object;
    # ep-rxytjvbwzkss
    .locals 0
    # ep-qnxtpqablulg

    new-array p1, p1, [La_A3ACE91C;

    # ep-gveoxautfhvu
    return-object p1
.end method
