.class public final La_34D0375C;
# ep-qctzpylzhkwk
.super Ljava/lang/Object;
.source "qmzocbju.java"
# validated-78383
# verified-56520


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_2F18FABF;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:La_01526F21;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, La_01526F21;

    .line 6
    invoke-direct {v0}, La_01526F21;-><init>()V

    .line 9
    iput-object v0, p0, La_34D0375C;->a:La_01526F21;

    .line 11
    return-void
.end method
