.class public final LWorkTimer;
.super Ljava/lang/Object;
.source "ivhmpqgl.java"
# verified-16350
# validated-25575

# ep-rspotgptgpme

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LWorkTimer$b;,
        LWorkTimer$c;
    }
.end annotation


# instance fields
.field public final a:Ljava/util/concurrent/ScheduledExecutorService;

.field public final b:Ljava/util/HashMap;

.field public final c:Ljava/util/HashMap;

.field public final d:Ljava/lang/Object;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "WorkTimer"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, LWorkTimer$a;

    .line 6
    invoke-direct {v0}, LWorkTimer$a;-><init>()V

    .line 9
    new-instance v1, Ljava/util/HashMap;

    .line 11
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 14
    iput-object v1, p0, LWorkTimer;->b:Ljava/util/HashMap;

    .line 16
    new-instance v1, Ljava/util/HashMap;

    .line 18
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 21
    iput-object v1, p0, LWorkTimer;->c:Ljava/util/HashMap;

    .line 23
    new-instance v1, Ljava/lang/Object;

    .line 25
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 28
    iput-object v1, p0, LWorkTimer;->d:Ljava/lang/Object;

    .line 30
    invoke-static {v0}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ScheduledExecutorService;

    .line 33
    move-result-object v0

    .line 34
    iput-object v0, p0, LWorkTimer;->a:Ljava/util/concurrent/ScheduledExecutorService;

    .line 36
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;LWorkTimer$b;)V
    .locals 5

    .line 1
    iget-object v0, p0, LWorkTimer;->d:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    invoke-static {}, Ltj;->c()Ltj;

    .line 7
    move-result-object v1

    .line 8
    const-string v2, "m5LsV7Gw81M1cTnU/od4T5IlH6dg"
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 10
    const/4 v3, 0x1

    .line 11
    new-array v3, v3, [Ljava/lang/Object;

    .line 13
    const/4 v4, 0x0

    .line 14
    aput-object p1, v3, v4

    .line 16
    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 19
    new-array v2, v4, [Ljava/lang/Throwable;

    .line 21
    invoke-virtual {v1, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 24
    invoke-virtual {p0, p1}, LWorkTimer;->b(Ljava/lang/String;)V

    .line 27
    new-instance v1, LWorkTimer$c;

    .line 29
    invoke-direct {v1, p0, p1}, LWorkTimer$c;-><init>(LWorkTimer;Ljava/lang/String;)V

    .line 32
    iget-object v2, p0, LWorkTimer;->b:Ljava/util/HashMap;

    .line 34
    invoke-virtual {v2, p1, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    iget-object v2, p0, LWorkTimer;->c:Ljava/util/HashMap;

    .line 39
    invoke-virtual {v2, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    iget-object p1, p0, LWorkTimer;->a:Ljava/util/concurrent/ScheduledExecutorService;

    .line 44
    sget-object p2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 46
    const-wide/32 v2, 0x927c0

    .line 49
    invoke-interface {p1, v1, v2, v3, p2}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    .line 52
    monitor-exit v0

    .line 53
    return-void

    .line 54
    :catchall_0
    move-exception p1

    .line 55
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 56
    throw p1
.end method

.method public final b(Ljava/lang/String;)V
    .locals 5

    .line 1
    iget-object v0, p0, LWorkTimer;->d:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, LWorkTimer;->b:Ljava/util/HashMap;

    .line 6
    invoke-virtual {v1, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    move-result-object v1

    .line 10
    check-cast v1, LWorkTimer$c;

    .line 12
    if-eqz v1, :cond_0

    .line 14
    invoke-static {}, Ltj;->c()Ltj;

    .line 17
    move-result-object v1

    .line 18
    const-string v2, "m5LiVbWw81M1cTnU/od4T5IlH6dg"
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 20
    const/4 v3, 0x1

    .line 21
    new-array v3, v3, [Ljava/lang/Object;

    .line 23
    const/4 v4, 0x0

    .line 24
    aput-object p1, v3, v4

    .line 26
    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 29
    new-array v2, v4, [Ljava/lang/Throwable;

    .line 31
    invoke-virtual {v1, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 34
    iget-object v1, p0, LWorkTimer;->c:Ljava/util/HashMap;

    .line 36
    invoke-virtual {v1, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    :cond_0
    monitor-exit v0

    .line 40
    return-void

    .line 41
    :catchall_0
    move-exception p1

    .line 42
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 43
    throw p1
.end method
