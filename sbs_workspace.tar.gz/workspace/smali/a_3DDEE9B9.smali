.class public La_3DDEE9B9;
.super Landroid/graphics/drawable/Drawable;
.source "iojsnlfy.java"
# generated-14189
# compiled-20799
# ep-bsftnwfsauvi

# interfaces
.implements Liv;
.implements Lbs;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_A9E1BAE7;
    }
.end annotation


# static fields
.field public static final y:Landroid/graphics/Paint;


# instance fields
.field public c:La_A9E1BAE7;

.field public final d:[La_BA3BE4DC;

.field public final e:[La_BA3BE4DC;

.field public final f:Ljava/util/BitSet;

.field public g:Z

.field public final h:Landroid/graphics/Matrix;

.field public final i:Landroid/graphics/Path;

.field public final j:Landroid/graphics/Path;

.field public final k:Landroid/graphics/RectF;

.field public final l:Landroid/graphics/RectF;

.field public final m:Landroid/graphics/Region;

.field public final n:Landroid/graphics/Region;

.field public o:Lxr;

.field public final p:Landroid/graphics/Paint;

.field public final q:Landroid/graphics/Paint;

.field public final r:Lvr;

.field public final s:La_B7279982;

.field public final t:Lyr;

.field public u:Landroid/graphics/PorterDuffColorFilter;

.field public v:Landroid/graphics/PorterDuffColorFilter;

.field public final w:Landroid/graphics/RectF;

.field public x:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Landroid/graphics/Paint;

    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    .line 7
    sput-object v0, La_3DDEE9B9;->y:Landroid/graphics/Paint;

    .line 9
    const/4 v1, -0x1

    .line 10
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 13
    new-instance v1, Landroid/graphics/PorterDuffXfermode;

    .line 15
    sget-object v2, Landroid/graphics/PorterDuff$Mode;->DST_OUT:Landroid/graphics/PorterDuff$Mode;

    .line 17
    invoke-direct {v1, v2}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    .line 20
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    .line 23
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    new-instance v0, Lxr;

    invoke-direct {v0}, Lxr;-><init>()V

    invoke-direct {p0, v0}, La_3DDEE9B9;-><init>(Lxr;)V

    return-void
.end method

.method public constructor <init>(La_A9E1BAE7;)V
    .locals 5

    .line 4
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    const/4 v0, 0x4

    new-array v1, v0, [La_BA3BE4DC;

    .line 5
    iput-object v1, p0, La_3DDEE9B9;->d:[La_BA3BE4DC;

    new-array v0, v0, [La_BA3BE4DC;

    .line 6
    iput-object v0, p0, La_3DDEE9B9;->e:[La_BA3BE4DC;

    .line 7
    new-instance v0, Ljava/util/BitSet;

    const/16 v1, 0x8

    invoke-direct {v0, v1}, Ljava/util/BitSet;-><init>(I)V

    iput-object v0, p0, La_3DDEE9B9;->f:Ljava/util/BitSet;

    .line 8
    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La_3DDEE9B9;->h:Landroid/graphics/Matrix;

    .line 9
    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, La_3DDEE9B9;->i:Landroid/graphics/Path;

    .line 10
    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, La_3DDEE9B9;->j:Landroid/graphics/Path;

    .line 11
    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, La_3DDEE9B9;->k:Landroid/graphics/RectF;

    .line 12
    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, La_3DDEE9B9;->l:Landroid/graphics/RectF;

    .line 13
    new-instance v0, Landroid/graphics/Region;

    invoke-direct {v0}, Landroid/graphics/Region;-><init>()V

    iput-object v0, p0, La_3DDEE9B9;->m:Landroid/graphics/Region;

    .line 14
    new-instance v0, Landroid/graphics/Region;

    invoke-direct {v0}, Landroid/graphics/Region;-><init>()V

    iput-object v0, p0, La_3DDEE9B9;->n:Landroid/graphics/Region;

    .line 15
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, La_3DDEE9B9;->p:Landroid/graphics/Paint;

    .line 16
    new-instance v2, Landroid/graphics/Paint;

    invoke-direct {v2, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v2, p0, La_3DDEE9B9;->q:Landroid/graphics/Paint;

    .line 17
    new-instance v3, Lvr;

    invoke-direct {v3}, Lvr;-><init>()V

    iput-object v3, p0, La_3DDEE9B9;->r:Lvr;

    .line 18
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v3

    invoke-virtual {v3}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v3

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v4

    if-ne v3, v4, :cond_0

    .line 19
    sget-object v3, La_1BF89200;->a:Lyr;

    goto :goto_0

    .line 20
    :cond_0
    new-instance v3, Lyr;

    invoke-direct {v3}, Lyr;-><init>()V

    :goto_0
    iput-object v3, p0, La_3DDEE9B9;->t:Lyr;

    .line 21
    new-instance v3, Landroid/graphics/RectF;

    invoke-direct {v3}, Landroid/graphics/RectF;-><init>()V

    iput-object v3, p0, La_3DDEE9B9;->w:Landroid/graphics/RectF;

    .line 22
    iput-boolean v1, p0, La_3DDEE9B9;->x:Z

    .line 23
    iput-object p1, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 24
    sget-object p1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, p1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 25
    sget-object p1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 26
    invoke-virtual {p0}, La_3DDEE9B9;->q()Z

    .line 27
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->m_a4bf0ce9()[I

    move-result-object p1

    invoke-virtual {p0, p1}, La_3DDEE9B9;->p([I)Z

    .line 28
    new-instance p1, La_B7279982;

    invoke-direct {p1, p0}, La_B7279982;-><init>(La_3DDEE9B9;)V

    iput-object p1, p0, La_3DDEE9B9;->s:La_B7279982;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 0

    .line 2
    invoke-static {p1, p2, p3, p4}, Lxr;->b(Landroid/content/Context;Landroid/util/AttributeSet;II)La_FACD8686;

    move-result-object p1

    invoke-virtual {p1}, La_FACD8686;->a()Lxr;

    move-result-object p1

    invoke-direct {p0, p1}, La_3DDEE9B9;-><init>(Lxr;)V

    return-void
.end method

.method public constructor <init>(Lxr;)V
    .locals 1

    .line 3
    new-instance v0, La_A9E1BAE7;

    invoke-direct {v0, p1}, La_A9E1BAE7;-><init>(Lxr;)V

    invoke-direct {p0, v0}, La_3DDEE9B9;-><init>(La_A9E1BAE7;)V

    return-void
.end method


# virtual methods
.method public final b(Landroid/graphics/RectF;Landroid/graphics/Path;)V
    .locals 6

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->t:Lyr;

    .line 3
    iget-object v1, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 5
    iget-object v2, v1, La_A9E1BAE7;->a:Lxr;

    .line 7
    iget v3, v1, La_A9E1BAE7;->j:F

    .line 9
    iget-object v4, p0, La_3DDEE9B9;->s:La_B7279982;

    .line 11
    move-object v1, v2

    .line 12
    move v2, v3

    .line 13
    move-object v3, p1

    .line 14
    move-object v5, p2

    .line 15
    invoke-virtual/range {v0 .. v5}, Lyr;->a(Lxr;FLandroid/graphics/RectF;La_B7279982;Landroid/graphics/Path;)V

    .line 18
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 20
    iget v0, v0, La_A9E1BAE7;->i:F

    .line 22
    const/high16 v1, 0x3f800000    # 1.0f

    .line 24
    cmpl-float v0, v0, v1

    .line 26
    if-eqz v0, :cond_0

    .line 28
    iget-object v0, p0, La_3DDEE9B9;->h:Landroid/graphics/Matrix;

    .line 30
    invoke-virtual {v0}, Landroid/graphics/Matrix;->reset()V

    .line 33
    iget-object v1, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 35
    iget v1, v1, La_A9E1BAE7;->i:F

    .line 37
    invoke-virtual {p1}, Landroid/graphics/RectF;->width()F

    .line 40
    move-result v2

    .line 41
    const/high16 v3, 0x40000000    # 2.0f

    .line 43
    div-float/2addr v2, v3

    .line 44
    invoke-virtual {p1}, Landroid/graphics/RectF;->height()F

    .line 47
    move-result p1

    .line 48
    div-float/2addr p1, v3

    .line 49
    invoke-virtual {v0, v1, v1, v2, p1}, Landroid/graphics/Matrix;->setScale(FFFF)V

    .line 52
    invoke-virtual {p2, v0}, Landroid/graphics/Path;->transform(Landroid/graphics/Matrix;)V

    .line 55
    :cond_0
    iget-object p1, p0, La_3DDEE9B9;->w:Landroid/graphics/RectF;

    .line 57
    const/4 v0, 0x1

    .line 58
    invoke-virtual {p2, p1, v0}, Landroid/graphics/Path;->computeBounds(Landroid/graphics/RectF;Z)V

    .line 61
    return-void
.end method

.method public final c(Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;Landroid/graphics/Paint;Z)Landroid/graphics/PorterDuffColorFilter;
    .locals 1

    .line 1
    if-eqz p1, :cond_2

    .line 3
    if-nez p2, :cond_0

    .line 5
    goto :goto_0

    .line 6
    :cond_0
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->m_a4bf0ce9()[I

    .line 9
    move-result-object p3

    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-virtual {p1, p3, v0}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 14
    move-result p1

    .line 15
    if-eqz p4, :cond_1

    .line 17
    invoke-virtual {p0, p1}, La_3DDEE9B9;->d(I)I

    .line 20
    move-result p1

    .line 21
    :cond_1
    new-instance p3, Landroid/graphics/PorterDuffColorFilter;

    .line 23
    invoke-direct {p3, p1, p2}, Landroid/graphics/PorterDuffColorFilter;-><init>(ILandroid/graphics/PorterDuff$Mode;)V

    .line 26
    goto :goto_2

    .line 27
    :cond_2
    :goto_0
    if-eqz p4, :cond_3

    .line 29
    invoke-virtual {p3}, Landroid/graphics/Paint;->getColor()I

    .line 32
    move-result p1

    .line 33
    invoke-virtual {p0, p1}, La_3DDEE9B9;->d(I)I

    .line 36
    move-result p2

    .line 37
    if-eq p2, p1, :cond_3

    .line 39
    new-instance p1, Landroid/graphics/PorterDuffColorFilter;

    .line 41
    sget-object p3, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    .line 43
    invoke-direct {p1, p2, p3}, Landroid/graphics/PorterDuffColorFilter;-><init>(ILandroid/graphics/PorterDuff$Mode;)V

    .line 46
    goto :goto_1

    .line 47
    :cond_3
    const/4 p1, 0x0

    .line 48
    :goto_1
    move-object p3, p1

    .line 49
    :goto_2
    return-object p3
.end method

.method public final d(I)I
    .locals 3

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 3
    iget v1, v0, La_A9E1BAE7;->n:F

    .line 5
    iget v2, v0, La_A9E1BAE7;->o:F

    .line 7
    add-float/2addr v1, v2

    .line 8
    iget v2, v0, La_A9E1BAE7;->m:F

    .line 10
    add-float/2addr v1, v2

    .line 11
    iget-object v0, v0, La_A9E1BAE7;->b:Lkb;

    .line 13
    if-eqz v0, :cond_0

    .line 15
    invoke-virtual {v0, p1, v1}, Lkb;->a(IF)I

    .line 18
    move-result p1

    .line 19
    :cond_0
    return p1
.end method

.method public m_2acfcc5a(Landroid/graphics/Canvas;)V
    .locals 21

    .line 1
    move-object/from16 v6, p0

    .line 3
    move-object/from16 v7, p1

    .line 5
    iget-object v8, v6, La_3DDEE9B9;->p:Landroid/graphics/Paint;

    .line 7
    iget-object v0, v6, La_3DDEE9B9;->u:Landroid/graphics/PorterDuffColorFilter;

    .line 9
    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->m_c2bf9474(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    .line 12
    invoke-virtual {v8}, Landroid/graphics/Paint;->m_b536a652()I

    .line 15
    move-result v9

    .line 16
    iget-object v0, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 18
    iget v0, v0, La_A9E1BAE7;->l:I

    .line 20
    ushr-int/lit8 v1, v0, 0x7

    .line 22
    add-int/2addr v0, v1

    .line 23
    mul-int v0, v0, v9

    .line 25
    ushr-int/lit8 v0, v0, 0x8

    .line 27
    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->m_46dc9993(I)V

    .line 30
    iget-object v10, v6, La_3DDEE9B9;->q:Landroid/graphics/Paint;

    .line 32
    iget-object v0, v6, La_3DDEE9B9;->v:Landroid/graphics/PorterDuffColorFilter;

    .line 34
    invoke-virtual {v10, v0}, Landroid/graphics/Paint;->m_c2bf9474(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    .line 37
    iget-object v0, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 39
    iget v0, v0, La_A9E1BAE7;->k:F

    .line 41
    invoke-virtual {v10, v0}, Landroid/graphics/Paint;->m_274a07cc(F)V

    .line 44
    invoke-virtual {v10}, Landroid/graphics/Paint;->m_b536a652()I

    .line 47
    move-result v11

    .line 48
    iget-object v0, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 50
    iget v0, v0, La_A9E1BAE7;->l:I

    .line 52
    ushr-int/lit8 v1, v0, 0x7

    .line 54
    add-int/2addr v0, v1

    .line 55
    mul-int v0, v0, v11

    .line 57
    ushr-int/lit8 v0, v0, 0x8

    .line 59
    invoke-virtual {v10, v0}, Landroid/graphics/Paint;->m_46dc9993(I)V

    .line 62
    iget-boolean v0, v6, La_3DDEE9B9;->g:Z

    .line 64
    iget-object v3, v6, La_3DDEE9B9;->i:Landroid/graphics/Path;

    .line 66
    const/4 v12, 0x0

    .line 67
    const/4 v13, 0x0

    .line 68
    if-eqz v0, :cond_a

    .line 70
    iget-object v0, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 72
    iget-object v0, v0, La_A9E1BAE7;->u:Landroid/graphics/Paint$Style;

    .line 74
    sget-object v1, Landroid/graphics/Paint$Style;->FILL_AND_STROKE:Landroid/graphics/Paint$Style;

    .line 76
    if-eq v0, v1, :cond_0

    .line 78
    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 80
    if-ne v0, v1, :cond_1

    .line 82
    :cond_0
    invoke-virtual {v10}, Landroid/graphics/Paint;->m_85fb00ec()F

    .line 85
    move-result v0

    .line 86
    cmpl-float v0, v0, v12

    .line 88
    if-lez v0, :cond_1

    .line 90
    const/4 v0, 0x1

    .line 91
    goto :goto_0

    .line 92
    :cond_1
    const/4 v0, 0x0

    .line 93
    :goto_0
    const/high16 v1, 0x40000000    # 2.0f

    .line 95
    if-eqz v0, :cond_2

    .line 97
    invoke-virtual {v10}, Landroid/graphics/Paint;->m_85fb00ec()F

    .line 100
    move-result v0

    .line 101
    div-float/2addr v0, v1

    .line 102
    goto :goto_1

    .line 103
    :cond_2
    const/4 v0, 0x0

    .line 104
    :goto_1
    neg-float v0, v0

    .line 105
    iget-object v2, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 107
    iget-object v2, v2, La_A9E1BAE7;->a:Lxr;

    .line 109
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 112
    new-instance v4, La_FACD8686;

    .line 114
    invoke-direct {v4, v2}, La_FACD8686;-><init>(Lxr;)V

    .line 117
    iget-object v5, v2, Lxr;->e:La_F45F3F3A;

    .line 119
    instance-of v15, v5, Lmp;

    .line 121
    if-eqz v15, :cond_3

    .line 123
    goto :goto_2

    .line 124
    :cond_3
    new-instance v15, La_EBB5E933;

    .line 126
    invoke-direct {v15, v0, v5}, La_EBB5E933;-><init>(FLa_F45F3F3A;)V

    .line 129
    move-object v5, v15

    .line 130
    :goto_2
    iput-object v5, v4, La_FACD8686;->e:La_F45F3F3A;

    .line 132
    iget-object v5, v2, Lxr;->f:La_F45F3F3A;

    .line 134
    instance-of v15, v5, Lmp;

    .line 136
    if-eqz v15, :cond_4

    .line 138
    goto :goto_3

    .line 139
    :cond_4
    new-instance v15, La_EBB5E933;

    .line 141
    invoke-direct {v15, v0, v5}, La_EBB5E933;-><init>(FLa_F45F3F3A;)V

    .line 144
    move-object v5, v15

    .line 145
    :goto_3
    iput-object v5, v4, La_FACD8686;->f:La_F45F3F3A;

    .line 147
    iget-object v5, v2, Lxr;->h:La_F45F3F3A;

    .line 149
    instance-of v15, v5, Lmp;

    .line 151
    if-eqz v15, :cond_5

    .line 153
    goto :goto_4

    .line 154
    :cond_5
    new-instance v15, La_EBB5E933;

    .line 156
    invoke-direct {v15, v0, v5}, La_EBB5E933;-><init>(FLa_F45F3F3A;)V

    .line 159
    move-object v5, v15

    .line 160
    :goto_4
    iput-object v5, v4, La_FACD8686;->h:La_F45F3F3A;

    .line 162
    iget-object v2, v2, Lxr;->g:La_F45F3F3A;

    .line 164
    instance-of v5, v2, Lmp;

    .line 166
    if-eqz v5, :cond_6

    .line 168
    goto :goto_5

    .line 169
    :cond_6
    new-instance v5, La_EBB5E933;

    .line 171
    invoke-direct {v5, v0, v2}, La_EBB5E933;-><init>(FLa_F45F3F3A;)V

    .line 174
    move-object v2, v5

    .line 175
    :goto_5
    iput-object v2, v4, La_FACD8686;->g:La_F45F3F3A;

    .line 177
    new-instance v0, Lxr;

    .line 179
    invoke-direct {v0, v4}, Lxr;-><init>(La_FACD8686;)V

    .line 182
    iput-object v0, v6, La_3DDEE9B9;->o:Lxr;

    .line 184
    iget-object v15, v6, La_3DDEE9B9;->t:Lyr;

    .line 186
    iget-object v2, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 188
    iget v2, v2, La_A9E1BAE7;->j:F

    .line 190
    iget-object v4, v6, La_3DDEE9B9;->l:Landroid/graphics/RectF;

    .line 192
    invoke-virtual/range {p0 .. p0}, La_3DDEE9B9;->h()Landroid/graphics/RectF;

    .line 195
    move-result-object v5

    .line 196
    invoke-virtual {v4, v5}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    .line 199
    iget-object v5, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 201
    iget-object v5, v5, La_A9E1BAE7;->u:Landroid/graphics/Paint$Style;

    .line 203
    sget-object v14, Landroid/graphics/Paint$Style;->FILL_AND_STROKE:Landroid/graphics/Paint$Style;

    .line 205
    if-eq v5, v14, :cond_7

    .line 207
    sget-object v14, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 209
    if-ne v5, v14, :cond_8

    .line 211
    :cond_7
    invoke-virtual {v10}, Landroid/graphics/Paint;->m_85fb00ec()F

    .line 214
    move-result v5

    .line 215
    cmpl-float v5, v5, v12

    .line 217
    if-lez v5, :cond_8

    .line 219
    const/4 v5, 0x1

    .line 220
    goto :goto_6

    .line 221
    :cond_8
    const/4 v5, 0x0

    .line 222
    :goto_6
    if-eqz v5, :cond_9

    .line 224
    invoke-virtual {v10}, Landroid/graphics/Paint;->m_85fb00ec()F

    .line 227
    move-result v5

    .line 228
    div-float/2addr v5, v1

    .line 229
    goto :goto_7

    .line 230
    :cond_9
    const/4 v5, 0x0

    .line 231
    :goto_7
    invoke-virtual {v4, v5, v5}, Landroid/graphics/RectF;->inset(FF)V

    .line 234
    iget-object v1, v6, La_3DDEE9B9;->j:Landroid/graphics/Path;

    .line 236
    const/16 v19, 0x0

    .line 238
    move-object/from16 v16, v0

    .line 240
    move/from16 v17, v2

    .line 242
    move-object/from16 v18, v4

    .line 244
    move-object/from16 v20, v1

    .line 246
    invoke-virtual/range {v15 .. v20}, Lyr;->a(Lxr;FLandroid/graphics/RectF;La_B7279982;Landroid/graphics/Path;)V

    .line 249
    invoke-virtual/range {p0 .. p0}, La_3DDEE9B9;->h()Landroid/graphics/RectF;

    .line 252
    move-result-object v0

    .line 253
    invoke-virtual {v6, v0, v3}, La_3DDEE9B9;->b(Landroid/graphics/RectF;Landroid/graphics/Path;)V

    .line 256
    iput-boolean v13, v6, La_3DDEE9B9;->g:Z

    .line 258
    :cond_a
    iget-object v0, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 260
    iget v1, v0, La_A9E1BAE7;->p:I

    .line 262
    const/4 v2, 0x2

    .line 263
    const/4 v14, 0x1

    .line 264
    if-eq v1, v14, :cond_d

    .line 266
    iget v0, v0, La_A9E1BAE7;->q:I

    .line 268
    if-lez v0, :cond_d

    .line 270
    if-eq v1, v2, :cond_c

    .line 272
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 274
    invoke-virtual/range {p0 .. p0}, La_3DDEE9B9;->k()Z

    .line 277
    move-result v1

    .line 278
    if-nez v1, :cond_b

    .line 280
    invoke-virtual {v3}, Landroid/graphics/Path;->isConvex()Z

    .line 283
    move-result v1

    .line 284
    if-nez v1, :cond_b

    .line 286
    const/16 v1, 0x1d

    .line 288
    if-ge v0, v1, :cond_b

    .line 290
    const/4 v0, 0x1

    .line 291
    goto :goto_8

    .line 292
    :cond_b
    const/4 v0, 0x0

    .line 293
    :goto_8
    if-eqz v0, :cond_d

    .line 295
    :cond_c
    const/4 v0, 0x1

    .line 296
    goto :goto_9

    .line 297
    :cond_d
    const/4 v0, 0x0

    .line 298
    :goto_9
    if-nez v0, :cond_e

    .line 300
    goto/16 :goto_a

    .line 302
    :cond_e
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    .line 305
    iget-object v0, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 307
    iget v1, v0, La_A9E1BAE7;->r:I

    .line 309
    int-to-double v4, v1

    .line 310
    iget v0, v0, La_A9E1BAE7;->s:I

    .line 312
    int-to-double v0, v0

    .line 313
    invoke-static {v0, v1}, Ljava/lang/Math;->toRadians(D)D

    .line 316
    move-result-wide v0

    .line 317
    invoke-static {v0, v1}, Ljava/lang/Math;->sin(D)D

    .line 320
    move-result-wide v0

    .line 321
    mul-double v0, v0, v4

    .line 323
    double-to-int v0, v0

    .line 324
    iget-object v1, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 326
    iget v4, v1, La_A9E1BAE7;->r:I

    .line 328
    int-to-double v4, v4

    .line 329
    iget v1, v1, La_A9E1BAE7;->s:I

    .line 331
    int-to-double v13, v1

    .line 332
    invoke-static {v13, v14}, Ljava/lang/Math;->toRadians(D)D

    .line 335
    move-result-wide v13

    .line 336
    invoke-static {v13, v14}, Ljava/lang/Math;->cos(D)D

    .line 339
    move-result-wide v13

    .line 340
    mul-double v13, v13, v4

    .line 342
    double-to-int v1, v13

    .line 343
    int-to-float v0, v0

    .line 344
    int-to-float v1, v1

    .line 345
    invoke-virtual {v7, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 348
    iget-boolean v0, v6, La_3DDEE9B9;->x:Z

    .line 350
    if-nez v0, :cond_f

    .line 352
    invoke-virtual/range {p0 .. p1}, La_3DDEE9B9;->e(Landroid/graphics/Canvas;)V

    .line 355
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->restore()V

    .line 358
    goto :goto_a

    .line 359
    :cond_f
    iget-object v0, v6, La_3DDEE9B9;->w:Landroid/graphics/RectF;

    .line 361
    invoke-virtual {v0}, Landroid/graphics/RectF;->width()F

    .line 364
    move-result v1

    .line 365
    invoke-virtual/range {p0 .. p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 368
    move-result-object v4

    .line 369
    invoke-virtual {v4}, Landroid/graphics/Rect;->width()I

    .line 372
    move-result v4

    .line 373
    int-to-float v4, v4

    .line 374
    sub-float/2addr v1, v4

    .line 375
    float-to-int v1, v1

    .line 376
    invoke-virtual {v0}, Landroid/graphics/RectF;->height()F

    .line 379
    move-result v4

    .line 380
    invoke-virtual/range {p0 .. p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 383
    move-result-object v5

    .line 384
    invoke-virtual {v5}, Landroid/graphics/Rect;->height()I

    .line 387
    move-result v5

    .line 388
    int-to-float v5, v5

    .line 389
    sub-float/2addr v4, v5

    .line 390
    float-to-int v4, v4

    .line 391
    if-ltz v1, :cond_16

    .line 393
    if-ltz v4, :cond_16

    .line 395
    invoke-virtual {v0}, Landroid/graphics/RectF;->width()F

    .line 398
    move-result v5

    .line 399
    float-to-int v5, v5

    .line 400
    iget-object v13, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 402
    iget v13, v13, La_A9E1BAE7;->q:I

    .line 404
    mul-int/lit8 v13, v13, 0x2

    .line 406
    add-int/2addr v13, v5

    .line 407
    add-int/2addr v13, v1

    .line 408
    invoke-virtual {v0}, Landroid/graphics/RectF;->height()F

    .line 411
    move-result v0

    .line 412
    float-to-int v0, v0

    .line 413
    iget-object v5, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 415
    iget v5, v5, La_A9E1BAE7;->q:I

    .line 417
    mul-int/lit8 v5, v5, 0x2

    .line 419
    add-int/2addr v5, v0

    .line 420
    add-int/2addr v5, v4

    .line 421
    sget-object v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 423
    invoke-static {v13, v5, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 426
    move-result-object v0

    .line 427
    new-instance v2, Landroid/graphics/Canvas;

    .line 429
    invoke-direct {v2, v0}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 432
    invoke-virtual/range {p0 .. p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 435
    move-result-object v5

    .line 436
    iget v5, v5, Landroid/graphics/Rect;->left:I

    .line 438
    iget-object v13, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 440
    iget v13, v13, La_A9E1BAE7;->q:I

    .line 442
    sub-int/2addr v5, v13

    .line 443
    sub-int/2addr v5, v1

    .line 444
    int-to-float v1, v5

    .line 445
    invoke-virtual/range {p0 .. p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 448
    move-result-object v5

    .line 449
    iget v5, v5, Landroid/graphics/Rect;->top:I

    .line 451
    iget-object v13, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 453
    iget v13, v13, La_A9E1BAE7;->q:I

    .line 455
    sub-int/2addr v5, v13

    .line 456
    sub-int/2addr v5, v4

    .line 457
    int-to-float v4, v5

    .line 458
    neg-float v5, v1

    .line 459
    neg-float v13, v4

    .line 460
    invoke-virtual {v2, v5, v13}, Landroid/graphics/Canvas;->translate(FF)V

    .line 463
    invoke-virtual {v6, v2}, La_3DDEE9B9;->e(Landroid/graphics/Canvas;)V

    .line 466
    const/4 v2, 0x0

    .line 467
    invoke-virtual {v7, v0, v1, v4, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 470
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 473
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->restore()V

    .line 476
    :goto_a
    iget-object v0, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 478
    iget-object v1, v0, La_A9E1BAE7;->u:Landroid/graphics/Paint$Style;

    .line 480
    sget-object v2, Landroid/graphics/Paint$Style;->FILL_AND_STROKE:Landroid/graphics/Paint$Style;

    .line 482
    if-eq v1, v2, :cond_11

    .line 484
    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 486
    if-ne v1, v2, :cond_10

    .line 488
    goto :goto_b

    .line 489
    :cond_10
    const/4 v1, 0x0

    .line 490
    goto :goto_c

    .line 491
    :cond_11
    :goto_b
    const/4 v1, 0x1

    .line 492
    :goto_c
    if-eqz v1, :cond_12

    .line 494
    iget-object v4, v0, La_A9E1BAE7;->a:Lxr;

    .line 496
    invoke-virtual/range {p0 .. p0}, La_3DDEE9B9;->h()Landroid/graphics/RectF;

    .line 499
    move-result-object v5

    .line 500
    move-object/from16 v0, p0

    .line 502
    move-object/from16 v1, p1

    .line 504
    move-object v2, v8

    .line 505
    invoke-virtual/range {v0 .. v5}, La_3DDEE9B9;->f(Landroid/graphics/Canvas;Landroid/graphics/Paint;Landroid/graphics/Path;Lxr;Landroid/graphics/RectF;)V

    .line 508
    :cond_12
    iget-object v0, v6, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 510
    iget-object v0, v0, La_A9E1BAE7;->u:Landroid/graphics/Paint$Style;

    .line 512
    sget-object v1, Landroid/graphics/Paint$Style;->FILL_AND_STROKE:Landroid/graphics/Paint$Style;

    .line 514
    if-eq v0, v1, :cond_13

    .line 516
    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 518
    if-ne v0, v1, :cond_14

    .line 520
    :cond_13
    invoke-virtual {v10}, Landroid/graphics/Paint;->m_85fb00ec()F

    .line 523
    move-result v0

    .line 524
    cmpl-float v0, v0, v12

    .line 526
    if-lez v0, :cond_14

    .line 528
    const/4 v13, 0x1

    .line 529
    goto :goto_d

    .line 530
    :cond_14
    const/4 v13, 0x0

    .line 531
    :goto_d
    if-eqz v13, :cond_15

    .line 533
    invoke-virtual/range {p0 .. p1}, La_3DDEE9B9;->g(Landroid/graphics/Canvas;)V

    .line 536
    :cond_15
    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->m_46dc9993(I)V

    .line 539
    invoke-virtual {v10, v11}, Landroid/graphics/Paint;->m_46dc9993(I)V

    .line 542
    return-void

    .line 543
    :cond_16
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 545
    const-string v1, "Invalid shadow bounds. Check that the treatments result in a valid path."

    .line 547
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 550
    throw v0
.end method

.method public final e(Landroid/graphics/Canvas;)V
    .locals 7

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->f:Ljava/util/BitSet;

    .line 3
    invoke-virtual {v0}, Ljava/util/BitSet;->cardinality()I

    .line 6
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 8
    iget v0, v0, La_A9E1BAE7;->r:I

    .line 10
    iget-object v1, p0, La_3DDEE9B9;->i:Landroid/graphics/Path;

    .line 12
    iget-object v2, p0, La_3DDEE9B9;->r:Lvr;

    .line 14
    if-eqz v0, :cond_0

    .line 16
    iget-object v0, v2, Lvr;->a:Landroid/graphics/Paint;

    .line 18
    invoke-virtual {p1, v1, v0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 21
    :cond_0
    const/4 v0, 0x0

    .line 22
    :goto_0
    const/4 v3, 0x4

    .line 23
    if-ge v0, v3, :cond_1

    .line 25
    iget-object v3, p0, La_3DDEE9B9;->d:[La_BA3BE4DC;

    .line 27
    aget-object v3, v3, v0

    .line 29
    iget-object v4, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 31
    iget v4, v4, La_A9E1BAE7;->q:I

    .line 33
    sget-object v5, La_BA3BE4DC;->b:Landroid/graphics/Matrix;

    .line 35
    invoke-virtual {v3, v5, v2, v4, p1}, La_BA3BE4DC;->a(Landroid/graphics/Matrix;Lvr;ILandroid/graphics/Canvas;)V

    .line 38
    iget-object v3, p0, La_3DDEE9B9;->e:[La_BA3BE4DC;

    .line 40
    aget-object v3, v3, v0

    .line 42
    iget-object v4, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 44
    iget v4, v4, La_A9E1BAE7;->q:I

    .line 46
    invoke-virtual {v3, v5, v2, v4, p1}, La_BA3BE4DC;->a(Landroid/graphics/Matrix;Lvr;ILandroid/graphics/Canvas;)V

    .line 49
    add-int/lit8 v0, v0, 0x1

    .line 51
    goto :goto_0

    .line 52
    :cond_1
    iget-boolean v0, p0, La_3DDEE9B9;->x:Z

    .line 54
    if-eqz v0, :cond_2

    .line 56
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 58
    iget v2, v0, La_A9E1BAE7;->r:I

    .line 60
    int-to-double v2, v2

    .line 61
    iget v0, v0, La_A9E1BAE7;->s:I

    .line 63
    int-to-double v4, v0

    .line 64
    invoke-static {v4, v5}, Ljava/lang/Math;->toRadians(D)D

    .line 67
    move-result-wide v4

    .line 68
    invoke-static {v4, v5}, Ljava/lang/Math;->sin(D)D

    .line 71
    move-result-wide v4

    .line 72
    mul-double v4, v4, v2

    .line 74
    double-to-int v0, v4

    .line 75
    iget-object v2, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 77
    iget v3, v2, La_A9E1BAE7;->r:I

    .line 79
    int-to-double v3, v3

    .line 80
    iget v2, v2, La_A9E1BAE7;->s:I

    .line 82
    int-to-double v5, v2

    .line 83
    invoke-static {v5, v6}, Ljava/lang/Math;->toRadians(D)D

    .line 86
    move-result-wide v5

    .line 87
    invoke-static {v5, v6}, Ljava/lang/Math;->cos(D)D

    .line 90
    move-result-wide v5

    .line 91
    mul-double v5, v5, v3

    .line 93
    double-to-int v2, v5

    .line 94
    neg-int v3, v0

    .line 95
    int-to-float v3, v3

    .line 96
    neg-int v4, v2

    .line 97
    int-to-float v4, v4

    .line 98
    invoke-virtual {p1, v3, v4}, Landroid/graphics/Canvas;->translate(FF)V

    .line 101
    sget-object v3, La_3DDEE9B9;->y:Landroid/graphics/Paint;

    .line 103
    invoke-virtual {p1, v1, v3}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 106
    int-to-float v0, v0

    .line 107
    int-to-float v1, v2

    .line 108
    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 111
    :cond_2
    return-void
.end method

.method public final f(Landroid/graphics/Canvas;Landroid/graphics/Paint;Landroid/graphics/Path;Lxr;Landroid/graphics/RectF;)V
    .locals 1

    .line 1
    invoke-virtual {p4, p5}, Lxr;->d(Landroid/graphics/RectF;)Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    iget-object p3, p4, Lxr;->f:La_F45F3F3A;

    .line 9
    invoke-interface {p3, p5}, La_F45F3F3A;->a(Landroid/graphics/RectF;)F

    .line 12
    move-result p3

    .line 13
    iget-object p4, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 15
    iget p4, p4, La_A9E1BAE7;->j:F

    .line 17
    mul-float p3, p3, p4

    .line 19
    invoke-virtual {p1, p5, p3, p3, p2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    invoke-virtual {p1, p3, p2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 26
    :goto_0
    return-void
.end method

.method public g(Landroid/graphics/Canvas;)V
    .locals 7

    .line 1
    iget-object v2, p0, La_3DDEE9B9;->q:Landroid/graphics/Paint;

    .line 3
    iget-object v3, p0, La_3DDEE9B9;->j:Landroid/graphics/Path;

    .line 5
    iget-object v4, p0, La_3DDEE9B9;->o:Lxr;

    .line 7
    iget-object v5, p0, La_3DDEE9B9;->l:Landroid/graphics/RectF;

    .line 9
    invoke-virtual {p0}, La_3DDEE9B9;->h()Landroid/graphics/RectF;

    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {v5, v0}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    .line 16
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 18
    iget-object v0, v0, La_A9E1BAE7;->u:Landroid/graphics/Paint$Style;

    .line 20
    sget-object v1, Landroid/graphics/Paint$Style;->FILL_AND_STROKE:Landroid/graphics/Paint$Style;

    .line 22
    const/4 v6, 0x0

    .line 23
    if-eq v0, v1, :cond_0

    .line 25
    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 27
    if-ne v0, v1, :cond_1

    .line 29
    :cond_0
    invoke-virtual {v2}, Landroid/graphics/Paint;->m_85fb00ec()F

    .line 32
    move-result v0

    .line 33
    cmpl-float v0, v0, v6

    .line 35
    if-lez v0, :cond_1

    .line 37
    const/4 v0, 0x1

    .line 38
    goto :goto_0

    .line 39
    :cond_1
    const/4 v0, 0x0

    .line 40
    :goto_0
    if-eqz v0, :cond_2

    .line 42
    invoke-virtual {v2}, Landroid/graphics/Paint;->m_85fb00ec()F

    .line 45
    move-result v0

    .line 46
    const/high16 v1, 0x40000000    # 2.0f

    .line 48
    div-float v6, v0, v1

    .line 50
    :cond_2
    invoke-virtual {v5, v6, v6}, Landroid/graphics/RectF;->inset(FF)V

    .line 53
    move-object v0, p0

    .line 54
    move-object v1, p1

    .line 55
    invoke-virtual/range {v0 .. v5}, La_3DDEE9B9;->f(Landroid/graphics/Canvas;Landroid/graphics/Paint;Landroid/graphics/Path;Lxr;Landroid/graphics/RectF;)V

    .line 58
    return-void
.end method

.method public m_b536a652()I
    .locals 1

    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    iget v0, v0, La_A9E1BAE7;->l:I

    return v0
.end method

.method public final m_3a533835()Landroid/graphics/drawable/Drawable$ConstantState;
    .locals 1

    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    return-object v0
.end method

.method public m_2965c51e()I
    .locals 1

    const/4 v0, -0x3

    return v0
.end method

.method public m_7653a4a3(Landroid/graphics/Outline;)V
    .locals 3
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 3
    iget v0, v0, La_A9E1BAE7;->p:I

    .line 5
    const/4 v1, 0x2

    .line 6
    if-ne v0, v1, :cond_0

    .line 8
    return-void

    .line 9
    :cond_0
    invoke-virtual {p0}, La_3DDEE9B9;->k()Z

    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_1

    .line 15
    invoke-virtual {p0}, La_3DDEE9B9;->i()F

    .line 18
    move-result v0

    .line 19
    iget-object v1, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 21
    iget v1, v1, La_A9E1BAE7;->j:F

    .line 23
    mul-float v0, v0, v1

    .line 25
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 28
    move-result-object v1

    .line 29
    invoke-virtual {p1, v1, v0}, Landroid/graphics/Outline;->setRoundRect(Landroid/graphics/Rect;F)V

    .line 32
    return-void

    .line 33
    :cond_1
    invoke-virtual {p0}, La_3DDEE9B9;->h()Landroid/graphics/RectF;

    .line 36
    move-result-object v0

    .line 37
    iget-object v1, p0, La_3DDEE9B9;->i:Landroid/graphics/Path;

    .line 39
    invoke-virtual {p0, v0, v1}, La_3DDEE9B9;->b(Landroid/graphics/RectF;Landroid/graphics/Path;)V

    .line 42
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 44
    const/16 v2, 0x1e

    .line 46
    if-lt v0, v2, :cond_2

    .line 48
    invoke-static {p1, v1}, Lq;->m(Landroid/graphics/Outline;Landroid/graphics/Path;)V

    .line 51
    goto :goto_0

    .line 52
    :cond_2
    const/16 v2, 0x1d

    .line 54
    if-lt v0, v2, :cond_3

    .line 56
    :try_start_0
    invoke-virtual {p1, v1}, Landroid/graphics/Outline;->setConvexPath(Landroid/graphics/Path;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 59
    goto :goto_0

    .line 60
    :cond_3
    invoke-virtual {v1}, Landroid/graphics/Path;->isConvex()Z

    .line 63
    move-result v0

    .line 64
    if-eqz v0, :cond_4

    .line 66
    invoke-virtual {p1, v1}, Landroid/graphics/Outline;->setConvexPath(Landroid/graphics/Path;)V

    .line 69
    :catch_0
    :cond_4
    :goto_0
    return-void
.end method

.method public final m_5a16927a(Landroid/graphics/Rect;)Z
    .locals 1

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 3
    iget-object v0, v0, La_A9E1BAE7;->h:Landroid/graphics/Rect;

    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-virtual {p1, v0}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 10
    const/4 p1, 0x1

    .line 11
    return p1

    .line 12
    :cond_0
    invoke-super {p0, p1}, Landroid/graphics/drawable/Drawable;->m_5a16927a(Landroid/graphics/Rect;)Z

    .line 15
    move-result p1

    .line 16
    return p1
.end method

.method public final m_9858d313()Landroid/graphics/Region;
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, La_3DDEE9B9;->m:Landroid/graphics/Region;

    .line 7
    invoke-virtual {v1, v0}, Landroid/graphics/Region;->set(Landroid/graphics/Rect;)Z

    .line 10
    invoke-virtual {p0}, La_3DDEE9B9;->h()Landroid/graphics/RectF;

    .line 13
    move-result-object v0

    .line 14
    iget-object v2, p0, La_3DDEE9B9;->i:Landroid/graphics/Path;

    .line 16
    invoke-virtual {p0, v0, v2}, La_3DDEE9B9;->b(Landroid/graphics/RectF;Landroid/graphics/Path;)V

    .line 19
    iget-object v0, p0, La_3DDEE9B9;->n:Landroid/graphics/Region;

    .line 21
    invoke-virtual {v0, v2, v1}, Landroid/graphics/Region;->setPath(Landroid/graphics/Path;Landroid/graphics/Region;)Z

    .line 24
    sget-object v2, Landroid/graphics/Region$Op;->DIFFERENCE:Landroid/graphics/Region$Op;

    .line 26
    invoke-virtual {v1, v0, v2}, Landroid/graphics/Region;->op(Landroid/graphics/Region;Landroid/graphics/Region$Op;)Z

    .line 29
    return-object v1
.end method

.method public final h()Landroid/graphics/RectF;
    .locals 2

    iget-object v0, p0, La_3DDEE9B9;->k:Landroid/graphics/RectF;

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    return-object v0
.end method

.method public final i()F
    .locals 2

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 3
    iget-object v0, v0, La_A9E1BAE7;->a:Lxr;

    .line 5
    iget-object v0, v0, Lxr;->e:La_F45F3F3A;

    .line 7
    invoke-virtual {p0}, La_3DDEE9B9;->h()Landroid/graphics/RectF;

    .line 10
    move-result-object v1

    .line 11
    invoke-interface {v0, v1}, La_F45F3F3A;->a(Landroid/graphics/RectF;)F

    .line 14
    move-result v0

    .line 15
    return v0
.end method

.method public final m_4fb22408()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, La_3DDEE9B9;->g:Z

    .line 4
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->m_4fb22408()V

    .line 7
    return-void
.end method

.method public m_46259b2f()Z
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->m_46259b2f()Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_4

    .line 7
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 9
    iget-object v0, v0, La_A9E1BAE7;->f:Landroid/content/res/ColorStateList;

    .line 11
    if-eqz v0, :cond_0

    .line 13
    invoke-virtual {v0}, Landroid/content/res/ColorStateList;->m_46259b2f()Z

    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_4

    .line 19
    :cond_0
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 21
    iget-object v0, v0, La_A9E1BAE7;->e:Landroid/content/res/ColorStateList;

    .line 23
    if-eqz v0, :cond_1

    .line 25
    invoke-virtual {v0}, Landroid/content/res/ColorStateList;->m_46259b2f()Z

    .line 28
    move-result v0

    .line 29
    if-nez v0, :cond_4

    .line 31
    :cond_1
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 33
    iget-object v0, v0, La_A9E1BAE7;->d:Landroid/content/res/ColorStateList;

    .line 35
    if-eqz v0, :cond_2

    .line 37
    invoke-virtual {v0}, Landroid/content/res/ColorStateList;->m_46259b2f()Z

    .line 40
    move-result v0

    .line 41
    if-nez v0, :cond_4

    .line 43
    :cond_2
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 45
    iget-object v0, v0, La_A9E1BAE7;->c:Landroid/content/res/ColorStateList;

    .line 47
    if-eqz v0, :cond_3

    .line 49
    invoke-virtual {v0}, Landroid/content/res/ColorStateList;->m_46259b2f()Z

    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_3

    .line 55
    goto :goto_0

    .line 56
    :cond_3
    const/4 v0, 0x0

    .line 57
    goto :goto_1

    .line 58
    :cond_4
    :goto_0
    const/4 v0, 0x1

    .line 59
    :goto_1
    return v0
.end method

.method public final j(Landroid/content/Context;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 3
    new-instance v1, Lkb;

    .line 5
    invoke-direct {v1, p1}, Lkb;-><init>(Landroid/content/Context;)V

    .line 8
    iput-object v1, v0, La_A9E1BAE7;->b:Lkb;

    .line 10
    invoke-virtual {p0}, La_3DDEE9B9;->r()V

    .line 13
    return-void
.end method

.method public final k()Z
    .locals 2

    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    iget-object v0, v0, La_A9E1BAE7;->a:Lxr;

    invoke-virtual {p0}, La_3DDEE9B9;->h()Landroid/graphics/RectF;

    move-result-object v1

    invoke-virtual {v0, v1}, Lxr;->d(Landroid/graphics/RectF;)Z

    move-result v0

    return v0
.end method

.method public final l(F)V
    .locals 2

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 3
    iget v1, v0, La_A9E1BAE7;->n:F

    .line 5
    cmpl-float v1, v1, p1

    .line 7
    if-eqz v1, :cond_0

    .line 9
    iput p1, v0, La_A9E1BAE7;->n:F

    .line 11
    invoke-virtual {p0}, La_3DDEE9B9;->r()V

    .line 14
    :cond_0
    return-void
.end method

.method public final m(Landroid/content/res/ColorStateList;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 3
    iget-object v1, v0, La_A9E1BAE7;->c:Landroid/content/res/ColorStateList;

    .line 5
    if-eq v1, p1, :cond_0

    .line 7
    iput-object p1, v0, La_A9E1BAE7;->c:Landroid/content/res/ColorStateList;

    .line 9
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->m_a4bf0ce9()[I

    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {p0, p1}, La_3DDEE9B9;->onStateChange([I)Z

    .line 16
    :cond_0
    return-void
.end method

.method public m_e416d128()Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 1
    new-instance v0, La_A9E1BAE7;

    .line 3
    iget-object v1, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 5
    invoke-direct {v0, v1}, La_A9E1BAE7;-><init>(La_A9E1BAE7;)V

    .line 8
    iput-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 10
    return-object p0
.end method

.method public final n(F)V
    .locals 2

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 3
    iget v1, v0, La_A9E1BAE7;->j:F

    .line 5
    cmpl-float v1, v1, p1

    .line 7
    if-eqz v1, :cond_0

    .line 9
    iput p1, v0, La_A9E1BAE7;->j:F

    .line 11
    const/4 p1, 0x1

    .line 12
    iput-boolean p1, p0, La_3DDEE9B9;->g:Z

    .line 14
    invoke-virtual {p0}, La_3DDEE9B9;->m_4fb22408()V

    .line 17
    :cond_0
    return-void
.end method

.method public final o()V
    .locals 2

    .line 1
    const v0, -0xbbbbbc

    .line 4
    iget-object v1, p0, La_3DDEE9B9;->r:Lvr;

    .line 6
    invoke-virtual {v1, v0}, Lvr;->a(I)V

    .line 9
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 11
    const/4 v1, 0x0

    .line 12
    iput-boolean v1, v0, La_A9E1BAE7;->t:Z

    .line 14
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->m_4fb22408()V

    .line 17
    return-void
.end method

.method public final onBoundsChange(Landroid/graphics/Rect;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, La_3DDEE9B9;->g:Z

    .line 4
    invoke-super {p0, p1}, Landroid/graphics/drawable/Drawable;->onBoundsChange(Landroid/graphics/Rect;)V

    .line 7
    return-void
.end method

.method public onStateChange([I)Z
    .locals 1

    .line 1
    invoke-virtual {p0, p1}, La_3DDEE9B9;->p([I)Z

    .line 4
    move-result p1

    .line 5
    invoke-virtual {p0}, La_3DDEE9B9;->q()Z

    .line 8
    move-result v0

    .line 9
    if-nez p1, :cond_1

    .line 11
    if-eqz v0, :cond_0

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 p1, 0x0

    .line 15
    goto :goto_1

    .line 16
    :cond_1
    :goto_0
    const/4 p1, 0x1

    .line 17
    :goto_1
    if-eqz p1, :cond_2

    .line 19
    invoke-virtual {p0}, La_3DDEE9B9;->m_4fb22408()V

    .line 22
    :cond_2
    return p1
.end method

.method public final p([I)Z
    .locals 5

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 3
    iget-object v0, v0, La_A9E1BAE7;->c:Landroid/content/res/ColorStateList;

    .line 5
    const/4 v1, 0x1

    .line 6
    if-eqz v0, :cond_0

    .line 8
    iget-object v0, p0, La_3DDEE9B9;->p:Landroid/graphics/Paint;

    .line 10
    invoke-virtual {v0}, Landroid/graphics/Paint;->getColor()I

    .line 13
    move-result v2

    .line 14
    iget-object v3, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 16
    iget-object v3, v3, La_A9E1BAE7;->c:Landroid/content/res/ColorStateList;

    .line 18
    invoke-virtual {v3, p1, v2}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 21
    move-result v3

    .line 22
    if-eq v2, v3, :cond_0

    .line 24
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 27
    const/4 v0, 0x1

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    const/4 v0, 0x0

    .line 30
    :goto_0
    iget-object v2, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 32
    iget-object v2, v2, La_A9E1BAE7;->d:Landroid/content/res/ColorStateList;

    .line 34
    if-eqz v2, :cond_1

    .line 36
    iget-object v2, p0, La_3DDEE9B9;->q:Landroid/graphics/Paint;

    .line 38
    invoke-virtual {v2}, Landroid/graphics/Paint;->getColor()I

    .line 41
    move-result v3

    .line 42
    iget-object v4, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 44
    iget-object v4, v4, La_A9E1BAE7;->d:Landroid/content/res/ColorStateList;

    .line 46
    invoke-virtual {v4, p1, v3}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 49
    move-result p1

    .line 50
    if-eq v3, p1, :cond_1

    .line 52
    invoke-virtual {v2, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 55
    goto :goto_1

    .line 56
    :cond_1
    move v1, v0

    .line 57
    :goto_1
    return v1
.end method

.method public final q()Z
    .locals 7

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->u:Landroid/graphics/PorterDuffColorFilter;

    .line 3
    iget-object v1, p0, La_3DDEE9B9;->v:Landroid/graphics/PorterDuffColorFilter;

    .line 5
    iget-object v2, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 7
    iget-object v3, v2, La_A9E1BAE7;->f:Landroid/content/res/ColorStateList;

    .line 9
    iget-object v2, v2, La_A9E1BAE7;->g:Landroid/graphics/PorterDuff$Mode;

    .line 11
    iget-object v4, p0, La_3DDEE9B9;->p:Landroid/graphics/Paint;

    .line 13
    const/4 v5, 0x1

    .line 14
    invoke-virtual {p0, v3, v2, v4, v5}, La_3DDEE9B9;->c(Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;Landroid/graphics/Paint;Z)Landroid/graphics/PorterDuffColorFilter;

    .line 17
    move-result-object v2

    .line 18
    iput-object v2, p0, La_3DDEE9B9;->u:Landroid/graphics/PorterDuffColorFilter;

    .line 20
    iget-object v2, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 22
    iget-object v3, v2, La_A9E1BAE7;->e:Landroid/content/res/ColorStateList;

    .line 24
    iget-object v2, v2, La_A9E1BAE7;->g:Landroid/graphics/PorterDuff$Mode;

    .line 26
    iget-object v4, p0, La_3DDEE9B9;->q:Landroid/graphics/Paint;

    .line 28
    const/4 v6, 0x0

    .line 29
    invoke-virtual {p0, v3, v2, v4, v6}, La_3DDEE9B9;->c(Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;Landroid/graphics/Paint;Z)Landroid/graphics/PorterDuffColorFilter;

    .line 32
    move-result-object v2

    .line 33
    iput-object v2, p0, La_3DDEE9B9;->v:Landroid/graphics/PorterDuffColorFilter;

    .line 35
    iget-object v2, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 37
    iget-boolean v3, v2, La_A9E1BAE7;->t:Z

    .line 39
    if-eqz v3, :cond_0

    .line 41
    iget-object v2, v2, La_A9E1BAE7;->f:Landroid/content/res/ColorStateList;

    .line 43
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->m_a4bf0ce9()[I

    .line 46
    move-result-object v3

    .line 47
    invoke-virtual {v2, v3, v6}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 50
    move-result v2

    .line 51
    iget-object v3, p0, La_3DDEE9B9;->r:Lvr;

    .line 53
    invoke-virtual {v3, v2}, Lvr;->a(I)V

    .line 56
    :cond_0
    iget-object v2, p0, La_3DDEE9B9;->u:Landroid/graphics/PorterDuffColorFilter;

    .line 58
    invoke-static {v0, v2}, Lxm;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 61
    move-result v0

    .line 62
    if-eqz v0, :cond_2

    .line 64
    iget-object v0, p0, La_3DDEE9B9;->v:Landroid/graphics/PorterDuffColorFilter;

    .line 66
    invoke-static {v1, v0}, Lxm;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 69
    move-result v0

    .line 70
    if-nez v0, :cond_1

    .line 72
    goto :goto_0

    .line 73
    :cond_1
    const/4 v5, 0x0

    .line 74
    :cond_2
    :goto_0
    return v5
.end method

.method public final r()V
    .locals 4

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 3
    iget v1, v0, La_A9E1BAE7;->n:F

    .line 5
    iget v2, v0, La_A9E1BAE7;->o:F

    .line 7
    add-float/2addr v1, v2

    .line 8
    const/high16 v2, 0x3f400000    # 0.75f

    .line 10
    mul-float v2, v2, v1

    .line 12
    float-to-double v2, v2

    .line 13
    invoke-static {v2, v3}, Ljava/lang/Math;->ceil(D)D

    .line 16
    move-result-wide v2

    .line 17
    double-to-int v2, v2

    .line 18
    iput v2, v0, La_A9E1BAE7;->q:I

    .line 20
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 22
    const/high16 v2, 0x3e800000    # 0.25f

    .line 24
    mul-float v1, v1, v2

    .line 26
    float-to-double v1, v1

    .line 27
    invoke-static {v1, v2}, Ljava/lang/Math;->ceil(D)D

    .line 30
    move-result-wide v1

    .line 31
    double-to-int v1, v1

    .line 32
    iput v1, v0, La_A9E1BAE7;->r:I

    .line 34
    invoke-virtual {p0}, La_3DDEE9B9;->q()Z

    .line 37
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->m_4fb22408()V

    .line 40
    return-void
.end method

.method public m_46dc9993(I)V
    .locals 2

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 3
    iget v1, v0, La_A9E1BAE7;->l:I

    .line 5
    if-eq v1, p1, :cond_0

    .line 7
    iput p1, v0, La_A9E1BAE7;->l:I

    .line 9
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->m_4fb22408()V

    .line 12
    :cond_0
    return-void
.end method

.method public m_c2bf9474(Landroid/graphics/ColorFilter;)V
    .locals 0

    .line 1
    iget-object p1, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->m_4fb22408()V

    .line 9
    return-void
.end method

.method public final m_f3cf19db(Lxr;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 3
    iput-object p1, v0, La_A9E1BAE7;->a:Lxr;

    .line 5
    invoke-virtual {p0}, La_3DDEE9B9;->m_4fb22408()V

    .line 8
    return-void
.end method

.method public final m_fd5fb1da(I)V
    .locals 0

    invoke-static {p1}, Landroid/content/res/ColorStateList;->m_446e0ad6(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    invoke-virtual {p0, p1}, La_3DDEE9B9;->m_fafedc67(Landroid/content/res/ColorStateList;)V

    return-void
.end method

.method public m_fafedc67(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 3
    iput-object p1, v0, La_A9E1BAE7;->f:Landroid/content/res/ColorStateList;

    .line 5
    invoke-virtual {p0}, La_3DDEE9B9;->q()Z

    .line 8
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->m_4fb22408()V

    .line 11
    return-void
.end method

.method public m_b2ffc8df(Landroid/graphics/PorterDuff$Mode;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 3
    iget-object v1, v0, La_A9E1BAE7;->g:Landroid/graphics/PorterDuff$Mode;

    .line 5
    if-eq v1, p1, :cond_0

    .line 7
    iput-object p1, v0, La_A9E1BAE7;->g:Landroid/graphics/PorterDuff$Mode;

    .line 9
    invoke-virtual {p0}, La_3DDEE9B9;->q()Z

    .line 12
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->m_4fb22408()V

    .line 15
    :cond_0
    return-void
.end method
