.class public final La_138F2AB1;
.super Lpi;
# generated-29440
# compiled-13850
.source "jotirrbr.java"

# ep-flosbhzcxoiy

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lan;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lpi;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(La_A9A97716;La_C9B48E93;Lft;)Lep;
    .locals 3

    .line 1
    iget-object p1, p1, La_A9A97716;->d:Ljava/util/ArrayDeque;

    .line 3
    invoke-virtual {p1}, Ljava/util/ArrayDeque;->m_a8414bdf()Ljava/util/Iterator;

    .line 6
    move-result-object p1

    .line 7
    :cond_0
    invoke-interface {p1}, Ljava/util/Iterator;->m_bd51c992()Z

    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_1

    .line 13
    invoke-interface {p1}, Ljava/util/Iterator;->m_092c0567()Ljava/lang/Object;

    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Lep;

    .line 19
    iget-object v1, v0, Lep;->l:Ljava/util/ArrayList;

    .line 21
    invoke-virtual {v1}, Ljava/util/ArrayList;->m_414f6463()I

    .line 24
    move-result v1

    .line 25
    iget v2, v0, Lep;->k:I

    .line 27
    if-ge v1, v2, :cond_0

    .line 29
    iget-object v1, v0, Lep;->b:Lpq;

    .line 31
    iget-object v1, v1, Lpq;->a:La_C9B48E93;

    .line 33
    invoke-virtual {p2, v1}, La_C9B48E93;->equals(Ljava/lang/Object;)Z

    .line 36
    move-result v1

    .line 37
    if-eqz v1, :cond_0

    .line 39
    iget-boolean v1, v0, Lep;->m:Z

    .line 41
    if-nez v1, :cond_0

    .line 43
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    iget-object p1, v0, Lep;->l:Ljava/util/ArrayList;

    .line 48
    new-instance p2, La_A33C2B6C;

    .line 50
    iget-object v1, p3, Lft;->d:Ljava/lang/Object;

    .line 52
    invoke-direct {p2, p3, v1}, La_A33C2B6C;-><init>(Lft;Ljava/lang/Object;)V

    .line 55
    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 58
    goto :goto_0

    .line 59
    :cond_1
    const/4 v0, 0x0

    .line 60
    :goto_0
    return-object v0
.end method
