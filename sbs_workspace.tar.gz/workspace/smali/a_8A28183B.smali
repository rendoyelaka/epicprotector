.class public final La_8A28183B;
.super Le;
.source "cbocxjah.java"

# ep-jzizvyjsvoev
# verified-29313

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_340F13F4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Le<",
        "La_59F8C096;",
        "La_340F13F4;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    sget-object v0, La_5A57E973;->a:La_5A57E973;

    .line 3
    sget-object v1, La_37F78A7F;->c:La_37F78A7F;

    .line 5
    invoke-direct {p0, v0, v1}, Le;-><init>(La_33BEBC85;Lhf;)V

    .line 8
    return-void
.end method
