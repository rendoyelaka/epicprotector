.class public interface abstract La_44AEE6A2;
.super Ljava/lang/Object;
.source "ndomvnrs.java"

# ep-fznvhumcdqsj
# validated-39055
# compiled-51548
# compiled-41057

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_52ACB80E;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation


# virtual methods
.method public abstract onRequestPermissionsResult(I[Ljava/lang/String;[I)V
.end method
