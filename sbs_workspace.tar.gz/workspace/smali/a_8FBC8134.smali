.class public interface abstract La_8FBC8134;
.super Ljava/lang/Object;
.source "lfmdwleu.java"


# validated-22772
# compiled-18711
# compiled-18280
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_6C2C7A62;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
