.class public abstract Ldo;
.super LFragment;
# ep-qllfiyrwwnsv
# processed-42392
# generated-22502
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<S:",
        "Ljava/lang/Object;",
        ">",
        "LFragment;"
    }
.end annotation


# instance fields
.field public final T:Ljava/util/LinkedHashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashSet<",
            "Lln<",
            "TS;>;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, LFragment;-><init>()V

    .line 4
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 6
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 9
    iput-object v0, p0, Ldo;->T:Ljava/util/LinkedHashSet;

    .line 11
    return-void
.end method


# virtual methods
.method public K(Lcom/google/android/material/datepicker/d$d;)Z
    .locals 1

    iget-object v0, p0, Ldo;->T:Ljava/util/LinkedHashSet;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_6r7zlnx7
    goto :ep_s_6r7zlnx7
    :ep_d_6r7zlnx7
    nop
    :ep_s_6r7zlnx7
    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_838b889g
    goto :ep_s_838b889g
    :ep_d_838b889g
    nop
    :ep_s_838b889g
    move-result p1

    return p1
.end method
