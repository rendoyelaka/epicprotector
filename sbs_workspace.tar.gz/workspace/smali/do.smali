.class public abstract Ldo;
.super LFragment;
# ep-lxutrqbpdmwx
.source "SourceFile"
# processed-48674


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<S:",
        "Ljava/lang/Object;",
        ">",
        "LFragment;"
    }
.end annotation


# instance fields
.field public final T:Ljava/util/LinkedHashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashSet<",
            "Lln<",
            "TS;>;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, LFragment;-><init>()V

    .line 4
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 6
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 9
    iput-object v0, p0, Ldo;->T:Ljava/util/LinkedHashSet;

    .line 11
    return-void
.end method


# virtual methods
.method public K(Lcom/google/android/material/datepicker/d$d;)Z
    .locals 1

    iget-object v0, p0, Ldo;->T:Ljava/util/LinkedHashSet;

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method
