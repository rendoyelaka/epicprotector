.class public final La_555DBC0F;
.super Ldw;
# validated-40651
# generated-93163
# compiled-28076
.source "zwpglutf.java"
# ep-nzzttmwnigip


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lfw;->y()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Law;


# direct methods
.method public constructor <init>(Law;)V
    .locals 0

    iput-object p1, p0, La_555DBC0F;->a:Law;

    invoke-direct {p0}, Ldw;-><init>()V

    return-void
.end method


# virtual methods
.method public final d(Law;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_555DBC0F;->a:Law;

    .line 3
    invoke-virtual {v0}, Law;->y()V

    .line 6
    invoke-virtual {p1, p0}, Law;->v(La_A8D05313;)V

    .line 9
    return-void
.end method
