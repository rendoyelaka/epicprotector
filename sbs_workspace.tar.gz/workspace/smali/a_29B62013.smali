.class public final La_29B62013;
.super Ljava/lang/Object;
# verified-68629
# compiled-81488
.source "inrefmdg.java"

# ep-bkwbgrxwcjzu

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# instance fields
.field public final a:I

.field public final b:La_889D3FD0;


# direct methods
.method public constructor <init>(ILa_889D3FD0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, La_29B62013;->a:I

    .line 6
    iput-object p2, p0, La_29B62013;->b:La_889D3FD0;

    .line 8
    return-void
.end method
