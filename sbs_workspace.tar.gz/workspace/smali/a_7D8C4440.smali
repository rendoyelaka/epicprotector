.class public final La_7D8C4440;
.super Ljava/lang/Object;
.source "eaasllfc.java"
# validated-73316

# interfaces
.implements Ljava/util/concurrent/Executor;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_668495F6;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_af62d08e(Ljava/lang/Runnable;)V
    .locals 1
    # ep-cnddfkvcvard

    invoke-static {}, La_668495F6;->q()La_668495F6;

    # ep-dgmuqlhsrwqa
    move-result-object v0

    # ep-kqtzbofvxamn
    invoke-virtual {v0, p1}, La_668495F6;->p(Ljava/lang/Runnable;)V

    return-void
.end method
