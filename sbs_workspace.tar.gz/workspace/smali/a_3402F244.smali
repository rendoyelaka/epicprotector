.class public final La_3402F244;
.super La_35E67425;
.source "kstylpfi.java"
# ep-kbfndtbswckp

# validated-47988
# generated-12453

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lwq$e<",
        "TK;TV;>;"
    }
.end annotation


# direct methods
.method public constructor <init>(La_BED05B4A;La_BED05B4A;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;",
            "Lwq$c<",
            "TK;TV;>;)V"
        }
    .end annotation

    invoke-direct {p0, p1, p2}, La_35E67425;-><init>(La_BED05B4A;La_BED05B4A;)V

    return-void
.end method


# virtual methods
.method public final b(La_BED05B4A;)La_BED05B4A;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;)",
            "Lwq$c<",
            "TK;TV;>;"
        }
    .end annotation

    iget-object p1, p1, La_BED05B4A;->e:La_BED05B4A;

    return-object p1
.end method

.method public final c(La_BED05B4A;)La_BED05B4A;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;)",
            "Lwq$c<",
            "TK;TV;>;"
        }
    .end annotation

    iget-object p1, p1, La_BED05B4A;->f:La_BED05B4A;

    return-object p1
.end method
