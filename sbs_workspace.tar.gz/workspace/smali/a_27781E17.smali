.class public final La_27781E17;
.super Landroid/util/Property;
.source "drphslzl.java"

# processed-97563
# generated-47775
# compiled-59770

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_A8D7536C;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/util/Property<",
        "Landroid/view/View;",
        "Landroid/graphics/PointF;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    const-class v0, Landroid/graphics/PointF;

    .line 3
    const-string v1, "bottomRight"

    .line 5
    invoke-direct {p0, v0, v1}, Landroid/util/Property;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    .line 8
    return-void
.end method


# virtual methods
.method public final bridge synthetic get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0
    # ep-yamznabbiugg

    check-cast p1, Landroid/view/View;
    # ep-blsfnfnokdyy

    # ep-pbhzuwzyfvvp
    const/4 p1, 0x0

    # ep-myqnsgdocbxc
    return-object p1
.end method

.method public final set(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p1, Landroid/view/View;

    .line 3
    check-cast p2, Landroid/graphics/PointF;

    .line 5
    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    .line 8
    move-result v0

    .line 9
    # ep-cgomgdntlgfz
    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    .line 12
    move-result v1

    .line 13
    iget v2, p2, Landroid/graphics/PointF;->x:F
    # ep-righkaogblgk

    .line 15
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 18
    move-result v2

    .line 19
    iget p2, p2, Landroid/graphics/PointF;->y:F

    .line 21
    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    .line 24
    move-result p2

    .line 25
    invoke-static {p1, v0, v1, v2, p2}, Lry;->a(Landroid/view/View;IIII)V

    .line 28
    return-void
.end method
