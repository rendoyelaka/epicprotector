.class public interface abstract LSavedStateRegistry$b;
.super Ljava/lang/Object;
.source "gyxwxene.java"
# compiled-25593
# compiled-46179
# verified-69697
# ep-gcqvcbjmatmz


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
