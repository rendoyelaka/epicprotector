.class public interface abstract LSavedStateRegistry$b;
.super Ljava/lang/Object;
.source "azgnjowy.java"
# ep-ftehpzqbfpln
# processed-42942
# generated-52756
# compiled-51519


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
