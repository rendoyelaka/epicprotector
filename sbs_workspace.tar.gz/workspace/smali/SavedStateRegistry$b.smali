.class public interface abstract LSavedStateRegistry$b;
# ep-vrfwdbcirbnk
# validated-93060
.super Ljava/lang/Object;
.source "prsmjrob.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
