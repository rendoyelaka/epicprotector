.class public interface abstract LSavedStateRegistry$b;
# provider-87866-activity
# helper-86303-manager
.super Ljava/lang/Object;
# ep-pilzpysqxaen
# generated-64727
# compiled-60330
# validated-65449
.source "EntityMapper95.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
