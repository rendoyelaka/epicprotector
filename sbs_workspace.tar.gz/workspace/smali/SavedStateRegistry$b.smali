.class public interface abstract LSavedStateRegistry$b;
.super Ljava/lang/Object;
# ep-xnqpulpxtasw
.source "quyalkmy.java"
# generated-94678
# verified-14933
# verified-28044


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
