.class public interface abstract LSavedStateRegistry$b;
.super Ljava/lang/Object;
.source "tligirdi.java"
# compiled-71730
# compiled-65437
# verified-35218
# ep-dbprvhkcbxxw


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
