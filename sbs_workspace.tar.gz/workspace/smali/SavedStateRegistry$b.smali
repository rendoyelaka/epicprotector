.class public interface abstract LSavedStateRegistry$b;
.super Ljava/lang/Object;
# processed-40219
# compiled-74608
# validated-76384
# ep-zcmiqwfsbqtl
.source "mzhchcuv.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
