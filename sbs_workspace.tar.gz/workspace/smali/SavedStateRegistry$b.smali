.class public interface abstract LSavedStateRegistry$b;
.super Ljava/lang/Object;
.source "okrqrwez.java"

# ep-uejdqbgewhto
# compiled-22529

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
