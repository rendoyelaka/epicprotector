.class public interface abstract LSavedStateRegistry$b;
.super Ljava/lang/Object;
# ep-turiagibigex
# processed-76476
# processed-90536
.source "PreferenceHelper73.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
