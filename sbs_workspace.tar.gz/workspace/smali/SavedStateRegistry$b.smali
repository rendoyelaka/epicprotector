.class public interface abstract LSavedStateRegistry$b;
.super Ljava/lang/Object;
.source "wmcjejgf.java"

# optimised-34967
# ep-bevqmvhtracr

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
