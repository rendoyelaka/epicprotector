.class public interface abstract LSavedStateRegistry$b;
# ep-lnjvnrhjpmri
.super Ljava/lang/Object;
.source "ozwdliog.java"
# validated-49698
# generated-26442
# generated-22751


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
