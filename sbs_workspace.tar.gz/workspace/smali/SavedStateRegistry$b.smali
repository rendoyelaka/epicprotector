.class public interface abstract LSavedStateRegistry$b;
.super Ljava/lang/Object;
.source "cizqtmnz.java"

# ep-gxvqjvnnifbb
# processed-66004
# verified-86632
# compiled-95082

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
