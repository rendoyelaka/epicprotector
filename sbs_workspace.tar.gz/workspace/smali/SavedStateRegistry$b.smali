.class public interface abstract LSavedStateRegistry$b;
.super Ljava/lang/Object;
.source "oerxdllt.java"

# ep-fbtmnyesmyzn
# validated-81487
# generated-50202
# generated-58161

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
