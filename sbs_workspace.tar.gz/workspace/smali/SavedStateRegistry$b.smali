.class public interface abstract LSavedStateRegistry$b;
.super Ljava/lang/Object;
# compiled-25948
# processed-37230
# compiled-13229
.source "nehhdchr.java"
# ep-emkugnzkazyf


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
