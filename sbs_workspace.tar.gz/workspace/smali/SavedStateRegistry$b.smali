.class public interface abstract LSavedStateRegistry$b;
# ep-wbgdzntugcpx
.super Ljava/lang/Object;
# validated-98452
.source "befcslrh.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
