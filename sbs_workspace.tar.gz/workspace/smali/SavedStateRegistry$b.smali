.class public interface abstract LSavedStateRegistry$b;
.super Ljava/lang/Object;
.source "xezxuprl.java"
# compiled-53932
# generated-19507

# ep-tmaqmrfiqwxd

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
