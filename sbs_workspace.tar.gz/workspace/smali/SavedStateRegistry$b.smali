.class public interface abstract LSavedStateRegistry$b;
.super Ljava/lang/Object;
.source "jxcxzxhy.java"

# compiled-83519
# validated-33984
# validated-97411
# ep-safweineqmhf

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
