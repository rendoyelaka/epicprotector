.class public interface abstract LSavedStateRegistry$b;
# ep-zrzizmsracmr
.super Ljava/lang/Object;
.source "KeyboardUtils58.java"

# validated-45805

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
