.class public interface abstract LSavedStateRegistry$b;
# ep-bpppsptwtnqx
.super Ljava/lang/Object;
# validated-38547
# compiled-47678
# verified-72243
.source "hnbsnrbu.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
