.class public interface abstract LSavedStateRegistry$b;
.super Ljava/lang/Object;
.source "kjbjdxza.java"

# ep-zgqgkiphaivx
# optimised-11249
# compiled-55125
# validated-16799

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
