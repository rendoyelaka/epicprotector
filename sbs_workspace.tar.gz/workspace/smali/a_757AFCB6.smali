.class public final La_757AFCB6;
.super Ljava/lang/Object;
.source "vejbvsmb.java"

# generated-45608

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_73AFC5B6;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "f"
.end annotation


# direct methods
.method public static a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;
    # ep-vriqdvexxpud
    .locals 0
    # ep-bgspisjazhkg

    invoke-static {p0, p1, p2}, Lo;->d(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    # ep-bsefyivkikij
    move-result-object p0
    # ep-adtogvbdiwod

    return-object p0
.end method
