.class public final LOkHttpDispatcher;
.super Ljava/lang/Object;
.source "riiuyqqz.java"
# processed-51181

# ep-nxlvygdmcsfn

# instance fields
.field public a:Ljava/util/concurrent/ThreadPoolExecutor;

.field public final b:Ljava/util/ArrayDeque;

.field public final c:Ljava/util/ArrayDeque;

.field public final d:Ljava/util/ArrayDeque;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/ArrayDeque;

    .line 6
    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    .line 9
    iput-object v0, p0, LOkHttpDispatcher;->b:Ljava/util/ArrayDeque;

    .line 11
    new-instance v0, Ljava/util/ArrayDeque;

    .line 13
    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    .line 16
    iput-object v0, p0, LOkHttpDispatcher;->c:Ljava/util/ArrayDeque;

    .line 18
    new-instance v0, Ljava/util/ArrayDeque;

    .line 20
    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    .line 23
    iput-object v0, p0, LOkHttpDispatcher;->d:Ljava/util/ArrayDeque;

    .line 25
    return-void
.end method


# virtual methods
.method public final declared-synchronized a(Ldp$a;)V
    .locals 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, LOkHttpDispatcher;->c:Ljava/util/ArrayDeque;

    .line 4
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->size()I

    .line 7
    move-result v0

    .line 8
    const/16 v1, 0x40

    .line 10
    if-ge v0, v1, :cond_0

    .line 12
    invoke-virtual {p0, p1}, LOkHttpDispatcher;->f(Ldp$a;)I

    .line 15
    move-result v0

    .line 16
    const/4 v1, 0x5

    .line 17
    if-ge v0, v1, :cond_0

    .line 19
    iget-object v0, p0, LOkHttpDispatcher;->c:Ljava/util/ArrayDeque;

    .line 21
    invoke-virtual {v0, p1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    .line 24
    invoke-virtual {p0}, LOkHttpDispatcher;->b()Ljava/util/concurrent/ExecutorService;

    .line 27
    move-result-object v0

    .line 28
    check-cast v0, Ljava/util/concurrent/ThreadPoolExecutor;

    .line 30
    invoke-virtual {v0, p1}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 33
    goto :goto_0

    .line 34
    :cond_0
    iget-object v0, p0, LOkHttpDispatcher;->b:Ljava/util/ArrayDeque;

    .line 36
    invoke-virtual {v0, p1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 39
    :goto_0
    monitor-exit p0

    .line 40
    return-void

    .line 41
    :catchall_0
    move-exception p1

    .line 42
    monitor-exit p0

    .line 43
    throw p1
.end method

.method public final declared-synchronized b()Ljava/util/concurrent/ExecutorService;
    .locals 10

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, LOkHttpDispatcher;->a:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 4
    if-nez v0, :cond_0

    .line 6
    new-instance v0, Ljava/util/concurrent/ThreadPoolExecutor;

    .line 8
    const/4 v2, 0x0

    .line 9
    const v3, 0x7fffffff

    .line 12
    const-wide/16 v4, 0x3c

    .line 14
    sget-object v6, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 16
    new-instance v7, Ljava/util/concurrent/SynchronousQueue;

    .line 18
    invoke-direct {v7}, Ljava/util/concurrent/SynchronousQueue;-><init>()V

    .line 21
    const-string v1, "OkHttp Dispatcher"

    .line 23
    sget-object v8, Lex;->a:[B

    .line 25
    new-instance v8, Lcx;

    .line 27
    const/4 v9, 0x0

    .line 28
    invoke-direct {v8, v1, v9}, Lcx;-><init>(Ljava/lang/String;Z)V

    .line 31
    move-object v1, v0

    .line 32
    invoke-direct/range {v1 .. v8}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    .line 35
    iput-object v0, p0, LOkHttpDispatcher;->a:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 37
    :cond_0
    iget-object v0, p0, LOkHttpDispatcher;->a:Ljava/util/concurrent/ThreadPoolExecutor;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 39
    monitor-exit p0

    .line 40
    return-object v0

    .line 41
    :catchall_0
    move-exception v0

    .line 42
    monitor-exit p0

    .line 43
    throw v0
.end method

.method public final c(Ldp$a;)V
    .locals 1

    .line 1
    iget-object v0, p0, LOkHttpDispatcher;->c:Ljava/util/ArrayDeque;

    .line 3
    monitor-enter p0

    .line 4
    :try_start_0
    invoke-virtual {v0, p1}, Ljava/util/ArrayDeque;->remove(Ljava/lang/Object;)Z

    .line 7
    move-result p1

    .line 8
    if-eqz p1, :cond_0

    .line 10
    invoke-virtual {p0}, LOkHttpDispatcher;->d()V

    .line 13
    invoke-virtual {p0}, LOkHttpDispatcher;->e()V

    .line 16
    monitor-exit p0

    .line 17
    return-void

    .line 18
    :cond_0
    new-instance p1, Ljava/lang/AssertionError;

    .line 20
    const-string v0, "Call wasn\'t in-flight!"

    .line 22
    invoke-direct {p1, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 25
    throw p1

    .line 26
    :catchall_0
    move-exception p1

    .line 27
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 28
    throw p1
.end method

.method public final d()V
    .locals 6

    .line 1
    iget-object v0, p0, LOkHttpDispatcher;->c:Ljava/util/ArrayDeque;

    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->size()I

    .line 6
    move-result v1

    .line 7
    const/16 v2, 0x40

    .line 9
    if-lt v1, v2, :cond_0

    .line 11
    return-void

    .line 12
    :cond_0
    iget-object v1, p0, LOkHttpDispatcher;->b:Ljava/util/ArrayDeque;

    .line 14
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 17
    move-result v3

    .line 18
    if-eqz v3, :cond_1

    .line 20
    return-void

    .line 21
    :cond_1
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->iterator()Ljava/util/Iterator;

    .line 24
    move-result-object v1

    .line 25
    :cond_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 28
    move-result v3

    .line 29
    if-eqz v3, :cond_4

    .line 31
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 34
    move-result-object v3

    .line 35
    check-cast v3, Ldp$a;

    .line 37
    invoke-virtual {p0, v3}, LOkHttpDispatcher;->f(Ldp$a;)I

    .line 40
    move-result v4

    .line 41
    const/4 v5, 0x5

    .line 42
    if-ge v4, v5, :cond_3

    .line 44
    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    .line 47
    invoke-virtual {v0, v3}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    .line 50
    invoke-virtual {p0}, LOkHttpDispatcher;->b()Ljava/util/concurrent/ExecutorService;

    .line 53
    move-result-object v4

    .line 54
    check-cast v4, Ljava/util/concurrent/ThreadPoolExecutor;

    .line 56
    invoke-virtual {v4, v3}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 59
    :cond_3
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->size()I

    .line 62
    move-result v3

    .line 63
    if-lt v3, v2, :cond_2

    .line 65
    :cond_4
    return-void
.end method

.method public final declared-synchronized e()V
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, LOkHttpDispatcher;->c:Ljava/util/ArrayDeque;

    .line 4
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->size()I

    .line 7
    iget-object v0, p0, LOkHttpDispatcher;->d:Ljava/util/ArrayDeque;

    .line 9
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->size()I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 12
    monitor-exit p0

    .line 13
    return-void

    .line 14
    :catchall_0
    move-exception v0

    .line 15
    monitor-exit p0

    .line 16
    throw v0
.end method

.method public final f(Ldp$a;)I
    .locals 4

    .line 1
    iget-object v0, p0, LOkHttpDispatcher;->c:Ljava/util/ArrayDeque;

    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->iterator()Ljava/util/Iterator;

    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x0

    .line 8
    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 11
    move-result v2

    .line 12
    if-eqz v2, :cond_1

    .line 14
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 17
    move-result-object v2

    .line 18
    check-cast v2, Ldp$a;

    .line 20
    iget-object v2, v2, Ldp$a;->e:Ldp;

    .line 22
    iget-object v2, v2, Ldp;->e:Lnp;

    .line 24
    iget-object v2, v2, Lnp;->a:Lih;

    .line 26
    iget-object v2, v2, Lih;->d:Ljava/lang/String;

    .line 28
    iget-object v3, p1, Ldp$a;->e:Ldp;

    .line 30
    iget-object v3, v3, Ldp;->e:Lnp;

    .line 32
    iget-object v3, v3, Lnp;->a:Lih;

    .line 34
    iget-object v3, v3, Lih;->d:Ljava/lang/String;

    .line 36
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 39
    move-result v2

    .line 40
    if-eqz v2, :cond_0

    .line 42
    add-int/lit8 v1, v1, 0x1

    .line 44
    goto :goto_0

    .line 45
    :cond_1
    return v1
.end method
