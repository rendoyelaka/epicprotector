.class public final La_83EF87B9;
.super Ljava/lang/Object;
# verified-26659
.source "fkfmfsny.java"

# interfaces
.implements La_969E5A20;


# instance fields
.field public final synthetic a:Landroid/animation/Animator;


# direct methods
.method public constructor <init>(Landroid/animation/Animator;)V
    .locals 0

    iput-object p1, p0, La_83EF87B9;->a:Landroid/animation/Animator;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCancel()V
    .locals 1

    # ep-bzukohwwhrpd
    iget-object v0, p0, La_83EF87B9;->a:Landroid/animation/Animator;

    # ep-uvjlrwnswibb
    invoke-virtual {v0}, Landroid/animation/Animator;->end()V

    # ep-wlzzezbqrimc
    return-void
.end method
