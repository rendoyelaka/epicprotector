.class public final La_2CE2CE43;
.super Ljava/lang/Object;
.source "aqgbnbfn.java"
# generated-10391
# compiled-31092
# generated-28314


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_904C1018;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation


# instance fields
.field public a:F

.field public b:F

.field public c:F


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(FFF)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p1, p0, La_2CE2CE43;->a:F

    .line 3
    iput p2, p0, La_2CE2CE43;->b:F

    .line 4
    iput p3, p0, La_2CE2CE43;->c:F

    return-void
.end method
