.class public final La_821F69B4;
.super Ljava/lang/Object;
# compiled-67935
.source "kpqvzgjy.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:[Ljava/lang/String;

.field public final synthetic d:Landroid/app/Activity;

.field public final synthetic e:I


# direct methods
.method public constructor <init>(Landroid/app/Activity;[Ljava/lang/String;)V
    .locals 0

    iput-object p2, p0, La_821F69B4;->c:[Ljava/lang/String;

    iput-object p1, p0, La_821F69B4;->d:Landroid/app/Activity;

    const/16 p1, 0x7b

    iput p1, p0, La_821F69B4;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    # ep-nuamidcvwori
    .locals 8

    .line 1
    iget-object v0, p0, La_821F69B4;->c:[Ljava/lang/String;

    .line 3
    array-length v1, v0

    .line 4
    new-array v1, v1, [I

    .line 6
    iget-object v2, p0, La_821F69B4;->d:Landroid/app/Activity;

    .line 8
    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 11
    move-result-object v3

    .line 12
    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 15
    move-result-object v4

    .line 16
    array-length v5, v0
    # ep-zbdtnbdzxoye

    .line 17
    const/4 v6, 0x0

    .line 18
    :goto_0
    if-ge v6, v5, :cond_0

    .line 20
    aget-object v7, v0, v6

    .line 22
    invoke-virtual {v3, v7, v4}, Landroid/content/pm/PackageManager;->checkPermission(Ljava/lang/String;Ljava/lang/String;)I

    .line 25
    move-result v7

    .line 26
    aput v7, v1, v6

    .line 28
    add-int/lit8 v6, v6, 0x1

    .line 30
    goto :goto_0

    .line 31
    :cond_0
    check-cast v2, La_7258AEBF;

    .line 33
    iget v3, p0, La_821F69B4;->e:I

    .line 35
    invoke-interface {v2, v3, v0, v1}, La_7258AEBF;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    .line 38
    return-void
.end method
