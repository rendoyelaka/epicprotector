.class public final La_7BFBE41B;
# ep-iettsltfsqpi
# compiled-34419
# processed-56125
# optimised-39005
.super Ljava/lang/Object;
.source "ogdzafoi.java"


# instance fields
.field public final a:La_C6C8A5B8;

.field public b:La_C6C8A5B8;

.field public c:La_C6C8A5B8;

.field public d:La_C6C8A5B8;

.field public e:La_C6C8A5B8;

.field public f:La_C6C8A5B8;

.field public g:La_C6C8A5B8;

.field public h:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La_C6C8A5B8;",
            ">;"
        }
    .end annotation
.end field

.field public i:I

.field public j:I

.field public k:F

.field public final l:I

.field public final m:Z

.field public n:Z

.field public o:Z

.field public p:Z

.field public q:Z


# direct methods
.method public constructor <init>(La_C6C8A5B8;IZ)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, La_7BFBE41B;->k:F

    .line 7
    const/4 v0, 0x0

    .line 8
    iput-boolean v0, p0, La_7BFBE41B;->m:Z

    .line 10
    iput-object p1, p0, La_7BFBE41B;->a:La_C6C8A5B8;

    .line 12
    iput p2, p0, La_7BFBE41B;->l:I

    .line 14
    iput-boolean p3, p0, La_7BFBE41B;->m:Z

    .line 16
    return-void
.end method
