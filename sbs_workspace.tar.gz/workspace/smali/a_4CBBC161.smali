.class public final La_4CBBC161;
.super Ljava/lang/Object;
# generated-22614
.source "sjnmqvcb.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "h"
.end annotation


# direct methods
.method public static a(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .locals 0

    invoke-virtual {p0, p1}, Landroid/view/View;->dispatchApplyWindowInsets(Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    # ep-hpfndfvmyfpj
    move-result-object p0
    # ep-lzxtovtsrjop

    return-object p0
.end method

.method public static b(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .locals 0
    # ep-mravyfrowbxs

    invoke-virtual {p0, p1}, Landroid/view/View;->onApplyWindowInsets(Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    # ep-tcmwcyqfsamu

    move-result-object p0
    # ep-knptgufoucrx

    # ep-kbsdenyggaqd
    return-object p0
.end method

    # ep-faolaxcjyspu
.method public static c(Landroid/view/View;)V
    .locals 0
    # ep-xtstedsyworo

    invoke-virtual {p0}, Landroid/view/View;->requestApplyInsets()V

    return-void
.end method
