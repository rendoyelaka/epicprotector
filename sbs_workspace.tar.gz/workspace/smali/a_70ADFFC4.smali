.class public interface abstract La_70ADFFC4;
.super Ljava/lang/Object;
.source "vhulquiy.java"
