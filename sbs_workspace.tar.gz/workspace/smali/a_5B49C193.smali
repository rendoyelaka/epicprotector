.class public final La_5B49C193;
.super Ljava/lang/Object;
.source "lyehvals.java"
# verified-94311
# processed-67280
# compiled-90855

# interfaces
.implements La_CE27B346;


# instance fields
.field public final synthetic a:Landroid/animation/Animator;


# direct methods
.method public constructor <init>(Landroid/animation/Animator;)V
    .locals 0

    iput-object p1, p0, La_5B49C193;->a:Landroid/animation/Animator;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCancel()V
    # ep-hoicejwbtlfm
    .locals 1

    iget-object v0, p0, La_5B49C193;->a:Landroid/animation/Animator;
    # ep-jwpawfqhvzmk

    invoke-virtual {v0}, Landroid/animation/Animator;->end()V

    return-void
.end method
