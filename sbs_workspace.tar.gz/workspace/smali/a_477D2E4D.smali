.class public final La_477D2E4D;
.super Ldw;
# ep-hwfxxevgzhcf
# validated-86191
.source "ofscmher.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_B8E3E9E8;->onPreDraw()Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_517C27AD;

.field public final synthetic b:La_B8E3E9E8;


# direct methods
.method public constructor <init>(La_B8E3E9E8;La_517C27AD;)V
    .locals 0

    iput-object p1, p0, La_477D2E4D;->b:La_B8E3E9E8;

    iput-object p2, p0, La_477D2E4D;->a:La_517C27AD;

    invoke-direct {p0}, Ldw;-><init>()V

    return-void
.end method


# virtual methods
.method public final d(Law;)V
    .locals 3

    .line 1
    iget-object v0, p0, La_477D2E4D;->b:La_B8E3E9E8;

    .line 3
    iget-object v0, v0, La_B8E3E9E8;->d:Landroid/view/ViewGroup;

    .line 5
    const/4 v1, 0x0

    .line 6
    iget-object v2, p0, La_477D2E4D;->a:La_517C27AD;

    .line 8
    invoke-virtual {v2, v0, v1}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Ljava/util/ArrayList;

    .line 14
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->m_8eb9dccd(Ljava/lang/Object;)Z

    .line 17
    invoke-virtual {p1, p0}, Law;->v(La_A8D05313;)V

    .line 20
    return-void
.end method
