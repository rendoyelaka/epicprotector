.class public final Lcn;
.super Ljava/lang/Object;
.source "ycnlbkgx.java"
# ep-sfdihohfyncx
# optimised-80000
# compiled-68422

# interfaces
.implements Lrs;


# instance fields
.field public final synthetic c:Lhv;

.field public final synthetic d:Ljava/io/InputStream;


# direct methods
.method public constructor <init>(Ljava/io/InputStream;Ldn;)V
    .locals 0

    iput-object p2, p0, Lcn;->c:Lhv;

    iput-object p1, p0, Lcn;->d:Ljava/io/InputStream;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Lhv;
    .locals 1

    iget-object v0, p0, Lcn;->c:Lhv;

    return-object v0
.end method

.method public final close()V
    .locals 1

    iget-object v0, p0, Lcn;->d:Ljava/io/InputStream;

    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    return-void
.end method

.method public final k(Lt4;J)J
    .locals 5

    .line 1
    const/4 p2, 0x1

    .line 2
    :try_start_0
    iget-object p3, p0, Lcn;->c:Lhv;

    .line 4
    invoke-virtual {p3}, Lhv;->f()V

    .line 7
    invoke-virtual {p1, p2}, Lt4;->y(I)Llr;

    .line 10
    move-result-object p3

    .line 11
    iget v0, p3, Llr;->c:I

    .line 13
    rsub-int v0, v0, 0x2000

    .line 15
    int-to-long v0, v0

    .line 16
    const-wide/16 v2, 0x2000

    .line 18
    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->min(JJ)J

    .line 21
    move-result-wide v0

    .line 22
    long-to-int v1, v0

    .line 23
    iget-object v0, p0, Lcn;->d:Ljava/io/InputStream;

    .line 25
    iget-object v2, p3, Llr;->a:[B

    .line 27
    iget v3, p3, Llr;->c:I

    .line 29
    invoke-virtual {v0, v2, v3, v1}, Ljava/io/InputStream;->read([BII)I

    .line 32
    move-result v0

    .line 33
    const/4 v1, -0x1

    .line 34
    if-ne v0, v1, :cond_0

    .line 36
    const-wide/16 p1, -0x1

    .line 38
    return-wide p1

    .line 39
    :cond_0
    iget v1, p3, Llr;->c:I

    .line 41
    add-int/2addr v1, v0

    .line 42
    iput v1, p3, Llr;->c:I

    .line 44
    iget-wide v1, p1, Lt4;->d:J

    .line 46
    int-to-long v3, v0

    .line 47
    add-long/2addr v1, v3

    .line 48
    iput-wide v1, p1, Lt4;->d:J
    :try_end_0
    .catch Ljava/lang/AssertionError; {:try_start_0 .. :try_end_0} :catch_0

    .line 50
    return-wide v3

    .line 51
    :catch_0
    move-exception p1

    .line 52
    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 55
    move-result-object p3

    .line 56
    if-eqz p3, :cond_1

    .line 58
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 61
    move-result-object p3

    .line 62
    if-eqz p3, :cond_1

    .line 64
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 67
    move-result-object p3

    .line 68
    const-string v0, "08hwAlN5FNBnk4lq2PsyFWaC"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 70
    invoke-virtual {p3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 73
    move-result p3

    .line 74
    if-eqz p3, :cond_1

    .line 76
    goto :goto_0

    .line 77
    :cond_1
    const/4 p2, 0x0

    .line 78
    :goto_0
    if-eqz p2, :cond_2

    .line 80
    new-instance p2, Ljava/io/IOException;

    .line 82
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    .line 85
    throw p2

    .line 86
    :cond_2
    throw p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "x8JxA19/Vw=="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcn;->d:Ljava/io/InputStream;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
