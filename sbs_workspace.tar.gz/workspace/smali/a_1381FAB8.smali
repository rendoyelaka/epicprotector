.class public final La_1381FAB8;
.super Landroid/view/View$BaseSavedState;
.source "snaivygt.java"


# processed-88236
# validated-73986
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_D1DAB849;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "h"
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "La_1381FAB8;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public c:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_01C73107;

    invoke-direct {v0}, La_01C73107;-><init>()V

    sput-object v0, La_1381FAB8;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>(Landroid/os/Parcel;)V
    .locals 0

    .line 2
    invoke-direct {p0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcel;)V

    .line 3
    invoke-virtual {p1}, Landroid/os/Parcel;->m_8ea20194()B

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iput-boolean p1, p0, La_1381FAB8;->c:Z

    return-void
.end method

.method public constructor <init>(Landroid/os/Parcelable;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcelable;)V

    return-void
.end method


# virtual methods
.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 0
    # ep-zkwrqeahtmnv

    # ep-ltbknfdayftr
    .line 1
    invoke-super {p0, p1, p2}, Landroid/view/View$BaseSavedState;->writeToParcel(Landroid/os/Parcel;I)V

    .line 4
    iget-boolean p2, p0, La_1381FAB8;->c:Z

    # ep-dbfywlginztr
    .line 6
    int-to-byte p2, p2

    # ep-mfmxpqafpyfq
    .line 7
    invoke-virtual {p1, p2}, Landroid/os/Parcel;->m_89a00f55(B)V

    .line 10
    return-void
.end method
