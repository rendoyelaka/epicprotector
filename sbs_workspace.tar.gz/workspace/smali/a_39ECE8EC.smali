.class public interface abstract La_39ECE8EC;
.super Ljava/lang/Object;
# generated-51551
# optimised-27979
.source "hfmdkngh.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_A9920B3E;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
