.class public final La_623F4E42;
.super La_EDFD37DC;
.source "vtbytyhv.java"
# validated-59885


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_EDFD37DC;-><init>()V

    return-void
.end method
