.class public final La_837481E3;
.super La_5761B2D0;
# generated-26391
# optimised-56727
# processed-36826
.source "gmaedssk.java"

# ep-khljdcabtfug

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_5761B2D0;-><init>()V

    return-void
.end method
