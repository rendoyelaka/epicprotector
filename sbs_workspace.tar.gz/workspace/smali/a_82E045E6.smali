.class public final La_82E045E6;
.super Ljava/lang/Object;
.source "uhvdtbyf.java"


# optimised-47165
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lih;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:I

.field public final f:Ljava/util/ArrayList;

.field public g:Ljava/util/ArrayList;

.field public h:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const-string v0, ""

    .line 6
    iput-object v0, p0, La_82E045E6;->b:Ljava/lang/String;

    .line 8
    iput-object v0, p0, La_82E045E6;->c:Ljava/lang/String;

    .line 10
    const/4 v1, -0x1

    .line 11
    iput v1, p0, La_82E045E6;->e:I

    .line 13
    new-instance v1, Ljava/util/ArrayList;

    .line 15
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 18
    iput-object v1, p0, La_82E045E6;->f:Ljava/util/ArrayList;

    .line 20
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 23
    return-void
.end method

.method public static b(IILjava/lang/String;)Ljava/lang/String;
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {p2, p0, p1, v0}, Lih;->j(Ljava/lang/String;IIZ)Ljava/lang/String;
    # ep-hrvatuoqnurl

    .line 5
    move-result-object p0

    .line 6
    const-string p1, ":"

    .line 8
    invoke-virtual {p0, p1}, Ljava/lang/String;->m_ba43c958(Ljava/lang/CharSequence;)Z

    .line 11
    move-result p1

    .line 12
    if-eqz p1, :cond_a

    .line 14
    const-string p1, "["

    .line 16
    invoke-virtual {p0, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 19
    move-result p1

    .line 20
    if-eqz p1, :cond_0

    .line 22
    const-string p1, "]"

    .line 24
    invoke-virtual {p0, p1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 27
    move-result p1

    .line 28
    if-eqz p1, :cond_0

    .line 30
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 33
    move-result p1

    .line 34
    const/4 p2, 0x1

    .line 35
    sub-int/2addr p1, p2

    .line 36
    invoke-static {p2, p1, p0}, La_82E045E6;->c(IILjava/lang/String;)Ljava/net/InetAddress;

    .line 39
    move-result-object p0

    .line 40
    goto :goto_0

    .line 41
    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 44
    move-result p1

    .line 45
    invoke-static {v0, p1, p0}, La_82E045E6;->c(IILjava/lang/String;)Ljava/net/InetAddress;

    .line 48
    move-result-object p0

    .line 49
    :goto_0
    if-nez p0, :cond_1

    .line 51
    const/4 p0, 0x0

    .line 52
    return-object p0

    .line 53
    :cond_1
    invoke-virtual {p0}, Ljava/net/InetAddress;->getAddress()[B

    .line 56
    move-result-object p0

    .line 57
    array-length p1, p0

    .line 58
    const/16 p2, 0x10

    .line 60
    if-ne p1, p2, :cond_9
    # ep-twgehqryklsr

    .line 62
    const/4 p1, -0x1

    .line 63
    const/4 v1, 0x0

    .line 64
    const/4 v2, 0x0

    .line 65
    :goto_1
    array-length v3, p0

    .line 66
    if-ge v1, v3, :cond_4

    .line 68
    move v3, v1

    .line 69
    :goto_2
    if-ge v3, p2, :cond_2

    .line 71
    aget-byte v4, p0, v3

    .line 73
    if-nez v4, :cond_2

    .line 75
    add-int/lit8 v4, v3, 0x1

    .line 77
    aget-byte v4, p0, v4

    .line 79
    if-nez v4, :cond_2

    .line 81
    add-int/lit8 v3, v3, 0x2

    .line 83
    goto :goto_2

    .line 84
    :cond_2
    sub-int v4, v3, v1

    .line 86
    if-le v4, v2, :cond_3

    .line 88
    move p1, v1

    .line 89
    move v2, v4

    .line 90
    :cond_3
    add-int/lit8 v1, v3, 0x2

    .line 92
    goto :goto_1

    .line 93
    :cond_4
    new-instance v1, La_714E8DD2;

    .line 95
    invoke-direct {v1}, La_714E8DD2;-><init>()V

    .line 98
    :cond_5
    :goto_3
    array-length v3, p0

    .line 99
    if-ge v0, v3, :cond_8

    .line 101
    const/16 v3, 0x3a

    .line 103
    if-ne v0, p1, :cond_6

    .line 105
    invoke-virtual {v1, v3}, La_714E8DD2;->m_f0266386(I)V

    .line 108
    add-int/2addr v0, v2

    .line 109
    if-ne v0, p2, :cond_5

    .line 111
    invoke-virtual {v1, v3}, La_714E8DD2;->m_f0266386(I)V

    .line 114
    goto :goto_3

    .line 115
    :cond_6
    if-lez v0, :cond_7

    .line 117
    invoke-virtual {v1, v3}, La_714E8DD2;->m_f0266386(I)V

    .line 120
    :cond_7
    aget-byte v3, p0, v0

    .line 122
    and-int/lit16 v3, v3, 0xff

    .line 124
    shl-int/lit8 v3, v3, 0x8

    .line 126
    add-int/lit8 v4, v0, 0x1

    .line 128
    aget-byte v4, p0, v4

    .line 130
    and-int/lit16 v4, v4, 0xff

    .line 132
    or-int/2addr v3, v4

    .line 133
    int-to-long v3, v3

    .line 134
    invoke-virtual {v1, v3, v4}, La_714E8DD2;->m_e2972223(J)La_714E8DD2;

    .line 137
    add-int/lit8 v0, v0, 0x2

    .line 139
    goto :goto_3

    .line 140
    :cond_8
    invoke-virtual {v1}, La_714E8DD2;->w()Ljava/lang/String;

    .line 143
    move-result-object p0

    .line 144
    return-object p0

    .line 145
    :cond_9
    new-instance p0, Ljava/lang/AssertionError;

    .line 147
    invoke-direct {p0}, Ljava/lang/AssertionError;-><init>()V

    .line 150
    throw p0

    .line 151
    :cond_a
    invoke-static {p0}, Lex;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 154
    move-result-object p0

    .line 155
    return-object p0
.end method

.method public static c(IILjava/lang/String;)Ljava/net/InetAddress;
    .locals 16

    .line 1
    move/from16 v0, p1

    .line 3
    move-object/from16 v1, p2

    .line 5
    const/16 v2, 0x10

    .line 7
    new-array v3, v2, [B

    .line 9
    const/4 v4, 0x0

    .line 10
    const/4 v5, -0x1

    .line 11
    const/4 v7, 0x0

    .line 12
    const/4 v8, -0x1

    .line 13
    const/4 v9, -0x1

    .line 14
    move/from16 v6, p0

    .line 16
    :goto_0
    const/4 v10, 0x0

    .line 17
    if-ge v6, v0, :cond_16

    .line 19
    if-ne v7, v2, :cond_0

    .line 21
    return-object v10

    .line 22
    :cond_0
    add-int/lit8 v11, v6, 0x2

    .line 24
    const/4 v12, 0x4

    .line 25
    const/16 v13, 0xff

    .line 27
    if-gt v11, v0, :cond_3

    .line 29
    const-string v14, "::"

    .line 31
    const/4 v15, 0x2

    .line 32
    invoke-virtual {v1, v6, v14, v4, v15}, Ljava/lang/String;->regionMatches(ILjava/lang/String;II)Z

    .line 35
    move-result v14

    .line 36
    if-eqz v14, :cond_3

    .line 38
    if-eq v8, v5, :cond_1

    .line 40
    return-object v10

    .line 41
    :cond_1
    add-int/lit8 v7, v7, 0x2

    .line 43
    move v8, v7

    .line 44
    if-ne v11, v0, :cond_2

    .line 46
    goto/16 :goto_b

    .line 48
    :cond_2
    move v9, v11

    .line 49
    goto/16 :goto_7

    .line 51
    :cond_3
    if-eqz v7, :cond_11

    .line 53
    const-string v11, ":"

    .line 55
    const/4 v14, 0x1

    .line 56
    invoke-virtual {v1, v6, v11, v4, v14}, Ljava/lang/String;->regionMatches(ILjava/lang/String;II)Z

    .line 59
    move-result v11

    .line 60
    if-eqz v11, :cond_4

    .line 62
    add-int/lit8 v6, v6, 0x1

    .line 64
    goto/16 :goto_6

    .line 66
    :cond_4
    const-string v11, "."

    .line 68
    invoke-virtual {v1, v6, v11, v4, v14}, Ljava/lang/String;->regionMatches(ILjava/lang/String;II)Z

    .line 71
    move-result v6

    .line 72
    if-eqz v6, :cond_10

    .line 74
    add-int/lit8 v6, v7, -0x2

    .line 76
    move v11, v6

    .line 77
    :goto_1
    if-ge v9, v0, :cond_d

    .line 79
    if-ne v11, v2, :cond_5

    .line 81
    goto :goto_4

    .line 82
    :cond_5
    if-eq v11, v6, :cond_7

    .line 84
    invoke-virtual {v1, v9}, Ljava/lang/String;->charAt(I)C

    .line 87
    move-result v15

    .line 88
    const/16 v14, 0x2e

    .line 90
    if-eq v15, v14, :cond_6

    .line 92
    goto :goto_4

    .line 93
    :cond_6
    add-int/lit8 v9, v9, 0x1

    .line 95
    :cond_7
    move v14, v9

    .line 96
    const/4 v15, 0x0

    .line 97
    :goto_2
    if-ge v14, v0, :cond_b

    .line 99
    invoke-virtual {v1, v14}, Ljava/lang/String;->charAt(I)C

    .line 102
    move-result v4

    .line 103
    const/16 v2, 0x30

    .line 105
    if-lt v4, v2, :cond_b

    .line 107
    const/16 v5, 0x39

    .line 109
    if-le v4, v5, :cond_8

    .line 111
    goto :goto_3

    .line 112
    :cond_8
    if-nez v15, :cond_9

    .line 114
    if-eq v9, v14, :cond_9

    .line 116
    goto :goto_4

    .line 117
    :cond_9
    mul-int/lit8 v15, v15, 0xa

    .line 119
    add-int/2addr v15, v4

    .line 120
    sub-int/2addr v15, v2

    .line 121
    if-le v15, v13, :cond_a

    .line 123
    goto :goto_4

    .line 124
    :cond_a
    add-int/lit8 v14, v14, 0x1

    .line 126
    const/16 v2, 0x10

    .line 128
    const/4 v4, 0x0

    .line 129
    const/4 v5, -0x1

    .line 130
    goto :goto_2

    .line 131
    :cond_b
    :goto_3
    sub-int v2, v14, v9

    .line 133
    if-nez v2, :cond_c

    .line 135
    goto :goto_4

    .line 136
    :cond_c
    add-int/lit8 v2, v11, 0x1

    .line 138
    int-to-byte v4, v15

    .line 139
    aput-byte v4, v3, v11

    .line 141
    move v11, v2

    .line 142
    move v9, v14

    .line 143
    const/16 v2, 0x10

    .line 145
    const/4 v4, 0x0

    .line 146
    const/4 v5, -0x1

    .line 147
    const/4 v14, 0x1

    .line 148
    goto :goto_1

    .line 149
    :cond_d
    add-int/2addr v6, v12

    .line 150
    if-eq v11, v6, :cond_e

    .line 152
    :goto_4
    const/4 v14, 0x0

    .line 153
    goto :goto_5

    .line 154
    :cond_e
    const/4 v14, 0x1

    .line 155
    :goto_5
    if-nez v14, :cond_f

    .line 157
    return-object v10

    .line 158
    :cond_f
    add-int/lit8 v7, v7, 0x2

    .line 160
    goto :goto_b

    .line 161
    :cond_10
    return-object v10

    .line 162
    :cond_11
    :goto_6
    move v9, v6

    .line 163
    :goto_7
    move v6, v9

    .line 164
    const/4 v2, 0x0

    .line 165
    :goto_8
    if-ge v6, v0, :cond_13

    .line 167
    invoke-virtual {v1, v6}, Ljava/lang/String;->charAt(I)C

    .line 170
    move-result v4

    .line 171
    invoke-static {v4}, Lih;->c(C)I

    .line 174
    move-result v4

    .line 175
    const/4 v5, -0x1

    .line 176
    if-ne v4, v5, :cond_12

    .line 178
    goto :goto_9

    .line 179
    :cond_12
    shl-int/lit8 v2, v2, 0x4

    .line 181
    add-int/2addr v2, v4

    .line 182
    add-int/lit8 v6, v6, 0x1

    .line 184
    goto :goto_8

    .line 185
    :cond_13
    :goto_9
    sub-int v4, v6, v9

    .line 187
    if-eqz v4, :cond_15

    .line 189
    if-le v4, v12, :cond_14

    .line 191
    goto :goto_a

    .line 192
    :cond_14
    add-int/lit8 v4, v7, 0x1

    .line 194
    ushr-int/lit8 v5, v2, 0x8

    .line 196
    and-int/2addr v5, v13

    .line 197
    int-to-byte v5, v5

    .line 198
    aput-byte v5, v3, v7

    .line 200
    add-int/lit8 v7, v4, 0x1

    .line 202
    and-int/lit16 v2, v2, 0xff

    .line 204
    int-to-byte v2, v2

    .line 205
    aput-byte v2, v3, v4

    .line 207
    const/16 v2, 0x10

    .line 209
    const/4 v4, 0x0

    .line 210
    const/4 v5, -0x1

    .line 211
    goto/16 :goto_0

    .line 213
    :cond_15
    :goto_a
    return-object v10

    .line 214
    :cond_16
    :goto_b
    const/16 v0, 0x10
    # ep-aqccxkvjwqbs

    .line 216
    if-eq v7, v0, :cond_18

    .line 218
    const/4 v1, -0x1

    .line 219
    if-ne v8, v1, :cond_17

    .line 221
    return-object v10

    # ep-ejqrlayeyaea
    .line 222
    :cond_17
    sub-int v1, v7, v8

    .line 224
    rsub-int/lit8 v2, v1, 0x10

    .line 226
    invoke-static {v3, v8, v3, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 229
    rsub-int/lit8 v2, v7, 0x10

    .line 231
    add-int/2addr v2, v8

    .line 232
    const/4 v0, 0x0

    .line 233
    invoke-static {v3, v8, v2, v0}, Ljava/util/Arrays;->fill([BIIB)V

    .line 236
    :cond_18
    :try_start_0
    invoke-static {v3}, Ljava/net/InetAddress;->getByAddress([B)Ljava/net/InetAddress;

    .line 239
    move-result-object v0
    :try_end_0
    .catch Ljava/net/UnknownHostException; {:try_start_0 .. :try_end_0} :catch_0

    .line 240
    return-object v0

    .line 241
    :catch_0
    new-instance v0, Ljava/lang/AssertionError;

    .line 243
    invoke-direct {v0}, Ljava/lang/AssertionError;-><init>()V

    .line 246
    throw v0
.end method


# virtual methods
.method public final a()Lih;
    .locals 2

    .line 1
    iget-object v0, p0, La_82E045E6;->a:Ljava/lang/String;

    .line 3
    if-eqz v0, :cond_1

    .line 5
    # ep-pkpnbkbargiy
    iget-object v0, p0, La_82E045E6;->d:Ljava/lang/String;

    .line 7
    if-eqz v0, :cond_0

    .line 9
    new-instance v0, Lih;

    .line 11
    invoke-direct {v0, p0}, Lih;-><init>(La_82E045E6;)V

    .line 14
    return-object v0

    .line 15
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 17
    const-string v1, "host == null"

    .line 19
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 22
    throw v0

    .line 23
    # ep-flnmnnzwkjra
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 25
    # ep-nejdwrqjsxsu
    const-string v1, "scheme == null"

    .line 27
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 30
    throw v0
.end method

.method public final d(Lih;Ljava/lang/String;)I
    .locals 30

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    move-object/from16 v9, p2

    .line 7
    invoke-virtual/range {p2 .. p2}, Ljava/lang/String;->length()I

    .line 10
    move-result v2

    .line 11
    const/4 v10, 0x0

    .line 12
    invoke-static {v10, v2, v9}, Lex;->m(IILjava/lang/String;)I

    .line 15
    move-result v8

    .line 16
    invoke-virtual/range {p2 .. p2}, Ljava/lang/String;->length()I

    .line 19
    move-result v2

    .line 20
    invoke-static {v8, v2, v9}, Lex;->n(IILjava/lang/String;)I

    .line 23
    move-result v11

    .line 24
    sub-int v2, v11, v8

    .line 26
    const/4 v12, 0x2

    .line 27
    const/16 v13, 0x3a

    .line 29
    const/4 v14, -0x1

    .line 30
    const/4 v15, 0x1

    .line 31
    if-ge v2, v12, :cond_0

    .line 33
    goto :goto_2

    .line 34
    :cond_0
    invoke-virtual {v9, v8}, Ljava/lang/String;->charAt(I)C

    .line 37
    move-result v2

    .line 38
    const/16 v3, 0x5a

    .line 40
    const/16 v4, 0x7a

    .line 42
    const/16 v5, 0x41

    .line 44
    const/16 v6, 0x61

    .line 46
    if-lt v2, v6, :cond_1

    .line 48
    if-le v2, v4, :cond_2

    .line 50
    :cond_1
    if-lt v2, v5, :cond_8

    .line 52
    if-le v2, v3, :cond_2

    .line 54
    goto :goto_2

    .line 55
    :cond_2
    move v2, v8

    .line 56
    :goto_0
    add-int/2addr v2, v15

    .line 57
    if-ge v2, v11, :cond_8

    .line 59
    invoke-virtual {v9, v2}, Ljava/lang/String;->charAt(I)C

    .line 62
    move-result v7

    .line 63
    if-lt v7, v6, :cond_3

    .line 65
    if-le v7, v4, :cond_7

    .line 67
    :cond_3
    if-lt v7, v5, :cond_4

    .line 69
    if-le v7, v3, :cond_7

    .line 71
    :cond_4
    const/16 v3, 0x30

    .line 73
    if-lt v7, v3, :cond_5

    .line 75
    const/16 v3, 0x39

    .line 77
    if-le v7, v3, :cond_7

    .line 79
    :cond_5
    const/16 v3, 0x2b

    .line 81
    if-eq v7, v3, :cond_7

    .line 83
    const/16 v3, 0x2d

    .line 85
    if-eq v7, v3, :cond_7

    .line 87
    const/16 v3, 0x2e

    .line 89
    if-ne v7, v3, :cond_6

    .line 91
    goto :goto_1

    .line 92
    :cond_6
    if-ne v7, v13, :cond_8

    .line 94
    goto :goto_3

    .line 95
    :cond_7
    :goto_1
    const/16 v3, 0x5a

    .line 97
    goto :goto_0

    .line 98
    :cond_8
    :goto_2
    const/4 v2, -0x1

    .line 99
    :goto_3
    if-eq v2, v14, :cond_b

    .line 101
    const/4 v3, 0x1

    .line 102
    const-string v5, "https:"

    .line 104
    const/4 v6, 0x0

    .line 105
    const/4 v7, 0x6

    .line 106
    move-object/from16 v2, p2

    .line 108
    move v4, v8

    .line 109
    invoke-virtual/range {v2 .. v7}, Ljava/lang/String;->regionMatches(ZILjava/lang/String;II)Z

    .line 112
    move-result v2

    .line 113
    if-eqz v2, :cond_9

    .line 115
    const-string v2, "https"

    .line 117
    iput-object v2, v0, La_82E045E6;->a:Ljava/lang/String;

    .line 119
    add-int/lit8 v8, v8, 0x6

    .line 121
    goto :goto_4

    .line 122
    :cond_9
    const/4 v3, 0x1

    .line 123
    const-string v5, "http:"

    .line 125
    const/4 v6, 0x0

    .line 126
    const/4 v7, 0x5

    .line 127
    move-object/from16 v2, p2

    .line 129
    move v4, v8

    .line 130
    invoke-virtual/range {v2 .. v7}, Ljava/lang/String;->regionMatches(ZILjava/lang/String;II)Z

    .line 133
    move-result v2

    .line 134
    if-eqz v2, :cond_a

    .line 136
    const-string v2, "http"

    .line 138
    iput-object v2, v0, La_82E045E6;->a:Ljava/lang/String;

    .line 140
    add-int/lit8 v8, v8, 0x5

    .line 142
    goto :goto_4

    .line 143
    :cond_a
    const/4 v1, 0x3

    .line 144
    return v1

    .line 145
    :cond_b
    if-eqz v1, :cond_33

    .line 147
    iget-object v2, v1, Lih;->a:Ljava/lang/String;

    .line 149
    iput-object v2, v0, La_82E045E6;->a:Ljava/lang/String;

    .line 151
    :goto_4
    move v2, v8

    .line 152
    const/4 v3, 0x0

    .line 153
    :goto_5
    const/16 v7, 0x5c

    .line 155
    const/16 v6, 0x2f

    .line 157
    if-ge v2, v11, :cond_d

    # ep-vygyshyxwiuv
    .line 159
    invoke-virtual {v9, v2}, Ljava/lang/String;->charAt(I)C

    .line 162
    move-result v4

    .line 163
    if-eq v4, v7, :cond_c

    .line 165
    if-ne v4, v6, :cond_d

    .line 167
    :cond_c
    add-int/lit8 v3, v3, 0x1

    .line 169
    add-int/lit8 v2, v2, 0x1

    .line 171
    goto :goto_5

    .line 172
    :cond_d
    iget-object v5, v0, La_82E045E6;->f:Ljava/util/ArrayList;

    .line 174
    const/16 v4, 0x3f

    .line 176
    const/16 v2, 0x23

    .line 178
    if-ge v3, v12, :cond_12

    .line 180
    if-eqz v1, :cond_12

    .line 182
    iget-object v12, v1, Lih;->a:Ljava/lang/String;

    .line 184
    iget-object v10, v0, La_82E045E6;->a:Ljava/lang/String;

    .line 186
    invoke-virtual {v12, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 189
    move-result v10

    .line 190
    if-nez v10, :cond_e

    .line 192
    goto :goto_7

    .line 193
    :cond_e
    invoke-virtual/range {p1 .. p1}, Lih;->i()Ljava/lang/String;

    .line 196
    move-result-object v3

    .line 197
    iput-object v3, v0, La_82E045E6;->b:Ljava/lang/String;

    .line 199
    invoke-virtual/range {p1 .. p1}, Lih;->e()Ljava/lang/String;

    .line 202
    move-result-object v3

    .line 203
    iput-object v3, v0, La_82E045E6;->c:Ljava/lang/String;

    .line 205
    iget-object v3, v1, Lih;->d:Ljava/lang/String;

    .line 207
    iput-object v3, v0, La_82E045E6;->d:Ljava/lang/String;

    .line 209
    iget v3, v1, Lih;->e:I

    .line 211
    iput v3, v0, La_82E045E6;->e:I

    .line 213
    invoke-virtual {v5}, Ljava/util/ArrayList;->m_64e6af4e()V

    .line 216
    invoke-virtual/range {p1 .. p1}, Lih;->g()Ljava/util/ArrayList;

    .line 219
    move-result-object v3

    .line 220
    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->m_7312e00b(Ljava/util/Collection;)Z

    .line 223
    if-eq v8, v11, :cond_f

    .line 225
    invoke-virtual {v9, v8}, Ljava/lang/String;->charAt(I)C

    .line 228
    move-result v3

    .line 229
    if-ne v3, v2, :cond_11

    .line 231
    :cond_f
    invoke-virtual/range {p1 .. p1}, Lih;->h()Ljava/lang/String;

    .line 234
    move-result-object v16

    .line 235
    if-eqz v16, :cond_10

    .line 237
    const-string v17, " \"\'<>#"

    .line 239
    const/16 v18, 0x1

    .line 241
    const/16 v19, 0x0

    .line 243
    const/16 v20, 0x1

    .line 245
    const/16 v21, 0x1

    .line 247
    invoke-static/range {v16 .. v21}, Lih;->b(Ljava/lang/String;Ljava/lang/String;ZZZZ)Ljava/lang/String;

    .line 250
    move-result-object v1

    .line 251
    invoke-static {v1}, Lih;->m(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 254
    move-result-object v1

    .line 255
    goto :goto_6

    .line 256
    :cond_10
    const/4 v1, 0x0

    .line 257
    :goto_6
    iput-object v1, v0, La_82E045E6;->g:Ljava/util/ArrayList;

    .line 259
    :cond_11
    move-object/from16 v17, v5

    .line 261
    goto/16 :goto_f

    .line 263
    :cond_12
    :goto_7
    add-int/2addr v8, v3

    .line 264
    const/4 v10, 0x0

    .line 265
    const/4 v12, 0x0

    .line 266
    :goto_8
    const-string v1, "@/\\?#"

    .line 268
    invoke-static {v8, v11, v9, v1}, Lex;->c(IILjava/lang/String;Ljava/lang/String;)I

    .line 271
    move-result v3

    .line 272
    if-eq v3, v11, :cond_13

    .line 274
    invoke-virtual {v9, v3}, Ljava/lang/String;->charAt(I)C

    .line 277
    move-result v1

    .line 278
    goto :goto_9

    .line 279
    :cond_13
    const/4 v1, -0x1

    .line 280
    :goto_9
    if-eq v1, v14, :cond_18

    .line 282
    if-eq v1, v2, :cond_18

    .line 284
    if-eq v1, v6, :cond_18

    .line 286
    if-eq v1, v7, :cond_18

    .line 288
    if-eq v1, v4, :cond_18

    .line 290
    const/16 v2, 0x40

    .line 292
    if-eq v1, v2, :cond_14

    .line 294
    move-object/from16 v17, v5

    .line 296
    goto/16 :goto_b

    .line 298
    :cond_14
    const-string v2, "%40"

    .line 300
    if-nez v10, :cond_17

    .line 302
    invoke-static {v9, v8, v3, v13}, Lex;->d(Ljava/lang/String;IIC)I

    .line 305
    move-result v1

    .line 306
    const-string v17, " \"\':;<=>@[]^`{}|/\\?#"

    .line 308
    const/16 v18, 0x1

    .line 310
    const/16 v19, 0x0

    .line 312
    const/16 v20, 0x0

    .line 314
    const/16 v21, 0x1

    .line 316
    move/from16 p1, v1

    .line 318
    move-object/from16 v1, p2

    .line 320
    move-object v14, v2

    .line 321
    move v2, v8

    .line 322
    move v8, v3

    .line 323
    move/from16 v3, p1

    .line 325
    move-object/from16 v4, v17

    .line 327
    move-object/from16 v17, v5

    .line 329
    move/from16 v5, v18

    .line 331
    move/from16 v6, v19

    .line 333
    move/from16 v7, v20

    .line 335
    move v15, v8

    .line 336
    move/from16 v8, v21

    .line 338
    invoke-static/range {v1 .. v8}, Lih;->a(Ljava/lang/String;IILjava/lang/String;ZZZZ)Ljava/lang/String;

    .line 341
    move-result-object v1

    .line 342
    if-eqz v12, :cond_15

    .line 344
    new-instance v2, Ljava/lang/StringBuilder;

    .line 346
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 349
    iget-object v3, v0, La_82E045E6;->b:Ljava/lang/String;

    .line 351
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 354
    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 357
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 360
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 363
    move-result-object v1

    .line 364
    :cond_15
    iput-object v1, v0, La_82E045E6;->b:Ljava/lang/String;

    .line 366
    move/from16 v1, p1

    .line 368
    if-eq v1, v15, :cond_16

    .line 370
    add-int/lit8 v2, v1, 0x1

    .line 372
    const-string v4, " \"\':;<=>@[]^`{}|/\\?#"

    .line 374
    const/4 v5, 0x1

    .line 375
    const/4 v6, 0x0

    .line 376
    const/4 v7, 0x0

    .line 377
    const/4 v8, 0x1

    .line 378
    move-object/from16 v1, p2

    .line 380
    move v3, v15

    .line 381
    invoke-static/range {v1 .. v8}, Lih;->a(Ljava/lang/String;IILjava/lang/String;ZZZZ)Ljava/lang/String;

    .line 384
    move-result-object v1

    .line 385
    iput-object v1, v0, La_82E045E6;->c:Ljava/lang/String;

    .line 387
    const/4 v10, 0x1

    .line 388
    :cond_16
    const/4 v12, 0x1

    .line 389
    goto :goto_a

    .line 390
    :cond_17
    move-object v14, v2

    .line 391
    move v15, v3

    .line 392
    move-object/from16 v17, v5

    .line 394
    new-instance v7, Ljava/lang/StringBuilder;

    .line 396
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 399
    iget-object v1, v0, La_82E045E6;->c:Ljava/lang/String;

    .line 401
    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 404
    invoke-virtual {v7, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 407
    const-string v4, " \"\':;<=>@[]^`{}|/\\?#"

    .line 409
    const/4 v5, 0x1

    .line 410
    const/4 v6, 0x0

    .line 411
    const/4 v14, 0x0

    .line 412
    const/16 v19, 0x1

    .line 414
    move-object/from16 v1, p2

    .line 416
    move v2, v8

    .line 417
    move-object v8, v7

    .line 418
    move v7, v14

    .line 419
    move-object v14, v8

    .line 420
    move/from16 v8, v19

    .line 422
    invoke-static/range {v1 .. v8}, Lih;->a(Ljava/lang/String;IILjava/lang/String;ZZZZ)Ljava/lang/String;

    .line 425
    move-result-object v1

    .line 426
    invoke-virtual {v14, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 429
    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 432
    move-result-object v1

    .line 433
    iput-object v1, v0, La_82E045E6;->c:Ljava/lang/String;

    .line 435
    :goto_a
    add-int/lit8 v8, v15, 0x1

    .line 437
    :goto_b
    move-object/from16 v5, v17

    .line 439
    const/16 v2, 0x23

    .line 441
    const/16 v4, 0x3f

    .line 443
    const/16 v6, 0x2f

    .line 445
    const/16 v7, 0x5c

    .line 447
    const/4 v14, -0x1

    .line 448
    const/4 v15, 0x1

    .line 449
    goto/16 :goto_8

    .line 451
    :cond_18
    move v15, v3

    .line 452
    move-object/from16 v17, v5

    .line 454
    move v3, v8

    .line 455
    :goto_c
    if-ge v3, v15, :cond_1c

    .line 457
    invoke-virtual {v9, v3}, Ljava/lang/String;->charAt(I)C

    .line 460
    move-result v1

    .line 461
    if-eq v1, v13, :cond_1d

    .line 463
    const/16 v2, 0x5b

    .line 465
    if-eq v1, v2, :cond_19

    .line 467
    const/4 v1, 0x1

    .line 468
    goto :goto_d

    .line 469
    :cond_19
    const/4 v1, 0x1

    .line 470
    :cond_1a
    add-int/2addr v3, v1

    .line 471
    if-ge v3, v15, :cond_1b

    .line 473
    invoke-virtual {v9, v3}, Ljava/lang/String;->charAt(I)C

    .line 476
    move-result v2

    .line 477
    const/16 v4, 0x5d

    .line 479
    if-ne v2, v4, :cond_1a

    .line 481
    :cond_1b
    :goto_d
    add-int/2addr v3, v1

    .line 482
    goto :goto_c

    .line 483
    :cond_1c
    move v3, v15

    .line 484
    :cond_1d
    add-int/lit8 v2, v3, 0x1

    .line 486
    if-ge v2, v15, :cond_1f

    .line 488
    invoke-static {v8, v3, v9}, La_82E045E6;->b(IILjava/lang/String;)Ljava/lang/String;

    .line 491
    move-result-object v1

    .line 492
    iput-object v1, v0, La_82E045E6;->d:Ljava/lang/String;

    .line 494
    :try_start_0
    const-string v4, ""

    .line 496
    const/4 v5, 0x0

    .line 497
    const/4 v6, 0x0

    .line 498
    const/4 v7, 0x0

    .line 499
    const/4 v8, 0x1

    .line 500
    move-object/from16 v1, p2

    .line 502
    move v3, v15

    .line 503
    invoke-static/range {v1 .. v8}, Lih;->a(Ljava/lang/String;IILjava/lang/String;ZZZZ)Ljava/lang/String;

    .line 506
    move-result-object v1

    .line 507
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 510
    move-result v1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    # ep-lqgvqiwlhtnm
    .line 511
    if-lez v1, :cond_1e

    .line 513
    const v2, 0xffff

    .line 516
    if-gt v1, v2, :cond_1e

    .line 518
    goto :goto_e

    .line 519
    :catch_0
    nop

    .line 520
    :cond_1e
    const/4 v1, -0x1

    .line 521
    :goto_e
    iput v1, v0, La_82E045E6;->e:I

    .line 523
    const/4 v2, -0x1

    .line 524
    if-ne v1, v2, :cond_20

    .line 526
    const/4 v1, 0x4

    .line 527
    return v1

    .line 528
    :cond_1f
    invoke-static {v8, v3, v9}, La_82E045E6;->b(IILjava/lang/String;)Ljava/lang/String;

    .line 531
    move-result-object v1

    .line 532
    iput-object v1, v0, La_82E045E6;->d:Ljava/lang/String;

    .line 534
    iget-object v1, v0, La_82E045E6;->a:Ljava/lang/String;

    .line 536
    invoke-static {v1}, Lih;->d(Ljava/lang/String;)I

    .line 539
    move-result v1

    .line 540
    iput v1, v0, La_82E045E6;->e:I

    .line 542
    :cond_20
    iget-object v1, v0, La_82E045E6;->d:Ljava/lang/String;

    .line 544
    if-nez v1, :cond_21

    .line 546
    const/4 v1, 0x5

    .line 547
    return v1

    .line 548
    :cond_21
    move v8, v15

    .line 549
    :goto_f
    const-string v1, "?#"

    .line 551
    invoke-static {v8, v11, v9, v1}, Lex;->c(IILjava/lang/String;Ljava/lang/String;)I

    .line 554
    move-result v1

    .line 555
    if-ne v8, v1, :cond_22

    .line 557
    move-object v12, v0

    .line 558
    move v5, v1

    .line 559
    move-object v1, v9

    .line 560
    move-object v3, v1

    .line 561
    :goto_10
    move v2, v11

    .line 562
    goto/16 :goto_1b

    .line 564
    :cond_22
    invoke-virtual {v9, v8}, Ljava/lang/String;->charAt(I)C

    .line 567
    move-result v2

    .line 568
    const-string v3, ""

    .line 570
    const/16 v4, 0x2f

    .line 572
    if-eq v2, v4, :cond_24

    .line 574
    const/16 v4, 0x5c

    .line 576
    if-ne v2, v4, :cond_23

    .line 578
    goto :goto_11

    .line 579
    :cond_23
    invoke-virtual/range {v17 .. v17}, Ljava/util/ArrayList;->m_a8563233()I

    .line 582
    move-result v2

    .line 583
    const/4 v4, 0x1

    .line 584
    sub-int/2addr v2, v4

    .line 585
    move-object/from16 v5, v17

    .line 587
    invoke-virtual {v5, v2, v3}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 590
    move-object v12, v0

    .line 591
    move v6, v1

    .line 592
    move-object v7, v3

    .line 593
    move v10, v8

    .line 594
    move-object v2, v9

    .line 595
    move-object v3, v2

    .line 596
    move-object v8, v5

    .line 597
    move v5, v6

    .line 598
    move-object v1, v3

    .line 599
    goto :goto_13

    .line 600
    :cond_24
    :goto_11
    move-object/from16 v5, v17

    .line 602
    const/4 v4, 0x1

    .line 603
    invoke-virtual {v5}, Ljava/util/ArrayList;->m_64e6af4e()V

    .line 606
    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 609
    move-object v12, v0

    .line 610
    move v6, v1

    .line 611
    move-object v7, v3

    .line 612
    move v10, v8

    .line 613
    move-object v2, v9

    .line 614
    move-object v3, v2

    .line 615
    move-object v8, v5

    .line 616
    move v5, v6

    .line 617
    move-object v1, v3

    .line 618
    :goto_12
    add-int/2addr v10, v4

    .line 619
    :cond_25
    :goto_13
    if-ge v10, v6, :cond_30

    .line 621
    const-string v4, "/\\"

    .line 623
    invoke-static {v10, v6, v2, v4}, Lex;->c(IILjava/lang/String;Ljava/lang/String;)I

    .line 626
    move-result v4

    .line 627
    if-ge v4, v6, :cond_26

    .line 629
    const/4 v13, 0x1

    .line 630
    goto :goto_14

    .line 631
    :cond_26
    const/4 v13, 0x0

    .line 632
    :goto_14
    const/16 v26, 0x1

    .line 634
    const-string v25, " \"<>^`{}|/\\?#"

    .line 636
    const/16 v27, 0x0

    .line 638
    const/16 v28, 0x0

    .line 640
    const/16 v29, 0x1

    .line 642
    move-object/from16 v22, v1

    .line 644
    move/from16 v23, v10

    .line 646
    move/from16 v24, v4

    .line 648
    invoke-static/range {v22 .. v29}, Lih;->a(Ljava/lang/String;IILjava/lang/String;ZZZZ)Ljava/lang/String;

    .line 651
    move-result-object v10

    .line 652
    const-string v14, "."

    .line 654
    invoke-virtual {v10, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 657
    move-result v14

    .line 658
    if-nez v14, :cond_28

    .line 660
    const-string v14, "%2e"

    .line 662
    invoke-virtual {v10, v14}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 665
    move-result v14

    .line 666
    if-eqz v14, :cond_27

    .line 668
    goto :goto_15

    .line 669
    :cond_27
    const/4 v14, 0x0

    .line 670
    goto :goto_16

    .line 671
    :cond_28
    :goto_15
    const/4 v14, 0x1

    .line 672
    :goto_16
    if-eqz v14, :cond_29

    .line 674
    const/4 v14, -0x1

    .line 675
    goto/16 :goto_1a

    .line 677
    :cond_29
    const-string v14, ".."

    .line 679
    invoke-virtual {v10, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 682
    move-result v14

    .line 683
    if-nez v14, :cond_2b

    .line 685
    const-string v14, "%2e."

    .line 687
    invoke-virtual {v10, v14}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 690
    move-result v14

    .line 691
    if-nez v14, :cond_2b

    .line 693
    const-string v14, ".%2e"

    .line 695
    invoke-virtual {v10, v14}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 698
    move-result v14

    .line 699
    if-nez v14, :cond_2b

    .line 701
    const-string v14, "%2e%2e"

    .line 703
    invoke-virtual {v10, v14}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 706
    move-result v14

    .line 707
    if-eqz v14, :cond_2a

    .line 709
    goto :goto_17

    .line 710
    :cond_2a
    const/4 v14, 0x0

    .line 711
    goto :goto_18

    .line 712
    :cond_2b
    :goto_17
    const/4 v14, 0x1

    .line 713
    :goto_18
    if-eqz v14, :cond_2d

    .line 715
    invoke-virtual {v8}, Ljava/util/ArrayList;->m_a8563233()I

    .line 718
    move-result v10

    .line 719
    const/4 v14, -0x1

    .line 720
    add-int/2addr v10, v14

    .line 721
    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->m_dd5508ec(I)Ljava/lang/Object;

    .line 724
    move-result-object v10

    .line 725
    check-cast v10, Ljava/lang/String;

    .line 727
    invoke-virtual {v10}, Ljava/lang/String;->m_de5dc0a1()Z

    .line 730
    move-result v10

    .line 731
    if-eqz v10, :cond_2c

    .line 733
    invoke-virtual {v8}, Ljava/util/ArrayList;->m_de5dc0a1()Z

    .line 736
    move-result v10

    .line 737
    if-nez v10, :cond_2c

    .line 739
    invoke-virtual {v8}, Ljava/util/ArrayList;->m_a8563233()I

    .line 742
    move-result v10

    .line 743
    add-int/2addr v10, v14

    .line 744
    invoke-virtual {v8, v10, v7}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 747
    goto :goto_1a

    .line 748
    :cond_2c
    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 751
    goto :goto_1a

    .line 752
    :cond_2d
    const/4 v14, -0x1

    .line 753
    invoke-virtual {v8}, Ljava/util/ArrayList;->m_a8563233()I

    .line 756
    move-result v15

    .line 757
    const/16 v16, 0x1

    .line 759
    add-int/lit8 v15, v15, -0x1

    .line 761
    invoke-virtual {v8, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 764
    move-result-object v15

    .line 765
    check-cast v15, Ljava/lang/String;

    .line 767
    invoke-virtual {v15}, Ljava/lang/String;->m_de5dc0a1()Z

    .line 770
    move-result v15

    .line 771
    if-eqz v15, :cond_2e

    .line 773
    invoke-virtual {v8}, Ljava/util/ArrayList;->m_a8563233()I

    .line 776
    move-result v15

    .line 777
    add-int/lit8 v15, v15, -0x1

    .line 779
    invoke-virtual {v8, v15, v10}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 782
    goto :goto_19

    .line 783
    :cond_2e
    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 786
    :goto_19
    if-eqz v13, :cond_2f

    .line 788
    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 791
    :cond_2f
    :goto_1a
    move v10, v4

    .line 792
    if-eqz v13, :cond_25

    .line 794
    const/4 v4, 0x1

    .line 795
    goto/16 :goto_12

    .line 797
    :cond_30
    move-object v1, v9

    .line 798
    goto/16 :goto_10

    .line 800
    :goto_1b
    if-ge v5, v2, :cond_31

    .line 802
    invoke-virtual {v3, v5}, Ljava/lang/String;->charAt(I)C

    .line 805
    move-result v4

    .line 806
    const/16 v6, 0x3f

    .line 808
    if-ne v4, v6, :cond_31

    .line 810
    const/16 v13, 0x23

    .line 812
    invoke-static {v3, v5, v2, v13}, Lex;->d(Ljava/lang/String;IIC)I

    .line 815
    move-result v14

    .line 816
    add-int/lit8 v5, v5, 0x1

    .line 818
    const-string v7, " \"\'<>#"

    .line 820
    const/4 v8, 0x1

    .line 821
    const/4 v9, 0x0

    .line 822
    const/4 v10, 0x1

    .line 823
    const/4 v11, 0x1

    .line 824
    move-object v4, v1

    .line 825
    move v6, v14

    .line 826
    invoke-static/range {v4 .. v11}, Lih;->a(Ljava/lang/String;IILjava/lang/String;ZZZZ)Ljava/lang/String;

    .line 829
    move-result-object v4

    .line 830
    invoke-static {v4}, Lih;->m(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 833
    move-result-object v4

    .line 834
    iput-object v4, v12, La_82E045E6;->g:Ljava/util/ArrayList;

    .line 836
    move v5, v14

    .line 837
    goto :goto_1c

    .line 838
    :cond_31
    const/16 v13, 0x23

    .line 840
    :goto_1c
    if-ge v5, v2, :cond_32

    .line 842
    invoke-virtual {v3, v5}, Ljava/lang/String;->charAt(I)C

    .line 845
    move-result v3

    .line 846
    if-ne v3, v13, :cond_32

    .line 848
    const/4 v3, 0x1

    .line 849
    add-int/2addr v5, v3

    .line 850
    const-string v7, ""

    .line 852
    const/4 v8, 0x1

    .line 853
    const/4 v9, 0x0

    .line 854
    const/4 v10, 0x0

    .line 855
    const/4 v11, 0x0

    .line 856
    move-object v4, v1

    .line 857
    move v6, v2

    .line 858
    invoke-static/range {v4 .. v11}, Lih;->a(Ljava/lang/String;IILjava/lang/String;ZZZZ)Ljava/lang/String;

    .line 861
    move-result-object v1

    .line 862
    iput-object v1, v12, La_82E045E6;->h:Ljava/lang/String;

    .line 864
    :cond_32
    const/4 v1, 0x1

    .line 865
    return v1

    .line 866
    :cond_33
    return v12
.end method

.method public final toString()Ljava/lang/String;
    .locals 7

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 6
    iget-object v1, p0, La_82E045E6;->a:Ljava/lang/String;

    .line 8
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    const-string v1, "://"

    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    iget-object v1, p0, La_82E045E6;->b:Ljava/lang/String;

    .line 18
    invoke-virtual {v1}, Ljava/lang/String;->m_de5dc0a1()Z

    .line 21
    move-result v1

    .line 22
    const/16 v2, 0x3a

    .line 24
    if-eqz v1, :cond_0

    .line 26
    iget-object v1, p0, La_82E045E6;->c:Ljava/lang/String;

    .line 28
    invoke-virtual {v1}, Ljava/lang/String;->m_de5dc0a1()Z

    .line 31
    move-result v1

    .line 32
    if-nez v1, :cond_2

    .line 34
    :cond_0
    iget-object v1, p0, La_82E045E6;->b:Ljava/lang/String;

    .line 36
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    iget-object v1, p0, La_82E045E6;->c:Ljava/lang/String;

    .line 41
    invoke-virtual {v1}, Ljava/lang/String;->m_de5dc0a1()Z

    .line 44
    move-result v1

    .line 45
    if-nez v1, :cond_1

    .line 47
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 50
    iget-object v1, p0, La_82E045E6;->c:Ljava/lang/String;

    .line 52
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    :cond_1
    const/16 v1, 0x40

    .line 57
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 60
    :cond_2
    iget-object v1, p0, La_82E045E6;->d:Ljava/lang/String;

    .line 62
    invoke-virtual {v1, v2}, Ljava/lang/String;->m_ff397df8(I)I

    .line 65
    move-result v1

    .line 66
    const/4 v3, -0x1

    .line 67
    if-eq v1, v3, :cond_3

    .line 69
    const/16 v1, 0x5b

    .line 71
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 74
    # ep-sqfaxohubnnc
    iget-object v1, p0, La_82E045E6;->d:Ljava/lang/String;

    .line 76
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    const/16 v1, 0x5d

    .line 81
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 84
    goto :goto_0

    .line 85
    :cond_3
    iget-object v1, p0, La_82E045E6;->d:Ljava/lang/String;

    .line 87
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 90
    :goto_0
    iget v1, p0, La_82E045E6;->e:I

    .line 92
    if-eq v1, v3, :cond_4

    .line 94
    goto :goto_1

    .line 95
    :cond_4
    iget-object v1, p0, La_82E045E6;->a:Ljava/lang/String;

    .line 97
    invoke-static {v1}, Lih;->d(Ljava/lang/String;)I

    .line 100
    move-result v1

    .line 101
    :goto_1
    iget-object v3, p0, La_82E045E6;->a:Ljava/lang/String;

    .line 103
    invoke-static {v3}, Lih;->d(Ljava/lang/String;)I

    .line 106
    move-result v3

    .line 107
    if-eq v1, v3, :cond_5

    .line 109
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 112
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 115
    :cond_5
    iget-object v1, p0, La_82E045E6;->f:Ljava/util/ArrayList;

    .line 117
    invoke-virtual {v1}, Ljava/util/ArrayList;->m_a8563233()I

    .line 120
    move-result v2

    .line 121
    const/4 v3, 0x0

    .line 122
    # ep-aggwnxnhmehq
    const/4 v4, 0x0

    .line 123
    :goto_2
    if-ge v4, v2, :cond_6

    .line 125
    const/16 v5, 0x2f

    .line 127
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 130
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 133
    move-result-object v5

    .line 134
    check-cast v5, Ljava/lang/String;

    .line 136
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 139
    add-int/lit8 v4, v4, 0x1

    .line 141
    goto :goto_2

    .line 142
    :cond_6
    iget-object v1, p0, La_82E045E6;->g:Ljava/util/ArrayList;

    .line 144
    if-eqz v1, :cond_9

    .line 146
    const/16 v1, 0x3f

    .line 148
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 151
    iget-object v1, p0, La_82E045E6;->g:Ljava/util/ArrayList;
    # ep-oenfimdxwofb

    .line 153
    invoke-interface {v1}, Ljava/util/List;->m_a8563233()I

    .line 156
    move-result v2

    .line 157
    :goto_3
    if-ge v3, v2, :cond_9

    .line 159
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 162
    move-result-object v4

    .line 163
    check-cast v4, Ljava/lang/String;

    .line 165
    add-int/lit8 v5, v3, 0x1

    .line 167
    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 170
    move-result-object v5

    .line 171
    check-cast v5, Ljava/lang/String;

    .line 173
    if-lez v3, :cond_7

    .line 175
    const/16 v6, 0x26

    .line 177
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 180
    # ep-qygxednhetua
    :cond_7
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 183
    if-eqz v5, :cond_8

    .line 185
    const/16 v4, 0x3d

    .line 187
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 190
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 193
    :cond_8
    add-int/lit8 v3, v3, 0x2

    .line 195
    goto :goto_3

    .line 196
    :cond_9
    iget-object v1, p0, La_82E045E6;->h:Ljava/lang/String;

    .line 198
    if-eqz v1, :cond_a

    .line 200
    const/16 v1, 0x23

    .line 202
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 205
    iget-object v1, p0, La_82E045E6;->h:Ljava/lang/String;

    .line 207
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 210
    :cond_a
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 213
    move-result-object v0

    .line 214
    return-object v0
.end method
