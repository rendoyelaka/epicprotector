.class public final synthetic La_863E8385;
.super Ljava/lang/Object;
# compiled-76014
# ep-ktlryvxmiluc
.source "zziubjdw.java"

# interfaces
.implements Landroid/view/View$OnUnhandledKeyEventListener;


# instance fields
.field public final synthetic a:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;

.field public final synthetic b:Landroid/view/View;

.field public final synthetic c:Lcom/google/android/material/appbar/AppBarLayout;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;Landroid/view/View;Lcom/google/android/material/appbar/AppBarLayout;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La_863E8385;->a:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;

    iput-object p2, p0, La_863E8385;->b:Landroid/view/View;

    iput-object p3, p0, La_863E8385;->c:Lcom/google/android/material/appbar/AppBarLayout;

    return-void
.end method


# virtual methods
.method public final onUnhandledKeyEvent(Landroid/view/View;Landroid/view/KeyEvent;)Z
    .locals 2

    .line 1
    iget-object p1, p0, La_863E8385;->a:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;

    .line 3
    iget-object v0, p0, La_863E8385;->b:Landroid/view/View;

    .line 5
    iget-object v1, p0, La_863E8385;->c:Lcom/google/android/material/appbar/AppBarLayout;

    .line 7
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    invoke-static {p2, v0, v1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->m_c9c42085(Landroid/view/KeyEvent;Landroid/view/View;Lcom/google/android/material/appbar/AppBarLayout;)V

    .line 13
    const/4 p1, 0x0

    .line 14
    return p1
.end method
