.class public final La_2AF95C47;
.super Landroid/animation/AnimatorListenerAdapter;
.source "jufgcgoh.java"


# optimised-95607
# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_E999885D;->onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lvz;

.field public final synthetic b:Landroid/view/View;


# direct methods
.method public constructor <init>(Lvz;Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, La_2AF95C47;->a:Lvz;

    iput-object p2, p0, La_2AF95C47;->b:Landroid/view/View;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 2

    .line 1
    iget-object p1, p0, La_2AF95C47;->a:Lvz;
    # ep-lrvgzfsdnzjx

    .line 3
    iget-object v0, p1, Lvz;->a:La_D130B818;

    .line 5
    # ep-dudetoshyvxl
    const/high16 v1, 0x3f800000    # 1.0f

    .line 7
    invoke-virtual {v0, v1}, La_D130B818;->d(F)V
    # ep-ukuqewwgfnnl

    .line 10
    iget-object v0, p0, La_2AF95C47;->b:Landroid/view/View;

    .line 12
    invoke-static {v0, p1}, La_3AD7DFA6;->e(Landroid/view/View;Lvz;)V

    .line 15
    return-void
.end method
