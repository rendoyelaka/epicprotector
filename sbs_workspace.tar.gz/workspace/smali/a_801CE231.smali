.class public final La_801CE231;
# ep-jnhpczxgxwds
.super Landroid/animation/AnimatorListenerAdapter;
.source "pgxxzcli.java"
# compiled-80091


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_1AC5639E;->onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lvz;

.field public final synthetic b:Landroid/view/View;


# direct methods
.method public constructor <init>(Lvz;Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, La_801CE231;->a:Lvz;

    iput-object p2, p0, La_801CE231;->b:Landroid/view/View;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 2

    .line 1
    iget-object p1, p0, La_801CE231;->a:Lvz;

    .line 3
    iget-object v0, p1, Lvz;->a:La_066709E7;

    .line 5
    const/high16 v1, 0x3f800000    # 1.0f

    .line 7
    invoke-virtual {v0, v1}, La_066709E7;->d(F)V

    .line 10
    iget-object v0, p0, La_801CE231;->b:Landroid/view/View;

    .line 12
    invoke-static {v0, p1}, La_BC9A1D83;->e(Landroid/view/View;Lvz;)V

    .line 15
    return-void
.end method
