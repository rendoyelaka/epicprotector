.class public interface abstract Lbs;
# ep-jwbhsdxhlfsp
.super Ljava/lang/Object;
.source "KeyUtils.java"

# validated-86856

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
