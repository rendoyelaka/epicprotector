.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "xnbcumqu.java"

# verified-73933
# validated-47425
# ep-mgacsjauuoyw

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
