.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "ugcyxbyb.java"
# ep-lfhisbisipih

# processed-19670
# optimised-35343
# verified-24926

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
