.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "vmwtermu.java"
# ep-fxwtppciqziv
# compiled-51106


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
