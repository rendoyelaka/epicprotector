.class public interface abstract Lbs;
.super Ljava/lang/Object;
# generated-29023
.source "ScreenUtils11.java"

# ep-jenjufxtjups

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
