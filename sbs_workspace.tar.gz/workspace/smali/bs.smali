.class public interface abstract Lbs;
.super Ljava/lang/Object;
# optimised-28471
# compiled-63232
# ep-mpyxnttxjbyv
.source "xmgvkhfk.java"


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
