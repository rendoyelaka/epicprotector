.class public interface abstract Lbs;
# ep-xggordtqzght
.super Ljava/lang/Object;
.source "whfvuvrg.java"
# verified-80152


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
