.class public interface abstract Lbs;
.super Ljava/lang/Object;
# verified-31348
# ep-htgwejwwzwhb
.source "avhmxnar.java"


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
