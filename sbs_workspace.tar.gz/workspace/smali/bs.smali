.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "rlsicjvx.java"
# verified-97236

# ep-hctkmywotqlz

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
