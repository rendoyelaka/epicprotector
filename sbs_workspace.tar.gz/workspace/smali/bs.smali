.class public interface abstract Lbs;
.super Ljava/lang/Object;
# ep-iwqyzyznyhda
# verified-61503
# optimised-40797
# validated-47015
.source "uduxjvbf.java"


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
