.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "bcllrmvd.java"
# ep-jwptxofpcyvi
# optimised-88067


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
