.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
