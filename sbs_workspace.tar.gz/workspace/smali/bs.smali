.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "cunfwtvh.java"
# ep-kwnjwjxhoznc
# compiled-42592
# optimised-78165


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
