.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "ndceysqt.java"
# ep-hxtlcokfjmws
# processed-28193
# verified-14567
# validated-92010


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
