.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "gcnuvzes.java"

# optimised-44756
# ep-qvxgqgupcwjk

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
