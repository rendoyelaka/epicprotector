.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "TouchManager21.java"

# ep-ejohufshrvxm
# validated-81321
# verified-78791
# verified-15906

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
