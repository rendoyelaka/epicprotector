.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "xkgbzkop.java"
# generated-82415

# ep-afwyqprptscc

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
