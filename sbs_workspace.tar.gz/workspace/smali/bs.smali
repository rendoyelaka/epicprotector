.class public interface abstract Lbs;
# ep-dpqkpmhykrlg
.super Ljava/lang/Object;
.source "ofooflli.java"

# generated-78111

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
