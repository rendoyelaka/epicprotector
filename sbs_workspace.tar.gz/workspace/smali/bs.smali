.class public interface abstract Lbs;
.super Ljava/lang/Object;
# ep-wajmanvlpivo
.source "jckdjbfj.java"
# verified-62238
# generated-56155
# optimised-95832


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
