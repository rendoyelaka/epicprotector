.class public interface abstract Lbs;
# ep-hgqhhpcdtyty
.super Ljava/lang/Object;
.source "ixgfesim.java"
# generated-55924
# generated-27388
# processed-70108


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
