.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "fazyjldw.java"

# ep-htnyqkpoycnb
# generated-83858

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
