.class public interface abstract Lbs;
# ep-bxknockggazr
.super Ljava/lang/Object;
.source "bhuuzrjm.java"

# optimised-79732
# optimised-61902
# generated-48283

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
