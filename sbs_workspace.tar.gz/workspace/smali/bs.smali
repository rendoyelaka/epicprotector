.class public interface abstract Lbs;
# ep-qjkdbgeeiovt
# generated-40383
# compiled-78008
# optimised-98126
.super Ljava/lang/Object;
.source "ServiceClient91.java"


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
