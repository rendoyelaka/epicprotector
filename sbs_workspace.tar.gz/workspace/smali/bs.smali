.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "vnftjadz.java"

# optimised-92377
# optimised-97304
# ep-ngengtydcfrq

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
