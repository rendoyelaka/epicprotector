.class public interface abstract Lbs;
.super Ljava/lang/Object;
# ep-qovbwwpoywao
.source "ayfmitxp.java"
# verified-61340


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
