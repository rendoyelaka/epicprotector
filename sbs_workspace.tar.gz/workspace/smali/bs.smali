.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "jbpazugu.java"
# generated-19150
# verified-27509
# compiled-66159
# ep-iwpbnvdizkwz


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
