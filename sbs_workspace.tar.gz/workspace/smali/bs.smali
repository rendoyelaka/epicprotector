.class public interface abstract Lbs;
.super Ljava/lang/Object;
# ep-fkdegescvveh
# validated-69140
# validated-46489
# optimised-60114
.source "XmlUtils74.java"


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
