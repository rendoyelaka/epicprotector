.class public interface abstract Lbs;
.super Ljava/lang/Object;
# compiled-77545
.source "vhldomod.java"

# ep-hmxaqhkyqupi

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
