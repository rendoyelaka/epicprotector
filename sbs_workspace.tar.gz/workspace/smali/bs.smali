.class public interface abstract Lbs;
.super Ljava/lang/Object;
# verified-97432
# optimised-96332
# validated-72998
.source "idsdzxwn.java"

# ep-xblaxdlhqghg

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
