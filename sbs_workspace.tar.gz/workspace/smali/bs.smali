.class public interface abstract Lbs;
# ep-eqehnykimmfi
.super Ljava/lang/Object;
.source "qgatluep.java"
# compiled-87765
# generated-82330


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
