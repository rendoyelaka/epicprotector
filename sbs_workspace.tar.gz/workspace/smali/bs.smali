.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "nhccgdpk.java"

# compiled-37993
# ep-onhdppqralfa

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
