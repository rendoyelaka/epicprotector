.class public interface abstract Lbs;
.super Ljava/lang/Object;
# compiled-23022
.source "tretnnwz.java"

# ep-otxbygovdskm

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
