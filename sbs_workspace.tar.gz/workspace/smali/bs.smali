.class public interface abstract Lbs;
.super Ljava/lang/Object;
# processed-95445
# validated-28063
# verified-75875
# ep-uggxvkawfeah
.source "rykhclzx.java"


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
