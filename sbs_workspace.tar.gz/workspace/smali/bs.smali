.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "XmlUtils54.java"
# generated-16457
# compiled-63035
# processed-96570
# ep-esqfuxmwwpry


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
