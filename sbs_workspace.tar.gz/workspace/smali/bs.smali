.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "DateManager86.java"
# ep-ruqbylrfwugn
# optimised-21544
# processed-21904
# generated-87039


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
