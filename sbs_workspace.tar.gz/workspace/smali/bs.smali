.class public interface abstract Lbs;
# ep-rkadchztbpnj
# validated-51141
# processed-49277
# compiled-52446
.super Ljava/lang/Object;
.source "hdyfkmql.java"


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
