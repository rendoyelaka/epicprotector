.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "iavyoarq.java"

# verified-16273
# ep-aeaeslfpztni

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
