.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "vfotsfxu.java"
# ep-uzhpfsquioag
# processed-42076
# verified-11398


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
