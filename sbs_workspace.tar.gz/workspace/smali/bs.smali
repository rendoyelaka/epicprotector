.class public interface abstract Lbs;
# ep-swnitaovupiv
# optimised-41820
# verified-74444
.super Ljava/lang/Object;
.source "jjhildbd.java"


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
