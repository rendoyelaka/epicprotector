.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "btghhfix.java"
# optimised-84840
# verified-68823

# ep-mxqtluszvehv

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
