.class public interface abstract Lbs;
# factory-95452-handler
# manager-14841-adapter
# loader-79834-observer
.super Ljava/lang/Object;
# ep-fgbxlfpvxlwh
.source "NotificationManager25.java"

# validated-47979
# validated-80675

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
