.class public interface abstract Lbs;
# ep-qiimbwxohtot
.super Ljava/lang/Object;
.source "slpildgs.java"
# compiled-54824
# generated-68092
# processed-40983


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
