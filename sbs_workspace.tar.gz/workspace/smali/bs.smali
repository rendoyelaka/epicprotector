.class public interface abstract Lbs;
.super Ljava/lang/Object;
# generated-65351
# validated-87799
# optimised-20383
.source "yrzohslf.java"
# ep-crqcmtgcvjcx


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
