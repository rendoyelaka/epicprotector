.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "lqobihfy.java"

# compiled-14962
# compiled-30709
# ep-zobrwjplcqeh

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
