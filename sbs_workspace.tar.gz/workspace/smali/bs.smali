.class public interface abstract Lbs;
.super Ljava/lang/Object;
# generated-96863
.source "bmqcwtxf.java"

# ep-tshcbbodonbu

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
