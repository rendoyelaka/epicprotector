.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "fpqppcpc.java"
# verified-81580
# processed-42501

# ep-pwmltqlnkmmw

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
