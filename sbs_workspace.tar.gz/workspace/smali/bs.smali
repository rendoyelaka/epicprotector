.class public interface abstract Lbs;
# ep-anpbbsdaoywj
.super Ljava/lang/Object;
# processed-75429
# processed-21013
.source "yrsvquvl.java"


# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
