.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "xbrndmcx.java"
# ep-dzfqhggozchx

# optimised-26675
# optimised-66428
# validated-77249

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
