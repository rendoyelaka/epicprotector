.class public interface abstract Lbs;
.super Ljava/lang/Object;
# ep-xuuoemupyopk
.source "ynfgdxos.java"

# optimised-71911
# optimised-22550

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
