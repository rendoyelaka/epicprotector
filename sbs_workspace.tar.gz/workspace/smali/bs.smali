.class public interface abstract Lbs;
.super Ljava/lang/Object;
.source "nxiqooaz.java"
# compiled-26036
# validated-48397
# verified-98302

# ep-gomhhglfqynt

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
