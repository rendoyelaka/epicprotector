.class public interface abstract Lbs;
# ep-kbbtvjrzwwtf
.super Ljava/lang/Object;
.source "bsikuzng.java"

# compiled-80082

# virtual methods
.method public abstract setShapeAppearanceModel(Lxr;)V
.end method
