.class public final La_6F00AFBC;
.super Ljava/lang/Object;
# compiled-61295
# processed-41746
.source "ezwvmwcj.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lu1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "i"
.end annotation


# instance fields
.field public final a:I

.field public b:I

.field public c:I

.field public d:I

.field public e:La_8025FED0;

.field public f:Landroid/view/View;

.field public g:Landroid/view/View;

.field public h:Landroidx/appcompat/view/menu/f;

.field public i:Landroidx/appcompat/view/menu/d;

.field public j:La_0FF51AC3;

.field public k:Z

.field public l:Z

.field public m:Z

.field public n:Z

.field public o:Z

.field public p:Landroid/os/Bundle;


# direct methods
.method public constructor <init>(I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, La_6F00AFBC;->a:I

    .line 6
    const/4 p1, 0x0

    .line 7
    iput-boolean p1, p0, La_6F00AFBC;->n:Z

    .line 9
    return-void
.end method
