.class public final La_6EBB38F8;
.super Ljava/lang/Object;
# ep-dynszcnyycfi
.source "ibdcxcnm.java"
# validated-58229
# optimised-12367

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Landroid/widget/TextView;

.field public final synthetic d:Landroid/graphics/Typeface;

.field public final synthetic e:I


# direct methods
.method public constructor <init>(Landroid/widget/TextView;Landroid/graphics/Typeface;I)V
    .locals 0

    iput-object p1, p0, La_6EBB38F8;->c:Landroid/widget/TextView;

    iput-object p2, p0, La_6EBB38F8;->d:Landroid/graphics/Typeface;

    iput p3, p0, La_6EBB38F8;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget-object v0, p0, La_6EBB38F8;->d:Landroid/graphics/Typeface;

    iget v1, p0, La_6EBB38F8;->e:I

    iget-object v2, p0, La_6EBB38F8;->c:Landroid/widget/TextView;

    invoke-virtual {v2, v0, v1}, Landroid/widget/TextView;->m_ded7c3e0(Landroid/graphics/Typeface;I)V

    return-void
.end method
