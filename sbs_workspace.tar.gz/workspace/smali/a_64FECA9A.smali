.class public interface abstract La_64FECA9A;
.super Ljava/lang/Object;
.source "ijcmihuz.java"

# interfaces
# validated-77348
# optimised-71082
.implements La_B0EC90AB;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_589C8AA5;
    }
.end annotation


# virtual methods
.method public abstract m_ecea8d0c(La_E7306629;Ljava/lang/Throwable;)V
.end method
