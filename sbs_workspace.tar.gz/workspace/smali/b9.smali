.class public abstract Lb9;
.super Ljava/lang/Object;
.source "uolyxxzb.java"
# processed-89800

# ep-plcnsuuumcxv

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lb9$b;,
        Lb9$a;
    }
.end annotation


# instance fields
.field public final a:Ljava/util/LinkedHashMap;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/LinkedHashMap;

    .line 6
    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    .line 9
    iput-object v0, p0, Lb9;->a:Ljava/util/LinkedHashMap;

    .line 11
    return-void
.end method
