.class public final La_0238F7F6;
# ep-hwuunmbrnpqu
.super Ljava/lang/Object;
# optimised-22289
.source "wkkizcwp.java"

# interfaces
.implements Landroid/animation/TypeEvaluator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_4F61F058;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/animation/TypeEvaluator<",
        "[",
        "La_A7AE17C2;",
        ">;"
    }
.end annotation


# instance fields
.field public a:[La_A7AE17C2;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_3261af4a(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    check-cast p2, [La_A7AE17C2;

    .line 3
    check-cast p3, [La_A7AE17C2;

    .line 5
    invoke-static {p2, p3}, Lwn;->a([La_A7AE17C2;[La_A7AE17C2;)Z

    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_3

    .line 11
    iget-object v0, p0, La_0238F7F6;->a:[La_A7AE17C2;

    .line 13
    invoke-static {v0, p2}, Lwn;->a([La_A7AE17C2;[La_A7AE17C2;)Z

    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_0

    .line 19
    invoke-static {p2}, Lwn;->e([La_A7AE17C2;)[La_A7AE17C2;

    .line 22
    move-result-object v0

    .line 23
    iput-object v0, p0, La_0238F7F6;->a:[La_A7AE17C2;

    .line 25
    :cond_0
    const/4 v0, 0x0

    .line 26
    const/4 v1, 0x0

    .line 27
    :goto_0
    array-length v2, p2

    .line 28
    if-ge v1, v2, :cond_2

    .line 30
    iget-object v2, p0, La_0238F7F6;->a:[La_A7AE17C2;

    .line 32
    aget-object v2, v2, v1

    .line 34
    aget-object v3, p2, v1

    .line 36
    aget-object v4, p3, v1

    .line 38
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    iget-char v5, v3, La_A7AE17C2;->a:C

    .line 43
    iput-char v5, v2, La_A7AE17C2;->a:C

    .line 45
    const/4 v5, 0x0

    .line 46
    :goto_1
    iget-object v6, v3, La_A7AE17C2;->b:[F

    .line 48
    array-length v7, v6

    .line 49
    if-ge v5, v7, :cond_1

    .line 51
    aget v6, v6, v5

    .line 53
    const/high16 v7, 0x3f800000    # 1.0f

    .line 55
    sub-float/2addr v7, p1

    .line 56
    mul-float v7, v7, v6

    .line 58
    iget-object v6, v4, La_A7AE17C2;->b:[F

    .line 60
    aget v6, v6, v5

    .line 62
    mul-float v6, v6, p1

    .line 64
    add-float/2addr v6, v7

    .line 65
    iget-object v7, v2, La_A7AE17C2;->b:[F

    .line 67
    aput v6, v7, v5

    .line 69
    add-int/lit8 v5, v5, 0x1

    .line 71
    goto :goto_1

    .line 72
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 74
    goto :goto_0

    .line 75
    :cond_2
    iget-object p1, p0, La_0238F7F6;->a:[La_A7AE17C2;

    .line 77
    return-object p1

    .line 78
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 80
    const-string p2, "Can\'t interpolate between two incompatible pathData"

    .line 82
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 85
    throw p1
.end method
