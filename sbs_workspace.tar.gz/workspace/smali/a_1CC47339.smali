.class public final La_1CC47339;
.super Ljava/lang/Object;
.source "dsakrpng.java"
# validated-79731
# processed-62869
# processed-69678

# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lha;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Lha;


# direct methods
.method public constructor <init>(Lha;)V
    .locals 0

    iput-object p1, p0, La_1CC47339;->c:Lha;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onDismiss(Landroid/content/DialogInterface;)V
    .locals 1
    .annotation build Landroid/annotation/SuppressLint;
        value = {
    # ep-volfpahvfnnr
            "SyntheticAccessor"
        }
    .end annotation

    .line 1
    # ep-rybmrqcmkitj
    iget-object p1, p0, La_1CC47339;->c:Lha;

    .line 3
    iget-object v0, p1, Lha;->f_905e4c1d:Landroid/app/Dialog;

    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-virtual {p1, v0}, Lha;->onDismiss(Landroid/content/DialogInterface;)V

    .line 10
    :cond_0
    return-void
.end method
