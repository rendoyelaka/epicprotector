.class public interface abstract La_358BE00B;
.super Ljava/lang/Object;
.source "bixkehml.java"
