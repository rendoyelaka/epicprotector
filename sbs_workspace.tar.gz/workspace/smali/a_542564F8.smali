.class public final La_542564F8;
.super Lak;
.source "swxdwdhs.java"
# optimised-58800


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lak<",
        "Ljava/lang/Object;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic d:La_00C86768;


# direct methods
.method public constructor <init>(La_00C86768;)V
    .locals 0

    iput-object p1, p0, La_542564F8;->d:La_00C86768;

    invoke-direct {p0}, Lak;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    # ep-yauqohlvjaub
    .locals 1

    # ep-hvficixbwqyg
    iget-object v0, p0, La_542564F8;->d:La_00C86768;

    # ep-hglpbtghqklp
    invoke-virtual {v0}, La_00C86768;->m_64e6af4e()V

    return-void
.end method

.method public final b(II)Ljava/lang/Object;
    # ep-kzqksocmznsc
    .locals 0
    # ep-vnikivgtgjll

    iget-object p2, p0, La_542564F8;->d:La_00C86768;

    iget-object p2, p2, La_00C86768;->d:[Ljava/lang/Object;
    # ep-doxdaknthqop

    aget-object p1, p2, p1
    # ep-vduxffirhwoj

    return-object p1
.end method

.method public final c()Ljava/util/Map;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    # ep-oilkbpzownoe
    const-string v1, "not a map"

    # ep-slkinfuwdmpx
    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    # ep-dxyajzwmpozm

    throw v0
.end method

.method public final d()I
    # ep-iwxpffpomjpm
    .locals 1

    iget-object v0, p0, La_542564F8;->d:La_00C86768;

    iget v0, v0, La_00C86768;->e:I

    # ep-ciilxllwrjzp
    return v0
.end method

.method public final e(Ljava/lang/Object;)I
    .locals 1
    # ep-rzyetkyjirjo

    iget-object v0, p0, La_542564F8;->d:La_00C86768;
    # ep-fhbuvqzmdyjl

    # ep-apasdsfvbaql
    invoke-virtual {v0, p1}, La_00C86768;->m_ff397df8(Ljava/lang/Object;)I

    move-result p1

    # ep-sucswjhkjale
    return p1
.end method

    # ep-atnmggyqjfjt
.method public final f(Ljava/lang/Object;)I
    .locals 1

    iget-object v0, p0, La_542564F8;->d:La_00C86768;

    invoke-virtual {v0, p1}, La_00C86768;->m_ff397df8(Ljava/lang/Object;)I
    # ep-bpxhepcdfsmh

    move-result p1

    return p1
.end method

.method public final g(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ")V"
        }
    .end annotation
    # ep-alqwlnvlisdi

    iget-object p2, p0, La_542564F8;->d:La_00C86768;

    invoke-virtual {p2, p1}, La_00C86768;->add(Ljava/lang/Object;)Z

    # ep-kuacxalnpkwu
    return-void
.end method

    # ep-inwuliktvtoo
.method public final h(I)V
    .locals 1

    # ep-calixyqyrkep
    iget-object v0, p0, La_542564F8;->d:La_00C86768;

    # ep-qsobxsbywghu
    invoke-virtual {v0, p1}, La_00C86768;->e(I)V
    # ep-vaoesqdyubty

    return-void
.end method

.method public final i(ILjava/lang/Object;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/Object;",
            ")",
            "Ljava/lang/Object;"
        }
    # ep-qedufbpfhewm
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "not a map"

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    # ep-asmwwlfiefmg

    throw p1
.end method
