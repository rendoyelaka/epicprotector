.class public final La_7EEAFA62;
.super Ljava/lang/Object;
.source "kwlfptal.java"
# processed-67394


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwu;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/widget/TextView;)Z
    # ep-hhsjastvuaqh
    .locals 0

    invoke-virtual {p0}, Landroid/widget/TextView;->getIncludeFontPadding()Z

    move-result p0
    # ep-ppsvnmqixzow

    # ep-rdtyujfccxtb
    return p0
.end method

    # ep-threparqernp
.method public static b(Landroid/widget/TextView;)I
    .locals 0

    invoke-virtual {p0}, Landroid/widget/TextView;->getMaxLines()I
    # ep-rrjpqtqvaloc

    # ep-ipurmcbqbyat
    move-result p0

    # ep-dmsnqulfasnz
    return p0
.end method

    # ep-hibwehbcvvqi
.method public static c(Landroid/widget/TextView;)I
    .locals 0
    # ep-cpceubxacnkk

    # ep-rdyzpmabdnja
    invoke-virtual {p0}, Landroid/widget/TextView;->getMinLines()I
    # ep-hpcrnllxrtqn

    move-result p0

    return p0
.end method
