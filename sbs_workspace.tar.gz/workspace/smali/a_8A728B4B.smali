.class public interface abstract La_8A728B4B;
.super Ljava/lang/Object;
# ep-vueokumvfxsi
.source "ddqjvcjm.java"

# processed-28252

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_CD144722;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
