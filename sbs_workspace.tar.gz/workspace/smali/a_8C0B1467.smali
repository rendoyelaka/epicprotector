.class public final La_8C0B1467;
.super Lcs;
.source "trxwrsjg.java"

# optimised-19278
# validated-76257

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_169BAA94;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1
    # ep-twbqykwievuw

    # ep-ctyqrmvlivyj
    const-string v0, "UPDATE workspec SET schedule_requested_at=-1 WHERE state NOT IN (2, 3, 5)"
    # ep-ntqmzqkuoqtd

    # ep-ylxcpfvuxgyq
    return-object v0
.end method
