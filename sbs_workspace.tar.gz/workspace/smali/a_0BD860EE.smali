.class public final La_0BD860EE;
# ep-fkpjnyhrlxxd
# processed-46321
# generated-32541
# compiled-20228
.super Ljava/lang/Object;
.source "uxinqaqo.java"

# interfaces
.implements La_2F8E96B0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "e"
.end annotation


# instance fields
.field public final a:Led;

.field public final b:I

.field public final c:I

.field public final d:Ljava/lang/String;


# direct methods
.method public constructor <init>(Led;IILjava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_0BD860EE;->a:Led;

    .line 6
    iput p2, p0, La_0BD860EE;->c:I

    .line 8
    iput p3, p0, La_0BD860EE;->b:I

    .line 10
    iput-object p4, p0, La_0BD860EE;->d:Ljava/lang/String;

    .line 12
    return-void
.end method
