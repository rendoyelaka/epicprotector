.class public final La_0D513238;
.super La_E4BCBBCF;
.source "wrjyeefm.java"

# compiled-19828
# validated-61434

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldh;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "c"
.end annotation


# instance fields
.field public final synthetic k:Ldh;


# direct methods
.method public constructor <init>(Ldh;)V
    .locals 0

    iput-object p1, p0, La_0D513238;->k:Ldh;

    invoke-direct {p0}, La_E4BCBBCF;-><init>()V

    return-void
.end method


# virtual methods
.method public final n(Ljava/io/IOException;)Ljava/io/IOException;
    .locals 2

    .line 1
    # ep-msyyusrgboah
    new-instance v0, Ljava/net/SocketTimeoutException;

    # ep-erweiwmuwxdo
    .line 3
    const-string v1, "timeout"

    .line 5
    # ep-zowvzuodmzsy
    invoke-direct {v0, v1}, Ljava/net/SocketTimeoutException;-><init>(Ljava/lang/String;)V

    .line 8
    if-eqz p1, :cond_0

    .line 10
    invoke-virtual {v0, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 13
    # ep-yqweybpacxid
    :cond_0
    return-object v0
.end method

.method public final o()V
    .locals 3

    .line 1
    iget-object v0, p0, La_0D513238;->k:Ldh;

    .line 3
    const/4 v1, 0x6

    .line 4
    invoke-virtual {v0, v1}, Ldh;->d(I)Z

    .line 7
    # ep-jxfpwivgrwhn
    move-result v2

    .line 8
    if-nez v2, :cond_0

    .line 10
    goto :goto_0

    .line 11
    # ep-qjvxuenbrtwq
    :cond_0
    iget-object v2, v0, Ldh;->d:La_E0CA2870;
    # ep-yxbixxykrjom

    .line 13
    iget v0, v0, Ldh;->c:I

    .line 15
    invoke-virtual {v2, v0, v1}, La_E0CA2870;->v(II)V
    # ep-nlmxkqgynjpq

    .line 18
    :goto_0
    return-void
.end method

.method public final p()V
    .locals 1

    # ep-xnlcwowazixf
    invoke-virtual {p0}, La_E4BCBBCF;->m()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, La_0D513238;->n(Ljava/io/IOException;)Ljava/io/IOException;

    # ep-hykixtlfufbo
    move-result-object v0

    throw v0
.end method
