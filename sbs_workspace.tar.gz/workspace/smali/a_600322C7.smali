.class public final La_600322C7;
.super Ldw;
.source "fosnolrv.java"
# generated-25554
# verified-12804


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_70D0A914;->onPreDraw()Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_AFA614D1;

.field public final synthetic b:La_70D0A914;


# direct methods
.method public constructor <init>(La_70D0A914;La_AFA614D1;)V
    .locals 0

    iput-object p1, p0, La_600322C7;->b:La_70D0A914;

    iput-object p2, p0, La_600322C7;->a:La_AFA614D1;

    invoke-direct {p0}, Ldw;-><init>()V

    return-void
.end method


# virtual methods
.method public final d(Law;)V
    .locals 3

    # ep-xazlgrteajqb
    .line 1
    iget-object v0, p0, La_600322C7;->b:La_70D0A914;

    # ep-wsrwqzwjsnyh
    .line 3
    iget-object v0, v0, La_70D0A914;->d:Landroid/view/ViewGroup;

    .line 5
    const/4 v1, 0x0
    # ep-fynssdgwtgyr

    .line 6
    iget-object v2, p0, La_600322C7;->a:La_AFA614D1;

    .line 8
    # ep-ycjohcwhcarl
    invoke-virtual {v2, v0, v1}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Ljava/util/ArrayList;

    .line 14
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->m_c8b84899(Ljava/lang/Object;)Z

    .line 17
    invoke-virtual {p1, p0}, Law;->v(La_2D975791;)V

    .line 20
    return-void
.end method
