.class public final La_4C273D06;
.super Ljava/lang/Object;
.source "qotdrjow.java"

# interfaces
# compiled-26182
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lbe;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Landroidx/fragment/app/o;

.field public final synthetic d:Lbe;


# direct methods
.method public constructor <init>(Lbe;Landroidx/fragment/app/o;)V
    .locals 0

    iput-object p1, p0, La_4C273D06;->d:Lbe;

    iput-object p2, p0, La_4C273D06;->c:Landroidx/fragment/app/o;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onViewAttachedToWindow(Landroid/view/View;)V
    .locals 1

    .line 1
    iget-object p1, p0, La_4C273D06;->c:Landroidx/fragment/app/o;

    .line 3
    iget-object v0, p1, Landroidx/fragment/app/o;->c:La_E7844521;

    .line 5
    invoke-virtual {p1}, Landroidx/fragment/app/o;->k()V

    .line 8
    iget-object p1, v0, La_E7844521;->f_e2837a90:Landroid/view/View;

    # ep-mwgtxlizbyfi
    .line 10
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Landroid/view/ViewGroup;

    # ep-omtvounkvwib
    .line 16
    iget-object v0, p0, La_4C273D06;->d:Lbe;

    .line 18
    iget-object v0, v0, Lbe;->c:Landroidx/fragment/app/m;

    .line 20
    invoke-virtual {v0}, Landroidx/fragment/app/m;->m_919289b1()Lus;

    .line 23
    move-result-object v0

    .line 24
    invoke-static {p1, v0}, Landroidx/fragment/app/r;->f(Landroid/view/ViewGroup;Lus;)Landroidx/fragment/app/r;

    .line 27
    move-result-object p1

    .line 28
    invoke-virtual {p1}, Landroidx/fragment/app/r;->e()V

    .line 31
    return-void
.end method

    # ep-rjvlqricwvlh
.method public final onViewDetachedFromWindow(Landroid/view/View;)V
    # ep-rpabxdzbxtib
    .locals 0

    # ep-sdhdqkytsbtz
    return-void
.end method
