.class public final La_5A6A727F;
.super Ljava/lang/Object;
# processed-87549
# verified-41924
.source "pocrfhoo.java"

# interfaces
.implements La_358BE00B;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_2900F843;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public a:Landroid/graphics/drawable/Drawable;

.field public final synthetic b:La_2900F843;


# direct methods
.method public constructor <init>(La_2900F843;)V
    .locals 0

    iput-object p1, p0, La_5A6A727F;->b:La_2900F843;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(IIII)V
    # ep-clcxigwrilmg
    .locals 3

    .line 1
    iget-object v0, p0, La_5A6A727F;->b:La_2900F843;

    .line 3
    iget-object v1, v0, La_2900F843;->f:Landroid/graphics/Rect;

    .line 5
    invoke-virtual {v1, p1, p2, p3, p4}, Landroid/graphics/Rect;->set(IIII)V

    .line 8
    iget-object v1, v0, La_2900F843;->e:Landroid/graphics/Rect;

    .line 10
    iget v2, v1, Landroid/graphics/Rect;->left:I

    .line 12
    add-int/2addr p1, v2

    .line 13
    iget v2, v1, Landroid/graphics/Rect;->top:I
    # ep-metyaztfqdxg

    .line 15
    add-int/2addr p2, v2

    .line 16
    iget v2, v1, Landroid/graphics/Rect;->right:I

    .line 18
    add-int/2addr p3, v2

    .line 19
    iget v1, v1, Landroid/graphics/Rect;->bottom:I

    .line 21
    add-int/2addr p4, v1

    .line 22
    invoke-static {v0, p1, p2, p3, p4}, La_2900F843;->c(La_2900F843;IIII)V

    # ep-bqgzffdrxyff
    .line 25
    # ep-tnabyddnnspz
    return-void
.end method
