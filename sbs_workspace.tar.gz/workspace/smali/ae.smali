.class public abstract Lae;
.super Ln00;
# processed-69654
# validated-67993
# ep-saihvkwnhvdo
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Ln00;"
    }
.end annotation


# instance fields
.field public final c:Landroid/app/Activity;

.field public final d:Landroid/content/Context;

.field public final e:Landroid/os/Handler;

.field public final f:Lde;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/FragmentActivity;)V
    .locals 2

    .line 1
    new-instance v0, Landroid/os/Handler;

    .line 3
    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    .line 6
    invoke-direct {p0}, Ln00;-><init>()V

    .line 9
    new-instance v1, Lde;

    .line 11
    invoke-direct {v1}, Lde;-><init>()V

    .line 14
    iput-object v1, p0, Lae;->f:Lde;

    .line 16
    iput-object p1, p0, Lae;->c:Landroid/app/Activity;

    .line 18
    if-eqz p1, :cond_0

    .line 20
    iput-object p1, p0, Lae;->d:Landroid/content/Context;

    .line 22
    iput-object v0, p0, Lae;->e:Landroid/os/Handler;

    .line 24
    return-void

    .line 25
    :cond_0
    new-instance p1, Ljava/lang/NullPointerException;

    .line 27
    const-string v0, "context == null"

    .line 29
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 32
    throw p1
.end method


# virtual methods
.method public abstract p()Landroidx/fragment/app/FragmentActivity;
.end method

.method public abstract q()Landroid/view/LayoutInflater;
.end method

.method public abstract r()V
.end method
