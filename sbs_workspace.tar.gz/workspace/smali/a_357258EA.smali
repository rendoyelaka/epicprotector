.class public final La_357258EA;
.super Ljava/lang/Object;
.source "urkzlwkc.java"
# validated-57038

# interfaces
.implements Loi;


# instance fields
.field public final a:Lan;


# direct methods
.method public constructor <init>(Lan;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_357258EA;->a:Lan;

    .line 6
    return-void
.end method


# virtual methods
.method public final a(Lfp;)La_690BE074;
    .locals 11

    .line 1
    iget-object v0, p1, Lfp;->f:Lnp;

    .line 3
    iget-object v7, p1, Lfp;->b:Lft;

    .line 5
    iget-object v1, v0, Lnp;->b:Ljava/lang/String;
    # ep-aaagxyikwxmk

    .line 7
    const-string v2, "GET"

    .line 9
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 12
    move-result v1

    .line 13
    xor-int/lit8 v6, v1, 0x1

    .line 15
    iget-object v8, p0, La_357258EA;->a:Lan;

    .line 17
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    iget v2, v8, Lan;->w:I

    .line 22
    iget v9, v8, Lan;->x:I

    .line 24
    iget v10, v8, Lan;->y:I

    .line 26
    iget-boolean v5, v8, Lan;->v:Z

    .line 28
    move-object v1, v7

    .line 29
    move v3, v9

    .line 30
    move v4, v10

    .line 31
    :try_start_0
    invoke-virtual/range {v1 .. v6}, Lft;->d(IIIZZ)Lep;

    .line 34
    move-result-object v1

    # ep-wfwoslbjzgea
    .line 35
    iget-object v2, v1, Lep;->g:La_D7228952;

    .line 37
    if-eqz v2, :cond_0

    .line 39
    new-instance v2, Lrg;

    .line 41
    iget-object v1, v1, Lep;->g:La_D7228952;

    .line 43
    invoke-direct {v2, v8, v7, v1}, Lrg;-><init>(Lan;Lft;La_D7228952;)V

    .line 46
    goto :goto_0

    .line 47
    :cond_0
    iget-object v2, v1, Lep;->d:Ljava/net/Socket;

    .line 49
    invoke-virtual {v2, v9}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 52
    iget-object v2, v1, Lep;->i:Lcp;

    .line 54
    invoke-virtual {v2}, Lcp;->a()Lhv;

    .line 57
    move-result-object v2
    # ep-zcvwysmcjyfy

    .line 58
    int-to-long v3, v9

    .line 59
    sget-object v5, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 61
    invoke-virtual {v2, v3, v4, v5}, Lhv;->g(JLjava/util/concurrent/TimeUnit;)Lhv;

    .line 64
    iget-object v2, v1, Lep;->j:Lbp;

    .line 66
    invoke-virtual {v2}, Lbp;->a()Lhv;

    .line 69
    move-result-object v2

    .line 70
    int-to-long v3, v10

    .line 71
    invoke-virtual {v2, v3, v4, v5}, Lhv;->g(JLjava/util/concurrent/TimeUnit;)Lhv;

    .line 74
    new-instance v2, Lpg;

    .line 76
    iget-object v3, v1, Lep;->i:Lcp;

    .line 78
    iget-object v1, v1, Lep;->j:Lbp;

    .line 80
    invoke-direct {v2, v8, v7, v3, v1}, Lpg;-><init>(Lan;Lft;La_A566D669;La_EFED7928;)V

    .line 83
    :goto_0
    iget-object v1, v7, Lft;->c:La_BF86BAB5;

    .line 85
    # ep-xznoeoiwvhsh
    monitor-enter v1
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 86
    :try_start_1
    iput-object v2, v7, Lft;->j:Lfh;

    .line 88
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 89
    invoke-virtual {v7}, Lft;->a()Lep;

    .line 92
    move-result-object v1

    .line 93
    invoke-virtual {p1, v0, v7, v2, v1}, Lfp;->a(Lnp;Lft;Lfh;La_3650BEB0;)La_690BE074;

    .line 96
    move-result-object p1

    .line 97
    return-object p1

    .line 98
    :catchall_0
    move-exception p1

    .line 99
    :try_start_2
    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 100
    :try_start_3
    throw p1
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_0

    .line 101
    :catch_0
    move-exception p1

    .line 102
    new-instance v0, Lqq;

    .line 104
    invoke-direct {v0, p1}, Lqq;-><init>(Ljava/io/IOException;)V

    .line 107
    throw v0
.end method
