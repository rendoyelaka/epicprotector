.class public final LHttp2Stream$a;
.super Ljava/lang/Object;
.source "atwzqplv.java"
# ep-iwnxspghwsee
# compiled-60424

# interfaces
.implements Lrs;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Stream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final c:Lv4;

.field public d:I

.field public e:B

.field public f:I

.field public g:I

.field public h:S


# direct methods
.method public constructor <init>(Lv4;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, LHttp2Stream$a;->c:Lv4;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()Lhv;
    .locals 1

    iget-object v0, p0, LHttp2Stream$a;->c:Lv4;

    invoke-interface {v0}, Lrs;->a()Lhv;

    move-result-object v0

    return-object v0
.end method

.method public final close()V
    .locals 0

    return-void
.end method

.method public final k(Lt4;J)J
    .locals 7

    .line 1
    :goto_0
    iget p2, p0, LHttp2Stream$a;->g:I

    .line 3
    const-wide/16 v0, -0x1

    .line 5
    iget-object p3, p0, LHttp2Stream$a;->c:Lv4;

    .line 7
    if-nez p2, :cond_4

    .line 9
    iget-short p2, p0, LHttp2Stream$a;->h:S

    .line 11
    int-to-long v2, p2

    .line 12
    invoke-interface {p3, v2, v3}, Lv4;->skip(J)V

    .line 15
    const/4 p2, 0x0

    .line 16
    iput-short p2, p0, LHttp2Stream$a;->h:S

    .line 18
    iget-byte v2, p0, LHttp2Stream$a;->e:B

    .line 20
    and-int/lit8 v2, v2, 0x4

    .line 22
    if-eqz v2, :cond_0

    .line 24
    return-wide v0

    .line 25
    :cond_0
    iget v0, p0, LHttp2Stream$a;->f:I

    .line 27
    invoke-interface {p3}, Lv4;->readByte()B

    .line 30
    move-result v1

    .line 31
    and-int/lit16 v1, v1, 0xff

    .line 33
    shl-int/lit8 v1, v1, 0x10

    .line 35
    invoke-interface {p3}, Lv4;->readByte()B

    .line 38
    move-result v2

    .line 39
    and-int/lit16 v2, v2, 0xff

    .line 41
    shl-int/lit8 v2, v2, 0x8

    .line 43
    or-int/2addr v1, v2

    .line 44
    invoke-interface {p3}, Lv4;->readByte()B

    .line 47
    move-result v2

    .line 48
    and-int/lit16 v2, v2, 0xff

    .line 50
    or-int/2addr v1, v2

    .line 51
    iput v1, p0, LHttp2Stream$a;->g:I

    .line 53
    iput v1, p0, LHttp2Stream$a;->d:I

    .line 55
    invoke-interface {p3}, Lv4;->readByte()B

    .line 58
    move-result v1

    .line 59
    and-int/lit16 v1, v1, 0xff

    .line 61
    int-to-byte v1, v1

    .line 62
    invoke-interface {p3}, Lv4;->readByte()B

    .line 65
    move-result v2

    .line 66
    and-int/lit16 v2, v2, 0xff

    .line 68
    int-to-byte v2, v2

    .line 69
    iput-byte v2, p0, LHttp2Stream$a;->e:B

    .line 71
    sget-object v2, LHttp2Stream;->g:Ljava/util/logging/Logger;

    .line 73
    sget-object v3, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;

    .line 75
    invoke-virtual {v2, v3}, Ljava/util/logging/Logger;->isLoggable(Ljava/util/logging/Level;)Z

    .line 78
    move-result v3

    .line 79
    const/4 v4, 0x1

    .line 80
    if-eqz v3, :cond_1

    .line 82
    iget v3, p0, LHttp2Stream$a;->f:I

    .line 84
    iget v5, p0, LHttp2Stream$a;->d:I

    .line 86
    iget-byte v6, p0, LHttp2Stream$a;->e:B

    .line 88
    invoke-static {v4, v3, v5, v1, v6}, Lqg;->a(ZIIBB)Ljava/lang/String;

    .line 91
    move-result-object v3

    .line 92
    invoke-virtual {v2, v3}, Ljava/util/logging/Logger;->fine(Ljava/lang/String;)V

    .line 95
    :cond_1
    invoke-interface {p3}, Lv4;->readInt()I

    .line 98
    move-result p3

    .line 99
    const v2, 0x7fffffff

    .line 102
    and-int/2addr p3, v2

    .line 103
    iput p3, p0, LHttp2Stream$a;->f:I

    .line 105
    const/16 v2, 0x9

    .line 107
    const/4 v3, 0x0

    .line 108
    if-ne v1, v2, :cond_3

    .line 110
    if-ne p3, v0, :cond_2

    .line 112
    goto :goto_0

    .line 113
    :cond_2
    const-string p1, "TYPE_CONTINUATION streamId changed"

    .line 115
    new-array p2, p2, [Ljava/lang/Object;

    .line 117
    invoke-static {p1, p2}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 120
    throw v3

    .line 121
    :cond_3
    new-array p1, v4, [Ljava/lang/Object;

    .line 123
    invoke-static {v1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 126
    move-result-object p3

    .line 127
    aput-object p3, p1, p2

    .line 129
    const-string p2, "%s != TYPE_CONTINUATION"

    .line 131
    invoke-static {p2, p1}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 134
    throw v3

    .line 135
    :cond_4
    int-to-long v2, p2

    .line 136
    const-wide/16 v4, 0x2000

    .line 138
    invoke-static {v4, v5, v2, v3}, Ljava/lang/Math;->min(JJ)J

    .line 141
    move-result-wide v2

    .line 142
    invoke-interface {p3, p1, v2, v3}, Lrs;->k(Lt4;J)J

    .line 145
    move-result-wide p1

    .line 146
    cmp-long p3, p1, v0

    .line 148
    if-nez p3, :cond_5

    .line 150
    return-wide v0

    .line 151
    :cond_5
    iget p3, p0, LHttp2Stream$a;->g:I

    .line 153
    int-to-long v0, p3

    .line 154
    sub-long/2addr v0, p1

    .line 155
    long-to-int p3, v0

    .line 156
    iput p3, p0, LHttp2Stream$a;->g:I

    .line 158
    return-wide p1
.end method
