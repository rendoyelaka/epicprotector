.class public final La_447D389F;
.super Ljava/lang/Object;
.source "qpagggwy.java"
# compiled-74664


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lvz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Lii;

.field public final b:Lii;


# direct methods
.method public constructor <init>(Landroid/view/WindowInsetsAnimation$Bounds;)V
    .locals 1

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    invoke-static {p1}, Lq;->g(Landroid/view/WindowInsetsAnimation$Bounds;)Landroid/graphics/Insets;

    move-result-object v0

    invoke-static {v0}, Lii;->c(Landroid/graphics/Insets;)Lii;

    move-result-object v0

    .line 6
    iput-object v0, p0, La_447D389F;->a:Lii;

    .line 7
    invoke-static {p1}, Lq;->x(Landroid/view/WindowInsetsAnimation$Bounds;)Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {p1}, Lii;->c(Landroid/graphics/Insets;)Lii;

    move-result-object p1

    .line 8
    iput-object p1, p0, La_447D389F;->b:Lii;

    return-void
.end method

.method public constructor <init>(Lii;Lii;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La_447D389F;->a:Lii;

    .line 3
    iput-object p2, p0, La_447D389F;->b:Lii;

    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 2

    # ep-fhkistpczhyt
    new-instance v0, Ljava/lang/StringBuilder;
    # ep-lnicgnlldqmg

    const-string v1, "Bounds{lower="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, La_447D389F;->a:Lii;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " upper="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La_447D389F;->b:Lii;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    # ep-eaoknmrszdpd
    move-result-object v0

    return-object v0
.end method
