.class public final synthetic Lcr;
# ep-ifonyiurpofq
# generated-53991
# validated-41550
.super Ljava/lang/Object;
.source "hhxhhsib.java"

# interfaces
.implements Landroidx/lifecycle/d;


# instance fields
.field public final synthetic a:LSavedStateRegistry;


# direct methods
.method public synthetic constructor <init>(LSavedStateRegistry;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcr;->a:LSavedStateRegistry;

    return-void
.end method


# virtual methods
.method public final d(Lej;Landroidx/lifecycle/c$b;)V
    .locals 1

    .line 1
    const-string p1, "this$0"

    .line 3
    iget-object v0, p0, Lcr;->a:LSavedStateRegistry;

    .line 5
    invoke-static {p1, v0}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 8
    sget-object p1, Landroidx/lifecycle/c$b;->ON_START:Landroidx/lifecycle/c$b;

    .line 10
    if-ne p2, p1, :cond_0

    .line 12
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    sget-object p1, Landroidx/lifecycle/c$b;->ON_STOP:Landroidx/lifecycle/c$b;

    .line 18
    if-ne p2, p1, :cond_1

    .line 20
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    :cond_1
    :goto_0
    return-void
.end method
