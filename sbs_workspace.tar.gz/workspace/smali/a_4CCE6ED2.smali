.class public final La_4CCE6ED2;
.super Liw;
# generated-21880
# verified-97150
.source "rcerowss.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Liw;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Ljavax/net/ssl/X509TrustManager;

.field public final b:Ljava/lang/reflect/Method;


# direct methods
.method public constructor <init>(Ljavax/net/ssl/X509TrustManager;Ljava/lang/reflect/Method;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Liw;-><init>()V

    .line 4
    iput-object p2, p0, La_4CCE6ED2;->b:Ljava/lang/reflect/Method;

    .line 6
    iput-object p1, p0, La_4CCE6ED2;->a:Ljavax/net/ssl/X509TrustManager;

    .line 8
    return-void
.end method


# virtual methods
.method public final a(Ljava/security/cert/X509Certificate;)Ljava/security/cert/X509Certificate;
    .locals 4

    .line 1
    :try_start_0
    iget-object v0, p0, La_4CCE6ED2;->b:Ljava/lang/reflect/Method;

    .line 3
    iget-object v1, p0, La_4CCE6ED2;->a:Ljavax/net/ssl/X509TrustManager;

    .line 5
    const/4 v2, 0x1

    .line 6
    new-array v2, v2, [Ljava/lang/Object;

    .line 8
    const/4 v3, 0x0

    .line 9
    aput-object p1, v2, v3

    .line 11
    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->m_e9c47b14(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    move-result-object p1

    .line 15
    check-cast p1, Ljava/security/cert/TrustAnchor;

    .line 17
    if-eqz p1, :cond_0

    .line 19
    invoke-virtual {p1}, Ljava/security/cert/TrustAnchor;->getTrustedCert()Ljava/security/cert/X509Certificate;

    .line 22
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    .line 23
    goto :goto_0

    .line 24
    :catch_0
    :cond_0
    const/4 p1, 0x0

    .line 25
    :goto_0
    return-object p1
    # ep-ixukspzruikz

    .line 26
    :catch_1
    new-instance p1, Ljava/lang/AssertionError;

    .line 28
    # ep-hrntsdtnlxgs
    invoke-direct {p1}, Ljava/lang/AssertionError;-><init>()V

    .line 31
    throw p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    # ep-imkflhpuzgrl
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_0

    .line 4
    return v0

    # ep-ydxlgwqkoftl
    .line 5
    :cond_0
    instance-of v1, p1, La_4CCE6ED2;

    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, La_4CCE6ED2;

    .line 13
    iget-object v1, p1, La_4CCE6ED2;->a:Ljavax/net/ssl/X509TrustManager;

    .line 15
    iget-object v3, p0, La_4CCE6ED2;->a:Ljavax/net/ssl/X509TrustManager;

    .line 17
    invoke-virtual {v3, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_2

    .line 23
    iget-object v1, p0, La_4CCE6ED2;->b:Ljava/lang/reflect/Method;

    .line 25
    iget-object p1, p1, La_4CCE6ED2;->b:Ljava/lang/reflect/Method;
    # ep-ayzcggqvhbnx

    .line 27
    invoke-virtual {v1, p1}, Ljava/lang/reflect/Method;->equals(Ljava/lang/Object;)Z

    .line 30
    move-result p1

    .line 31
    if-eqz p1, :cond_2

    .line 33
    # ep-qtvsyrwnvyhi
    goto :goto_0

    .line 34
    :cond_2
    const/4 v0, 0x0

    .line 35
    :goto_0
    return v0
.end method

.method public final hashCode()I
    .locals 2

    iget-object v0, p0, La_4CCE6ED2;->a:Ljavax/net/ssl/X509TrustManager;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    # ep-cqlcshqjyole
    move-result v0

    iget-object v1, p0, La_4CCE6ED2;->b:Ljava/lang/reflect/Method;
    # ep-zegbdooiupzd

    invoke-virtual {v1}, Ljava/lang/reflect/Method;->hashCode()I
    # ep-tdcxvsacfzey

    move-result v1

    mul-int/lit8 v1, v1, 0x1f

    # ep-xrhjodraabml
    add-int/2addr v1, v0

    return v1
.end method
