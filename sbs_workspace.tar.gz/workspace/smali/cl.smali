.class public final Lcl;
# ep-dpyjanmakthx
.super Ldo;
.source "zcrsmgor.java"

# optimised-83163
# compiled-41715

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<S:",
        "Ljava/lang/Object;",
        ">",
        "Ldo<",
        "TS;>;"
    }
.end annotation


# instance fields
.field public U:I

.field public V:Lj9;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lj9<",
            "TS;>;"
        }
    .end annotation
.end field

.field public W:Lcom/google/android/material/datepicker/a;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ldo;-><init>()V

    return-void
.end method


# virtual methods
.method public final r(Landroid/os/Bundle;)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, LFragment;->r(Landroid/os/Bundle;)V

    .line 4
    if-nez p1, :cond_0

    .line 6
    iget-object p1, p0, LFragment;->h:Landroid/os/Bundle;

    .line 8
    :cond_0
    const-string v1, "/lEXoMZz/E/G+c/HyDn5XA=="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 10
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 13
    move-result v0

    .line 14
    iput v0, p0, Lcl;->U:I

    .line 16
    const-string v1, "7lgGqNx/60bQ5dLMxS33QIE="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 21
    move-result-object v0

    .line 22
    check-cast v0, Lj9;

    .line 24
    iput-object v0, p0, Lcl;->V:Lj9;

    .line 26
    const-string v1, "6VgeqM1o71jK5cnNxCbuRJFm6/HBx539"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 28
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 31
    move-result-object p1

    .line 32
    check-cast p1, Lcom/google/android/material/datepicker/a;

    .line 34
    iput-object p1, p0, Lcl;->W:Lcom/google/android/material/datepicker/a;

    .line 36
    return-void
.end method

.method public final s(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 1

    .line 1
    new-instance p2, Landroid/view/ContextThemeWrapper;

    .line 3
    invoke-virtual {p0}, LFragment;->i()Landroid/content/Context;

    .line 6
    move-result-object p3

    .line 7
    iget v0, p0, Lcl;->U:I

    .line 9
    invoke-direct {p2, p3, v0}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    .line 12
    invoke-virtual {p1, p2}, Landroid/view/LayoutInflater;->cloneInContext(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 15
    iget-object p1, p0, Lcl;->V:Lj9;

    .line 17
    new-instance p2, Lcl$a;

    .line 19
    invoke-direct {p2, p0}, Lcl$a;-><init>(Lcl;)V

    .line 22
    invoke-interface {p1}, Lj9;->j()Landroid/view/View;

    .line 25
    move-result-object p1

    .line 26
    return-object p1
.end method

.method public final w(Landroid/os/Bundle;)V
    .locals 3

    .line 1
    const-string v2, "/lEXoMZz/E/G+c/HyDn5XA=="
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    iget v1, p0, Lcl;->U:I

    .line 5
    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 8
    const-string v2, "7lgGqNx/60bQ5dLMxS33QIE="
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 10
    iget-object v1, p0, Lcl;->V:Lj9;

    .line 12
    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 15
    const-string v2, "6VgeqM1o71jK5cnNxCbuRJFm6/HBx539"
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 17
    iget-object v1, p0, Lcl;->W:Lcom/google/android/material/datepicker/a;

    .line 19
    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 22
    return-void
.end method
