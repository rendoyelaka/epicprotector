.class public final La_58497785;
# ep-kcrtyervnqme
# optimised-47985
# optimised-63710
.super Ljava/lang/Object;
.source "wmurkahi.java"


# instance fields
.field public final a:Landroid/widget/CompoundButton;

.field public b:Landroid/content/res/ColorStateList;

.field public c:Landroid/graphics/PorterDuff$Mode;

.field public d:Z

.field public e:Z

.field public f:Z


# direct methods
.method public constructor <init>(Landroid/widget/CompoundButton;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, La_58497785;->b:Landroid/content/res/ColorStateList;

    .line 7
    iput-object v0, p0, La_58497785;->c:Landroid/graphics/PorterDuff$Mode;

    .line 9
    const/4 v0, 0x0

    .line 10
    iput-boolean v0, p0, La_58497785;->d:Z

    .line 12
    iput-boolean v0, p0, La_58497785;->e:Z

    .line 14
    iput-object p1, p0, La_58497785;->a:Landroid/widget/CompoundButton;

    .line 16
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    .line 1
    iget-object v0, p0, La_58497785;->a:Landroid/widget/CompoundButton;

    .line 3
    invoke-static {v0}, La_43AC2462;->a(Landroid/widget/CompoundButton;)Landroid/graphics/drawable/Drawable;

    .line 6
    move-result-object v1

    .line 7
    if-eqz v1, :cond_4

    .line 9
    iget-boolean v2, p0, La_58497785;->d:Z

    .line 11
    if-nez v2, :cond_0

    .line 13
    iget-boolean v2, p0, La_58497785;->e:Z

    .line 15
    if-eqz v2, :cond_4

    .line 17
    :cond_0
    invoke-static {v1}, Lta;->g(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->m_e416d128()Landroid/graphics/drawable/Drawable;

    .line 24
    move-result-object v1

    .line 25
    iget-boolean v2, p0, La_58497785;->d:Z

    .line 27
    if-eqz v2, :cond_1

    .line 29
    iget-object v2, p0, La_58497785;->b:Landroid/content/res/ColorStateList;

    .line 31
    invoke-static {v1, v2}, La_4F46A9E0;->h(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 34
    :cond_1
    iget-boolean v2, p0, La_58497785;->e:Z

    .line 36
    if-eqz v2, :cond_2

    .line 38
    iget-object v2, p0, La_58497785;->c:Landroid/graphics/PorterDuff$Mode;

    .line 40
    invoke-static {v1, v2}, La_4F46A9E0;->i(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    .line 43
    :cond_2
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->m_46259b2f()Z

    .line 46
    move-result v2

    .line 47
    if-eqz v2, :cond_3

    .line 49
    invoke-virtual {v0}, Landroid/view/View;->getDrawableState()[I

    .line 52
    move-result-object v2

    .line 53
    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->m_36047764([I)Z

    .line 56
    :cond_3
    invoke-virtual {v0, v1}, Landroid/widget/CompoundButton;->m_6d42912e(Landroid/graphics/drawable/Drawable;)V

    .line 59
    :cond_4
    return-void
.end method

.method public final b(Landroid/util/AttributeSet;I)V
    .locals 8

    .line 1
    iget-object v6, p0, La_58497785;->a:Landroid/widget/CompoundButton;

    .line 3
    invoke-virtual {v6}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 6
    move-result-object v0

    .line 7
    sget-object v2, La_2C13166E;->f_04ca7c74:[I

    .line 9
    invoke-static {v0, p1, v2, p2}, Lmv;->m(Landroid/content/Context;Landroid/util/AttributeSet;[II)Lmv;

    .line 12
    move-result-object v7

    .line 13
    invoke-virtual {v6}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 16
    move-result-object v1

    .line 17
    iget-object v4, v7, Lmv;->b:Landroid/content/res/TypedArray;

    .line 19
    move-object v0, v6

    .line 20
    move-object v3, p1

    .line 21
    move v5, p2

    .line 22
    invoke-static/range {v0 .. v5}, Lqx;->o(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;I)V

    .line 25
    const/4 p1, 0x1

    .line 26
    :try_start_0
    invoke-virtual {v7, p1}, Lmv;->l(I)Z

    .line 29
    move-result p2

    .line 30
    const/4 v0, 0x0

    .line 31
    if-eqz p2, :cond_0

    .line 33
    invoke-virtual {v7, p1, v0}, Lmv;->i(II)I

    .line 36
    move-result p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 37
    if-eqz p2, :cond_0

    .line 39
    :try_start_1
    invoke-virtual {v6}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 42
    move-result-object v1

    .line 43
    invoke-static {v1, p2}, La_2C13166E;->m_d26d803e(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 46
    move-result-object p2

    .line 47
    invoke-virtual {v6, p2}, Landroid/widget/CompoundButton;->m_6d42912e(Landroid/graphics/drawable/Drawable;)V
    :try_end_1
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 50
    goto :goto_0

    .line 51
    :catch_0
    nop

    .line 52
    :cond_0
    const/4 p1, 0x0

    .line 53
    :goto_0
    if-nez p1, :cond_1

    .line 55
    :try_start_2
    invoke-virtual {v7, v0}, Lmv;->l(I)Z

    .line 58
    move-result p1

    .line 59
    if-eqz p1, :cond_1

    .line 61
    invoke-virtual {v7, v0, v0}, Lmv;->i(II)I

    .line 64
    move-result p1

    .line 65
    if-eqz p1, :cond_1

    .line 67
    invoke-virtual {v6}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 70
    move-result-object p2

    .line 71
    invoke-static {p2, p1}, La_2C13166E;->m_d26d803e(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 74
    move-result-object p1

    .line 75
    invoke-virtual {v6, p1}, Landroid/widget/CompoundButton;->m_6d42912e(Landroid/graphics/drawable/Drawable;)V

    .line 78
    :cond_1
    const/4 p1, 0x2

    .line 79
    invoke-virtual {v7, p1}, Lmv;->l(I)Z

    .line 82
    move-result p2

    .line 83
    if-eqz p2, :cond_2

    .line 85
    invoke-virtual {v7, p1}, Lmv;->b(I)Landroid/content/res/ColorStateList;

    .line 88
    move-result-object p1

    .line 89
    invoke-static {v6, p1}, La_BE7C7280;->c(Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V

    .line 92
    :cond_2
    const/4 p1, 0x3

    .line 93
    invoke-virtual {v7, p1}, Lmv;->l(I)Z

    .line 96
    move-result p2

    .line 97
    if-eqz p2, :cond_3

    .line 99
    const/4 p2, -0x1

    .line 100
    invoke-virtual {v7, p1, p2}, Lmv;->h(II)I

    .line 103
    move-result p1

    .line 104
    const/4 p2, 0x0

    .line 105
    invoke-static {p1, p2}, Lwa;->b(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    .line 108
    move-result-object p1

    .line 109
    invoke-static {v6, p1}, La_BE7C7280;->d(Landroid/widget/CompoundButton;Landroid/graphics/PorterDuff$Mode;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 112
    :cond_3
    invoke-virtual {v7}, Lmv;->n()V

    .line 115
    return-void

    .line 116
    :catchall_0
    move-exception p1

    .line 117
    invoke-virtual {v7}, Lmv;->n()V

    .line 120
    throw p1
.end method
