.class public final La_6BB9F8F3;
.super Ljava/lang/Object;
.source "vvwgofor.java"
# ep-tmttfbqtehpp

# optimised-78121

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_C247270D;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
