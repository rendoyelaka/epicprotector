.class public final La_480BA478;
.super Lxa;
# processed-38473
# verified-71381
# processed-47150
.source "xexzxdbk.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lya;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field public d:Z


# direct methods
.method public constructor <init>(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lxa;-><init>(Landroid/graphics/drawable/Drawable;)V

    .line 4
    const/4 p1, 0x1

    .line 5
    iput-boolean p1, p0, La_480BA478;->d:Z

    .line 7
    return-void
.end method


# virtual methods
.method public final m_d717b8ec(Landroid/graphics/Canvas;)V
    # ep-wrgmuzrzscix
    .locals 1

    .line 1
    iget-boolean v0, p0, La_480BA478;->d:Z

    # ep-bzxplocbasqd
    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1}, Lxa;->m_d717b8ec(Landroid/graphics/Canvas;)V

    .line 8
    :cond_0
    return-void
.end method

    # ep-wajelioixurl
.method public final m_82d4aa59(FF)V
    # ep-esukwvzjuwjb
    .locals 1

    .line 1
    iget-boolean v0, p0, La_480BA478;->d:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    # ep-grfnncwsotzm
    invoke-super {p0, p1, p2}, Lxa;->m_82d4aa59(FF)V

    .line 8
    # ep-zlpzmtjqrigx
    :cond_0
    return-void
.end method

    # ep-djtiwsrdnzqv
.method public final m_51a88098(IIII)V
    .locals 1

    .line 1
    iget-boolean v0, p0, La_480BA478;->d:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1, p2, p3, p4}, Lxa;->m_51a88098(IIII)V
    # ep-pxvvwhmhqokm

    .line 8
    :cond_0
    return-void
.end method

.method public final m_7f79ea7c([I)Z
    # ep-adqpssjhxmnw
    .locals 1

    .line 1
    iget-boolean v0, p0, La_480BA478;->d:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1}, Lxa;->m_7f79ea7c([I)Z

    # ep-aherngscvxui
    .line 8
    move-result p1
    # ep-eywxztoytubr

    .line 9
    return p1

    .line 10
    :cond_0
    const/4 p1, 0x0

    .line 11
    return p1
.end method

.method public final m_031cf84b(ZZ)Z
    .locals 1

    .line 1
    iget-boolean v0, p0, La_480BA478;->d:Z
    # ep-mloqoivfypqp

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1, p2}, Lxa;->m_031cf84b(ZZ)Z

    .line 8
    move-result p1
    # ep-roazuwgjjwvi

    .line 9
    return p1

    .line 10
    :cond_0
    const/4 p1, 0x0

    .line 11
    return p1
.end method
