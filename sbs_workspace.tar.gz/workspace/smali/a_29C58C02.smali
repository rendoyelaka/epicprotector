.class public final La_29C58C02;
.super La_F5C4F8D6;
.source "titmncoj.java"
# ep-aopplrnprhvq

# verified-55003
# verified-19283
# processed-31429

# instance fields
.field public final synthetic f_811b1921:Lu1;


# direct methods
.method public constructor <init>(Lu1;)V
    .locals 0

    iput-object p1, p0, La_29C58C02;->f_811b1921:Lu1;

    invoke-direct {p0}, La_F5C4F8D6;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    .line 1
    iget-object v0, p0, La_29C58C02;->f_811b1921:Lu1;

    .line 3
    iget-object v1, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 5
    const/high16 v2, 0x3f800000    # 1.0f

    .line 7
    invoke-virtual {v1, v2}, Landroid/view/View;->m_302f9ab3(F)V

    .line 10
    iget-object v1, v0, Lu1;->t:Lky;

    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-virtual {v1, v2}, Lky;->d(Lmy;)V

    .line 16
    iput-object v2, v0, Lu1;->t:Lky;

    .line 18
    return-void
.end method

.method public final c()V
    .locals 3

    .line 1
    iget-object v0, p0, La_29C58C02;->f_811b1921:Lu1;

    .line 3
    iget-object v1, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/ActionBarContextView;->setVisibility(I)V

    .line 9
    iget-object v1, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 11
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 14
    move-result-object v1

    .line 15
    instance-of v1, v1, Landroid/view/View;

    .line 17
    if-eqz v1, :cond_0

    .line 19
    iget-object v0, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 21
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Landroid/view/View;

    .line 27
    sget-object v1, Lqx;->a:Ljava/util/WeakHashMap;

    .line 29
    invoke-static {v0}, La_09F7FDBC;->c(Landroid/view/View;)V

    .line 32
    :cond_0
    return-void
.end method
