.class public final LWorkSpecDao$d;
.super Lcs;
# ep-ckgxkzditzfz
.source "lqhvabil.java"

# generated-14395
# optimised-45447
# processed-73922

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "5/PsB177QDcQG/7p75gaSWq4x+MzSXU98Xh5T4oA9trt18Erb4NfYCgh0Mja3RANBMI="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
