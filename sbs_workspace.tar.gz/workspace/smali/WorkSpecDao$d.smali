.class public final LWorkSpecDao$d;
.super Lcs;
.source "wjczjexn.java"
# ep-akzsaonsedbj

# verified-78719
# compiled-86895
# processed-98881

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 2

    const-string v1, "E7vWgYcAKwMsNRd5262NSQjLGmNiZ93juKsCX7R0TqUZn/uttng0VBQPOVju6IcNZrE="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
