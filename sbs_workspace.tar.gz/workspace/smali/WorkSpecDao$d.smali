.class public final LWorkSpecDao$d;
# binding-55353-response
# activity-66819-dispatcher
# response-57708-callback
# observer-33526-request
# factory-20553-listener
.super Lcs;
.source "PreferenceManager59.java"
# ep-ohsddijoklqk
# optimised-83610
# compiled-89038


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 16

    const-string v0,new-instance v15, Ljava/lang/StringBuilder;
    const-string v0,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v0,const-string v0, "UPDATE w"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "orkspec SET"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, " period_start_time=? WHERE id=?"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v0,move-result-object v0

    return-object v0
.end method
