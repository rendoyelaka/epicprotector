.class public final LWorkSpecDao$d;
# ep-dyfrlizndlyu
.super Lcs;
# verified-76628
.source "clduvxlc.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "Xfng+3M3nKTliqwotjykVnC6+Kw25UKMq6u7a4bDs+xX3c3XQk+D892wggmDea4SHsA="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
