.class public final LWorkSpecDao$d;
.super Lcs;
# ep-pweaejaosxrk
.source "amaoouvy.java"

# generated-69770
# verified-79810
# verified-69267

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "itLZADlCspTLyE03fAboU6Qax5K7wcINL4duz/2EXKaA9vQsCDqtw/PyYxZJQ+IXymA="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
