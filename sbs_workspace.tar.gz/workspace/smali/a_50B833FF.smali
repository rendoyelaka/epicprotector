.class public final La_50B833FF;
.super La_F2B92A54;
.source "hmythvfk.java"


# optimised-20657
# verified-66574
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, La_F2B92A54;-><init>()V

    return-void
.end method

.method public constructor <init>(La_50B833FF;)V
    .locals 0

    .line 2
    invoke-direct {p0, p1}, La_F2B92A54;-><init>(La_F2B92A54;)V

    return-void
.end method
