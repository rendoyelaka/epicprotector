.class public final La_18A996FF;
.super Ljava/lang/Object;
.source "khdlfjgz.java"


# validated-16807
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# instance fields
.field public final a:I

.field public final b:La_06B1C2B4;


# direct methods
.method public constructor <init>(ILa_06B1C2B4;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, La_18A996FF;->a:I

    .line 6
    iput-object p2, p0, La_18A996FF;->b:La_06B1C2B4;

    .line 8
    return-void
.end method
