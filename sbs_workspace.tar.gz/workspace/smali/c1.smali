.class public final Lc1;
.super Landroid/animation/AnimatorListenerAdapter;
.source "zrprjyam.java"
# optimised-54922
# verified-89519
# generated-99595
# ep-qznxwazmdacc


# instance fields
.field public final synthetic a:Lb1;


# direct methods
.method public constructor <init>(Lb1;)V
    .locals 0

    iput-object p1, p0, Lc1;->a:Lb1;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 4

    .line 1
    new-instance p1, Ljava/util/ArrayList;

    .line 3
    iget-object v0, p0, Lc1;->a:Lb1;

    .line 5
    iget-object v1, v0, Lb1;->g:Ljava/util/ArrayList;

    .line 7
    invoke-direct {p1, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 10
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 13
    move-result v1

    .line 14
    const/4 v2, 0x0

    .line 15
    :goto_0
    if-ge v2, v1, :cond_0

    .line 17
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 20
    move-result-object v3

    .line 21
    check-cast v3, Lz0;

    .line 23
    invoke-virtual {v3, v0}, Lz0;->a(Landroid/graphics/drawable/Drawable;)V

    .line 26
    add-int/lit8 v2, v2, 0x1

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    return-void
.end method

.method public final onAnimationStart(Landroid/animation/Animator;)V
    .locals 4

    .line 1
    new-instance p1, Ljava/util/ArrayList;

    .line 3
    iget-object v0, p0, Lc1;->a:Lb1;

    .line 5
    iget-object v1, v0, Lb1;->g:Ljava/util/ArrayList;

    .line 7
    invoke-direct {p1, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 10
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 13
    move-result v1

    .line 14
    const/4 v2, 0x0

    .line 15
    :goto_0
    if-ge v2, v1, :cond_0

    .line 17
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 20
    move-result-object v3

    .line 21
    check-cast v3, Lz0;

    .line 23
    invoke-virtual {v3, v0}, Lz0;->b(Landroid/graphics/drawable/Drawable;)V

    .line 26
    add-int/lit8 v2, v2, 0x1

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    return-void
.end method
