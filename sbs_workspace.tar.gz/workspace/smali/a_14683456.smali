.class public final La_14683456;
.super Ljava/lang/Object;
.source "pyvtwnne.java"

# interfaces
# optimised-66219
# compiled-89903
# validated-97793
.implements La_2994889C;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_D370F97A;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv8$b<",
        "La_D370F97A;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
