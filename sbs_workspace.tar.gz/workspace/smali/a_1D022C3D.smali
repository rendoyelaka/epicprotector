.class public final La_1D022C3D;
# ep-bhmqudbmdaas
.super La_56A5C342;
# processed-66173
# generated-37429
.source "kujsisft.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public e:La_14245EA9;

.field public f:F

.field public g:La_14245EA9;

.field public h:F

.field public i:F

.field public j:F

.field public k:F

.field public l:F

.field public m:Landroid/graphics/Paint$Cap;

.field public n:Landroid/graphics/Paint$Join;

.field public o:F


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, La_56A5C342;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput v0, p0, La_1D022C3D;->f:F

    const/high16 v1, 0x3f800000    # 1.0f

    .line 3
    iput v1, p0, La_1D022C3D;->h:F

    .line 4
    iput v1, p0, La_1D022C3D;->i:F

    .line 5
    iput v0, p0, La_1D022C3D;->j:F

    .line 6
    iput v1, p0, La_1D022C3D;->k:F

    .line 7
    iput v0, p0, La_1D022C3D;->l:F

    .line 8
    sget-object v0, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    iput-object v0, p0, La_1D022C3D;->m:Landroid/graphics/Paint$Cap;

    .line 9
    sget-object v0, Landroid/graphics/Paint$Join;->MITER:Landroid/graphics/Paint$Join;

    iput-object v0, p0, La_1D022C3D;->n:Landroid/graphics/Paint$Join;

    const/high16 v0, 0x40800000    # 4.0f

    .line 10
    iput v0, p0, La_1D022C3D;->o:F

    return-void
.end method

.method public constructor <init>(La_1D022C3D;)V
    .locals 2

    .line 11
    invoke-direct {p0, p1}, La_56A5C342;-><init>(La_56A5C342;)V

    const/4 v0, 0x0

    .line 12
    iput v0, p0, La_1D022C3D;->f:F

    const/high16 v1, 0x3f800000    # 1.0f

    .line 13
    iput v1, p0, La_1D022C3D;->h:F

    .line 14
    iput v1, p0, La_1D022C3D;->i:F

    .line 15
    iput v0, p0, La_1D022C3D;->j:F

    .line 16
    iput v1, p0, La_1D022C3D;->k:F

    .line 17
    iput v0, p0, La_1D022C3D;->l:F

    .line 18
    sget-object v0, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    iput-object v0, p0, La_1D022C3D;->m:Landroid/graphics/Paint$Cap;

    .line 19
    sget-object v0, Landroid/graphics/Paint$Join;->MITER:Landroid/graphics/Paint$Join;

    iput-object v0, p0, La_1D022C3D;->n:Landroid/graphics/Paint$Join;

    const/high16 v0, 0x40800000    # 4.0f

    .line 20
    iput v0, p0, La_1D022C3D;->o:F

    .line 21
    iget-object v0, p1, La_1D022C3D;->e:La_14245EA9;

    iput-object v0, p0, La_1D022C3D;->e:La_14245EA9;

    .line 22
    iget v0, p1, La_1D022C3D;->f:F

    iput v0, p0, La_1D022C3D;->f:F

    .line 23
    iget v0, p1, La_1D022C3D;->h:F

    iput v0, p0, La_1D022C3D;->h:F

    .line 24
    iget-object v0, p1, La_1D022C3D;->g:La_14245EA9;

    iput-object v0, p0, La_1D022C3D;->g:La_14245EA9;

    .line 25
    iget v0, p1, La_56A5C342;->c:I

    iput v0, p0, La_56A5C342;->c:I

    .line 26
    iget v0, p1, La_1D022C3D;->i:F

    iput v0, p0, La_1D022C3D;->i:F

    .line 27
    iget v0, p1, La_1D022C3D;->j:F

    iput v0, p0, La_1D022C3D;->j:F

    .line 28
    iget v0, p1, La_1D022C3D;->k:F

    iput v0, p0, La_1D022C3D;->k:F

    .line 29
    iget v0, p1, La_1D022C3D;->l:F

    iput v0, p0, La_1D022C3D;->l:F

    .line 30
    iget-object v0, p1, La_1D022C3D;->m:Landroid/graphics/Paint$Cap;

    iput-object v0, p0, La_1D022C3D;->m:Landroid/graphics/Paint$Cap;

    .line 31
    iget-object v0, p1, La_1D022C3D;->n:Landroid/graphics/Paint$Join;

    iput-object v0, p0, La_1D022C3D;->n:Landroid/graphics/Paint$Join;

    .line 32
    iget p1, p1, La_1D022C3D;->o:F

    iput p1, p0, La_1D022C3D;->o:F

    return-void
.end method


# virtual methods
.method public final a()Z
    .locals 1

    iget-object v0, p0, La_1D022C3D;->g:La_14245EA9;

    invoke-virtual {v0}, La_14245EA9;->b()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, La_1D022C3D;->e:La_14245EA9;

    invoke-virtual {v0}, La_14245EA9;->b()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method public final b([I)Z
    .locals 6

    .line 1
    iget-object v0, p0, La_1D022C3D;->g:La_14245EA9;

    .line 3
    invoke-virtual {v0}, La_14245EA9;->b()Z

    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x1

    .line 8
    const/4 v3, 0x0

    .line 9
    if-eqz v1, :cond_0

    .line 11
    iget-object v1, v0, La_14245EA9;->b:Landroid/content/res/ColorStateList;

    .line 13
    invoke-virtual {v1}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    .line 16
    move-result v4

    .line 17
    invoke-virtual {v1, p1, v4}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 20
    move-result v1

    .line 21
    iget v4, v0, La_14245EA9;->c:I

    .line 23
    if-eq v1, v4, :cond_0

    .line 25
    iput v1, v0, La_14245EA9;->c:I

    .line 27
    const/4 v0, 0x1

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    const/4 v0, 0x0

    .line 30
    :goto_0
    iget-object v1, p0, La_1D022C3D;->e:La_14245EA9;

    .line 32
    invoke-virtual {v1}, La_14245EA9;->b()Z

    .line 35
    move-result v4

    .line 36
    if-eqz v4, :cond_1

    .line 38
    iget-object v4, v1, La_14245EA9;->b:Landroid/content/res/ColorStateList;

    .line 40
    invoke-virtual {v4}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    .line 43
    move-result v5

    .line 44
    invoke-virtual {v4, p1, v5}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 47
    move-result p1

    .line 48
    iget v4, v1, La_14245EA9;->c:I

    .line 50
    if-eq p1, v4, :cond_1

    .line 52
    iput p1, v1, La_14245EA9;->c:I

    .line 54
    goto :goto_1

    .line 55
    :cond_1
    const/4 v2, 0x0

    .line 56
    :goto_1
    or-int p1, v2, v0

    .line 58
    return p1
.end method

.method public m_a25a6ae9()F
    .locals 1

    iget v0, p0, La_1D022C3D;->i:F

    return v0
.end method

.method public m_6ab12179()I
    .locals 1

    .line 1
    iget-object v0, p0, La_1D022C3D;->g:La_14245EA9;

    .line 3
    iget v0, v0, La_14245EA9;->c:I

    .line 5
    return v0
.end method

.method public m_ee8f87e8()F
    .locals 1

    iget v0, p0, La_1D022C3D;->h:F

    return v0
.end method

.method public m_524de2c3()I
    .locals 1

    .line 1
    iget-object v0, p0, La_1D022C3D;->e:La_14245EA9;

    .line 3
    iget v0, v0, La_14245EA9;->c:I

    .line 5
    return v0
.end method

.method public m_117d31ee()F
    .locals 1

    iget v0, p0, La_1D022C3D;->f:F

    return v0
.end method

.method public m_d70d97fc()F
    .locals 1

    iget v0, p0, La_1D022C3D;->k:F

    return v0
.end method

.method public m_15adda4d()F
    .locals 1

    iget v0, p0, La_1D022C3D;->l:F

    return v0
.end method

.method public m_00dcef10()F
    .locals 1

    iget v0, p0, La_1D022C3D;->j:F

    return v0
.end method

.method public m_713c56bf(F)V
    .locals 0

    iput p1, p0, La_1D022C3D;->i:F

    return-void
.end method

.method public m_3e5df26b(I)V
    .locals 1

    .line 1
    iget-object v0, p0, La_1D022C3D;->g:La_14245EA9;

    .line 3
    iput p1, v0, La_14245EA9;->c:I

    .line 5
    return-void
.end method

.method public m_025a3fd2(F)V
    .locals 0

    iput p1, p0, La_1D022C3D;->h:F

    return-void
.end method

.method public m_04ebddde(I)V
    .locals 1

    .line 1
    iget-object v0, p0, La_1D022C3D;->e:La_14245EA9;

    .line 3
    iput p1, v0, La_14245EA9;->c:I

    .line 5
    return-void
.end method

.method public m_d5589f0f(F)V
    .locals 0

    iput p1, p0, La_1D022C3D;->f:F

    return-void
.end method

.method public m_325c0f8d(F)V
    .locals 0

    iput p1, p0, La_1D022C3D;->k:F

    return-void
.end method

.method public m_1515c7b4(F)V
    .locals 0

    iput p1, p0, La_1D022C3D;->l:F

    return-void
.end method

.method public m_cc89a63c(F)V
    .locals 0

    iput p1, p0, La_1D022C3D;->j:F

    return-void
.end method
