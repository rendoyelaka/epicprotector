.class public final La_0F74DF36;
.super La_9AE2D17C;
.source "cisjerto.java"

# ep-dmpxeqrohhcm
# compiled-96019

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnn;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lx00$a<",
        "La_0F74DF36;",
        "Lnn;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/Class;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "+",
            "Landroidx/work/ListenableWorker;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1}, La_9AE2D17C;-><init>(Ljava/lang/Class;)V

    .line 4
    iget-object p1, p0, La_9AE2D17C;->c:La_AA524E44;

    .line 6
    const-class v0, Landroidx/work/OverwritingInputMerger;

    .line 8
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 11
    move-result-object v0

    .line 12
    iput-object v0, p1, La_AA524E44;->d:Ljava/lang/String;

    .line 14
    return-void
.end method


# virtual methods
.method public final b()La_95A9DA12;
    .locals 2

    .line 1
    iget-boolean v0, p0, La_9AE2D17C;->a:Z

    .line 3
    if-eqz v0, :cond_1

    .line 5
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 7
    const/16 v1, 0x17

    .line 9
    if-lt v0, v1, :cond_1

    .line 11
    iget-object v0, p0, La_9AE2D17C;->c:La_AA524E44;

    .line 13
    iget-object v0, v0, La_AA524E44;->j:La_DB594D1B;

    .line 15
    iget-boolean v0, v0, La_DB594D1B;->c:Z

    .line 17
    if-nez v0, :cond_0

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 22
    const-string v1, "Cannot set backoff criteria on an idle mode job"

    .line 24
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 27
    throw v0

    .line 28
    :cond_1
    :goto_0
    new-instance v0, Lnn;

    .line 30
    invoke-direct {v0, p0}, Lnn;-><init>(La_0F74DF36;)V

    .line 33
    return-object v0
.end method

.method public final c()La_9AE2D17C;
    .locals 0

    return-object p0
.end method
