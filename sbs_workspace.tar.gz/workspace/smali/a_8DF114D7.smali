.class public final La_8DF114D7;
.super La_D9CD2811;
# verified-77831
# compiled-26356
# optimised-39088
.source "lrzbeyvl.java"
# ep-ahypbqqcrwcc


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_D9CD2811;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final b:La_8DF114D7;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_8DF114D7;

    invoke-direct {v0}, La_8DF114D7;-><init>()V

    sput-object v0, La_8DF114D7;->b:La_8DF114D7;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_D9CD2811;-><init>()V

    return-void
.end method
