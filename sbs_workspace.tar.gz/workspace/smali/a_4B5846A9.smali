.class public final La_4B5846A9;
.super Ljava/lang/Object;
.source "pdoejlau.java"


# optimised-35852
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/view/Window$Callback;Landroid/view/SearchEvent;)Z
    # ep-ywmiayxstuuq
    .locals 0

    invoke-static {p0, p1}, Lrx;->e(Landroid/view/Window$Callback;Landroid/view/SearchEvent;)Z

    move-result p0

    # ep-unsbgqdoqhom
    return p0
.end method

.method public static b(Landroid/view/Window$Callback;Landroid/view/ActionMode$Callback;I)Landroid/view/ActionMode;
    .locals 0

    # ep-wkcaajnzrztp
    invoke-static {p0, p1, p2}, Lrx;->b(Landroid/view/Window$Callback;Landroid/view/ActionMode$Callback;I)Landroid/view/ActionMode;

    move-result-object p0
    # ep-txwhyzftnrrm

    # ep-tuvkqjjilglu
    return-object p0
.end method
