.class public abstract La_747A2121;
.super Ljava/lang/Object;
# ep-kiblbntsqbtb
.source "txwwrqgu.java"
# generated-71206

# interfaces
.implements Lrs;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpg;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x401
    name = "a"
.end annotation


# instance fields
.field public final c:Lud;

.field public d:Z

.field public final synthetic e:Lpg;


# direct methods
.method public constructor <init>(Lpg;)V
    .locals 1

    .line 1
    iput-object p1, p0, La_747A2121;->e:Lpg;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    new-instance v0, Lud;

    .line 8
    iget-object p1, p1, Lpg;->c:La_34230022;

    .line 10
    invoke-interface {p1}, Lrs;->a()Lhv;

    .line 13
    move-result-object p1

    .line 14
    invoke-direct {v0, p1}, Lud;-><init>(Lhv;)V

    .line 17
    iput-object v0, p0, La_747A2121;->c:Lud;

    .line 19
    return-void
.end method


# virtual methods
.method public final a()Lhv;
    .locals 1

    iget-object v0, p0, La_747A2121;->c:Lud;

    return-object v0
.end method

.method public final h(Z)V
    .locals 5

    .line 1
    iget-object v0, p0, La_747A2121;->e:Lpg;

    .line 3
    iget v1, v0, Lpg;->e:I

    .line 5
    const/4 v2, 0x6

    .line 6
    if-ne v1, v2, :cond_0

    .line 8
    return-void

    .line 9
    :cond_0
    const/4 v3, 0x5

    .line 10
    if-ne v1, v3, :cond_2

    .line 12
    iget-object v1, p0, La_747A2121;->c:Lud;

    .line 14
    iget-object v3, v1, Lud;->e:Lhv;

    .line 16
    sget-object v4, Lhv;->d:La_65F81E5E;

    .line 18
    iput-object v4, v1, Lud;->e:Lhv;

    .line 20
    invoke-virtual {v3}, Lhv;->a()Lhv;

    .line 23
    invoke-virtual {v3}, Lhv;->b()Lhv;

    .line 26
    iput v2, v0, Lpg;->e:I

    .line 28
    iget-object v1, v0, Lpg;->b:Lft;

    .line 30
    if-eqz v1, :cond_1

    .line 32
    xor-int/lit8 p1, p1, 0x1

    .line 34
    invoke-virtual {v1, p1, v0}, Lft;->f(ZLfh;)V

    .line 37
    :cond_1
    return-void

    .line 38
    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 40
    new-instance v1, Ljava/lang/StringBuilder;

    .line 42
    const-string v2, "state: "

    .line 44
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 47
    iget v0, v0, Lpg;->e:I

    .line 49
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 52
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 55
    move-result-object v0

    .line 56
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 59
    throw p1
.end method
