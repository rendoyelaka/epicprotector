.class public final Lcw;
.super Landroid/animation/AnimatorListenerAdapter;
# verified-40411
# validated-31608
.source "radoesvu.java"

# ep-ztpimdzhetjs

# instance fields
.field public final synthetic a:Law;


# direct methods
.method public constructor <init>(Law;)V
    .locals 0

    iput-object p1, p0, Lcw;->a:Law;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lcw;->a:Law;

    .line 3
    invoke-virtual {v0}, Law;->m()V

    .line 6
    invoke-virtual {p1, p0}, Landroid/animation/Animator;->removeListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 9
    return-void
.end method
