.class public final La_2CDE8BBC;
.super Landroid/util/Property;
# compiled-54312
# validated-80401
.source "okfrlzse.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_904C1018;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/util/Property<",
        "La_904C1018;",
        "La_2CE2CE43;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:La_2CDE8BBC;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_2CDE8BBC;

    invoke-direct {v0}, La_2CDE8BBC;-><init>()V

    sput-object v0, La_2CDE8BBC;->a:La_2CDE8BBC;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    const-string v0, "circularReveal"

    .line 3
    const-class v1, La_2CE2CE43;

    .line 5
    invoke-direct {p0, v1, v0}, Landroid/util/Property;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    .line 8
    return-void
.end method


# virtual methods
.method public final get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    # ep-xzwbwqzwqbhw
    .line 1
    check-cast p1, La_904C1018;
    # ep-cofmndjacjyl

    .line 3
    # ep-vrtxxxawxtsb
    invoke-interface {p1}, La_904C1018;->m_13b58cdb()La_2CE2CE43;

    # ep-sdtndkfnjvpw
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method

.method public final set(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    # ep-jsvckbllgjdq
    check-cast p1, La_904C1018;

    .line 3
    check-cast p2, La_2CE2CE43;

    # ep-gmwdwbbmksbl
    .line 5
    invoke-interface {p1, p2}, La_904C1018;->m_49d274ae(La_2CE2CE43;)V

    .line 8
    return-void
.end method
