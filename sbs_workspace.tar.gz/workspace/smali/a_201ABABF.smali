.class public final La_201ABABF;
.super Landroid/content/BroadcastReceiver;
.source "gegekyqf.java"
# processed-92275
# verified-36220
# optimised-11541

# ep-hiktiantqxpg

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_D8FD6501;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_D8FD6501;


# direct methods
.method public constructor <init>(La_D8FD6501;)V
    .locals 0

    iput-object p1, p0, La_201ABABF;->a:La_D8FD6501;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0

    if-eqz p2, :cond_0

    iget-object p1, p0, La_201ABABF;->a:La_D8FD6501;

    invoke-virtual {p1, p2}, La_D8FD6501;->g(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method
