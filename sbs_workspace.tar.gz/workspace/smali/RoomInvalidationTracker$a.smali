.class public final LRoomInvalidationTracker$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:LRoomInvalidationTracker;


# direct methods
.method public constructor <init>(LRoomInvalidationTracker;)V
    .locals 0

    iput-object p1, p0, LRoomInvalidationTracker$a;->c:LRoomInvalidationTracker;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/util/HashSet;
    .locals 4

    .line 1
    new-instance v0, Ljava/util/HashSet;

    .line 3
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 6
    iget-object v1, p0, LRoomInvalidationTracker$a;->c:LRoomInvalidationTracker;

    .line 8
    iget-object v1, v1, LRoomInvalidationTracker;->c:Ljq;

    .line 10
    new-instance v2, Lri;

    .line 12
    const-string v3, "SELECT * FROM room_table_modification_log WHERE invalidated = 1;"

    .line 14
    invoke-direct {v2, v3}, Lri;-><init>(Ljava/lang/String;)V

    .line 17
    invoke-virtual {v1, v2}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 20
    move-result-object v1

    .line 21
    :goto_0
    :try_start_0
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    .line 24
    move-result v2

    .line 25
    if-eqz v2, :cond_0

    .line 27
    const/4 v2, 0x0

    .line 28
    invoke-interface {v1, v2}, Landroid/database/Cursor;->getInt(I)I

    .line 31
    move-result v2

    .line 32
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 35
    move-result-object v2

    .line 36
    invoke-virtual {v0, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 39
    goto :goto_0

    .line 40
    :cond_0
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 43
    invoke-virtual {v0}, Ljava/util/HashSet;->isEmpty()Z

    .line 46
    move-result v1

    .line 47
    if-nez v1, :cond_1

    .line 49
    iget-object v1, p0, LRoomInvalidationTracker$a;->c:LRoomInvalidationTracker;

    .line 51
    iget-object v1, v1, LRoomInvalidationTracker;->f:Lue;

    .line 53
    invoke-virtual {v1}, Lue;->u()I

    .line 56
    :cond_1
    return-object v0

    .line 57
    :catchall_0
    move-exception v0

    .line 58
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 61
    throw v0
.end method

.method public final run()V
    .locals 5

    .line 1
    iget-object v0, p0, LRoomInvalidationTracker$a;->c:LRoomInvalidationTracker;

    .line 3
    iget-object v0, v0, LRoomInvalidationTracker;->c:Ljq;

    .line 5
    iget-object v0, v0, Ljq;->h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 7
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    .line 10
    move-result-object v0

    .line 11
    const/4 v1, 0x1

    .line 12
    const/4 v2, 0x0

    .line 13
    const/4 v3, 0x0

    .line 14
    :try_start_0
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    .line 17
    iget-object v4, p0, LRoomInvalidationTracker$a;->c:LRoomInvalidationTracker;

    .line 19
    invoke-virtual {v4}, LRoomInvalidationTracker;->a()Z

    .line 22
    move-result v4
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 23
    if-nez v4, :cond_0

    .line 25
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 28
    return-void

    .line 29
    :cond_0
    :try_start_1
    iget-object v4, p0, LRoomInvalidationTracker$a;->c:LRoomInvalidationTracker;

    .line 31
    iget-object v4, v4, LRoomInvalidationTracker;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 33
    invoke-virtual {v4, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 36
    move-result v1
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 37
    if-nez v1, :cond_1

    .line 39
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 42
    return-void

    .line 43
    :cond_1
    :try_start_2
    iget-object v1, p0, LRoomInvalidationTracker$a;->c:LRoomInvalidationTracker;

    .line 45
    iget-object v1, v1, LRoomInvalidationTracker;->c:Ljq;

    .line 47
    iget-object v1, v1, Ljq;->c:Ltt;

    .line 49
    invoke-interface {v1}, Ltt;->n()Lst;

    .line 52
    move-result-object v1

    .line 53
    check-cast v1, Lqe;

    .line 55
    iget-object v1, v1, Lqe;->c:Landroid/database/sqlite/SQLiteDatabase;

    .line 57
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteDatabase;->inTransaction()Z

    .line 60
    move-result v1
    :try_end_2
    .catch Ljava/lang/IllegalStateException; {:try_start_2 .. :try_end_2} :catch_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 61
    if-eqz v1, :cond_2

    .line 63
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 66
    return-void

    .line 67
    :cond_2
    :try_start_3
    iget-object v1, p0, LRoomInvalidationTracker$a;->c:LRoomInvalidationTracker;

    .line 69
    iget-object v1, v1, LRoomInvalidationTracker;->c:Ljq;

    .line 71
    iget-boolean v2, v1, Ljq;->f:Z

    .line 73
    if-eqz v2, :cond_3

    .line 75
    iget-object v1, v1, Ljq;->c:Ltt;

    .line 77
    invoke-interface {v1}, Ltt;->n()Lst;

    .line 80
    move-result-object v1

    .line 81
    check-cast v1, Lqe;

    .line 83
    invoke-virtual {v1}, Lqe;->h()V
    :try_end_3
    .catch Ljava/lang/IllegalStateException; {:try_start_3 .. :try_end_3} :catch_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 86
    :try_start_4
    invoke-virtual {p0}, LRoomInvalidationTracker$a;->a()Ljava/util/HashSet;

    .line 89
    move-result-object v3

    .line 90
    invoke-virtual {v1}, Lqe;->u()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 93
    :try_start_5
    invoke-virtual {v1}, Lqe;->j()V

    .line 96
    goto :goto_0

    .line 97
    :catch_0
    nop

    .line 98
    goto :goto_0

    .line 99
    :catchall_0
    move-exception v2

    .line 100
    invoke-virtual {v1}, Lqe;->j()V

    .line 103
    throw v2

    .line 104
    :cond_3
    invoke-virtual {p0}, LRoomInvalidationTracker$a;->a()Ljava/util/HashSet;

    .line 107
    move-result-object v3
    :try_end_5
    .catch Ljava/lang/IllegalStateException; {:try_start_5 .. :try_end_5} :catch_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 108
    goto :goto_0

    .line 109
    :catchall_1
    move-exception v1

    .line 110
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 113
    throw v1

    .line 114
    :goto_0
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 117
    if-eqz v3, :cond_5

    .line 119
    invoke-interface {v3}, Ljava/util/Set;->isEmpty()Z

    .line 122
    move-result v0

    .line 123
    if-nez v0, :cond_5

    .line 125
    iget-object v0, p0, LRoomInvalidationTracker$a;->c:LRoomInvalidationTracker;

    .line 127
    iget-object v0, v0, LRoomInvalidationTracker;->h:Lwq;

    .line 129
    monitor-enter v0

    .line 130
    :try_start_6
    iget-object v1, p0, LRoomInvalidationTracker$a;->c:LRoomInvalidationTracker;

    .line 132
    iget-object v1, v1, LRoomInvalidationTracker;->h:Lwq;

    .line 134
    invoke-virtual {v1}, Lwq;->iterator()Ljava/util/Iterator;

    .line 137
    move-result-object v1

    .line 138
    check-cast v1, Lwq$e;

    .line 140
    invoke-virtual {v1}, Lwq$e;->hasNext()Z

    .line 143
    move-result v2

    .line 144
    if-nez v2, :cond_4

    .line 146
    monitor-exit v0

    .line 147
    goto :goto_1

    .line 148
    :cond_4
    invoke-virtual {v1}, Lwq$e;->next()Ljava/lang/Object;

    .line 151
    move-result-object v1

    .line 152
    check-cast v1, Ljava/util/Map$Entry;

    .line 154
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 157
    move-result-object v1

    .line 158
    check-cast v1, LRoomInvalidationTracker$d;

    .line 160
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 163
    const/4 v1, 0x0

    .line 164
    throw v1

    .line 165
    :catchall_2
    move-exception v1

    .line 166
    monitor-exit v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 167
    throw v1

    .line 168
    :cond_5
    :goto_1
    return-void
.end method
