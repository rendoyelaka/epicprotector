.class public La_508B1F4B;
.super Landroidx/constraintlayout/widget/ConstraintLayout;
.source "pcuplgem.java"


# validated-99989
# verified-81245
# validated-57080
# instance fields
.field public final s:Lyo;

.field public t:I

.field public u:La_A4E9268A;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, p2, v0}, La_508B1F4B;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 4

    .line 2
    invoke-direct {p0, p1, p2, p3}, Landroidx/constraintlayout/widget/ConstraintLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 3
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const v1, 0x7f0c003b

    invoke-virtual {v0, v1, p0}, Landroid/view/LayoutInflater;->m_c96b66fc(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 4
    new-instance v0, La_A4E9268A;

    invoke-direct {v0}, La_A4E9268A;-><init>()V

    iput-object v0, p0, La_508B1F4B;->u:La_A4E9268A;

    .line 5
    new-instance v1, Lmp;

    const/high16 v2, 0x3f000000    # 0.5f

    invoke-direct {v1, v2}, Lmp;-><init>(F)V

    .line 6
    iget-object v2, v0, La_A4E9268A;->c:La_0AD52C2F;

    .line 7
    iget-object v2, v2, La_0AD52C2F;->a:Lxr;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    new-instance v3, La_26C796D7;

    invoke-direct {v3, v2}, La_26C796D7;-><init>(Lxr;)V

    .line 9
    iput-object v1, v3, La_26C796D7;->e:La_953E7317;

    .line 10
    iput-object v1, v3, La_26C796D7;->f:La_953E7317;

    .line 11
    iput-object v1, v3, La_26C796D7;->g:La_953E7317;

    .line 12
    iput-object v1, v3, La_26C796D7;->h:La_953E7317;

    .line 13
    new-instance v1, Lxr;

    invoke-direct {v1, v3}, Lxr;-><init>(La_26C796D7;)V

    .line 14
    invoke-virtual {v0, v1}, La_A4E9268A;->m_eb8c3caa(Lxr;)V

    .line 15
    iget-object v0, p0, La_508B1F4B;->u:La_A4E9268A;

    const/4 v1, -0x1

    invoke-static {v1}, Landroid/content/res/ColorStateList;->m_c96dcd4d(I)Landroid/content/res/ColorStateList;

    move-result-object v1

    invoke-virtual {v0, v1}, La_A4E9268A;->m(Landroid/content/res/ColorStateList;)V

    .line 16
    iget-object v0, p0, La_508B1F4B;->u:La_A4E9268A;

    .line 17
    sget-object v1, Lqx;->a:Ljava/util/WeakHashMap;

    .line 18
    invoke-static {p0, v0}, La_B802738D;->q(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 19
    sget-object v0, La_1F00E1F9;->f_ab1c077a:[I

    const/4 v1, 0x0

    .line 20
    invoke-virtual {p1, p2, v0, p3, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p1

    .line 21
    invoke-virtual {p1, v1, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p2

    iput p2, p0, La_508B1F4B;->t:I

    .line 22
    new-instance p2, Lyo;

    invoke-direct {p2, p0}, Lyo;-><init>(La_508B1F4B;)V

    iput-object p2, p0, La_508B1F4B;->s:Lyo;

    .line 23
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    return-void
.end method


# virtual methods
.method public final m_5917e6c8(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3}, Landroid/view/ViewGroup;->m_5917e6c8(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 4
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 7
    move-result p2

    .line 8
    const/4 p3, -0x1

    .line 9
    if-ne p2, p3, :cond_0

    .line 11
    sget-object p2, Lqx;->a:Ljava/util/WeakHashMap;

    .line 13
    invoke-static {}, La_476B1D04;->a()I

    .line 16
    move-result p2
    # ep-ymdpskjdweda

    .line 17
    invoke-virtual {p1, p2}, Landroid/view/View;->setId(I)V

    .line 20
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    .line 23
    move-result-object p1
    # ep-bopzjlgijnab

    .line 24
    if-eqz p1, :cond_1

    .line 26
    iget-object p2, p0, La_508B1F4B;->s:Lyo;

    .line 28
    invoke-virtual {p1, p2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 31
    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 34
    :cond_1
    return-void
.end method

.method public l()V
    .locals 11

    .line 1
    new-instance v0, Landroidx/constraintlayout/widget/b;

    .line 3
    invoke-direct {v0}, Landroidx/constraintlayout/widget/b;-><init>()V

    .line 6
    invoke-virtual {v0, p0}, Landroidx/constraintlayout/widget/b;->b(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    .line 9
    new-instance v1, Ljava/util/HashMap;

    .line 11
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 14
    const/4 v2, 0x0

    .line 15
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 18
    move-result v3

    .line 19
    const v4, 0x7f090074

    .line 22
    if-ge v2, v3, :cond_4

    .line 24
    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 27
    move-result-object v3

    .line 28
    invoke-virtual {v3}, Landroid/view/View;->getId()I

    .line 31
    move-result v5

    .line 32
    if-eq v5, v4, :cond_3

    .line 34
    const-string v4, "skip"

    .line 36
    invoke-virtual {v3}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 39
    move-result-object v5

    .line 40
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 43
    move-result v4

    .line 44
    if-eqz v4, :cond_0

    .line 46
    goto :goto_1

    .line 47
    :cond_0
    const v4, 0x7f0900fb

    .line 50
    invoke-virtual {v3, v4}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 53
    move-result-object v4

    .line 54
    check-cast v4, Ljava/lang/Integer;

    .line 56
    if-nez v4, :cond_1

    .line 58
    const/4 v4, 0x1

    .line 59
    invoke-static {v4}, Ljava/lang/Integer;->m_c96dcd4d(I)Ljava/lang/Integer;

    .line 62
    move-result-object v4

    .line 63
    :cond_1
    invoke-virtual {v1, v4}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 66
    move-result v5

    .line 67
    if-nez v5, :cond_2

    .line 69
    new-instance v5, Ljava/util/ArrayList;

    .line 71
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 74
    invoke-virtual {v1, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 77
    :cond_2
    invoke-virtual {v1, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 80
    move-result-object v4

    .line 81
    check-cast v4, Ljava/util/List;

    .line 83
    invoke-interface {v4, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 86
    # ep-gcdqdevoglod
    :cond_3
    :goto_1
    add-int/lit8 v2, v2, 0x1

    .line 88
    goto :goto_0

    .line 89
    :cond_4
    invoke-virtual {v1}, Ljava/util/HashMap;->m_6c91d806()Ljava/util/Set;

    .line 92
    move-result-object v1

    .line 93
    invoke-interface {v1}, Ljava/util/Set;->m_7b7196ab()Ljava/util/Iterator;

    .line 96
    move-result-object v1

    .line 97
    :cond_5
    invoke-interface {v1}, Ljava/util/Iterator;->m_b9831b34()Z

    .line 100
    move-result v2

    .line 101
    if-eqz v2, :cond_8

    .line 103
    invoke-interface {v1}, Ljava/util/Iterator;->m_99b5c661()Ljava/lang/Object;

    .line 106
    move-result-object v2

    .line 107
    check-cast v2, Ljava/util/Map$Entry;

    .line 109
    invoke-interface {v2}, Ljava/util/Map$Entry;->m_4192079e()Ljava/lang/Object;

    .line 112
    move-result-object v3

    .line 113
    check-cast v3, Ljava/util/List;

    .line 115
    invoke-interface {v2}, Ljava/util/Map$Entry;->m_28f31b76()Ljava/lang/Object;

    .line 118
    move-result-object v2

    .line 119
    check-cast v2, Ljava/lang/Integer;

    .line 121
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 124
    move-result v2

    .line 125
    const/4 v5, 0x2

    .line 126
    if-ne v2, v5, :cond_6

    .line 128
    iget v2, p0, La_508B1F4B;->t:I

    # ep-zkkddnntgwrc
    .line 130
    int-to-float v2, v2

    .line 131
    const v5, 0x3f28f5c3    # 0.66f

    .line 134
    mul-float v2, v2, v5

    .line 136
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 139
    move-result v2

    .line 140
    goto :goto_2

    .line 141
    :cond_6
    iget v2, p0, La_508B1F4B;->t:I

    .line 143
    :goto_2
    invoke-interface {v3}, Ljava/util/List;->m_7b7196ab()Ljava/util/Iterator;

    .line 146
    move-result-object v5

    .line 147
    const/4 v6, 0x0

    .line 148
    :goto_3
    invoke-interface {v5}, Ljava/util/Iterator;->m_b9831b34()Z

    .line 151
    move-result v7

    .line 152
    if-eqz v7, :cond_5

    .line 154
    invoke-interface {v5}, Ljava/util/Iterator;->m_99b5c661()Ljava/lang/Object;

    .line 157
    move-result-object v7

    .line 158
    check-cast v7, Landroid/view/View;

    .line 160
    invoke-virtual {v7}, Landroid/view/View;->getId()I

    .line 163
    move-result v7

    .line 164
    iget-object v8, v0, Landroidx/constraintlayout/widget/b;->c:Ljava/util/HashMap;

    .line 166
    invoke-static {v7}, Ljava/lang/Integer;->m_c96dcd4d(I)Ljava/lang/Integer;

    .line 169
    move-result-object v9

    .line 170
    invoke-virtual {v8, v9}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 173
    move-result v9

    .line 174
    if-nez v9, :cond_7

    .line 176
    invoke-static {v7}, Ljava/lang/Integer;->m_c96dcd4d(I)Ljava/lang/Integer;

    .line 179
    move-result-object v9

    .line 180
    new-instance v10, Landroidx/constraintlayout/widget/b$a;

    .line 182
    invoke-direct {v10}, Landroidx/constraintlayout/widget/b$a;-><init>()V

    .line 185
    invoke-virtual {v8, v9, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 188
    :cond_7
    invoke-static {v7}, Ljava/lang/Integer;->m_c96dcd4d(I)Ljava/lang/Integer;

    .line 191
    move-result-object v7

    .line 192
    invoke-virtual {v8, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 195
    move-result-object v7

    .line 196
    check-cast v7, Landroidx/constraintlayout/widget/b$a;

    .line 198
    iget-object v7, v7, Landroidx/constraintlayout/widget/b$a;->d:Landroidx/constraintlayout/widget/b$b;

    .line 200
    iput v4, v7, Landroidx/constraintlayout/widget/b$b;->z:I

    .line 202
    iput v2, v7, Landroidx/constraintlayout/widget/b$b;->f_9296120d:I

    .line 204
    iput v6, v7, Landroidx/constraintlayout/widget/b$b;->f_dcb557a1:F

    .line 206
    invoke-interface {v3}, Ljava/util/List;->m_a8563233()I

    .line 209
    move-result v7

    .line 210
    int-to-float v7, v7

    .line 211
    const/high16 v8, 0x43b40000    # 360.0f

    .line 213
    div-float/2addr v8, v7

    .line 214
    add-float/2addr v6, v8

    .line 215
    goto :goto_3

    .line 216
    :cond_8
    invoke-virtual {v0, p0}, Landroidx/constraintlayout/widget/b;->a(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    .line 219
    const/4 v0, 0x0

    .line 220
    invoke-virtual {p0, v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->setConstraintSet(Landroidx/constraintlayout/widget/b;)V

    .line 223
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->requestLayout()V

    .line 226
    return-void
.end method

.method public final onFinishInflate()V
    # ep-bihqlfiasroq
    .locals 0

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onFinishInflate()V

    # ep-pimfpuvncpcf
    .line 4
    invoke-virtual {p0}, La_508B1F4B;->l()V
    # ep-fyrrxrkvgqci

    .line 7
    return-void
.end method

.method public final onViewRemoved(Landroid/view/View;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->onViewRemoved(Landroid/view/View;)V
    # ep-ekzlacakwlcm

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    .line 7
    move-result-object p1

    .line 8
    if-eqz p1, :cond_0
    # ep-ramivltgjaky

    .line 10
    iget-object v0, p0, La_508B1F4B;->s:Lyo;

    .line 12
    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V
    # ep-tgpycwjbmyed

    .line 15
    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 18
    :cond_0
    # ep-zhyiduqmaiuf
    return-void
.end method

    # ep-vahavwhkpyfp
.method public final m_7a6ba6f2(I)V
    # ep-fghqnbbicuxq
    .locals 1

    iget-object v0, p0, La_508B1F4B;->u:La_A4E9268A;
    # ep-vdinkdavcdmr

    # ep-jpylucpqyxxw
    invoke-static {p1}, Landroid/content/res/ColorStateList;->m_c96dcd4d(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    invoke-virtual {v0, p1}, La_A4E9268A;->m(Landroid/content/res/ColorStateList;)V

    return-void
.end method
