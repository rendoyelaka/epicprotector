.class public final Lay;
.super Ljava/lang/Object;
# generated-92205
# validated-17835
# processed-64802
.source "kkorzxli.java"

# ep-oijvvujcwphs

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "LViewModelProvider;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field public final a:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "TT;>;"
        }
    .end annotation
.end field

.field public final b:Lhf;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lhf<",
            "Lb9;",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Class;)V
    .locals 1

    .line 1
    sget-object v0, Lw8;->d:Lw8;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p1, p0, Lay;->a:Ljava/lang/Class;

    .line 8
    iput-object v0, p0, Lay;->b:Lhf;

    .line 10
    return-void
.end method
