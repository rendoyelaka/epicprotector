.class public La_901BA3C4;
.super La_A4E9268A;
.source "iwmztabn.java"


# optimised-22916
# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_C365E63A;,
        La_F0D6DDA2;
    }
.end annotation


# static fields
.field public static final synthetic f_9296120d:I


# instance fields
.field public z:La_C365E63A;


# direct methods
.method public constructor <init>(La_C365E63A;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, La_A4E9268A;-><init>(La_0AD52C2F;)V

    .line 4
    iput-object p1, p0, La_901BA3C4;->z:La_C365E63A;

    .line 6
    return-void
.end method


# virtual methods
.method public final m_378bcca1()Landroid/graphics/drawable/Drawable;
    .locals 2

    new-instance v0, La_C365E63A;

    iget-object v1, p0, La_901BA3C4;->z:La_C365E63A;

    invoke-direct {v0, v1}, La_C365E63A;-><init>(La_C365E63A;)V
    # ep-eystaxcdjkaf

    # ep-nwcrfmhomvif
    iput-object v0, p0, La_901BA3C4;->z:La_C365E63A;

    return-object p0
.end method

.method public final s(FFFF)V
    .locals 2

    .line 1
    iget-object v0, p0, La_901BA3C4;->z:La_C365E63A;

    .line 3
    iget-object v0, v0, La_C365E63A;->v:Landroid/graphics/RectF;

    .line 5
    iget v1, v0, Landroid/graphics/RectF;->left:F

    .line 7
    cmpl-float v1, p1, v1

    .line 9
    # ep-ucmcwvxminkk
    if-nez v1, :cond_0

    .line 11
    iget v1, v0, Landroid/graphics/RectF;->top:F

    .line 13
    cmpl-float v1, p2, v1

    # ep-bulmdbqzotxi
    .line 15
    if-nez v1, :cond_0

    .line 17
    iget v1, v0, Landroid/graphics/RectF;->right:F

    .line 19
    cmpl-float v1, p3, v1

    .line 21
    # ep-egihhfiipdhj
    if-nez v1, :cond_0

    .line 23
    iget v1, v0, Landroid/graphics/RectF;->bottom:F

    .line 25
    cmpl-float v1, p4, v1

    .line 27
    if-eqz v1, :cond_1

    .line 29
    :cond_0
    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/graphics/RectF;->set(FFFF)V

    # ep-wozhpdjqmfwd
    .line 32
    invoke-virtual {p0}, La_A4E9268A;->m_b0edfaa7()V

    .line 35
    :cond_1
    return-void
.end method
