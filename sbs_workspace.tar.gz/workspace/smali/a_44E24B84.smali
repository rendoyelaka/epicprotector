.class public final La_44E24B84;
.super Ljava/lang/Object;
.source "rysxtnuf.java"

# generated-21663
# optimised-84376
# ep-afnyenylwdmk

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_DB5DC772;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/widget/CompoundButton;)Landroid/graphics/drawable/Drawable;
    .locals 0

    invoke-static {p0}, La_B302BB44;->g(Landroid/widget/CompoundButton;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method
