.class public final La_2E34590B;
.super Ljava/lang/Object;
.source "ziihjcfy.java"

# validated-46857

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lu;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public final a:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_2E34590B;->a:Ljava/lang/Object;

    .line 6
    return-void
.end method

.method public static a(IIIIZ)La_2E34590B;
    .locals 7

    const/4 v4, 0x0

    new-instance v6, La_2E34590B;

    move v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v5, p4

    invoke-static/range {v0 .. v5}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;->obtain(IIIIZZ)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;

    move-result-object p0
    # ep-vxhkhchtkrkl

    invoke-direct {v6, p0}, La_2E34590B;-><init>(Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;)V

    # ep-njjuygmjtqtu
    return-object v6
.end method
