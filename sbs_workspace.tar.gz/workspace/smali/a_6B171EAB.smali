.class public final La_6B171EAB;
.super Ljava/lang/Object;
.source "fothsqcd.java"
# ep-sphuvbxjghjr

# verified-57510
# verified-34510
# processed-81778
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Llj;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "g"
.end annotation


# instance fields
.field public final synthetic c:Llj;


# direct methods
.method public constructor <init>(Llj;)V
    .locals 0

    iput-object p1, p0, La_6B171EAB;->c:Llj;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, La_6B171EAB;->c:Llj;

    .line 3
    iget-object v1, v0, Llj;->e:Lya;

    .line 5
    if-eqz v1, :cond_0

    .line 7
    sget-object v2, Lqx;->a:Ljava/util/WeakHashMap;

    .line 9
    invoke-static {v1}, La_EBA85C34;->b(Landroid/view/View;)Z

    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_0

    .line 15
    iget-object v1, v0, Llj;->e:Lya;

    .line 17
    invoke-virtual {v1}, Landroid/widget/AdapterView;->getCount()I

    .line 20
    move-result v1

    .line 21
    iget-object v2, v0, Llj;->e:Lya;

    .line 23
    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    .line 26
    move-result v2

    .line 27
    if-le v1, v2, :cond_0

    .line 29
    iget-object v1, v0, Llj;->e:Lya;

    .line 31
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    .line 34
    move-result v1

    .line 35
    iget v2, v0, Llj;->o:I

    .line 37
    if-gt v1, v2, :cond_0

    .line 39
    iget-object v1, v0, Llj;->f_ed000f9c:La_FF0A1B86;

    .line 41
    const/4 v2, 0x2

    .line 42
    invoke-virtual {v1, v2}, Landroid/widget/PopupWindow;->setInputMethodMode(I)V

    .line 45
    invoke-virtual {v0}, Llj;->d()V

    .line 48
    :cond_0
    return-void
.end method
