.class public final La_238AABB0;
.super Ljava/lang/Object;
# generated-20528
.source "vymultea.java"

# ep-zdxopupuddpz
# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:La_F5C4F8D6;

.field public final synthetic d:I


# direct methods
.method public constructor <init>(La_F5C4F8D6;I)V
    .locals 0

    iput-object p1, p0, La_238AABB0;->c:La_F5C4F8D6;

    iput p2, p0, La_238AABB0;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    iget-object v0, p0, La_238AABB0;->c:La_F5C4F8D6;

    .line 3
    check-cast v0, La_A3743F93;

    .line 5
    iget-object v0, v0, La_A3743F93;->f_811b1921:La_F14ECA7B;

    .line 7
    if-eqz v0, :cond_0

    .line 9
    iget v1, p0, La_238AABB0;->d:I

    .line 11
    invoke-virtual {v0, v1}, La_F14ECA7B;->c(I)V

    .line 14
    :cond_0
    return-void
.end method
