.class public final La_5FAD34FF;
# ep-zuxlayekzzod
.super La_63B32426;
.source "pafabjiw.java"

# processed-91011
# validated-67379
# processed-44854

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_63B32426;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_63B32426;-><init>()V

    return-void
.end method


# virtual methods
.method public final b(Ldh;)V
    .locals 1

    const/4 v0, 0x5

    invoke-virtual {p1, v0}, Ldh;->c(I)V

    return-void
.end method
