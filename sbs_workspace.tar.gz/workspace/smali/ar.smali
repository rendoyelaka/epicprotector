.class public final Lar;
.super Ljava/lang/Object;
.source "dflhhbeu.java"
# processed-81063
# compiled-50097
# optimised-81296
# ep-turmcjzdpqsq

# interfaces
.implements LSavedStateRegistry$b;


# instance fields
.field public final a:LSavedStateRegistry;

.field public b:Z

.field public c:Landroid/os/Bundle;

.field public final d:Lxt;


# direct methods
.method public constructor <init>(LSavedStateRegistry;Ley;)V
    .locals 1

    .line 1
    const-string v0, "savedStateRegistry"

    .line 3
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    const-string v0, "viewModelStoreOwner"

    .line 8
    invoke-static {v0, p2}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    iput-object p1, p0, Lar;->a:LSavedStateRegistry;

    .line 16
    new-instance p1, Lar$a;

    .line 18
    invoke-direct {p1, p2}, Lar$a;-><init>(Ley;)V

    .line 21
    new-instance p2, Lxt;

    .line 23
    invoke-direct {p2, p1}, Lxt;-><init>(Lar$a;)V

    .line 26
    iput-object p2, p0, Lar;->d:Lxt;

    .line 28
    return-void
.end method


# virtual methods
.method public final a()Landroid/os/Bundle;
    .locals 5

    .line 1
    new-instance v0, Landroid/os/Bundle;

    .line 3
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 6
    iget-object v1, p0, Lar;->c:Landroid/os/Bundle;

    .line 8
    if-eqz v1, :cond_0

    .line 10
    invoke-virtual {v0, v1}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    .line 13
    :cond_0
    iget-object v1, p0, Lar;->d:Lxt;

    .line 15
    invoke-virtual {v1}, Lxt;->a()Ljava/lang/Object;

    .line 18
    move-result-object v1

    .line 19
    check-cast v1, Lbr;

    .line 21
    iget-object v1, v1, Lbr;->c:Ljava/util/LinkedHashMap;

    .line 23
    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 26
    move-result-object v1

    .line 27
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 30
    move-result-object v1

    .line 31
    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 34
    move-result v2

    .line 35
    if-eqz v2, :cond_2

    .line 37
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 40
    move-result-object v2

    .line 41
    check-cast v2, Ljava/util/Map$Entry;

    .line 43
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 46
    move-result-object v3

    .line 47
    check-cast v3, Ljava/lang/String;

    .line 49
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 52
    move-result-object v2

    .line 53
    check-cast v2, Lyq;

    .line 55
    iget-object v2, v2, Lyq;->e:Lxq;

    .line 57
    invoke-virtual {v2}, Lxq;->a()Landroid/os/Bundle;

    .line 60
    move-result-object v2

    .line 61
    sget-object v4, Landroid/os/Bundle;->EMPTY:Landroid/os/Bundle;

    .line 63
    invoke-static {v2, v4}, Lqi;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 66
    move-result v4

    .line 67
    if-nez v4, :cond_1

    .line 69
    invoke-virtual {v0, v3, v2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 72
    goto :goto_0

    .line 73
    :cond_2
    const/4 v1, 0x0

    .line 74
    iput-boolean v1, p0, Lar;->b:Z

    .line 76
    return-object v0
.end method
