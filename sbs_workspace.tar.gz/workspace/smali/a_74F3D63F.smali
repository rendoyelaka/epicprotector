.class public final La_74F3D63F;
# ep-kchrinqprrgb
.super Ljava/lang/Object;
# verified-44568
# processed-57466
.source "ingsoysi.java"

# interfaces
.implements Lls;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpg;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "d"
.end annotation


# instance fields
.field public final c:Lud;

.field public d:Z

.field public e:J

.field public final synthetic f:Lpg;


# direct methods
.method public constructor <init>(Lpg;J)V
    .locals 1

    .line 1
    iput-object p1, p0, La_74F3D63F;->f:Lpg;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    new-instance v0, Lud;

    .line 8
    iget-object p1, p1, Lpg;->d:La_ED811785;

    .line 10
    invoke-interface {p1}, Lls;->a()Lhv;

    .line 13
    move-result-object p1

    .line 14
    invoke-direct {v0, p1}, Lud;-><init>(Lhv;)V

    .line 17
    iput-object v0, p0, La_74F3D63F;->c:Lud;

    .line 19
    iput-wide p2, p0, La_74F3D63F;->e:J

    .line 21
    return-void
.end method


# virtual methods
.method public final a()Lhv;
    .locals 1

    iget-object v0, p0, La_74F3D63F;->c:Lud;

    return-object v0
.end method

.method public final b(La_726A8EEF;J)V
    .locals 7

    .line 1
    iget-boolean v0, p0, La_74F3D63F;->d:Z

    .line 3
    if-nez v0, :cond_2

    .line 5
    iget-wide v0, p1, La_726A8EEF;->d:J

    .line 7
    sget-object v2, Lex;->a:[B

    .line 9
    const-wide/16 v2, 0x0

    .line 11
    or-long v4, v2, p2

    .line 13
    cmp-long v6, v4, v2

    .line 15
    if-ltz v6, :cond_1

    .line 17
    cmp-long v4, v2, v0

    .line 19
    if-gtz v4, :cond_1

    .line 21
    sub-long/2addr v0, v2

    .line 22
    cmp-long v2, v0, p2

    .line 24
    if-ltz v2, :cond_1

    .line 26
    iget-wide v0, p0, La_74F3D63F;->e:J

    .line 28
    cmp-long v2, p2, v0

    .line 30
    if-gtz v2, :cond_0

    .line 32
    iget-object v0, p0, La_74F3D63F;->f:Lpg;

    .line 34
    iget-object v0, v0, Lpg;->d:La_ED811785;

    .line 36
    invoke-interface {v0, p1, p2, p3}, Lls;->b(La_726A8EEF;J)V

    .line 39
    iget-wide v0, p0, La_74F3D63F;->e:J

    .line 41
    sub-long/2addr v0, p2

    .line 42
    iput-wide v0, p0, La_74F3D63F;->e:J

    .line 44
    return-void

    .line 45
    :cond_0
    new-instance p1, Ljava/net/ProtocolException;

    .line 47
    new-instance v0, Ljava/lang/StringBuilder;

    .line 49
    const-string v1, "expected "

    .line 51
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 54
    iget-wide v1, p0, La_74F3D63F;->e:J

    .line 56
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 59
    const-string v1, " bytes but received "

    .line 61
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    invoke-virtual {v0, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 67
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 70
    move-result-object p2

    .line 71
    invoke-direct {p1, p2}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 74
    throw p1

    .line 75
    :cond_1
    new-instance p1, Ljava/lang/ArrayIndexOutOfBoundsException;

    .line 77
    invoke-direct {p1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>()V

    .line 80
    throw p1

    .line 81
    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 83
    const-string p2, "closed"

    .line 85
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 88
    throw p1
.end method

.method public final m_ce32a5d6()V
    .locals 5

    .line 1
    iget-boolean v0, p0, La_74F3D63F;->d:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, La_74F3D63F;->d:Z

    .line 9
    iget-wide v0, p0, La_74F3D63F;->e:J

    .line 11
    const-wide/16 v2, 0x0

    .line 13
    cmp-long v4, v0, v2

    .line 15
    if-gtz v4, :cond_1

    .line 17
    iget-object v0, p0, La_74F3D63F;->f:Lpg;

    .line 19
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    iget-object v1, p0, La_74F3D63F;->c:Lud;

    .line 24
    iget-object v2, v1, Lud;->e:Lhv;

    .line 26
    sget-object v3, Lhv;->d:La_65F81E5E;

    .line 28
    iput-object v3, v1, Lud;->e:Lhv;

    .line 30
    invoke-virtual {v2}, Lhv;->a()Lhv;

    .line 33
    invoke-virtual {v2}, Lhv;->b()Lhv;

    .line 36
    const/4 v1, 0x3

    .line 37
    iput v1, v0, Lpg;->e:I

    .line 39
    return-void

    .line 40
    :cond_1
    new-instance v0, Ljava/net/ProtocolException;

    .line 42
    const-string v1, "unexpected end of stream"

    .line 44
    invoke-direct {v0, v1}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 47
    throw v0
.end method

.method public final m_471bb8d1()V
    .locals 1

    .line 1
    iget-boolean v0, p0, La_74F3D63F;->d:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    iget-object v0, p0, La_74F3D63F;->f:Lpg;

    .line 8
    iget-object v0, v0, Lpg;->d:La_ED811785;

    .line 10
    invoke-interface {v0}, La_ED811785;->m_471bb8d1()V

    .line 13
    return-void
.end method
