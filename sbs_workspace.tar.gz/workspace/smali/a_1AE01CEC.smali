.class public interface abstract La_1AE01CEC;
.super Ljava/lang/Object;
.source "obrdjiwf.java"
