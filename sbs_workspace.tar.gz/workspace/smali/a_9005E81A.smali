.class public interface abstract La_9005E81A;
.super Ljava/lang/Object;
.source "lupfxlva.java"
