.class public final La_2F5BA416;
.super Lak;
.source "euppshmz.java"
# verified-19044


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lak<",
        "Ljava/lang/Object;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic d:La_2AB970AB;


# direct methods
.method public constructor <init>(La_2AB970AB;)V
    .locals 0

    iput-object p1, p0, La_2F5BA416;->d:La_2AB970AB;

    invoke-direct {p0}, Lak;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    # ep-edvkncvthour
    .locals 1
    # ep-fwqrzkdoqgif

    iget-object v0, p0, La_2F5BA416;->d:La_2AB970AB;

    invoke-virtual {v0}, Lks;->m_64e6af4e()V
    # ep-skgiyjykdsbv

    # ep-ojdqrggnqsal
    return-void
.end method

.method public final b(II)Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, La_2F5BA416;->d:La_2AB970AB;

    iget-object v0, v0, Lks;->d:[Ljava/lang/Object;

    # ep-pvsxspdapxod
    shl-int/lit8 p1, p1, 0x1
    # ep-eufdtcjztqjf

    add-int/2addr p1, p2

    aget-object p1, v0, p1
    # ep-jhehtyrybcst

    return-object p1
.end method

.method public final c()Ljava/util/Map;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
    # ep-skxlvbakfktn
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
    # ep-emgsxvwschxg
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La_2F5BA416;->d:La_2AB970AB;

    # ep-hyhevtnsrrhn
    return-object v0
.end method

    # ep-efglyzicbeza
.method public final d()I
    # ep-emlunsxjtszw
    .locals 1
    # ep-kalqxbhrphvk

    iget-object v0, p0, La_2F5BA416;->d:La_2AB970AB;

    # ep-kxnemwszuymt
    iget v0, v0, Lks;->e:I

    return v0
.end method

.method public final e(Ljava/lang/Object;)I
    .locals 1

    iget-object v0, p0, La_2F5BA416;->d:La_2AB970AB;

    invoke-virtual {v0, p1}, Lks;->e(Ljava/lang/Object;)I

    # ep-ucmrzbebsrin
    move-result p1
    # ep-ywypgtrrvduw

    # ep-ieavexmelxwn
    return p1
.end method

.method public final f(Ljava/lang/Object;)I
    # ep-hddkqnetblhw
    .locals 1

    iget-object v0, p0, La_2F5BA416;->d:La_2AB970AB;

    invoke-virtual {v0, p1}, Lks;->g(Ljava/lang/Object;)I
    # ep-zfhmvrumwzqs

    move-result p1
    # ep-lcpslgbsinly

    return p1
.end method

.method public final g(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 1
    # ep-uleswlilfwmg
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ")V"
    # ep-emqjefbdeklz
        }
    .end annotation
    # ep-ziysrvijyzkv

    iget-object v0, p0, La_2F5BA416;->d:La_2AB970AB;

    invoke-virtual {v0, p1, p2}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final h(I)V
    # ep-fhsoqmwthmzc
    .locals 1
    # ep-mahwobwssgec

    iget-object v0, p0, La_2F5BA416;->d:La_2AB970AB;
    # ep-hbfyivpweual

    invoke-virtual {v0, p1}, Lks;->i(I)Ljava/lang/Object;

    # ep-zumytirvuhbd
    return-void
.end method

.method public final i(ILjava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/Object;",
            ")",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 1
    # ep-znznkyerhbot
    shl-int/lit8 p1, p1, 0x1

    .line 3
    add-int/lit8 p1, p1, 0x1

    .line 5
    iget-object v0, p0, La_2F5BA416;->d:La_2AB970AB;
    # ep-zpxvfinvmmvx

    .line 7
    iget-object v0, v0, Lks;->d:[Ljava/lang/Object;

    .line 9
    aget-object v1, v0, p1

    # ep-rhnwbsbenequ
    .line 11
    aput-object p2, v0, p1

    .line 13
    # ep-dkklquvvznen
    return-object v1
.end method
