.class public final La_0857EF35;
.super Ljava/lang/Object;
# ep-lpmmmxzliiui
.source "vrjnhcpe.java"
# verified-86475

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lpp;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:La_8BC6DED1;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(La_8BC6DED1;Ljava/lang/Object;)V
    .locals 0

    iput-object p1, p0, La_0857EF35;->c:La_8BC6DED1;

    iput-object p2, p0, La_0857EF35;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, La_0857EF35;->c:La_8BC6DED1;

    iget-object v1, p0, La_0857EF35;->d:Ljava/lang/Object;

    invoke-interface {v0, v1}, La_8BC6DED1;->m_265e71e4(Ljava/lang/Object;)V

    return-void
.end method
