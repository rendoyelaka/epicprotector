.class public La_02165597;
# ep-dghggrgufzau
.super Landroid/widget/EditText;
.source "hfjagslq.java"

# generated-30495
# processed-63052
# interfaces
.implements Lkn;
.implements Lov;


# instance fields
.field public final c:La_0D850CD8;

.field public final d:La_1CAFA37F;

.field public final e:La_BC92C3B9;

.field public final f:Lxu;

.field public final g:La_9AC5F7FC;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, p2, v0}, La_02165597;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 3

    .line 2
    invoke-static {p1}, Ljv;->a(Landroid/content/Context;)V

    const p3, 0x7f030192

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/EditText;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 3
    invoke-virtual {p0}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    move-result-object p1

    invoke-static {p0, p1}, Lav;->a(Landroid/view/View;Landroid/content/Context;)V

    .line 4
    new-instance p1, La_0D850CD8;

    invoke-direct {p1, p0}, La_0D850CD8;-><init>(Landroid/view/View;)V

    iput-object p1, p0, La_02165597;->c:La_0D850CD8;

    .line 5
    invoke-virtual {p1, p2, p3}, La_0D850CD8;->d(Landroid/util/AttributeSet;I)V

    .line 6
    new-instance p1, La_1CAFA37F;

    invoke-direct {p1, p0}, La_1CAFA37F;-><init>(Landroid/widget/TextView;)V

    iput-object p1, p0, La_02165597;->d:La_1CAFA37F;

    .line 7
    invoke-virtual {p1, p2, p3}, La_1CAFA37F;->f(Landroid/util/AttributeSet;I)V

    .line 8
    invoke-virtual {p1}, La_1CAFA37F;->b()V

    .line 9
    new-instance p1, La_BC92C3B9;

    invoke-direct {p1, p0}, La_BC92C3B9;-><init>(Landroid/widget/TextView;)V

    iput-object p1, p0, La_02165597;->e:La_BC92C3B9;

    .line 10
    new-instance p1, Lxu;

    invoke-direct {p1}, Lxu;-><init>()V

    iput-object p1, p0, La_02165597;->f:Lxu;

    .line 11
    new-instance p1, La_9AC5F7FC;

    invoke-direct {p1, p0}, La_9AC5F7FC;-><init>(Landroid/widget/EditText;)V

    iput-object p1, p0, La_02165597;->g:La_9AC5F7FC;

    .line 12
    invoke-virtual {p1, p2, p3}, La_9AC5F7FC;->b(Landroid/util/AttributeSet;I)V

    .line 13
    invoke-virtual {p0}, Landroid/widget/TextView;->getKeyListener()Landroid/text/method/KeyListener;

    move-result-object p2

    .line 14
    instance-of p3, p2, Landroid/text/method/NumberKeyListener;

    xor-int/lit8 p3, p3, 0x1

    if-eqz p3, :cond_1

    .line 15
    invoke-super {p0}, Landroid/widget/EditText;->isFocusable()Z

    move-result p3

    .line 16
    invoke-super {p0}, Landroid/widget/EditText;->isClickable()Z

    move-result v0

    .line 17
    invoke-super {p0}, Landroid/widget/EditText;->isLongClickable()Z

    move-result v1

    .line 18
    invoke-super {p0}, Landroid/widget/EditText;->getInputType()I

    move-result v2

    .line 19
    invoke-virtual {p1, p2}, La_9AC5F7FC;->a(Landroid/text/method/KeyListener;)Landroid/text/method/KeyListener;

    move-result-object p1

    if-ne p1, p2, :cond_0

    goto :goto_0

    .line 20
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/EditText;->m_d92bd184(Landroid/text/method/KeyListener;)V

    .line 21
    invoke-super {p0, v2}, Landroid/widget/EditText;->setRawInputType(I)V

    .line 22
    invoke-super {p0, p3}, Landroid/widget/EditText;->setFocusable(Z)V

    .line 23
    invoke-super {p0, v0}, Landroid/widget/EditText;->setClickable(Z)V

    .line 24
    invoke-super {p0, v1}, Landroid/widget/EditText;->setLongClickable(Z)V

    :cond_1
    :goto_0
    return-void
.end method


# virtual methods
.method public final a(La_F34E86BF;)La_F34E86BF;
    .locals 1

    iget-object v0, p0, La_02165597;->f:Lxu;

    invoke-virtual {v0, p0, p1}, Lxu;->a(Landroid/view/View;La_F34E86BF;)La_F34E86BF;

    move-result-object p1

    return-object p1
.end method

.method public final m_cb26974e()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/EditText;->m_cb26974e()V

    .line 4
    iget-object v0, p0, La_02165597;->c:La_0D850CD8;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, La_0D850CD8;->a()V

    .line 11
    :cond_0
    iget-object v0, p0, La_02165597;->d:La_1CAFA37F;

    .line 13
    if-eqz v0, :cond_1

    .line 15
    invoke-virtual {v0}, La_1CAFA37F;->b()V

    .line 18
    :cond_1
    return-void
.end method

.method public m_d2f56bdd()Landroid/view/ActionMode$Callback;
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/EditText;->m_d2f56bdd()Landroid/view/ActionMode$Callback;

    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Lwu;->f(Landroid/view/ActionMode$Callback;)Landroid/view/ActionMode$Callback;

    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public m_4eb19bca()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, La_02165597;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_0D850CD8;->b()Landroid/content/res/ColorStateList;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_c605babf()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, La_02165597;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_0D850CD8;->c()Landroid/graphics/PorterDuff$Mode;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_d7d2cbaa()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, La_02165597;->d:La_1CAFA37F;

    invoke-virtual {v0}, La_1CAFA37F;->d()Landroid/content/res/ColorStateList;

    move-result-object v0

    return-object v0
.end method

.method public m_93878187()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    iget-object v0, p0, La_02165597;->d:La_1CAFA37F;

    invoke-virtual {v0}, La_1CAFA37F;->e()Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    return-object v0
.end method

.method public m_8956cb8d()Landroid/text/Editable;
    .locals 2

    .line 2
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1c

    if-lt v0, v1, :cond_0

    .line 3
    invoke-super {p0}, Landroid/widget/EditText;->m_8956cb8d()Landroid/text/Editable;

    move-result-object v0

    return-object v0

    .line 4
    :cond_0
    invoke-super {p0}, Landroid/widget/EditText;->getEditableText()Landroid/text/Editable;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic m_8956cb8d()Ljava/lang/CharSequence;
    .locals 1

    .line 1
    invoke-virtual {p0}, La_02165597;->m_8956cb8d()Landroid/text/Editable;

    move-result-object v0

    return-object v0
.end method

.method public m_1ebf30c0()Landroid/view/textclassifier/TextClassifier;
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1c

    .line 5
    if-ge v0, v1, :cond_2

    .line 7
    iget-object v0, p0, La_02165597;->e:La_BC92C3B9;

    .line 9
    if-nez v0, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iget-object v1, v0, La_BC92C3B9;->b:Landroid/view/textclassifier/TextClassifier;

    .line 14
    if-nez v1, :cond_1

    .line 16
    iget-object v0, v0, La_BC92C3B9;->a:Landroid/widget/TextView;

    .line 18
    invoke-static {v0}, La_00ABB2DA;->a(Landroid/widget/TextView;)Landroid/view/textclassifier/TextClassifier;

    .line 21
    move-result-object v1

    .line 22
    :cond_1
    return-object v1

    .line 23
    :cond_2
    :goto_0
    invoke-super {p0}, Landroid/widget/EditText;->m_1ebf30c0()Landroid/view/textclassifier/TextClassifier;

    .line 26
    move-result-object v0

    .line 27
    return-object v0
.end method

.method public onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .locals 7

    .line 1
    invoke-super {p0, p1}, Landroid/widget/EditText;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, La_02165597;->d:La_1CAFA37F;

    .line 7
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    invoke-static {p0, v0, p1}, La_1CAFA37F;->h(Landroid/widget/TextView;Landroid/view/inputmethod/InputConnection;Landroid/view/inputmethod/EditorInfo;)V

    .line 13
    invoke-static {p0, p1, v0}, La_F5C4F8D6;->m_fabc7ccf(Landroid/view/View;Landroid/view/inputmethod/EditorInfo;Landroid/view/inputmethod/InputConnection;)V

    .line 16
    if-eqz v0, :cond_8

    .line 18
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 20
    const/16 v2, 0x1e

    .line 22
    if-gt v1, v2, :cond_8

    .line 24
    invoke-static {p0}, Lqx;->g(Landroid/view/View;)[Ljava/lang/String;

    .line 27
    move-result-object v2

    .line 28
    if-eqz v2, :cond_8

    .line 30
    const-string v3, "android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"

    .line 32
    const-string v4, "androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"

    .line 34
    const/16 v5, 0x19

    .line 36
    if-lt v1, v5, :cond_0

    .line 38
    invoke-static {p1, v2}, Lib;->c(Landroid/view/inputmethod/EditorInfo;[Ljava/lang/String;)V

    .line 41
    goto :goto_0

    .line 42
    :cond_0
    iget-object v6, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 44
    if-nez v6, :cond_1

    .line 46
    new-instance v6, Landroid/os/Bundle;

    .line 48
    invoke-direct {v6}, Landroid/os/Bundle;-><init>()V

    .line 51
    iput-object v6, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 53
    :cond_1
    iget-object v6, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 55
    invoke-virtual {v6, v4, v2}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    .line 58
    iget-object v6, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 60
    invoke-virtual {v6, v3, v2}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    .line 63
    :goto_0
    new-instance v2, Lai;

    .line 65
    invoke-direct {v2, p0}, Lai;-><init>(Ljava/lang/Object;)V

    .line 68
    if-lt v1, v5, :cond_2

    .line 70
    new-instance v1, Lbi;

    .line 72
    invoke-direct {v1, v0, v2}, Lbi;-><init>(Landroid/view/inputmethod/InputConnection;Lai;)V

    .line 75
    :goto_1
    move-object v0, v1

    .line 76
    goto :goto_4

    .line 77
    :cond_2
    sget-object v6, Ljb;->a:[Ljava/lang/String;

    .line 79
    if-lt v1, v5, :cond_3

    .line 81
    invoke-static {p1}, Lib;->e(Landroid/view/inputmethod/EditorInfo;)[Ljava/lang/String;

    .line 84
    move-result-object v1

    .line 85
    if-eqz v1, :cond_6

    .line 87
    :goto_2
    move-object v6, v1

    .line 88
    goto :goto_3

    .line 89
    :cond_3
    iget-object v1, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 91
    if-nez v1, :cond_4

    .line 93
    goto :goto_3

    .line 94
    :cond_4
    invoke-virtual {v1, v4}, Landroid/os/BaseBundle;->getStringArray(Ljava/lang/String;)[Ljava/lang/String;

    .line 97
    move-result-object v1

    .line 98
    if-nez v1, :cond_5

    .line 100
    iget-object v1, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 102
    invoke-virtual {v1, v3}, Landroid/os/BaseBundle;->getStringArray(Ljava/lang/String;)[Ljava/lang/String;

    .line 105
    move-result-object v1

    .line 106
    :cond_5
    if-eqz v1, :cond_6

    .line 108
    goto :goto_2

    .line 109
    :cond_6
    :goto_3
    array-length v1, v6

    .line 110
    if-nez v1, :cond_7

    .line 112
    goto :goto_4

    .line 113
    :cond_7
    new-instance v1, Lci;

    .line 115
    invoke-direct {v1, v0, v2}, Lci;-><init>(Landroid/view/inputmethod/InputConnection;Lai;)V

    .line 118
    goto :goto_1

    .line 119
    :cond_8
    :goto_4
    iget-object v1, p0, La_02165597;->g:La_9AC5F7FC;

    .line 121
    invoke-virtual {v1, v0, p1}, La_9AC5F7FC;->c(Landroid/view/inputmethod/InputConnection;Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    .line 124
    move-result-object p1

    .line 125
    return-object p1
.end method

.method public final onDragEvent(Landroid/view/DragEvent;)Z
    .locals 5

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1f

    .line 5
    const/4 v2, 0x1

    .line 6
    const/4 v3, 0x0

    .line 7
    if-ge v0, v1, :cond_5

    .line 9
    const/16 v1, 0x18

    .line 11
    if-lt v0, v1, :cond_5

    .line 13
    invoke-virtual {p1}, Landroid/view/DragEvent;->getLocalState()Ljava/lang/Object;

    .line 16
    move-result-object v0

    .line 17
    if-nez v0, :cond_5

    .line 19
    invoke-static {p0}, Lqx;->g(Landroid/view/View;)[Ljava/lang/String;

    .line 22
    move-result-object v0

    .line 23
    if-nez v0, :cond_0

    .line 25
    goto :goto_2

    .line 26
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    .line 29
    move-result-object v0

    .line 30
    :goto_0
    instance-of v1, v0, Landroid/content/ContextWrapper;

    .line 32
    if-eqz v1, :cond_2

    .line 34
    instance-of v1, v0, Landroid/app/Activity;

    .line 36
    if-eqz v1, :cond_1

    .line 38
    check-cast v0, Landroid/app/Activity;

    .line 40
    goto :goto_1

    .line 41
    :cond_1
    check-cast v0, Landroid/content/ContextWrapper;

    .line 43
    invoke-virtual {v0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 46
    move-result-object v0

    .line 47
    goto :goto_0

    .line 48
    :cond_2
    const/4 v0, 0x0

    .line 49
    :goto_1
    if-nez v0, :cond_3

    .line 51
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 54
    goto :goto_2

    .line 55
    :cond_3
    invoke-virtual {p1}, Landroid/view/DragEvent;->getAction()I

    .line 58
    move-result v1

    .line 59
    if-ne v1, v2, :cond_4

    .line 61
    goto :goto_2

    .line 62
    :cond_4
    invoke-virtual {p1}, Landroid/view/DragEvent;->getAction()I

    .line 65
    move-result v1

    .line 66
    const/4 v4, 0x3

    .line 67
    if-ne v1, v4, :cond_5

    .line 69
    invoke-static {p1, p0, v0}, La_9A83FD2D;->a(Landroid/view/DragEvent;Landroid/widget/TextView;Landroid/app/Activity;)Z

    .line 72
    move-result v3

    .line 73
    :cond_5
    :goto_2
    if-eqz v3, :cond_6

    .line 75
    return v2

    .line 76
    :cond_6
    invoke-super {p0, p1}, Landroid/widget/EditText;->onDragEvent(Landroid/view/DragEvent;)Z

    .line 79
    move-result p1

    .line 80
    return p1
.end method

.method public final onTextContextMenuItem(I)Z
    .locals 7

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    const/16 v3, 0x1f

    .line 7
    if-ge v0, v3, :cond_4

    .line 9
    invoke-static {p0}, Lqx;->g(Landroid/view/View;)[Ljava/lang/String;

    .line 12
    move-result-object v4

    .line 13
    if-eqz v4, :cond_4

    .line 15
    const v4, 0x1020022

    .line 18
    if-eq p1, v4, :cond_0

    .line 20
    const v5, 0x1020031

    .line 23
    if-eq p1, v5, :cond_0

    .line 25
    goto :goto_2

    .line 26
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    .line 29
    move-result-object v5

    .line 46
    if-eqz v5, :cond_3

    .line 48
    invoke-virtual {v5}, Landroid/content/ClipData;->getItemCount()I

    .line 51
    move-result v6

    .line 52
    if-lez v6, :cond_3

    .line 54
    if-lt v0, v3, :cond_1

    .line 56
    new-instance v0, La_9663B370;

    .line 58
    invoke-direct {v0, v5, v1}, La_9663B370;-><init>(Landroid/content/ClipData;I)V

    .line 61
    goto :goto_0

    .line 62
    :cond_1
    new-instance v0, La_0320A008;

    .line 64
    invoke-direct {v0, v5, v1}, La_0320A008;-><init>(Landroid/content/ClipData;I)V

    .line 67
    :goto_0
    if-ne p1, v4, :cond_2

    .line 69
    goto :goto_1

    .line 70
    :cond_2
    const/4 v2, 0x1

    .line 71
    :goto_1
    invoke-interface {v0, v2}, La_CE6FA55F;->b(I)V

    .line 74
    invoke-interface {v0}, La_CE6FA55F;->m_426b25df()La_F34E86BF;

    .line 77
    move-result-object v0

    .line 78
    invoke-static {p0, v0}, Lqx;->l(Landroid/view/View;La_F34E86BF;)La_F34E86BF;

    .line 81
    :cond_3
    const/4 v2, 0x1

    .line 82
    :cond_4
    :goto_2
    if-eqz v2, :cond_5

    .line 84
    return v1

    .line 85
    :cond_5
    invoke-super {p0, p1}, Landroid/widget/EditText;->onTextContextMenuItem(I)Z

    .line 88
    move-result p1

    .line 89
    return p1
.end method

.method public m_08385e47(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/EditText;->m_08385e47(Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_02165597;->c:La_0D850CD8;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_0D850CD8;->e()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_ee40bba3(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/EditText;->m_ee40bba3(I)V

    .line 4
    iget-object v0, p0, La_02165597;->c:La_0D850CD8;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1}, La_0D850CD8;->f(I)V

    .line 11
    :cond_0
    return-void
.end method

.method public final m_4e411e88(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/EditText;->m_4e411e88(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_02165597;->d:La_1CAFA37F;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_1CAFA37F;->b()V

    .line 11
    :cond_0
    return-void
.end method

.method public final m_26748812(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/EditText;->m_26748812(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_02165597;->d:La_1CAFA37F;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_1CAFA37F;->b()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_43b91c56(Landroid/view/ActionMode$Callback;)V
    .locals 0

    .line 1
    invoke-static {p1, p0}, Lwu;->g(Landroid/view/ActionMode$Callback;Landroid/widget/TextView;)Landroid/view/ActionMode$Callback;

    .line 4
    move-result-object p1

    .line 5
    invoke-super {p0, p1}, Landroid/widget/EditText;->m_43b91c56(Landroid/view/ActionMode$Callback;)V

    .line 8
    return-void
.end method

.method public m_63db9ddc(Z)V
    .locals 1

    iget-object v0, p0, La_02165597;->g:La_9AC5F7FC;

    invoke-virtual {v0, p1}, La_9AC5F7FC;->d(Z)V

    return-void
.end method

.method public m_d92bd184(Landroid/text/method/KeyListener;)V
    .locals 1

    iget-object v0, p0, La_02165597;->g:La_9AC5F7FC;

    invoke-virtual {v0, p1}, La_9AC5F7FC;->a(Landroid/text/method/KeyListener;)Landroid/text/method/KeyListener;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/widget/EditText;->m_d92bd184(Landroid/text/method/KeyListener;)V

    return-void
.end method

.method public m_44b49f65(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_02165597;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_0D850CD8;->h(Landroid/content/res/ColorStateList;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_10b86d4b(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_02165597;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_0D850CD8;->i(Landroid/graphics/PorterDuff$Mode;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_30fdcbb6(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_02165597;->d:La_1CAFA37F;

    .line 3
    invoke-virtual {v0, p1}, La_1CAFA37F;->l(Landroid/content/res/ColorStateList;)V

    .line 6
    invoke-virtual {v0}, La_1CAFA37F;->b()V

    .line 9
    return-void
.end method

.method public m_ad713641(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_02165597;->d:La_1CAFA37F;

    .line 3
    invoke-virtual {v0, p1}, La_1CAFA37F;->m(Landroid/graphics/PorterDuff$Mode;)V

    .line 6
    invoke-virtual {v0}, La_1CAFA37F;->b()V

    .line 9
    return-void
.end method

.method public final m_f1267819(Landroid/content/Context;I)V
    .locals 1

    .line 1
    invoke-super {p0, p1, p2}, Landroid/widget/EditText;->m_f1267819(Landroid/content/Context;I)V

    .line 4
    iget-object v0, p0, La_02165597;->d:La_1CAFA37F;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1, p2}, La_1CAFA37F;->g(Landroid/content/Context;I)V

    .line 11
    :cond_0
    return-void
.end method

.method public m_62fd6b61(Landroid/view/textclassifier/TextClassifier;)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1c

    .line 5
    if-ge v0, v1, :cond_1

    .line 7
    iget-object v0, p0, La_02165597;->e:La_BC92C3B9;

    .line 9
    if-nez v0, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iput-object p1, v0, La_BC92C3B9;->b:Landroid/view/textclassifier/TextClassifier;

    .line 14
    return-void

    .line 15
    :cond_1
    :goto_0
    invoke-super {p0, p1}, Landroid/widget/EditText;->m_62fd6b61(Landroid/view/textclassifier/TextClassifier;)V

    .line 18
    return-void
.end method
