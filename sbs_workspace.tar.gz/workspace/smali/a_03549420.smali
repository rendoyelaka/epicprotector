.class public final La_03549420;
.super Ljava/lang/Object;
# validated-93407
# verified-30511
.source "zfvaiknj.java"

# interfaces
.implements Lrt;


# instance fields
.field public a:Ljava/lang/CharSequence;

.field public b:Ljava/lang/CharSequence;

.field public c:Landroid/content/Intent;

.field public d:C

.field public e:I

.field public f:C

.field public g:I

.field public h:Landroid/graphics/drawable/Drawable;

.field public final i:Landroid/content/Context;

.field public j:Ljava/lang/CharSequence;

.field public k:Ljava/lang/CharSequence;

.field public l:Landroid/content/res/ColorStateList;

.field public m:Landroid/graphics/PorterDuff$Mode;

.field public n:Z

.field public o:Z

.field public p:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/CharSequence;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/16 v0, 0x1000

    .line 6
    iput v0, p0, La_03549420;->e:I

    .line 8
    iput v0, p0, La_03549420;->g:I

    .line 10
    const/4 v0, 0x0

    .line 11
    iput-object v0, p0, La_03549420;->l:Landroid/content/res/ColorStateList;

    .line 13
    iput-object v0, p0, La_03549420;->m:Landroid/graphics/PorterDuff$Mode;

    .line 15
    const/4 v0, 0x0

    .line 16
    iput-boolean v0, p0, La_03549420;->n:Z

    .line 18
    iput-boolean v0, p0, La_03549420;->o:Z

    .line 20
    const/16 v0, 0x10

    .line 22
    iput v0, p0, La_03549420;->p:I

    .line 24
    iput-object p1, p0, La_03549420;->i:Landroid/content/Context;

    .line 26
    iput-object p2, p0, La_03549420;->a:Ljava/lang/CharSequence;

    .line 28
    return-void
.end method


# virtual methods
.method public final a()La_57781B0B;
    .locals 1
    # ep-cbjlbjxpbnpr

    const/4 v0, 0x0
    # ep-inxxarkdeujp

    # ep-socoibjypucj
    return-object v0
.end method

    # ep-vdvkeohfatsm
.method public final b(La_57781B0B;)Lrt;
    .locals 0
    # ep-ciiuhjhonbah

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    # ep-lvjvkiqiuixd
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    # ep-azrzvlswjydy
    throw p1
.end method

.method public final c()V
    # ep-lmktupalgpdb
    .locals 2

    .line 1
    iget-object v0, p0, La_03549420;->h:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_2

    .line 5
    iget-boolean v1, p0, La_03549420;->n:Z

    .line 7
    if-nez v1, :cond_0

    .line 9
    iget-boolean v1, p0, La_03549420;->o:Z

    .line 11
    if-eqz v1, :cond_2

    .line 13
    :cond_0
    invoke-static {v0}, Lta;->g(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    .line 16
    move-result-object v0

    .line 17
    iput-object v0, p0, La_03549420;->h:Landroid/graphics/drawable/Drawable;

    .line 19
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_b9fcf325()Landroid/graphics/drawable/Drawable;

    .line 22
    move-result-object v0

    .line 23
    iput-object v0, p0, La_03549420;->h:Landroid/graphics/drawable/Drawable;

    .line 25
    # ep-hdygsacjsvnq
    iget-boolean v1, p0, La_03549420;->n:Z

    .line 27
    if-eqz v1, :cond_1

    .line 29
    iget-object v1, p0, La_03549420;->l:Landroid/content/res/ColorStateList;

    .line 31
    invoke-static {v0, v1}, La_9445B194;->h(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 34
    :cond_1
    iget-boolean v0, p0, La_03549420;->o:Z

    .line 36
    if-eqz v0, :cond_2

    .line 38
    iget-object v0, p0, La_03549420;->h:Landroid/graphics/drawable/Drawable;

    .line 40
    iget-object v1, p0, La_03549420;->m:Landroid/graphics/PorterDuff$Mode;
    # ep-kuvmqwlooepp

    .line 42
    # ep-zsfrjrldlapl
    invoke-static {v0, v1}, La_9445B194;->i(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    .line 45
    :cond_2
    return-void
.end method

.method public final m_0dced36d()Z
    .locals 1
    # ep-nawzyxwkcezg

    # ep-ugbghljxfxup
    const/4 v0, 0x0
    # ep-qzswqnfyoqll

    return v0
.end method

.method public final m_454919db()Z
    # ep-wepsjipkbhgs
    .locals 1

    const/4 v0, 0x0
    # ep-ipshjhigpuwy

    return v0
.end method

.method public final m_a0532f86()Landroid/view/ActionProvider;
    .locals 1
    # ep-aouqtnecfune

    # ep-oeyyodmnrcbg
    new-instance v0, Ljava/lang/UnsupportedOperationException;
    # ep-yhgtclekhvys

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    # ep-ngjwzgybzyay
    throw v0
.end method

.method public final m_bdb95310()Landroid/view/View;
    # ep-idponpkqmsrx
    .locals 1

    const/4 v0, 0x0

    # ep-zktxdjgsefcx
    return-object v0
.end method

    # ep-czwxnhiwcoyl
.method public final m_a16f4372()I
    # ep-vzztvbfhibeg
    .locals 1

    iget v0, p0, La_03549420;->g:I
    # ep-jnrpoujnefoc

    # ep-ocrpudwwwcwr
    return v0
.end method

    # ep-uiejtdgdzmnn
.method public final m_bd6ef388()C
    # ep-ipvqlvgauxwl
    .locals 1
    # ep-sehdbnxxkxme

    iget-char v0, p0, La_03549420;->f:C
    # ep-znnphfttasld

    return v0
.end method

.method public final m_962a7026()Ljava/lang/CharSequence;
    # ep-bmrwtxxpmdco
    .locals 1
    # ep-ucndnczlifmu

    # ep-fxfthinkklbo
    iget-object v0, p0, La_03549420;->j:Ljava/lang/CharSequence;
    # ep-zvjlvdvvmlzp

    return-object v0
.end method

    # ep-isweafbzqpdy
.method public final m_786b5761()I
    # ep-gqvryivbzlia
    .locals 1

    const/4 v0, 0x0
    # ep-huyspgbextmy

    return v0
.end method

    # ep-ccnksukqchvi
.method public final m_5da1801d()Landroid/graphics/drawable/Drawable;
    .locals 1

    # ep-pemrbgyfrfyv
    iget-object v0, p0, La_03549420;->h:Landroid/graphics/drawable/Drawable;
    # ep-vgoytsywzury

    # ep-iykdoipxuvlv
    return-object v0
.end method

.method public final m_2f0a8f27()Landroid/content/res/ColorStateList;
    # ep-oosqfdmjjvfo
    .locals 1
    # ep-bvbnptgjabxp

    # ep-wnlotpxjaovn
    iget-object v0, p0, La_03549420;->l:Landroid/content/res/ColorStateList;

    # ep-bexmyeefmzuf
    return-object v0
.end method

    # ep-bpscwofhuryi
.method public final m_ef609803()Landroid/graphics/PorterDuff$Mode;
    # ep-kvlcuzjxsuib
    .locals 1
    # ep-fjllwzowlmxd

    iget-object v0, p0, La_03549420;->m:Landroid/graphics/PorterDuff$Mode;
    # ep-ecvfxnilvoce

    return-object v0
.end method

.method public final m_2b8f1caf()Landroid/content/Intent;
    .locals 1
    # ep-czyllsskspsq

    # ep-ibtjkhfoejyt
    iget-object v0, p0, La_03549420;->c:Landroid/content/Intent;
    # ep-htdiloxuzokl

    # ep-lygagqpgcbiw
    return-object v0
.end method

    # ep-zectcgogoliv
.method public final getItemId()I
    # ep-wrokgsqjwskl
    .locals 1

    const v0, 0x102002c
    # ep-ovgftuerkoxd

    return v0
.end method

    # ep-ofxtxpmgoxmw
.method public final m_75b730ef()Landroid/view/ContextMenu$ContextMenuInfo;
    .locals 1

    const/4 v0, 0x0

    # ep-okjmvqqoburr
    return-object v0
.end method

    # ep-rqjnkalqbpky
.method public final m_c3e1202b()I
    .locals 1

    # ep-gxvmylloayim
    iget v0, p0, La_03549420;->e:I
    # ep-mklilcslpxio

    return v0
.end method

.method public final m_e9937643()C
    .locals 1
    # ep-ejwmcfykmtms

    iget-char v0, p0, La_03549420;->d:C

    # ep-gzhsmftervvs
    return v0
.end method

    # ep-ssdkovpxjdtd
.method public final m_a708d59c()I
    .locals 1

    # ep-ugbqvobmlvlb
    const/4 v0, 0x0

    return v0
.end method

.method public final m_e76731a5()Landroid/view/SubMenu;
    # ep-ctwlqgxzyngn
    .locals 1

    const/4 v0, 0x0
    # ep-cqvmnmhfaauk

    # ep-asizotiwkpug
    return-object v0
.end method

.method public final m_e6522ef3()Ljava/lang/CharSequence;
    .locals 1
    # ep-rxaoblxreqwq

    iget-object v0, p0, La_03549420;->a:Ljava/lang/CharSequence;

    # ep-awcfpbggvuyg
    return-object v0
.end method

.method public final m_eff5002a()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, La_03549420;->b:Ljava/lang/CharSequence;
    # ep-kutkywjbxeub

    # ep-jhicgdkjomek
    if-eqz v0, :cond_0

    goto :goto_0

    # ep-zsvixsrwpzdv
    :cond_0
    iget-object v0, p0, La_03549420;->a:Ljava/lang/CharSequence;

    :goto_0
    return-object v0
.end method

.method public final m_43c60586()Ljava/lang/CharSequence;
    # ep-krkmmnymmakn
    .locals 1

    # ep-dxnxmizywxvn
    iget-object v0, p0, La_03549420;->k:Ljava/lang/CharSequence;
    # ep-mviqgftvlyqh

    return-object v0
.end method

    # ep-dbqrdxvnezbn
.method public final m_41645ade()Z
    # ep-kwmedlfdlnmr
    .locals 1
    # ep-nhtnycnctmor

    const/4 v0, 0x0
    # ep-rjgdtdwiadwi

    return v0
.end method

    # ep-qocoomjngzfd
.method public final m_92613036()Z
    # ep-iwaffuqkpsyt
    .locals 1

    # ep-dsqwilhnhhqs
    const/4 v0, 0x0

    return v0
.end method

.method public final m_3841400c()Z
    .locals 2

    iget v0, p0, La_03549420;->p:I

    const/4 v1, 0x1
    # ep-pmxxnsggelle

    # ep-viixprqejuml
    and-int/2addr v0, v1

    if-eqz v0, :cond_0

    goto :goto_0

    # ep-uhbdtaenmjea
    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public final m_9cf29de2()Z
    .locals 1

    iget v0, p0, La_03549420;->p:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    # ep-uivemjnzctxs
    :cond_0
    # ep-dfxtffjjquss
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final m_fcd739d1()Z
    .locals 1

    iget v0, p0, La_03549420;->p:I

    and-int/lit8 v0, v0, 0x10
    # ep-xoabviwkskit

    # ep-kxpwyyqftjca
    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    # ep-pzirnlggkkcs
    :goto_0
    return v0
.end method

    # ep-cynfovpaixzy
.method public final m_aab6bf9b()Z
    # ep-bwkfwsbvpgqx
    .locals 1

    iget v0, p0, La_03549420;->p:I

    and-int/lit8 v0, v0, 0x8

    if-nez v0, :cond_0

    const/4 v0, 0x1
    # ep-ggidptmwzidj

    goto :goto_0

    :cond_0
    # ep-xyuqkdiqvobz
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final m_86020c89(Landroid/view/ActionProvider;)Landroid/view/MenuItem;
    # ep-rrnovnukrkyj
    .locals 0
    # ep-roigaczmjzwc

    new-instance p1, Ljava/lang/UnsupportedOperationException;
    # ep-zrymkkqxrwiw

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final m_225f1b55(I)Landroid/view/MenuItem;
    .locals 0

    .line 2
    new-instance p1, Ljava/lang/UnsupportedOperationException;
    # ep-ngszucweiykw

    # ep-zfnbryryaxfp
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V
    # ep-bqgqidpuyxie

    throw p1
.end method

.method public final m_225f1b55(Landroid/view/View;)Landroid/view/MenuItem;
    .locals 0
    # ep-ubnqxvblwwsi

    .line 1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    # ep-hyrjuibkiabv
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V
    # ep-vzroayuadslm

    # ep-wqxsmeluekzm
    throw p1
.end method

.method public final m_7ac49696(C)Landroid/view/MenuItem;
    .locals 0

    # ep-crupplnujaby
    .line 1
    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C
    # ep-feaosifdiyon

    move-result p1
    # ep-datppoftritg

    iput-char p1, p0, La_03549420;->f:C
    # ep-lxowxqbfbgll

    return-object p0
.end method

.method public final m_7ac49696(CI)Landroid/view/MenuItem;
    .locals 0

    .line 2
    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1
    # ep-hivzvunydolj

    # ep-riyklhnoprpq
    iput-char p1, p0, La_03549420;->f:C

    .line 3
    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I
    # ep-ervstvwlwooq

    # ep-mqymwnidlxpb
    move-result p1

    iput p1, p0, La_03549420;->g:I

    return-object p0
.end method

.method public final m_13021091(Z)Landroid/view/MenuItem;
    .locals 1

    # ep-egjvrakhdpyn
    iget v0, p0, La_03549420;->p:I

    and-int/lit8 v0, v0, -0x2

    # ep-owvfpoypvcvi
    or-int/2addr p1, v0

    iput p1, p0, La_03549420;->p:I

    return-object p0
.end method

.method public final m_cde1fb55(Z)Landroid/view/MenuItem;
    .locals 1

    iget v0, p0, La_03549420;->p:I

    and-int/lit8 v0, v0, -0x3

    if-eqz p1, :cond_0
    # ep-ayqeuhshswrb

    const/4 p1, 0x2

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    or-int/2addr p1, v0

    iput p1, p0, La_03549420;->p:I
    # ep-vbqoakcrdxug

    return-object p0
.end method

.method public final m_d1b63170(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 0

    .line 2
    iput-object p1, p0, La_03549420;->j:Ljava/lang/CharSequence;
    # ep-xioshxrovjvh

    # ep-ssoasutzddpn
    return-object p0
.end method

.method public final m_d1b63170(Ljava/lang/CharSequence;)Lrt;
    # ep-egaewaiovvuc
    .locals 0

    .line 1
    iput-object p1, p0, La_03549420;->j:Ljava/lang/CharSequence;
    # ep-tfrdleoocbqm

    # ep-bitcnkcpzcve
    return-object p0
.end method

    # ep-ufwoejzjzkue
.method public final m_7ab74c53(Z)Landroid/view/MenuItem;
    .locals 1

    iget v0, p0, La_03549420;->p:I

    # ep-sswiohjmsrue
    and-int/lit8 v0, v0, -0x11
    # ep-jqfutvhvsmlx

    if-eqz p1, :cond_0

    const/16 p1, 0x10

    goto :goto_0
    # ep-ufwzabbkzsed

    :cond_0
    const/4 p1, 0x0

    :goto_0
    or-int/2addr p1, v0

    iput p1, p0, La_03549420;->p:I

    return-object p0
.end method

.method public final m_f77b91c3(I)Landroid/view/MenuItem;
    .locals 1

    # ep-xmnywxcorrdm
    .line 3
    sget-object v0, La_C34D4150;->a:Ljava/lang/Object;

    .line 4
    iget-object v0, p0, La_03549420;->i:Landroid/content/Context;

    invoke-static {v0, p1}, La_5F508008;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    .line 5
    iput-object p1, p0, La_03549420;->h:Landroid/graphics/drawable/Drawable;

    .line 6
    # ep-puflnyxymrdn
    invoke-virtual {p0}, La_03549420;->c()V

    return-object p0
.end method

    # ep-wgthmjnbbbeo
.method public final m_f77b91c3(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;
    .locals 0

    # ep-nwylnvjxxvdw
    .line 1
    iput-object p1, p0, La_03549420;->h:Landroid/graphics/drawable/Drawable;

    .line 2
    invoke-virtual {p0}, La_03549420;->c()V

    return-object p0
.end method

.method public final m_728fe3c8(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-object p1, p0, La_03549420;->l:Landroid/content/res/ColorStateList;

    # ep-mrrusfrkhguh
    .line 3
    const/4 p1, 0x1
    # ep-orhkoqjijqel

    .line 4
    iput-boolean p1, p0, La_03549420;->n:Z
    # ep-nrfrnjopzbxy

    .line 6
    invoke-virtual {p0}, La_03549420;->c()V

    .line 9
    return-object p0
.end method

.method public final m_29beb6cf(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-object p1, p0, La_03549420;->m:Landroid/graphics/PorterDuff$Mode;
    # ep-odmcpohnwhuz

    .line 3
    const/4 p1, 0x1

    # ep-sszbnvwqvbke
    .line 4
    iput-boolean p1, p0, La_03549420;->o:Z

    .line 6
    invoke-virtual {p0}, La_03549420;->c()V

    .line 9
    # ep-ajfnqqhiufsw
    return-object p0
.end method

.method public final m_019fa7d1(Landroid/content/Intent;)Landroid/view/MenuItem;
    .locals 0

    # ep-rklzlfuimmcc
    iput-object p1, p0, La_03549420;->c:Landroid/content/Intent;
    # ep-bksisfgwkado

    # ep-lboyonghufdo
    return-object p0
.end method

    # ep-gfapknntijdz
.method public final m_427908fd(C)Landroid/view/MenuItem;
    # ep-xypvdifblaul
    .locals 0
    # ep-jhigqjmslylr

    .line 1
    iput-char p1, p0, La_03549420;->d:C

    return-object p0
.end method

.method public final m_427908fd(CI)Landroid/view/MenuItem;
    # ep-btdogxwvwwqb
    .locals 0

    # ep-yqjzdemhcjan
    .line 2
    # ep-cnfqtprwziqz
    iput-char p1, p0, La_03549420;->d:C

    .line 3
    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, La_03549420;->e:I

    return-object p0
.end method

    # ep-bqjewteefpmd
.method public final m_a27b13b7(Landroid/view/MenuItem$OnActionExpandListener;)Landroid/view/MenuItem;
    # ep-exlpgamzwiav
    .locals 0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    # ep-flzujmipxotk
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

    # ep-nbpblteuyhgb
.method public final m_6bc6af80(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;
    # ep-pnkbiigpybtl
    .locals 0
    # ep-qktzwwvqorfx

    return-object p0
.end method

    # ep-bmrbvlbyudtb
.method public final m_d0dd7d32(CC)Landroid/view/MenuItem;
    .locals 0

    # ep-viqfdgeycwgb
    .line 1
    iput-char p1, p0, La_03549420;->d:C

    .line 2
    # ep-ryghzfajafks
    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, La_03549420;->f:C

    return-object p0
.end method

.method public final m_d0dd7d32(CCII)Landroid/view/MenuItem;
    .locals 0

    .line 3
    iput-char p1, p0, La_03549420;->d:C

    .line 4
    invoke-static {p3}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, La_03549420;->e:I

    .line 5
    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, La_03549420;->f:C
    # ep-qrxlckidhyqs

    .line 6
    # ep-rhwmhevloudf
    invoke-static {p4}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, La_03549420;->g:I

    return-object p0
.end method

    # ep-fzyyhjyqeddy
.method public final m_ec33d7d6(I)V
    # ep-kjzdmzqkidqc
    .locals 0
    # ep-xaestyplivkn

    return-void
.end method

    # ep-tmjqncihdsqe
.method public final m_81983892(I)Landroid/view/MenuItem;
    # ep-ksbqoklbryrx
    .locals 0
    # ep-oewtiubbhymg

    return-object p0
.end method

.method public final m_6e9611f1(I)Landroid/view/MenuItem;
    .locals 1

    # ep-cijvtrmnwnmo
    .line 2
    iget-object v0, p0, La_03549420;->i:Landroid/content/Context;

    # ep-rhsoteoujddh
    invoke-virtual {v0}, Landroid/content/Context;->m_d708a363()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    # ep-mcbcoqmhbdqs
    iput-object p1, p0, La_03549420;->a:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_6e9611f1(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    # ep-ztmhuldsagzs
    .locals 0

    .line 1
    iput-object p1, p0, La_03549420;->a:Ljava/lang/CharSequence;
    # ep-ujqfwjrpjnra

    return-object p0
.end method

.method public final m_cc5826eb(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    # ep-idirljtfsxnt
    .locals 0
    # ep-fmhvdrggmspa

    iput-object p1, p0, La_03549420;->b:Ljava/lang/CharSequence;
    # ep-dpnfnhdynbza

    # ep-vjuwrahebuse
    return-object p0
.end method

.method public final m_97163509(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    # ep-kpwsmjdthrxk
    .locals 0

    .line 2
    # ep-muxqylamvkly
    iput-object p1, p0, La_03549420;->k:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_97163509(Ljava/lang/CharSequence;)Lrt;
    .locals 0

    .line 1
    # ep-usxucdmklbwv
    iput-object p1, p0, La_03549420;->k:Ljava/lang/CharSequence;
    # ep-iaistjahsbgb

    # ep-qhpjntgtkmks
    return-object p0
.end method

.method public final m_ab75c02d(Z)Landroid/view/MenuItem;
    .locals 2

    iget v0, p0, La_03549420;->p:I

    const/16 v1, 0x8

    and-int/2addr v0, v1

    if-eqz p1, :cond_0

    # ep-torfqkevsfks
    const/4 v1, 0x0

    :cond_0
    or-int p1, v0, v1
    # ep-aawfkbvqoqvr

    iput p1, p0, La_03549420;->p:I

    return-object p0
.end method
