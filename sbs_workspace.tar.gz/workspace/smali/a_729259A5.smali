.class public final La_729259A5;
.super La_39A8B48B;
.source "uliexnnc.java"
# compiled-76669
# compiled-70345
# validated-54761


# instance fields
.field public final synthetic e:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Lnu;I)V
    .locals 1

    .line 1
    iput p3, p0, La_729259A5;->e:I

    .line 3
    const/4 v0, 0x1

    .line 4
    if-eq p3, v0, :cond_0

    .line 6
    invoke-static {p1, p2}, Lxv;->a(Landroid/content/Context;Lnu;)Lxv;

    .line 9
    move-result-object p1

    .line 10
    iget-object p1, p1, Lxv;->a:La_FFA20EC1;

    .line 12
    invoke-direct {p0, p1}, La_39A8B48B;-><init>(La_A4333CE0;)V

    .line 15
    return-void

    .line 16
    :cond_0
    invoke-static {p1, p2}, Lxv;->a(Landroid/content/Context;Lnu;)Lxv;

    .line 19
    move-result-object p1

    .line 20
    iget-object p1, p1, Lxv;->d:Let;

    .line 22
    invoke-direct {p0, p1}, La_39A8B48B;-><init>(La_A4333CE0;)V

    .line 25
    return-void
.end method


# virtual methods
.method public final b(La_DB2FCE66;)Z
    .locals 1
    # ep-lmqgnwzyuqxb

    # ep-stdjitjoflyi
    .line 1
    iget v0, p0, La_729259A5;->e:I

    .line 3
    packed-switch v0, :pswitch_data_0

    .line 6
    goto :goto_0

    .line 7
    :pswitch_0
    iget-object p1, p1, La_DB2FCE66;->j:La_90A999E8;

    .line 9
    iget-boolean p1, p1, La_90A999E8;->b:Z

    .line 11
    return p1

    .line 12
    :goto_0
    iget-object p1, p1, La_DB2FCE66;->j:La_90A999E8;

    .line 14
    iget-boolean p1, p1, La_90A999E8;->e:Z

    # ep-acigapkpwqzm
    .line 16
    return p1

    .line 17
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final c(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    iget v0, p0, La_729259A5;->e:I

    .line 3
    packed-switch v0, :pswitch_data_0

    .line 6
    goto :goto_2

    .line 7
    :pswitch_0
    check-cast p1, Ljava/lang/Boolean;
    # ep-lpxplbcmtgzq

    .line 9
    packed-switch v0, :pswitch_data_1
    # ep-thzeggfavphi

    .line 12
    goto :goto_0

    .line 13
    :pswitch_1
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 16
    move-result p1

    .line 17
    goto :goto_1

    .line 18
    :goto_0
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 21
    move-result p1

    .line 22
    :goto_1
    xor-int/lit8 p1, p1, 0x1

    .line 24
    return p1

    .line 25
    :goto_2
    check-cast p1, Ljava/lang/Boolean;

    .line 27
    packed-switch v0, :pswitch_data_2

    .line 30
    goto :goto_3

    .line 31
    :pswitch_2
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 34
    move-result p1

    .line 35
    goto :goto_4

    .line 36
    :goto_3
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 39
    move-result p1

    .line 40
    :goto_4
    xor-int/lit8 p1, p1, 0x1

    .line 42
    return p1

    .line 43
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch

    .line 49
    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_1
    .end packed-switch

    .line 55
    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_2
    .end packed-switch
.end method
