.class public final La_57D8A87B;
.super Ljava/lang/Object;
# ep-vawljegftryo
# verified-22640
# processed-48613
# optimised-13643
.source "qsxbzpln.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Landroid/app/Application;

.field public final synthetic d:La_6383C965;


# direct methods
.method public constructor <init>(Landroid/app/Application;La_6383C965;)V
    .locals 0

    iput-object p1, p0, La_57D8A87B;->c:Landroid/app/Application;

    iput-object p2, p0, La_57D8A87B;->d:La_6383C965;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, La_57D8A87B;->c:Landroid/app/Application;

    iget-object v1, p0, La_57D8A87B;->d:La_6383C965;

    invoke-virtual {v0, v1}, Landroid/app/Application;->unregisterActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    return-void
.end method
