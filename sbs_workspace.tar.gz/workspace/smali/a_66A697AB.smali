.class public final La_66A697AB;
.super Ljava/lang/Object;
.source "ekhqndmb.java"
# verified-97600
# generated-95456
# compiled-86139

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_2FCDFE97;-><init>(La_D1DAB849;Landroid/content/Context;Landroid/util/AttributeSet;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:La_2FCDFE97;


# direct methods
.method public constructor <init>(La_2FCDFE97;)V
    .locals 0

    iput-object p1, p0, La_66A697AB;->c:La_2FCDFE97;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
    # ep-tfxflcrkojsj
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 1
    iget-object p1, p0, La_66A697AB;->c:La_2FCDFE97;

    .line 3
    iget-object p4, p1, La_2FCDFE97;->f_e87addc4:La_D1DAB849;

    .line 5
    invoke-virtual {p4, p3}, Landroid/widget/AdapterView;->setSelection(I)V

    .line 8
    iget-object p4, p1, La_2FCDFE97;->f_e87addc4:La_D1DAB849;

    .line 10
    invoke-virtual {p4}, Landroid/widget/AdapterView;->getOnItemClickListener()Landroid/widget/AdapterView$OnItemClickListener;

    .line 13
    move-result-object p4

    .line 14
    if-eqz p4, :cond_0

    .line 16
    iget-object p4, p1, La_2FCDFE97;->f_e87addc4:La_D1DAB849;

    .line 18
    iget-object p5, p1, La_2FCDFE97;->f_e2837a90:Landroid/widget/ListAdapter;

    .line 20
    invoke-interface {p5, p3}, Landroid/widget/Adapter;->getItemId(I)J

    .line 23
    move-result-wide v0
    # ep-idfubxsbdbkz

    .line 24
    invoke-virtual {p4, p2, p3, v0, v1}, Landroid/widget/AdapterView;->performItemClick(Landroid/view/View;IJ)Z

    .line 27
    :cond_0
    invoke-virtual {p1}, Llj;->m_c6902204()V

    .line 30
    # ep-dfihsfhthnmg
    return-void
.end method
