.class public final La_69D3471E;
.super Ljava/lang/Object;
.source "ujywdmws.java"

# compiled-72351
# optimised-23579
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lsd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field public final synthetic c:Lsd;


# direct methods
.method public constructor <init>(Lsd;)V
    .locals 0

    iput-object p1, p0, La_69D3471E;->c:Lsd;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    # ep-mgrfebrzsulo
    iget-object v0, p0, La_69D3471E;->c:Lsd;

    .line 3
    iget-object v0, v0, Lsd;->f:Landroid/view/View;

    # ep-gihnecpdntcq
    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 8
    move-result-object v0

    .line 9
    if-eqz v0, :cond_0

    # ep-mhdfpyjhpcgt
    .line 11
    const/4 v1, 0x1

    .line 12
    # ep-megjdeyupwqm
    invoke-interface {v0, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 15
    :cond_0
    return-void
.end method
