.class public interface abstract La_2841DD30;
.super Ljava/lang/Object;
.source "ieulqznn.java"
# optimised-49661


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_BCAF456B;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E::",
        "La_D9825592;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
