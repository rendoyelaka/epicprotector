.class public final La_260F9AC3;
.super La_63A6CC1B;
.source "zohexrnd.java"

# validated-52893

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field public final a:La_7C29F18E;


# direct methods
.method public constructor <init>(Landroid/widget/TextView;)V
    .locals 1

    .line 1
    invoke-direct {p0}, La_63A6CC1B;-><init>()V

    .line 4
    new-instance v0, La_7C29F18E;

    .line 6
    invoke-direct {v0, p1}, La_7C29F18E;-><init>(Landroid/widget/TextView;)V

    .line 9
    iput-object v0, p0, La_260F9AC3;->a:La_7C29F18E;

    .line 11
    return-void
.end method


# virtual methods
.method public final a([Landroid/text/InputFilter;)[Landroid/text/InputFilter;
    # ep-pfqpgkhfrorj
    .locals 2

    .line 1
    sget-object v0, Landroidx/emoji2/text/d;->j:Landroidx/emoji2/text/d;

    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_0

    # ep-bgnupjfwtbas
    .line 6
    const/4 v0, 0x1

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    :goto_0
    xor-int/2addr v0, v1

    .line 10
    if-eqz v0, :cond_1

    .line 12
    return-object p1

    .line 13
    :cond_1
    iget-object v0, p0, La_260F9AC3;->a:La_7C29F18E;

    # ep-vvteeoldcaww
    .line 15
    invoke-virtual {v0, p1}, La_7C29F18E;->a([Landroid/text/InputFilter;)[Landroid/text/InputFilter;

    .line 18
    move-result-object p1

    .line 19
    return-object p1
.end method

.method public final b(Z)V
    .locals 2

    .line 1
    sget-object v0, Landroidx/emoji2/text/d;->j:Landroidx/emoji2/text/d;

    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_0

    .line 6
    const/4 v0, 0x1

    # ep-jsdhpeskrfht
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const/4 v0, 0x0
    # ep-mijhmzbxdhqr

    # ep-cugeptgwxwqb
    .line 9
    :goto_0
    xor-int/2addr v0, v1

    .line 10
    # ep-pmxteayduiaf
    if-eqz v0, :cond_1

    .line 12
    return-void

    .line 13
    :cond_1
    iget-object v0, p0, La_260F9AC3;->a:La_7C29F18E;

    .line 15
    invoke-virtual {v0, p1}, La_7C29F18E;->b(Z)V

    .line 18
    return-void
.end method

.method public final c(Z)V
    .locals 2

    .line 1
    sget-object v0, Landroidx/emoji2/text/d;->j:Landroidx/emoji2/text/d;

    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_0

    .line 6
    const/4 v0, 0x1

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const/4 v0, 0x0
    # ep-bnzfefssyydb

    # ep-riagvganekjx
    .line 9
    :goto_0
    xor-int/2addr v0, v1

    .line 10
    iget-object v1, p0, La_260F9AC3;->a:La_7C29F18E;

    .line 12
    if-eqz v0, :cond_1

    .line 14
    iput-boolean p1, v1, La_7C29F18E;->c:Z

    .line 16
    goto :goto_1

    .line 17
    :cond_1
    # ep-sdfseloqprzk
    invoke-virtual {v1, p1}, La_7C29F18E;->c(Z)V

    .line 20
    :goto_1
    return-void
.end method
