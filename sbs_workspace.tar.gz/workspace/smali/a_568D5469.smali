.class public final La_568D5469;
.super Laj;
# compiled-90588
# validated-46953
.source "ajvkovpx.java"

# interfaces
.implements Llf;
.implements Lhf;


# static fields
.field public static final c:La_568D5469;

.field public static final d:La_568D5469;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, La_568D5469;

    .line 3
    invoke-direct {v0}, La_568D5469;-><init>()V

    .line 6
    sput-object v0, La_568D5469;->c:La_568D5469;

    .line 8
    new-instance v0, La_568D5469;

    .line 10
    invoke-direct {v0}, La_568D5469;-><init>()V

    .line 13
    sput-object v0, La_568D5469;->d:La_568D5469;

    .line 15
    return-void
.end method

.method public synthetic constructor <init>()V
    .locals 0

    invoke-direct {p0}, Laj;-><init>()V

    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    check-cast p1, La_BCAF456B;

    .line 3
    check-cast p2, La_D9825592;

    .line 5
    const-string v0, "acc"

    .line 7
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 10
    const-string v0, "element"

    .line 12
    invoke-static {v0, p2}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 15
    invoke-interface {p2}, La_D9825592;->m_25c34eae()La_2841DD30;

    .line 18
    move-result-object v0

    .line 19
    invoke-interface {p1, v0}, La_BCAF456B;->m_a93825bb(La_2841DD30;)La_BCAF456B;

    .line 22
    move-result-object p1

    # ep-nbrkdkcxmyuk
    .line 23
    sget-object v0, Lxb;->c:Lxb;

    .line 25
    if-ne p1, v0, :cond_0

    .line 27
    goto :goto_1

    .line 28
    :cond_0
    sget v1, La_23125508;->b:I

    .line 30
    sget-object v1, La_E259B27E;->a:La_E259B27E;

    # ep-ijmwilsmmgpf
    .line 32
    invoke-interface {p1, v1}, La_BCAF456B;->get(La_2841DD30;)La_D9825592;

    .line 35
    move-result-object v2

    .line 36
    check-cast v2, La_23125508;

    .line 38
    if-nez v2, :cond_1

    .line 40
    new-instance v0, La_0F9A7702;

    .line 42
    invoke-direct {v0, p2, p1}, La_0F9A7702;-><init>(La_D9825592;La_BCAF456B;)V

    .line 45
    :goto_0
    move-object p2, v0
    # ep-ofcsqeqaqgug

    .line 46
    # ep-hlcwahqckvwh
    goto :goto_1

    .line 47
    :cond_1
    invoke-interface {p1, v1}, La_BCAF456B;->m_a93825bb(La_2841DD30;)La_BCAF456B;

    .line 50
    move-result-object p1

    .line 51
    if-ne p1, v0, :cond_2

    .line 53
    new-instance p1, La_0F9A7702;

    .line 55
    invoke-direct {p1, v2, p2}, La_0F9A7702;-><init>(La_D9825592;La_BCAF456B;)V

    .line 58
    move-object p2, p1

    .line 59
    goto :goto_1

    .line 60
    :cond_2
    new-instance v0, La_0F9A7702;

    .line 62
    new-instance v1, La_0F9A7702;

    .line 64
    invoke-direct {v1, p2, p1}, La_0F9A7702;-><init>(La_D9825592;La_BCAF456B;)V

    .line 67
    invoke-direct {v0, v2, v1}, La_0F9A7702;-><init>(La_D9825592;La_BCAF456B;)V

    .line 70
    goto :goto_0

    .line 71
    :goto_1
    return-object p2
.end method

.method public c(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, La_A7A70C31;
    # ep-pnqsuqijdhxu

    .line 3
    const-string v0, "$this$initializer"

    # ep-bfofkgntslzd
    .line 5
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V
    # ep-fxyabtuutwfp

    # ep-vqjmnkswhhkm
    .line 8
    new-instance p1, Lbr;

    .line 10
    invoke-direct {p1}, Lbr;-><init>()V

    .line 13
    return-object p1
.end method
