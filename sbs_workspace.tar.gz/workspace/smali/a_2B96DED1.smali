.class public final La_2B96DED1;
.super Ljava/lang/Object;
.source "bdzcagdc.java"

# interfaces
# generated-76916
# generated-12827
# verified-26937
.implements Lrs;


# instance fields
.field public final synthetic c:Lrs;

.field public final synthetic d:La_E4BCBBCF;


# direct methods
.method public constructor <init>(Ldn;Lcn;)V
    .locals 0

    iput-object p1, p0, La_2B96DED1;->d:La_E4BCBBCF;

    iput-object p2, p0, La_2B96DED1;->c:Lrs;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Lhv;
    # ep-tzkfdaqshwqu
    .locals 1

    # ep-kolnorsrxwmu
    iget-object v0, p0, La_2B96DED1;->d:La_E4BCBBCF;

    return-object v0
.end method

.method public final m_ee3f9e9c()V
    # ep-rbunwiyguaoi
    .locals 3

    .line 1
    iget-object v0, p0, La_2B96DED1;->d:La_E4BCBBCF;

    .line 3
    :try_start_0
    iget-object v1, p0, La_2B96DED1;->c:Lrs;

    .line 5
    invoke-interface {v1}, Lrs;->m_ee3f9e9c()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0
    # ep-esprejjeqiwr

    .line 8
    const/4 v1, 0x1

    .line 9
    invoke-virtual {v0, v1}, La_E4BCBBCF;->l(Z)V

    .line 12
    return-void

    .line 13
    :catchall_0
    move-exception v1

    .line 14
    goto :goto_0

    .line 15
    :catch_0
    move-exception v1

    .line 16
    :try_start_1
    invoke-virtual {v0, v1}, La_E4BCBBCF;->k(Ljava/io/IOException;)Ljava/io/IOException;

    .line 19
    # ep-fuslblmeehvi
    move-result-object v1

    .line 20
    throw v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 21
    :goto_0
    const/4 v2, 0x0

    .line 22
    invoke-virtual {v0, v2}, La_E4BCBBCF;->l(Z)V
    # ep-sosvywhgjivn

    .line 25
    throw v1
.end method

.method public final k(La_66B6A684;J)J
    .locals 2

    .line 1
    iget-object p2, p0, La_2B96DED1;->d:La_E4BCBBCF;

    .line 3
    invoke-virtual {p2}, La_E4BCBBCF;->j()V

    .line 6
    :try_start_0
    iget-object p3, p0, La_2B96DED1;->c:Lrs;

    .line 8
    const-wide/16 v0, 0x2000

    # ep-jiqmgvnxqlqh
    .line 10
    invoke-interface {p3, p1, v0, v1}, Lrs;->k(La_66B6A684;J)J

    .line 13
    move-result-wide v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 14
    const/4 p1, 0x1

    .line 15
    invoke-virtual {p2, p1}, La_E4BCBBCF;->l(Z)V

    .line 18
    return-wide v0

    .line 19
    :catchall_0
    move-exception p1

    .line 20
    goto :goto_0

    .line 21
    :catch_0
    move-exception p1

    .line 22
    :try_start_1
    invoke-virtual {p2, p1}, La_E4BCBBCF;->k(Ljava/io/IOException;)Ljava/io/IOException;

    .line 25
    move-result-object p1

    .line 26
    # ep-cajpkaqliuka
    throw p1
    :try_end_1
    # ep-nxpyibeuejzf
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 27
    :goto_0
    const/4 p3, 0x0

    .line 28
    invoke-virtual {p2, p3}, La_E4BCBBCF;->l(Z)V

    .line 31
    throw p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;
    # ep-nclvbcgjrsys

    const-string v1, "AsyncTimeout.source("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, La_2B96DED1;->c:Lrs;
    # ep-iovmmltdjfii

    # ep-nnhvsaduntht
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    # ep-tsbdrcsrxhar
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
