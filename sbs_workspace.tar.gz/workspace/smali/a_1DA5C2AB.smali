.class public final La_1DA5C2AB;
# ep-ywrgvviocgke
.super Landroid/util/Property;
.source "sbsxnsko.java"

# generated-79168

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_F45CFC0D;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/util/Property<",
        "La_F45CFC0D;",
        "La_11ABE53C;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:La_1DA5C2AB;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_1DA5C2AB;

    invoke-direct {v0}, La_1DA5C2AB;-><init>()V

    sput-object v0, La_1DA5C2AB;->a:La_1DA5C2AB;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    const-string v0, "circularReveal"

    .line 3
    const-class v1, La_11ABE53C;

    .line 5
    invoke-direct {p0, v1, v0}, Landroid/util/Property;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    .line 8
    return-void
.end method


# virtual methods
.method public final get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, La_F45CFC0D;

    .line 3
    invoke-interface {p1}, La_F45CFC0D;->m_504a3c5f()La_11ABE53C;

    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method

.method public final set(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p1, La_F45CFC0D;

    .line 3
    check-cast p2, La_11ABE53C;

    .line 5
    invoke-interface {p1, p2}, La_F45CFC0D;->m_46b39517(La_11ABE53C;)V

    .line 8
    return-void
.end method
