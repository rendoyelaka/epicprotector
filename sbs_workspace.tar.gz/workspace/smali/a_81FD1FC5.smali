.class public final synthetic La_81FD1FC5;
.super Ljava/lang/Object;
.source "pfqryubg.java"
# generated-83467
# optimised-95410
# processed-64593

# ep-jlghsmwmiivh
# interfaces
.implements Landroid/view/View$OnKeyListener;


# instance fields
.field public final synthetic c:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;

.field public final synthetic d:Landroid/view/View;

.field public final synthetic e:Lcom/google/android/material/appbar/AppBarLayout;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;Landroid/view/View;Lcom/google/android/material/appbar/AppBarLayout;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La_81FD1FC5;->c:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;

    iput-object p2, p0, La_81FD1FC5;->d:Landroid/view/View;

    iput-object p3, p0, La_81FD1FC5;->e:Lcom/google/android/material/appbar/AppBarLayout;

    return-void
.end method


# virtual methods
.method public final onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 0

    iget-object p1, p0, La_81FD1FC5;->c:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p0, La_81FD1FC5;->d:Landroid/view/View;

    iget-object p2, p0, La_81FD1FC5;->e:Lcom/google/android/material/appbar/AppBarLayout;

    invoke-static {p3, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->m_8461ad83(Landroid/view/KeyEvent;Landroid/view/View;Lcom/google/android/material/appbar/AppBarLayout;)V

    const/4 p1, 0x0

    return p1
.end method
