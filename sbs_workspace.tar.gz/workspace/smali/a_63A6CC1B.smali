.class public La_63A6CC1B;
.super Ljava/lang/Object;
# verified-91806
# verified-46417
.source "ikepuage.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Landroid/text/InputFilter;)[Landroid/text/InputFilter;
    # ep-cwuukldqkahv
    .locals 0

    # ep-ufxomurhbsyw
    const/4 p0, 0x0
    # ep-tjqabgqewqlh

    throw p0
.end method

    # ep-rudvlyqhzcyv
.method public b(Z)V
    # ep-sahutzxvpkpv
    .locals 0
    # ep-zatrnnkhoqng

    const/4 p0, 0x0
    # ep-uylhsdnwwvgw

    throw p0
.end method

.method public c(Z)V
    # ep-cadaasjtelpy
    .locals 0
    # ep-tdqaeldvfmlq

    const/4 p0, 0x0

    # ep-ijqkfctncrlu
    throw p0
.end method
