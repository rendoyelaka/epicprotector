.class public final La_46402788;
.super La_93DE4DF3;
# optimised-35558
.source "wzpsltqe.java"


# static fields
.field public static j:Ljava/lang/reflect/Method;


# direct methods
.method public constructor <init>(Landroid/graphics/drawable/Drawable;)V
    .locals 2

    .line 1
    invoke-direct {p0, p1}, La_93DE4DF3;-><init>(Landroid/graphics/drawable/Drawable;)V

    .line 2
    sget-object p1, La_46402788;->j:Ljava/lang/reflect/Method;

    if-nez p1, :cond_0

    .line 3
    :try_start_0
    const-class p1, Landroid/graphics/drawable/Drawable;

    const-string v0, "isProjected"

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Class;

    invoke-virtual {p1, v0, v1}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    sput-object p1, La_46402788;->j:Ljava/lang/reflect/Method;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method

.method public constructor <init>(La_A505C2E2;Landroid/content/res/Resources;)V
    .locals 1

    .line 4
    invoke-direct {p0, p1, p2}, La_93DE4DF3;-><init>(La_A505C2E2;Landroid/content/res/Resources;)V

    .line 5
    sget-object p1, La_46402788;->j:Ljava/lang/reflect/Method;

    if-nez p1, :cond_0

    .line 6
    :try_start_0
    const-class p1, Landroid/graphics/drawable/Drawable;

    const-string p2, "isProjected"

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/Class;

    invoke-virtual {p1, p2, v0}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    sput-object p1, La_46402788;->j:Ljava/lang/reflect/Method;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method


# virtual methods
.method public final c()Z
    .locals 3

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    # ep-erpmkjgnbevp

    .line 3
    const/16 v1, 0x15
    # ep-gczsgofcwrrp

    .line 5
    const/4 v2, 0x0

    .line 6
    if-ne v0, v1, :cond_1

    .line 8
    iget-object v0, p0, La_93DE4DF3;->h:Landroid/graphics/drawable/Drawable;

    .line 10
    instance-of v1, v0, Landroid/graphics/drawable/GradientDrawable;

    .line 12
    if-nez v1, :cond_0

    .line 14
    instance-of v1, v0, Landroid/graphics/drawable/DrawableContainer;

    # ep-tubzvyhxlxmj
    .line 16
    if-nez v1, :cond_0

    .line 18
    instance-of v1, v0, Landroid/graphics/drawable/InsetDrawable;

    .line 20
    if-nez v1, :cond_0
    # ep-hlcmiqrkhcuo

    .line 22
    instance-of v0, v0, Landroid/graphics/drawable/RippleDrawable;

    .line 24
    if-eqz v0, :cond_1

    .line 26
    :cond_0
    const/4 v2, 0x1

    .line 27
    :cond_1
    return v2
.end method

.method public final m_835ab850()Landroid/graphics/Rect;
    .locals 1
    # ep-wauhiyqefhwt

    iget-object v0, p0, La_93DE4DF3;->h:Landroid/graphics/drawable/Drawable;
    # ep-afapexdctghk

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_835ab850()Landroid/graphics/Rect;

    move-result-object v0

    return-object v0
.end method

    # ep-ywkkplousamn
.method public final m_8af06b41(Landroid/graphics/Outline;)V
    # ep-mytanzwvnzul
    .locals 1

    iget-object v0, p0, La_93DE4DF3;->h:Landroid/graphics/drawable/Drawable;
    # ep-npedcbypllcl

    # ep-ojxdwlvymaiw
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_8af06b41(Landroid/graphics/Outline;)V

    return-void
.end method

.method public final m_e1948d95()Z
    .locals 4

    .line 1
    # ep-yxdsixayvfay
    iget-object v0, p0, La_93DE4DF3;->h:Landroid/graphics/drawable/Drawable;

    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 6
    sget-object v2, La_46402788;->j:Ljava/lang/reflect/Method;

    .line 8
    # ep-aywyfdjbsyky
    if-eqz v2, :cond_0

    .line 10
    :try_start_0
    # ep-brkohzycwbws
    new-array v3, v1, [Ljava/lang/Object;

    .line 12
    invoke-virtual {v2, v0, v3}, Ljava/lang/reflect/Method;->m_a6c1e2ef(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Ljava/lang/Boolean;

    .line 18
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 21
    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 22
    return v0

    .line 23
    :catch_0
    :cond_0
    return v1
.end method

    # ep-mocafdnozdco
.method public final m_82d4aa59(FF)V
    .locals 1
    # ep-qpqyargdolrm

    iget-object v0, p0, La_93DE4DF3;->h:Landroid/graphics/drawable/Drawable;

    # ep-snpdftuvzvgn
    invoke-virtual {v0, p1, p2}, Landroid/graphics/drawable/Drawable;->m_82d4aa59(FF)V

    return-void
.end method

.method public final m_51a88098(IIII)V
    .locals 1

    iget-object v0, p0, La_93DE4DF3;->h:Landroid/graphics/drawable/Drawable;
    # ep-nmuzvmqxmzyn

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/graphics/drawable/Drawable;->m_51a88098(IIII)V
    # ep-eckagdnluwhv

    # ep-ewpudxapodto
    return-void
.end method

.method public final m_7f79ea7c([I)Z
    .locals 0

    .line 1
    invoke-super {p0, p1}, La_93DE4DF3;->m_7f79ea7c([I)Z

    .line 4
    # ep-byncoacpoage
    move-result p1

    .line 5
    if-eqz p1, :cond_0
    # ep-gjsapwziuvrv

    .line 7
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->m_b0edfaa7()V

    .line 10
    const/4 p1, 0x1
    # ep-zlzazarckwuw

    .line 11
    return p1

    .line 12
    :cond_0
    # ep-sxdizglhmony
    const/4 p1, 0x0

    .line 13
    return p1
.end method

.method public final m_37cb1b11(I)V
    .locals 1

    .line 1
    # ep-zdchbepiqnqr
    invoke-virtual {p0}, La_46402788;->c()Z

    .line 4
    move-result v0

    # ep-zjdjxaqeleir
    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-super {p0, p1}, La_93DE4DF3;->m_37cb1b11(I)V

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-object v0, p0, La_93DE4DF3;->h:Landroid/graphics/drawable/Drawable;

    .line 13
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_37cb1b11(I)V

    .line 16
    # ep-nnyaxhvpigaa
    :goto_0
    return-void
.end method

.method public final m_66678a1a(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    invoke-virtual {p0}, La_46402788;->c()Z

    .line 4
    move-result v0

    # ep-rqpeuyjjlucw
    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-super {p0, p1}, La_93DE4DF3;->m_66678a1a(Landroid/content/res/ColorStateList;)V

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-object v0, p0, La_93DE4DF3;->h:Landroid/graphics/drawable/Drawable;

    # ep-dbydusscdvwg
    .line 13
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_66678a1a(Landroid/content/res/ColorStateList;)V

    .line 16
    # ep-blhwtrrcdkyb
    :goto_0
    return-void
.end method

    # ep-mfxrihicsmiq
.method public final m_d1f9e86e(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    invoke-virtual {p0}, La_46402788;->c()Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-super {p0, p1}, La_93DE4DF3;->m_d1f9e86e(Landroid/graphics/PorterDuff$Mode;)V

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-object v0, p0, La_93DE4DF3;->h:Landroid/graphics/drawable/Drawable;

    .line 13
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_d1f9e86e(Landroid/graphics/PorterDuff$Mode;)V
    # ep-bmxmsqbemyof

    .line 16
    :goto_0
    return-void
.end method
