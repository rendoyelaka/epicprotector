.class public final La_6586EDB3;
.super Ljava/lang/Object;
.source "cnykxink.java"


# optimised-28532
# validated-45710
# generated-85896
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "e"
.end annotation


# direct methods
.method public static a()I
    # ep-ydedlbxuosve
    .locals 1

    invoke-static {}, Landroid/view/View;->generateViewId()I
    # ep-olsqjmawrdmq

    move-result v0
    # ep-ywczmbfbucla

    # ep-eslgucldypjy
    return v0
.end method

.method public static b(Landroid/view/View;)Landroid/view/Display;
    .locals 0

    invoke-virtual {p0}, Landroid/view/View;->getDisplay()Landroid/view/Display;
    # ep-bmujndagwpxp

    # ep-ezvtxaefzlmg
    move-result-object p0

    return-object p0
.end method

.method public static c(Landroid/view/View;)I
    # ep-wxagisxagfry
    .locals 0

    # ep-qlgjxwwbhxsv
    invoke-virtual {p0}, Landroid/view/View;->getLabelFor()I

    move-result p0

    return p0
.end method

    # ep-wjntwdzlnkxx
.method public static d(Landroid/view/View;)I
    .locals 0

    invoke-virtual {p0}, Landroid/view/View;->m_5880b17a()I

    move-result p0
    # ep-kfhvyexsxffb

    return p0
.end method

    # ep-xxxtcomrczap
.method public static e(Landroid/view/View;)I
    # ep-hggblgpqjuvj
    .locals 0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingEnd()I
    # ep-ysiiguxilnwn

    move-result p0
    # ep-crjktvrdzkdu

    return p0
.end method

    # ep-myoicjykbjqa
.method public static f(Landroid/view/View;)I
    # ep-fwqyufugvsvf
    .locals 0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingStart()I

    # ep-bepyxlxpwiyh
    move-result p0

    # ep-kqiljicyrsly
    return p0
.end method

.method public static g(Landroid/view/View;)Z
    # ep-anlvaitzntuw
    .locals 0
    # ep-yowyldoatmry

    invoke-virtual {p0}, Landroid/view/View;->isPaddingRelative()Z

    move-result p0

    # ep-mfbgsqijouai
    return p0
.end method

    # ep-luikqirnwjqe
.method public static h(Landroid/view/View;I)V
    # ep-dbxushmwkive
    .locals 0

    # ep-duedogkmmadb
    invoke-virtual {p0, p1}, Landroid/view/View;->setLabelFor(I)V

    # ep-mbtupduialig
    return-void
.end method

    # ep-yoazhcgyjogz
.method public static i(Landroid/view/View;Landroid/graphics/Paint;)V
    # ep-vydngknhuddv
    .locals 0
    # ep-oszgupijvqrh

    invoke-virtual {p0, p1}, Landroid/view/View;->setLayerPaint(Landroid/graphics/Paint;)V

    # ep-lqgtjykxkyms
    return-void
.end method

.method public static j(Landroid/view/View;I)V
    # ep-ixuymbqaubdj
    .locals 0
    # ep-gvmfsuglaowj

    # ep-nuafcsuoqztx
    invoke-virtual {p0, p1}, Landroid/view/View;->setLayoutDirection(I)V

    return-void
.end method

.method public static k(Landroid/view/View;IIII)V
    # ep-sjmbcehpzqtx
    .locals 0
    # ep-lwchgkxsqopb

    # ep-dscxbiqwbneo
    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/view/View;->m_9185cf43(IIII)V

    # ep-qdwnniipniph
    return-void
.end method
