.class public interface abstract La_7DFF1DDA;
.super Ljava/lang/Object;
# validated-82829
# compiled-21830
# validated-84683
.source "hvhtecnm.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "f"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a(La_8C27E16D;)V
    .annotation system Ldalvik/annotation/Signature;
    # ep-zmzinatuunwe
        value = {
    # ep-evrtufnfwcts
            "(",
            "Lwq$c<",
            "TK;TV;>;)V"
        }
    .end annotation
.end method
