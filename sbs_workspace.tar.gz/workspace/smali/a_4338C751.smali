.class public final La_4338C751;
.super Ljava/lang/Object;
.source "pmxnrwom.java"
# generated-54964
# processed-52955
# processed-13234


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_512AB34F;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public a:Lnp;

.field public b:Lvo;

.field public c:I

.field public d:Ljava/lang/String;

.field public e:Leg;

.field public f:La_FAB612EB;

.field public g:Ldq;

.field public h:La_512AB34F;

.field public i:La_512AB34F;

.field public j:La_512AB34F;

.field public k:J

.field public l:J


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 2
    iput v0, p0, La_4338C751;->c:I

    .line 3
    new-instance v0, La_FAB612EB;

    invoke-direct {v0}, La_FAB612EB;-><init>()V

    iput-object v0, p0, La_4338C751;->f:La_FAB612EB;

    return-void
.end method

.method public constructor <init>(La_512AB34F;)V
    .locals 2

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 5
    iput v0, p0, La_4338C751;->c:I

    .line 6
    iget-object v0, p1, La_512AB34F;->c:Lnp;

    iput-object v0, p0, La_4338C751;->a:Lnp;

    .line 7
    iget-object v0, p1, La_512AB34F;->d:Lvo;

    iput-object v0, p0, La_4338C751;->b:Lvo;

    .line 8
    iget v0, p1, La_512AB34F;->e:I

    iput v0, p0, La_4338C751;->c:I

    .line 9
    iget-object v0, p1, La_512AB34F;->f:Ljava/lang/String;

    iput-object v0, p0, La_4338C751;->d:Ljava/lang/String;

    .line 10
    iget-object v0, p1, La_512AB34F;->g:Leg;

    iput-object v0, p0, La_4338C751;->e:Leg;

    .line 11
    iget-object v0, p1, La_512AB34F;->h:Ljg;

    invoke-virtual {v0}, Ljg;->c()La_FAB612EB;

    move-result-object v0

    iput-object v0, p0, La_4338C751;->f:La_FAB612EB;

    .line 12
    iget-object v0, p1, La_512AB34F;->i:Ldq;

    iput-object v0, p0, La_4338C751;->g:Ldq;

    .line 13
    iget-object v0, p1, La_512AB34F;->j:La_512AB34F;

    iput-object v0, p0, La_4338C751;->h:La_512AB34F;

    .line 14
    iget-object v0, p1, La_512AB34F;->k:La_512AB34F;

    iput-object v0, p0, La_4338C751;->i:La_512AB34F;

    .line 15
    iget-object v0, p1, La_512AB34F;->l:La_512AB34F;

    iput-object v0, p0, La_4338C751;->j:La_512AB34F;

    .line 16
    iget-wide v0, p1, La_512AB34F;->m:J

    iput-wide v0, p0, La_4338C751;->k:J

    .line 17
    iget-wide v0, p1, La_512AB34F;->n:J

    iput-wide v0, p0, La_4338C751;->l:J

    return-void
.end method

.method public static b(Ljava/lang/String;La_512AB34F;)V
    .locals 1

    .line 1
    iget-object v0, p1, La_512AB34F;->i:Ldq;

    .line 3
    if-nez v0, :cond_3

    .line 5
    iget-object v0, p1, La_512AB34F;->j:La_512AB34F;

    .line 7
    if-nez v0, :cond_2

    .line 9
    iget-object v0, p1, La_512AB34F;->k:La_512AB34F;

    .line 11
    if-nez v0, :cond_1

    .line 13
    iget-object p1, p1, La_512AB34F;->l:La_512AB34F;

    .line 15
    if-nez p1, :cond_0
    # ep-fjatfnljrurn

    .line 17
    return-void

    .line 18
    :cond_0
    # ep-uehgibacuwbx
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 20
    const-string v0, ".priorResponse != null"

    .line 22
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 25
    move-result-object p0

    .line 26
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 29
    throw p1

    .line 30
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 32
    const-string v0, ".cacheResponse != null"

    .line 34
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 37
    move-result-object p0

    .line 38
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 41
    throw p1

    .line 42
    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 44
    const-string v0, ".networkResponse != null"

    .line 46
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 49
    move-result-object p0

    .line 50
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 53
    throw p1

    .line 54
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 56
    const-string v0, ".body != null"

    .line 58
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 61
    move-result-object p0

    .line 62
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 65
    throw p1
.end method


# virtual methods
.method public final a()La_512AB34F;
    .locals 3

    .line 1
    iget-object v0, p0, La_4338C751;->a:Lnp;

    .line 3
    if-eqz v0, :cond_2

    .line 5
    iget-object v0, p0, La_4338C751;->b:Lvo;

    # ep-oulxsycrguvi
    .line 7
    if-eqz v0, :cond_1

    .line 9
    iget v0, p0, La_4338C751;->c:I

    .line 11
    if-ltz v0, :cond_0

    .line 13
    new-instance v0, La_512AB34F;

    .line 15
    invoke-direct {v0, p0}, La_512AB34F;-><init>(La_4338C751;)V

    .line 18
    # ep-mccropjklflj
    return-object v0

    .line 19
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 21
    new-instance v1, Ljava/lang/StringBuilder;

    .line 23
    const-string v2, "code < 0: "

    .line 25
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 28
    iget v2, p0, La_4338C751;->c:I

    # ep-mwumpwtizsaw
    .line 30
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 33
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 36
    move-result-object v1

    .line 37
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 40
    throw v0

    .line 41
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 43
    const-string v1, "protocol == null"

    .line 45
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 48
    throw v0

    .line 49
    :cond_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 51
    const-string v1, "request == null"

    .line 53
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 56
    throw v0
.end method
