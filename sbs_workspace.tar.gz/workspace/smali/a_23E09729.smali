.class public final La_23E09729;
.super Ljava/lang/Object;
# processed-43012
# validated-42545
# optimised-74749
# ep-kcbhzyltjqeh
.source "uuoigilw.java"


# static fields
.field public static final synthetic d:I


# instance fields
.field public final a:La_38A51E97;

.field public final b:Lri;

.field public final c:Ljava/util/HashMap;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "DelayedWorkTracker"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(La_38A51E97;Lri;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_23E09729;->a:La_38A51E97;

    .line 6
    iput-object p2, p0, La_23E09729;->b:Lri;

    .line 8
    new-instance p1, Ljava/util/HashMap;

    .line 10
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 13
    iput-object p1, p0, La_23E09729;->c:Ljava/util/HashMap;

    .line 15
    return-void
.end method
