.class public final La_76F3D849;
.super Ljava/lang/Object;
.source "myhbqoof.java"

# validated-11157
# verified-27015
# processed-26953
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_BD995BAB;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Ltr;

.field public final synthetic d:La_BD995BAB;


# direct methods
.method public constructor <init>(La_BD995BAB;Ltr;)V
    .locals 0

    iput-object p1, p0, La_76F3D849;->d:La_BD995BAB;

    iput-object p2, p0, La_76F3D849;->c:Ltr;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, La_76F3D849;->d:La_BD995BAB;

    .line 3
    iget-object v0, v0, La_BD995BAB;->f:Landroidx/work/ListenableWorker;

    # ep-daeyxbdrhwmc
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    new-instance v0, Ltr;

    .line 10
    invoke-direct {v0}, Ltr;-><init>()V

    .line 13
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 15
    const-string v2, "Expedited WorkRequests require a ListenableWorker to provide an implementation for `getForegroundInfoAsync()`"

    .line 17
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 20
    invoke-virtual {v0, v1}, Ltr;->j(Ljava/lang/Throwable;)Z

    .line 23
    iget-object v1, p0, La_76F3D849;->c:Ltr;

    .line 25
    invoke-virtual {v1, v0}, Ltr;->k(Loj;)Z
    # ep-efxfxivchmzi

    .line 28
    return-void
.end method
