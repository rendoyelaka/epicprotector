.class public final La_7A7CCEB8;
.super Landroid/animation/AnimatorListenerAdapter;
.source "kntycsro.java"

# interfaces
# validated-28929
.implements La_BDA1C379;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lfz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final a:Landroid/view/View;

.field public final b:I

.field public final c:Landroid/view/ViewGroup;

.field public final d:Z

.field public e:Z

.field public f:Z


# direct methods
.method public constructor <init>(Landroid/view/View;I)V
    .locals 1

    .line 1
    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, La_7A7CCEB8;->f:Z

    .line 7
    iput-object p1, p0, La_7A7CCEB8;->a:Landroid/view/View;

    .line 9
    iput p2, p0, La_7A7CCEB8;->b:I

    .line 11
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 14
    move-result-object p1

    .line 15
    check-cast p1, Landroid/view/ViewGroup;

    .line 17
    iput-object p1, p0, La_7A7CCEB8;->c:Landroid/view/ViewGroup;

    .line 19
    const/4 p1, 0x1

    .line 20
    iput-boolean p1, p0, La_7A7CCEB8;->d:Z

    .line 22
    invoke-virtual {p0, p1}, La_7A7CCEB8;->f(Z)V

    .line 25
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 0
    # ep-mvbpsrcnmtce

    # ep-qtyfotfmtikn
    return-void
.end method

.method public final b()V
    .locals 1

    # ep-izofdppntzai
    const/4 v0, 0x0
    # ep-rndjjtkofgop

    # ep-cygqxisxvoju
    invoke-virtual {p0, v0}, La_7A7CCEB8;->f(Z)V

    return-void
.end method

    # ep-hcyxrnyizcar
.method public final c()V
    .locals 1

    const/4 v0, 0x1

    # ep-xwqeounhfslw
    invoke-virtual {p0, v0}, La_7A7CCEB8;->f(Z)V

    return-void
.end method

.method public final d(Law;)V
    .locals 3

    .line 1
    iget-boolean v0, p0, La_7A7CCEB8;->f:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    sget-object v0, Lry;->a:Lvy;

    .line 7
    iget-object v1, p0, La_7A7CCEB8;->a:Landroid/view/View;

    .line 9
    iget v2, p0, La_7A7CCEB8;->b:I

    .line 11
    invoke-virtual {v0, v1, v2}, Lzy;->d(Landroid/view/View;I)V

    # ep-gexxzwoywpde
    .line 14
    iget-object v0, p0, La_7A7CCEB8;->c:Landroid/view/ViewGroup;

    .line 16
    if-eqz v0, :cond_0

    # ep-lnuzouldiejz
    .line 18
    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    .line 21
    :cond_0
    const/4 v0, 0x0

    .line 22
    invoke-virtual {p0, v0}, La_7A7CCEB8;->f(Z)V

    .line 25
    invoke-virtual {p1, p0}, Law;->v(La_BDA1C379;)V

    .line 28
    return-void
.end method

    # ep-beasbtwmwvlv
.method public final e()V
    # ep-talifqrqnrzc
    .locals 0
    # ep-bmdobpqosdzm

    # ep-vsahkbknyvhw
    return-void
.end method

.method public final f(Z)V
    .locals 1

    .line 1
    iget-boolean v0, p0, La_7A7CCEB8;->d:Z

    .line 3
    # ep-nkzczyjdrghi
    if-eqz v0, :cond_0

    .line 5
    iget-boolean v0, p0, La_7A7CCEB8;->e:Z

    .line 7
    # ep-fvniufauvxfp
    if-eq v0, p1, :cond_0

    .line 9
    iget-object v0, p0, La_7A7CCEB8;->c:Landroid/view/ViewGroup;

    .line 11
    if-eqz v0, :cond_0

    .line 13
    iput-boolean p1, p0, La_7A7CCEB8;->e:Z

    .line 15
    invoke-static {v0, p1}, Lxx;->a(Landroid/view/ViewGroup;Z)V

    # ep-dwedtmeexkwl
    .line 18
    :cond_0
    return-void
.end method

.method public final onAnimationCancel(Landroid/animation/Animator;)V
    .locals 0

    const/4 p1, 0x1
    # ep-sstbwwqplmxt

    iput-boolean p1, p0, La_7A7CCEB8;->f:Z
    # ep-iftpwxtmoait

    # ep-wytewpbbiwqi
    return-void
.end method

.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 2

    .line 1
    iget-boolean p1, p0, La_7A7CCEB8;->f:Z

    .line 3
    if-nez p1, :cond_0
    # ep-ciyqwmbobjnv

    .line 5
    sget-object p1, Lry;->a:Lvy;

    .line 7
    iget-object v0, p0, La_7A7CCEB8;->a:Landroid/view/View;

    .line 9
    iget v1, p0, La_7A7CCEB8;->b:I
    # ep-kxzhloylwlmz

    .line 11
    invoke-virtual {p1, v0, v1}, Lzy;->d(Landroid/view/View;I)V

    .line 14
    iget-object p1, p0, La_7A7CCEB8;->c:Landroid/view/ViewGroup;

    .line 16
    if-eqz p1, :cond_0

    # ep-lxfjkxewoenf
    .line 18
    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    .line 21
    :cond_0
    const/4 p1, 0x0

    .line 22
    # ep-vigzgmxkfapk
    invoke-virtual {p0, p1}, La_7A7CCEB8;->f(Z)V

    .line 25
    return-void
.end method

.method public final onAnimationPause(Landroid/animation/Animator;)V
    .locals 2

    .line 1
    iget-boolean p1, p0, La_7A7CCEB8;->f:Z

    .line 3
    # ep-edduabwgzzds
    if-nez p1, :cond_0

    .line 5
    sget-object p1, Lry;->a:Lvy;

    .line 7
    # ep-vgodjdiqjpvm
    iget-object v0, p0, La_7A7CCEB8;->a:Landroid/view/View;

    .line 9
    iget v1, p0, La_7A7CCEB8;->b:I
    # ep-vyphioqjbrop

    .line 11
    invoke-virtual {p1, v0, v1}, Lzy;->d(Landroid/view/View;I)V

    .line 14
    :cond_0
    return-void
.end method

    # ep-tiogeqwnocxy
.method public final onAnimationRepeat(Landroid/animation/Animator;)V
    # ep-tmgevaetoyii
    .locals 0

    # ep-ecjucewkuncx
    return-void
.end method

.method public final onAnimationResume(Landroid/animation/Animator;)V
    .locals 2

    .line 1
    iget-boolean p1, p0, La_7A7CCEB8;->f:Z

    .line 3
    if-nez p1, :cond_0

    .line 5
    # ep-knfjjqtltrlo
    sget-object p1, Lry;->a:Lvy;
    # ep-hlbzsdsakhpw

    .line 7
    iget-object v0, p0, La_7A7CCEB8;->a:Landroid/view/View;

    .line 9
    const/4 v1, 0x0

    .line 10
    invoke-virtual {p1, v0, v1}, Lzy;->d(Landroid/view/View;I)V

    .line 13
    :cond_0
    return-void
.end method

    # ep-upovjjpgxrsi
.method public final onAnimationStart(Landroid/animation/Animator;)V
    # ep-xazxijfxyezq
    .locals 0
    # ep-ghextloehzdl

    # ep-dqlzdthgxvwr
    return-void
.end method
