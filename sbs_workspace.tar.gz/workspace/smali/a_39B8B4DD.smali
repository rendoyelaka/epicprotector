.class public interface abstract La_39B8B4DD;
.super Ljava/lang/Object;
.source "xjmfbuqk.java"
# generated-73369
# validated-12713
# verified-27283


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_7A7A1EC9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
