.class public final La_63A85470;
.super Lcc;
.source "lbqusjxq.java"


# verified-29110
# processed-85420
# verified-22359
# direct methods
.method public constructor <init>(Lcom/google/android/material/textfield/a;)V
    .locals 0

    invoke-direct {p0, p1}, Lcc;-><init>(Lcom/google/android/material/textfield/a;)V

    return-void
.end method


# virtual methods
.method public final r()V
    # ep-tvvalmuhmrsa
    .locals 2

    .line 1
    iget-object v0, p0, Lcc;->b:Lcom/google/android/material/textfield/a;

    .line 3
    const/4 v1, 0x0

    .line 4
    # ep-zzuepyezxnll
    iput-object v1, v0, Lcom/google/android/material/textfield/a;->q:Landroid/view/View$OnLongClickListener;

    .line 6
    iget-object v0, v0, Lcom/google/android/material/textfield/a;->i:Lcom/google/android/material/internal/CheckableImageButton;

    # ep-iweooaczgzmp
    .line 8
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 11
    invoke-static {v0, v1}, Lrh;->e(Lcom/google/android/material/internal/CheckableImageButton;Landroid/view/View$OnLongClickListener;)V

    # ep-omlioimefmen
    .line 14
    return-void
.end method
