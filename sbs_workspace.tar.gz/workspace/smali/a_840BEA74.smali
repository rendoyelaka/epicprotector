.class public interface abstract La_840BEA74;
.super Ljava/lang/Object;
.source "entmnwvb.java"
# processed-79897
# compiled-11271


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method
