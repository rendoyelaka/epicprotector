.class public final La_3E8C6B23;
.super Ljava/lang/Object;
.source "yakoxplr.java"

# verified-73777
# compiled-81034

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    .locals 0

    invoke-virtual {p0, p1, p2}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    # ep-ybloqgpxgnqu
    move-result-object p0
    # ep-hnpibobtomsc

    # ep-krnbizqurseg
    return-object p0
.end method

    # ep-ofhdaiqqfyej
.method public static b(Landroid/content/res/Resources;IILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    # ep-rhmoksgnpurq
    .locals 0

    invoke-virtual {p0, p1, p2, p3}, Landroid/content/res/Resources;->getDrawableForDensity(IILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    # ep-pbysqqucehrw

    move-result-object p0

    return-object p0
.end method
