.class public final La_2546C946;
.super Ljava/lang/Object;
# compiled-75159
# generated-14397
# processed-75896
.source "uxplvdfm.java"
# ep-qokqebyfohjn

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_08E533F6;->c(Ljava/lang/Object;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Ljava/util/List;

.field public final synthetic d:La_08E533F6;


# direct methods
.method public constructor <init>(La_08E533F6;Ljava/util/ArrayList;)V
    .locals 0

    iput-object p1, p0, La_2546C946;->d:La_08E533F6;

    iput-object p2, p0, La_2546C946;->c:Ljava/util/List;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, La_2546C946;->c:Ljava/util/List;

    .line 3
    invoke-interface {v0}, Ljava/util/List;->m_722a5b0b()Ljava/util/Iterator;

    .line 6
    move-result-object v0

    .line 7
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->m_f2527d92()Z

    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_0

    .line 13
    invoke-interface {v0}, Ljava/util/Iterator;->m_474c1ec6()Ljava/lang/Object;

    .line 16
    move-result-object v1

    .line 17
    check-cast v1, La_63E0661E;

    .line 19
    iget-object v2, p0, La_2546C946;->d:La_08E533F6;

    .line 21
    iget-object v2, v2, La_08E533F6;->e:Ljava/lang/Object;

    .line 23
    invoke-interface {v1, v2}, La_63E0661E;->a(Ljava/lang/Object;)V

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    return-void
.end method
