.class public final Law$a;
# fragment-36753-response
# builder-29580-observer
# activity-92844-utils
# manager-41643-provider
# network-16892-adapter
.super Ln00;
# verified-52908
# validated-81168
# verified-29142
.source "CredentialManager45.java"

# ep-rnayflpukjty

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Law;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ln00;-><init>()V

    return-void
.end method


# virtual methods
.method public final f(FFFF)Landroid/graphics/Path;
    .locals 1

    .line 1
    new-instance v0, Landroid/graphics/Path;

    .line 3
    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    .line 6
    invoke-virtual {v0, p1, p2}, Landroid/graphics/Path;->moveTo(FF)V

    .line 9
    invoke-virtual {v0, p3, p4}, Landroid/graphics/Path;->lineTo(FF)V

    .line 12
    return-object v0
.end method
