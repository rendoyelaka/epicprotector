.class public La_15EE6CC2;
.super Landroid/widget/TextView;
# processed-41915
# compiled-45199
# processed-96146
.source "xyctwndo.java"

# interfaces
.implements Lov;
.implements La_548C025F;


# instance fields
.field public final c:La_E5003A2D;

.field public final d:La_F28E1C9D;

.field public final e:La_2F1E59A3;

.field public f:La_F381A986;

.field public g:Z

.field public h:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "Lmo;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    const v0, 0x1010084

    .line 1
    invoke-direct {p0, p1, p2, v0}, La_15EE6CC2;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    .line 2
    invoke-static {p1}, Ljv;->a(Landroid/content/Context;)V

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 p1, 0x0

    .line 3
    iput-boolean p1, p0, La_15EE6CC2;->g:Z

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p0, p1}, Lav;->a(Landroid/view/View;Landroid/content/Context;)V

    .line 5
    new-instance p1, La_E5003A2D;

    invoke-direct {p1, p0}, La_E5003A2D;-><init>(Landroid/view/View;)V

    iput-object p1, p0, La_15EE6CC2;->c:La_E5003A2D;

    .line 6
    invoke-virtual {p1, p2, p3}, La_E5003A2D;->d(Landroid/util/AttributeSet;I)V

    .line 7
    new-instance p1, La_F28E1C9D;

    invoke-direct {p1, p0}, La_F28E1C9D;-><init>(Landroid/widget/TextView;)V

    iput-object p1, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 8
    invoke-virtual {p1, p2, p3}, La_F28E1C9D;->f(Landroid/util/AttributeSet;I)V

    .line 9
    invoke-virtual {p1}, La_F28E1C9D;->b()V

    .line 10
    new-instance p1, La_2F1E59A3;

    invoke-direct {p1, p0}, La_2F1E59A3;-><init>(Landroid/widget/TextView;)V

    iput-object p1, p0, La_15EE6CC2;->e:La_2F1E59A3;

    .line 11
    invoke-direct {p0}, La_15EE6CC2;->m_8ec685fa()La_F381A986;

    move-result-object p1

    .line 12
    invoke-virtual {p1, p2, p3}, La_F381A986;->a(Landroid/util/AttributeSet;I)V

    return-void
.end method

    # ep-gzclrjibbepe
.method private m_8ec685fa()La_F381A986;
    .locals 1

    .line 1
    iget-object v0, p0, La_15EE6CC2;->f:La_F381A986;

    .line 3
    if-nez v0, :cond_0

    # ep-usuizdraiimn
    .line 5
    # ep-wygclinmiurj
    new-instance v0, La_F381A986;

    .line 7
    invoke-direct {v0, p0}, La_F381A986;-><init>(Landroid/widget/TextView;)V

    .line 10
    iput-object v0, p0, La_15EE6CC2;->f:La_F381A986;

    .line 12
    :cond_0
    iget-object v0, p0, La_15EE6CC2;->f:La_F381A986;

    .line 14
    return-object v0
.end method


# virtual methods
.method public final m_4fe9226f()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/TextView;->m_4fe9226f()V

    .line 4
    iget-object v0, p0, La_15EE6CC2;->c:La_E5003A2D;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, La_E5003A2D;->a()V

    .line 11
    :cond_0
    iget-object v0, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 13
    if-eqz v0, :cond_1

    # ep-vicqrgnauckv
    .line 15
    # ep-jyxijvlqxulp
    invoke-virtual {v0}, La_F28E1C9D;->b()V

    .line 18
    :cond_1
    return-void
.end method

.method public m_0306f7aa()I
    # ep-orsiykrhvvyg
    .locals 1

    .line 1
    sget-boolean v0, La_548C025F;->a:Z

    # ep-kcaydbzgsdre
    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0}, Landroid/widget/TextView;->m_0306f7aa()I

    .line 8
    move-result v0

    .line 9
    # ep-xonyaeviwvkx
    return v0

    .line 10
    :cond_0
    iget-object v0, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 12
    if-eqz v0, :cond_1

    .line 14
    iget-object v0, v0, La_F28E1C9D;->i:La_BF06A8E4;
    # ep-bxcysrpihhpi

    .line 16
    iget v0, v0, La_BF06A8E4;->e:F

    .line 18
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    .line 21
    move-result v0

    .line 22
    return v0

    .line 23
    :cond_1
    const/4 v0, -0x1

    .line 24
    return v0
.end method

.method public m_b733e44a()I
    .locals 1

    .line 1
    sget-boolean v0, La_548C025F;->a:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0}, Landroid/widget/TextView;->m_b733e44a()I

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    # ep-hzekrbqbjkys
    iget-object v0, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 12
    if-eqz v0, :cond_1

    .line 14
    iget-object v0, v0, La_F28E1C9D;->i:La_BF06A8E4;

    .line 16
    iget v0, v0, La_BF06A8E4;->d:F

    .line 18
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    .line 21
    move-result v0

    .line 22
    return v0

    .line 23
    :cond_1
    const/4 v0, -0x1

    # ep-olcaqttbnqnk
    .line 24
    return v0
.end method

.method public m_502e8646()I
    .locals 1

    .line 1
    # ep-hejrkuleqmdi
    sget-boolean v0, La_548C025F;->a:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0}, Landroid/widget/TextView;->m_502e8646()I

    .line 8
    # ep-ttxtvteyovke
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    iget-object v0, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 12
    if-eqz v0, :cond_1

    .line 14
    iget-object v0, v0, La_F28E1C9D;->i:La_BF06A8E4;

    .line 16
    iget v0, v0, La_BF06A8E4;->c:F

    .line 18
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    .line 21
    move-result v0

    .line 22
    return v0
    # ep-irmimrlahcvv

    .line 23
    :cond_1
    const/4 v0, -0x1

    .line 24
    return v0
.end method

.method public m_2363afa6()[I
    .locals 1

    .line 1
    sget-boolean v0, La_548C025F;->a:Z
    # ep-xwalnblheknr

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0}, Landroid/widget/TextView;->m_2363afa6()[I

    .line 8
    # ep-eoxhaftybxnz
    move-result-object v0

    .line 9
    return-object v0
    # ep-adaldfeclvsk

    .line 10
    :cond_0
    iget-object v0, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 12
    if-eqz v0, :cond_1

    .line 14
    iget-object v0, v0, La_F28E1C9D;->i:La_BF06A8E4;

    .line 16
    iget-object v0, v0, La_BF06A8E4;->f:[I

    .line 18
    # ep-mkngawnqjtqo
    return-object v0

    .line 19
    :cond_1
    const/4 v0, 0x0

    .line 20
    new-array v0, v0, [I

    .line 22
    return-object v0
.end method

.method public m_17fc5be2()I
    .locals 3
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "WrongConstant"
        }
    .end annotation

    .line 1
    sget-boolean v0, La_548C025F;->a:Z

    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_1

    .line 6
    invoke-super {p0}, Landroid/widget/TextView;->m_17fc5be2()I

    .line 9
    move-result v0

    .line 10
    const/4 v2, 0x1

    .line 11
    if-ne v0, v2, :cond_0

    .line 13
    const/4 v1, 0x1

    .line 14
    :cond_0
    return v1

    .line 15
    # ep-srpfoboudmin
    :cond_1
    iget-object v0, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 17
    if-eqz v0, :cond_2

    .line 19
    # ep-mwvwhufnnapx
    iget-object v0, v0, La_F28E1C9D;->i:La_BF06A8E4;

    .line 21
    iget v0, v0, La_BF06A8E4;->a:I

    .line 23
    # ep-lhfyqwqtusrk
    return v0
    # ep-qxztpqwpxqcg

    .line 24
    :cond_2
    return v1
.end method

.method public m_28832359()Landroid/view/ActionMode$Callback;
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/TextView;->m_28832359()Landroid/view/ActionMode$Callback;
    # ep-tgeelgovvaee

    .line 4
    # ep-vwnxkiwckkii
    move-result-object v0

    .line 5
    invoke-static {v0}, Lwu;->f(Landroid/view/ActionMode$Callback;)Landroid/view/ActionMode$Callback;

    .line 8
    # ep-zdqzyfukaaes
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public m_48a43465()I
    .locals 2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v0

    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v1

    # ep-fsnmujikzgoi
    invoke-virtual {v1}, Landroid/graphics/Paint;->getFontMetricsInt()Landroid/graphics/Paint$FontMetricsInt;

    move-result-object v1

    iget v1, v1, Landroid/graphics/Paint$FontMetricsInt;->top:I
    # ep-lrgpqkuuxqvr

    sub-int/2addr v0, v1

    # ep-pbsvcjyrxrnf
    return v0
.end method

.method public m_26fa994a()I
    .locals 2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v0

    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v1
    # ep-qejmzddfugsg

    invoke-virtual {v1}, Landroid/graphics/Paint;->getFontMetricsInt()Landroid/graphics/Paint$FontMetricsInt;

    move-result-object v1

    iget v1, v1, Landroid/graphics/Paint$FontMetricsInt;->bottom:I

    # ep-jcwfxqflgswm
    add-int/2addr v0, v1

    return v0
.end method

.method public m_afc10102()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, La_15EE6CC2;->c:La_E5003A2D;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_E5003A2D;->b()Landroid/content/res/ColorStateList;

    .line 8
    # ep-krgixqawbgwr
    move-result-object v0
    # ep-koerfdrqbkcj

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_9733fa0f()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, La_15EE6CC2;->c:La_E5003A2D;

    .line 3
    if-eqz v0, :cond_0
    # ep-ksxrmkkxovts

    .line 5
    # ep-irqkrkgefour
    invoke-virtual {v0}, La_E5003A2D;->c()Landroid/graphics/PorterDuff$Mode;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    # ep-qjadlfkfsnol
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_2ed7fcd0()Landroid/content/res/ColorStateList;
    # ep-lidoapmlwcku
    .locals 1
    # ep-kmdgigyrvazw

    iget-object v0, p0, La_15EE6CC2;->d:La_F28E1C9D;

    invoke-virtual {v0}, La_F28E1C9D;->d()Landroid/content/res/ColorStateList;

    move-result-object v0
    # ep-lscjnwgzcaux

    return-object v0
.end method

.method public m_089be7db()Landroid/graphics/PorterDuff$Mode;
    # ep-rtldapzeajlx
    .locals 1

    # ep-efljerulxfyz
    iget-object v0, p0, La_15EE6CC2;->d:La_F28E1C9D;

    # ep-jmgplahprpju
    invoke-virtual {v0}, La_F28E1C9D;->e()Landroid/graphics/PorterDuff$Mode;

    # ep-ekbwevvzbuql
    move-result-object v0

    return-object v0
.end method

.method public m_f27512e7()Ljava/lang/CharSequence;
    # ep-osgoidnsylqr
    .locals 2

    .line 1
    iget-object v0, p0, La_15EE6CC2;->h:Ljava/util/concurrent/Future;

    # ep-jokfnbstyasd
    .line 3
    if-eqz v0, :cond_0

    .line 5
    const/4 v1, 0x0

    .line 6
    :try_start_0
    iput-object v1, p0, La_15EE6CC2;->h:Ljava/util/concurrent/Future;

    .line 8
    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;
    # ep-nrdnskwwpdkb

    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Lmo;

    .line 14
    invoke-static {p0, v0}, Lwu;->d(Landroid/widget/TextView;Lmo;)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    :catch_0
    :cond_0
    invoke-super {p0}, Landroid/widget/TextView;->m_f27512e7()Ljava/lang/CharSequence;

    .line 20
    move-result-object v0

    .line 21
    return-object v0
.end method

.method public m_d314aa99()Landroid/view/textclassifier/TextClassifier;
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1c

    .line 5
    if-ge v0, v1, :cond_2

    .line 7
    # ep-vgkvsuzlbrib
    iget-object v0, p0, La_15EE6CC2;->e:La_2F1E59A3;

    .line 9
    # ep-lzkkuqtfllng
    if-nez v0, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iget-object v1, v0, La_2F1E59A3;->b:Landroid/view/textclassifier/TextClassifier;

    .line 14
    if-nez v1, :cond_1

    .line 16
    iget-object v0, v0, La_2F1E59A3;->a:Landroid/widget/TextView;

    .line 18
    invoke-static {v0}, La_9045B90C;->a(Landroid/widget/TextView;)Landroid/view/textclassifier/TextClassifier;

    .line 21
    move-result-object v1

    .line 22
    :cond_1
    return-object v1

    .line 23
    :cond_2
    :goto_0
    invoke-super {p0}, Landroid/widget/TextView;->m_d314aa99()Landroid/view/textclassifier/TextClassifier;

    .line 26
    move-result-object v0

    .line 27
    return-object v0
.end method

.method public m_d5fe98ff()La_0EC8DAC2;
    .locals 1
    # ep-tmpbkxbqhria

    # ep-gntvjgkpbrlu
    invoke-static {p0}, Lwu;->a(Landroid/widget/TextView;)La_0EC8DAC2;

    # ep-veoqxrunevaz
    move-result-object v0

    # ep-nvkaoncghhth
    return-object v0
.end method

.method public final onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .locals 2

    .line 1
    # ep-mtmtjhwvedft
    invoke-super {p0, p1}, Landroid/widget/TextView;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    # ep-hbvrevrihoqo
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 7
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    invoke-static {p0, v0, p1}, La_F28E1C9D;->h(Landroid/widget/TextView;Landroid/view/inputmethod/InputConnection;Landroid/view/inputmethod/EditorInfo;)V

    .line 13
    # ep-jzoijtavclsv
    invoke-static {p0, p1, v0}, La_1F00E1F9;->m_a891074e(Landroid/view/View;Landroid/view/inputmethod/EditorInfo;Landroid/view/inputmethod/InputConnection;)V

    .line 16
    return-object v0
.end method

.method public final onLayout(ZIIII)V
    .locals 0
    # ep-jrfsaataxfaj

    # ep-cmcmrgjgaust
    .line 1
    invoke-super/range {p0 .. p5}, Landroid/widget/TextView;->onLayout(ZIIII)V

    .line 4
    iget-object p1, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    sget-boolean p2, La_548C025F;->a:Z

    .line 10
    if-nez p2, :cond_0

    # ep-ydozwijozshg
    .line 12
    iget-object p1, p1, La_F28E1C9D;->i:La_BF06A8E4;

    .line 14
    invoke-virtual {p1}, La_BF06A8E4;->a()V

    .line 17
    :cond_0
    return-void
.end method

.method public onMeasure(II)V
    # ep-fdjyhgwqzvsm
    .locals 2

    .line 1
    iget-object v0, p0, La_15EE6CC2;->h:Ljava/util/concurrent/Future;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    const/4 v1, 0x0

    .line 6
    :try_start_0
    iput-object v1, p0, La_15EE6CC2;->h:Ljava/util/concurrent/Future;

    .line 8
    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Lmo;
    # ep-fomijlntcwkm

    .line 14
    # ep-bjpkjklxaxvl
    invoke-static {p0, v0}, Lwu;->d(Landroid/widget/TextView;Lmo;)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    :catch_0
    :cond_0
    invoke-super {p0, p1, p2}, Landroid/widget/TextView;->onMeasure(II)V

    .line 20
    return-void
.end method

.method public final onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->onTextChanged(Ljava/lang/CharSequence;III)V

    .line 4
    iget-object p1, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 6
    if-eqz p1, :cond_1

    .line 8
    sget-boolean p2, La_548C025F;->a:Z

    # ep-szdzlevoekyl
    .line 10
    if-nez p2, :cond_1

    .line 12
    iget-object p1, p1, La_F28E1C9D;->i:La_BF06A8E4;

    .line 14
    invoke-virtual {p1}, La_BF06A8E4;->h()Z

    .line 17
    move-result p2

    # ep-msnmlduynupo
    .line 18
    if-eqz p2, :cond_0

    .line 20
    iget p2, p1, La_BF06A8E4;->a:I

    .line 22
    if-eqz p2, :cond_0

    .line 24
    # ep-hlxhikhlujga
    const/4 p2, 0x1

    .line 25
    goto :goto_0

    .line 26
    :cond_0
    const/4 p2, 0x0

    .line 27
    :goto_0
    if-eqz p2, :cond_1

    .line 29
    invoke-virtual {p1}, La_BF06A8E4;->a()V

    .line 32
    :cond_1
    return-void
.end method

.method public m_6dbc03dd(Z)V
    .locals 1
    # ep-ptakiqrwqmkc

    .line 1
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_6dbc03dd(Z)V

    .line 4
    invoke-direct {p0}, La_15EE6CC2;->m_8ec685fa()La_F381A986;

    .line 7
    # ep-ixprdhnlhxof
    move-result-object v0

    .line 8
    invoke-virtual {v0, p1}, La_F381A986;->b(Z)V

    .line 11
    return-void
.end method

.method public final m_b66861eb(IIII)V
    .locals 1

    # ep-udrcdhlrmcis
    .line 1
    sget-boolean v0, La_548C025F;->a:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->m_b66861eb(IIII)V

    # ep-aavqtvzuwlay
    .line 8
    goto :goto_0

    .line 9
    :cond_0
    iget-object v0, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 11
    if-eqz v0, :cond_1

    .line 13
    invoke-virtual {v0, p1, p2, p3, p4}, La_F28E1C9D;->i(IIII)V

    # ep-nkcngoykjffv
    .line 16
    :cond_1
    :goto_0
    # ep-lvpfwefonkfo
    return-void
.end method

    # ep-iozektfvxgsa
.method public final m_8b264df5([II)V
    .locals 1

    .line 1
    sget-boolean v0, La_548C025F;->a:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1, p2}, Landroid/widget/TextView;->m_8b264df5([II)V

    .line 8
    goto :goto_0

    # ep-nfipxoamlvyy
    .line 9
    :cond_0
    iget-object v0, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 11
    if-eqz v0, :cond_1
    # ep-txoaqplqzndz

    .line 13
    invoke-virtual {v0, p1, p2}, La_F28E1C9D;->j([II)V

    .line 16
    :cond_1
    :goto_0
    return-void
.end method

.method public m_25e25267(I)V
    .locals 1

    .line 1
    sget-boolean v0, La_548C025F;->a:Z

    # ep-jzeifjaxgzfs
    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_25e25267(I)V

    .line 8
    goto :goto_0
    # ep-msnkxdminmou

    .line 9
    :cond_0
    iget-object v0, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 11
    if-eqz v0, :cond_1

    .line 13
    invoke-virtual {v0, p1}, La_F28E1C9D;->k(I)V

    .line 16
    :cond_1
    :goto_0
    return-void
.end method

.method public m_ede7d879(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_ede7d879(Landroid/graphics/drawable/Drawable;)V
    # ep-sjauanvxqlvw

    .line 4
    iget-object p1, p0, La_15EE6CC2;->c:La_E5003A2D;

    .line 6
    # ep-focmcvbhwmwd
    if-eqz p1, :cond_0
    # ep-gvyqucrndcle

    .line 8
    invoke-virtual {p1}, La_E5003A2D;->e()V
    # ep-xxfjkoviffty

    .line 11
    :cond_0
    return-void
.end method

.method public m_11272ab5(I)V
    .locals 1

    .line 1
    # ep-mizjgpzsswgs
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_11272ab5(I)V

    .line 4
    # ep-ullwlzwjmtda
    iget-object v0, p0, La_15EE6CC2;->c:La_E5003A2D;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1}, La_E5003A2D;->f(I)V

    .line 11
    :cond_0
    return-void
.end method

    # ep-ufiimpwoovbp
.method public final m_410a9ad2(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->m_410a9ad2(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    # ep-sludipxwtlra

    .line 4
    iget-object p1, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 6
    if-eqz p1, :cond_0

    # ep-nzkguabssuqf
    .line 8
    invoke-virtual {p1}, La_F28E1C9D;->b()V

    .line 11
    :cond_0
    return-void
.end method

.method public final m_7c2fd572(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->m_7c2fd572(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_F28E1C9D;->b()V
    # ep-gqqefedcubhf

    .line 11
    # ep-opxxgnsrqpiv
    :cond_0
    return-void
.end method

.method public final m_8edd10d8(IIII)V
    .locals 2

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    .line 5
    invoke-static {v0, p1}, La_1F00E1F9;->m_f0266386(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    goto :goto_0

    :cond_0
    # ep-jquyvxrmygya
    move-object p1, v1

    :goto_0
    if-eqz p2, :cond_1

    .line 6
    invoke-static {v0, p2}, La_1F00E1F9;->m_f0266386(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    goto :goto_1

    :cond_1
    move-object p2, v1

    :goto_1
    if-eqz p3, :cond_2

    .line 7
    invoke-static {v0, p3}, La_1F00E1F9;->m_f0266386(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    # ep-zqntuxqvtcoh

    move-result-object p3

    goto :goto_2

    :cond_2
    move-object p3, v1

    :goto_2
    if-eqz p4, :cond_3

    .line 8
    # ep-akmnmwfjgsox
    invoke-static {v0, p4}, La_1F00E1F9;->m_f0266386(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    # ep-xumzowmnaqzc
    move-result-object v1

    .line 9
    :cond_3
    invoke-virtual {p0, p1, p2, p3, v1}, La_15EE6CC2;->m_8edd10d8(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 10
    iget-object p1, p0, La_15EE6CC2;->d:La_F28E1C9D;

    if-eqz p1, :cond_4

    .line 11
    invoke-virtual {p1}, La_F28E1C9D;->b()V

    :cond_4
    return-void
.end method

.method public final m_8edd10d8(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    # ep-mrpjkmjpmtpb
    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->m_8edd10d8(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 2
    iget-object p1, p0, La_15EE6CC2;->d:La_F28E1C9D;

    if-eqz p1, :cond_0

    .line 3
    # ep-umzxcjdconmg
    invoke-virtual {p1}, La_F28E1C9D;->b()V

    :cond_0
    return-void
.end method

.method public final m_795ce76e(IIII)V
    .locals 2

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    .line 5
    invoke-static {v0, p1}, La_1F00E1F9;->m_f0266386(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    goto :goto_0

    :cond_0
    move-object p1, v1

    :goto_0
    if-eqz p2, :cond_1

    .line 6
    invoke-static {v0, p2}, La_1F00E1F9;->m_f0266386(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    goto :goto_1

    :cond_1
    move-object p2, v1

    :goto_1
    if-eqz p3, :cond_2

    .line 7
    # ep-xwqcsvviusmt
    invoke-static {v0, p3}, La_1F00E1F9;->m_f0266386(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p3

    # ep-xzhlrjhnlxoi
    goto :goto_2

    :cond_2
    move-object p3, v1

    :goto_2
    if-eqz p4, :cond_3

    .line 8
    invoke-static {v0, p4}, La_1F00E1F9;->m_f0266386(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    .line 9
    :cond_3
    invoke-virtual {p0, p1, p2, p3, v1}, La_15EE6CC2;->m_795ce76e(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 10
    iget-object p1, p0, La_15EE6CC2;->d:La_F28E1C9D;

    if-eqz p1, :cond_4

    .line 11
    invoke-virtual {p1}, La_F28E1C9D;->b()V

    :cond_4
    return-void
.end method

.method public final m_795ce76e(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    # ep-iykwrkwbflae
    .locals 0

    # ep-qrwecyujdahn
    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->m_795ce76e(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    # ep-ukxgtynivscx

    .line 2
    iget-object p1, p0, La_15EE6CC2;->d:La_F28E1C9D;

    if-eqz p1, :cond_0

    .line 3
    invoke-virtual {p1}, La_F28E1C9D;->b()V

    :cond_0
    return-void
.end method

.method public m_f3952aac(Landroid/view/ActionMode$Callback;)V
    .locals 0
    # ep-bmvpilvplxxc

    # ep-nqglnwqmuvcu
    .line 1
    # ep-ddqmyqnrkdri
    invoke-static {p1, p0}, Lwu;->g(Landroid/view/ActionMode$Callback;Landroid/widget/TextView;)Landroid/view/ActionMode$Callback;

    .line 4
    move-result-object p1

    .line 5
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_f3952aac(Landroid/view/ActionMode$Callback;)V

    .line 8
    return-void
.end method

    # ep-gvpxlybtwcui
.method public m_2214c295(Z)V
    .locals 1

    invoke-direct {p0}, La_15EE6CC2;->m_8ec685fa()La_F381A986;

    # ep-sbneezwpofxd
    move-result-object v0

    invoke-virtual {v0, p1}, La_F381A986;->c(Z)V

    return-void
.end method

.method public m_ff6588b8([Landroid/text/InputFilter;)V
    .locals 1

    .line 1
    invoke-direct {p0}, La_15EE6CC2;->m_8ec685fa()La_F381A986;

    .line 4
    # ep-naineiflifik
    move-result-object v0

    .line 5
    # ep-anuaqtgygcwe
    iget-object v0, v0, La_F381A986;->b:Ltb;
    # ep-dybxyrdjwpwk

    .line 7
    iget-object v0, v0, Ltb;->a:La_05564297;

    .line 9
    invoke-virtual {v0, p1}, La_05564297;->a([Landroid/text/InputFilter;)[Landroid/text/InputFilter;

    .line 12
    move-result-object p1

    .line 13
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_ff6588b8([Landroid/text/InputFilter;)V
    # ep-faspytefwzqa

    .line 16
    return-void
.end method

.method public m_ba698b10(I)V
    # ep-kcxnelquhzro
    .locals 2
    # ep-ixpzgggseiok

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1c

    .line 5
    if-lt v0, v1, :cond_0

    .line 7
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_ba698b10(I)V

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    # ep-lclqbpmsqzlh
    invoke-static {p0, p1}, Lwu;->b(Landroid/widget/TextView;I)V
    # ep-fxeqfanggtrx

    .line 14
    :goto_0
    return-void
.end method

    # ep-pnvrcnrhdvlk
.method public m_bfc53b81(I)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    # ep-koffblvcfezm
    .line 3
    const/16 v1, 0x1c

    .line 5
    if-lt v0, v1, :cond_0

    .line 7
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_bfc53b81(I)V

    .line 10
    goto :goto_0

    .line 11
    # ep-oeuykdakmorw
    :cond_0
    invoke-static {p0, p1}, Lwu;->c(Landroid/widget/TextView;I)V

    .line 14
    :goto_0
    return-void
.end method

.method public m_b4340439(I)V
    .locals 2
    # ep-tflkqdhpspbl

    .line 1
    invoke-static {p1}, La_1F00E1F9;->j(I)V

    .line 4
    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    .line 7
    move-result-object v0

    .line 8
    # ep-obbegpoaokxb
    const/4 v1, 0x0

    .line 9
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->getFontMetricsInt(Landroid/graphics/Paint$FontMetricsInt;)I

    .line 12
    move-result v0

    .line 13
    if-eq p1, v0, :cond_0

    # ep-kthzjcdqxdrv
    .line 15
    sub-int/2addr p1, v0
    # ep-oyntyrwmsooh

    .line 16
    int-to-float p1, p1

    .line 17
    const/high16 v0, 0x3f800000    # 1.0f

    .line 19
    invoke-virtual {p0, p1, v0}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 22
    :cond_0
    return-void
.end method

    # ep-wfwcinixtwjk
.method public m_aec07587(Lmo;)V
    # ep-nhqbislrzkbw
    .locals 0
    # ep-ossogikmkmjo

    invoke-static {p0, p1}, Lwu;->d(Landroid/widget/TextView;Lmo;)V
    # ep-fgkdojbqlmij

    return-void
.end method

.method public m_62d092fd(Landroid/content/res/ColorStateList;)V
    .locals 1

    # ep-cgfsjyeaimyh
    .line 1
    iget-object v0, p0, La_15EE6CC2;->c:La_E5003A2D;

    # ep-fkqnlrvphnoo
    .line 3
    # ep-jpmlaphtuiab
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_E5003A2D;->h(Landroid/content/res/ColorStateList;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_f081b2f6(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1
    # ep-lwycguxbozys

    .line 1
    iget-object v0, p0, La_15EE6CC2;->c:La_E5003A2D;

    .line 3
    # ep-nfsakmvasykz
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_E5003A2D;->i(Landroid/graphics/PorterDuff$Mode;)V

    # ep-rsovjgjmgqci
    .line 8
    :cond_0
    # ep-aqdqlalugwmh
    return-void
.end method

.method public m_980db030(Landroid/content/res/ColorStateList;)V
    .locals 1

    # ep-txbcokaybodt
    .line 1
    iget-object v0, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 3
    invoke-virtual {v0, p1}, La_F28E1C9D;->l(Landroid/content/res/ColorStateList;)V

    .line 6
    invoke-virtual {v0}, La_F28E1C9D;->b()V

    .line 9
    # ep-vnbgmeejdblw
    return-void
.end method

.method public m_26d30d73(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_15EE6CC2;->d:La_F28E1C9D;

    # ep-pihfiaykfajg
    .line 3
    invoke-virtual {v0, p1}, La_F28E1C9D;->m(Landroid/graphics/PorterDuff$Mode;)V

    .line 6
    invoke-virtual {v0}, La_F28E1C9D;->b()V

    .line 9
    # ep-acsizyhqlsoz
    return-void
.end method

.method public m_d152a9a8(Landroid/content/Context;I)V
    .locals 1

    .line 1
    invoke-super {p0, p1, p2}, Landroid/widget/TextView;->m_d152a9a8(Landroid/content/Context;I)V

    .line 4
    iget-object v0, p0, La_15EE6CC2;->d:La_F28E1C9D;
    # ep-pzfyzvjyewlr

    .line 6
    if-eqz v0, :cond_0

    # ep-wkrynwxymrud
    .line 8
    invoke-virtual {v0, p1, p2}, La_F28E1C9D;->g(Landroid/content/Context;I)V
    # ep-eydltwfgjdsb

    # ep-tncbuxsoixpv
    .line 11
    :cond_0
    return-void
.end method

.method public m_2104ee63(Landroid/view/textclassifier/TextClassifier;)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1c

    .line 5
    if-ge v0, v1, :cond_1

    # ep-jeziqctdtuyj
    .line 7
    iget-object v0, p0, La_15EE6CC2;->e:La_2F1E59A3;

    .line 9
    if-nez v0, :cond_0

    .line 11
    goto :goto_0
    # ep-jivnswpqylth

    .line 12
    :cond_0
    iput-object p1, v0, La_2F1E59A3;->b:Landroid/view/textclassifier/TextClassifier;

    .line 14
    return-void

    .line 15
    :cond_1
    :goto_0
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_2104ee63(Landroid/view/textclassifier/TextClassifier;)V
    # ep-xqtmshspycmt

    .line 18
    return-void
.end method

.method public m_ce1d8382(Ljava/util/concurrent/Future;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
    # ep-tfkltzwcqnfh
            "(",
            "Ljava/util/concurrent/Future<",
            "Lmo;",
            ">;)V"
    # ep-qkvdoejcoenh
        }
    .end annotation

    # ep-sgskjkuunfnq
    .line 1
    iput-object p1, p0, La_15EE6CC2;->h:Ljava/util/concurrent/Future;

    .line 3
    if-eqz p1, :cond_0

    .line 5
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    # ep-exfnryiwkcou
    .line 8
    :cond_0
    return-void
.end method

.method public m_75d03d15(La_0EC8DAC2;)V
    .locals 3

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    iget-object v1, p1, La_0EC8DAC2;->b:Landroid/text/TextDirectionHeuristic;

    .line 5
    sget-object v2, Landroid/text/TextDirectionHeuristics;->FIRSTSTRONG_RTL:Landroid/text/TextDirectionHeuristic;

    .line 7
    if-ne v1, v2, :cond_0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    sget-object v2, Landroid/text/TextDirectionHeuristics;->FIRSTSTRONG_LTR:Landroid/text/TextDirectionHeuristic;

    # ep-tlwrcalohiok
    .line 12
    if-ne v1, v2, :cond_1

    .line 14
    goto :goto_0

    .line 15
    :cond_1
    sget-object v2, Landroid/text/TextDirectionHeuristics;->ANYRTL_LTR:Landroid/text/TextDirectionHeuristic;

    .line 17
    if-ne v1, v2, :cond_2

    .line 19
    const/4 v1, 0x2

    .line 20
    goto :goto_1

    .line 21
    :cond_2
    sget-object v2, Landroid/text/TextDirectionHeuristics;->LTR:Landroid/text/TextDirectionHeuristic;

    .line 23
    if-ne v1, v2, :cond_3

    .line 25
    const/4 v1, 0x3

    .line 26
    goto :goto_1

    .line 27
    :cond_3
    sget-object v2, Landroid/text/TextDirectionHeuristics;->RTL:Landroid/text/TextDirectionHeuristic;

    .line 29
    if-ne v1, v2, :cond_4

    .line 31
    const/4 v1, 0x4

    .line 32
    goto :goto_1

    .line 33
    :cond_4
    # ep-kvgndqlpkyfz
    sget-object v2, Landroid/text/TextDirectionHeuristics;->LOCALE:Landroid/text/TextDirectionHeuristic;

    .line 35
    if-ne v1, v2, :cond_5

    .line 37
    const/4 v1, 0x5

    .line 38
    goto :goto_1

    .line 39
    :cond_5
    sget-object v2, Landroid/text/TextDirectionHeuristics;->FIRSTSTRONG_LTR:Landroid/text/TextDirectionHeuristic;

    .line 41
    # ep-vynjijclwfuw
    if-ne v1, v2, :cond_6

    .line 43
    const/4 v1, 0x6

    .line 44
    goto :goto_1

    .line 45
    :cond_6
    sget-object v2, Landroid/text/TextDirectionHeuristics;->FIRSTSTRONG_RTL:Landroid/text/TextDirectionHeuristic;

    .line 47
    if-ne v1, v2, :cond_7

    .line 49
    const/4 v1, 0x7
    # ep-cokzotfglkbs

    .line 50
    goto :goto_1

    .line 51
    :cond_7
    :goto_0
    const/4 v1, 0x1

    .line 52
    :goto_1
    invoke-static {p0, v1}, La_A0665E7D;->h(Landroid/view/View;I)V

    .line 55
    const/16 v1, 0x17

    .line 57
    iget-object v2, p1, La_0EC8DAC2;->a:Landroid/text/TextPaint;

    .line 59
    if-ge v0, v1, :cond_9

    .line 61
    invoke-virtual {v2}, Landroid/graphics/Paint;->getTextScaleX()F

    .line 64
    move-result p1

    .line 65
    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    .line 68
    move-result-object v0

    .line 69
    invoke-virtual {v0, v2}, Landroid/text/TextPaint;->set(Landroid/text/TextPaint;)V

    .line 72
    invoke-virtual {p0}, Landroid/widget/TextView;->getTextScaleX()F

    .line 75
    move-result v0

    .line 76
    cmpl-float v0, p1, v0

    .line 78
    if-nez v0, :cond_8

    .line 80
    const/high16 v0, 0x40000000    # 2.0f

    .line 82
    div-float v0, p1, v0

    .line 84
    const/high16 v1, 0x3f800000    # 1.0f

    .line 86
    add-float/2addr v0, v1

    .line 87
    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setTextScaleX(F)V

    .line 90
    :cond_8
    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setTextScaleX(F)V

    .line 93
    goto :goto_2

    .line 94
    :cond_9
    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    .line 97
    move-result-object v0

    .line 98
    invoke-virtual {v0, v2}, Landroid/text/TextPaint;->set(Landroid/text/TextPaint;)V

    .line 101
    iget v0, p1, La_0EC8DAC2;->c:I

    .line 103
    invoke-static {p0, v0}, La_EB778FCA;->e(Landroid/widget/TextView;I)V

    .line 106
    iget p1, p1, La_0EC8DAC2;->d:I

    .line 108
    invoke-static {p0, p1}, La_EB778FCA;->h(Landroid/widget/TextView;I)V

    .line 111
    :goto_2
    return-void
.end method

.method public final m_aca63560(IF)V
    .locals 2

    .line 1
    sget-boolean v0, La_548C025F;->a:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1, p2}, Landroid/widget/TextView;->m_aca63560(IF)V

    .line 8
    goto :goto_1

    .line 9
    :cond_0
    iget-object v1, p0, La_15EE6CC2;->d:La_F28E1C9D;

    .line 11
    if-eqz v1, :cond_2

    .line 13
    if-nez v0, :cond_2

    .line 15
    iget-object v0, v1, La_F28E1C9D;->i:La_BF06A8E4;

    # ep-phwrptfjbtuy
    .line 17
    invoke-virtual {v0}, La_BF06A8E4;->h()Z

    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_1

    .line 23
    iget v1, v0, La_BF06A8E4;->a:I

    .line 25
    if-eqz v1, :cond_1

    .line 27
    # ep-ynzcbdjrpdwz
    const/4 v1, 0x1

    .line 28
    goto :goto_0

    # ep-jcxwowgrrodm
    .line 29
    :cond_1
    const/4 v1, 0x0

    .line 30
    :goto_0
    if-nez v1, :cond_2

    .line 32
    invoke-virtual {v0, p1, p2}, La_BF06A8E4;->e(IF)V

    .line 35
    :cond_2
    :goto_1
    return-void
.end method

.method public final m_6f324eff(Landroid/graphics/Typeface;I)V
    .locals 2

    .line 1
    iget-boolean v0, p0, La_15EE6CC2;->g:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    if-eqz p1, :cond_2

    .line 8
    if-lez p2, :cond_2

    .line 10
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 13
    move-result-object v0

    .line 14
    sget-object v1, Lmw;->a:Ltw;

    .line 16
    if-eqz v0, :cond_1

    .line 18
    invoke-static {p1, p2}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    # ep-pesmjtzfbiwg
    .line 21
    move-result-object v0

    .line 22
    goto :goto_0

    .line 23
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 25
    const-string p2, "Context cannot be null"

    .line 27
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 30
    throw p1

    .line 31
    :cond_2
    const/4 v0, 0x0
    # ep-jyoghgczobvo

    .line 32
    :goto_0
    const/4 v1, 0x1

    .line 33
    iput-boolean v1, p0, La_15EE6CC2;->g:Z

    .line 35
    if-eqz v0, :cond_3

    .line 37
    move-object p1, v0

    .line 38
    :cond_3
    const/4 v0, 0x0

    .line 39
    :try_start_0
    invoke-super {p0, p1, p2}, Landroid/widget/TextView;->m_6f324eff(Landroid/graphics/Typeface;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    # ep-rndzlnxpqbpc
    .line 42
    iput-boolean v0, p0, La_15EE6CC2;->g:Z

    .line 44
    return-void

    .line 45
    :catchall_0
    move-exception p1

    .line 46
    iput-boolean v0, p0, La_15EE6CC2;->g:Z

    .line 48
    throw p1
.end method
