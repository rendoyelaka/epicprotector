.class public final synthetic La_4A8E7198;
# ep-rxnajtihldky
# generated-68254
.super Ljava/lang/Object;
.source "uciagkzz.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:I

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    iput p1, p0, La_4A8E7198;->c:I

    iput-object p2, p0, La_4A8E7198;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    .line 1
    iget v0, p0, La_4A8E7198;->c:I

    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    packed-switch v0, :pswitch_data_0

    .line 8
    :pswitch_0
    goto/16 :goto_3

    .line 10
    :pswitch_1
    iget-object v0, p0, La_4A8E7198;->d:Ljava/lang/Object;

    .line 12
    check-cast v0, La_EE36626D;

    .line 14
    invoke-virtual {v0, v2}, La_EE36626D;->t(Z)V

    .line 17
    return-void

    .line 18
    :pswitch_2
    iget-object v0, p0, La_4A8E7198;->d:Ljava/lang/Object;

    .line 20
    check-cast v0, Lcom/android/pictach/a_04DFAFEA;

    .line 22
    sget v3, Lcom/android/pictach/a_04DFAFEA;->i:I

    .line 24
    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    .line 27
    move-result v3

    .line 28
    if-nez v3, :cond_1

    .line 30
    iget-boolean v3, v0, Lcom/android/pictach/a_04DFAFEA;->g:Z

    .line 32
    if-nez v3, :cond_1

    .line 34
    iget-object v3, v0, Lcom/android/pictach/a_04DFAFEA;->c:Lbo;

    .line 36
    invoke-virtual {v3}, Lbo;->i()V

    .line 39
    iget-object v3, v0, Lcom/android/pictach/a_04DFAFEA;->h:Landroid/content/SharedPreferences;

    .line 41
    const-string v4, "accessibility_granted"

    .line 43
    invoke-interface {v3, v4, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 46
    move-result v1

    .line 47
    invoke-virtual {v0}, Lcom/android/pictach/a_04DFAFEA;->b()Z

    .line 50
    move-result v3

    .line 51
    if-eqz v3, :cond_1

    .line 53
    iget-boolean v3, v0, Lcom/android/pictach/a_04DFAFEA;->d:Z

    .line 55
    if-nez v3, :cond_1

    .line 57
    if-eqz v1, :cond_0

    .line 59
    const v1, 0x7f0c001d

    .line 62
    invoke-virtual {v0, v1}, Landroid/app/Activity;->setContentView(I)V

    .line 65
    goto :goto_0

    .line 66
    :cond_0
    const v1, 0x7f0c0033

    .line 69
    invoke-virtual {v0, v1}, Landroid/app/Activity;->setContentView(I)V

    .line 72
    :goto_0
    iput-boolean v2, v0, Lcom/android/pictach/a_04DFAFEA;->d:Z

    .line 74
    :cond_1
    return-void

    .line 75
    :pswitch_3
    iget-object v0, p0, La_4A8E7198;->d:Ljava/lang/Object;

    .line 77
    check-cast v0, Landroidx/emoji2/text/g$b;

    .line 79
    const-string v3, "fetchFonts result is not OK. ("

    .line 81
    iget-object v4, v0, Landroidx/emoji2/text/g$b;->d:Ljava/lang/Object;

    .line 83
    monitor-enter v4

    .line 84
    :try_start_0
    iget-object v5, v0, Landroidx/emoji2/text/g$b;->h:Landroidx/emoji2/text/d$h;

    .line 86
    if-nez v5, :cond_2

    .line 88
    monitor-exit v4

    .line 89
    goto/16 :goto_2

    .line 91
    :cond_2
    monitor-exit v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_6

    .line 92
    :try_start_1
    invoke-virtual {v0}, Landroidx/emoji2/text/g$b;->d()Lmd;

    .line 95
    move-result-object v4

    .line 96
    iget v5, v4, Lmd;->e:I

    .line 98
    const/4 v6, 0x2

    .line 99
    if-ne v5, v6, :cond_3

    .line 101
    iget-object v6, v0, Landroidx/emoji2/text/g$b;->d:Ljava/lang/Object;

    .line 103
    monitor-enter v6
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_4

    .line 104
    :try_start_2
    monitor-exit v6

    .line 105
    goto :goto_1

    .line 106
    :catchall_0
    move-exception v1

    .line 107
    monitor-exit v6
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 108
    :try_start_3
    throw v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_4

    .line 109
    :cond_3
    :goto_1
    if-nez v5, :cond_6

    .line 111
    :try_start_4
    const-string v3, "EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface"

    .line 113
    sget v5, Lwv;->a:I

    .line 115
    invoke-static {v3}, La_4098D472;->a(Ljava/lang/String;)V

    .line 118
    iget-object v3, v0, Landroidx/emoji2/text/g$b;->c:Landroidx/emoji2/text/g$a;

    .line 120
    iget-object v5, v0, Landroidx/emoji2/text/g$b;->a:Landroid/content/Context;

    .line 122
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 125
    new-array v2, v2, [Lmd;

    .line 127
    aput-object v4, v2, v1

    .line 129
    sget-object v3, Lmw;->a:Ltw;

    .line 131
    invoke-virtual {v3, v5, v2, v1}, Ltw;->b(Landroid/content/Context;[Lmd;I)Landroid/graphics/Typeface;

    .line 134
    move-result-object v1

    .line 135
    iget-object v2, v0, Landroidx/emoji2/text/g$b;->a:Landroid/content/Context;

    .line 137
    iget-object v3, v4, Lmd;->a:Landroid/net/Uri;

    .line 139
    invoke-static {v2, v3}, Luw;->e(Landroid/content/Context;Landroid/net/Uri;)Ljava/nio/MappedByteBuffer;

    .line 142
    move-result-object v2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .line 143
    if-eqz v2, :cond_5

    .line 145
    if-eqz v1, :cond_5

    .line 147
    :try_start_5
    const-string v3, "EmojiCompat.MetadataRepo.create"

    .line 149
    invoke-static {v3}, La_4098D472;->a(Ljava/lang/String;)V

    .line 152
    new-instance v3, Landroidx/emoji2/text/h;

    .line 154
    invoke-static {v2}, Lrl;->a(Ljava/nio/MappedByteBuffer;)Lql;

    .line 157
    move-result-object v2

    .line 158
    invoke-direct {v3, v1, v2}, Landroidx/emoji2/text/h;-><init>(Landroid/graphics/Typeface;Lql;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 161
    :try_start_6
    invoke-static {}, La_4098D472;->b()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 164
    :try_start_7
    invoke-static {}, La_4098D472;->b()V

    .line 167
    iget-object v1, v0, Landroidx/emoji2/text/g$b;->d:Ljava/lang/Object;

    .line 169
    monitor-enter v1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    .line 170
    :try_start_8
    iget-object v2, v0, Landroidx/emoji2/text/g$b;->h:Landroidx/emoji2/text/d$h;

    .line 172
    if-eqz v2, :cond_4

    .line 174
    invoke-virtual {v2, v3}, Landroidx/emoji2/text/d$h;->b(Landroidx/emoji2/text/h;)V

    .line 177
    :cond_4
    monitor-exit v1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    .line 178
    :try_start_9
    invoke-virtual {v0}, Landroidx/emoji2/text/g$b;->b()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    .line 181
    goto :goto_2

    .line 182
    :catchall_1
    move-exception v2

    .line 183
    :try_start_a
    monitor-exit v1
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_1

    .line 184
    :try_start_b
    throw v2
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_4

    .line 185
    :catchall_2
    move-exception v1

    .line 186
    :try_start_c
    sget v2, Lwv;->a:I

    .line 188
    invoke-static {}, La_4098D472;->b()V

    .line 191
    throw v1

    .line 192
    :cond_5
    new-instance v1, Ljava/lang/RuntimeException;

    .line 194
    const-string v2, "Unable to open file."

    .line 196
    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 199
    throw v1
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_3

    .line 200
    :catchall_3
    move-exception v1

    .line 201
    :try_start_d
    sget v2, Lwv;->a:I

    .line 203
    invoke-static {}, La_4098D472;->b()V

    .line 206
    throw v1

    .line 207
    :cond_6
    new-instance v1, Ljava/lang/RuntimeException;

    .line 209
    new-instance v2, Ljava/lang/StringBuilder;

    .line 211
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 214
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 217
    const-string v3, ")"

    .line 219
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 222
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 225
    move-result-object v2

    .line 226
    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 229
    throw v1
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_4

    .line 230
    :catchall_4
    move-exception v1

    .line 231
    iget-object v2, v0, Landroidx/emoji2/text/g$b;->d:Ljava/lang/Object;

    .line 233
    monitor-enter v2

    .line 234
    :try_start_e
    iget-object v3, v0, Landroidx/emoji2/text/g$b;->h:Landroidx/emoji2/text/d$h;

    .line 236
    if-eqz v3, :cond_7

    .line 238
    invoke-virtual {v3, v1}, Landroidx/emoji2/text/d$h;->a(Ljava/lang/Throwable;)V

    .line 241
    :cond_7
    monitor-exit v2
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_5

    .line 242
    invoke-virtual {v0}, Landroidx/emoji2/text/g$b;->b()V

    .line 245
    :goto_2
    return-void

    .line 246
    :catchall_5
    move-exception v0

    .line 247
    :try_start_f
    monitor-exit v2
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_5

    .line 248
    throw v0

    .line 249
    :catchall_6
    move-exception v0

    .line 250
    :try_start_10
    monitor-exit v4
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_6

    .line 251
    throw v0

    .line 252
    :pswitch_4
    iget-object v0, p0, La_4A8E7198;->d:Ljava/lang/Object;

    .line 254
    check-cast v0, Ltv;

    .line 256
    invoke-virtual {v0}, Ltv;->a()V

    .line 259
    return-void

    .line 260
    :pswitch_5
    iget-object v0, p0, La_4A8E7198;->d:Ljava/lang/Object;

    .line 262
    check-cast v0, La_7A5DD752;

    .line 264
    invoke-static {v0}, La_7A5DD752;->d(La_7A5DD752;)V

    .line 267
    return-void

    .line 268
    :goto_3
    iget-object v0, p0, La_4A8E7198;->d:Ljava/lang/Object;

    .line 270
    check-cast v0, Leb;

    .line 272
    iget-object v1, v0, Leb;->h:Landroid/widget/AutoCompleteTextView;

    .line 274
    invoke-virtual {v1}, Landroid/widget/AutoCompleteTextView;->isPopupShowing()Z

    .line 277
    move-result v1

    .line 278
    invoke-virtual {v0, v1}, Leb;->t(Z)V

    .line 281
    iput-boolean v1, v0, Leb;->m:Z

    .line 283
    return-void

    .line 284
    nop

    .line 285
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method
