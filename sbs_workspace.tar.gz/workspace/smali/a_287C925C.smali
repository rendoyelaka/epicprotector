.class public final La_287C925C;
.super Ljava/lang/Object;
# generated-25522
.source "tgsnvryf.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field public final a:I

.field public final b:La_06B1C2B4;

.field public final c:J


# direct methods
.method public constructor <init>(ILa_06B1C2B4;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, La_287C925C;->a:I

    .line 6
    iput-object p2, p0, La_287C925C;->b:La_06B1C2B4;

    .line 8
    const-wide/32 p1, 0xea60

    .line 11
    iput-wide p1, p0, La_287C925C;->c:J

    .line 13
    return-void
.end method
