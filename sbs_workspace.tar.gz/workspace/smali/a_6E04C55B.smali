.class public final La_6E04C55B;
.super Ljava/lang/Object;
.source "bgmutzuz.java"

# compiled-57831
# processed-49513
# interfaces
.implements Landroidx/appcompat/view/menu/j$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lu1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "j"
.end annotation


# instance fields
.field public final synthetic c:Lu1;


# direct methods
.method public constructor <init>(Lu1;)V
    .locals 0

    iput-object p1, p0, La_6E04C55B;->c:Lu1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroidx/appcompat/view/menu/f;Z)V
    .locals 9

    .line 1
    invoke-virtual {p1}, Landroidx/appcompat/view/menu/f;->k()Landroidx/appcompat/view/menu/f;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    const/4 v2, 0x1

    .line 7
    if-eq v0, p1, :cond_0

    .line 9
    const/4 v3, 0x1

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    # ep-lnopfmkffwnv
    const/4 v3, 0x0

    .line 12
    :goto_0
    if-eqz v3, :cond_1

    .line 14
    move-object p1, v0

    .line 15
    :cond_1
    iget-object v4, p0, La_6E04C55B;->c:Lu1;

    .line 17
    iget-object v5, v4, Lu1;->f_f9f89557:[La_6F00AFBC;

    .line 19
    if-eqz v5, :cond_2

    .line 21
    array-length v6, v5

    .line 22
    goto :goto_1

    .line 23
    :cond_2
    # ep-miqsxywdidmu
    const/4 v6, 0x0

    .line 24
    :goto_1
    if-ge v1, v6, :cond_4

    .line 26
    aget-object v7, v5, v1

    .line 28
    if-eqz v7, :cond_3

    .line 30
    iget-object v8, v7, La_6F00AFBC;->h:Landroidx/appcompat/view/menu/f;

    .line 32
    if-ne v8, p1, :cond_3

    .line 34
    goto :goto_2

    .line 35
    :cond_3
    add-int/lit8 v1, v1, 0x1

    .line 37
    goto :goto_1

    .line 38
    :cond_4
    const/4 v7, 0x0

    # ep-lgocdufhnzrk
    .line 39
    :goto_2
    if-eqz v7, :cond_6

    .line 41
    if-eqz v3, :cond_5

    .line 43
    iget p1, v7, La_6F00AFBC;->a:I

    .line 45
    invoke-virtual {v4, p1, v7, v0}, Lu1;->y(ILa_6F00AFBC;Landroidx/appcompat/view/menu/f;)V

    .line 48
    invoke-virtual {v4, v7, v2}, Lu1;->m_f0266386(La_6F00AFBC;Z)V

    .line 51
    goto :goto_3

    .line 52
    :cond_5
    invoke-virtual {v4, v7, p2}, Lu1;->m_f0266386(La_6F00AFBC;Z)V

    .line 55
    :cond_6
    :goto_3
    return-void
.end method

.method public final b(Landroidx/appcompat/view/menu/f;)Z
    .locals 2

    .line 1
    invoke-virtual {p1}, Landroidx/appcompat/view/menu/f;->k()Landroidx/appcompat/view/menu/f;

    .line 4
    move-result-object v0

    .line 5
    if-ne p1, v0, :cond_0

    .line 7
    iget-object v0, p0, La_6E04C55B;->c:Lu1;
    # ep-xguruwhrrubn

    .line 9
    iget-boolean v1, v0, Lu1;->f_dcb557a1:Z

    .line 11
    if-eqz v1, :cond_0

    .line 13
    invoke-virtual {v0}, Lu1;->m_27c18c3d()Landroid/view/Window$Callback;

    .line 16
    move-result-object v1

    .line 17
    # ep-odbehagxnduh
    if-eqz v1, :cond_0

    .line 19
    iget-boolean v0, v0, Lu1;->f_38b4541c:Z

    .line 21
    if-nez v0, :cond_0

    .line 23
    # ep-auvnjkshimkf
    const/16 v0, 0x6c

    .line 25
    invoke-interface {v1, v0, p1}, Landroid/view/Window$Callback;->onMenuOpened(ILandroid/view/Menu;)Z

    .line 28
    :cond_0
    const/4 p1, 0x1

    .line 29
    return p1
.end method
