.class public final La_5E9A672E;
.super Landroid/graphics/drawable/Drawable$ConstantState;
# compiled-34864
.source "kbsljwqt.java"
# ep-egmotukplgsm


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lhq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:La_3DDEE9B9;

.field public b:Z


# direct methods
.method public constructor <init>(La_3DDEE9B9;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    .line 2
    iput-object p1, p0, La_5E9A672E;->a:La_3DDEE9B9;

    const/4 p1, 0x0

    .line 3
    iput-boolean p1, p0, La_5E9A672E;->b:Z

    return-void
.end method

.method public constructor <init>(La_5E9A672E;)V
    .locals 1

    .line 4
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    .line 5
    iget-object v0, p1, La_5E9A672E;->a:La_3DDEE9B9;

    .line 6
    iget-object v0, v0, La_3DDEE9B9;->c:La_A9E1BAE7;

    .line 7
    invoke-virtual {v0}, La_A9E1BAE7;->m_48aae3f6()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    check-cast v0, La_3DDEE9B9;

    iput-object v0, p0, La_5E9A672E;->a:La_3DDEE9B9;

    .line 8
    iget-boolean p1, p1, La_5E9A672E;->b:Z

    iput-boolean p1, p0, La_5E9A672E;->b:Z

    return-void
.end method


# virtual methods
.method public final m_fbdebb97()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final m_48aae3f6()Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 1
    new-instance v0, Lhq;

    .line 3
    new-instance v1, La_5E9A672E;

    .line 5
    invoke-direct {v1, p0}, La_5E9A672E;-><init>(La_5E9A672E;)V

    .line 8
    invoke-direct {v0, v1}, Lhq;-><init>(La_5E9A672E;)V

    .line 11
    return-object v0
.end method
