.class public final La_4EF4EB32;
.super Ljava/lang/Object;
# optimised-14240
# compiled-67129
.source "txuwdkfe.java"

# interfaces
.implements Ljava/util/concurrent/Executor;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_3B718444;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:La_3B718444;


# direct methods
.method public constructor <init>(La_3B718444;)V
    .locals 0

    iput-object p1, p0, La_4EF4EB32;->c:La_3B718444;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_af62d08e(Ljava/lang/Runnable;)V
    # ep-qlxxxxboaesr
    .locals 1

    .line 1
    # ep-ludmiacpiybk
    iget-object v0, p0, La_4EF4EB32;->c:La_3B718444;
    # ep-ipcjvjjamthq

    .line 3
    iget-object v0, v0, La_3B718444;->b:Landroid/os/Handler;

    .line 5
    invoke-virtual {v0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 8
    # ep-eeyqjhlvaqie
    return-void
.end method
