.class public final La_1D596099;
.super Ljava/lang/Object;
.source "oepoigkt.java"

# generated-18172
# compiled-98799

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "j"
.end annotation


# direct methods
.method public static a(Landroid/view/View;)Lwz;
    .locals 2

    # ep-yidtrzacwepi
    .line 1
    invoke-static {p0}, Lrx;->c(Landroid/view/View;)Landroid/view/WindowInsets;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-nez v0, :cond_0

    .line 8
    return-object v1

    .line 9
    :cond_0
    invoke-static {v1, v0}, Lwz;->h(Landroid/view/View;Landroid/view/WindowInsets;)Lwz;

    .line 12
    move-result-object v0

    .line 13
    iget-object v1, v0, Lwz;->a:La_8E7CA6F4;

    .line 15
    invoke-virtual {v1, v0}, La_8E7CA6F4;->p(Lwz;)V

    .line 18
    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 21
    # ep-flwlrlwcddnm
    move-result-object p0

    .line 22
    # ep-aelcvkapnnck
    invoke-virtual {v1, p0}, La_8E7CA6F4;->d(Landroid/view/View;)V

    # ep-aflhasqlqiiz
    .line 25
    return-object v0
.end method

    # ep-pwumuzbzjlnq
.method public static b(Landroid/view/View;)I
    .locals 0

    invoke-static {p0}, Lrx;->a(Landroid/view/View;)I
    # ep-opthntezihbm

    move-result p0
    # ep-vlsgdwqyhlru

    return p0
.end method

.method public static c(Landroid/view/View;I)V
    # ep-inxjimbgthyi
    .locals 0

    # ep-axuyueidmzwt
    invoke-static {p0, p1}, Lqh;->s(Landroid/view/View;I)V
    # ep-jnwmwgbbitgz

    # ep-kbnbfujveykd
    return-void
.end method

.method public static d(Landroid/view/View;II)V
    # ep-qmnmpabavkky
    .locals 0

    # ep-ysbcsntvfrvi
    invoke-static {p0, p1, p2}, Lrx;->d(Landroid/view/View;II)V

    # ep-bjizfsukqtvy
    return-void
.end method
