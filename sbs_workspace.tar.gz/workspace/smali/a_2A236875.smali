.class public final La_2A236875;
.super Ljava/lang/Object;
# verified-20685
# compiled-94631
# optimised-22031
.source "ufpktyil.java"

# ep-wylpjlsotnyh
# interfaces
.implements Landroid/database/sqlite/SQLiteDatabase$CursorFactory;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lqe;->s(Lut;)Landroid/database/Cursor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lut;


# direct methods
.method public constructor <init>(Lut;)V
    .locals 0

    iput-object p1, p0, La_2A236875;->a:Lut;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_6481c680(Landroid/database/sqlite/SQLiteDatabase;Landroid/database/sqlite/SQLiteCursorDriver;Ljava/lang/String;Landroid/database/sqlite/SQLiteQuery;)Landroid/database/Cursor;
    .locals 1

    .line 1
    new-instance p1, Lte;

    .line 3
    invoke-direct {p1, p4}, Lte;-><init>(Landroid/database/sqlite/SQLiteProgram;)V

    .line 6
    iget-object v0, p0, La_2A236875;->a:Lut;

    .line 8
    invoke-interface {v0, p1}, Lut;->j(Lte;)V

    .line 11
    new-instance p1, Landroid/database/sqlite/SQLiteCursor;

    .line 13
    invoke-direct {p1, p2, p3, p4}, Landroid/database/sqlite/SQLiteCursor;-><init>(Landroid/database/sqlite/SQLiteCursorDriver;Ljava/lang/String;Landroid/database/sqlite/SQLiteQuery;)V

    .line 16
    return-object p1
.end method
