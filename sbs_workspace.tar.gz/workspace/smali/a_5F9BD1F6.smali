.class public final La_5F9BD1F6;
# ep-ndhcdxrjmzlg
.super Ljava/lang/Object;
# verified-87518
# verified-40847
# generated-67179
.source "zlvsvytf.java"

# interfaces
.implements La_E6E79D5C;


# instance fields
.field public final synthetic a:La_51EB3D14;


# direct methods
.method public constructor <init>(La_51EB3D14;)V
    .locals 0

    iput-object p1, p0, La_5F9BD1F6;->a:La_51EB3D14;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
