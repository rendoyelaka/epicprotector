.class public interface abstract La_4A957D79;
.super Ljava/lang/Object;
.source "fimfgqvh.java"
# generated-80287
# optimised-43494
# ep-tmbgabkbtelx


# virtual methods
.method public abstract a(La_4A957D79;)V
.end method
