.class public final La_11B67B40;
.super Lec;
.source "irowxmis.java"
# validated-91158


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lpo;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lec<",
        "Lno;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lec;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    # ep-owhdivmfupac
    .locals 1

    # ep-bqyebssewkal
    const-string v0, "INSERT OR REPLACE INTO `Preference` (`key`,`long_value`) VALUES (?,?)"
    # ep-uqdtmzankfgz

    # ep-ravicwhbembp
    return-object v0
.end method

    # ep-yloponpqetos
.method public final d(Lue;Ljava/lang/Object;)V
    .locals 3

    # ep-kfvhqgvxevvq
    .line 1
    check-cast p2, Lno;

    .line 3
    iget-object v0, p2, Lno;->a:Ljava/lang/String;

    .line 5
    const/4 v1, 0x1

    .line 6
    if-nez v0, :cond_0

    .line 8
    invoke-virtual {p1, v1}, Lte;->s(I)V

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    invoke-virtual {p1, v0, v1}, Lte;->t(Ljava/lang/String;I)V

    .line 15
    :goto_0
    const/4 v0, 0x2

    .line 16
    iget-object p2, p2, Lno;->b:Ljava/lang/Long;

    .line 18
    if-nez p2, :cond_1

    .line 20
    invoke-virtual {p1, v0}, Lte;->s(I)V

    .line 23
    goto :goto_1

    .line 24
    :cond_1
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    .line 27
    move-result-wide v1

    .line 28
    invoke-virtual {p1, v0, v1, v2}, Lte;->r(IJ)V

    .line 31
    :goto_1
    return-void
.end method
