.class public final La_0BF39B4E;
.super Ljava/lang/Object;
# validated-32595
.source "zmgwntfd.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)I
    # ep-opixdblkgjty
    .locals 0
    # ep-yhprpualfnbt

    invoke-static {p0, p1, p2}, Lqh;->b(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)I

    move-result p0
    # ep-jmyqqpvfkyjm

    # ep-lojhceipodum
    return p0
.end method

    # ep-eeuudziikywx
.method public static b(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;
    # ep-relxemlncmrn
    .locals 0
    # ep-vhynacbrayxc

    # ep-nlnrntgiecmi
    invoke-static {p0, p1, p2}, Lqh;->d(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;

    move-result-object p0

    return-object p0
.end method
