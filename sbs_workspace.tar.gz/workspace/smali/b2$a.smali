.class public final Lb2$a;
# ep-iddolbgecsph
.super Ljava/lang/Object;
.source "smkwsaat.java"
# generated-94932
# compiled-85092

# interfaces
.implements Ltp$f;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lb2;->d()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final a:[I

.field public final b:[I

.field public final c:[I

.field public final d:[I

.field public final e:[I

.field public final f:[I


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x3

    .line 5
    new-array v1, v0, [I

    .line 7
    fill-array-data v1, :array_0

    .line 10
    iput-object v1, p0, Lb2$a;->a:[I

    .line 12
    const/4 v1, 0x7

    .line 13
    new-array v2, v1, [I

    .line 15
    fill-array-data v2, :array_1

    .line 18
    iput-object v2, p0, Lb2$a;->b:[I

    .line 20
    new-array v1, v1, [I

    .line 22
    fill-array-data v1, :array_2

    .line 25
    iput-object v1, p0, Lb2$a;->c:[I

    .line 27
    new-array v0, v0, [I

    .line 29
    fill-array-data v0, :array_3

    .line 32
    iput-object v0, p0, Lb2$a;->d:[I

    .line 34
    const/4 v0, 0x2

    .line 35
    new-array v0, v0, [I

    .line 37
    fill-array-data v0, :array_4

    .line 40
    iput-object v0, p0, Lb2$a;->e:[I

    .line 42
    const/4 v0, 0x4

    .line 43
    new-array v0, v0, [I

    .line 45
    fill-array-data v0, :array_5

    .line 48
    iput-object v0, p0, Lb2$a;->f:[I

    .line 50
    return-void

    .line 51
    :array_0
    .array-data 4
        0x7f070074
        0x7f070072
        0x7f070028
    .end array-data

    .line 61
    :array_1
    .array-data 4
        0x7f070040
        0x7f070063
        0x7f070047
        0x7f070042
        0x7f070043
        0x7f070046
        0x7f070045
    .end array-data

    :array_2
    .array-data 4
        0x7f070071
        0x7f070073
        0x7f070039
        0x7f07006d
        0x7f07006e
        0x7f07006f
        0x7f070070
    .end array-data

    :array_3
    .array-data 4
        0x7f070059
        0x7f070037
        0x7f070058
    .end array-data

    :array_4
    .array-data 4
        0x7f07006b
        0x7f070075
    .end array-data

    :array_5
    .array-data 4
        0x7f07002b
        0x7f070031
        0x7f07002c
        0x7f070032
    .end array-data
.end method

.method public static a([II)Z
    .locals 4

    array-length v0, p0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_1

    aget v3, p0, v2

    if-ne v3, p1, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return v1
.end method

.method public static b(Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    .locals 5

    .line 1
    const/4 v0, 0x4

    .line 2
    new-array v1, v0, [[I

    .line 4
    new-array v0, v0, [I

    .line 6
    const v2, 0x7f0300f2

    .line 9
    invoke-static {p0, v2}, Lav;->c(Landroid/content/Context;I)I

    .line 12
    move-result v2

    .line 13
    const v3, 0x7f0300ef

    .line 16
    invoke-static {p0, v3}, Lav;->b(Landroid/content/Context;I)I

    .line 19
    move-result p0

    .line 20
    sget-object v3, Lav;->b:[I

    .line 22
    const/4 v4, 0x0

    .line 23
    aput-object v3, v1, v4

    .line 25
    aput p0, v0, v4

    .line 27
    sget-object p0, Lav;->d:[I

    .line 29
    const/4 v3, 0x1

    .line 30
    aput-object p0, v1, v3

    .line 32
    invoke-static {v2, p1}, Lw6;->b(II)I

    .line 35
    move-result p0

    .line 36
    aput p0, v0, v3

    .line 38
    sget-object p0, Lav;->c:[I

    .line 40
    const/4 v3, 0x2

    .line 41
    aput-object p0, v1, v3

    .line 43
    invoke-static {v2, p1}, Lw6;->b(II)I

    .line 46
    move-result p0

    .line 47
    aput p0, v0, v3

    .line 49
    sget-object p0, Lav;->f:[I

    .line 51
    const/4 v2, 0x3

    .line 52
    aput-object p0, v1, v2

    .line 54
    aput p1, v0, v2

    .line 56
    new-instance p0, Landroid/content/res/ColorStateList;

    .line 58
    invoke-direct {p0, v1, v0}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    .line 61
    return-object p0
.end method

.method public static c(Ltp;Landroid/content/Context;I)Landroid/graphics/drawable/LayerDrawable;
    .locals 4

    .line 1
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0, p2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 8
    move-result p2

    .line 9
    const v0, 0x7f070067

    .line 12
    invoke-virtual {p0, p1, v0}, Ltp;->f(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 15
    move-result-object v0

    .line 16
    const v1, 0x7f070068

    .line 19
    invoke-virtual {p0, p1, v1}, Ltp;->f(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 22
    move-result-object p0

    .line 23
    instance-of p1, v0, Landroid/graphics/drawable/BitmapDrawable;

    .line 25
    const/4 v1, 0x0

    .line 26
    if-eqz p1, :cond_0

    .line 28
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 31
    move-result p1

    .line 32
    if-ne p1, p2, :cond_0

    .line 34
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    .line 37
    move-result p1

    .line 38
    if-ne p1, p2, :cond_0

    .line 40
    check-cast v0, Landroid/graphics/drawable/BitmapDrawable;

    .line 42
    new-instance p1, Landroid/graphics/drawable/BitmapDrawable;

    .line 44
    invoke-virtual {v0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    .line 47
    move-result-object v2

    .line 48
    invoke-direct {p1, v2}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/graphics/Bitmap;)V

    .line 51
    goto :goto_0

    .line 52
    :cond_0
    sget-object p1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 54
    invoke-static {p2, p2, p1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 57
    move-result-object p1

    .line 58
    new-instance v2, Landroid/graphics/Canvas;

    .line 60
    invoke-direct {v2, p1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 63
    invoke-virtual {v0, v1, v1, p2, p2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 66
    invoke-virtual {v0, v2}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 69
    new-instance v0, Landroid/graphics/drawable/BitmapDrawable;

    .line 71
    invoke-direct {v0, p1}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/graphics/Bitmap;)V

    .line 74
    new-instance v2, Landroid/graphics/drawable/BitmapDrawable;

    .line 76
    invoke-direct {v2, p1}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/graphics/Bitmap;)V

    .line 79
    move-object p1, v2

    .line 80
    :goto_0
    sget-object v2, Landroid/graphics/Shader$TileMode;->REPEAT:Landroid/graphics/Shader$TileMode;

    .line 82
    invoke-virtual {p1, v2}, Landroid/graphics/drawable/BitmapDrawable;->setTileModeX(Landroid/graphics/Shader$TileMode;)V

    .line 85
    instance-of v2, p0, Landroid/graphics/drawable/BitmapDrawable;

    .line 87
    if-eqz v2, :cond_1

    .line 89
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 92
    move-result v2

    .line 93
    if-ne v2, p2, :cond_1

    .line 95
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    .line 98
    move-result v2

    .line 99
    if-ne v2, p2, :cond_1

    .line 101
    check-cast p0, Landroid/graphics/drawable/BitmapDrawable;

    .line 103
    goto :goto_1

    .line 104
    :cond_1
    sget-object v2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 106
    invoke-static {p2, p2, v2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 109
    move-result-object v2

    .line 110
    new-instance v3, Landroid/graphics/Canvas;

    .line 112
    invoke-direct {v3, v2}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 115
    invoke-virtual {p0, v1, v1, p2, p2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 118
    invoke-virtual {p0, v3}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 121
    new-instance p0, Landroid/graphics/drawable/BitmapDrawable;

    .line 123
    invoke-direct {p0, v2}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/graphics/Bitmap;)V

    .line 126
    :goto_1
    new-instance p2, Landroid/graphics/drawable/LayerDrawable;

    .line 128
    const/4 v2, 0x3

    .line 129
    new-array v2, v2, [Landroid/graphics/drawable/Drawable;

    .line 131
    aput-object v0, v2, v1

    .line 133
    const/4 v0, 0x1

    .line 134
    aput-object p0, v2, v0

    .line 136
    const/4 p0, 0x2

    .line 137
    aput-object p1, v2, p0

    .line 139
    invoke-direct {p2, v2}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    .line 142
    const/high16 p1, 0x1020000

    .line 144
    invoke-virtual {p2, v1, p1}, Landroid/graphics/drawable/LayerDrawable;->setId(II)V

    .line 147
    const p1, 0x102000f

    .line 150
    invoke-virtual {p2, v0, p1}, Landroid/graphics/drawable/LayerDrawable;->setId(II)V

    .line 153
    const p1, 0x102000d

    .line 156
    invoke-virtual {p2, p0, p1}, Landroid/graphics/drawable/LayerDrawable;->setId(II)V

    .line 159
    return-object p2
.end method

.method public static e(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    sget-object v0, Lwa;->a:[I

    .line 3
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 6
    move-result-object p0

    .line 7
    if-nez p2, :cond_0

    .line 9
    sget-object p2, Lb2;->b:Landroid/graphics/PorterDuff$Mode;

    .line 11
    :cond_0
    invoke-static {p1, p2}, Lb2;->c(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    .line 14
    move-result-object p1

    .line 15
    invoke-virtual {p0, p1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    .line 18
    return-void
.end method


# virtual methods
.method public final d(Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    .locals 8

    .line 1
    const v0, 0x7f07003c

    .line 4
    if-ne p2, v0, :cond_0

    .line 6
    const p2, 0x7f050015

    .line 9
    invoke-static {p1, p2}, Ln8;->c(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 12
    move-result-object p1

    .line 13
    return-object p1

    .line 14
    :cond_0
    const v0, 0x7f07006a

    .line 17
    if-ne p2, v0, :cond_1

    .line 19
    const p2, 0x7f050018

    .line 22
    invoke-static {p1, p2}, Ln8;->c(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 25
    move-result-object p1

    .line 26
    return-object p1

    .line 27
    :cond_1
    const v0, 0x7f070069

    .line 30
    const/4 v1, 0x0

    .line 31
    if-ne p2, v0, :cond_3

    .line 33
    const/4 p2, 0x3

    .line 34
    new-array v0, p2, [[I

    .line 36
    new-array p2, p2, [I

    .line 38
    const v2, 0x7f030124

    .line 41
    invoke-static {p1, v2}, Lav;->d(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 44
    move-result-object v3

    .line 45
    const/4 v4, 0x2

    .line 46
    const v5, 0x7f0300f1

    .line 49
    const/4 v6, 0x1

    .line 50
    if-eqz v3, :cond_2

    .line 52
    invoke-virtual {v3}, Landroid/content/res/ColorStateList;->isStateful()Z

    .line 55
    move-result v7

    .line 56
    if-eqz v7, :cond_2

    .line 58
    sget-object v2, Lav;->b:[I

    .line 60
    aput-object v2, v0, v1

    .line 62
    invoke-virtual {v3, v2, v1}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 65
    move-result v2

    .line 66
    aput v2, p2, v1

    .line 68
    sget-object v1, Lav;->e:[I

    .line 70
    aput-object v1, v0, v6

    .line 72
    invoke-static {p1, v5}, Lav;->c(Landroid/content/Context;I)I

    .line 75
    move-result p1

    .line 76
    aput p1, p2, v6

    .line 78
    sget-object p1, Lav;->f:[I

    .line 80
    aput-object p1, v0, v4

    .line 82
    invoke-virtual {v3}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    .line 85
    move-result p1

    .line 86
    aput p1, p2, v4

    .line 88
    goto :goto_0

    .line 89
    :cond_2
    sget-object v3, Lav;->b:[I

    .line 91
    aput-object v3, v0, v1

    .line 93
    invoke-static {p1, v2}, Lav;->b(Landroid/content/Context;I)I

    .line 96
    move-result v3

    .line 97
    aput v3, p2, v1

    .line 99
    sget-object v1, Lav;->e:[I

    .line 101
    aput-object v1, v0, v6

    .line 103
    invoke-static {p1, v5}, Lav;->c(Landroid/content/Context;I)I

    .line 106
    move-result v1

    .line 107
    aput v1, p2, v6

    .line 109
    sget-object v1, Lav;->f:[I

    .line 111
    aput-object v1, v0, v4

    .line 113
    invoke-static {p1, v2}, Lav;->c(Landroid/content/Context;I)I

    .line 116
    move-result p1

    .line 117
    aput p1, p2, v4

    .line 119
    :goto_0
    new-instance p1, Landroid/content/res/ColorStateList;

    .line 121
    invoke-direct {p1, v0, p2}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    .line 124
    return-object p1

    .line 125
    :cond_3
    const v0, 0x7f070030

    .line 128
    if-ne p2, v0, :cond_4

    .line 130
    const p2, 0x7f0300ef

    .line 133
    invoke-static {p1, p2}, Lav;->c(Landroid/content/Context;I)I

    .line 136
    move-result p2

    .line 137
    invoke-static {p1, p2}, Lb2$a;->b(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 140
    move-result-object p1

    .line 141
    return-object p1

    .line 142
    :cond_4
    const v0, 0x7f07002a

    .line 145
    if-ne p2, v0, :cond_5

    .line 147
    invoke-static {p1, v1}, Lb2$a;->b(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 150
    move-result-object p1

    .line 151
    return-object p1

    .line 152
    :cond_5
    const v0, 0x7f07002f

    .line 155
    if-ne p2, v0, :cond_6

    .line 157
    const p2, 0x7f0300ed

    .line 160
    invoke-static {p1, p2}, Lav;->c(Landroid/content/Context;I)I

    .line 163
    move-result p2

    .line 164
    invoke-static {p1, p2}, Lb2$a;->b(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 167
    move-result-object p1

    .line 168
    return-object p1

    .line 169
    :cond_6
    const v0, 0x7f070065

    .line 172
    if-eq p2, v0, :cond_c

    .line 174
    const v0, 0x7f070066

    .line 177
    if-ne p2, v0, :cond_7

    .line 179
    goto :goto_1

    .line 180
    :cond_7
    iget-object v0, p0, Lb2$a;->b:[I

    .line 182
    invoke-static {v0, p2}, Lb2$a;->a([II)Z

    .line 185
    move-result v0

    .line 186
    if-eqz v0, :cond_8

    .line 188
    const p2, 0x7f0300f3

    .line 191
    invoke-static {p1, p2}, Lav;->d(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 194
    move-result-object p1

    .line 195
    return-object p1

    .line 196
    :cond_8
    iget-object v0, p0, Lb2$a;->e:[I

    .line 198
    invoke-static {v0, p2}, Lb2$a;->a([II)Z

    .line 201
    move-result v0

    .line 202
    if-eqz v0, :cond_9

    .line 204
    const p2, 0x7f050014

    .line 207
    invoke-static {p1, p2}, Ln8;->c(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 210
    move-result-object p1

    .line 211
    return-object p1

    .line 212
    :cond_9
    iget-object v0, p0, Lb2$a;->f:[I

    .line 214
    invoke-static {v0, p2}, Lb2$a;->a([II)Z

    .line 217
    move-result v0

    .line 218
    if-eqz v0, :cond_a

    .line 220
    const p2, 0x7f050013

    .line 223
    invoke-static {p1, p2}, Ln8;->c(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 226
    move-result-object p1

    .line 227
    return-object p1

    .line 228
    :cond_a
    const v0, 0x7f070062

    .line 231
    if-ne p2, v0, :cond_b

    .line 233
    const p2, 0x7f050016

    .line 236
    invoke-static {p1, p2}, Ln8;->c(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 239
    move-result-object p1

    .line 240
    return-object p1

    .line 241
    :cond_b
    const/4 p1, 0x0

    .line 242
    return-object p1

    .line 243
    :cond_c
    :goto_1
    const p2, 0x7f050017

    .line 246
    invoke-static {p1, p2}, Ln8;->c(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 249
    move-result-object p1

    .line 250
    return-object p1
.end method
