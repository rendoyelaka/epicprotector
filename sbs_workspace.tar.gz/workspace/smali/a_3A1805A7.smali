.class public final La_3A1805A7;
.super Ljava/lang/Object;
.source "rjzygorh.java"
# compiled-81452
# optimised-45688
# verified-16491
# ep-sokaxplpkgwc


# instance fields
.field public final a:Lnp;

.field public final b:La_4C1B04CF;


# direct methods
.method public constructor <init>(Lnp;La_4C1B04CF;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_3A1805A7;->a:Lnp;

    .line 6
    iput-object p2, p0, La_3A1805A7;->b:La_4C1B04CF;

    .line 8
    return-void
.end method
