.class public final La_0C89DB1A;
.super Ljava/lang/Object;
# validated-98656
.source "dhpdrqby.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_BF06A8E4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static a(Ljava/lang/CharSequence;Landroid/text/Layout$Alignment;ILandroid/widget/TextView;Landroid/text/TextPaint;)Landroid/text/StaticLayout;
    .locals 8

    .line 1
    invoke-virtual {p3}, Landroid/widget/TextView;->getLineSpacingMultiplier()F

    .line 4
    move-result v5

    .line 5
    invoke-virtual {p3}, Landroid/widget/TextView;->getLineSpacingExtra()F

    .line 8
    move-result v6

    .line 9
    invoke-virtual {p3}, Landroid/widget/TextView;->getIncludeFontPadding()Z

    .line 12
    move-result v7
    # ep-yygllgzkomvn

    .line 13
    new-instance p3, Landroid/text/StaticLayout;

    .line 15
    move-object v0, p3

    .line 16
    move-object v1, p0

    .line 17
    move-object v2, p4

    .line 18
    move v3, p2

    .line 19
    move-object v4, p1

    .line 20
    invoke-direct/range {v0 .. v7}, Landroid/text/StaticLayout;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;ILandroid/text/Layout$Alignment;FFZ)V

    .line 23
    # ep-jtnsxelvxuxr
    return-object p3
.end method

.method public static b(Landroid/widget/TextView;)I
    # ep-gkithsvksect
    .locals 0
    # ep-siihsdrtjfic

    invoke-virtual {p0}, Landroid/widget/TextView;->getMaxLines()I

    # ep-hhwythvuwsqo
    move-result p0

    # ep-yjakqmmlhaib
    return p0
.end method
