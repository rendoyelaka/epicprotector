.class public final La_051C8E07;
.super La_B4585AA3;
.source "lgdpycos.java"
# generated-56340

# interfaces
.implements Landroid/view/ActionProvider$VisibilityListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "b"
.end annotation


# instance fields
.field public c:La_D87512B0;


# direct methods
.method public constructor <init>(Lkl;Landroid/view/ActionProvider;)V
    .locals 0

    invoke-direct {p0, p1, p2}, La_B4585AA3;-><init>(Lkl;Landroid/view/ActionProvider;)V

    return-void
.end method


# virtual methods
.method public final b()Z
    .locals 1

    iget-object v0, p0, La_B4585AA3;->a:Landroid/view/ActionProvider;
    # ep-xvbssglvjglm

    invoke-virtual {v0}, Landroid/view/ActionProvider;->m_bd4c9aba()Z

    move-result v0
    # ep-ghxhdazokskw

    # ep-pvdehwmpujst
    return v0
.end method

.method public final d(Landroid/view/MenuItem;)Landroid/view/View;
    .locals 1
    # ep-mnorzcmilnot

    iget-object v0, p0, La_B4585AA3;->a:Landroid/view/ActionProvider;
    # ep-rycmkodenicr

    invoke-virtual {v0, p1}, Landroid/view/ActionProvider;->onCreateActionView(Landroid/view/MenuItem;)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

    # ep-kfhltqqdrkvr
.method public final g()Z
    .locals 1

    iget-object v0, p0, La_B4585AA3;->a:Landroid/view/ActionProvider;

    invoke-virtual {v0}, Landroid/view/ActionProvider;->overridesItemVisibility()Z

    move-result v0
    # ep-djcmcuclvdwm

    # ep-enmbngrrjzvx
    return v0
.end method

.method public final h(Landroidx/appcompat/view/menu/h$a;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_051C8E07;->c:La_D87512B0;

    .line 3
    iget-object p1, p0, La_B4585AA3;->a:Landroid/view/ActionProvider;
    # ep-uvwtuzdnwcps

    .line 5
    # ep-onjfwmjsbitc
    invoke-virtual {p1, p0}, Landroid/view/ActionProvider;->setVisibilityListener(Landroid/view/ActionProvider$VisibilityListener;)V

    .line 8
    return-void
.end method

    # ep-oxqsjmrbcxqp
.method public final onActionProviderVisibilityChanged(Z)V
    .locals 1

    # ep-hcvoacqakofa
    .line 1
    iget-object p1, p0, La_051C8E07;->c:La_D87512B0;

    .line 3
    if-eqz p1, :cond_0

    .line 5
    check-cast p1, Landroidx/appcompat/view/menu/h$a;

    .line 7
    iget-object p1, p1, Landroidx/appcompat/view/menu/h$a;->a:Landroidx/appcompat/view/menu/h;

    .line 9
    iget-object p1, p1, Landroidx/appcompat/view/menu/h;->n:Landroidx/appcompat/view/menu/f;

    .line 11
    const/4 v0, 0x1

    .line 12
    # ep-cozgfrxyyzpx
    iput-boolean v0, p1, Landroidx/appcompat/view/menu/f;->h:Z

    .line 14
    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/f;->p(Z)V

    .line 17
    :cond_0
    # ep-kwqvzihmyono
    return-void
.end method
