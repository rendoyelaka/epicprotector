.class public final La_862B0935;
# ep-iigpgynprien
.super Ljava/lang/Object;
.source "omlppqnt.java"
# generated-27667
# generated-26688


# instance fields
.field public final a:Landroid/widget/ImageView;

.field public b:Lkv;

.field public c:Lkv;

.field public d:I


# direct methods
.method public constructor <init>(Landroid/widget/ImageView;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, La_862B0935;->d:I

    .line 7
    iput-object p1, p0, La_862B0935;->a:Landroid/widget/ImageView;

    .line 9
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 6

    .line 1
    iget-object v0, p0, La_862B0935;->a:Landroid/widget/ImageView;

    .line 3
    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 6
    move-result-object v1

    .line 7
    if-eqz v1, :cond_0

    .line 9
    invoke-static {v1}, Lwa;->a(Landroid/graphics/drawable/Drawable;)V

    .line 12
    :cond_0
    if-eqz v1, :cond_9

    .line 14
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 16
    const/4 v3, 0x1

    .line 17
    const/4 v4, 0x0

    .line 18
    const/16 v5, 0x15

    .line 20
    if-le v2, v5, :cond_1

    .line 22
    goto :goto_0

    .line 23
    :cond_1
    if-ne v2, v5, :cond_2

    .line 25
    const/4 v2, 0x1

    .line 26
    goto :goto_1

    .line 27
    :cond_2
    :goto_0
    const/4 v2, 0x0

    .line 28
    :goto_1
    if-eqz v2, :cond_8

    .line 30
    iget-object v2, p0, La_862B0935;->c:Lkv;

    .line 32
    if-nez v2, :cond_3

    .line 34
    new-instance v2, Lkv;

    .line 36
    invoke-direct {v2}, Lkv;-><init>()V

    .line 39
    iput-object v2, p0, La_862B0935;->c:Lkv;

    .line 41
    :cond_3
    iget-object v2, p0, La_862B0935;->c:Lkv;

    .line 43
    const/4 v5, 0x0

    .line 44
    iput-object v5, v2, Lkv;->a:Landroid/content/res/ColorStateList;

    .line 46
    iput-boolean v4, v2, Lkv;->d:Z

    .line 48
    iput-object v5, v2, Lkv;->b:Landroid/graphics/PorterDuff$Mode;

    .line 50
    iput-boolean v4, v2, Lkv;->c:Z

    .line 52
    invoke-static {v0}, Luh;->a(Landroid/widget/ImageView;)Landroid/content/res/ColorStateList;

    .line 55
    move-result-object v5

    .line 56
    if-eqz v5, :cond_4

    .line 58
    iput-boolean v3, v2, Lkv;->d:Z

    .line 60
    iput-object v5, v2, Lkv;->a:Landroid/content/res/ColorStateList;

    .line 62
    :cond_4
    invoke-static {v0}, Luh;->b(Landroid/widget/ImageView;)Landroid/graphics/PorterDuff$Mode;

    .line 65
    move-result-object v5

    .line 66
    if-eqz v5, :cond_5

    .line 68
    iput-boolean v3, v2, Lkv;->c:Z

    .line 70
    iput-object v5, v2, Lkv;->b:Landroid/graphics/PorterDuff$Mode;

    .line 72
    :cond_5
    iget-boolean v5, v2, Lkv;->d:Z

    .line 74
    if-nez v5, :cond_7

    .line 76
    iget-boolean v5, v2, Lkv;->c:Z

    .line 78
    if-eqz v5, :cond_6

    .line 80
    goto :goto_2

    .line 81
    :cond_6
    const/4 v3, 0x0

    .line 82
    goto :goto_3

    .line 83
    :cond_7
    :goto_2
    invoke-virtual {v0}, Landroid/view/View;->getDrawableState()[I

    .line 86
    move-result-object v4

    .line 87
    invoke-static {v1, v2, v4}, La_5053E101;->e(Landroid/graphics/drawable/Drawable;Lkv;[I)V

    .line 90
    :goto_3
    if-eqz v3, :cond_8

    .line 92
    return-void

    .line 93
    :cond_8
    iget-object v2, p0, La_862B0935;->b:Lkv;

    .line 95
    if-eqz v2, :cond_9

    .line 97
    invoke-virtual {v0}, Landroid/view/View;->getDrawableState()[I

    .line 100
    move-result-object v0

    .line 101
    invoke-static {v1, v2, v0}, La_5053E101;->e(Landroid/graphics/drawable/Drawable;Lkv;[I)V

    .line 104
    :cond_9
    return-void
.end method

.method public final b(Landroid/util/AttributeSet;I)V
    .locals 8

    .line 1
    iget-object v6, p0, La_862B0935;->a:Landroid/widget/ImageView;

    .line 3
    invoke-virtual {v6}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    .line 6
    move-result-object v0

    .line 7
    sget-object v2, La_F5C4F8D6;->f_38055503:[I

    .line 9
    invoke-static {v0, p1, v2, p2}, Lmv;->m(Landroid/content/Context;Landroid/util/AttributeSet;[II)Lmv;

    .line 12
    move-result-object v7

    .line 13
    invoke-virtual {v6}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    .line 16
    move-result-object v1

    .line 17
    iget-object v4, v7, Lmv;->b:Landroid/content/res/TypedArray;

    .line 19
    move-object v0, v6

    .line 20
    move-object v3, p1

    .line 21
    move v5, p2

    .line 22
    invoke-static/range {v0 .. v5}, Lqx;->o(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;I)V

    .line 25
    :try_start_0
    invoke-virtual {v6}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 28
    move-result-object p1

    .line 29
    const/4 p2, -0x1

    .line 30
    if-nez p1, :cond_0

    .line 32
    const/4 v0, 0x1

    .line 33
    invoke-virtual {v7, v0, p2}, Lmv;->i(II)I

    .line 36
    move-result v0

    .line 37
    if-eq v0, p2, :cond_0

    .line 39
    invoke-virtual {v6}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    .line 42
    move-result-object p1

    .line 43
    invoke-static {p1, v0}, La_F5C4F8D6;->m_7bf4cde2(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 46
    move-result-object p1

    .line 47
    if-eqz p1, :cond_0

    .line 49
    invoke-virtual {v6, p1}, Landroid/widget/ImageView;->m_c591b61f(Landroid/graphics/drawable/Drawable;)V

    .line 52
    :cond_0
    if-eqz p1, :cond_1

    .line 54
    invoke-static {p1}, Lwa;->a(Landroid/graphics/drawable/Drawable;)V

    .line 57
    :cond_1
    const/4 p1, 0x2

    .line 58
    invoke-virtual {v7, p1}, Lmv;->l(I)Z

    .line 61
    move-result v0

    .line 62
    const/16 v1, 0x15

    .line 64
    if-eqz v0, :cond_3

    .line 66
    invoke-virtual {v7, p1}, Lmv;->b(I)Landroid/content/res/ColorStateList;

    .line 69
    move-result-object p1

    .line 70
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 72
    invoke-static {v6, p1}, Luh;->c(Landroid/widget/ImageView;Landroid/content/res/ColorStateList;)V

    .line 75
    if-ne v0, v1, :cond_3

    .line 77
    invoke-virtual {v6}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 80
    move-result-object p1

    .line 81
    if-eqz p1, :cond_3

    .line 83
    invoke-static {v6}, Luh;->a(Landroid/widget/ImageView;)Landroid/content/res/ColorStateList;

    .line 86
    move-result-object v0

    .line 87
    if-eqz v0, :cond_3

    .line 89
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->m_2b4a0a7e()Z

    .line 92
    move-result v0

    .line 93
    if-eqz v0, :cond_2

    .line 95
    invoke-virtual {v6}, Landroid/view/View;->getDrawableState()[I

    .line 98
    move-result-object v0

    .line 99
    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->m_17d85843([I)Z

    .line 102
    :cond_2
    invoke-virtual {v6, p1}, Landroid/widget/ImageView;->m_c591b61f(Landroid/graphics/drawable/Drawable;)V

    .line 105
    :cond_3
    const/4 p1, 0x3

    .line 106
    invoke-virtual {v7, p1}, Lmv;->l(I)Z

    .line 109
    move-result v0

    .line 110
    if-eqz v0, :cond_5

    .line 112
    invoke-virtual {v7, p1, p2}, Lmv;->h(II)I

    .line 115
    move-result p1

    .line 116
    const/4 p2, 0x0

    .line 117
    invoke-static {p1, p2}, Lwa;->b(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    .line 120
    move-result-object p1

    .line 121
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 123
    invoke-static {v6, p1}, Luh;->d(Landroid/widget/ImageView;Landroid/graphics/PorterDuff$Mode;)V

    .line 126
    if-ne p2, v1, :cond_5

    .line 128
    invoke-virtual {v6}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 131
    move-result-object p1

    .line 132
    if-eqz p1, :cond_5

    .line 134
    invoke-static {v6}, Luh;->a(Landroid/widget/ImageView;)Landroid/content/res/ColorStateList;

    .line 137
    move-result-object p2

    .line 138
    if-eqz p2, :cond_5

    .line 140
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->m_2b4a0a7e()Z

    .line 143
    move-result p2

    .line 144
    if-eqz p2, :cond_4

    .line 146
    invoke-virtual {v6}, Landroid/view/View;->getDrawableState()[I

    .line 149
    move-result-object p2

    .line 150
    invoke-virtual {p1, p2}, Landroid/graphics/drawable/Drawable;->m_17d85843([I)Z

    .line 153
    :cond_4
    invoke-virtual {v6, p1}, Landroid/widget/ImageView;->m_c591b61f(Landroid/graphics/drawable/Drawable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 156
    :cond_5
    invoke-virtual {v7}, Lmv;->n()V

    .line 159
    return-void

    .line 160
    :catchall_0
    move-exception p1

    .line 161
    invoke-virtual {v7}, Lmv;->n()V

    .line 164
    throw p1
.end method

.method public final c(I)V
    .locals 2

    .line 1
    iget-object v0, p0, La_862B0935;->a:Landroid/widget/ImageView;

    .line 3
    if-eqz p1, :cond_1

    .line 5
    invoke-virtual {v0}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    .line 8
    move-result-object v1

    .line 9
    invoke-static {v1, p1}, La_F5C4F8D6;->m_7bf4cde2(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 12
    move-result-object p1

    .line 13
    if-eqz p1, :cond_0

    .line 15
    invoke-static {p1}, Lwa;->a(Landroid/graphics/drawable/Drawable;)V

    .line 18
    :cond_0
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->m_c591b61f(Landroid/graphics/drawable/Drawable;)V

    .line 21
    goto :goto_0

    .line 22
    :cond_1
    const/4 p1, 0x0

    .line 23
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->m_c591b61f(Landroid/graphics/drawable/Drawable;)V

    .line 26
    :goto_0
    invoke-virtual {p0}, La_862B0935;->a()V

    .line 29
    return-void
.end method
