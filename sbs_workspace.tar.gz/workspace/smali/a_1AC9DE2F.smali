.class public final La_1AC9DE2F;
.super Ljava/lang/Object;
.source "flnqluyq.java"
# optimised-65397
# compiled-70983

# interfaces
.implements La_6B7A69F9;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field public final a:[La_09321C45;


# direct methods
.method public constructor <init>([La_09321C45;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_1AC9DE2F;->a:[La_09321C45;

    .line 6
    return-void
.end method
