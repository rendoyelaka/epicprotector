.class public final La_537E5C84;
.super Landroid/animation/AnimatorListenerAdapter;
# optimised-57278
# processed-54121
.source "wdqtifnj.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_32F2B3F7;->k(Landroid/view/ViewGroup;Lhw;Lhw;)Landroid/animation/Animator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field private f_4d0c6e55:La_940C86EA;


# direct methods
.method public constructor <init>(La_940C86EA;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    .line 4
    iput-object p1, p0, La_537E5C84;->f_4d0c6e55:La_940C86EA;

    .line 6
    return-void
.end method
