.class public final La_8502CFDB;
.super La_809F6E05;
.source "xsstiivi.java"

# ep-ahfhoxtjroca
# validated-27954
# verified-38581
# generated-93696

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lf;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "g"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_809F6E05;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lf;La_DF069E47;La_DF069E47;)Z
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lf<",
            "*>;",
            "La_DF069E47;",
            "La_DF069E47;",
            ")Z"
        }
    .end annotation

    .line 1
    monitor-enter p1

    .line 2
    :try_start_0
    iget-object v0, p1, Lf;->d:La_DF069E47;

    .line 4
    if-ne v0, p2, :cond_0

    .line 6
    iput-object p3, p1, Lf;->d:La_DF069E47;

    .line 8
    monitor-exit p1

    .line 9
    const/4 p1, 0x1

    .line 10
    return p1

    .line 11
    :cond_0
    monitor-exit p1

    .line 12
    const/4 p1, 0x0

    .line 13
    return p1

    .line 14
    :catchall_0
    move-exception p2

    .line 15
    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 16
    throw p2
.end method

.method public final b(Lf;Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lf<",
            "*>;",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ")Z"
        }
    .end annotation

    .line 1
    monitor-enter p1

    .line 2
    :try_start_0
    iget-object v0, p1, Lf;->c:Ljava/lang/Object;

    .line 4
    if-ne v0, p2, :cond_0

    .line 6
    iput-object p3, p1, Lf;->c:Ljava/lang/Object;

    .line 8
    monitor-exit p1

    .line 9
    const/4 p1, 0x1

    .line 10
    return p1

    .line 11
    :cond_0
    monitor-exit p1

    .line 12
    const/4 p1, 0x0

    .line 13
    return p1

    .line 14
    :catchall_0
    move-exception p2

    .line 15
    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 16
    throw p2
.end method

.method public final c(Lf;La_D09ED89B;La_D09ED89B;)Z
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lf<",
            "*>;",
            "La_D09ED89B;",
            "La_D09ED89B;",
            ")Z"
        }
    .end annotation

    .line 1
    monitor-enter p1

    .line 2
    :try_start_0
    iget-object v0, p1, Lf;->e:La_D09ED89B;

    .line 4
    if-ne v0, p2, :cond_0

    .line 6
    iput-object p3, p1, Lf;->e:La_D09ED89B;

    .line 8
    monitor-exit p1

    .line 9
    const/4 p1, 0x1

    .line 10
    return p1

    .line 11
    :cond_0
    monitor-exit p1

    .line 12
    const/4 p1, 0x0

    .line 13
    return p1

    .line 14
    :catchall_0
    move-exception p2

    .line 15
    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 16
    throw p2
.end method

.method public final d(La_D09ED89B;La_D09ED89B;)V
    .locals 0

    iput-object p2, p1, La_D09ED89B;->b:La_D09ED89B;

    return-void
.end method

.method public final e(La_D09ED89B;Ljava/lang/Thread;)V
    .locals 0

    iput-object p2, p1, La_D09ED89B;->a:Ljava/lang/Thread;

    return-void
.end method
