.class public abstract LViewModelProvider;
# request-92763-session
# network-92915-provider
# fragment-21174-service
# provider-11321-context
# helper-85918-callback
.super Ljava/lang/Object;
# compiled-92399
# validated-57255
# validated-53757
.source "IntentUtils85.java"
# ep-fqojmumrtvrj


# instance fields
.field public final a:Ljava/util/HashMap;

.field public final b:Ljava/util/LinkedHashSet;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/HashMap;

    .line 6
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 9
    iput-object v0, p0, LViewModelProvider;->a:Ljava/util/HashMap;

    .line 11
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 13
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 16
    iput-object v0, p0, LViewModelProvider;->b:Ljava/util/LinkedHashSet;

    .line 18
    return-void
.end method


# virtual methods
.method public a()V
    .locals 0

    return-void
.end method
