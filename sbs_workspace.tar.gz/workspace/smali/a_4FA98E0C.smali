.class public final La_4FA98E0C;
.super Ljava/lang/Object;
.source "ftaisjzx.java"


# optimised-20021
# verified-82655
# verified-89382
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lyr;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# static fields
.field public static final a:Lyr;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Lyr;

    invoke-direct {v0}, Lyr;-><init>()V

    sput-object v0, La_4FA98E0C;->a:Lyr;

    return-void
.end method
