.class public final La_36232B78;
.super Ljava/lang/Object;
.source "xcjelhsq.java"

# optimised-91299
# generated-74862
# optimised-16429
# ep-mrsxmsdukgtw
# interfaces
.implements Ly;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;


# direct methods
.method public constructor <init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;I)V
    .locals 0

    iput-object p1, p0, La_36232B78;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    iput p2, p0, La_36232B78;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;)Z
    .locals 1

    iget-object p1, p0, La_36232B78;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    iget v0, p0, La_36232B78;->a:I

    invoke-virtual {p1, v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->m_d26d803e(I)V

    const/4 p1, 0x1

    return p1
.end method
