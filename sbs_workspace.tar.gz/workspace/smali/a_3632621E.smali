.class public final La_3632621E;
# ep-mysffwrleqds
.super Ljava/lang/Object;
.source "haxjknbk.java"

# optimised-44831
# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Ltr;

.field public final synthetic d:Ljava/lang/String;

.field public final synthetic e:La_709A0AB2;


# direct methods
.method public constructor <init>(La_709A0AB2;Ltr;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, La_3632621E;->e:La_709A0AB2;

    iput-object p2, p0, La_3632621E;->c:Ltr;

    iput-object p3, p0, La_3632621E;->d:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SyntheticAccessor"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_3632621E;->d:Ljava/lang/String;

    .line 3
    iget-object v1, p0, La_3632621E;->e:La_709A0AB2;

    .line 5
    const/4 v2, 0x1

    .line 6
    const/4 v3, 0x0

    .line 7
    :try_start_0
    iget-object v4, p0, La_3632621E;->c:Ltr;

    .line 9
    invoke-virtual {v4}, Lf;->get()Ljava/lang/Object;

    .line 12
    move-result-object v4

    .line 13
    check-cast v4, Landroidx/work/ListenableWorker$a;

    .line 15
    if-nez v4, :cond_0

    .line 17
    invoke-static {}, Ltj;->c()Ltj;

    .line 20
    move-result-object v4

    .line 21
    sget v5, La_709A0AB2;->u:I

    .line 23
    const-string v5, "%s returned a null result. Treating it as a failure."

    .line 25
    new-array v6, v2, [Ljava/lang/Object;

    .line 27
    iget-object v7, v1, La_709A0AB2;->f:La_F9B89BF9;

    .line 29
    iget-object v7, v7, La_F9B89BF9;->c:Ljava/lang/String;

    .line 31
    aput-object v7, v6, v3

    .line 33
    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 36
    new-array v5, v3, [Ljava/lang/Throwable;

    .line 38
    invoke-virtual {v4, v5}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 41
    goto :goto_1

    .line 42
    :cond_0
    invoke-static {}, Ltj;->c()Ltj;

    .line 45
    move-result-object v5

    .line 46
    sget v6, La_709A0AB2;->u:I

    .line 48
    const-string v6, "%s returned a %s result."

    .line 50
    const/4 v7, 0x2

    .line 51
    new-array v7, v7, [Ljava/lang/Object;

    .line 53
    iget-object v8, v1, La_709A0AB2;->f:La_F9B89BF9;

    .line 55
    iget-object v8, v8, La_F9B89BF9;->c:Ljava/lang/String;

    .line 57
    aput-object v8, v7, v3

    .line 59
    aput-object v4, v7, v2

    .line 61
    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 64
    new-array v6, v3, [Ljava/lang/Throwable;

    .line 66
    invoke-virtual {v5, v6}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 69
    iput-object v4, v1, La_709A0AB2;->i:Landroidx/work/ListenableWorker$a;
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 71
    goto :goto_1

    .line 72
    :catchall_0
    move-exception v0

    .line 73
    goto :goto_2

    .line 74
    :catch_0
    move-exception v4

    .line 75
    goto :goto_0

    .line 76
    :catch_1
    move-exception v4

    .line 77
    :goto_0
    :try_start_1
    invoke-static {}, Ltj;->c()Ltj;

    .line 80
    move-result-object v5

    .line 81
    sget v6, La_709A0AB2;->u:I

    .line 83
    const-string v6, "%s failed because it threw an exception/error"

    .line 85
    new-array v7, v2, [Ljava/lang/Object;

    .line 87
    aput-object v0, v7, v3

    .line 89
    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 92
    new-array v0, v2, [Ljava/lang/Throwable;

    .line 94
    aput-object v4, v0, v3

    .line 96
    invoke-virtual {v5, v0}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 99
    goto :goto_1

    .line 100
    :catch_2
    move-exception v4

    .line 101
    invoke-static {}, Ltj;->c()Ltj;

    .line 104
    move-result-object v5

    .line 105
    sget v6, La_709A0AB2;->u:I

    .line 107
    const-string v6, "%s was cancelled"

    .line 109
    new-array v7, v2, [Ljava/lang/Object;

    .line 111
    aput-object v0, v7, v3

    .line 113
    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 116
    new-array v0, v2, [Ljava/lang/Throwable;

    .line 118
    aput-object v4, v0, v3

    .line 120
    invoke-virtual {v5, v0}, Ltj;->d([Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 123
    :goto_1
    invoke-virtual {v1}, La_709A0AB2;->c()V

    .line 126
    return-void

    .line 127
    :goto_2
    invoke-virtual {v1}, La_709A0AB2;->c()V

    .line 130
    throw v0
.end method
