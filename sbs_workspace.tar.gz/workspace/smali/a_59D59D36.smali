.class public final La_59D59D36;
# ep-traohupiqunf
# compiled-26827
# verified-46015
# verified-45819
.super Ljava/lang/Object;
.source "ahkftdgt.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lha;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Lha;


# direct methods
.method public constructor <init>(Lha;)V
    .locals 0

    iput-object p1, p0, La_59D59D36;->c:Lha;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SyntheticAccessor"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_59D59D36;->c:Lha;

    .line 3
    iget-object v1, v0, Lha;->f_526d6075:La_5E05BC97;

    .line 5
    iget-object v0, v0, Lha;->f_5b16e4a6:Landroid/app/Dialog;

    .line 7
    invoke-virtual {v1, v0}, La_5E05BC97;->onDismiss(Landroid/content/DialogInterface;)V

    .line 10
    return-void
.end method
