.class public final Lb5;
.super Ljava/lang/Object;
.source "jydbrlyb.java"
# ep-jxnadramujcd

# validated-46918
# validated-92392

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lb5$a;
    }
.end annotation


# instance fields
.field public final a:Z

.field public final b:Z

.field public final c:I

.field public final d:I

.field public final e:Z

.field public final f:Z

.field public final g:Z

.field public final h:I

.field public final i:I

.field public final j:Z

.field public final k:Z

.field public l:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    .line 1
    new-instance v0, Lb5$a;

    .line 3
    invoke-direct {v0}, Lb5$a;-><init>()V

    .line 6
    const/4 v1, 0x1

    .line 7
    iput-boolean v1, v0, Lb5$a;->a:Z

    .line 9
    new-instance v2, Lb5;

    .line 11
    invoke-direct {v2, v0}, Lb5;-><init>(Lb5$a;)V

    .line 14
    new-instance v0, Lb5$a;

    .line 16
    invoke-direct {v0}, Lb5$a;-><init>()V

    .line 19
    iput-boolean v1, v0, Lb5$a;->c:Z

    .line 21
    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 23
    const v2, 0x7fffffff

    .line 26
    int-to-long v3, v2

    .line 27
    invoke-virtual {v1, v3, v4}, Ljava/util/concurrent/TimeUnit;->toSeconds(J)J

    .line 30
    move-result-wide v3

    .line 31
    const-wide/32 v5, 0x7fffffff

    .line 34
    cmp-long v1, v3, v5

    .line 36
    if-lez v1, :cond_0

    .line 38
    goto :goto_0

    .line 39
    :cond_0
    long-to-int v2, v3

    .line 40
    :goto_0
    iput v2, v0, Lb5$a;->b:I

    .line 42
    new-instance v1, Lb5;

    .line 44
    invoke-direct {v1, v0}, Lb5;-><init>(Lb5$a;)V

    .line 47
    return-void
.end method

.method public constructor <init>(Lb5$a;)V
    .locals 3

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 15
    iget-boolean v0, p1, Lb5$a;->a:Z

    iput-boolean v0, p0, Lb5;->a:Z

    const/4 v0, 0x0

    .line 16
    iput-boolean v0, p0, Lb5;->b:Z

    const/4 v1, -0x1

    .line 17
    iput v1, p0, Lb5;->c:I

    .line 18
    iput v1, p0, Lb5;->d:I

    .line 19
    iput-boolean v0, p0, Lb5;->e:Z

    .line 20
    iput-boolean v0, p0, Lb5;->f:Z

    .line 21
    iput-boolean v0, p0, Lb5;->g:Z

    .line 22
    iget v2, p1, Lb5$a;->b:I

    iput v2, p0, Lb5;->h:I

    .line 23
    iput v1, p0, Lb5;->i:I

    .line 24
    iget-boolean p1, p1, Lb5$a;->c:Z

    iput-boolean p1, p0, Lb5;->j:Z

    .line 25
    iput-boolean v0, p0, Lb5;->k:Z

    return-void
.end method

.method public constructor <init>(ZZIIZZZIIZZLjava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-boolean p1, p0, Lb5;->a:Z

    .line 3
    iput-boolean p2, p0, Lb5;->b:Z

    .line 4
    iput p3, p0, Lb5;->c:I

    .line 5
    iput p4, p0, Lb5;->d:I

    .line 6
    iput-boolean p5, p0, Lb5;->e:Z

    .line 7
    iput-boolean p6, p0, Lb5;->f:Z

    .line 8
    iput-boolean p7, p0, Lb5;->g:Z

    .line 9
    iput p8, p0, Lb5;->h:I

    .line 10
    iput p9, p0, Lb5;->i:I

    .line 11
    iput-boolean p10, p0, Lb5;->j:Z

    .line 12
    iput-boolean p11, p0, Lb5;->k:Z

    .line 13
    iput-object p12, p0, Lb5;->l:Ljava/lang/String;

    return-void
.end method

.method public static a(Ljg;)Lb5;
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v1, v0, Ljg;->a:[Ljava/lang/String;

    .line 5
    array-length v1, v1

    .line 6
    div-int/lit8 v1, v1, 0x2

    .line 8
    const/4 v6, 0x0

    .line 9
    const/4 v7, 0x1

    .line 10
    const/4 v8, 0x0

    .line 11
    const/4 v9, 0x0

    .line 12
    const/4 v10, 0x0

    .line 13
    const/4 v11, -0x1

    .line 14
    const/4 v12, -0x1

    .line 15
    const/4 v13, 0x0

    .line 16
    const/4 v14, 0x0

    .line 17
    const/4 v15, 0x0

    .line 18
    const/16 v16, -0x1

    .line 20
    const/16 v17, -0x1

    .line 22
    const/16 v18, 0x0

    .line 24
    const/16 v19, 0x0

    .line 26
    :goto_0
    if-ge v6, v1, :cond_12

    .line 28
    invoke-virtual {v0, v6}, Ljg;->b(I)Ljava/lang/String;

    .line 31
    move-result-object v2

    .line 32
    invoke-virtual {v0, v6}, Ljg;->d(I)Ljava/lang/String;

    .line 35
    move-result-object v5

    .line 36
    const-string v3, "Cache-Control"

    .line 38
    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 41
    move-result v3

    .line 42
    if-eqz v3, :cond_1

    .line 44
    if-eqz v8, :cond_0

    .line 46
    goto :goto_1

    .line 47
    :cond_0
    move-object v8, v5

    .line 48
    goto :goto_2

    .line 49
    :cond_1
    const-string v3, "Pragma"

    .line 51
    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 54
    move-result v2

    .line 55
    if-eqz v2, :cond_11

    .line 57
    :goto_1
    const/4 v7, 0x0

    .line 58
    :goto_2
    const/4 v2, 0x0

    .line 59
    :goto_3
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 62
    move-result v3

    .line 63
    if-ge v2, v3, :cond_11

    .line 65
    const-string v3, "=,;"

    .line 67
    invoke-static {v2, v5, v3}, Lhh;->e(ILjava/lang/String;Ljava/lang/String;)I

    .line 70
    move-result v3

    .line 71
    invoke-virtual {v5, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 74
    move-result-object v2

    .line 75
    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 78
    move-result-object v2

    .line 79
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 82
    move-result v4

    .line 83
    if-eq v3, v4, :cond_5

    .line 85
    invoke-virtual {v5, v3}, Ljava/lang/String;->charAt(I)C

    .line 88
    move-result v4

    .line 89
    const/16 v0, 0x2c

    .line 91
    if-eq v4, v0, :cond_5

    .line 93
    invoke-virtual {v5, v3}, Ljava/lang/String;->charAt(I)C

    .line 96
    move-result v0

    .line 97
    const/16 v4, 0x3b

    .line 99
    if-ne v0, v4, :cond_2

    .line 101
    goto :goto_6

    .line 102
    :goto_4
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 105
    move-result v0

    .line 106
    if-ge v3, v0, :cond_3

    .line 108
    invoke-virtual {v5, v3}, Ljava/lang/String;->charAt(I)C

    .line 111
    move-result v0

    .line 112
    const/16 v4, 0x20

    .line 114
    if-eq v0, v4, :cond_2

    .line 116
    const/16 v4, 0x9

    .line 118
    if-eq v0, v4, :cond_2

    .line 120
    goto :goto_5

    .line 121
    :cond_2
    add-int/lit8 v3, v3, 0x1

    .line 123
    goto :goto_4

    .line 124
    :cond_3
    :goto_5
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 127
    move-result v0

    .line 128
    if-ge v3, v0, :cond_4

    .line 130
    invoke-virtual {v5, v3}, Ljava/lang/String;->charAt(I)C

    .line 133
    move-result v0

    .line 134
    const/16 v4, 0x22

    .line 136
    if-ne v0, v4, :cond_4

    .line 138
    add-int/lit8 v3, v3, 0x1

    .line 140
    const-string v0, "\""

    .line 142
    invoke-static {v3, v5, v0}, Lhh;->e(ILjava/lang/String;Ljava/lang/String;)I

    .line 145
    move-result v0

    .line 146
    invoke-virtual {v5, v3, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 149
    move-result-object v3

    .line 150
    const/4 v4, 0x1

    .line 151
    add-int/2addr v0, v4

    .line 152
    goto :goto_7

    .line 153
    :cond_4
    const/4 v4, 0x1

    .line 154
    const-string v0, ",;"

    .line 156
    invoke-static {v3, v5, v0}, Lhh;->e(ILjava/lang/String;Ljava/lang/String;)I

    .line 159
    move-result v0

    .line 160
    invoke-virtual {v5, v3, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 163
    move-result-object v3

    .line 164
    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 167
    move-result-object v3

    .line 168
    goto :goto_7

    .line 169
    :cond_5
    :goto_6
    const/4 v4, 0x1

    .line 170
    add-int/lit8 v3, v3, 0x1

    .line 172
    move v0, v3

    .line 173
    const/4 v3, 0x0

    .line 174
    :goto_7
    const-string v4, "no-cache"

    .line 176
    invoke-virtual {v4, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 179
    move-result v4

    .line 180
    if-eqz v4, :cond_6

    .line 182
    const/4 v4, -0x1

    .line 183
    const/4 v9, 0x1

    .line 184
    goto/16 :goto_8

    .line 186
    :cond_6
    const-string v4, "no-store"

    .line 188
    invoke-virtual {v4, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 191
    move-result v4

    .line 192
    if-eqz v4, :cond_7

    .line 194
    const/4 v4, -0x1

    .line 195
    const/4 v10, 0x1

    .line 196
    goto/16 :goto_8

    .line 198
    :cond_7
    const-string v4, "max-age"

    .line 200
    invoke-virtual {v4, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 203
    move-result v4

    .line 204
    if-eqz v4, :cond_8

    .line 206
    const/4 v4, -0x1

    .line 207
    invoke-static {v3, v4}, Lhh;->c(Ljava/lang/String;I)I

    .line 210
    move-result v11

    .line 211
    goto :goto_8

    .line 212
    :cond_8
    const-string v4, "s-maxage"

    .line 214
    invoke-virtual {v4, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 217
    move-result v4

    .line 218
    if-eqz v4, :cond_9

    .line 220
    const/4 v4, -0x1

    .line 221
    invoke-static {v3, v4}, Lhh;->c(Ljava/lang/String;I)I

    .line 224
    move-result v12

    .line 225
    goto :goto_8

    .line 226
    :cond_9
    const-string v4, "private"

    .line 228
    invoke-virtual {v4, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 231
    move-result v4

    .line 232
    if-eqz v4, :cond_a

    .line 234
    const/4 v4, -0x1

    .line 235
    const/4 v13, 0x1

    .line 236
    goto :goto_8

    .line 237
    :cond_a
    const-string v4, "public"

    .line 239
    invoke-virtual {v4, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 242
    move-result v4

    .line 243
    if-eqz v4, :cond_b

    .line 245
    const/4 v4, -0x1

    .line 246
    const/4 v14, 0x1

    .line 247
    goto :goto_8

    .line 248
    :cond_b
    const-string v4, "must-revalidate"

    .line 250
    invoke-virtual {v4, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 253
    move-result v4

    .line 254
    if-eqz v4, :cond_c

    .line 256
    const/4 v4, -0x1

    .line 257
    const/4 v15, 0x1

    .line 258
    goto :goto_8

    .line 259
    :cond_c
    const-string v4, "max-stale"

    .line 261
    invoke-virtual {v4, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 264
    move-result v4

    .line 265
    if-eqz v4, :cond_d

    .line 267
    const v2, 0x7fffffff

    .line 270
    invoke-static {v3, v2}, Lhh;->c(Ljava/lang/String;I)I

    .line 273
    move-result v16

    .line 274
    const/4 v4, -0x1

    .line 275
    goto :goto_8

    .line 276
    :cond_d
    const-string v4, "min-fresh"

    .line 278
    invoke-virtual {v4, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 281
    move-result v4

    .line 282
    if-eqz v4, :cond_e

    .line 284
    const/4 v4, -0x1

    .line 285
    invoke-static {v3, v4}, Lhh;->c(Ljava/lang/String;I)I

    .line 288
    move-result v17

    .line 289
    goto :goto_8

    .line 290
    :cond_e
    const/4 v4, -0x1

    .line 291
    const-string v3, "only-if-cached"

    .line 293
    invoke-virtual {v3, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 296
    move-result v3

    .line 297
    if-eqz v3, :cond_f

    .line 299
    const/16 v18, 0x1

    .line 301
    goto :goto_8

    .line 302
    :cond_f
    const-string v3, "no-transform"

    .line 304
    invoke-virtual {v3, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 307
    move-result v2

    .line 308
    if-eqz v2, :cond_10

    .line 310
    const/16 v19, 0x1

    .line 312
    :cond_10
    :goto_8
    move v2, v0

    .line 313
    move-object/from16 v0, p0

    .line 315
    goto/16 :goto_3

    .line 317
    :cond_11
    const/4 v4, -0x1

    .line 318
    add-int/lit8 v6, v6, 0x1

    .line 320
    move-object/from16 v0, p0

    .line 322
    goto/16 :goto_0

    .line 324
    :cond_12
    if-nez v7, :cond_13

    .line 326
    const/16 v20, 0x0

    .line 328
    goto :goto_9

    .line 329
    :cond_13
    move-object/from16 v20, v8

    .line 331
    :goto_9
    new-instance v0, Lb5;

    .line 333
    move-object v8, v0

    .line 334
    invoke-direct/range {v8 .. v20}, Lb5;-><init>(ZZIIZZZIIZZLjava/lang/String;)V

    .line 337
    return-object v0
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 16

    .line 1
    iget-object v0, p0, Lb5;->l:Ljava/lang/String;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    goto/16 :goto_1

    .line 7
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 9
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 12
    iget-boolean v1, p0, Lb5;->a:Z

    .line 14
    if-eqz v1, :cond_1

    .line 16
    const-string v1,new-instance v15, Ljava/lang/StringBuilder;
    const-string v1,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v1,const-string v1, "no"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "-cac"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "he, "
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v1,move-result-object v1

    .line 18
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    :cond_1
    iget-boolean v1, p0, Lb5;->b:Z

    .line 23
    if-eqz v1, :cond_2

    .line 25
    const-string v1,new-instance v15, Ljava/lang/StringBuilder;
    const-string v1,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v1,const-string v1, "no-"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "st"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "ore, "
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v1,move-result-object v1

    .line 27
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    :cond_2
    iget v1, p0, Lb5;->c:I

    .line 32
    const-string v2, ", "

    .line 34
    const/4 v3, -0x1

    .line 35
    if-eq v1, v3, :cond_3

    .line 37
    const-string v4,new-instance v15, Ljava/lang/StringBuilder;
    const-string v4,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v4,const-string v4, "max"
    const-string v4,invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v4,const-string v4, "-age="
    const-string v4,invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v4,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v4,move-result-object v4

    .line 39
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 42
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 45
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 48
    :cond_3
    iget v1, p0, Lb5;->d:I

    .line 50
    if-eq v1, v3, :cond_4

    .line 52
    const-string v4,new-instance v15, Ljava/lang/StringBuilder;
    const-string v4,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v4,const-string v4, "s-"
    const-string v4,invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v4,const-string v4, "maxa"
    const-string v4,invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v4,const-string v4, "ge="
    const-string v4,invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v4,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v4,move-result-object v4

    .line 54
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 57
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 60
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    :cond_4
    iget-boolean v1, p0, Lb5;->e:Z

    .line 65
    if-eqz v1, :cond_5

    .line 67
    const-string v1,new-instance v15, Ljava/lang/StringBuilder;
    const-string v1,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v1,const-string v1, "pr"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "iv"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "ate, "
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v1,move-result-object v1

    .line 69
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    :cond_5
    iget-boolean v1, p0, Lb5;->f:Z

    .line 74
    if-eqz v1, :cond_6

    .line 76
    const-string v1,new-instance v15, Ljava/lang/StringBuilder;
    const-string v1,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v1,const-string v1, "p"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "ublic, "
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v1,move-result-object v1

    .line 78
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 81
    :cond_6
    iget-boolean v1, p0, Lb5;->g:Z

    .line 83
    if-eqz v1, :cond_7

    .line 85
    const-string v1,new-instance v15, Ljava/lang/StringBuilder;
    const-string v1,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v1,const-string v1, "mu"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "st-revali"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "date, "
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v1,move-result-object v1

    .line 87
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 90
    :cond_7
    iget v1, p0, Lb5;->h:I

    .line 92
    if-eq v1, v3, :cond_8

    .line 94
    const-string v4,new-instance v15, Ljava/lang/StringBuilder;
    const-string v4,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v4,const-string v4, "ma"
    const-string v4,invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v4,const-string v4, "x-st"
    const-string v4,invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v4,const-string v4, "ale="
    const-string v4,invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v4,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v4,move-result-object v4

    .line 96
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 99
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 102
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 105
    :cond_8
    iget v1, p0, Lb5;->i:I

    .line 107
    if-eq v1, v3, :cond_9

    .line 109
    const-string v3,new-instance v15, Ljava/lang/StringBuilder;
    const-string v3,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v3,const-string v3, "mi"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,const-string v3, "n-"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,const-string v3, "fresh="
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v3,move-result-object v3

    .line 111
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 114
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 117
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 120
    :cond_9
    iget-boolean v1, p0, Lb5;->j:Z

    .line 122
    if-eqz v1, :cond_a

    .line 124
    const-string v1,new-instance v15, Ljava/lang/StringBuilder;
    const-string v1,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v1,const-string v1, "on"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "ly-if-"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "cached, "
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v1,move-result-object v1

    .line 126
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 129
    :cond_a
    iget-boolean v1, p0, Lb5;->k:Z

    .line 131
    if-eqz v1, :cond_b

    .line 133
    const-string v1,new-instance v15, Ljava/lang/StringBuilder;
    const-string v1,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v1,const-string v1, "no"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "-tra"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "nsform, "
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v1,move-result-object v1

    .line 135
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 138
    :cond_b
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    .line 141
    move-result v1

    .line 142
    if-nez v1, :cond_c

    .line 144
    const-string v0, ""

    .line 146
    goto :goto_0

    .line 147
    :cond_c
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    .line 150
    move-result v1

    .line 151
    add-int/lit8 v1, v1, -0x2

    .line 153
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    .line 156
    move-result v2

    .line 157
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->delete(II)Ljava/lang/StringBuilder;

    .line 160
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 163
    move-result-object v0

    .line 164
    :goto_0
    iput-object v0, p0, Lb5;->l:Ljava/lang/String;

    .line 166
    :goto_1
    return-object v0
.end method
