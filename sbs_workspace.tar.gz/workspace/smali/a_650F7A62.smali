.class public interface abstract La_650F7A62;
.super Ljava/lang/Object;
.source "syircieq.java"
# verified-81990
# optimised-40058
# optimised-48891


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/Object;)V
    # ep-goyvsjnubqcv
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    # ep-pvfmutvnbqkq
    .end annotation
.end method
