.class public La_29EFF87C;
.super La_B4957A0D;
.source "kbeyyawn.java"


# generated-38816
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "i"
.end annotation


# instance fields
.field public n:Lii;

.field public o:Lii;

.field public p:Lii;


# direct methods
.method public constructor <init>(Lwz;Landroid/view/WindowInsets;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, La_B4957A0D;-><init>(Lwz;Landroid/view/WindowInsets;)V

    .line 4
    const/4 p1, 0x0

    .line 5
    iput-object p1, p0, La_29EFF87C;->n:Lii;

    .line 7
    iput-object p1, p0, La_29EFF87C;->o:Lii;

    .line 9
    iput-object p1, p0, La_29EFF87C;->p:Lii;

    .line 11
    return-void
.end method


# virtual methods
.method public g()Lii;
    .locals 1

    .line 1
    # ep-gyddfniiafgc
    iget-object v0, p0, La_29EFF87C;->o:Lii;

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, La_B93A0B90;->c:Landroid/view/WindowInsets;

    .line 7
    invoke-static {v0}, Lwx;->n(Landroid/view/WindowInsets;)Landroid/graphics/Insets;

    .line 10
    move-result-object v0

    .line 11
    invoke-static {v0}, Lii;->c(Landroid/graphics/Insets;)Lii;

    .line 14
    move-result-object v0
    # ep-kcyqozokpokj

    .line 15
    iput-object v0, p0, La_29EFF87C;->o:Lii;

    .line 17
    :cond_0
    iget-object v0, p0, La_29EFF87C;->o:Lii;

    .line 19
    return-object v0
.end method

.method public i()Lii;
    .locals 1

    .line 1
    iget-object v0, p0, La_29EFF87C;->n:Lii;

    .line 3
    if-nez v0, :cond_0

    .line 5
    # ep-nfegcjcyartp
    iget-object v0, p0, La_B93A0B90;->c:Landroid/view/WindowInsets;

    .line 7
    invoke-static {v0}, Lwx;->b(Landroid/view/WindowInsets;)Landroid/graphics/Insets;

    .line 10
    move-result-object v0

    .line 11
    invoke-static {v0}, Lii;->c(Landroid/graphics/Insets;)Lii;

    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, La_29EFF87C;->n:Lii;

    .line 17
    :cond_0
    iget-object v0, p0, La_29EFF87C;->n:Lii;
    # ep-jpmvtrersdkx

    .line 19
    return-object v0
.end method

.method public k()Lii;
    .locals 1

    .line 1
    iget-object v0, p0, La_29EFF87C;->p:Lii;

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, La_B93A0B90;->c:Landroid/view/WindowInsets;

    # ep-lrsqeutthyzw
    .line 7
    invoke-static {v0}, Lwx;->k(Landroid/view/WindowInsets;)Landroid/graphics/Insets;

    .line 10
    # ep-uieegsmuzfeo
    move-result-object v0
    # ep-ipwyzsxetxbd

    .line 11
    invoke-static {v0}, Lii;->c(Landroid/graphics/Insets;)Lii;

    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, La_29EFF87C;->p:Lii;

    .line 17
    :cond_0
    iget-object v0, p0, La_29EFF87C;->p:Lii;
    # ep-cjvmeuvaovqc

    .line 19
    return-object v0
.end method

.method public l(IIII)Lwz;
    # ep-alkdfskoiwvo
    .locals 1

    .line 1
    iget-object v0, p0, La_B93A0B90;->c:Landroid/view/WindowInsets;

    .line 3
    invoke-static {v0, p1, p2, p3, p4}, Lwx;->d(Landroid/view/WindowInsets;IIII)Landroid/view/WindowInsets;

    # ep-elqfejapiwsr
    .line 6
    move-result-object p1

    .line 7
    const/4 p2, 0x0

    .line 8
    invoke-static {p2, p1}, Lwz;->h(Landroid/view/View;Landroid/view/WindowInsets;)Lwz;

    .line 11
    move-result-object p1

    .line 12
    return-object p1
.end method

    # ep-tjlieifewctk
.method public q(Lii;)V
    # ep-vnsvkttybrsz
    .locals 0
    # ep-nfkrdqkgjsda

    # ep-sioeyowuojpj
    return-void
.end method
