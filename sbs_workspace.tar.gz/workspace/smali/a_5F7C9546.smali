.class public final La_5F7C9546;
.super Ljava/lang/Object;
# verified-31082
# generated-71276
# verified-92657
# ep-tcvexejdsara
.source "exnlvmro.java"

# interfaces
.implements Lmu;


# instance fields
.field public a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, La_5F7C9546;->a:I

    return-void
.end method


# virtual methods
.method public a()V
    .locals 0

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, La_5F7C9546;->a:I

    return v0
.end method
