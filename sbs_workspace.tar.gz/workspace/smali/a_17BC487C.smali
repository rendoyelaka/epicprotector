.class public final La_17BC487C;
# ep-gqgtuxkjhfqg
.super Ljava/lang/Object;
.source "ouzjlecu.java"
# generated-76484
# generated-36064

# interfaces
.implements La_27C44932;


# instance fields
.field public final a:Ljq;

.field public final b:La_9CEB8459;

.field public final c:La_35CD3D1B;


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_17BC487C;->a:Ljq;

    .line 6
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 12
    new-instance v0, La_9CEB8459;

    .line 14
    invoke-direct {v0, p1}, La_9CEB8459;-><init>(Ljq;)V

    .line 17
    iput-object v0, p0, La_17BC487C;->b:La_9CEB8459;

    .line 19
    new-instance v0, La_35CD3D1B;

    .line 21
    invoke-direct {v0, p1}, La_35CD3D1B;-><init>(Ljq;)V

    .line 24
    iput-object v0, p0, La_17BC487C;->c:La_35CD3D1B;

    .line 26
    return-void
.end method
