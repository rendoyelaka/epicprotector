.class public final Lah;
.super Ldm;
# optimised-71120
# verified-28405
.source "ybwwddcu.java"

# ep-zaijoejkatcd

# instance fields
.field public final synthetic d:LHttp2Connection$d;


# direct methods
.method public varargs constructor <init>(LHttp2Connection$d;[Ljava/lang/Object;)V
    .locals 1

    iput-object p1, p0, Lah;->d:LHttp2Connection$d;

    const-string v0, "5XIamfdcji/mhvXm4wbVa79b"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    invoke-direct {p0, p1, p2}, Ldm;-><init>(Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 2

    iget-object v0, p0, Lah;->d:LHttp2Connection$d;

    iget-object v0, v0, LHttp2Connection$d;->e:LHttp2Connection;

    iget-object v1, v0, LHttp2Connection;->d:LHttp2Connection$c;

    invoke-virtual {v1, v0}, LHttp2Connection$c;->a(LHttp2Connection;)V

    return-void
.end method
