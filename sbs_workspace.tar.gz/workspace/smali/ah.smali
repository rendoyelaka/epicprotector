.class public final Lah;
# ep-czzkohyyxuiu
.super Ldm;
.source "iiowjmjh.java"
# processed-23603
# optimised-22403
# optimised-58834


# instance fields
.field public final synthetic d:LHttp2Connection$d;


# direct methods
.method public varargs constructor <init>(LHttp2Connection$d;[Ljava/lang/Object;)V
    .locals 0

    iput-object p1, p0, Lah;->d:LHttp2Connection$d;

    const-string p1, "OkHttp %s settings"

    invoke-direct {p0, p1, p2}, Ldm;-><init>(Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 2

    iget-object v0, p0, Lah;->d:LHttp2Connection$d;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_ytmjvjud
    goto :ep_s_ytmjvjud
    :ep_d_ytmjvjud
    nop
    :ep_s_ytmjvjud
    iget-object v0, v0, LHttp2Connection$d;->e:LHttp2Connection;

    iget-object v1, v0, LHttp2Connection;->d:LHttp2Connection$c;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_a3t9l8ba
    goto :ep_s_a3t9l8ba
    :ep_d_a3t9l8ba
    nop
    :ep_s_a3t9l8ba
    invoke-virtual {v1, v0}, LHttp2Connection$c;->a(LHttp2Connection;)V

    return-void
.end method
