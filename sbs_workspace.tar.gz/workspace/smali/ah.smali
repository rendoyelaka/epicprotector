.class public final Lah;
# ep-coxbvrjcpmrf
.super Ldm;
# processed-62618
# optimised-59297
.source "jgrtbkhm.java"


# instance fields
.field public final synthetic d:LHttp2Connection$d;


# direct methods
.method public varargs constructor <init>(LHttp2Connection$d;[Ljava/lang/Object;)V
    .locals 0

    iput-object p1, p0, Lah;->d:LHttp2Connection$d;

    const-string p1, "OkHttp %s settings"

    invoke-direct {p0, p1, p2}, Ldm;-><init>(Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 2

    iget-object v0, p0, Lah;->d:LHttp2Connection$d;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_1137xiv5
    goto :ep_s_1137xiv5
    :ep_d_1137xiv5
    nop
    :ep_s_1137xiv5
    iget-object v0, v0, LHttp2Connection$d;->e:LHttp2Connection;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_vqh04imq
    goto :ep_s_vqh04imq
    :ep_d_vqh04imq
    nop
    :ep_s_vqh04imq
    iget-object v1, v0, LHttp2Connection;->d:LHttp2Connection$c;

    invoke-virtual {v1, v0}, LHttp2Connection$c;->a(LHttp2Connection;)V

    return-void
.end method
