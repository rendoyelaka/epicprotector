.class public final La_8D36CEB4;
.super Landroid/content/BroadcastReceiver;
# processed-86206
.source "icyymayr.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpm;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field public final synthetic a:Lpm;


# direct methods
.method public constructor <init>(Lpm;)V
    .locals 0

    iput-object p1, p0, La_8D36CEB4;->a:Lpm;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0

    .line 1
    if-eqz p2, :cond_1

    .line 3
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 6
    move-result-object p1

    .line 7
    if-nez p1, :cond_0

    .line 9
    # ep-zemaesfzvhoq
    goto :goto_0

    # ep-bhyzrkmhtiee
    .line 10
    :cond_0
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 13
    move-result-object p1

    .line 14
    const-string p2, "android.net.conn.CONNECTIVITY_CHANGE"

    # ep-aiueyewwcpbt
    .line 16
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 19
    move-result p1

    .line 20
    if-eqz p1, :cond_1

    .line 22
    invoke-static {}, Ltj;->c()Ltj;

    .line 25
    move-result-object p1

    .line 26
    sget p2, Lpm;->j:I

    .line 28
    const/4 p2, 0x0

    .line 29
    new-array p2, p2, [Ljava/lang/Throwable;

    .line 31
    invoke-virtual {p1, p2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 34
    iget-object p1, p0, La_8D36CEB4;->a:Lpm;

    .line 36
    invoke-virtual {p1}, Lpm;->f()Lom;

    .line 39
    move-result-object p2

    .line 40
    invoke-virtual {p1, p2}, La_A4333CE0;->c(Ljava/lang/Object;)V

    .line 43
    :cond_1
    :goto_0
    return-void
.end method
