.class public final La_0B44A848;
.super Ljava/lang/Object;
.source "hcwzncms.java"

# interfaces
# generated-50991
# validated-57341
.implements La_1CD4A688;


# instance fields
.field public final synthetic a:La_2BDA982B;


# direct methods
.method public constructor <init>(La_2BDA982B;)V
    .locals 0

    iput-object p1, p0, La_0B44A848;->a:La_2BDA982B;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
