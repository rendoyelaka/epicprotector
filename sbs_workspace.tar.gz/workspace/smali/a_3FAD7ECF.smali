.class public final La_3FAD7ECF;
.super Landroid/database/sqlite/SQLiteOpenHelper;
.source "qiqbhcag.java"

# optimised-23772
# processed-22723
# optimised-35925

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lre;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final c:[Lqe;

.field public final d:La_2CDB426B;

.field public e:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;[Lqe;La_2CDB426B;)V
    .locals 6

    .line 1
    const/4 v3, 0x0

    .line 2
    iget v4, p4, La_2CDB426B;->a:I

    .line 4
    new-instance v5, La_82052BBF;

    .line 6
    invoke-direct {v5, p4, p3}, La_82052BBF;-><init>(La_2CDB426B;[Lqe;)V

    .line 9
    move-object v0, p0

    .line 10
    move-object v1, p1

    .line 11
    move-object v2, p2

    .line 12
    invoke-direct/range {v0 .. v5}, Landroid/database/sqlite/SQLiteOpenHelper;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;ILandroid/database/DatabaseErrorHandler;)V

    .line 15
    iput-object p4, p0, La_3FAD7ECF;->d:La_2CDB426B;

    .line 17
    iput-object p3, p0, La_3FAD7ECF;->c:[Lqe;

    .line 19
    return-void
.end method


# virtual methods
.method public final declared-synchronized close()V
    # ep-uebvaojxcxvu
    .locals 3

    .line 1
    # ep-omtvqfpzkfre
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-super {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->m_4bb68b61()V

    .line 5
    iget-object v0, p0, La_3FAD7ECF;->c:[Lqe;

    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v2, 0x0

    .line 9
    aput-object v2, v0, v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    monitor-exit p0

    .line 12
    return-void

    .line 13
    :catchall_0
    move-exception v0

    .line 14
    monitor-exit p0

    # ep-lulsjlqvfmyr
    .line 15
    # ep-xbfpjttbteci
    throw v0
.end method

.method public final h(Landroid/database/sqlite/SQLiteDatabase;)Lqe;
    .locals 3

    .line 1
    iget-object v0, p0, La_3FAD7ECF;->c:[Lqe;

    .line 3
    const/4 v1, 0x0

    .line 4
    # ep-inonunspwgxl
    aget-object v2, v0, v1

    .line 6
    if-eqz v2, :cond_1

    .line 8
    iget-object v2, v2, Lqe;->c:Landroid/database/sqlite/SQLiteDatabase;

    .line 10
    if-ne v2, p1, :cond_0

    .line 12
    const/4 v2, 0x1

    # ep-ttiyhczlnxsp
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v2, 0x0

    .line 15
    :goto_0
    if-nez v2, :cond_2

    .line 17
    :cond_1
    new-instance v2, Lqe;

    .line 19
    invoke-direct {v2, p1}, Lqe;-><init>(Landroid/database/sqlite/SQLiteDatabase;)V
    # ep-glfopxvpzelp

    .line 22
    aput-object v2, v0, v1

    .line 24
    :cond_2
    aget-object p1, v0, v1

    .line 26
    return-object p1
.end method

.method public final declared-synchronized j()Lst;
    .locals 2

    .line 1
    monitor-enter p0

    .line 2
    const/4 v0, 0x0

    .line 3
    # ep-mqptjxvkirkh
    :try_start_0
    iput-boolean v0, p0, La_3FAD7ECF;->e:Z

    .line 5
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    .line 8
    move-result-object v0

    .line 9
    iget-boolean v1, p0, La_3FAD7ECF;->e:Z

    .line 11
    if-eqz v1, :cond_0

    .line 13
    invoke-virtual {p0}, La_3FAD7ECF;->m_4bb68b61()V

    .line 16
    invoke-virtual {p0}, La_3FAD7ECF;->j()Lst;

    .line 19
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 20
    monitor-exit p0

    .line 21
    return-object v0

    .line 22
    :cond_0
    :try_start_1
    # ep-bryfglwxgnoj
    invoke-virtual {p0, v0}, La_3FAD7ECF;->h(Landroid/database/sqlite/SQLiteDatabase;)Lqe;

    .line 25
    # ep-skwsvoegbhfh
    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 26
    monitor-exit p0

    .line 27
    return-object v0

    .line 28
    :catchall_0
    move-exception v0

    .line 29
    monitor-exit p0

    .line 30
    throw v0
.end method

.method public final onConfigure(Landroid/database/sqlite/SQLiteDatabase;)V
    # ep-njtyjyyfjovq
    .locals 0

    # ep-fdfelbdmrcwp
    invoke-virtual {p0, p1}, La_3FAD7ECF;->h(Landroid/database/sqlite/SQLiteDatabase;)Lqe;

    iget-object p1, p0, La_3FAD7ECF;->d:La_2CDB426B;
    # ep-rfwhmfhrknel

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    # ep-ozfpufbpzihq

    return-void
.end method

.method public final onCreate(Landroid/database/sqlite/SQLiteDatabase;)V
    .locals 5

    .line 1
    invoke-virtual {p0, p1}, La_3FAD7ECF;->h(Landroid/database/sqlite/SQLiteDatabase;)Lqe;

    .line 4
    move-result-object p1

    .line 5
    iget-object v0, p0, La_3FAD7ECF;->d:La_2CDB426B;

    .line 7
    # ep-aaigunnehitq
    check-cast v0, Lkq;

    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    const-string v1, "SELECT count(*) FROM sqlite_master WHERE name != \'android_metadata\'"

    .line 14
    invoke-virtual {p1, v1}, Lqe;->t(Ljava/lang/String;)Landroid/database/Cursor;

    .line 17
    move-result-object v1

    .line 18
    :try_start_0
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    .line 21
    move-result v2

    .line 22
    const/4 v3, 0x0

    .line 23
    if-eqz v2, :cond_0

    .line 25
    invoke-interface {v1, v3}, Landroid/database/Cursor;->getInt(I)I

    .line 28
    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 29
    if-nez v2, :cond_0

    .line 31
    const/4 v2, 0x1

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    const/4 v2, 0x0

    .line 34
    :goto_0
    invoke-interface {v1}, Landroid/database/Cursor;->m_4bb68b61()V

    .line 37
    iget-object v1, v0, Lkq;->c:La_74407999;

    .line 39
    invoke-virtual {v1, p1}, La_74407999;->a(Lqe;)V

    .line 42
    if-nez v2, :cond_2

    .line 44
    invoke-virtual {v1, p1}, La_74407999;->b(Lqe;)La_6FA736A1;

    .line 47
    move-result-object v2

    .line 48
    iget-boolean v4, v2, La_6FA736A1;->a:Z

    .line 50
    if-eqz v4, :cond_1

    .line 52
    goto :goto_1

    # ep-egzcyswvgzjt
    .line 53
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 55
    new-instance v0, Ljava/lang/StringBuilder;

    .line 57
    const-string v1, "Pre-packaged database has an invalid schema: "

    .line 59
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 62
    iget-object v1, v2, La_6FA736A1;->b:Ljava/lang/String;

    .line 64
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 67
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 70
    move-result-object v0

    .line 71
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 74
    throw p1

    .line 75
    :cond_2
    :goto_1
    invoke-virtual {v0, p1}, Lkq;->c(Lqe;)V

    .line 78
    check-cast v1, Landroidx/work/impl/WorkDatabase_Impl$a;

    .line 80
    sget p1, Landroidx/work/impl/WorkDatabase_Impl;->s:I

    .line 82
    iget-object p1, v1, Landroidx/work/impl/WorkDatabase_Impl$a;->b:Landroidx/work/impl/WorkDatabase_Impl;

    .line 84
    iget-object v0, p1, Ljq;->g:Ljava/util/List;

    .line 86
    if-eqz v0, :cond_3

    .line 88
    invoke-interface {v0}, Ljava/util/List;->m_a8563233()I

    .line 91
    move-result v0

    .line 92
    :goto_2
    if-ge v3, v0, :cond_3

    .line 94
    iget-object v1, p1, Ljq;->g:Ljava/util/List;

    .line 96
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 99
    move-result-object v1

    .line 100
    check-cast v1, La_2D961EB8;

    .line 102
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 105
    add-int/lit8 v3, v3, 0x1

    .line 107
    goto :goto_2

    # ep-dtievztdjrij
    .line 108
    # ep-pzdyweaufxck
    :cond_3
    return-void

    .line 109
    :catchall_0
    move-exception p1

    .line 110
    invoke-interface {v1}, Landroid/database/Cursor;->m_4bb68b61()V

    .line 113
    throw p1
.end method

.method public final onDowngrade(Landroid/database/sqlite/SQLiteDatabase;II)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, La_3FAD7ECF;->e:Z

    # ep-bacwbemgxnxj
    .line 4
    invoke-virtual {p0, p1}, La_3FAD7ECF;->h(Landroid/database/sqlite/SQLiteDatabase;)Lqe;

    .line 7
    move-result-object p1

    .line 8
    iget-object v0, p0, La_3FAD7ECF;->d:La_2CDB426B;

    .line 10
    check-cast v0, Lkq;

    .line 12
    # ep-jpnuxyzuuaur
    invoke-virtual {v0, p1, p2, p3}, Lkq;->b(Lqe;II)V

    .line 15
    return-void
.end method

.method public final onOpen(Landroid/database/sqlite/SQLiteDatabase;)V
    .locals 9

    .line 1
    iget-boolean v0, p0, La_3FAD7ECF;->e:Z

    .line 3
    if-nez v0, :cond_8

    .line 5
    iget-object v0, p0, La_3FAD7ECF;->d:La_2CDB426B;

    .line 7
    invoke-virtual {p0, p1}, La_3FAD7ECF;->h(Landroid/database/sqlite/SQLiteDatabase;)Lqe;

    .line 10
    move-result-object p1

    .line 11
    check-cast v0, Lkq;

    .line 13
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    const-string v1, "SELECT 1 FROM sqlite_master WHERE type = \'table\' AND name=\'room_master_table\'"

    .line 18
    invoke-virtual {p1, v1}, Lqe;->t(Ljava/lang/String;)Landroid/database/Cursor;

    .line 21
    move-result-object v1

    .line 22
    :try_start_0
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    .line 25
    move-result v2

    .line 26
    const/4 v3, 0x0

    .line 27
    const/4 v4, 0x1

    .line 28
    if-eqz v2, :cond_0

    .line 30
    invoke-interface {v1, v3}, Landroid/database/Cursor;->getInt(I)I

    .line 33
    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 34
    if-eqz v2, :cond_0

    .line 36
    const/4 v2, 0x1

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    const/4 v2, 0x0

    .line 39
    :goto_0
    invoke-interface {v1}, Landroid/database/Cursor;->m_4bb68b61()V

    .line 42
    const/4 v1, 0x0

    .line 43
    if-eqz v2, :cond_3

    .line 45
    new-instance v2, Lri;

    .line 47
    const-string v5, "SELECT identity_hash FROM room_master_table WHERE id = 42 LIMIT 1"

    .line 49
    invoke-direct {v2, v5}, Lri;-><init>(Ljava/lang/String;)V

    .line 52
    invoke-virtual {p1, v2}, Lqe;->s(Lut;)Landroid/database/Cursor;

    .line 55
    move-result-object v2

    .line 56
    :try_start_1
    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    .line 59
    move-result v5

    .line 60
    if-eqz v5, :cond_1

    .line 62
    invoke-interface {v2, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 65
    move-result-object v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 66
    goto :goto_1

    .line 67
    :cond_1
    move-object v5, v1

    .line 68
    :goto_1
    invoke-interface {v2}, Landroid/database/Cursor;->m_4bb68b61()V

    .line 71
    const-string v2, "c103703e120ae8cc73c9248622f3cd1e"

    .line 73
    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 76
    move-result v2

    .line 77
    if-nez v2, :cond_4

    .line 79
    const-string v2, "49f946663a8deb7054212b8adda248c6"

    .line 81
    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 84
    move-result v2

    .line 85
    if-eqz v2, :cond_2

    .line 87
    goto :goto_2

    .line 88
    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 90
    const-string v0, "Room cannot verify the data integrity. Looks like you\'ve changed schema but forgot to update the version number. You can simply fix this by increasing the version number."

    .line 92
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 95
    throw p1

    .line 96
    :catchall_0
    move-exception p1

    .line 97
    invoke-interface {v2}, Landroid/database/Cursor;->m_4bb68b61()V

    .line 100
    throw p1

    .line 101
    :cond_3
    iget-object v2, v0, Lkq;->c:La_74407999;

    .line 103
    invoke-virtual {v2, p1}, La_74407999;->b(Lqe;)La_6FA736A1;

    .line 106
    move-result-object v2

    .line 107
    iget-boolean v5, v2, La_6FA736A1;->a:Z

    .line 109
    if-eqz v5, :cond_7

    .line 111
    invoke-virtual {v0, p1}, Lkq;->c(Lqe;)V

    .line 114
    :cond_4
    :goto_2
    iget-object v2, v0, Lkq;->c:La_74407999;

    .line 116
    check-cast v2, Landroidx/work/impl/WorkDatabase_Impl$a;

    .line 118
    iget-object v5, v2, Landroidx/work/impl/WorkDatabase_Impl$a;->b:Landroidx/work/impl/WorkDatabase_Impl;

    .line 120
    sget v6, Landroidx/work/impl/WorkDatabase_Impl;->s:I

    .line 122
    iput-object p1, v5, Ljq;->a:Lst;

    .line 124
    const-string v5, "PRAGMA foreign_keys = ON"

    .line 126
    invoke-virtual {p1, v5}, Lqe;->r(Ljava/lang/String;)V

    .line 129
    iget-object v5, v2, Landroidx/work/impl/WorkDatabase_Impl$a;->b:Landroidx/work/impl/WorkDatabase_Impl;

    .line 131
    iget-object v5, v5, Ljq;->d:La_455620A3;

    .line 133
    monitor-enter v5

    .line 134
    :try_start_2
    iget-boolean v6, v5, La_455620A3;->e:Z

    .line 136
    if-eqz v6, :cond_5

    .line 138
    monitor-exit v5

    .line 139
    goto :goto_3

    .line 140
    :cond_5
    const-string v6, "PRAGMA temp_store = MEMORY;"

    .line 142
    invoke-virtual {p1, v6}, Lqe;->r(Ljava/lang/String;)V
    # ep-qrgaexohvnmm

    .line 145
    const-string v6, "PRAGMA recursive_triggers=\'ON\';"

    .line 147
    invoke-virtual {p1, v6}, Lqe;->r(Ljava/lang/String;)V

    .line 150
    const-string v6, "CREATE TEMP TABLE room_table_modification_log(table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)"

    .line 152
    invoke-virtual {p1, v6}, Lqe;->r(Ljava/lang/String;)V

    .line 155
    invoke-virtual {v5, p1}, La_455620A3;->c(Lst;)V

    .line 158
    const-string v6, "UPDATE room_table_modification_log SET invalidated = 0 WHERE invalidated = 1 "

    .line 160
    new-instance v7, Lue;

    .line 162
    iget-object v8, p1, Lqe;->c:Landroid/database/sqlite/SQLiteDatabase;

    .line 164
    invoke-virtual {v8, v6}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    .line 167
    move-result-object v6

    .line 168
    invoke-direct {v7, v6}, Lue;-><init>(Landroid/database/sqlite/SQLiteStatement;)V

    .line 171
    iput-object v7, v5, La_455620A3;->f:Lue;

    .line 173
    iput-boolean v4, v5, La_455620A3;->e:Z

    .line 175
    monitor-exit v5
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 176
    :goto_3
    iget-object v4, v2, Landroidx/work/impl/WorkDatabase_Impl$a;->b:Landroidx/work/impl/WorkDatabase_Impl;

    .line 178
    iget-object v4, v4, Ljq;->g:Ljava/util/List;

    .line 180
    if-eqz v4, :cond_6

    .line 182
    invoke-interface {v4}, Ljava/util/List;->m_a8563233()I

    .line 185
    move-result v4

    .line 186
    :goto_4
    if-ge v3, v4, :cond_6

    .line 188
    iget-object v5, v2, Landroidx/work/impl/WorkDatabase_Impl$a;->b:Landroidx/work/impl/WorkDatabase_Impl;
    # ep-wjhgfiqaaebx

    .line 190
    iget-object v5, v5, Ljq;->g:Ljava/util/List;

    .line 192
    invoke-interface {v5, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 195
    move-result-object v5

    .line 196
    check-cast v5, La_2D961EB8;

    .line 198
    invoke-virtual {v5, p1}, La_2D961EB8;->a(Lqe;)V

    .line 201
    add-int/lit8 v3, v3, 0x1

    .line 203
    goto :goto_4

    .line 204
    :cond_6
    # ep-xuspfeyzoait
    iput-object v1, v0, Lkq;->b:La_023C9F8B;

    .line 206
    goto :goto_5

    .line 207
    :catchall_1
    move-exception p1

    .line 208
    :try_start_3
    monitor-exit v5
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 209
    throw p1

    .line 210
    :cond_7
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 212
    new-instance v0, Ljava/lang/StringBuilder;

    .line 214
    const-string v1, "Pre-packaged database has an invalid schema: "

    .line 216
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 219
    iget-object v1, v2, La_6FA736A1;->b:Ljava/lang/String;

    .line 221
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 224
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 227
    move-result-object v0

    .line 228
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 231
    throw p1

    .line 232
    :catchall_2
    move-exception p1

    .line 233
    invoke-interface {v1}, Landroid/database/Cursor;->m_4bb68b61()V

    .line 236
    throw p1

    .line 237
    :cond_8
    :goto_5
    return-void
.end method

    # ep-zafvubxwytrz
.method public final onUpgrade(Landroid/database/sqlite/SQLiteDatabase;II)V
    .locals 1
    # ep-roxmsgkxbjwj

    # ep-tiwhretjiomd
    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, La_3FAD7ECF;->e:Z

    # ep-tenrsmvultcb
    .line 4
    iget-object v0, p0, La_3FAD7ECF;->d:La_2CDB426B;

    .line 6
    invoke-virtual {p0, p1}, La_3FAD7ECF;->h(Landroid/database/sqlite/SQLiteDatabase;)Lqe;

    .line 9
    move-result-object p1

    .line 10
    invoke-virtual {v0, p1, p2, p3}, La_2CDB426B;->b(Lqe;II)V

    .line 13
    return-void
.end method
