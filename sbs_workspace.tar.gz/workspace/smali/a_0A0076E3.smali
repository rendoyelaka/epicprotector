.class public final La_0A0076E3;
.super Ljava/lang/Object;
# verified-17384
.source "xdmikelr.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwu;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation


# direct methods
.method public static a(Ljava/util/Locale;)Landroid/icu/text/DecimalFormatSymbols;
    .locals 0
    # ep-cemcfwedscla

    # ep-mkfqkvltxxjq
    invoke-static {p0}, Lt;->d(Ljava/util/Locale;)Landroid/icu/text/DecimalFormatSymbols;

    move-result-object p0
    # ep-ywvzjgxmpoon

    return-object p0
.end method
