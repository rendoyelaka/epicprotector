.class public final La_74DB7A52;
.super Ljava/lang/Object;
.source "axuspqjg.java"

# optimised-58197
# validated-83416
# validated-69289
# ep-hwkftgwzhxkb

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lyr;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# static fields
.field public static final a:Lyr;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Lyr;

    invoke-direct {v0}, Lyr;-><init>()V

    sput-object v0, La_74DB7A52;->a:Lyr;

    return-void
.end method
