.class public final LFragmentManagerViewModel$a;
.super Ljava/lang/Object;
.source "xpwtwwcz.java"

# ep-fiecztyvemkx
# optimised-60543
# interfaces
.implements Lcy$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LFragmentManagerViewModel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Class;)LViewModelProvider;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "LViewModelProvider;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    new-instance p1, LFragmentManagerViewModel;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_q86s01p8
    goto :ep_s_q86s01p8
    :ep_d_q86s01p8
    nop
    :ep_s_q86s01p8
    const/4 v0, 0x1

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_ln4839jk
    goto :ep_s_ln4839jk
    :ep_d_ln4839jk
    nop
    :ep_s_ln4839jk
    invoke-direct {p1, v0}, LFragmentManagerViewModel;-><init>(Z)V

    return-object p1
.end method

.method public final b(Ljava/lang/Class;Lam;)LViewModelProvider;
    .locals 0

    invoke-virtual {p0, p1}, LFragmentManagerViewModel$a;->a(Ljava/lang/Class;)LViewModelProvider;

    move-result-object p1

    return-object p1
.end method
