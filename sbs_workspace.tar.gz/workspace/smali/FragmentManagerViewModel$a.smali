.class public final LFragmentManagerViewModel$a;
.super Ljava/lang/Object;
.source "vcpsjprd.java"

# ep-xkasxnzgkhkd
# generated-13559
# generated-42607
# optimised-73861
# interfaces
.implements Lcy$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LFragmentManagerViewModel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Class;)LViewModelProvider;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "LViewModelProvider;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    new-instance p1, LFragmentManagerViewModel;

    const/4 v0, 0x1

    invoke-direct {p1, v0}, LFragmentManagerViewModel;-><init>(Z)V

    return-object p1
.end method

.method public final b(Ljava/lang/Class;Lam;)LViewModelProvider;
    .locals 0

    invoke-virtual {p0, p1}, LFragmentManagerViewModel$a;->a(Ljava/lang/Class;)LViewModelProvider;

    move-result-object p1

    return-object p1
.end method
