.class public interface abstract La_78266A94;
.super Ljava/lang/Object;
# optimised-81903
# processed-95626
# validated-91481
.source "udhwfiuk.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_6C2C7A62;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
