.class public final La_1C0AB759;
.super Ljava/lang/Object;
.source "ppnuqmnh.java"
# verified-11624
# validated-95876
# ep-uaeqniiubual


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lii;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(IIII)Landroid/graphics/Insets;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Ls;->c(IIII)Landroid/graphics/Insets;

    move-result-object p0

    return-object p0
.end method
