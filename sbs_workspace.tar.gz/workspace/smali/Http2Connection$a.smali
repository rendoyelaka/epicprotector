.class public final LHttp2Connection$a;
.super Ldm;
# ep-dnoykpduvnhn
.source "ReceiverManager68.java"

# verified-45887
# optimised-66605

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LHttp2Connection;->w(IJ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic d:I

.field public final synthetic e:J

.field public final synthetic f:LHttp2Connection;


# direct methods
.method public varargs constructor <init>(LHttp2Connection;[Ljava/lang/Object;IJ)V
    .locals 0

    iput-object p1, p0, LHttp2Connection$a;->f:LHttp2Connection;

    iput p3, p0, LHttp2Connection$a;->d:I

    iput-wide p4, p0, LHttp2Connection$a;->e:J

    const-string p1, "OkHttp Window Update %s stream %d"

    invoke-direct {p0, p1, p2}, Ldm;-><init>(Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 4

    :try_start_0
    iget-object v0, p0, LHttp2Connection$a;->f:LHttp2Connection;

    iget-object v0, v0, LHttp2Connection;->r:Leh;

    iget v1, p0, LHttp2Connection$a;->d:I

    iget-wide v2, p0, LHttp2Connection$a;->e:J

    invoke-virtual {v0, v1, v2, v3}, Leh;->y(IJ)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method
