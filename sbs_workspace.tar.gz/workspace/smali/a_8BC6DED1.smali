.class public interface abstract La_8BC6DED1;
.super Ljava/lang/Object;
# ep-fflaaoedvatp
.source "enrgkeeu.java"
# optimised-79126
# optimised-90261
# processed-91463


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract m_265e71e4(Ljava/lang/Object;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation
.end method
