.class public abstract La_162AA6A7;
.super Ljava/lang/Object;
# compiled-56690
# processed-59251
.source "cbtyriqr.java"
# ep-alwgmgqnqlyn


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "d"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public b([I)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method
