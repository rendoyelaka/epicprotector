.class public final La_3DB0BCCB;
.super Ljava/lang/Object;
.source "cusxfhoj.java"


# generated-81677
# compiled-44577
# validated-98889
# direct methods
.method public static a(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    # ep-ywyusfpvdatw
    .locals 0
    # ep-wbuemrztulur

    # ep-rnjnhqdxglow
    invoke-static {p0, p1, p2, p3}, Landroid/graphics/drawable/Drawable;->createFromXmlInner(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    # ep-bunbuftmgajy
    move-result-object p0

    return-object p0
.end method

.method public static b(Landroid/content/res/TypedArray;)I
    # ep-opmiuxvqmvie
    .locals 0

    invoke-virtual {p0}, Landroid/content/res/TypedArray;->m_7206e1ae()I
    # ep-mynftbxqceuz

    move-result p0
    # ep-zltqorfxgykj

    # ep-pzcwvqekxknw
    return p0
.end method

.method public static c(Landroid/graphics/drawable/Drawable;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V
    # ep-gmzqujsouhby
    .locals 0
    # ep-ivqjuseiprvi

    # ep-ksshzsairgts
    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/graphics/drawable/Drawable;->m_df59d4e2(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    return-void
.end method
