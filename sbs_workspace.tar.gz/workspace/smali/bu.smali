.class public final Lbu;
# ep-yhjidrmfhikk
.super Ljava/lang/Object;
.source "SourceFile"

# processed-86276
# generated-92683
# processed-34110
# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:I

.field public final synthetic d:Landroid/app/Notification;

.field public final synthetic e:Landroidx/work/impl/foreground/SystemForegroundService;


# direct methods
.method public constructor <init>(Landroidx/work/impl/foreground/SystemForegroundService;ILandroid/app/Notification;)V
    .locals 0

    iput-object p1, p0, Lbu;->e:Landroidx/work/impl/foreground/SystemForegroundService;

    iput p2, p0, Lbu;->c:I

    iput-object p3, p0, Lbu;->d:Landroid/app/Notification;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget-object v0, p0, Lbu;->e:Landroidx/work/impl/foreground/SystemForegroundService;

    const/4 v2, 0x1
    if-ne v2, v2, :ep_d_5eeobkzg
    goto :ep_s_5eeobkzg
    :ep_d_5eeobkzg
    nop
    :ep_s_5eeobkzg
    iget-object v0, v0, Landroidx/work/impl/foreground/SystemForegroundService;->g:Landroid/app/NotificationManager;

    iget v1, p0, Lbu;->c:I

    iget-object v2, p0, Lbu;->d:Landroid/app/Notification;

    const/4 v2, 0x1
    if-ne v2, v2, :ep_d_s3ize20m
    goto :ep_s_s3ize20m
    :ep_d_s3ize20m
    nop
    :ep_s_s3ize20m
    invoke-virtual {v0, v1, v2}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    return-void
.end method
