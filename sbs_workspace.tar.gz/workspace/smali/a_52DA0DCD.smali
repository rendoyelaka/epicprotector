.class public final La_52DA0DCD;
# ep-fusscqurgcjh
# validated-57535
# compiled-87302
.super Ljava/lang/Error;
.source "lqepwsij.java"


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
