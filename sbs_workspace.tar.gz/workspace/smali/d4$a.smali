.class public final Ld4$a;
.super Ljava/lang/Object;
# ep-zkzngzkroyjx
.source "ActivityUtils85.java"

# verified-10826
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 1
    invoke-static {}, Lcom/android/pictach/App;->getContext()Landroid/content/Context;

    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-static {v0}, Ld4;->a(Landroid/content/Context;)V

    .line 10
    sget-object v0, Ld4;->a:Landroid/os/Handler;

    .line 12
    sget-object v1, Ld4;->c:Ld4$b;

    .line 14
    const-wide/16 v2, 0x2710

    .line 16
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    sget-object v0, Ld4;->a:Landroid/os/Handler;

    .line 22
    :goto_0
    return-void
.end method
