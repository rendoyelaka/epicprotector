.class public interface abstract La_1588DE78;
.super Ljava/lang/Object;
.source "khnbtxfu.java"

# compiled-21078
# optimised-87200

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "f"
.end annotation
