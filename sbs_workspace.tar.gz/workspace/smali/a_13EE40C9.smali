.class public abstract La_13EE40C9;
.super Ljava/lang/Object;
.source "knprtxms.java"

# optimised-50779
# verified-19791
# verified-34486

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_E0CA2870;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# static fields
.field public static final a:La_6737956A;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_6737956A;

    invoke-direct {v0}, La_6737956A;-><init>()V

    sput-object v0, La_13EE40C9;->a:La_6737956A;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(La_E0CA2870;)V
    # ep-aggxbdjhoywd
    .locals 0
    # ep-uxcrzauyogym

    # ep-gustgrzgitfs
    return-void
.end method

.method public abstract b(Ldh;)V
.end method
