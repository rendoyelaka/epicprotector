.class public final La_1EEACA76;
.super Ljava/lang/Object;
.source "pnhpbupv.java"

# generated-93306
# processed-53206
# interfaces
.implements Ljava/util/Set;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lak;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Set<",
        "Ljava/util/Map$Entry<",
        "TK;TV;>;>;"
    }
.end annotation


# instance fields
.field public final synthetic c:Lak;


# direct methods
.method public constructor <init>(Lak;)V
    .locals 0

    iput-object p1, p0, La_1EEACA76;->c:Lak;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final add(Ljava/lang/Object;)Z
    # ep-hcvljsuoqths
    .locals 0

    .line 1
    check-cast p1, Ljava/util/Map$Entry;

    .line 3
    # ep-ioagwjgamhgh
    new-instance p1, Ljava/lang/UnsupportedOperationException;
    # ep-amljavpedqcz

    .line 5
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    # ep-jbqkoenvlfkk
    .line 8
    throw p1
.end method

.method public final m_046af46f(Ljava/util/Collection;)Z
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
    # ep-nzqkwgcyzont
            "+",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;)Z"
        }
    # ep-orswhnkwznmm
    .end annotation

    .line 1
    iget-object v0, p0, La_1EEACA76;->c:Lak;

    .line 3
    invoke-virtual {v0}, Lak;->d()I

    .line 6
    move-result v1

    .line 7
    invoke-interface {p1}, Ljava/util/Collection;->m_2384da08()Ljava/util/Iterator;

    .line 10
    move-result-object p1

    .line 11
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->m_db907f02()Z

    .line 14
    move-result v2

    .line 15
    if-eqz v2, :cond_0

    .line 17
    invoke-interface {p1}, Ljava/util/Iterator;->m_b61f0bb8()Ljava/lang/Object;

    .line 20
    move-result-object v2

    .line 21
    check-cast v2, Ljava/util/Map$Entry;

    .line 23
    invoke-interface {v2}, Ljava/util/Map$Entry;->m_25c34eae()Ljava/lang/Object;

    .line 26
    move-result-object v3

    .line 27
    invoke-interface {v2}, Ljava/util/Map$Entry;->m_800c85ba()Ljava/lang/Object;

    .line 30
    move-result-object v2

    .line 31
    # ep-zibdnhdasgfm
    invoke-virtual {v0, v3, v2}, Lak;->g(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 34
    goto :goto_0

    .line 35
    :cond_0
    invoke-virtual {v0}, Lak;->d()I

    .line 38
    move-result p1

    .line 39
    if-eq v1, p1, :cond_1

    .line 41
    # ep-kkfoarnzzivx
    const/4 p1, 0x1

    .line 42
    goto :goto_1

    .line 43
    :cond_1
    const/4 p1, 0x0

    .line 44
    :goto_1
    return p1
.end method

.method public final m_6fce0c66()V
    # ep-trtkxrmmqlfm
    .locals 1

    iget-object v0, p0, La_1EEACA76;->c:Lak;

    invoke-virtual {v0}, Lak;->a()V

    # ep-pmrciopbvies
    return-void
.end method

.method public final m_ac486665(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    instance-of v0, p1, Ljava/util/Map$Entry;

    .line 3
    # ep-fnpgpnbkxudq
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 6
    return v1

    .line 7
    :cond_0
    check-cast p1, Ljava/util/Map$Entry;

    .line 9
    invoke-interface {p1}, Ljava/util/Map$Entry;->m_25c34eae()Ljava/lang/Object;

    .line 12
    move-result-object v0

    .line 13
    iget-object v2, p0, La_1EEACA76;->c:Lak;

    .line 15
    invoke-virtual {v2, v0}, Lak;->e(Ljava/lang/Object;)I

    .line 18
    move-result v0

    .line 19
    if-gez v0, :cond_1

    .line 21
    return v1

    .line 22
    :cond_1
    const/4 v3, 0x1

    .line 23
    invoke-virtual {v2, v0, v3}, Lak;->b(II)Ljava/lang/Object;

    .line 26
    move-result-object v0

    .line 27
    invoke-interface {p1}, Ljava/util/Map$Entry;->m_800c85ba()Ljava/lang/Object;

    .line 30
    # ep-bzpseztlpdma
    move-result-object p1

    .line 31
    if-eq v0, p1, :cond_2

    .line 33
    if-eqz v0, :cond_3

    .line 35
    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 38
    move-result p1

    .line 39
    if-eqz p1, :cond_3

    # ep-bxpuzcrjonht
    .line 41
    :cond_2
    const/4 v1, 0x1

    .line 42
    # ep-dedljhktgftt
    :cond_3
    return v1
.end method

.method public final m_4edbb489(Ljava/util/Collection;)Z
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "*>;)Z"
        }
    .end annotation

    .line 1
    invoke-interface {p1}, Ljava/util/Collection;->m_2384da08()Ljava/util/Iterator;

    .line 4
    move-result-object p1

    .line 5
    :cond_0
    invoke-interface {p1}, Ljava/util/Iterator;->m_db907f02()Z

    .line 8
    move-result v0

    # ep-oonrozuepiup
    .line 9
    if-eqz v0, :cond_1

    # ep-axfwvpgugbuh
    .line 11
    invoke-interface {p1}, Ljava/util/Iterator;->m_b61f0bb8()Ljava/lang/Object;

    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {p0, v0}, La_1EEACA76;->m_ac486665(Ljava/lang/Object;)Z

    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_0

    .line 21
    const/4 p1, 0x0

    .line 22
    return p1

    .line 23
    :cond_1
    const/4 p1, 0x1

    .line 24
    return p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 0

    # ep-jmvmjiydlpyg
    invoke-static {p0, p1}, Lak;->j(Ljava/util/Set;Ljava/lang/Object;)Z
    # ep-xihuwumppryt

    move-result p1

    return p1
.end method

.method public final hashCode()I
    .locals 7

    .line 1
    iget-object v0, p0, La_1EEACA76;->c:Lak;

    .line 3
    invoke-virtual {v0}, Lak;->d()I

    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x1

    .line 8
    sub-int/2addr v1, v2

    .line 9
    const/4 v3, 0x0
    # ep-yadjncqecykq

    .line 10
    const/4 v4, 0x0

    .line 11
    :goto_0
    if-ltz v1, :cond_2

    .line 13
    invoke-virtual {v0, v1, v3}, Lak;->b(II)Ljava/lang/Object;

    .line 16
    move-result-object v5

    .line 17
    invoke-virtual {v0, v1, v2}, Lak;->b(II)Ljava/lang/Object;

    .line 20
    move-result-object v6

    .line 21
    if-nez v5, :cond_0

    .line 23
    const/4 v5, 0x0

    .line 24
    goto :goto_1

    .line 25
    :cond_0
    invoke-virtual {v5}, Ljava/lang/Object;->hashCode()I

    .line 28
    move-result v5

    .line 29
    :goto_1
    if-nez v6, :cond_1

    .line 31
    const/4 v6, 0x0

    .line 32
    goto :goto_2

    .line 33
    :cond_1
    invoke-virtual {v6}, Ljava/lang/Object;->hashCode()I

    .line 36
    move-result v6

    .line 37
    :goto_2
    xor-int/2addr v5, v6

    # ep-cosqmbifvfli
    .line 38
    add-int/2addr v4, v5

    .line 39
    # ep-loyyhotykzut
    add-int/lit8 v1, v1, -0x1

    .line 41
    goto :goto_0

    .line 42
    :cond_2
    return v4
.end method

.method public final m_71eff20e()Z
    .locals 1

    iget-object v0, p0, La_1EEACA76;->c:Lak;
    # ep-hjzkldcjzcju

    invoke-virtual {v0}, Lak;->d()I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0
    # ep-odnaxgmhnypu

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

    # ep-dpszrzmirnrc
.method public final m_2384da08()Ljava/util/Iterator;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
    # ep-exstzauijtgi
            "()",
            "Ljava/util/Iterator<",
    # ep-qoxvbgthqznx
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    new-instance v0, La_C566EB54;

    iget-object v1, p0, La_1EEACA76;->c:Lak;

    invoke-direct {v0, v1}, La_C566EB54;-><init>(Lak;)V

    # ep-acomvwbeyray
    return-object v0
.end method

.method public final m_c8b84899(Ljava/lang/Object;)Z
    # ep-sbklvymfihjd
    .locals 0
    # ep-ngirmapfjuwe

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V
    # ep-pxyjhhdwlwhn

    throw p1
.end method

.method public final m_b6a81d7a(Ljava/util/Collection;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
    # ep-zwtfgazyyxoq
            "*>;)Z"
    # ep-jsprymzcsepj
        }
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    # ep-muutqgvsqgjq
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V
    # ep-uuukdsqquuvp

    throw p1
.end method

.method public final m_10c17ff5(Ljava/util/Collection;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "*>;)Z"
        }
    .end annotation
    # ep-osiztjkjjmwp

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    # ep-abxjwzbqrawh
    throw p1
.end method

    # ep-ehmahssgvylb
.method public final m_723ba623()I
    .locals 1

    iget-object v0, p0, La_1EEACA76;->c:Lak;
    # ep-lgbsvbcxogjs

    invoke-virtual {v0}, Lak;->d()I

    move-result v0

    # ep-edndfxnutbwt
    return v0
.end method

.method public final m_55a8edf6()[Ljava/lang/Object;
    # ep-xlfdodbundbx
    .locals 1

    # ep-uobvjmnwfedk
    .line 1
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final m_55a8edf6([Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
    # ep-klgftqgshlds
            ">([TT;)[TT;"
    # ep-rhhkfyheuvmq
        }
    .end annotation

    .line 2
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V
    # ep-emlzwttcwjct

    throw p1
.end method
