.class public final LHttp2Connection$b;
# ep-rzillknskvcr
.super Ljava/lang/Object;
.source "cphedaxm.java"

# verified-21722
# optimised-47667

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Connection;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public a:Ljava/net/Socket;

.field public b:Ljava/lang/String;

.field public c:Lv4;

.field public d:Lu4;

.field public e:LHttp2Connection$c;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    sget-object v0, LHttp2Connection$c;->a:LHttp2Connection$c$a;

    .line 6
    iput-object v0, p0, LHttp2Connection$b;->e:LHttp2Connection$c;

    .line 8
    return-void
.end method
