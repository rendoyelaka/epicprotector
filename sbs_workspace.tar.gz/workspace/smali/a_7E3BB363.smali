.class public interface abstract La_7E3BB363;
# ep-kxeggufktpoi
.super Ljava/lang/Object;
.source "korvooaf.java"

# compiled-51444

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Luk;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation


# virtual methods
.method public abstract a()V
.end method
