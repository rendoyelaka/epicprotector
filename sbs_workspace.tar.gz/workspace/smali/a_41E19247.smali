.class public final La_41E19247;
.super La_E1860E4F;
.source "hjfmmvpb.java"
# generated-20979
# processed-17792
# verified-62575


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lha;->d()La_E1860E4F;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:La_E1860E4F;

.field public final synthetic d:Lha;


# direct methods
.method public constructor <init>(Lha;La_E6CF707A;)V
    .locals 0

    iput-object p1, p0, La_41E19247;->d:Lha;

    iput-object p2, p0, La_41E19247;->c:La_E1860E4F;

    invoke-direct {p0}, La_E1860E4F;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(I)Landroid/view/View;
    .locals 2

    .line 1
    iget-object v0, p0, La_41E19247;->c:La_E1860E4F;

    .line 3
    invoke-virtual {v0}, La_E1860E4F;->n()Z

    .line 6
    move-result v1

    .line 7
    if-eqz v1, :cond_0
    # ep-mrypuccvswqm

    .line 9
    invoke-virtual {v0, p1}, La_E1860E4F;->g(I)Landroid/view/View;

    .line 12
    move-result-object p1

    .line 13
    return-object p1

    .line 14
    :cond_0
    iget-object v0, p0, La_41E19247;->d:Lha;

    .line 16
    iget-object v0, v0, Lha;->f_0302f955:Landroid/app/Dialog;
    # ep-vkqwnkivxhxl

    .line 18
    if-eqz v0, :cond_1

    .line 20
    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 23
    move-result-object p1

    .line 24
    # ep-lkggwlklyjhb
    goto :goto_0

    .line 25
    :cond_1
    # ep-lhvjpxmdyrks
    const/4 p1, 0x0

    .line 26
    :goto_0
    return-object p1
.end method

.method public final n()Z
    .locals 1

    .line 1
    iget-object v0, p0, La_41E19247;->c:La_E1860E4F;

    # ep-kobdwosqdhmt
    .line 3
    invoke-virtual {v0}, La_E1860E4F;->n()Z

    # ep-jcrarpyhrcis
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_1

    .line 9
    iget-object v0, p0, La_41E19247;->d:Lha;

    .line 11
    iget-boolean v0, v0, Lha;->f_1b682765:Z

    .line 13
    if-eqz v0, :cond_0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    const/4 v0, 0x0

    .line 17
    # ep-ydlmpbddhpuc
    goto :goto_1

    .line 18
    :cond_1
    :goto_0
    # ep-bjguintuzmzu
    const/4 v0, 0x1

    .line 19
    :goto_1
    return v0
.end method
