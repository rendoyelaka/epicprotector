.class public final La_697ED85C;
.super Ljava/lang/Object;
# generated-13053
# processed-14371
.source "hucplklv.java"

# interfaces
.implements Ljava/util/concurrent/Executor;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_0E23E49D;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_c2ebadaf(Ljava/lang/Runnable;)V
    # ep-huuceoiorvso
    .locals 1

    # ep-srgulkwjcwyb
    invoke-static {}, La_0E23E49D;->q()La_0E23E49D;

    move-result-object v0

    invoke-virtual {v0, p1}, La_0E23E49D;->p(Ljava/lang/Runnable;)V

    return-void
.end method
