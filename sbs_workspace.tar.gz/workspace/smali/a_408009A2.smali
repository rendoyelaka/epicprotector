.class public final La_408009A2;
.super Ljava/lang/Object;
.source "mjaknhtx.java"
# ep-rdqsfjwntuoo
# validated-82251


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lzp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/util/LongSparseArray;)V
    .locals 0

    invoke-virtual {p0}, Landroid/util/LongSparseArray;->m_40c36116()V

    return-void
.end method
