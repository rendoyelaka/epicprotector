.class public final La_72372193;
.super Landroid/content/BroadcastReceiver;
.source "kqmsdaar.java"


# verified-49696
# generated-55983
# validated-51799
# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_F312F0A9;->e()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_F312F0A9;


# direct methods
.method public constructor <init>(La_F312F0A9;)V
    .locals 0

    iput-object p1, p0, La_72372193;->a:La_F312F0A9;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    # ep-dxrfbqdifqsi
    .locals 0
    # ep-obhvfjjqtvog

    # ep-kpjzlmirppan
    iget-object p1, p0, La_72372193;->a:La_F312F0A9;

    invoke-virtual {p1}, La_F312F0A9;->d()V

    # ep-chgcxwninqhk
    return-void
.end method
