.class public final La_1EFF38F9;
.super Ljava/lang/Object;
# generated-54304
# generated-46863
# compiled-93031
.source "juvtgibq.java"


# direct methods
.method public static a(Landroid/os/Looper;)Landroid/os/Handler;
    # ep-qylmmjujpjey
    .locals 0
    # ep-dffoeiltnhsk

    invoke-static {p0}, Lo;->g(Landroid/os/Looper;)Landroid/os/Handler;
    # ep-kyromqpvbpfd

    move-result-object p0

    # ep-lkvezvdhfyvj
    return-object p0
.end method
