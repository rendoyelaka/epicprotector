.class public final La_32FBB2C3;
# ep-bhfckhargffe
.super Ljava/lang/Object;
# validated-45708
# generated-94600
.source "souxsboe.java"


# direct methods
.method public static a(Ljava/io/File;)I
    .locals 10

    .line 1
    const/4 v0, 0x4

    .line 2
    const/4 v1, 0x0

    .line 3
    :try_start_0
    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    .line 6
    move-result-object v2

    .line 7
    new-instance v3, Ljava/io/FileInputStream;

    .line 9
    invoke-direct {v3, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 12
    invoke-virtual {v3}, Ljava/io/FileInputStream;->getChannel()Ljava/nio/channels/FileChannel;

    .line 15
    move-result-object v1

    .line 16
    const-wide/16 v5, 0x3c

    .line 18
    const-wide/16 v7, 0x4

    .line 20
    const/4 v9, 0x1

    .line 21
    move-object v4, v1

    .line 22
    invoke-virtual/range {v4 .. v9}, Ljava/nio/channels/FileChannel;->tryLock(JJZ)Ljava/nio/channels/FileLock;

    .line 25
    const-wide/16 v3, 0x3c

    .line 27
    invoke-virtual {v1, v3, v4}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    .line 30
    invoke-virtual {v1, v2}, Ljava/nio/channels/FileChannel;->m_ad5497fa(Ljava/nio/ByteBuffer;)I

    .line 33
    move-result p0

    .line 34
    if-ne p0, v0, :cond_0

    .line 36
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    .line 39
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->getInt()I

    .line 42
    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 43
    invoke-virtual {v1}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->m_806d7b76()V

    .line 46
    return p0

    .line 47
    :cond_0
    :try_start_1
    new-instance p0, Ljava/io/IOException;

    .line 49
    const-string v0, "Bad database header, unable to read 4 bytes at offset 60"

    .line 51
    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 54
    throw p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 55
    :catchall_0
    move-exception p0

    .line 56
    if-eqz v1, :cond_1

    .line 58
    invoke-virtual {v1}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->m_806d7b76()V

    .line 61
    :cond_1
    throw p0
.end method
