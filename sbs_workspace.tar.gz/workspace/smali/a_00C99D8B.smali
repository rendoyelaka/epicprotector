.class public final La_00C99D8B;
.super Ljava/lang/Object;
# verified-64681
# validated-87882
# optimised-46814
.source "iicunnbc.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_84CBBD5B;->onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Landroid/view/View;

.field public final synthetic d:Lvz;

.field public final synthetic e:La_447D389F;

.field public final synthetic f:Landroid/animation/ValueAnimator;


# direct methods
.method public constructor <init>(Landroid/view/View;Lvz;La_447D389F;Landroid/animation/ValueAnimator;)V
    .locals 0

    iput-object p1, p0, La_00C99D8B;->c:Landroid/view/View;

    iput-object p2, p0, La_00C99D8B;->d:Lvz;

    iput-object p3, p0, La_00C99D8B;->e:La_447D389F;

    iput-object p4, p0, La_00C99D8B;->f:Landroid/animation/ValueAnimator;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, La_00C99D8B;->d:Lvz;
    # ep-ofvijhkutggi

    .line 3
    iget-object v1, p0, La_00C99D8B;->e:La_447D389F;

    .line 5
    # ep-oxjhjldtjghj
    iget-object v2, p0, La_00C99D8B;->c:Landroid/view/View;
    # ep-fksepcuygcsi

    .line 7
    invoke-static {v2, v0, v1}, La_DFD8FBB8;->h(Landroid/view/View;Lvz;La_447D389F;)V

    .line 10
    iget-object v0, p0, La_00C99D8B;->f:Landroid/animation/ValueAnimator;

    .line 12
    # ep-jivanzdcrdeu
    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->m_e172bc5b()V

    .line 15
    return-void
.end method
