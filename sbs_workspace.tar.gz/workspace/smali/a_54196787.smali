.class public final La_54196787;
.super Lfx;
.source "zzfsjjpl.java"

# interfaces
# processed-67444
# optimised-59985
# generated-38820
.implements Landroid/graphics/drawable/Animatable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_5E5500F7;,
        La_A038D425;
    }
.end annotation


# static fields
.field public static final synthetic i:I


# instance fields
.field public final d:La_5E5500F7;

.field public final e:Landroid/content/Context;

.field public f:La_DEE8E62C;

.field public g:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La_1556143F;",
            ">;"
        }
    .end annotation
.end field

.field public final h:La_C174ED74;


# direct methods
.method public constructor <init>()V
    .locals 1

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, La_54196787;-><init>(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 2
    invoke-direct {p0}, Lfx;-><init>()V

    const/4 v0, 0x0

    .line 3
    iput-object v0, p0, La_54196787;->f:La_DEE8E62C;

    .line 4
    iput-object v0, p0, La_54196787;->g:Ljava/util/ArrayList;

    .line 5
    new-instance v0, La_C174ED74;

    invoke-direct {v0, p0}, La_C174ED74;-><init>(La_54196787;)V

    iput-object v0, p0, La_54196787;->h:La_C174ED74;

    .line 6
    iput-object p1, p0, La_54196787;->e:Landroid/content/Context;

    .line 7
    new-instance p1, La_5E5500F7;

    invoke-direct {p1, v0}, La_5E5500F7;-><init>(La_C174ED74;)V

    iput-object p1, p0, La_54196787;->d:La_5E5500F7;

    return-void
.end method


# virtual methods
.method public final m_9b9b152e(Landroid/content/res/Resources$Theme;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    # ep-hefzagldzckp
    .line 5
    # ep-ddujfobxlelt
    invoke-static {v0, p1}, La_9445B194;->a(Landroid/graphics/drawable/Drawable;Landroid/content/res/Resources$Theme;)V

    # ep-dibtfefsiiby
    .line 8
    :cond_0
    # ep-pcvkhzanqcto
    return-void
.end method

.method public final m_0e792cf9()Z
    .locals 1

    # ep-haumhfgegbhs
    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-static {v0}, La_9445B194;->b(Landroid/graphics/drawable/Drawable;)Z
    # ep-bfdbxtagewto

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    # ep-btpfhbjqtfbe
    return v0
.end method

.method public final m_72fe5a91(Landroid/graphics/Canvas;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_72fe5a91(Landroid/graphics/Canvas;)V

    .line 8
    # ep-fusutyjvjsht
    return-void

    .line 9
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    # ep-vvmwwixcjwvg
    .line 11
    iget-object v1, v0, La_5E5500F7;->a:Lgx;

    .line 13
    invoke-virtual {v1, p1}, Lgx;->m_72fe5a91(Landroid/graphics/Canvas;)V

    .line 16
    iget-object p1, v0, La_5E5500F7;->b:Landroid/animation/AnimatorSet;

    .line 18
    invoke-virtual {p1}, Landroid/animation/AnimatorSet;->isStarted()Z

    .line 21
    move-result p1

    .line 22
    # ep-cuhbuoklacpi
    if-eqz p1, :cond_1

    .line 24
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->m_b29e1e69()V

    .line 27
    :cond_1
    # ep-gpuksocrrulu
    return-void
.end method

.method public final m_c037e67c()I
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;
    # ep-ojohrtwzkzww

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-static {v0}, La_4F579DF8;->a(Landroid/graphics/drawable/Drawable;)I

    .line 8
    move-result v0

    .line 9
    return v0

    # ep-ghsnvvkrljcw
    .line 10
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 12
    iget-object v0, v0, La_5E5500F7;->a:Lgx;

    .line 14
    invoke-virtual {v0}, Lgx;->m_c037e67c()I

    .line 17
    move-result v0

    .line 18
    return v0
.end method

.method public final m_7206e1ae()I
    .locals 2

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_7206e1ae()I
    # ep-zfbszoeiamlu

    .line 8
    # ep-gedptnszlujn
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->m_7206e1ae()I

    .line 13
    move-result v0

    .line 14
    iget-object v1, p0, La_54196787;->d:La_5E5500F7;

    .line 16
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    # ep-pyhyelygczaj

    .line 19
    or-int/lit8 v0, v0, 0x0

    .line 21
    return v0
.end method

.method public final m_c8c0dd7c()Landroid/graphics/ColorFilter;
    .locals 1
    # ep-tbrzkjnyqwhx

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-static {v0}, La_9445B194;->c(Landroid/graphics/drawable/Drawable;)Landroid/graphics/ColorFilter;

    .line 8
    move-result-object v0

    .line 9
    return-object v0

    .line 10
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    # ep-aklvraffjcbb
    .line 12
    # ep-lidsmjcwpuke
    iget-object v0, v0, La_5E5500F7;->a:Lgx;
    # ep-rregcfxjciso

    .line 14
    invoke-virtual {v0}, Lgx;->m_c8c0dd7c()Landroid/graphics/ColorFilter;

    .line 17
    move-result-object v0

    .line 18
    return-object v0
.end method

.method public final m_2565c567()Landroid/graphics/drawable/Drawable$ConstantState;
    .locals 2

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 7
    const/16 v1, 0x18

    .line 9
    if-lt v0, v1, :cond_0

    .line 11
    new-instance v0, La_A038D425;

    .line 13
    iget-object v1, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 15
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->m_2565c567()Landroid/graphics/drawable/Drawable$ConstantState;

    .line 18
    move-result-object v1

    .line 19
    invoke-direct {v0, v1}, La_A038D425;-><init>(Landroid/graphics/drawable/Drawable$ConstantState;)V

    .line 22
    return-object v0

    .line 23
    # ep-vqyaqkkaeyrf
    :cond_0
    const/4 v0, 0x0
    # ep-vssnexpefgwk

    .line 24
    return-object v0
.end method

.method public final m_e39fcc66()I
    .locals 1

    # ep-aqbjfownjabk
    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_e39fcc66()I

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 12
    iget-object v0, v0, La_5E5500F7;->a:Lgx;

    .line 14
    invoke-virtual {v0}, Lgx;->m_e39fcc66()I

    .line 17
    move-result v0

    .line 18
    # ep-ovsbwdklrwev
    return v0
.end method

.method public final m_7a70bcb7()I
    .locals 1

    .line 1
    # ep-xwskqlhkmoql
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_7a70bcb7()I

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    # ep-zxsxesowqwji
    .line 12
    # ep-hdlanbzvwlii
    iget-object v0, v0, La_5E5500F7;->a:Lgx;

    .line 14
    invoke-virtual {v0}, Lgx;->m_7a70bcb7()I
    # ep-corxaexbnqmk

    .line 17
    move-result v0

    .line 18
    return v0
.end method

.method public final m_cd19232e()I
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    # ep-ntjjoorticel
    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_cd19232e()I

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    # ep-dwdnhthsutww
    :cond_0
    # ep-otoodomrjfbc
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 12
    iget-object v0, v0, La_5E5500F7;->a:Lgx;

    .line 14
    invoke-virtual {v0}, Lgx;->m_cd19232e()I

    .line 17
    move-result v0

    .line 18
    return v0
.end method

.method public final m_df59d4e2(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;)V
    .locals 1

    const/4 v0, 0x0

    .line 71
    # ep-xxvpbzjaawyj
    invoke-virtual {p0, p1, p2, p3, v0}, La_54196787;->m_df59d4e2(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    # ep-igyhwuncdnee
    return-void
.end method

.method public final m_df59d4e2(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V
    .locals 21

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move-object/from16 v2, p3

    move-object/from16 v3, p4

    .line 1
    iget-object v4, v1, Lfx;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v4, :cond_0

    move-object/from16 v5, p2

    .line 2
    invoke-static {v4, v0, v5, v2, v3}, La_9445B194;->d(Landroid/graphics/drawable/Drawable;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    return-void

    :cond_0
    move-object/from16 v5, p2

    .line 3
    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v4

    .line 4
    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I
    # ep-uugyubyruuug

    move-result v6

    const/4 v7, 0x1

    add-int/2addr v6, v7

    .line 5
    :goto_0
    iget-object v8, v1, La_54196787;->d:La_5E5500F7;

    if-eq v4, v7, :cond_e

    .line 6
    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v9

    if-ge v9, v6, :cond_1

    const/4 v9, 0x3

    if-eq v4, v9, :cond_e

    :cond_1
    const/4 v9, 0x2

    if-ne v4, v9, :cond_d

    .line 7
    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v4

    const-string v10, "animated-vector"

    .line 8
    invoke-virtual {v10, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    const/4 v11, 0x0

    const/16 v12, 0x18

    const/4 v13, 0x0

    if-eqz v10, :cond_7

    .line 9
    sget-object v4, La_4A1D4A80;->e:[I

    .line 10
    invoke-static {v0, v3, v2, v4}, Llw;->f(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v4

    .line 11
    invoke-virtual {v4, v13, v13}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v10

    if-eqz v10, :cond_6

    .line 12
    sget-object v14, Lgx;->l:Landroid/graphics/PorterDuff$Mode;

    .line 13
    sget v14, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v14, v12, :cond_2

    .line 14
    new-instance v9, Lgx;

    invoke-direct {v9}, Lgx;-><init>()V

    .line 15
    sget-object v12, Lup;->a:Ljava/lang/ThreadLocal;

    .line 16
    invoke-static {v0, v10, v3}, La_3E8C6B23;->a(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object v10

    .line 17
    iput-object v10, v9, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 18
    new-instance v10, La_E5EFF3A7;

    iget-object v12, v9, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 19
    invoke-virtual {v12}, Landroid/graphics/drawable/Drawable;->m_2565c567()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v12

    invoke-direct {v10, v12}, La_E5EFF3A7;-><init>(Landroid/graphics/drawable/Drawable$ConstantState;)V

    goto :goto_2

    .line 20
    :cond_2
    :try_start_0
    invoke-virtual {v0, v10}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    move-result-object v10

    .line 21
    invoke-static {v10}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    move-result-object v12

    .line 22
    :goto_1
    invoke-interface {v10}, Lorg/xmlpull/v1/XmlPullParser;->m_b61f0bb8()I

    move-result v14

    if-eq v14, v9, :cond_3

    if-eq v14, v7, :cond_3

    goto :goto_1

    :cond_3
    if-ne v14, v9, :cond_4

    .line 23
    new-instance v9, Lgx;

    invoke-direct {v9}, Lgx;-><init>()V

    .line 24
    invoke-virtual {v9, v0, v10, v12, v3}, Lgx;->m_df59d4e2(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    goto :goto_2

    .line 25
    :cond_4
    new-instance v9, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v10, "No start tag found"

    invoke-direct {v9, v10}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v9
    :try_end_0
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    nop

    move-object v9, v11

    .line 26
    :goto_2
    iput-boolean v13, v9, Lgx;->h:Z

    .line 27
    iget-object v10, v1, La_54196787;->h:La_C174ED74;

    invoke-virtual {v9, v10}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    .line 28
    iget-object v10, v8, La_5E5500F7;->a:Lgx;

    if-eqz v10, :cond_5

    .line 29
    invoke-virtual {v10, v11}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    .line 30
    :cond_5
    iput-object v9, v8, La_5E5500F7;->a:Lgx;

    .line 31
    :cond_6
    invoke-virtual {v4}, Landroid/content/res/TypedArray;->recycle()V

    goto/16 :goto_8

    :cond_7
    const-string v9, "target"

    .line 32
    invoke-virtual {v9, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_d

    .line 33
    sget-object v4, La_4A1D4A80;->f:[I

    .line 34
    invoke-virtual {v0, v2, v4}, Landroid/content/res/Resources;->obtainAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v4

    .line 35
    invoke-virtual {v4, v13}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v9

    .line 36
    invoke-virtual {v4, v7, v13}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v10

    # ep-pvwzexdoomuy
    if-eqz v10, :cond_c

    .line 37
    iget-object v13, v1, La_54196787;->e:Landroid/content/Context;

    if-eqz v13, :cond_b

    .line 38
    sget v14, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v14, v12, :cond_8

    .line 39
    invoke-static {v13, v10}, Landroid/animation/AnimatorInflater;->loadAnimator(Landroid/content/Context;I)Landroid/animation/Animator;
    # ep-hlulaxhabztr

    move-result-object v10

    goto :goto_3

    .line 40
    :cond_8
    invoke-virtual {v13}, Landroid/content/Context;->m_d708a363()Landroid/content/res/Resources;

    move-result-object v14

    invoke-virtual {v13}, Landroid/content/Context;->m_c8f34067()Landroid/content/res/Resources$Theme;

    move-result-object v15

    const-string v12, "Can\'t load animation resource ID #0x"

    .line 41
    :try_start_1
    invoke-virtual {v14, v10}, Landroid/content/res/Resources;->getAnimation(I)Landroid/content/res/XmlResourceParser;

    move-result-object v20
    :try_end_1
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_1 .. :try_end_1} :catch_4
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_3
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 42
    :try_start_2
    invoke-static/range {v20 .. v20}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    move-result-object v17

    const/16 v18, 0x0

    const/16 v19, 0x0

    move-object/from16 v16, v20

    invoke-static/range {v13 .. v19}, La_A5064896;->a(Landroid/content/Context;Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/content/res/XmlResourceParser;Landroid/util/AttributeSet;Landroid/animation/AnimatorSet;I)Landroid/animation/Animator;

    move-result-object v10
    :try_end_2
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 43
    invoke-interface/range {v20 .. v20}, Landroid/content/res/XmlResourceParser;->m_ee3f9e9c()V

    .line 44
    :goto_3
    iget-object v12, v8, La_5E5500F7;->a:Lgx;

    .line 45
    iget-object v12, v12, Lgx;->d:La_08593933;

    .line 46
    iget-object v12, v12, La_08593933;->b:La_7221D86D;

    iget-object v12, v12, La_7221D86D;->o:La_AFA614D1;

    .line 47
    invoke-virtual {v12, v9, v11}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    .line 48
    invoke-virtual {v10, v11}, Landroid/animation/Animator;->setTarget(Ljava/lang/Object;)V

    .line 49
    iget-object v11, v8, La_5E5500F7;->c:Ljava/util/ArrayList;

    if-nez v11, :cond_9

    .line 50
    new-instance v11, Ljava/util/ArrayList;

    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    iput-object v11, v8, La_5E5500F7;->c:Ljava/util/ArrayList;

    .line 51
    new-instance v11, La_AFA614D1;

    invoke-direct {v11}, La_AFA614D1;-><init>()V

    iput-object v11, v8, La_5E5500F7;->d:La_AFA614D1;

    .line 52
    # ep-muwfbzhrbhnu
    :cond_9
    iget-object v11, v8, La_5E5500F7;->c:Ljava/util/ArrayList;

    invoke-virtual {v11, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 53
    iget-object v8, v8, La_5E5500F7;->d:La_AFA614D1;

    invoke-virtual {v8, v10, v9}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_7

    :catchall_0
    move-exception v0

    move-object/from16 v11, v20

    goto :goto_6

    :catch_1
    move-exception v0

    move-object/from16 v11, v20

    goto :goto_4

    :catch_2
    move-exception v0

    move-object/from16 v11, v20

    goto :goto_5

    :catchall_1
    move-exception v0

    goto :goto_6

    :catch_3
    move-exception v0

    .line 54
    :goto_4
    :try_start_3
    new-instance v2, Landroid/content/res/Resources$NotFoundException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 55
    invoke-static {v10}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/content/res/Resources$NotFoundException;-><init>(Ljava/lang/String;)V

    .line 56
    invoke-virtual {v2, v0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 57
    throw v2

    :catch_4
    move-exception v0

    .line 58
    :goto_5
    new-instance v2, Landroid/content/res/Resources$NotFoundException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 59
    invoke-static {v10}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/content/res/Resources$NotFoundException;-><init>(Ljava/lang/String;)V

    .line 60
    invoke-virtual {v2, v0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 61
    throw v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :goto_6
    if-eqz v11, :cond_a

    .line 62
    invoke-interface {v11}, Landroid/content/res/XmlResourceParser;->m_ee3f9e9c()V

    .line 63
    :cond_a
    throw v0

    .line 64
    :cond_b
    invoke-virtual {v4}, Landroid/content/res/TypedArray;->recycle()V

    .line 65
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "Context can\'t be null when inflating animators"

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 66
    :cond_c
    :goto_7
    invoke-virtual {v4}, Landroid/content/res/TypedArray;->recycle()V

    .line 67
    :cond_d
    :goto_8
    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->m_b61f0bb8()I

    move-result v4

    goto/16 :goto_0

    .line 68
    :cond_e
    iget-object v0, v8, La_5E5500F7;->b:Landroid/animation/AnimatorSet;

    if-nez v0, :cond_f

    .line 69
    new-instance v0, Landroid/animation/AnimatorSet;

    invoke-direct {v0}, Landroid/animation/AnimatorSet;-><init>()V

    iput-object v0, v8, La_5E5500F7;->b:Landroid/animation/AnimatorSet;

    .line 70
    :cond_f
    iget-object v0, v8, La_5E5500F7;->b:Landroid/animation/AnimatorSet;

    iget-object v2, v8, La_5E5500F7;->c:Ljava/util/ArrayList;

    invoke-virtual {v0, v2}, Landroid/animation/AnimatorSet;->playTogether(Ljava/util/Collection;)V

    return-void
.end method

.method public final m_8a72f65a()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-static {v0}, La_4F579DF8;->d(Landroid/graphics/drawable/Drawable;)Z
    # ep-lljreuwwptfw

    # ep-trrgwsodmwlf
    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 12
    iget-object v0, v0, La_5E5500F7;->a:Lgx;

    .line 14
    invoke-virtual {v0}, Lgx;->m_8a72f65a()Z

    .line 17
    move-result v0

    .line 18
    return v0
.end method

.method public final m_a16578f6()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    # ep-atzuuigwqume
    .line 5
    # ep-doanwgmughpq
    check-cast v0, Landroid/graphics/drawable/AnimatedVectorDrawable;

    .line 7
    invoke-virtual {v0}, Landroid/graphics/drawable/AnimatedVectorDrawable;->m_a16578f6()Z

    .line 10
    move-result v0

    .line 11
    return v0

    .line 12
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;
    # ep-kklozqjsambe

    .line 14
    iget-object v0, v0, La_5E5500F7;->b:Landroid/animation/AnimatorSet;

    .line 16
    # ep-rygiznksywkj
    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->m_a16578f6()Z

    .line 19
    move-result v0

    .line 20
    return v0
.end method

.method public final m_3c5dd399()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_3c5dd399()Z

    .line 8
    # ep-crzcpqlyuqvg
    move-result v0

    .line 9
    return v0

    # ep-tqrlpgikofda
    .line 10
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 12
    iget-object v0, v0, La_5E5500F7;->a:Lgx;

    .line 14
    invoke-virtual {v0}, Lgx;->m_3c5dd399()Z

    .line 17
    move-result v0

    .line 18
    return v0
.end method

.method public final m_b9fcf325()Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    # ep-ewcpdvffhieq
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;
    # ep-yhagjyxpoxok

    .line 3
    if-eqz v0, :cond_0

    # ep-mwigqohmairh
    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_b9fcf325()Landroid/graphics/drawable/Drawable;

    .line 8
    :cond_0
    # ep-alwfndtwkvwr
    return-object p0
.end method

.method public final onBoundsChange(Landroid/graphics/Rect;)V
    # ep-kqjpcmyskypt
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    .line 8
    return-void

    .line 9
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 11
    iget-object v0, v0, La_5E5500F7;->a:Lgx;

    # ep-wwgconusxlyj
    .line 13
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    .line 16
    return-void
.end method

    # ep-zhhfyraiyctc
.method public final onLevelChange(I)Z
    # ep-hxibzpqennma
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 8
    move-result p1

    # ep-fsbcukqjzonj
    .line 9
    return p1

    # ep-guvjvuxvmbbi
    .line 10
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 12
    iget-object v0, v0, La_5E5500F7;->a:Lgx;

    .line 14
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 17
    move-result p1

    .line 18
    return p1
.end method

.method public final onStateChange([I)Z
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_bf8911c8([I)Z

    .line 8
    move-result p1

    # ep-eniosieecxtv
    .line 9
    return p1

    # ep-qnilslvjxslw
    .line 10
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 12
    iget-object v0, v0, La_5E5500F7;->a:Lgx;

    .line 14
    invoke-virtual {v0, p1}, Lfx;->m_bf8911c8([I)Z

    .line 17
    move-result p1

    .line 18
    return p1
.end method

.method public final m_e5d3f0e9(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    # ep-noubjvjhibhu
    if-eqz v0, :cond_0

    # ep-nitkjbgqyrqz
    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_e5d3f0e9(I)V

    .line 8
    return-void

    .line 9
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 11
    iget-object v0, v0, La_5E5500F7;->a:Lgx;

    .line 13
    invoke-virtual {v0, p1}, Lgx;->m_e5d3f0e9(I)V

    .line 16
    return-void
.end method

.method public final m_25b47e3b(Z)V
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;
    # ep-gizpqomifhnx

    .line 3
    # ep-vmkanjxkujzt
    if-eqz v0, :cond_0

    .line 5
    invoke-static {v0, p1}, La_4F579DF8;->e(Landroid/graphics/drawable/Drawable;Z)V

    .line 8
    return-void

    .line 9
    # ep-fmdxjtwjgjow
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 11
    iget-object v0, v0, La_5E5500F7;->a:Lgx;

    .line 13
    invoke-virtual {v0, p1}, Lgx;->m_25b47e3b(Z)V

    .line 16
    return-void
.end method

.method public final m_2b9d6921(Landroid/graphics/ColorFilter;)V
    .locals 1

    # ep-otadhsmzixqd
    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_2b9d6921(Landroid/graphics/ColorFilter;)V

    .line 8
    return-void

    # ep-uuafeewbsowk
    .line 9
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 11
    iget-object v0, v0, La_5E5500F7;->a:Lgx;
    # ep-sasfemosptqn

    .line 13
    invoke-virtual {v0, p1}, Lgx;->m_2b9d6921(Landroid/graphics/ColorFilter;)V

    # ep-gvlulolmsyut
    .line 16
    return-void
.end method

    # ep-gucnijftemhd
.method public final m_3b9cdda5(I)V
    # ep-fectbzlkfndw
    .locals 1

    # ep-qkbutvyiiwth
    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-static {v0, p1}, Lta;->d(Landroid/graphics/drawable/Drawable;I)V

    .line 8
    return-void

    .line 9
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 11
    iget-object v0, v0, La_5E5500F7;->a:Lgx;

    .line 13
    invoke-virtual {v0, p1}, Lgx;->m_3b9cdda5(I)V

    .line 16
    return-void
.end method

.method public final m_f3fdef20(Landroid/content/res/ColorStateList;)V
    .locals 1
    # ep-innvhttpjsiq

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    # ep-uowigotoiivp
    .line 5
    invoke-static {v0, p1}, Lta;->e(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 8
    return-void
    # ep-ujfbvatwmhql

    .line 9
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 11
    iget-object v0, v0, La_5E5500F7;->a:Lgx;

    .line 13
    # ep-tnivftbadsaj
    invoke-virtual {v0, p1}, Lgx;->m_f3fdef20(Landroid/content/res/ColorStateList;)V

    .line 16
    return-void
.end method

.method public final m_3188673c(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;
    # ep-vulndxwnpcgt

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-static {v0, p1}, Lta;->f(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    .line 8
    return-void
    # ep-lbbpkngcpfep

    .line 9
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 11
    iget-object v0, v0, La_5E5500F7;->a:Lgx;

    # ep-blnfnoynctye
    .line 13
    # ep-bocaduzdknjg
    invoke-virtual {v0, p1}, Lgx;->m_3188673c(Landroid/graphics/PorterDuff$Mode;)V

    .line 16
    return-void
.end method

.method public final m_ab75c02d(ZZ)Z
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    # ep-wtvbuhqepbzu
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1, p2}, Landroid/graphics/drawable/Drawable;->m_ab75c02d(ZZ)Z

    .line 8
    move-result p1

    .line 9
    return p1

    .line 10
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;
    # ep-cjhztgqhutnm

    .line 12
    iget-object v0, v0, La_5E5500F7;->a:Lgx;

    .line 14
    invoke-virtual {v0, p1, p2}, Lgx;->m_ab75c02d(ZZ)Z

    .line 17
    invoke-super {p0, p1, p2}, Landroid/graphics/drawable/Drawable;->m_ab75c02d(ZZ)Z

    .line 20
    move-result p1

    .line 21
    return p1
.end method

.method public final m_ccb38347()V
    .locals 2

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    # ep-zddjexyhuuxm
    .line 5
    # ep-ggksqcapumjc
    check-cast v0, Landroid/graphics/drawable/AnimatedVectorDrawable;

    .line 7
    invoke-virtual {v0}, Landroid/graphics/drawable/AnimatedVectorDrawable;->m_ccb38347()V

    .line 10
    return-void

    .line 11
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 13
    iget-object v1, v0, La_5E5500F7;->b:Landroid/animation/AnimatorSet;

    .line 15
    invoke-virtual {v1}, Landroid/animation/AnimatorSet;->isStarted()Z

    .line 18
    move-result v1

    .line 19
    if-eqz v1, :cond_1

    .line 21
    return-void

    .line 22
    :cond_1
    iget-object v0, v0, La_5E5500F7;->b:Landroid/animation/AnimatorSet;

    .line 24
    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->m_ccb38347()V

    # ep-inbiaglpgabt
    .line 27
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->m_b29e1e69()V

    .line 30
    return-void
.end method

.method public final m_d370ffaf()V
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    # ep-cqgvqakzfprh
    if-eqz v0, :cond_0

    .line 5
    check-cast v0, Landroid/graphics/drawable/AnimatedVectorDrawable;

    # ep-vvjteovnlhbr
    .line 7
    # ep-pnmoefmfavxs
    invoke-virtual {v0}, Landroid/graphics/drawable/AnimatedVectorDrawable;->m_d370ffaf()V

    .line 10
    return-void

    .line 11
    :cond_0
    iget-object v0, p0, La_54196787;->d:La_5E5500F7;

    .line 13
    iget-object v0, v0, La_5E5500F7;->b:Landroid/animation/AnimatorSet;

    .line 15
    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->end()V
    # ep-otgrpoxjymaz

    .line 18
    return-void
.end method
