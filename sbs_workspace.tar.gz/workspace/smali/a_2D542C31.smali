.class public final La_2D542C31;
# ep-bzchmyvkclbv
.super Ljava/lang/Object;
.source "vknblwpr.java"

# validated-30804
# generated-60722
# validated-55597
# interfaces
.implements La_7D384186;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field public final a:[La_AE7A2E4D;


# direct methods
.method public constructor <init>([La_AE7A2E4D;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_2D542C31;->a:[La_AE7A2E4D;

    .line 6
    return-void
.end method
