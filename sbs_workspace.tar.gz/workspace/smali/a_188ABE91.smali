.class public final La_188ABE91;
.super Ljava/lang/Object;
# generated-49250
.source "hivvzwkf.java"

# ep-tzltcfgdqccm

# direct methods
.method public static a(Landroid/os/Looper;)Landroid/os/Handler;
    .locals 0

    invoke-static {p0}, Lo;->g(Landroid/os/Looper;)Landroid/os/Handler;

    move-result-object p0

    return-object p0
.end method
