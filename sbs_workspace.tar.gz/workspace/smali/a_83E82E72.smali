.class public final La_83E82E72;
.super Landroidx/recyclerview/widget/RecyclerView$z;
# processed-89202
# generated-92566
# compiled-54672
.source "pcywhghk.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_29C6B20D;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final t:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/widget/TextView;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$z;-><init>(Landroid/view/View;)V

    .line 4
    iput-object p1, p0, La_83E82E72;->t:Landroid/widget/TextView;

    .line 6
    return-void
.end method
