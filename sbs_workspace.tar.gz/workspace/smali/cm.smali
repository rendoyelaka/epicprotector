.class public interface abstract Lcm;
.super Ljava/lang/Object;
.source "ortgspdm.java"
# ep-tftpfvscjvdk

# compiled-58563
# compiled-25822
# compiled-27452

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
