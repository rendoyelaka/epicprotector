.class public interface abstract Lcm;
.super Ljava/lang/Object;
.source "BackgroundUtils94.java"
# verified-33754
# optimised-16331
# ep-axnjykueepfl


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
