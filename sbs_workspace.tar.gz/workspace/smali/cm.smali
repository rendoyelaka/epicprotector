.class public interface abstract Lcm;
.super Ljava/lang/Object;
# validated-67747
# compiled-88594
.source "hliifhlx.java"
# ep-vvuyciouvmuj


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
