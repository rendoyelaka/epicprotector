.class public interface abstract Lcm;
# ep-tbzrrzpcqtjz
.super Ljava/lang/Object;
.source "kbecjhng.java"
# compiled-10667
# verified-58952


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
