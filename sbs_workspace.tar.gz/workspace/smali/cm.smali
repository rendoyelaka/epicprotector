.class public interface abstract Lcm;
.super Ljava/lang/Object;
# compiled-56957
.source "bgjyhcqy.java"

# ep-clwsdskyzhcc

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
