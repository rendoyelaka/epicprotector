.class public interface abstract Lcm;
.super Ljava/lang/Object;
.source "fhnbmitq.java"
# generated-10029
# ep-eoeqkgczhory


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
