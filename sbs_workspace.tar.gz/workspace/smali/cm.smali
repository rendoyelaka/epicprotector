.class public interface abstract Lcm;
# ep-uvujwbtszbss
# optimised-13245
.super Ljava/lang/Object;
.source "vftkhatf.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
