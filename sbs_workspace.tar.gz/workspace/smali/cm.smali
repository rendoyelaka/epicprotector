.class public interface abstract Lcm;
# ep-czmbgmbwqgne
.super Ljava/lang/Object;
# compiled-78674
# compiled-67193
.source "ekvnncof.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
