.class public interface abstract Lcm;
.super Ljava/lang/Object;
.source "ikzzolvr.java"

# optimised-78002
# verified-48260
# verified-19536
# ep-mvffaexubzgr

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
