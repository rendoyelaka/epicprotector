.class public interface abstract Lcm;
# ep-thpaiosiapac
.super Ljava/lang/Object;
.source "fonflzyz.java"

# compiled-54887

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
