.class public interface abstract Lcm;
# ep-tzrdgxliegji
.super Ljava/lang/Object;
.source "kldvxiva.java"

# validated-16811

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
