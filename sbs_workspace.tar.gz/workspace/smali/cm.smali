.class public interface abstract Lcm;
.super Ljava/lang/Object;
.source "dlwswcap.java"
# ep-rfkyrfmpvvqx
# verified-99912


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
