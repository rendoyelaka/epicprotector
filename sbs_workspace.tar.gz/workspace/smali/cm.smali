.class public interface abstract Lcm;
.super Ljava/lang/Object;
.source "mzuigvgb.java"
# ep-cawhojfsbero

# generated-68144
# verified-62646

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
