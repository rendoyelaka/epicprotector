.class public interface abstract Lcm;
# ep-rxeriaivfxut
.super Ljava/lang/Object;
# processed-90467
# verified-55921
# generated-96625
.source "biotqaon.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
