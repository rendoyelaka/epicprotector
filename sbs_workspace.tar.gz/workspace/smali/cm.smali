.class public interface abstract Lcm;
.super Ljava/lang/Object;
.source "vmmcduzs.java"
# ep-mjrrpmdlclta
# optimised-98514
# verified-66141


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
