.class public interface abstract Lcm;
.super Ljava/lang/Object;
# ep-jfsymwhkldvm
.source "ovywmkxc.java"

# validated-15224
# validated-19775

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
