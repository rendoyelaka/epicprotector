.class public interface abstract Lcm;
.super Ljava/lang/Object;
# optimised-85619
# verified-19387
# generated-41440
.source "bfcntfkq.java"
# ep-urjrtqpfffmh


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
