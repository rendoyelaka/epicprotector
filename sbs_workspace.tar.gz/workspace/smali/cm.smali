.class public interface abstract Lcm;
# ep-ffdutlfnzznk
.super Ljava/lang/Object;
# compiled-87011
# validated-97460
.source "pzgvrneg.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
