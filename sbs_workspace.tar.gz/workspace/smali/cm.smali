.class public interface abstract Lcm;
.super Ljava/lang/Object;
# validated-60150
# compiled-66102
.source "rvpsmcck.java"
# ep-onniaidneqxx


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
