.class public interface abstract Lcm;
# ep-yyhuwhnaywkk
# optimised-81896
# optimised-96067
.super Ljava/lang/Object;
.source "kqckbysx.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
