.class public interface abstract Lcm;
.super Ljava/lang/Object;
# ep-licnqcbbwirx
.source "PermissionHelper55.java"

# optimised-58988
# compiled-14831

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
