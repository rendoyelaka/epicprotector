.class public interface abstract Lcm;
# ep-gpmdoupntcxh
.super Ljava/lang/Object;
.source "ngzbwmng.java"

# optimised-94174
# validated-30214
# optimised-98574

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
