.class public interface abstract Lcm;
.super Ljava/lang/Object;
.source "ResponseUtils70.java"
# compiled-56481

# ep-lweihqeytdtn

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a()V
.end method
