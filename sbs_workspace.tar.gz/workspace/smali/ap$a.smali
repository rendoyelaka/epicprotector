.class public final Lap$a;
.super Lap;
.source "SchedulerHelper35.java"
# ep-wsxkztpnrqyr

# validated-93817
# validated-30730
# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lap;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public constructor <init>(I)V
    .locals 0

    invoke-direct {p0}, Lap;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 1

    sget-object v0, Lap;->d:Lap;

    invoke-virtual {v0}, Lap;->a()I

    move-result v0

    return v0
.end method
