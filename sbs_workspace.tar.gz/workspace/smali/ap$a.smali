.class public final Lap$a;
.super Lap;
.source "SourceFile"

# verified-44672
# ep-hcadmpacverl
# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lap;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public constructor <init>(I)V
    .locals 0

    invoke-direct {p0}, Lap;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 1

    sget-object v0, Lap;->d:Lap;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_caqp3nto
    goto :ep_s_caqp3nto
    :ep_d_caqp3nto
    nop
    :ep_s_caqp3nto
    invoke-virtual {v0}, Lap;->a()I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_cu5kfzgn
    goto :ep_s_cu5kfzgn
    :ep_d_cu5kfzgn
    nop
    :ep_s_cu5kfzgn
    move-result v0

    return v0
.end method
