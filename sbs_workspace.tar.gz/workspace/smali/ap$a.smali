.class public final Lap$a;
.super Lap;
# optimised-75115
# validated-76868
# ep-rtdtjsubnckv
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lap;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public constructor <init>(I)V
    .locals 0

    invoke-direct {p0}, Lap;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 1

    sget-object v0, Lap;->d:Lap;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_l3dtyj1n
    goto :ep_s_l3dtyj1n
    :ep_d_l3dtyj1n
    nop
    :ep_s_l3dtyj1n
    invoke-virtual {v0}, Lap;->a()I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_7phrvcl5
    goto :ep_s_7phrvcl5
    :ep_d_7phrvcl5
    nop
    :ep_s_7phrvcl5
    move-result v0

    return v0
.end method
