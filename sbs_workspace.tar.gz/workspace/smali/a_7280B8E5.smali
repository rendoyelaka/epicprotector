.class public final synthetic La_7280B8E5;
.super Ljava/lang/Object;
.source "gberxjgy.java"

# ep-ejyizfqydjua
# optimised-21132
# generated-92913
# optimised-28360
# interfaces
.implements La_687DAFF9;


# instance fields
.field public final synthetic c:La2;


# direct methods
.method public synthetic constructor <init>(Landroidx/appcompat/app/b;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La_7280B8E5;->c:La2;

    return-void
.end method


# virtual methods
.method public final d(Landroid/view/KeyEvent;)Z
    .locals 1

    iget-object v0, p0, La_7280B8E5;->c:La2;

    invoke-virtual {v0, p1}, La2;->g(Landroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method
