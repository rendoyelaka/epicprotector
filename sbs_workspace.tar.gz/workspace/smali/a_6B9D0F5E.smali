.class public final La_6B9D0F5E;
.super Ljava/lang/Object;
.source "qpdforeg.java"


# processed-18391
# compiled-22985
# verified-98580
# static fields
.field public static final a:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Landroid/util/TypedValue;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/ThreadLocal;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    sput-object v0, La_6B9D0F5E;->a:Ljava/lang/ThreadLocal;

    return-void
.end method

    # ep-thbzrrpnvweo
.method public static a(Landroid/content/res/Resources;Landroid/content/res/XmlResourceParser;Landroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;
    .locals 4

    .line 1
    # ep-mppnxkubrkid
    invoke-static {p1}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    .line 4
    move-result-object v0

    .line 5
    :goto_0
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->m_b61f0bb8()I

    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x2

    .line 10
    if-eq v1, v2, :cond_0

    .line 12
    const/4 v3, 0x1

    .line 13
    if-eq v1, v3, :cond_0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    if-ne v1, v2, :cond_1

    .line 18
    invoke-static {p0, p1, v0, p2}, La_6B9D0F5E;->b(Landroid/content/res/Resources;Landroid/content/res/XmlResourceParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;

    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :cond_1
    new-instance p0, Lorg/xmlpull/v1/XmlPullParserException;

    .line 25
    const-string p1, "No start tag found"

    .line 27
    invoke-direct {p0, p1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    .line 30
    throw p0
.end method

.method public static b(Landroid/content/res/Resources;Landroid/content/res/XmlResourceParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;
    .locals 34

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move-object/from16 v2, p3

    .line 1
    invoke-interface/range {p1 .. p1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v3

    const-string v4, "selector"

    .line 2
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_23

    .line 3
    invoke-interface/range {p1 .. p1}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v3

    const/4 v4, 0x1

    add-int/2addr v3, v4

    const/16 v5, 0x14

    new-array v6, v5, [[I

    new-array v5, v5, [I

    const/4 v7, 0x0

    const/4 v8, 0x0

    .line 4
    :goto_0
    invoke-interface/range {p1 .. p1}, Lorg/xmlpull/v1/XmlPullParser;->m_b61f0bb8()I

    move-result v9

    if-eq v9, v4, :cond_22

    .line 5
    invoke-interface/range {p1 .. p1}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v10

    const/4 v11, 0x3

    if-ge v10, v3, :cond_0

    if-eq v9, v11, :cond_22

    :cond_0
    const/4 v12, 0x2

    if-ne v9, v12, :cond_21

    if-gt v10, v3, :cond_21

    .line 6
    invoke-interface/range {p1 .. p1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v9

    const-string v10, "item"

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1

    goto/16 :goto_17

    .line 7
    :cond_1
    sget-object v9, La_A906E194;->f_2070c155:[I

    if-nez v2, :cond_2

    .line 8
    invoke-virtual {v0, v1, v9}, Landroid/content/res/Resources;->obtainAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v9

    goto :goto_1

    .line 9
    :cond_2
    invoke-virtual {v2, v1, v9, v7, v7}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object v9

    :goto_1
    const/4 v10, -0x1

    .line 10
    invoke-virtual {v9, v7, v10}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v13

    const/16 v14, 0x1f

    const v15, -0xff01

    if-eq v13, v10, :cond_5

    .line 11
    sget-object v10, La_6B9D0F5E;->a:Ljava/lang/ThreadLocal;

    invoke-virtual {v10}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Landroid/util/TypedValue;

    if-nez v16, :cond_3

    .line 12
    new-instance v12, Landroid/util/TypedValue;

    invoke-direct {v12}, Landroid/util/TypedValue;-><init>()V

    .line 13
    invoke-virtual {v10, v12}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    goto :goto_2

    :cond_3
    move-object/from16 v12, v16

    .line 14
    :goto_2
    invoke-virtual {v0, v13, v12, v4}, Landroid/content/res/Resources;->m_800c85ba(ILandroid/util/TypedValue;Z)V

    .line 15
    iget v10, v12, Landroid/util/TypedValue;->type:I

    const/16 v12, 0x1c

    if-lt v10, v12, :cond_4

    if-gt v10, v14, :cond_4

    const/4 v10, 0x1

    goto :goto_3

    :cond_4
    const/4 v10, 0x0

    :goto_3
    if-nez v10, :cond_5

    .line 16
    :try_start_0
    invoke-virtual {v0, v13}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    # ep-cirutrnmnjlj
    move-result-object v10

    invoke-static {v0, v10, v2}, La_6B9D0F5E;->a(Landroid/content/res/Resources;Landroid/content/res/XmlResourceParser;Landroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;

    move-result-object v10

    invoke-virtual {v10}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v10
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_4

    .line 17
    :catch_0
    invoke-virtual {v9, v7, v15}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result v10

    goto :goto_4

    .line 18
    :cond_5
    invoke-virtual {v9, v7, v15}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result v10

    .line 19
    :goto_4
    invoke-virtual {v9, v4}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v12

    const/high16 v13, 0x3f800000    # 1.0f

    if-eqz v12, :cond_6

    .line 20
    invoke-virtual {v9, v4, v13}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v11

    goto :goto_5

    .line 21
    :cond_6
    invoke-virtual {v9, v11}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v12

    if-eqz v12, :cond_7

    .line 22
    invoke-virtual {v9, v11, v13}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v11

    goto :goto_5

    :cond_7
    const/high16 v11, 0x3f800000    # 1.0f

    .line 23
    :goto_5
    sget v12, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v15, 0x4

    const/high16 v4, -0x40800000    # -1.0f

    if-lt v12, v14, :cond_8

    const/4 v12, 0x2

    .line 24
    invoke-virtual {v9, v12}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v14

    if-eqz v14, :cond_8

    .line 25
    invoke-virtual {v9, v12, v4}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    goto :goto_6

    .line 26
    :cond_8
    invoke-virtual {v9, v15, v4}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    .line 27
    :goto_6
    invoke-virtual {v9}, Landroid/content/res/TypedArray;->recycle()V

    .line 28
    invoke-interface/range {p2 .. p2}, Landroid/util/AttributeSet;->getAttributeCount()I

    move-result v9

    .line 29
    new-array v12, v9, [I

    const/4 v14, 0x0

    const/4 v15, 0x0

    :goto_7
    if-ge v14, v9, :cond_b

    .line 30
    invoke-interface {v1, v14}, Landroid/util/AttributeSet;->getAttributeNameResource(I)I

    move-result v13

    const v7, 0x10101a5

    if-eq v13, v7, :cond_a

    const v7, 0x101031f

    if-eq v13, v7, :cond_a

    const v7, 0x7f03002d

    if-eq v13, v7, :cond_a

    const v7, 0x7f030259

    if-eq v13, v7, :cond_a

    add-int/lit8 v7, v15, 0x1

    const/4 v0, 0x0

    .line 31
    invoke-interface {v1, v14, v0}, Landroid/util/AttributeSet;->getAttributeBooleanValue(IZ)Z

    move-result v19

    if-eqz v19, :cond_9

    goto :goto_8

    :cond_9
    neg-int v13, v13

    .line 32
    :goto_8
    aput v13, v12, v15

    move v15, v7

    :cond_a
    add-int/lit8 v14, v14, 0x1

    move-object/from16 v0, p0

    const/4 v7, 0x0

    const/high16 v13, 0x3f800000    # 1.0f

    goto :goto_7

    .line 33
    :cond_b
    invoke-static {v12, v15}, Landroid/util/StateSet;->trimStateSet([II)[I

    move-result-object v0

    const/high16 v7, 0x42c80000    # 100.0f

    const/4 v9, 0x0

    cmpl-float v12, v4, v9

    if-ltz v12, :cond_c

    cmpg-float v12, v4, v7

    if-gtz v12, :cond_c

    const/4 v12, 0x1

    goto :goto_9

    :cond_c
    const/4 v12, 0x0

    :goto_9
    const/high16 v13, 0x3f800000    # 1.0f

    cmpl-float v14, v11, v13

    if-nez v14, :cond_d

    if-nez v12, :cond_d

    move/from16 v30, v3

    const/16 v16, 0x1

    goto/16 :goto_14

    .line 34
    :cond_d
    invoke-static {v10}, Landroid/graphics/Color;->alpha(I)I

    move-result v13

    int-to-float v13, v13

    mul-float v13, v13, v11

    const/high16 v11, 0x3f000000    # 0.5f

    add-float/2addr v13, v11

    float-to-int v11, v13

    const/16 v13, 0xff

    const/4 v14, 0x0

    .line 35
    invoke-static {v11, v14, v13}, La_A906E194;->n(III)I

    move-result v11

    if-eqz v12, :cond_1c

    .line 36
    # ep-oagqphzvxpqz
    invoke-static {v10}, La_3C4E2C8A;->a(I)La_3C4E2C8A;

    move-result-object v10

    .line 37
    sget-object v12, Lbz;->k:Lbz;

    iget v13, v10, La_3C4E2C8A;->b:F

    float-to-double v14, v13

    const-wide/high16 v19, 0x3ff0000000000000L    # 1.0

    cmpg-double v21, v14, v19

    if-ltz v21, :cond_1b

    .line 38
    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v14

    int-to-double v14, v14

    const-wide/16 v19, 0x0

    cmpg-double v21, v14, v19

    if-lez v21, :cond_1b

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v14

    int-to-double v14, v14

    const-wide/high16 v19, 0x4059000000000000L    # 100.0

    cmpl-double v21, v14, v19

    if-ltz v21, :cond_e

    goto/16 :goto_12

    :cond_e
    iget v10, v10, La_3C4E2C8A;->a:F

    cmpg-float v14, v10, v9

    if-gez v14, :cond_f

    const/4 v10, 0x0

    goto :goto_a

    :cond_f
    const/high16 v14, 0x43b40000    # 360.0f

    .line 39
    invoke-static {v14, v10}, Ljava/lang/Math;->min(FF)F

    move-result v10

    :goto_a
    move v15, v13

    const/4 v14, 0x0

    const/16 v19, 0x1

    const/16 v20, 0x0

    :goto_b
    sub-float v22, v20, v13

    .line 40
    invoke-static/range {v22 .. v22}, Ljava/lang/Math;->abs(F)F

    move-result v22

    const v23, 0x3ecccccd    # 0.4f

    cmpl-float v22, v22, v23

    if-ltz v22, :cond_19

    const/high16 v22, 0x447a0000    # 1000.0f

    const/high16 v23, 0x447a0000    # 1000.0f

    const/16 v24, 0x0

    const/high16 v25, 0x42c80000    # 100.0f

    const/16 v26, 0x0

    :goto_c
    sub-float v27, v24, v25

    .line 41
    invoke-static/range {v27 .. v27}, Ljava/lang/Math;->abs(F)F

    move-result v27

    const v28, 0x3c23d70a    # 0.01f

    const/high16 v29, 0x40000000    # 2.0f

    cmpl-float v27, v27, v28

    if-lez v27, :cond_15

    sub-float v27, v25, v24

    div-float v27, v27, v29

    add-float v9, v27, v24

    .line 42
    invoke-static {v9, v15, v10}, La_3C4E2C8A;->b(FFF)La_3C4E2C8A;

    move-result-object v7

    .line 43
    sget-object v1, Lbz;->k:Lbz;

    invoke-virtual {v7, v1}, La_3C4E2C8A;->c(Lbz;)I

    move-result v1

    .line 44
    invoke-static {v1}, Landroid/graphics/Color;->red(I)I

    move-result v7

    invoke-static {v7}, La_A906E194;->m_b5120073(I)F

    move-result v7

    .line 45
    invoke-static {v1}, Landroid/graphics/Color;->green(I)I

    move-result v30

    invoke-static/range {v30 .. v30}, La_A906E194;->m_b5120073(I)F

    move-result v30

    .line 46
    invoke-static {v1}, Landroid/graphics/Color;->blue(I)I

    move-result v31

    invoke-static/range {v31 .. v31}, La_A906E194;->m_b5120073(I)F

    move-result v31

    .line 47
    sget-object v32, La_A906E194;->e:[[F

    const/16 v16, 0x1

    .line 48
    aget-object v32, v32, v16

    const/16 v18, 0x0

    aget v33, v32, v18

    mul-float v7, v7, v33

    aget v33, v32, v16

    mul-float v30, v30, v33

    add-float v30, v30, v7

    const/4 v7, 0x2

    aget v17, v32, v7

    mul-float v31, v31, v17

    add-float v31, v31, v30

    const/high16 v17, 0x42c80000    # 100.0f

    div-float v7, v31, v17

    const v30, 0x3c111aa7

    cmpg-float v30, v7, v30

    if-gtz v30, :cond_10

    const v30, 0x4461d2f7

    mul-float v7, v7, v30

    move/from16 v30, v3

    goto :goto_d

    :cond_10
    move/from16 v30, v3

    # ep-ylvsmljtdzvd
    float-to-double v2, v7

    .line 49
    invoke-static {v2, v3}, Ljava/lang/Math;->cbrt(D)D

    move-result-wide v2

    double-to-float v2, v2

    const/high16 v3, 0x42e80000    # 116.0f

    mul-float v2, v2, v3

    const/high16 v3, 0x41800000    # 16.0f

    sub-float v7, v2, v3

    :goto_d
    sub-float v2, v4, v7

    .line 50
    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v2

    const v3, 0x3e4ccccd    # 0.2f

    cmpg-float v3, v2, v3

    if-gez v3, :cond_11

    .line 51
    invoke-static {v1}, La_3C4E2C8A;->a(I)La_3C4E2C8A;

    move-result-object v1

    .line 52
    iget v3, v1, La_3C4E2C8A;->c:F

    move/from16 v31, v2

    iget v2, v1, La_3C4E2C8A;->b:F

    invoke-static {v3, v2, v10}, La_3C4E2C8A;->b(FFF)La_3C4E2C8A;

    move-result-object v2

    .line 53
    iget v3, v2, La_3C4E2C8A;->d:F

    move/from16 v32, v9

    .line 54
    iget v9, v1, La_3C4E2C8A;->d:F

    sub-float/2addr v9, v3

    .line 55
    iget v3, v1, La_3C4E2C8A;->e:F

    move/from16 v33, v10

    iget v10, v2, La_3C4E2C8A;->e:F

    sub-float/2addr v3, v10

    .line 56
    iget v10, v1, La_3C4E2C8A;->f:F

    iget v2, v2, La_3C4E2C8A;->f:F

    sub-float/2addr v10, v2

    mul-float v9, v9, v9

    mul-float v3, v3, v3

    add-float/2addr v3, v9

    mul-float v10, v10, v10

    add-float/2addr v10, v3

    float-to-double v2, v10

    .line 57
    invoke-static {v2, v3}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v2

    const-wide v9, 0x3fe428f5c28f5c29L    # 0.63

    .line 58
    invoke-static {v2, v3, v9, v10}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v2

    const-wide v9, 0x3ff68f5c28f5c28fL    # 1.41

    mul-double v2, v2, v9

    double-to-float v2, v2

    const/high16 v3, 0x3f800000    # 1.0f

    cmpg-float v9, v2, v3

    if-gtz v9, :cond_12

    move-object/from16 v26, v1

    move/from16 v23, v2

    move/from16 v22, v31

    goto :goto_e

    :cond_11
    move/from16 v32, v9

    move/from16 v33, v10

    const/high16 v3, 0x3f800000    # 1.0f

    :cond_12
    :goto_e
    const/4 v1, 0x0

    cmpl-float v2, v22, v1

    if-nez v2, :cond_13

    cmpl-float v2, v23, v1

    if-nez v2, :cond_13

    goto :goto_10

    :cond_13
    cmpg-float v2, v7, v4

    if-gez v2, :cond_14

    move/from16 v24, v32

    goto :goto_f

    :cond_14
    move/from16 v25, v32

    :goto_f
    move-object/from16 v1, p2

    move-object/from16 v2, p3

    move/from16 v3, v30

    move/from16 v10, v33

    const/high16 v7, 0x42c80000    # 100.0f

    const/4 v9, 0x0

    goto/16 :goto_c

    :cond_15
    move/from16 v30, v3

    move/from16 v33, v10

    const/4 v1, 0x0

    const/high16 v3, 0x3f800000    # 1.0f

    const/16 v16, 0x1

    const/high16 v17, 0x42c80000    # 100.0f

    :goto_10
    move-object/from16 v2, v26

    if-eqz v19, :cond_17

    if-eqz v2, :cond_16

    .line 59
    invoke-virtual {v2, v12}, La_3C4E2C8A;->c(Lbz;)I

    move-result v10

    goto :goto_13

    :cond_16
    sub-float v2, v13, v20

    div-float v2, v2, v29

    add-float v15, v2, v20

    move-object/from16 v1, p2

    move-object/from16 v2, p3

    move/from16 v3, v30

    move/from16 v10, v33

    const/high16 v7, 0x42c80000    # 100.0f

    const/4 v9, 0x0

    const/16 v19, 0x0

    goto/16 :goto_b

    :cond_17
    if-nez v2, :cond_18

    move v13, v15

    goto :goto_11

    :cond_18
    move-object v14, v2

    move/from16 v20, v15

    :goto_11
    sub-float v2, v13, v20

    div-float v2, v2, v29

    add-float v15, v2, v20

    move-object/from16 v1, p2

    move-object/from16 v2, p3

    move/from16 v3, v30

    move/from16 v10, v33

    const/high16 v7, 0x42c80000    # 100.0f

    const/4 v9, 0x0

    goto/16 :goto_b

    :cond_19
    move/from16 v30, v3

    const/16 v16, 0x1

    if-nez v14, :cond_1a

    .line 60
    invoke-static {v4}, La_A906E194;->m_8e0f795c(F)I

    move-result v10

    goto :goto_13

    .line 61
    :cond_1a
    invoke-virtual {v14, v12}, La_3C4E2C8A;->c(Lbz;)I

    move-result v10

    goto :goto_13

    :cond_1b
    :goto_12
    move/from16 v30, v3

    const/16 v16, 0x1

    .line 62
    invoke-static {v4}, La_A906E194;->m_8e0f795c(F)I

    move-result v10

    goto :goto_13

    :cond_1c
    move/from16 v30, v3

    const/16 v16, 0x1

    # ep-cblhjiuhatqj
    :goto_13
    const v1, 0xffffff

    and-int/2addr v1, v10

    shl-int/lit8 v2, v11, 0x18

    or-int v10, v1, v2

    :goto_14
    add-int/lit8 v1, v8, 0x1

    .line 63
    array-length v2, v5

    const/16 v3, 0x8

    if-le v1, v2, :cond_1e

    const/4 v2, 0x4

    if-gt v8, v2, :cond_1d

    const/16 v2, 0x8

    goto :goto_15

    :cond_1d
    mul-int/lit8 v2, v8, 0x2

    .line 64
    :goto_15
    new-array v2, v2, [I

    const/4 v4, 0x0

    .line 65
    invoke-static {v5, v4, v2, v4, v8}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object v5, v2

    .line 66
    :cond_1e
    aput v10, v5, v8

    .line 67
    array-length v2, v6

    if-le v1, v2, :cond_20

    .line 68
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v2

    const/4 v4, 0x4

    if-gt v8, v4, :cond_1f

    goto :goto_16

    :cond_1f
    mul-int/lit8 v3, v8, 0x2

    :goto_16
    invoke-static {v2, v3}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    .line 69
    invoke-static {v6, v3, v2, v3, v8}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object v6, v2

    .line 70
    :cond_20
    aput-object v0, v6, v8

    .line 71
    check-cast v6, [[I

    move-object/from16 v0, p0

    move-object/from16 v2, p3

    move v8, v1

    move/from16 v3, v30

    const/4 v4, 0x1

    const/4 v7, 0x0

    move-object/from16 v1, p2

    goto/16 :goto_0

    :cond_21
    :goto_17
    move/from16 v30, v3

    const/16 v16, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move-object/from16 v2, p3

    move/from16 v3, v30

    const/4 v4, 0x1

    const/4 v7, 0x0

    goto/16 :goto_0

    .line 72
    :cond_22
    new-array v0, v8, [I

    .line 73
    new-array v1, v8, [[I

    const/4 v2, 0x0

    .line 74
    invoke-static {v5, v2, v0, v2, v8}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 75
    invoke-static {v6, v2, v1, v2, v8}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 76
    new-instance v2, Landroid/content/res/ColorStateList;

    invoke-direct {v2, v1, v0}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    return-object v2

    .line 77
    :cond_23
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 78
    invoke-interface/range {p1 .. p1}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ": invalid color state list tag "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
