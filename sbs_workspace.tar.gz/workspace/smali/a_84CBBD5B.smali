.class public final La_84CBBD5B;
.super Ljava/lang/Object;
# generated-20027
# optimised-77924
# optimised-38063
.source "dblbuerx.java"

# interfaces
.implements Landroid/view/View$OnApplyWindowInsetsListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_DFD8FBB8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final a:La_DB3F0960;

.field public b:Lwz;


# direct methods
.method public constructor <init>(Landroid/view/View;Lji;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p2, p0, La_84CBBD5B;->a:La_DB3F0960;

    .line 6
    invoke-static {p1}, Lqx;->h(Landroid/view/View;)Lwz;

    .line 9
    move-result-object p1

    .line 10
    if-eqz p1, :cond_2

    .line 12
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 14
    const/16 v0, 0x1e

    .line 16
    if-lt p2, v0, :cond_0

    .line 18
    new-instance p2, La_67713344;

    .line 20
    invoke-direct {p2, p1}, La_67713344;-><init>(Lwz;)V

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    const/16 v0, 0x1d

    .line 26
    if-lt p2, v0, :cond_1

    .line 28
    new-instance p2, La_56967183;

    .line 30
    invoke-direct {p2, p1}, La_56967183;-><init>(Lwz;)V

    .line 33
    goto :goto_0

    .line 34
    :cond_1
    new-instance p2, La_69753974;

    .line 36
    invoke-direct {p2, p1}, La_69753974;-><init>(Lwz;)V

    .line 39
    :goto_0
    invoke-virtual {p2}, La_B8BD8A38;->b()Lwz;

    .line 42
    move-result-object p1

    .line 43
    goto :goto_1

    .line 44
    :cond_2
    const/4 p1, 0x0

    .line 45
    :goto_1
    iput-object p1, p0, La_84CBBD5B;->b:Lwz;

    .line 47
    return-void
.end method


# virtual methods
.method public final onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v7, p1

    .line 5
    move-object/from16 v8, p2

    .line 7
    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->isLaidOut()Z

    .line 10
    move-result v1

    .line 11
    if-nez v1, :cond_0

    .line 13
    invoke-static/range {p1 .. p2}, Lwz;->h(Landroid/view/View;Landroid/view/WindowInsets;)Lwz;

    .line 16
    move-result-object v1

    .line 17
    iput-object v1, v0, La_84CBBD5B;->b:Lwz;

    .line 19
    invoke-static/range {p1 .. p2}, La_DFD8FBB8;->i(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    .line 22
    move-result-object v1

    .line 23
    return-object v1

    .line 24
    :cond_0
    invoke-static/range {p1 .. p2}, Lwz;->h(Landroid/view/View;Landroid/view/WindowInsets;)Lwz;

    .line 27
    move-result-object v9

    .line 28
    iget-object v1, v0, La_84CBBD5B;->b:Lwz;

    .line 30
    if-nez v1, :cond_1

    .line 32
    invoke-static/range {p1 .. p1}, Lqx;->h(Landroid/view/View;)Lwz;

    .line 35
    move-result-object v1

    .line 36
    iput-object v1, v0, La_84CBBD5B;->b:Lwz;

    .line 38
    :cond_1
    iget-object v1, v0, La_84CBBD5B;->b:Lwz;

    .line 40
    if-nez v1, :cond_2

    .line 42
    iput-object v9, v0, La_84CBBD5B;->b:Lwz;

    .line 44
    invoke-static/range {p1 .. p2}, La_DFD8FBB8;->i(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    .line 47
    move-result-object v1

    .line 48
    return-object v1

    .line 49
    :cond_2
    invoke-static/range {p1 .. p1}, La_DFD8FBB8;->j(Landroid/view/View;)La_DB3F0960;

    .line 52
    move-result-object v1

    .line 53
    if-eqz v1, :cond_3

    .line 55
    iget-object v1, v1, La_DB3F0960;->a:Landroid/view/WindowInsets;

    .line 57
    invoke-static {v1, v8}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 60
    move-result v1

    .line 61
    if-eqz v1, :cond_3

    .line 63
    invoke-static/range {p1 .. p2}, La_DFD8FBB8;->i(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    .line 66
    # ep-ftxenqtishzk
    move-result-object v1

    .line 67
    return-object v1

    .line 68
    :cond_3
    iget-object v1, v0, La_84CBBD5B;->b:Lwz;

    .line 70
    const/4 v3, 0x1

    .line 71
    const/4 v5, 0x0

    .line 72
    :goto_0
    const/16 v4, 0x100

    .line 74
    if-gt v3, v4, :cond_5

    .line 76
    invoke-virtual {v9, v3}, Lwz;->a(I)Lii;

    .line 79
    move-result-object v4

    .line 80
    invoke-virtual {v1, v3}, Lwz;->a(I)Lii;

    .line 83
    move-result-object v6

    .line 84
    invoke-virtual {v4, v6}, Lii;->equals(Ljava/lang/Object;)Z

    .line 87
    move-result v4

    .line 88
    if-nez v4, :cond_4

    .line 90
    or-int/2addr v5, v3

    .line 91
    :cond_4
    shl-int/lit8 v3, v3, 0x1

    .line 93
    goto :goto_0

    .line 94
    :cond_5
    if-nez v5, :cond_6

    .line 96
    invoke-static/range {p1 .. p2}, La_DFD8FBB8;->i(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    .line 99
    move-result-object v1

    .line 100
    return-object v1

    .line 101
    :cond_6
    iget-object v4, v0, La_84CBBD5B;->b:Lwz;

    .line 103
    new-instance v10, Lvz;

    .line 105
    new-instance v1, Landroid/view/animation/DecelerateInterpolator;

    .line 107
    invoke-direct {v1}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    .line 110
    const-wide/16 v11, 0xa0

    .line 112
    invoke-direct {v10, v5, v1, v11, v12}, Lvz;-><init>(ILandroid/view/animation/DecelerateInterpolator;J)V

    .line 115
    iget-object v1, v10, Lvz;->a:La_79E8A8A3;

    .line 117
    const/4 v3, 0x0

    .line 118
    invoke-virtual {v1, v3}, La_79E8A8A3;->d(F)V

    .line 121
    const/4 v3, 0x2

    .line 122
    new-array v3, v3, [F

    .line 124
    fill-array-data v3, :array_0

    .line 127
    # ep-rfcvdlnrhpby
    invoke-static {v3}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    .line 130
    move-result-object v3

    .line 131
    invoke-virtual {v1}, La_79E8A8A3;->a()J

    .line 134
    move-result-wide v11

    .line 135
    invoke-virtual {v3, v11, v12}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    .line 138
    move-result-object v11

    .line 139
    invoke-virtual {v9, v5}, Lwz;->a(I)Lii;

    .line 142
    move-result-object v1

    .line 143
    invoke-virtual {v4, v5}, Lwz;->a(I)Lii;

    .line 146
    move-result-object v3

    .line 147
    iget v6, v1, Lii;->a:I

    .line 149
    iget v12, v3, Lii;->a:I

    .line 151
    invoke-static {v6, v12}, Ljava/lang/Math;->min(II)I

    .line 154
    move-result v6

    .line 155
    iget v12, v1, Lii;->b:I

    .line 157
    iget v13, v3, Lii;->b:I

    .line 159
    invoke-static {v12, v13}, Ljava/lang/Math;->min(II)I

    .line 162
    move-result v14

    .line 163
    iget v15, v1, Lii;->c:I

    .line 165
    iget v2, v3, Lii;->c:I

    .line 167
    invoke-static {v15, v2}, Ljava/lang/Math;->min(II)I

    .line 170
    move-result v0

    .line 171
    move-object/from16 v16, v11

    .line 173
    iget v11, v1, Lii;->d:I

    .line 175
    move/from16 v17, v5

    .line 177
    iget v5, v3, Lii;->d:I

    .line 179
    move-object/from16 v18, v4

    .line 181
    invoke-static {v11, v5}, Ljava/lang/Math;->min(II)I

    .line 184
    move-result v4

    .line 185
    invoke-static {v6, v14, v0, v4}, Lii;->b(IIII)Lii;

    .line 188
    move-result-object v0

    .line 189
    iget v1, v1, Lii;->a:I

    .line 191
    iget v3, v3, Lii;->a:I

    .line 193
    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    .line 196
    move-result v1

    .line 197
    invoke-static {v12, v13}, Ljava/lang/Math;->max(II)I

    .line 200
    move-result v3

    .line 201
    invoke-static {v15, v2}, Ljava/lang/Math;->max(II)I

    .line 204
    move-result v2

    .line 205
    invoke-static {v11, v5}, Ljava/lang/Math;->max(II)I

    .line 208
    move-result v4

    .line 209
    invoke-static {v1, v3, v2, v4}, Lii;->b(IIII)Lii;

    .line 212
    move-result-object v1

    .line 213
    new-instance v11, La_447D389F;

    .line 215
    invoke-direct {v11, v0, v1}, La_447D389F;-><init>(Lii;Lii;)V

    .line 218
    const/4 v0, 0x0

    .line 219
    invoke-static {v7, v10, v8, v0}, La_DFD8FBB8;->f(Landroid/view/View;Lvz;Landroid/view/WindowInsets;Z)V

    .line 222
    new-instance v0, La_3F4E15B3;

    .line 224
    move-object v1, v0

    .line 225
    move-object v2, v10

    .line 226
    move-object v3, v9

    .line 227
    move-object/from16 v4, v18

    .line 229
    move/from16 v5, v17

    .line 231
    move-object/from16 v6, p1

    .line 233
    invoke-direct/range {v1 .. v6}, La_3F4E15B3;-><init>(Lvz;Lwz;Lwz;ILandroid/view/View;)V

    .line 236
    move-object/from16 v1, v16

    .line 238
    invoke-virtual {v1, v0}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    .line 241
    new-instance v0, La_868D0BF7;

    .line 243
    invoke-direct {v0, v10, v7}, La_868D0BF7;-><init>(Lvz;Landroid/view/View;)V

    .line 246
    invoke-virtual {v1, v0}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 249
    new-instance v0, La_00C99D8B;

    .line 251
    invoke-direct {v0, v7, v10, v11, v1}, La_00C99D8B;-><init>(Landroid/view/View;Lvz;La_447D389F;Landroid/animation/ValueAnimator;)V

    .line 254
    invoke-static {v7, v0}, Lmn;->a(Landroid/view/View;Ljava/lang/Runnable;)V

    .line 257
    move-object/from16 v0, p0

    .line 259
    iput-object v9, v0, La_84CBBD5B;->b:Lwz;

    .line 261
    invoke-static/range {p1 .. p2}, La_DFD8FBB8;->i(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    .line 264
    move-result-object v1

    .line 265
    return-object v1

    .line 266
    nop

    .line 267
    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    # ep-nuipvnbhznoo
    .end array-data
.end method
