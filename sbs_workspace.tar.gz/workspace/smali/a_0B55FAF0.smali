.class public final La_0B55FAF0;
.super La_225AD6CD;
# verified-82413
# validated-71917
.source "bfthtllr.java"

# ep-rdhjnyeigkpt

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_225AD6CD;-><init>()V

    return-void
.end method
