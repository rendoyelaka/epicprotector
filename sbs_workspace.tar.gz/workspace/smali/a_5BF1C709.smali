.class public final La_5BF1C709;
.super Lcom/google/android/material/floatingactionbutton/FloatingActionButton$a;
# verified-15376
# optimised-11728
.source "koetxafd.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_4CEAB8F6;->a(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_4CEAB8F6;


# direct methods
.method public constructor <init>(La_4CEAB8F6;)V
    .locals 0

    iput-object p1, p0, La_5BF1C709;->a:La_4CEAB8F6;

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$a;-><init>()V

    return-void
.end method


# virtual methods
.method public final b()V
    # ep-yqchessppmnh
    .locals 2

    .line 1
    # ep-lwwovyaywtpj
    iget-object v0, p0, La_5BF1C709;->a:La_4CEAB8F6;

    .line 3
    iget-object v0, v0, La_4CEAB8F6;->b:Lcom/google/android/material/bottomappbar/BottomAppBar;

    # ep-cbktckuckujp
    .line 5
    sget v1, Lcom/google/android/material/bottomappbar/BottomAppBar;->f_f33b9271:I
    # ep-vnzksytrvvjj

    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    return-void
.end method
