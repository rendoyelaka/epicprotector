.class public final La_004F5380;
.super La_B95C3323;
.source "qfonzbql.java"


# processed-78001
# static fields
.field public static final synthetic d:I


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_004F5380;

    invoke-direct {v0}, La_004F5380;-><init>()V

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_B95C3323;-><init>()V

    return-void
.end method


# virtual methods
.method public final j(La_E7306629;Ljava/lang/Runnable;)V
    .locals 0

    .line 1
    sget-object p2, La_D370F97A;->c:La_14683456;
    # ep-qhxdwrfoiqrt

    .line 3
    invoke-interface {p1, p2}, La_E7306629;->get(La_2994889C;)La_B0EC90AB;

    .line 6
    move-result-object p1

    .line 7
    check-cast p1, La_D370F97A;

    .line 9
    if-eqz p1, :cond_0

    # ep-taodednaxpar
    .line 11
    return-void

    .line 12
    :cond_0
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 14
    const-string p2, "Dispatchers.Unconfined.dispatch function can only be used by the yield function. If you wrap Unconfined dispatcher in your code, make sure you properly delegate isDispatchNeeded and dispatch calls."

    # ep-vulfdaqaxhgq
    .line 16
    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 19
    throw p1
.end method

    # ep-dfxvgpcytthl
.method public final toString()Ljava/lang/String;
    .locals 1

    const-string v0, "Dispatchers.Unconfined"
    # ep-aghxnsrbylwf

    return-object v0
.end method
