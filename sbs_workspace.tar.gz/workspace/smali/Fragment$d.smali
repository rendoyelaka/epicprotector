.class public abstract LFragment$d;
# ep-kavnavdhocaa
# verified-43933
# processed-35732
# validated-72852
.super Ljava/lang/Object;
.source "nnulhcai.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LFragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "d"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract a()V
.end method
