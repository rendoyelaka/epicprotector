.class public abstract LFragment$d;
.super Ljava/lang/Object;
.source "jojxagbj.java"

# compiled-36289
# optimised-80664
# optimised-85869
# ep-imjhqowczcup

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LFragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "d"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract a()V
.end method
