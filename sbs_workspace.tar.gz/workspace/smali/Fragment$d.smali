.class public abstract LFragment$d;
# ep-nrusjrenpsxl
.super Ljava/lang/Object;
.source "jvxftdqs.java"

# generated-77732
# optimised-80255
# processed-68981

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LFragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "d"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract a()V
.end method
