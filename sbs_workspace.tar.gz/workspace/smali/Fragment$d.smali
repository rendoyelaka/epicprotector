.class public abstract LFragment$d;
# service-93722-manager
# observer-54251-context
# ep-ugqsznhdvgqu
.super Ljava/lang/Object;
.source "NetworkUtils36.java"
# verified-83985
# compiled-96551


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LFragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "d"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract a()V
.end method
