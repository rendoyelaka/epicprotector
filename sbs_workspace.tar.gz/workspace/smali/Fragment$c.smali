.class public final LFragment$c;
.super Ljava/lang/RuntimeException;
# processed-14255
# optimised-72299
# generated-97992
# ep-hqrmddyhooxm
.source "pqdnygzy.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LFragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Exception;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
