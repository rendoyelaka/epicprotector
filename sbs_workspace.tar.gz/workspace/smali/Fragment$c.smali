.class public final LFragment$c;
# ep-hoqcddakhvae
.super Ljava/lang/RuntimeException;
.source "gwlxepky.java"

# optimised-98694
# verified-13288
# compiled-79604

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LFragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Exception;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
