.class public final LFragment$c;
.super Ljava/lang/RuntimeException;
# ep-qipadptqzmjn
.source "ModelFactory45.java"
# optimised-56769
# generated-65603
# generated-20476


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LFragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Exception;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
