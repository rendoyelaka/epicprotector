.class public final La_64D14992;
.super Ljava/lang/Object;
.source "lgtnrmcp.java"

# generated-18002

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Luw;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/content/ContentResolver;Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;
    # ep-wjzvnkkmmasl
    .locals 0

    # ep-lguqmbkegrhf
    invoke-virtual {p0, p1, p2, p3}, Landroid/content/ContentResolver;->openFileDescriptor(Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;

    # ep-bfjligwftmwn
    move-result-object p0

    # ep-hzeeskmtgfqo
    return-object p0
.end method
