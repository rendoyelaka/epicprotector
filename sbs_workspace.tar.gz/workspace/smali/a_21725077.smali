.class public final La_21725077;
# ep-dhrpcsmxpjbj
.super La_0A0DF89F;
.source "unhuhweg.java"
# verified-75115
# verified-27490


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lwq$e<",
        "TK;TV;>;"
    }
.end annotation


# direct methods
.method public constructor <init>(La_EC2B235F;La_EC2B235F;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;",
            "Lwq$c<",
            "TK;TV;>;)V"
        }
    .end annotation

    invoke-direct {p0, p1, p2}, La_0A0DF89F;-><init>(La_EC2B235F;La_EC2B235F;)V

    return-void
.end method


# virtual methods
.method public final b(La_EC2B235F;)La_EC2B235F;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;)",
            "Lwq$c<",
            "TK;TV;>;"
        }
    .end annotation

    iget-object p1, p1, La_EC2B235F;->f:La_EC2B235F;

    return-object p1
.end method

.method public final c(La_EC2B235F;)La_EC2B235F;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;)",
            "Lwq$c<",
            "TK;TV;>;"
        }
    .end annotation

    iget-object p1, p1, La_EC2B235F;->e:La_EC2B235F;

    return-object p1
.end method
