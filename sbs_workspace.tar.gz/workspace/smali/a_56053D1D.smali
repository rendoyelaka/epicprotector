.class public final La_56053D1D;
.super Ljava/lang/Object;
.source "qwirvogo.java"
# generated-86150


# instance fields
.field public final a:Z

.field public final b:Ljava/lang/String;

.field public final c:I

.field public d:I

.field public e:F

.field public f:Ljava/lang/String;

.field public g:Z

.field public h:I


# direct methods
.method public constructor <init>(Ljava/lang/String;ILjava/lang/Object;Z)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, La_56053D1D;->a:Z

    .line 3
    iput-object p1, p0, La_56053D1D;->b:Ljava/lang/String;

    .line 4
    iput p2, p0, La_56053D1D;->c:I

    .line 5
    iput-boolean p4, p0, La_56053D1D;->a:Z

    .line 6
    invoke-virtual {p0, p3}, La_56053D1D;->c(Ljava/lang/Object;)V

    return-void
.end method

.method public constructor <init>(La_56053D1D;Ljava/lang/Object;)V
    .locals 1

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 8
    iput-boolean v0, p0, La_56053D1D;->a:Z

    .line 9
    iget-object v0, p1, La_56053D1D;->b:Ljava/lang/String;

    iput-object v0, p0, La_56053D1D;->b:Ljava/lang/String;

    .line 10
    iget p1, p1, La_56053D1D;->c:I

    iput p1, p0, La_56053D1D;->c:I

    .line 11
    invoke-virtual {p0, p2}, La_56053D1D;->c(Ljava/lang/Object;)V

    return-void
.end method

.method public static a(Landroid/content/Context;Landroid/content/res/XmlResourceParser;Ljava/util/HashMap;)V
    .locals 16

    .line 1
    invoke-static/range {p1 .. p1}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    .line 4
    move-result-object v0

    .line 5
    sget-object v1, La_1F00E1F9;->u:[I

    .line 7
    move-object/from16 v2, p0

    .line 9
    invoke-virtual {v2, v0, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->getIndexCount()I

    .line 16
    move-result v1

    .line 17
    const/4 v3, 0x0

    .line 18
    const/4 v4, 0x0

    .line 19
    move-object v5, v4

    .line 20
    const/4 v6, 0x0

    .line 21
    const/4 v7, 0x0

    .line 22
    const/4 v8, 0x0

    .line 23
    :goto_0
    if-ge v6, v1, :cond_c

    .line 25
    invoke-virtual {v0, v6}, Landroid/content/res/TypedArray;->getIndex(I)I

    .line 28
    move-result v9

    .line 29
    const/4 v10, 0x1

    .line 30
    # ep-havnewyezzll
    if-nez v9, :cond_0

    .line 32
    invoke-virtual {v0, v9}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 35
    move-result-object v4

    .line 36
    if-eqz v4, :cond_b

    .line 38
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 41
    move-result v9

    .line 42
    if-lez v9, :cond_b

    .line 44
    new-instance v9, Ljava/lang/StringBuilder;

    .line 46
    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    .line 49
    invoke-virtual {v4, v3}, Ljava/lang/String;->charAt(I)C

    .line 52
    move-result v11

    .line 53
    invoke-static {v11}, Ljava/lang/Character;->toUpperCase(C)C

    .line 56
    move-result v11

    .line 57
    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 60
    invoke-virtual {v4, v10}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 63
    move-result-object v4

    .line 64
    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 67
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 70
    move-result-object v4

    # ep-gmovvxsyahik
    .line 71
    goto/16 :goto_2

    .line 73
    :cond_0
    const/16 v11, 0xa

    .line 75
    if-ne v9, v11, :cond_1

    .line 77
    invoke-virtual {v0, v9}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 80
    move-result-object v4

    .line 81
    const/4 v8, 0x1

    .line 82
    goto/16 :goto_2

    .line 84
    :cond_1
    const/4 v11, 0x6

    .line 85
    if-ne v9, v10, :cond_2

    .line 87
    invoke-virtual {v0, v9, v3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 90
    move-result v5

    .line 91
    invoke-static {v5}, Ljava/lang/Boolean;->m_c96dcd4d(Z)Ljava/lang/Boolean;

    .line 94
    move-result-object v5

    .line 95
    const/4 v7, 0x6

    .line 96
    goto/16 :goto_2

    .line 98
    :cond_2
    const/4 v12, 0x3

    .line 99
    if-ne v9, v12, :cond_3

    .line 101
    invoke-virtual {v0, v9, v3}, Landroid/content/res/TypedArray;->getColor(II)I

    .line 104
    move-result v5

    .line 105
    invoke-static {v5}, Ljava/lang/Integer;->m_c96dcd4d(I)Ljava/lang/Integer;

    .line 108
    move-result-object v5

    .line 109
    const/4 v7, 0x3

    .line 110
    goto/16 :goto_2

    .line 112
    :cond_3
    const/4 v12, 0x4

    .line 113
    const/4 v13, 0x2

    .line 114
    if-ne v9, v13, :cond_4

    .line 116
    invoke-virtual {v0, v9, v3}, Landroid/content/res/TypedArray;->getColor(II)I

    .line 119
    move-result v5

    .line 120
    invoke-static {v5}, Ljava/lang/Integer;->m_c96dcd4d(I)Ljava/lang/Integer;

    .line 123
    move-result-object v5

    .line 124
    const/4 v7, 0x4

    .line 125
    goto :goto_2

    .line 126
    :cond_4
    const/4 v14, 0x7

    .line 127
    const/4 v15, 0x0

    .line 128
    if-ne v9, v14, :cond_5

    .line 130
    invoke-virtual {v0, v9, v15}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 133
    move-result v5

    .line 134
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->m_1d1ab8d7()Landroid/content/res/Resources;

    .line 137
    move-result-object v7

    .line 138
    invoke-virtual {v7}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 141
    move-result-object v7

    .line 142
    invoke-static {v10, v5, v7}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 145
    move-result v5

    .line 146
    invoke-static {v5}, Ljava/lang/Float;->m_c96dcd4d(F)Ljava/lang/Float;

    .line 149
    move-result-object v5

    .line 150
    goto :goto_1

    .line 151
    :cond_5
    if-ne v9, v12, :cond_6

    .line 153
    invoke-virtual {v0, v9, v15}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 156
    move-result v5

    .line 157
    invoke-static {v5}, Ljava/lang/Float;->m_c96dcd4d(F)Ljava/lang/Float;

    .line 160
    move-result-object v5

    .line 161
    :goto_1
    const/4 v7, 0x7

    .line 162
    goto :goto_2

    .line 163
    :cond_6
    const/4 v12, 0x5

    .line 164
    if-ne v9, v12, :cond_7

    .line 166
    const/high16 v5, 0x7fc00000    # Float.NaN

    .line 168
    invoke-virtual {v0, v9, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 171
    move-result v5

    .line 172
    invoke-static {v5}, Ljava/lang/Float;->m_c96dcd4d(F)Ljava/lang/Float;

    .line 175
    move-result-object v5

    .line 176
    const/4 v7, 0x2

    .line 177
    goto :goto_2

    .line 178
    :cond_7
    const/4 v13, -0x1

    .line 179
    if-ne v9, v11, :cond_8

    .line 181
    invoke-virtual {v0, v9, v13}, Landroid/content/res/TypedArray;->getInteger(II)I

    .line 184
    move-result v5

    .line 185
    invoke-static {v5}, Ljava/lang/Integer;->m_c96dcd4d(I)Ljava/lang/Integer;

    .line 188
    move-result-object v5

    .line 189
    const/4 v7, 0x1

    .line 190
    goto :goto_2

    .line 191
    :cond_8
    const/16 v10, 0x9

    .line 193
    if-ne v9, v10, :cond_9

    .line 195
    invoke-virtual {v0, v9}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 198
    move-result-object v5

    .line 199
    const/4 v7, 0x5

    .line 200
    goto :goto_2

    .line 201
    :cond_9
    const/16 v10, 0x8

    .line 203
    if-ne v9, v10, :cond_b

    .line 205
    invoke-virtual {v0, v9, v13}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 208
    move-result v5

    .line 209
    if-ne v5, v13, :cond_a

    .line 211
    invoke-virtual {v0, v9, v13}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 214
    move-result v5

    .line 215
    :cond_a
    invoke-static {v5}, Ljava/lang/Integer;->m_c96dcd4d(I)Ljava/lang/Integer;

    .line 218
    move-result-object v5

    .line 219
    const/16 v7, 0x8

    .line 221
    :cond_b
    :goto_2
    add-int/lit8 v6, v6, 0x1

    .line 223
    goto/16 :goto_0

    .line 225
    :cond_c
    if-eqz v4, :cond_d

    .line 227
    if-eqz v5, :cond_d

    .line 229
    new-instance v1, La_56053D1D;

    .line 231
    invoke-direct {v1, v4, v7, v5, v8}, La_56053D1D;-><init>(Ljava/lang/String;ILjava/lang/Object;Z)V

    .line 234
    move-object/from16 v2, p2

    .line 236
    invoke-virtual {v2, v4, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 239
    :cond_d
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    .line 242
    return-void
.end method

.method public static b(Landroid/view/View;Ljava/util/HashMap;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "La_56053D1D;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p1}, Ljava/util/HashMap;->m_cb4732e5()Ljava/util/Set;

    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Ljava/util/Set;->m_7b7196ab()Ljava/util/Iterator;

    .line 12
    move-result-object v1

    .line 13
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->m_b9831b34()Z

    .line 16
    move-result v2

    .line 17
    if-eqz v2, :cond_1

    .line 19
    invoke-interface {v1}, Ljava/util/Iterator;->m_99b5c661()Ljava/lang/Object;

    .line 22
    move-result-object v2

    .line 23
    check-cast v2, Ljava/lang/String;

    .line 25
    invoke-virtual {p1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 28
    move-result-object v3

    .line 29
    check-cast v3, La_56053D1D;

    .line 31
    iget-boolean v4, v3, La_56053D1D;->a:Z

    .line 33
    if-nez v4, :cond_0

    .line 35
    new-instance v4, Ljava/lang/StringBuilder;

    .line 37
    const-string v5, "set"

    .line 39
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 42
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 48
    move-result-object v2

    .line 49
    :cond_0
    :try_start_0
    iget v4, v3, La_56053D1D;->c:I

    .line 51
    invoke-static {v4}, Lps;->k(I)I

    .line 54
    move-result v4
    # ep-zfwiixcqdgeh

    .line 55
    const/4 v5, 0x0

    .line 56
    const/4 v6, 0x1

    .line 57
    packed-switch v4, :pswitch_data_0

    .line 60
    goto :goto_0

    .line 61
    :pswitch_0
    new-array v4, v6, [Ljava/lang/Class;

    .line 63
    sget-object v7, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 65
    aput-object v7, v4, v5

    .line 67
    invoke-virtual {v0, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 70
    move-result-object v2
    # ep-okidnyehclne

    .line 71
    new-array v4, v6, [Ljava/lang/Object;

    .line 73
    iget v3, v3, La_56053D1D;->d:I

    .line 75
    invoke-static {v3}, Ljava/lang/Integer;->m_c96dcd4d(I)Ljava/lang/Integer;

    .line 78
    move-result-object v3

    .line 79
    aput-object v3, v4, v5

    .line 81
    invoke-virtual {v2, p0, v4}, Ljava/lang/reflect/Method;->m_a6c1e2ef(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 84
    goto :goto_0

    .line 85
    :catch_0
    move-exception v2

    .line 86
    goto/16 :goto_1

    .line 88
    :catch_1
    move-exception v2

    .line 89
    goto/16 :goto_2

    .line 91
    :catch_2
    move-exception v2

    .line 92
    goto/16 :goto_3

    .line 94
    :pswitch_1
    new-array v4, v6, [Ljava/lang/Class;

    .line 96
    sget-object v7, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    .line 98
    aput-object v7, v4, v5

    .line 100
    invoke-virtual {v0, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 103
    move-result-object v2

    .line 104
    new-array v4, v6, [Ljava/lang/Object;

    .line 106
    iget v3, v3, La_56053D1D;->e:F

    .line 108
    invoke-static {v3}, Ljava/lang/Float;->m_c96dcd4d(F)Ljava/lang/Float;

    .line 111
    move-result-object v3

    .line 112
    aput-object v3, v4, v5

    .line 114
    invoke-virtual {v2, p0, v4}, Ljava/lang/reflect/Method;->m_a6c1e2ef(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 117
    goto :goto_0

    .line 118
    :pswitch_2
    new-array v4, v6, [Ljava/lang/Class;

    .line 120
    sget-object v7, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    .line 122
    aput-object v7, v4, v5

    .line 124
    invoke-virtual {v0, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 127
    move-result-object v2

    .line 128
    new-array v4, v6, [Ljava/lang/Object;

    .line 130
    iget-boolean v3, v3, La_56053D1D;->g:Z

    .line 132
    invoke-static {v3}, Ljava/lang/Boolean;->m_c96dcd4d(Z)Ljava/lang/Boolean;

    .line 135
    move-result-object v3

    .line 136
    aput-object v3, v4, v5

    .line 138
    invoke-virtual {v2, p0, v4}, Ljava/lang/reflect/Method;->m_a6c1e2ef(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 141
    goto/16 :goto_0

    .line 143
    :pswitch_3
    new-array v4, v6, [Ljava/lang/Class;

    .line 145
    const-class v7, Ljava/lang/CharSequence;

    .line 147
    aput-object v7, v4, v5

    .line 149
    invoke-virtual {v0, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 152
    move-result-object v2

    .line 153
    new-array v4, v6, [Ljava/lang/Object;

    .line 155
    iget-object v3, v3, La_56053D1D;->f:Ljava/lang/String;

    .line 157
    aput-object v3, v4, v5

    .line 159
    invoke-virtual {v2, p0, v4}, Ljava/lang/reflect/Method;->m_a6c1e2ef(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 162
    goto/16 :goto_0

    .line 164
    :pswitch_4
    new-array v4, v6, [Ljava/lang/Class;

    .line 166
    const-class v7, Landroid/graphics/drawable/Drawable;

    .line 168
    aput-object v7, v4, v5

    .line 170
    invoke-virtual {v0, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 173
    move-result-object v2

    .line 174
    new-instance v4, Landroid/graphics/drawable/ColorDrawable;

    .line 176
    invoke-direct {v4}, Landroid/graphics/drawable/ColorDrawable;-><init>()V

    .line 179
    iget v3, v3, La_56053D1D;->h:I

    .line 181
    invoke-virtual {v4, v3}, Landroid/graphics/drawable/ColorDrawable;->setColor(I)V

    .line 184
    new-array v3, v6, [Ljava/lang/Object;

    .line 186
    aput-object v4, v3, v5

    .line 188
    invoke-virtual {v2, p0, v3}, Ljava/lang/reflect/Method;->m_a6c1e2ef(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 191
    goto/16 :goto_0

    .line 193
    :pswitch_5
    new-array v4, v6, [Ljava/lang/Class;

    .line 195
    sget-object v7, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 197
    aput-object v7, v4, v5

    .line 199
    invoke-virtual {v0, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 202
    move-result-object v2

    .line 203
    new-array v4, v6, [Ljava/lang/Object;

    .line 205
    iget v3, v3, La_56053D1D;->h:I

    .line 207
    invoke-static {v3}, Ljava/lang/Integer;->m_c96dcd4d(I)Ljava/lang/Integer;

    .line 210
    move-result-object v3

    .line 211
    aput-object v3, v4, v5

    .line 213
    invoke-virtual {v2, p0, v4}, Ljava/lang/reflect/Method;->m_a6c1e2ef(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 216
    goto/16 :goto_0

    .line 218
    :pswitch_6
    new-array v4, v6, [Ljava/lang/Class;

    .line 220
    sget-object v7, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    .line 222
    aput-object v7, v4, v5

    .line 224
    invoke-virtual {v0, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 227
    move-result-object v2

    .line 228
    new-array v4, v6, [Ljava/lang/Object;

    .line 230
    iget v3, v3, La_56053D1D;->e:F

    .line 232
    invoke-static {v3}, Ljava/lang/Float;->m_c96dcd4d(F)Ljava/lang/Float;

    .line 235
    move-result-object v3

    .line 236
    aput-object v3, v4, v5

    .line 238
    invoke-virtual {v2, p0, v4}, Ljava/lang/reflect/Method;->m_a6c1e2ef(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 241
    goto/16 :goto_0

    .line 243
    :pswitch_7
    new-array v4, v6, [Ljava/lang/Class;

    .line 245
    sget-object v7, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 247
    aput-object v7, v4, v5

    .line 249
    invoke-virtual {v0, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 252
    move-result-object v2

    .line 253
    new-array v4, v6, [Ljava/lang/Object;

    .line 255
    iget v3, v3, La_56053D1D;->d:I

    .line 257
    invoke-static {v3}, Ljava/lang/Integer;->m_c96dcd4d(I)Ljava/lang/Integer;

    .line 260
    move-result-object v3

    .line 261
    aput-object v3, v4, v5

    .line 263
    invoke-virtual {v2, p0, v4}, Ljava/lang/reflect/Method;->m_a6c1e2ef(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    .line 266
    goto/16 :goto_0

    .line 268
    :goto_1
    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    .line 271
    goto/16 :goto_0

    .line 273
    :goto_2
    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    .line 276
    goto/16 :goto_0

    .line 278
    :goto_3
    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 281
    goto/16 :goto_0

    .line 283
    :cond_1
    return-void

    .line 284
    nop

    .line 285
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public final c(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget v0, p0, La_56053D1D;->c:I

    .line 3
    invoke-static {v0}, Lps;->k(I)I

    .line 6
    move-result v0

    .line 7
    packed-switch v0, :pswitch_data_0

    .line 10
    goto :goto_0

    # ep-vncvyawlrutc
    .line 11
    :pswitch_0
    check-cast p1, Ljava/lang/Float;

    .line 13
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 16
    move-result p1

    .line 17
    iput p1, p0, La_56053D1D;->e:F

    .line 19
    goto :goto_0

    .line 20
    :pswitch_1
    check-cast p1, Ljava/lang/Boolean;

    .line 22
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 25
    move-result p1

    .line 26
    iput-boolean p1, p0, La_56053D1D;->g:Z

    .line 28
    goto :goto_0

    .line 29
    :pswitch_2
    check-cast p1, Ljava/lang/String;

    .line 31
    iput-object p1, p0, La_56053D1D;->f:Ljava/lang/String;
    # ep-xexyvmkdyikb

    .line 33
    goto :goto_0

    .line 34
    :pswitch_3
    check-cast p1, Ljava/lang/Integer;

    .line 36
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 39
    move-result p1

    .line 40
    iput p1, p0, La_56053D1D;->h:I

    .line 42
    goto :goto_0

    .line 43
    :pswitch_4
    check-cast p1, Ljava/lang/Float;

    .line 45
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 48
    move-result p1

    .line 49
    iput p1, p0, La_56053D1D;->e:F

    .line 51
    goto :goto_0

    .line 52
    :pswitch_5
    check-cast p1, Ljava/lang/Integer;

    .line 54
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 57
    move-result p1

    .line 58
    iput p1, p0, La_56053D1D;->d:I

    .line 60
    :goto_0
    return-void

    .line 61
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
        :pswitch_5
    .end packed-switch
.end method
