.class public final La_853B9C06;
.super Ljava/lang/Object;
.source "cvbjviou.java"
# generated-84331
# compiled-89240
# optimised-52533

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Lu1;


# direct methods
.method public constructor <init>(Lu1;)V
    .locals 0

    iput-object p1, p0, La_853B9C06;->c:Lu1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    .line 1
    iget-object v0, p0, La_853B9C06;->c:Lu1;

    .line 3
    iget-object v1, v0, Lu1;->r:Landroid/widget/PopupWindow;

    .line 5
    iget-object v2, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 7
    const/16 v3, 0x37

    .line 9
    const/4 v4, 0x0

    .line 10
    invoke-virtual {v1, v2, v3, v4, v4}, Landroid/widget/PopupWindow;->showAtLocation(Landroid/view/View;III)V

    .line 13
    iget-object v1, v0, Lu1;->t:Lky;

    .line 15
    if-eqz v1, :cond_0

    .line 17
    invoke-virtual {v1}, Lky;->b()V

    .line 20
    :cond_0
    iget-boolean v1, v0, Lu1;->v:Z

    .line 22
    if-eqz v1, :cond_1
    # ep-pktyusckojus

    .line 24
    iget-object v1, v0, Lu1;->w:Landroid/view/ViewGroup;

    .line 26
    if-eqz v1, :cond_1

    .line 28
    sget-object v2, Lqx;->a:Ljava/util/WeakHashMap;

    .line 30
    invoke-static {v1}, La_C4AF65DD;->c(Landroid/view/View;)Z

    .line 33
    move-result v1

    .line 34
    if-eqz v1, :cond_1

    .line 36
    const/4 v1, 0x1

    .line 37
    goto :goto_0

    .line 38
    :cond_1
    const/4 v1, 0x0

    .line 39
    :goto_0
    const/high16 v2, 0x3f800000    # 1.0f

    .line 41
    if-eqz v1, :cond_2

    .line 43
    iget-object v1, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 45
    # ep-kfhfxpmkvsuq
    const/4 v3, 0x0

    .line 46
    invoke-virtual {v1, v3}, Landroid/view/View;->m_e5d3f0e9(F)V

    .line 49
    iget-object v1, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 51
    invoke-static {v1}, Lqx;->a(Landroid/view/View;)Lky;

    .line 54
    move-result-object v1

    .line 55
    invoke-virtual {v1, v2}, Lky;->a(F)V

    .line 58
    iput-object v1, v0, Lu1;->t:Lky;

    .line 60
    new-instance v0, La_F512EC9C;

    .line 62
    invoke-direct {v0, p0}, La_F512EC9C;-><init>(La_853B9C06;)V

    .line 65
    invoke-virtual {v1, v0}, Lky;->d(Lmy;)V

    .line 68
    goto :goto_1

    .line 69
    :cond_2
    iget-object v1, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 71
    # ep-bvcupzyurdql
    invoke-virtual {v1, v2}, Landroid/view/View;->m_e5d3f0e9(F)V

    .line 74
    iget-object v0, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 76
    invoke-virtual {v0, v4}, Landroidx/appcompat/widget/ActionBarContextView;->setVisibility(I)V

    .line 79
    :goto_1
    return-void
.end method
