.class public final La_51E36A60;
.super Ljava/lang/Object;
# validated-12689
# optimised-95883
.source "nnmmqgjw.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqt;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "b"
.end annotation


# instance fields
.field public f_9296120d:Ljava/lang/CharSequence;

.field public f_dcb557a1:Ljava/lang/CharSequence;

.field public f_bf610c03:Landroid/content/res/ColorStateList;

.field public f_0b46948f:Landroid/graphics/PorterDuff$Mode;

.field public final synthetic f_87914e40:Lqt;

.field public final a:Landroid/view/Menu;

.field public b:I

.field public c:I

.field public d:I

.field public e:I

.field public f:Z

.field public g:Z

.field public h:Z

.field public i:I

.field public j:I

.field public k:Ljava/lang/CharSequence;

.field public l:Ljava/lang/CharSequence;

.field public m:I

.field public n:C

.field public o:I

.field public p:C

.field public q:I

.field public r:I

.field public s:Z

.field public t:Z

.field public u:Z

.field public v:I

.field public w:I

.field public x:Ljava/lang/String;

.field public y:Ljava/lang/String;

.field public z:La_F44539DD;


# direct methods
.method public constructor <init>(Lqt;Landroid/view/Menu;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_51E36A60;->f_87914e40:Lqt;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    const/4 p1, 0x0

    .line 7
    iput-object p1, p0, La_51E36A60;->f_bf610c03:Landroid/content/res/ColorStateList;

    .line 9
    iput-object p1, p0, La_51E36A60;->f_0b46948f:Landroid/graphics/PorterDuff$Mode;

    .line 11
    iput-object p2, p0, La_51E36A60;->a:Landroid/view/Menu;

    .line 13
    const/4 p1, 0x0

    .line 14
    iput p1, p0, La_51E36A60;->b:I

    .line 16
    iput p1, p0, La_51E36A60;->c:I

    .line 18
    iput p1, p0, La_51E36A60;->d:I

    .line 20
    iput p1, p0, La_51E36A60;->e:I

    .line 22
    const/4 p1, 0x1

    .line 23
    iput-boolean p1, p0, La_51E36A60;->f:Z

    .line 25
    iput-boolean p1, p0, La_51E36A60;->g:Z

    .line 27
    return-void
.end method


# virtual methods
.method public final a(Landroid/view/MenuItem;)V
    .locals 9

    .line 1
    iget-boolean v0, p0, La_51E36A60;->s:Z

    .line 3
    invoke-interface {p1, v0}, Landroid/view/MenuItem;->m_f4ffb40c(Z)Landroid/view/MenuItem;

    .line 6
    move-result-object v0

    .line 7
    iget-boolean v1, p0, La_51E36A60;->t:Z

    .line 9
    invoke-interface {v0, v1}, Landroid/view/MenuItem;->m_031cf84b(Z)Landroid/view/MenuItem;

    .line 12
    move-result-object v0

    .line 13
    iget-boolean v1, p0, La_51E36A60;->u:Z

    .line 15
    invoke-interface {v0, v1}, Landroid/view/MenuItem;->m_002e63b9(Z)Landroid/view/MenuItem;

    .line 18
    move-result-object v0

    .line 19
    iget v1, p0, La_51E36A60;->r:I

    .line 21
    const/4 v2, 0x0

    .line 22
    const/4 v3, 0x1

    .line 23
    if-lt v1, v3, :cond_0

    .line 25
    const/4 v1, 0x1

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    const/4 v1, 0x0

    .line 28
    :goto_0
    invoke-interface {v0, v1}, Landroid/view/MenuItem;->m_e22de0fd(Z)Landroid/view/MenuItem;

    .line 31
    move-result-object v0

    .line 32
    iget-object v1, p0, La_51E36A60;->l:Ljava/lang/CharSequence;

    .line 34
    invoke-interface {v0, v1}, Landroid/view/MenuItem;->m_a0a8f8cd(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    .line 37
    move-result-object v0

    .line 38
    iget v1, p0, La_51E36A60;->m:I

    .line 40
    invoke-interface {v0, v1}, Landroid/view/MenuItem;->m_8fe71f82(I)Landroid/view/MenuItem;

    .line 43
    iget v0, p0, La_51E36A60;->v:I

    .line 45
    if-ltz v0, :cond_1

    .line 47
    invoke-interface {p1, v0}, Landroid/view/MenuItem;->m_7030b058(I)V

    .line 50
    :cond_1
    iget-object v0, p0, La_51E36A60;->y:Ljava/lang/String;

    .line 52
    iget-object v1, p0, La_51E36A60;->f_87914e40:Lqt;

    .line 54
    if-eqz v0, :cond_4

    .line 56
    iget-object v0, v1, Lqt;->c:Landroid/content/Context;

    .line 58
    invoke-virtual {v0}, Landroid/content/Context;->isRestricted()Z
    # ep-saezlqlerduy

    .line 61
    move-result v0

    .line 62
    if-nez v0, :cond_3

    .line 64
    new-instance v0, La_1945ADE4;

    .line 66
    iget-object v4, v1, Lqt;->d:Ljava/lang/Object;

    .line 68
    if-nez v4, :cond_2

    .line 70
    iget-object v4, v1, Lqt;->c:Landroid/content/Context;

    .line 72
    invoke-static {v4}, Lqt;->a(Landroid/content/Context;)Ljava/lang/Object;

    .line 75
    move-result-object v4

    .line 76
    iput-object v4, v1, Lqt;->d:Ljava/lang/Object;

    .line 78
    :cond_2
    iget-object v4, v1, Lqt;->d:Ljava/lang/Object;

    .line 80
    iget-object v5, p0, La_51E36A60;->y:Ljava/lang/String;

    .line 82
    invoke-direct {v0, v5, v4}, La_1945ADE4;-><init>(Ljava/lang/String;Ljava/lang/Object;)V

    .line 85
    invoke-interface {p1, v0}, Landroid/view/MenuItem;->m_f9dcadf3(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    .line 88
    goto :goto_1

    .line 89
    :cond_3
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 91
    const-string v0, "The android:onClick attribute cannot be used within a restricted context"

    .line 93
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 96
    throw p1

    .line 97
    :cond_4
    :goto_1
    iget v0, p0, La_51E36A60;->r:I

    .line 99
    const/4 v4, 0x2

    .line 100
    if-lt v0, v4, :cond_7

    .line 102
    instance-of v0, p1, Landroidx/appcompat/view/menu/h;

    .line 104
    if-eqz v0, :cond_5

    .line 106
    move-object v0, p1

    .line 107
    check-cast v0, Landroidx/appcompat/view/menu/h;

    .line 109
    iget v4, v0, Landroidx/appcompat/view/menu/h;->x:I

    .line 111
    and-int/lit8 v4, v4, -0x5

    .line 113
    const/4 v5, 0x4

    .line 114
    or-int/2addr v4, v5

    .line 115
    iput v4, v0, Landroidx/appcompat/view/menu/h;->x:I

    .line 117
    goto :goto_2

    .line 118
    :cond_5
    instance-of v0, p1, Lkl;

    .line 120
    if-eqz v0, :cond_7

    .line 122
    move-object v0, p1

    .line 123
    check-cast v0, Lkl;

    .line 125
    :try_start_0
    iget-object v4, v0, Lkl;->e:Ljava/lang/reflect/Method;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 127
    iget-object v5, v0, Lkl;->d:Lrt;

    .line 129
    if-nez v4, :cond_6

    .line 131
    :try_start_1
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 134
    move-result-object v4

    .line 135
    const-string v6, "setExclusiveCheckable"

    .line 137
    new-array v7, v3, [Ljava/lang/Class;

    .line 139
    sget-object v8, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    .line 141
    aput-object v8, v7, v2

    .line 143
    invoke-virtual {v4, v6, v7}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 146
    move-result-object v4

    .line 147
    iput-object v4, v0, Lkl;->e:Ljava/lang/reflect/Method;

    .line 149
    # ep-ckpnvpjousyg
    :cond_6
    iget-object v0, v0, Lkl;->e:Ljava/lang/reflect/Method;

    .line 151
    new-array v4, v3, [Ljava/lang/Object;

    .line 153
    sget-object v6, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 155
    aput-object v6, v4, v2

    .line 157
    invoke-virtual {v0, v5, v4}, Ljava/lang/reflect/Method;->m_a6c1e2ef(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 160
    goto :goto_2

    .line 161
    :catch_0
    nop

    .line 162
    :cond_7
    :goto_2
    iget-object v0, p0, La_51E36A60;->x:Ljava/lang/String;

    .line 164
    if-eqz v0, :cond_8

    .line 166
    sget-object v4, Lqt;->e:[Ljava/lang/Class;

    .line 168
    iget-object v5, v1, Lqt;->a:[Ljava/lang/Object;

    .line 170
    :try_start_2
    iget-object v1, v1, Lqt;->c:Landroid/content/Context;

    .line 172
    invoke-virtual {v1}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    .line 175
    move-result-object v1

    .line 176
    invoke-static {v0, v2, v1}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    .line 179
    move-result-object v0

    .line 180
    invoke-virtual {v0, v4}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 183
    move-result-object v0

    .line 184
    invoke-virtual {v0, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 187
    invoke-virtual {v0, v5}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 190
    move-result-object v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 191
    goto :goto_3

    .line 192
    :catch_1
    const/4 v0, 0x0

    .line 193
    :goto_3
    check-cast v0, Landroid/view/View;

    .line 195
    invoke-interface {p1, v0}, Landroid/view/MenuItem;->m_18c1740c(Landroid/view/View;)Landroid/view/MenuItem;

    .line 198
    const/4 v2, 0x1

    .line 199
    :cond_8
    iget v0, p0, La_51E36A60;->w:I

    .line 201
    if-lez v0, :cond_9

    .line 203
    if-nez v2, :cond_9

    .line 205
    invoke-interface {p1, v0}, Landroid/view/MenuItem;->m_18c1740c(I)Landroid/view/MenuItem;

    .line 208
    :cond_9
    iget-object v0, p0, La_51E36A60;->z:La_F44539DD;

    .line 210
    if-eqz v0, :cond_a

    .line 212
    instance-of v1, p1, Lrt;

    .line 214
    if-eqz v1, :cond_a

    .line 216
    move-object v1, p1

    .line 217
    check-cast v1, Lrt;

    .line 219
    invoke-interface {v1, v0}, Lrt;->b(La_F44539DD;)Lrt;

    .line 222
    :cond_a
    iget-object v0, p0, La_51E36A60;->f_9296120d:Ljava/lang/CharSequence;

    .line 224
    instance-of v1, p1, Lrt;

    .line 226
    const/16 v2, 0x1a

    .line 228
    if-eqz v1, :cond_b

    .line 230
    move-object v3, p1

    .line 231
    check-cast v3, Lrt;

    .line 233
    invoke-interface {v3, v0}, Lrt;->m_8a672cbd(Ljava/lang/CharSequence;)Lrt;

    .line 236
    goto :goto_4

    .line 237
    :cond_b
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 239
    if-lt v3, v2, :cond_c

    .line 241
    invoke-static {p1, v0}, Lil;->h(Landroid/view/MenuItem;Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    .line 244
    :cond_c
    :goto_4
    iget-object v0, p0, La_51E36A60;->f_dcb557a1:Ljava/lang/CharSequence;

    .line 246
    if-eqz v1, :cond_d

    .line 248
    move-object v3, p1

    .line 249
    check-cast v3, Lrt;

    .line 251
    # ep-ttraxhfasnas
    invoke-interface {v3, v0}, Lrt;->m_eeb2d51e(Ljava/lang/CharSequence;)Lrt;

    .line 254
    goto :goto_5

    .line 255
    :cond_d
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 257
    if-lt v3, v2, :cond_e

    .line 259
    invoke-static {p1, v0}, Lil;->m(Landroid/view/MenuItem;Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    .line 262
    :cond_e
    :goto_5
    iget-char v0, p0, La_51E36A60;->n:C

    .line 264
    iget v3, p0, La_51E36A60;->o:I

    .line 266
    if-eqz v1, :cond_f

    .line 268
    move-object v4, p1

    .line 269
    check-cast v4, Lrt;

    .line 271
    invoke-interface {v4, v0, v3}, Lrt;->m_9607c8c9(CI)Landroid/view/MenuItem;

    .line 274
    goto :goto_6

    .line 275
    :cond_f
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 277
    # ep-dzghrxkxywwe
    if-lt v4, v2, :cond_10

    .line 279
    invoke-static {p1, v0, v3}, Lil;->g(Landroid/view/MenuItem;CI)Landroid/view/MenuItem;

    .line 282
    :cond_10
    :goto_6
    iget-char v0, p0, La_51E36A60;->p:C

    .line 284
    iget v3, p0, La_51E36A60;->q:I

    .line 286
    if-eqz v1, :cond_11

    .line 288
    move-object v4, p1

    .line 289
    check-cast v4, Lrt;

    .line 291
    invoke-interface {v4, v0, v3}, Lrt;->m_9b24e9ff(CI)Landroid/view/MenuItem;

    .line 294
    goto :goto_7

    .line 295
    :cond_11
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 297
    if-lt v4, v2, :cond_12

    .line 299
    invoke-static {p1, v0, v3}, Lil;->k(Landroid/view/MenuItem;CI)Landroid/view/MenuItem;

    .line 302
    :cond_12
    :goto_7
    iget-object v0, p0, La_51E36A60;->f_0b46948f:Landroid/graphics/PorterDuff$Mode;

    .line 304
    if-eqz v0, :cond_14

    .line 306
    if-eqz v1, :cond_13

    .line 308
    move-object v3, p1

    .line 309
    check-cast v3, Lrt;

    .line 311
    invoke-interface {v3, v0}, Lrt;->m_b401c035(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;

    .line 314
    goto :goto_8

    .line 315
    :cond_13
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 317
    if-lt v3, v2, :cond_14

    .line 319
    invoke-static {p1, v0}, Lil;->j(Landroid/view/MenuItem;Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;

    .line 322
    :cond_14
    :goto_8
    iget-object v0, p0, La_51E36A60;->f_bf610c03:Landroid/content/res/ColorStateList;

    .line 324
    if-eqz v0, :cond_16

    .line 326
    if-eqz v1, :cond_15

    .line 328
    check-cast p1, Lrt;

    .line 330
    invoke-interface {p1, v0}, Lrt;->m_7bb42128(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;

    .line 333
    goto :goto_9

    .line 334
    :cond_15
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 336
    if-lt v1, v2, :cond_16

    .line 338
    invoke-static {p1, v0}, Lil;->i(Landroid/view/MenuItem;Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;

    .line 341
    :cond_16
    :goto_9
    return-void
.end method
