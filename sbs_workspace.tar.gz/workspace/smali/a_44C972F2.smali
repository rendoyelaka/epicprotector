.class public final La_44C972F2;
# ep-jvwscfhgozry
# processed-26371
# verified-32643
.super Lak;
.source "keqnwjai.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lak<",
        "Ljava/lang/Object;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic d:La_A87A3FEC;


# direct methods
.method public constructor <init>(La_A87A3FEC;)V
    .locals 0

    iput-object p1, p0, La_44C972F2;->d:La_A87A3FEC;

    invoke-direct {p0}, Lak;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 1

    iget-object v0, p0, La_44C972F2;->d:La_A87A3FEC;

    invoke-virtual {v0}, La_A87A3FEC;->m_a9dd2564()V

    return-void
.end method

.method public final b(II)Ljava/lang/Object;
    .locals 0

    iget-object p2, p0, La_44C972F2;->d:La_A87A3FEC;

    iget-object p2, p2, La_A87A3FEC;->d:[Ljava/lang/Object;

    aget-object p1, p2, p1

    return-object p1
.end method

.method public final c()Ljava/util/Map;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v1, "not a map"

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final d()I
    .locals 1

    iget-object v0, p0, La_44C972F2;->d:La_A87A3FEC;

    iget v0, v0, La_A87A3FEC;->e:I

    return v0
.end method

.method public final e(Ljava/lang/Object;)I
    .locals 1

    iget-object v0, p0, La_44C972F2;->d:La_A87A3FEC;

    invoke-virtual {v0, p1}, La_A87A3FEC;->m_0f0ebae8(Ljava/lang/Object;)I

    move-result p1

    return p1
.end method

.method public final f(Ljava/lang/Object;)I
    .locals 1

    iget-object v0, p0, La_44C972F2;->d:La_A87A3FEC;

    invoke-virtual {v0, p1}, La_A87A3FEC;->m_0f0ebae8(Ljava/lang/Object;)I

    move-result p1

    return p1
.end method

.method public final g(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ")V"
        }
    .end annotation

    iget-object p2, p0, La_44C972F2;->d:La_A87A3FEC;

    invoke-virtual {p2, p1}, La_A87A3FEC;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final h(I)V
    .locals 1

    iget-object v0, p0, La_44C972F2;->d:La_A87A3FEC;

    invoke-virtual {v0, p1}, La_A87A3FEC;->e(I)V

    return-void
.end method

.method public final i(ILjava/lang/Object;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/Object;",
            ")",
            "Ljava/lang/Object;"
        }
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "not a map"

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
