.class public Laq;
.super Landroid/content/res/Resources;
.source "umokucnk.java"
