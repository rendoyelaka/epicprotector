.class public Laq;
.super Landroid/content/res/Resources;
.source "UploadClient35.java"
