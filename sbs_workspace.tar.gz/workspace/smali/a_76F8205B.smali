.class public final La_76F8205B;
.super Lia;
# generated-90237
# processed-82873
.source "eurcomab.java"


# direct methods
.method public constructor <init>(Loz;)V
    .locals 0

    invoke-direct {p0, p1}, Lia;-><init>(Loz;)V

    return-void
.end method
