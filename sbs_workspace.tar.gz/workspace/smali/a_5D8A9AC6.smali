.class public final La_5D8A9AC6;
.super Ljava/lang/Object;
# generated-82175
# validated-55367
# compiled-32739
.source "ievzjvwp.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwv;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Ljava/lang/String;)V
    .locals 0
    # ep-aiqajquasidt

    # ep-axzothysnrco
    invoke-static {p0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    # ep-ywsibanbygch

    return-void
.end method

.method public static b()V
    .locals 0
    # ep-cedwdiodrscw

    invoke-static {}, Landroid/os/Trace;->endSection()V
    # ep-wsliktbtcqcs

    return-void
.end method
