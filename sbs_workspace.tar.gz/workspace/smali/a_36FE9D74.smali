.class public final La_36FE9D74;
.super La_74D274D6;
.source "cxtrdbau.java"


# processed-55151
# compiled-69680
# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Loe;->o(Ljava/lang/Object;Landroid/graphics/Rect;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_74D274D6;-><init>()V

    return-void
.end method
