.class public final La_92531CE3;
.super Ljava/lang/Object;
# ep-ytoepxriicvx
# generated-39532
# verified-20236
.source "vagpehqk.java"

# interfaces
.implements La_AD3DE74A;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_50334AF1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Landroid/view/ContentInfo$Builder;


# direct methods
.method public constructor <init>(Landroid/content/ClipData;I)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Landroid/view/ContentInfo$Builder;

    .line 6
    invoke-direct {v0, p1, p2}, Landroid/view/ContentInfo$Builder;-><init>(Landroid/content/ClipData;I)V

    .line 9
    iput-object v0, p0, La_92531CE3;->a:Landroid/view/ContentInfo$Builder;

    .line 11
    return-void
.end method


# virtual methods
.method public final a(Landroid/net/Uri;)V
    .locals 1

    iget-object v0, p0, La_92531CE3;->a:Landroid/view/ContentInfo$Builder;

    invoke-static {v0, p1}, La_F80A868D;->k(Landroid/view/ContentInfo$Builder;Landroid/net/Uri;)V

    return-void
.end method

.method public final b(I)V
    .locals 1

    iget-object v0, p0, La_92531CE3;->a:Landroid/view/ContentInfo$Builder;

    invoke-static {v0, p1}, La_F80A868D;->j(Landroid/view/ContentInfo$Builder;I)V

    return-void
.end method

.method public final m_ee043eee()La_50334AF1;
    .locals 3

    new-instance v0, La_50334AF1;

    new-instance v1, La_90068634;

    iget-object v2, p0, La_92531CE3;->a:Landroid/view/ContentInfo$Builder;

    invoke-static {v2}, La_F80A868D;->f(Landroid/view/ContentInfo$Builder;)Landroid/view/ContentInfo;

    move-result-object v2

    invoke-direct {v1, v2}, La_90068634;-><init>(Landroid/view/ContentInfo;)V

    invoke-direct {v0, v1}, La_50334AF1;-><init>(La_F3196EE8;)V

    return-object v0
.end method

.method public final m_7cc735ee(Landroid/os/Bundle;)V
    .locals 1

    iget-object v0, p0, La_92531CE3;->a:Landroid/view/ContentInfo$Builder;

    invoke-static {v0, p1}, La_F80A868D;->l(Landroid/view/ContentInfo$Builder;Landroid/os/Bundle;)V

    return-void
.end method
