.class public final La_0E5F6FEF;
.super Landroid/animation/AnimatorListenerAdapter;
.source "rilsodpn.java"

# optimised-28364
# verified-31636
# generated-38197

# instance fields
.field public final synthetic a:La_904C1018;


# direct methods
.method public constructor <init>(La_904C1018;)V
    .locals 0

    iput-object p1, p0, La_0E5F6FEF;->a:La_904C1018;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    # ep-wrqgykftbakf
    .locals 0
    # ep-pqvyrvlwbmjr

    iget-object p1, p0, La_0E5F6FEF;->a:La_904C1018;

    # ep-nnebciayxupv
    invoke-interface {p1}, La_904C1018;->a()V

    return-void
.end method

.method public final onAnimationStart(Landroid/animation/Animator;)V
    .locals 0

    iget-object p1, p0, La_0E5F6FEF;->a:La_904C1018;
    # ep-lybzkqswgjoj

    invoke-interface {p1}, La_904C1018;->b()V

    # ep-hxgdeurxpnby
    return-void
.end method
