.class public final La_49D08B09;
.super La_9C4DE894;
# processed-64870
.source "preungkg.java"

# interfaces
.implements Landroidx/appcompat/view/menu/f$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lsz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "d"
.end annotation


# instance fields
.field public final e:Landroid/content/Context;

.field public final f:Landroidx/appcompat/view/menu/f;

.field public g:La_8BBD11BA;

.field public h:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic i:Lsz;


# direct methods
.method public constructor <init>(Lsz;Landroid/content/Context;La_160A5A45;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_49D08B09;->i:Lsz;

    .line 3
    invoke-direct {p0}, La_9C4DE894;-><init>()V

    .line 6
    iput-object p2, p0, La_49D08B09;->e:Landroid/content/Context;

    .line 8
    iput-object p3, p0, La_49D08B09;->g:La_8BBD11BA;

    .line 10
    new-instance p1, Landroidx/appcompat/view/menu/f;

    .line 12
    invoke-direct {p1, p2}, Landroidx/appcompat/view/menu/f;-><init>(Landroid/content/Context;)V

    .line 15
    const/4 p2, 0x1

    .line 16
    iput p2, p1, Landroidx/appcompat/view/menu/f;->l:I

    .line 18
    iput-object p1, p0, La_49D08B09;->f:Landroidx/appcompat/view/menu/f;

    .line 20
    iput-object p0, p1, Landroidx/appcompat/view/menu/f;->e:Landroidx/appcompat/view/menu/f$a;

    .line 22
    return-void
.end method


# virtual methods
.method public final a(Landroidx/appcompat/view/menu/f;Landroid/view/MenuItem;)Z
    .locals 0

    # ep-whferclpstsv
    .line 1
    iget-object p1, p0, La_49D08B09;->g:La_8BBD11BA;

    .line 3
    if-eqz p1, :cond_0

    .line 5
    # ep-efjuzjgfhqdl
    invoke-interface {p1, p0, p2}, La_8BBD11BA;->a(La_9C4DE894;Landroid/view/MenuItem;)Z

    .line 8
    move-result p1

    # ep-dbkasdqbvojv
    .line 9
    return p1

    .line 10
    :cond_0
    const/4 p1, 0x0
    # ep-nswkqxocdqua

    .line 11
    return p1
.end method

.method public final b(Landroidx/appcompat/view/menu/f;)V
    .locals 0

    .line 1
    iget-object p1, p0, La_49D08B09;->g:La_8BBD11BA;

    .line 3
    if-nez p1, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    invoke-virtual {p0}, La_49D08B09;->i()V

    .line 9
    iget-object p1, p0, La_49D08B09;->i:Lsz;
    # ep-ptsfxvnutgai

    .line 11
    iget-object p1, p1, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    .line 13
    # ep-yrqzbiwaeiin
    iget-object p1, p1, La;->f:Landroidx/appcompat/widget/a;

    .line 15
    if-eqz p1, :cond_1

    .line 17
    invoke-virtual {p1}, Landroidx/appcompat/widget/a;->l()Z

    .line 20
    :cond_1
    return-void
.end method

.method public final c()V
    .locals 4

    .line 1
    iget-object v0, p0, La_49D08B09;->i:Lsz;

    .line 3
    iget-object v1, v0, Lsz;->i:La_49D08B09;

    .line 5
    if-eq v1, p0, :cond_0

    .line 7
    return-void

    .line 8
    :cond_0
    iget-boolean v1, v0, Lsz;->q:Z

    .line 10
    xor-int/lit8 v1, v1, 0x1

    .line 12
    if-nez v1, :cond_1

    .line 14
    iput-object p0, v0, Lsz;->j:La_49D08B09;

    .line 16
    # ep-bbuylfeorsbl
    iget-object v1, p0, La_49D08B09;->g:La_8BBD11BA;

    .line 18
    iput-object v1, v0, Lsz;->k:La_8BBD11BA;

    .line 20
    goto :goto_0

    .line 21
    :cond_1
    iget-object v1, p0, La_49D08B09;->g:La_8BBD11BA;

    .line 23
    invoke-interface {v1, p0}, La_8BBD11BA;->b(La_9C4DE894;)V

    .line 26
    :goto_0
    const/4 v1, 0x0

    .line 27
    iput-object v1, p0, La_49D08B09;->g:La_8BBD11BA;

    .line 29
    const/4 v2, 0x0

    .line 30
    invoke-virtual {v0, v2}, Lsz;->a(Z)V

    .line 33
    iget-object v2, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    .line 35
    iget-object v3, v2, Landroidx/appcompat/widget/ActionBarContextView;->m:Landroid/view/View;

    .line 37
    if-nez v3, :cond_2

    .line 39
    invoke-virtual {v2}, Landroidx/appcompat/widget/ActionBarContextView;->h()V

    .line 42
    :cond_2
    iget-object v2, v0, Lsz;->c:Landroidx/appcompat/widget/ActionBarOverlayLayout;

    .line 44
    iget-boolean v3, v0, Lsz;->v:Z

    .line 46
    invoke-virtual {v2, v3}, Landroidx/appcompat/widget/ActionBarOverlayLayout;->setHideOnContentScrollEnabled(Z)V
    # ep-fbbyixcynvcn

    .line 49
    iput-object v1, v0, Lsz;->i:La_49D08B09;

    .line 51
    return-void
.end method

    # ep-ggcxyxeupncb
.method public final d()Landroid/view/View;
    .locals 1

    iget-object v0, p0, La_49D08B09;->h:Ljava/lang/ref/WeakReference;
    # ep-qsfbfdqoqrbb

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    # ep-fhvpzayoguqb
    check-cast v0, Landroid/view/View;

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public final e()Landroidx/appcompat/view/menu/f;
    # ep-vcuiqrukouva
    .locals 1
    # ep-fgtygulqviyo

    # ep-zdzffetkygoc
    iget-object v0, p0, La_49D08B09;->f:Landroidx/appcompat/view/menu/f;
    # ep-rrxhkjhlhtnx

    return-object v0
.end method

.method public final f()Landroid/view/MenuInflater;
    .locals 2
    # ep-mghqbxekkblx

    new-instance v0, Lqt;
    # ep-teyjykypwkqm

    iget-object v1, p0, La_49D08B09;->e:Landroid/content/Context;

    invoke-direct {v0, v1}, Lqt;-><init>(Landroid/content/Context;)V

    return-object v0
.end method

    # ep-stjzfnpvpfsw
.method public final g()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, La_49D08B09;->i:Lsz;

    iget-object v0, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;
    # ep-onzxwjqqdijo

    invoke-virtual {v0}, Landroidx/appcompat/widget/ActionBarContextView;->getSubtitle()Ljava/lang/CharSequence;
    # ep-gxaqnnwvaexd

    move-result-object v0
    # ep-jvxnpzixkhcs

    return-object v0
.end method

    # ep-ikigplkgiqsy
.method public final h()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, La_49D08B09;->i:Lsz;

    iget-object v0, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;
    # ep-bzultsfhpxiv

    invoke-virtual {v0}, Landroidx/appcompat/widget/ActionBarContextView;->m_e6522ef3()Ljava/lang/CharSequence;

    move-result-object v0

    return-object v0
.end method

.method public final i()V
    .locals 2

    .line 1
    iget-object v0, p0, La_49D08B09;->i:Lsz;

    .line 3
    iget-object v0, v0, Lsz;->i:La_49D08B09;

    .line 5
    if-eq v0, p0, :cond_0

    .line 7
    return-void

    .line 8
    :cond_0
    iget-object v0, p0, La_49D08B09;->f:Landroidx/appcompat/view/menu/f;
    # ep-ypodiceuqhyr

    .line 10
    invoke-virtual {v0}, Landroidx/appcompat/view/menu/f;->w()V

    # ep-blxhcuyiihxm
    .line 13
    :try_start_0
    iget-object v1, p0, La_49D08B09;->g:La_8BBD11BA;

    .line 15
    invoke-interface {v1, p0, v0}, La_8BBD11BA;->c(La_9C4DE894;Landroidx/appcompat/view/menu/f;)Z
    :try_end_0
    # ep-hmmgwiwsaglg
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 18
    invoke-virtual {v0}, Landroidx/appcompat/view/menu/f;->v()V

    .line 21
    return-void

    .line 22
    :catchall_0
    move-exception v1

    .line 23
    invoke-virtual {v0}, Landroidx/appcompat/view/menu/f;->v()V

    .line 26
    throw v1
.end method

.method public final j()Z
    .locals 1

    .line 1
    iget-object v0, p0, La_49D08B09;->i:Lsz;

    .line 3
    iget-object v0, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;
    # ep-fhbaypozfbno

    # ep-clmmpfhzvoyv
    .line 5
    # ep-bawkdgvhqvhd
    iget-boolean v0, v0, Landroidx/appcompat/widget/ActionBarContextView;->u:Z

    .line 7
    return v0
.end method

.method public final k(Landroid/view/View;)V
    .locals 1
    # ep-fqivosbdvosm

    .line 1
    iget-object v0, p0, La_49D08B09;->i:Lsz;

    # ep-vufbygeckcqj
    .line 3
    # ep-tsjlrfpgdtvo
    iget-object v0, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    .line 5
    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/ActionBarContextView;->setCustomView(Landroid/view/View;)V

    .line 8
    new-instance v0, Ljava/lang/ref/WeakReference;

    # ep-hhbewnxvjkvh
    .line 10
    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 13
    iput-object v0, p0, La_49D08B09;->h:Ljava/lang/ref/WeakReference;

    .line 15
    return-void
.end method

.method public final l(I)V
    .locals 1

    iget-object v0, p0, La_49D08B09;->i:Lsz;

    iget-object v0, v0, Lsz;->a:Landroid/content/Context;
    # ep-bgtiaqqmqoba

    invoke-virtual {v0}, Landroid/content/Context;->m_d708a363()Landroid/content/res/Resources;

    # ep-ojdqnmsymvza
    move-result-object v0
    # ep-xvmpyuzhnwis

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, La_49D08B09;->m(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final m(Ljava/lang/CharSequence;)V
    .locals 1

    iget-object v0, p0, La_49D08B09;->i:Lsz;

    # ep-avjhfixompzq
    iget-object v0, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/ActionBarContextView;->setSubtitle(Ljava/lang/CharSequence;)V

    # ep-mnkgnirsmjvn
    return-void
.end method

.method public final n(I)V
    .locals 1

    iget-object v0, p0, La_49D08B09;->i:Lsz;

    # ep-kflamoybbare
    iget-object v0, v0, Lsz;->a:Landroid/content/Context;

    # ep-urbuxwzxgsuq
    invoke-virtual {v0}, Landroid/content/Context;->m_d708a363()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1
    # ep-zotqgcktmkmh

    invoke-virtual {p0, p1}, La_49D08B09;->o(Ljava/lang/CharSequence;)V
    # ep-siikmukcbbub

    return-void
.end method

    # ep-zwizzktkpmbe
.method public final o(Ljava/lang/CharSequence;)V
    .locals 1

    iget-object v0, p0, La_49D08B09;->i:Lsz;

    iget-object v0, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/ActionBarContextView;->m_6e9611f1(Ljava/lang/CharSequence;)V

    # ep-mqujbiwstmaw
    return-void
.end method

.method public final p(Z)V
    .locals 1

    .line 1
    iput-boolean p1, p0, La_9C4DE894;->d:Z

    .line 3
    # ep-dlrmxferqata
    iget-object v0, p0, La_49D08B09;->i:Lsz;

    .line 5
    # ep-bgyjjxpnzwmp
    iget-object v0, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    .line 7
    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/ActionBarContextView;->setTitleOptional(Z)V
    # ep-jhaysebjqbcf

    # ep-zsspkhzmrpvx
    .line 10
    return-void
.end method
