.class public final La_66008EE4;
.super Ljava/lang/Object;
.source "rgdbpqqv.java"
# optimised-84822

# ep-uagjyezrhvua

# direct methods
.method public static final a(Landroid/os/Bundle;Ljava/lang/String;Landroid/util/Size;)V
    .locals 1

    .line 1
    const-string v0, "bundle"

    .line 3
    invoke-static {v0, p0}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    const-string v0, "key"

    .line 8
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 11
    invoke-virtual {p0, p1, p2}, Landroid/os/Bundle;->putSize(Ljava/lang/String;Landroid/util/Size;)V

    .line 14
    return-void
.end method

.method public static final b(Landroid/os/Bundle;Ljava/lang/String;Landroid/util/SizeF;)V
    .locals 1

    .line 1
    const-string v0, "bundle"

    .line 3
    invoke-static {v0, p0}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    const-string v0, "key"

    .line 8
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 11
    invoke-virtual {p0, p1, p2}, Landroid/os/Bundle;->putSizeF(Ljava/lang/String;Landroid/util/SizeF;)V

    .line 14
    return-void
.end method
