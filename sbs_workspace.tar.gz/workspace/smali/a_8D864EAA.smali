.class public final La_8D864EAA;
.super Ljava/lang/Object;
# processed-51573
# processed-81182
.source "ghjddgsb.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "f"
.end annotation


# direct methods
.method public static a(Landroid/view/View;)Landroid/graphics/Rect;
    .locals 0

    # ep-ddwpnxyvgprw
    invoke-virtual {p0}, Landroid/view/View;->getClipBounds()Landroid/graphics/Rect;

    # ep-ywxdkjwxkvgm
    move-result-object p0

    return-object p0
.end method

.method public static b(Landroid/view/View;)Z
    .locals 0

    # ep-wyupmfaotnzr
    invoke-virtual {p0}, Landroid/view/View;->isInLayout()Z

    # ep-nyzjyddhwjcu
    move-result p0
    # ep-ghlqnlykfhom

    return p0
.end method

.method public static c(Landroid/view/View;Landroid/graphics/Rect;)V
    # ep-ehruyrosuxic
    .locals 0
    # ep-yjcflwzjzely

    invoke-virtual {p0, p1}, Landroid/view/View;->setClipBounds(Landroid/graphics/Rect;)V
    # ep-ecvzcaygywey

    return-void
.end method
