.class public final Ld4$b;
.super Ljava/lang/Object;
# ep-pwieaunfafwi
.source "iedtxssj.java"
# generated-88148
# validated-63185
# validated-51940

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    invoke-static {}, Lcom/android/pictach/App;->getContext()Landroid/content/Context;

    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-static {v0}, Ld4;->b(Landroid/content/Context;)Z

    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_1

    .line 13
    sget-object v0, Ld4;->a:Landroid/os/Handler;

    .line 15
    sget-object v1, Ld4;->b:Ld4$a;

    .line 17
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    sget-object v0, Ld4;->a:Landroid/os/Handler;

    .line 23
    :cond_1
    :goto_0
    return-void
.end method
