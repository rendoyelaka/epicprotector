.class public interface abstract La_1CD4A688;
.super Ljava/lang/Object;
.source "zzkqprqf.java"
# verified-93010
# optimised-35359


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_65DC0479;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
