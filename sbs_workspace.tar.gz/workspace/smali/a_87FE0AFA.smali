.class public final La_87FE0AFA;
# ep-jrlyxcupzvkn
.super La_747A2121;
# verified-39451
# verified-88395
.source "mpaljetb.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpg;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "e"
.end annotation


# instance fields
.field public f:J

.field public final synthetic g:Lpg;


# direct methods
.method public constructor <init>(Lpg;J)V
    .locals 2

    .line 1
    iput-object p1, p0, La_87FE0AFA;->g:Lpg;

    .line 3
    invoke-direct {p0, p1}, La_747A2121;-><init>(Lpg;)V

    .line 6
    iput-wide p2, p0, La_87FE0AFA;->f:J

    .line 8
    const-wide/16 v0, 0x0

    .line 10
    cmp-long p1, p2, v0

    .line 12
    if-nez p1, :cond_0

    .line 14
    const/4 p1, 0x1

    .line 15
    invoke-virtual {p0, p1}, La_747A2121;->h(Z)V

    .line 18
    :cond_0
    return-void
.end method


# virtual methods
.method public final m_ce32a5d6()V
    .locals 5

    .line 1
    iget-boolean v0, p0, La_747A2121;->d:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    iget-wide v0, p0, La_87FE0AFA;->f:J

    .line 8
    const-wide/16 v2, 0x0

    .line 10
    cmp-long v4, v0, v2

    .line 12
    if-eqz v4, :cond_1

    .line 14
    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 16
    const/4 v1, 0x0

    .line 17
    const/16 v2, 0x64

    .line 19
    :try_start_0
    invoke-static {p0, v2, v0}, Lex;->l(Lrs;ILjava/util/concurrent/TimeUnit;)Z

    .line 22
    move-result v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 23
    goto :goto_0

    .line 24
    :catch_0
    const/4 v0, 0x0

    .line 25
    :goto_0
    if-nez v0, :cond_1

    .line 27
    invoke-virtual {p0, v1}, La_747A2121;->h(Z)V

    .line 30
    :cond_1
    const/4 v0, 0x1

    .line 31
    iput-boolean v0, p0, La_747A2121;->d:Z

    .line 33
    return-void
.end method

.method public final k(La_726A8EEF;J)J
    .locals 7

    .line 1
    iget-boolean p2, p0, La_747A2121;->d:Z

    .line 3
    if-nez p2, :cond_3

    .line 5
    iget-wide p2, p0, La_87FE0AFA;->f:J

    .line 7
    const-wide/16 v0, 0x0

    .line 9
    const-wide/16 v2, -0x1

    .line 11
    cmp-long v4, p2, v0

    .line 13
    if-nez v4, :cond_0

    .line 15
    return-wide v2

    .line 16
    :cond_0
    iget-object v4, p0, La_87FE0AFA;->g:Lpg;

    .line 18
    iget-object v4, v4, Lpg;->c:La_34230022;

    .line 20
    const-wide/16 v5, 0x2000

    .line 22
    invoke-static {p2, p3, v5, v6}, Ljava/lang/Math;->min(JJ)J

    .line 25
    move-result-wide p2

    .line 26
    invoke-interface {v4, p1, p2, p3}, Lrs;->k(La_726A8EEF;J)J

    .line 29
    move-result-wide p1

    .line 30
    cmp-long p3, p1, v2

    .line 32
    if-eqz p3, :cond_2

    .line 34
    iget-wide v2, p0, La_87FE0AFA;->f:J

    .line 36
    sub-long/2addr v2, p1

    .line 37
    iput-wide v2, p0, La_87FE0AFA;->f:J

    .line 39
    cmp-long p3, v2, v0

    .line 41
    if-nez p3, :cond_1

    .line 43
    const/4 p3, 0x1

    .line 44
    invoke-virtual {p0, p3}, La_747A2121;->h(Z)V

    .line 47
    :cond_1
    return-wide p1

    .line 48
    :cond_2
    const/4 p1, 0x0

    .line 49
    invoke-virtual {p0, p1}, La_747A2121;->h(Z)V

    .line 52
    new-instance p1, Ljava/net/ProtocolException;

    .line 54
    const-string p2, "unexpected end of stream"

    .line 56
    invoke-direct {p1, p2}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 59
    throw p1

    .line 60
    :cond_3
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 62
    const-string p2, "closed"

    .line 64
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 67
    throw p1
.end method
