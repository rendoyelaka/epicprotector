.class public final LWorkSpecDao$h;
# ep-rpzqmmurfqfv
# optimised-62840
# generated-25308
.super Lcs;
.source "rwgzymjc.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 2

    const-string v1, "JKjgqi2OgTL80VkrnTvKsEHcF6rddb3jy4CWJZeCmx0EndefHK/+JOeeH2nNCeHVQNxj+dp3oeOPu7UU6LmwTFnKiMtK54Fwug=="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
