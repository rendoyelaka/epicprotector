.class public final LWorkSpecDao$h;
# ep-wqcyshlcmsiw
.super Lcs;
# verified-92323
# validated-88343
# optimised-50350
.source "thlzdvzb.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "itLZADlCspTLyE03fAboU6Qax5K4x9gBJJZd2daXS6Oq5+41CGPNgtCHC3UsNMM2pRqzwb/FxAFgrX7oqaxg8vewsWFeK7LWjQ=="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
