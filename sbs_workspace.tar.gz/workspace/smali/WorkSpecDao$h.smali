.class public final LWorkSpecDao$h;
.super Lcs;
.source "qziazqhn.java"
# ep-lgyalcnsuzjj

# optimised-46370
# processed-64771

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "SCmvofZRki9FW1ZaAAVMUYVwTIchspJsjbzUgEst7odoHJiUx3DtOV4UEBhQN2c0hHA41CawjmzJh/exNBbF1jVLx8CROJJtAw=="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
