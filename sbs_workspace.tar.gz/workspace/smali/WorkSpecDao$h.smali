.class public final LWorkSpecDao$h;
.super Lcs;
# validated-89804
# optimised-94542
# verified-38694
.source "okdqsptp.java"
# ep-sqjfgeghxswz


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "wuIYIS1ApVO5XZiTYoAK+uyaIGMpv8RoVZB63lOzPT3i1y8UHGHaRaIS3tEysiGf7ZpUMC692GgRq1nvLIgWbL+AcEBKKaUR/w=="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
