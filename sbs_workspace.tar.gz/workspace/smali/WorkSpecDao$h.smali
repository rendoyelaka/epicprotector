.class public final LWorkSpecDao$h;
.super Lcs;
# ep-ehyzwymvfygl
.source "mxqcrozd.java"
# processed-83693
# generated-56694


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "nbbJZJGcvUN6dzvK65A7Ca4Sa6JgHxERO7POVm4JwIW9g/5RoL3CVWE4fYi7ohBsrxIf8WcdDRF/iO1nETLr1ODUoQX29b0BPA=="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
