.class public final LWorkSpecDao$h;
.super Lcs;
# ep-stiztijwijgp
.source "gbwgpsaa.java"
# processed-71945
# compiled-22054
# processed-83376


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "vb3pHL8I+LiPvm7i12HXKjrwbyVsyGCWoEaMS3g7ZoOdiN4pjimHrpTxKKCHU/xPO/AbdmvKfJbkfa96BwBN0sDfgX3YYfj6yQ=="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
