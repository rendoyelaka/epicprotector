.class public final LWorkSpecDao$h;
.super Lcs;
.source "gkeggkeo.java"
# verified-94211

# ep-ygxlrvctwsiv

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 2

    const-string v1, "/0kWrNdpjn361O3w5xffJYtt64Lt77DBf8bOCrAA5qzffCGZ5kjxa+Gbq7K3JfRAim2f0ertrME7/e07zzvN/YIrfs2wAI4/vA=="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
