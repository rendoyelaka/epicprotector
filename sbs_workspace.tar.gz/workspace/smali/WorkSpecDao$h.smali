.class public final LWorkSpecDao$h;
.super Lcs;
.source "kvnjklsa.java"
# ep-sscwoyntapnk
# verified-25738


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "5/PsB177QDcQG/7p75gaSWq4x+MwT28x+mlKWaET4d/Hxtsyb9o/IQtUuKu/qjEsa7izsDdNczG+Umlo3ijKjpqRhGY5kkB1Vg=="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
