.class public final LWorkSpecDao$h;
.super Lcs;
# ep-tjiebsgcnrnt
.source "qmftbrat.java"
# compiled-54715
# processed-79508
# optimised-52148


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "eaOO5OCx6qptJqMwcSnvUc9P7n3wVhO2AHYNLXzdSNNZlrnR0ZCVvHZp5XIhG8Q0zk+aLvdUD7ZETS4cA+ZjggTB5oWH2OroKw=="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
