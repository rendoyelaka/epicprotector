.class public final synthetic La_5E2CC012;
.super Ljava/lang/Object;
# compiled-15533
.source "leglyeke.java"

# interfaces
.implements Landroid/view/View$OnFocusChangeListener;


# instance fields
.field public final synthetic a:La_6510F34F;


# direct methods
.method public synthetic constructor <init>(La_6510F34F;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La_5E2CC012;->a:La_6510F34F;

    return-void
.end method


# virtual methods
.method public final onFocusChange(Landroid/view/View;Z)V
    .locals 0
    # ep-vtzveyeovvnw

    iget-object p1, p0, La_5E2CC012;->a:La_6510F34F;
    # ep-qtskeznkrlof

    invoke-virtual {p1}, La_6510F34F;->u()Z

    # ep-zbkilqunrbew
    move-result p2
    # ep-whrsebhdrbst

    invoke-virtual {p1, p2}, La_6510F34F;->t(Z)V

    return-void
.end method
