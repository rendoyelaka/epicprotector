.class public interface abstract La_8BF1009F;
.super Ljava/lang/Object;
.source "qywletdf.java"
# verified-31168
# compiled-68630
# compiled-74363
# ep-nyljbhsgvsfj

# interfaces
.implements La_0ED6D319;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_C754A081;
    }
.end annotation


# static fields
.field public static final synthetic b:I
