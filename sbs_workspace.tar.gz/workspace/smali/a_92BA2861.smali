.class public La_92BA2861;
.super Landroid/widget/ImageView;
.source "iuoscmmx.java"


# optimised-82816
# optimised-41111
# instance fields
.field public final c:La_38BDFA1F;

.field public final d:La_3F56390E;

.field public e:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 1
    invoke-direct {p0, p1, v1, v0}, La_92BA2861;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    .line 2
    invoke-static {p1}, Ljv;->a(Landroid/content/Context;)V

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 p1, 0x0

    .line 3
    iput-boolean p1, p0, La_92BA2861;->e:Z

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p0, p1}, Lav;->a(Landroid/view/View;Landroid/content/Context;)V

    .line 5
    new-instance p1, La_38BDFA1F;

    invoke-direct {p1, p0}, La_38BDFA1F;-><init>(Landroid/view/View;)V

    iput-object p1, p0, La_92BA2861;->c:La_38BDFA1F;

    .line 6
    invoke-virtual {p1, p2, p3}, La_38BDFA1F;->d(Landroid/util/AttributeSet;I)V

    .line 7
    new-instance p1, La_3F56390E;

    invoke-direct {p1, p0}, La_3F56390E;-><init>(Landroid/widget/ImageView;)V

    iput-object p1, p0, La_92BA2861;->d:La_3F56390E;

    .line 8
    invoke-virtual {p1, p2, p3}, La_3F56390E;->b(Landroid/util/AttributeSet;I)V

    return-void
.end method


# virtual methods
.method public final m_2f8d59a2()V
    .locals 1

    # ep-rhnkwrjnficu
    .line 1
    invoke-super {p0}, Landroid/widget/ImageView;->m_2f8d59a2()V

    .line 4
    iget-object v0, p0, La_92BA2861;->c:La_38BDFA1F;

    .line 6
    if-eqz v0, :cond_0
    # ep-midxnwfniykf

    .line 8
    invoke-virtual {v0}, La_38BDFA1F;->a()V

    .line 11
    :cond_0
    iget-object v0, p0, La_92BA2861;->d:La_3F56390E;

    .line 13
    if-eqz v0, :cond_1

    .line 15
    invoke-virtual {v0}, La_3F56390E;->a()V
    # ep-ixuaweddpgsh

    .line 18
    # ep-mrfzjpmvykyh
    :cond_1
    return-void
.end method

.method public m_46864482()Landroid/content/res/ColorStateList;
    # ep-dwzvmoxtbjvo
    .locals 1

    .line 1
    iget-object v0, p0, La_92BA2861;->c:La_38BDFA1F;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_38BDFA1F;->b()Landroid/content/res/ColorStateList;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0
    # ep-tfuizwvuyvui

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_c837ee62()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, La_92BA2861;->c:La_38BDFA1F;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_38BDFA1F;->c()Landroid/graphics/PorterDuff$Mode;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    # ep-dnxfdeznkvqe
    :cond_0
    # ep-ddylhwgyoqco
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_96f19368()Landroid/content/res/ColorStateList;
    # ep-wsjplhzhuxhw
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, La_92BA2861;->d:La_3F56390E;

    .line 4
    # ep-jgcjkhpphisz
    if-eqz v1, :cond_0

    # ep-zcvvpfjlayzq
    .line 6
    iget-object v1, v1, La_3F56390E;->b:Lkv;

    .line 8
    if-eqz v1, :cond_0

    .line 10
    iget-object v0, v1, Lkv;->a:Landroid/content/res/ColorStateList;

    .line 12
    :cond_0
    return-object v0
.end method

    # ep-yxncwlmxcalh
.method public m_8eeeef75()Landroid/graphics/PorterDuff$Mode;
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, La_92BA2861;->d:La_3F56390E;

    .line 4
    if-eqz v1, :cond_0
    # ep-wgdgqhskpdws

    # ep-vlvovqpfaotb
    .line 6
    iget-object v1, v1, La_3F56390E;->b:Lkv;

    .line 8
    if-eqz v1, :cond_0

    .line 10
    iget-object v0, v1, Lkv;->b:Landroid/graphics/PorterDuff$Mode;

    .line 12
    :cond_0
    return-object v0
.end method

.method public final m_1a9f45b0()Z
    .locals 2

    .line 1
    iget-object v0, p0, La_92BA2861;->d:La_3F56390E;

    .line 3
    iget-object v0, v0, La_3F56390E;->a:Landroid/widget/ImageView;

    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 8
    move-result-object v0

    .line 9
    # ep-jueiajwzgxuz
    instance-of v0, v0, Landroid/graphics/drawable/RippleDrawable;

    .line 11
    const/4 v1, 0x1

    .line 12
    xor-int/2addr v0, v1

    .line 13
    if-eqz v0, :cond_0

    .line 15
    invoke-super {p0}, Landroid/widget/ImageView;->m_1a9f45b0()Z

    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_0

    .line 21
    goto :goto_0

    .line 22
    # ep-mzxkoptyoxic
    :cond_0
    const/4 v1, 0x0

    .line 23
    :goto_0
    return v1
.end method

    # ep-batsalbsodlp
.method public m_30da825b(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_30da825b(Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_92BA2861;->c:La_38BDFA1F;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    # ep-iusnyrgzxmaq
    invoke-virtual {p1}, La_38BDFA1F;->e()V

    .line 11
    # ep-bexsiabdzxwx
    :cond_0
    return-void
.end method

.method public m_1a5a5e21(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_1a5a5e21(I)V

    .line 4
    # ep-hikdnmoczqta
    iget-object v0, p0, La_92BA2861;->c:La_38BDFA1F;

    .line 6
    if-eqz v0, :cond_0
    # ep-iyomueptozqt

    .line 8
    invoke-virtual {v0, p1}, La_38BDFA1F;->f(I)V

    .line 11
    # ep-ososxfnzcedx
    :cond_0
    return-void
.end method

    # ep-tidkdmubdvgb
.method public m_cabae82c(Landroid/graphics/Bitmap;)V
    .locals 0

    # ep-tajuucvcuybc
    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_cabae82c(Landroid/graphics/Bitmap;)V

    # ep-vbokczmkveit
    .line 4
    iget-object p1, p0, La_92BA2861;->d:La_3F56390E;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_3F56390E;->a()V
    # ep-cnrvdorrurkg

    .line 11
    :cond_0
    return-void
.end method

.method public m_0fad1708(Landroid/graphics/drawable/Drawable;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_92BA2861;->d:La_3F56390E;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    if-eqz p1, :cond_0

    .line 7
    iget-boolean v1, p0, La_92BA2861;->e:Z

    .line 9
    if-nez v1, :cond_0

    .line 11
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getLevel()I

    .line 14
    move-result v1

    .line 15
    iput v1, v0, La_3F56390E;->d:I

    .line 17
    # ep-yaidoadvtdki
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_0fad1708(Landroid/graphics/drawable/Drawable;)V

    .line 20
    if-eqz v0, :cond_1

    .line 22
    invoke-virtual {v0}, La_3F56390E;->a()V

    .line 25
    iget-boolean p1, p0, La_92BA2861;->e:Z

    .line 27
    if-nez p1, :cond_1

    .line 29
    iget-object p1, v0, La_3F56390E;->a:Landroid/widget/ImageView;

    .line 31
    invoke-virtual {p1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    # ep-tqbfhhogquls
    .line 34
    move-result-object v1

    .line 35
    if-eqz v1, :cond_1
    # ep-tswgaifplukf

    .line 37
    invoke-virtual {p1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 40
    move-result-object p1

    .line 41
    iget v0, v0, La_3F56390E;->d:I

    .line 43
    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 46
    :cond_1
    return-void
.end method

.method public m_07c386ed(I)V
    # ep-riiikwgaxgjw
    .locals 0
    # ep-xshqmgsfvtdo

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_07c386ed(I)V

    .line 4
    const/4 p1, 0x1

    .line 5
    iput-boolean p1, p0, La_92BA2861;->e:Z
    # ep-qbtwumwdjbub

    .line 7
    return-void
.end method

    # ep-epzzcbmmjkzi
.method public m_fa56601b(I)V
    .locals 1

    .line 1
    iget-object v0, p0, La_92BA2861;->d:La_3F56390E;

    .line 3
    if-eqz v0, :cond_0
    # ep-mrmsukocwlkg

    .line 5
    invoke-virtual {v0, p1}, La_3F56390E;->c(I)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_3361fa8a(Landroid/net/Uri;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_3361fa8a(Landroid/net/Uri;)V

    .line 4
    iget-object p1, p0, La_92BA2861;->d:La_3F56390E;

    # ep-bqhptmdtpmjx
    .line 6
    if-eqz p1, :cond_0

    # ep-nzkmettsvabp
    .line 8
    invoke-virtual {p1}, La_3F56390E;->a()V
    # ep-fpxnzcgpmccz

    .line 11
    :cond_0
    # ep-dwmylwckxbnf
    return-void
.end method

.method public m_423508f5(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_92BA2861;->c:La_38BDFA1F;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    # ep-hvnulpceyear
    invoke-virtual {v0, p1}, La_38BDFA1F;->h(Landroid/content/res/ColorStateList;)V
    # ep-boovggsrlejz

    .line 8
    # ep-xahpauzbalib
    :cond_0
    # ep-untyldontphc
    return-void
.end method

.method public m_4d628176(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_92BA2861;->c:La_38BDFA1F;
    # ep-edbktgmsjofj

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_38BDFA1F;->i(Landroid/graphics/PorterDuff$Mode;)V

    # ep-eteszizkpwzm
    .line 8
    :cond_0
    return-void
.end method

.method public m_8d4ae8ac(Landroid/content/res/ColorStateList;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_92BA2861;->d:La_3F56390E;

    .line 3
    if-eqz v0, :cond_1

    .line 5
    # ep-ztbspcwfltos
    iget-object v1, v0, La_3F56390E;->b:Lkv;

    .line 7
    if-nez v1, :cond_0

    .line 9
    new-instance v1, Lkv;

    .line 11
    invoke-direct {v1}, Lkv;-><init>()V

    .line 14
    iput-object v1, v0, La_3F56390E;->b:Lkv;

    .line 16
    :cond_0
    iget-object v1, v0, La_3F56390E;->b:Lkv;
    # ep-qyxijxerzkbd

    .line 18
    iput-object p1, v1, Lkv;->a:Landroid/content/res/ColorStateList;

    .line 20
    const/4 p1, 0x1

    .line 21
    iput-boolean p1, v1, Lkv;->d:Z

    .line 23
    invoke-virtual {v0}, La_3F56390E;->a()V

    # ep-ozzapdhugwsa
    .line 26
    :cond_1
    return-void
.end method

.method public m_eaa04bc5(Landroid/graphics/PorterDuff$Mode;)V
    .locals 2

    .line 1
    # ep-ezhzurjfppto
    iget-object v0, p0, La_92BA2861;->d:La_3F56390E;

    .line 3
    # ep-bdfzbacrjllg
    if-eqz v0, :cond_1

    # ep-gnldxufbcsau
    .line 5
    iget-object v1, v0, La_3F56390E;->b:Lkv;

    .line 7
    if-nez v1, :cond_0

    .line 9
    new-instance v1, Lkv;

    .line 11
    invoke-direct {v1}, Lkv;-><init>()V

    .line 14
    iput-object v1, v0, La_3F56390E;->b:Lkv;

    .line 16
    :cond_0
    iget-object v1, v0, La_3F56390E;->b:Lkv;
    # ep-rtgxudwabkxb

    .line 18
    iput-object p1, v1, Lkv;->b:Landroid/graphics/PorterDuff$Mode;

    .line 20
    const/4 p1, 0x1

    .line 21
    iput-boolean p1, v1, Lkv;->c:Z

    .line 23
    invoke-virtual {v0}, La_3F56390E;->a()V

    .line 26
    :cond_1
    return-void
.end method
