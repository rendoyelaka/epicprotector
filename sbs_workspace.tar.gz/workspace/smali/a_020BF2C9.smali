.class public interface abstract La_020BF2C9;
.super Ljava/lang/Object;
# generated-39617
# generated-67640
.source "obmgkatp.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Luk;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method
