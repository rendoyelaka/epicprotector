.class public La_922A9ECB;
.super Lhv;
.source "ygfnmhtx.java"
# ep-cdxnkttcsvun

# optimised-43874
# validated-68189
# generated-20992

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_CD84397D;
    }
.end annotation


# static fields
.field public static final h:J

.field public static final i:J

.field public static j:La_922A9ECB;


# instance fields
.field public e:Z

.field public f:La_922A9ECB;

.field public g:J


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 1
    sget-object v0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 3
    const-wide/16 v1, 0x3c

    .line 5
    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 8
    move-result-wide v0

    .line 9
    sput-wide v0, La_922A9ECB;->h:J

    .line 11
    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 13
    invoke-virtual {v2, v0, v1}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    .line 16
    move-result-wide v0

    .line 17
    sput-wide v0, La_922A9ECB;->i:J

    .line 19
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lhv;-><init>()V

    return-void
.end method

.method public static i()La_922A9ECB;
    .locals 9

    .line 1
    sget-object v0, La_922A9ECB;->j:La_922A9ECB;

    .line 3
    iget-object v0, v0, La_922A9ECB;->f:La_922A9ECB;

    .line 5
    const-class v1, La_922A9ECB;

    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v0, :cond_1

    .line 10
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 13
    move-result-wide v3

    .line 14
    sget-wide v5, La_922A9ECB;->h:J

    .line 16
    invoke-virtual {v1, v5, v6}, Ljava/lang/Object;->wait(J)V

    .line 19
    sget-object v0, La_922A9ECB;->j:La_922A9ECB;

    .line 21
    iget-object v0, v0, La_922A9ECB;->f:La_922A9ECB;

    .line 23
    if-nez v0, :cond_0

    .line 25
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 28
    move-result-wide v0

    .line 29
    sub-long/2addr v0, v3

    .line 30
    sget-wide v3, La_922A9ECB;->i:J

    .line 32
    cmp-long v5, v0, v3

    .line 34
    if-ltz v5, :cond_0

    .line 36
    sget-object v2, La_922A9ECB;->j:La_922A9ECB;

    .line 38
    :cond_0
    return-object v2

    .line 39
    :cond_1
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 42
    move-result-wide v3

    .line 43
    iget-wide v5, v0, La_922A9ECB;->g:J

    .line 45
    sub-long/2addr v5, v3

    .line 46
    const-wide/16 v3, 0x0

    .line 48
    cmp-long v7, v5, v3

    .line 50
    if-lez v7, :cond_2

    .line 52
    const-wide/32 v3, 0xf4240

    .line 55
    div-long v7, v5, v3

    .line 57
    mul-long v3, v3, v7

    .line 59
    sub-long/2addr v5, v3

    .line 60
    long-to-int v0, v5

    .line 61
    invoke-virtual {v1, v7, v8, v0}, Ljava/lang/Object;->wait(JI)V

    .line 64
    return-object v2

    .line 65
    :cond_2
    sget-object v1, La_922A9ECB;->j:La_922A9ECB;

    .line 67
    iget-object v3, v0, La_922A9ECB;->f:La_922A9ECB;

    .line 69
    iput-object v3, v1, La_922A9ECB;->f:La_922A9ECB;

    .line 71
    iput-object v2, v0, La_922A9ECB;->f:La_922A9ECB;

    .line 73
    return-object v0
.end method


# virtual methods
.method public final j()V
    .locals 10

    .line 1
    iget-boolean v0, p0, La_922A9ECB;->e:Z

    .line 3
    if-nez v0, :cond_8

    .line 5
    iget-wide v0, p0, Lhv;->c:J

    .line 7
    iget-boolean v2, p0, Lhv;->a:Z

    .line 9
    const-wide/16 v3, 0x0

    .line 11
    cmp-long v5, v0, v3

    .line 13
    if-nez v5, :cond_0

    .line 15
    if-nez v2, :cond_0

    .line 17
    return-void

    .line 18
    :cond_0
    const/4 v3, 0x1

    .line 19
    iput-boolean v3, p0, La_922A9ECB;->e:Z

    .line 21
    const-class v3, La_922A9ECB;

    .line 23
    monitor-enter v3

    .line 24
    :try_start_0
    sget-object v4, La_922A9ECB;->j:La_922A9ECB;

    .line 26
    if-nez v4, :cond_1

    .line 28
    new-instance v4, La_922A9ECB;

    .line 30
    invoke-direct {v4}, La_922A9ECB;-><init>()V

    .line 33
    sput-object v4, La_922A9ECB;->j:La_922A9ECB;

    .line 35
    new-instance v4, La_CD84397D;

    .line 37
    invoke-direct {v4}, La_CD84397D;-><init>()V

    .line 40
    invoke-virtual {v4}, Ljava/lang/Thread;->m_b629ea98()V

    .line 43
    :cond_1
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 46
    move-result-wide v6

    .line 47
    if-eqz v5, :cond_2

    .line 49
    if-eqz v2, :cond_2

    .line 51
    invoke-virtual {p0}, Lhv;->c()J

    .line 54
    move-result-wide v4

    .line 55
    sub-long/2addr v4, v6

    .line 56
    invoke-static {v0, v1, v4, v5}, Ljava/lang/Math;->min(JJ)J

    .line 59
    move-result-wide v0

    .line 60
    add-long/2addr v0, v6

    .line 61
    iput-wide v0, p0, La_922A9ECB;->g:J

    .line 63
    goto :goto_0

    .line 64
    :cond_2
    if-eqz v5, :cond_3

    .line 66
    add-long/2addr v0, v6

    .line 67
    iput-wide v0, p0, La_922A9ECB;->g:J

    .line 69
    goto :goto_0

    .line 70
    :cond_3
    if-eqz v2, :cond_7

    .line 72
    invoke-virtual {p0}, Lhv;->c()J

    .line 75
    move-result-wide v0

    .line 76
    iput-wide v0, p0, La_922A9ECB;->g:J

    .line 78
    :goto_0
    iget-wide v0, p0, La_922A9ECB;->g:J

    .line 80
    sub-long/2addr v0, v6

    .line 81
    sget-object v2, La_922A9ECB;->j:La_922A9ECB;

    .line 83
    :goto_1
    iget-object v4, v2, La_922A9ECB;->f:La_922A9ECB;

    .line 85
    if-eqz v4, :cond_5

    .line 87
    iget-wide v8, v4, La_922A9ECB;->g:J

    .line 89
    sub-long/2addr v8, v6

    .line 90
    cmp-long v5, v0, v8

    .line 92
    if-gez v5, :cond_4

    .line 94
    goto :goto_2

    .line 95
    :cond_4
    move-object v2, v4

    .line 96
    goto :goto_1

    .line 97
    :cond_5
    :goto_2
    iput-object v4, p0, La_922A9ECB;->f:La_922A9ECB;

    .line 99
    iput-object p0, v2, La_922A9ECB;->f:La_922A9ECB;

    .line 101
    sget-object v0, La_922A9ECB;->j:La_922A9ECB;

    .line 103
    if-ne v2, v0, :cond_6

    .line 105
    const-class v0, La_922A9ECB;

    .line 107
    invoke-virtual {v0}, Ljava/lang/Object;->notify()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 110
    :cond_6
    monitor-exit v3

    .line 111
    return-void

    .line 112
    :cond_7
    :try_start_1
    new-instance v0, Ljava/lang/AssertionError;

    .line 114
    invoke-direct {v0}, Ljava/lang/AssertionError;-><init>()V

    .line 117
    throw v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 118
    :catchall_0
    move-exception v0

    .line 119
    monitor-exit v3

    .line 120
    throw v0

    .line 121
    :cond_8
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 123
    const-string v1, "Unbalanced enter/exit"

    .line 125
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 128
    throw v0
.end method

.method public final k(Ljava/io/IOException;)Ljava/io/IOException;
    .locals 1

    .line 1
    invoke-virtual {p0}, La_922A9ECB;->m()Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_0

    .line 7
    return-object p1

    .line 8
    :cond_0
    invoke-virtual {p0, p1}, La_922A9ECB;->n(Ljava/io/IOException;)Ljava/io/IOException;

    .line 11
    move-result-object p1

    .line 12
    return-object p1
.end method

.method public final l(Z)V
    .locals 1

    .line 1
    invoke-virtual {p0}, La_922A9ECB;->m()Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_1

    .line 7
    if-nez p1, :cond_0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 p1, 0x0

    .line 11
    invoke-virtual {p0, p1}, La_922A9ECB;->n(Ljava/io/IOException;)Ljava/io/IOException;

    .line 14
    move-result-object p1

    .line 15
    throw p1

    .line 16
    :cond_1
    :goto_0
    return-void
.end method

.method public final m()Z
    .locals 4

    .line 1
    iget-boolean v0, p0, La_922A9ECB;->e:Z

    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 6
    return v1

    .line 7
    :cond_0
    iput-boolean v1, p0, La_922A9ECB;->e:Z

    .line 9
    const-class v0, La_922A9ECB;

    .line 11
    monitor-enter v0

    .line 12
    :try_start_0
    sget-object v2, La_922A9ECB;->j:La_922A9ECB;

    .line 14
    :goto_0
    if-eqz v2, :cond_2

    .line 16
    iget-object v3, v2, La_922A9ECB;->f:La_922A9ECB;

    .line 18
    if-ne v3, p0, :cond_1

    .line 20
    iget-object v3, p0, La_922A9ECB;->f:La_922A9ECB;

    .line 22
    iput-object v3, v2, La_922A9ECB;->f:La_922A9ECB;

    .line 24
    const/4 v2, 0x0

    .line 25
    iput-object v2, p0, La_922A9ECB;->f:La_922A9ECB;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 27
    monitor-exit v0

    .line 28
    goto :goto_1

    .line 29
    :cond_1
    move-object v2, v3

    .line 30
    goto :goto_0

    .line 31
    :cond_2
    monitor-exit v0

    .line 32
    const/4 v1, 0x1

    .line 33
    :goto_1
    return v1

    .line 34
    :catchall_0
    move-exception v1

    .line 35
    monitor-exit v0

    .line 36
    throw v1
.end method

.method public n(Ljava/io/IOException;)Ljava/io/IOException;
    .locals 2

    .line 1
    new-instance v0, Ljava/io/InterruptedIOException;

    .line 3
    const-string v1, "timeout"

    .line 5
    invoke-direct {v0, v1}, Ljava/io/InterruptedIOException;-><init>(Ljava/lang/String;)V

    .line 8
    if-eqz p1, :cond_0

    .line 10
    invoke-virtual {v0, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 13
    :cond_0
    return-object v0
.end method

.method public o()V
    .locals 0

    return-void
.end method
