.class public final La_3DC2D1E9;
# ep-eyhfgvkwdvfr
.super Ljava/lang/Object;
# validated-23890
.source "cicqyvor.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lhg;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field public final c:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

.field public final d:Landroid/view/View;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public final synthetic e:Lhg;


# direct methods
.method public constructor <init>(Lhg;Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;)V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, La_3DC2D1E9;->e:Lhg;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p2, p0, La_3DC2D1E9;->c:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    .line 8
    iput-object p3, p0, La_3DC2D1E9;->d:Landroid/view/View;

    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 1
    iget-object v0, p0, La_3DC2D1E9;->d:Landroid/view/View;

    .line 3
    if-eqz v0, :cond_1

    .line 5
    iget-object v1, p0, La_3DC2D1E9;->e:Lhg;

    .line 7
    iget-object v2, v1, Lhg;->d:Landroid/widget/OverScroller;

    .line 9
    if-eqz v2, :cond_1

    .line 11
    invoke-virtual {v2}, Landroid/widget/OverScroller;->computeScrollOffset()Z

    .line 14
    move-result v2

    .line 15
    iget-object v3, p0, La_3DC2D1E9;->c:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    .line 17
    if-eqz v2, :cond_0

    .line 19
    iget-object v2, v1, Lhg;->d:Landroid/widget/OverScroller;

    .line 21
    invoke-virtual {v2}, Landroid/widget/OverScroller;->getCurrY()I

    .line 24
    move-result v2

    .line 25
    invoke-virtual {v1, v3, v0, v2}, Lhg;->m_7bf4cde2(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)V

    .line 28
    sget-object v1, Lqx;->a:Ljava/util/WeakHashMap;

    .line 30
    invoke-static {v0, p0}, La_19221068;->m(Landroid/view/View;Ljava/lang/Runnable;)V

    .line 33
    goto :goto_0

    .line 34
    :cond_0
    invoke-virtual {v1, v0, v3}, Lhg;->y(Landroid/view/View;Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V

    .line 37
    :cond_1
    :goto_0
    return-void
.end method
