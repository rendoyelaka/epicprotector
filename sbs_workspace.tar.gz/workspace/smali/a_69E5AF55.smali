.class public interface abstract La_69E5AF55;
.super Ljava/lang/Object;
.source "xzxuqzzs.java"

# optimised-76090
# ep-rwohddzrvqtn

# virtual methods
.method public abstract a(Landroid/graphics/drawable/Drawable;)V
.end method

.method public abstract b()Landroid/graphics/drawable/Drawable;
.end method
