.class public final La_8147508F;
.super Ljava/lang/Object;
# ep-rizyfgcuhefs
.source "xwmxunqp.java"
# validated-34883


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_1AEDFBBB;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(La_1AEDFBBB;Landroid/content/res/Configuration;)Landroid/content/Context;
    .locals 0

    invoke-virtual {p0, p1}, Landroid/content/Context;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;

    move-result-object p0

    return-object p0
.end method
