.class public final La_74554B4D;
.super Ljava/lang/Object;
# compiled-82583
# processed-11170
# compiled-61649
.source "zfskqfds.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public static a(Landroid/view/View;)Z
    .locals 0
    # ep-kyaqihbthazd

    invoke-virtual {p0}, Landroid/view/View;->hasOnClickListeners()Z
    # ep-vjbebedhaqei

    # ep-dhlewehdveze
    move-result p0
    # ep-dverqawwaniq

    return p0
.end method
