.class public final synthetic La_13353AC7;
.super Ljava/lang/Object;
# verified-68384
# optimised-11947
.source "otdrluoo.java"

# interfaces
.implements La_F3AD7C94;


# instance fields
.field public final synthetic c:La2;


# direct methods
.method public synthetic constructor <init>(Landroidx/appcompat/app/b;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La_13353AC7;->c:La2;

    return-void
.end method


# virtual methods
.method public final d(Landroid/view/KeyEvent;)Z
    # ep-ymfltxfnqaoo
    .locals 1

    # ep-gavglkkunysc
    iget-object v0, p0, La_13353AC7;->c:La2;

    # ep-ilvnsmmqobtp
    invoke-virtual {v0, p1}, La2;->g(Landroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method
