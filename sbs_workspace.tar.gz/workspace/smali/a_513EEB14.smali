.class public final La_513EEB14;
.super Ljava/lang/Object;
# ep-xevdptptrilm
.source "thqqrhxb.java"

# verified-50885
# validated-90043

# static fields
.field public static final a:[Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 1
    const-string v0, "WrkDbPathHelper"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    const-string v0, "-shm"

    .line 8
    const-string v1, "-wal"

    .line 10
    const-string v2, "-journal"

    .line 12
    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    .line 15
    move-result-object v0

    .line 16
    sput-object v0, La_513EEB14;->a:[Ljava/lang/String;

    .line 18
    return-void
.end method

.method public static a(Landroid/content/Context;)V
    .locals 11

    .line 1
    const-string v0, "androidx.work.workdb"

    .line 3
    invoke-virtual {p0, v0}, Landroid/content/Context;->getDatabasePath(Ljava/lang/String;)Ljava/io/File;

    .line 6
    move-result-object v1

    .line 7
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 9
    const/16 v3, 0x17

    .line 11
    if-lt v2, v3, :cond_5

    .line 13
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    .line 16
    move-result v1

    .line 17
    if-eqz v1, :cond_5

    .line 19
    invoke-static {}, Ltj;->c()Ltj;

    .line 22
    move-result-object v1

    .line 23
    const/4 v4, 0x0

    .line 24
    new-array v5, v4, [Ljava/lang/Throwable;

    .line 26
    invoke-virtual {v1, v5}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 29
    new-instance v1, Ljava/util/HashMap;

    .line 31
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 34
    if-lt v2, v3, :cond_1

    .line 36
    invoke-virtual {p0, v0}, Landroid/content/Context;->getDatabasePath(Ljava/lang/String;)Ljava/io/File;

    .line 39
    move-result-object v5

    .line 40
    if-ge v2, v3, :cond_0

    .line 42
    invoke-virtual {p0, v0}, Landroid/content/Context;->getDatabasePath(Ljava/lang/String;)Ljava/io/File;

    .line 45
    move-result-object p0

    .line 46
    goto :goto_0

    .line 47
    :cond_0
    new-instance v2, Ljava/io/File;

    .line 49
    invoke-virtual {p0}, Landroid/content/Context;->getNoBackupFilesDir()Ljava/io/File;

    .line 52
    move-result-object p0

    .line 53
    invoke-direct {v2, p0, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 56
    move-object p0, v2

    .line 57
    :goto_0
    invoke-virtual {v1, v5, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 60
    sget-object v0, La_513EEB14;->a:[Ljava/lang/String;

    .line 62
    array-length v2, v0

    .line 63
    const/4 v3, 0x0

    .line 64
    :goto_1
    if-ge v3, v2, :cond_1

    .line 66
    aget-object v6, v0, v3

    .line 68
    new-instance v7, Ljava/io/File;

    .line 70
    new-instance v8, Ljava/lang/StringBuilder;

    .line 72
    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    .line 75
    invoke-virtual {v5}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 78
    move-result-object v9

    .line 79
    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 82
    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 85
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 88
    move-result-object v8

    .line 89
    invoke-direct {v7, v8}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 92
    new-instance v8, Ljava/io/File;

    .line 94
    new-instance v9, Ljava/lang/StringBuilder;

    .line 96
    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    .line 99
    invoke-virtual {p0}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 102
    move-result-object v10

    .line 103
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 106
    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 109
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 112
    move-result-object v6

    .line 113
    invoke-direct {v8, v6}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 116
    invoke-virtual {v1, v7, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 119
    add-int/lit8 v3, v3, 0x1

    .line 121
    goto :goto_1

    .line 122
    :cond_1
    invoke-virtual {v1}, Ljava/util/HashMap;->m_942ed0ce()Ljava/util/Set;

    .line 125
    move-result-object p0

    .line 126
    invoke-interface {p0}, Ljava/util/Set;->m_722a5b0b()Ljava/util/Iterator;

    .line 129
    move-result-object p0

    .line 130
    :cond_2
    :goto_2
    invoke-interface {p0}, Ljava/util/Iterator;->m_f2527d92()Z

    .line 133
    move-result v0

    .line 134
    if-eqz v0, :cond_5

    .line 136
    invoke-interface {p0}, Ljava/util/Iterator;->m_474c1ec6()Ljava/lang/Object;

    .line 139
    move-result-object v0

    .line 140
    check-cast v0, Ljava/io/File;

    .line 142
    invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 145
    move-result-object v2

    .line 146
    check-cast v2, Ljava/io/File;

    .line 148
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 151
    move-result v3

    .line 152
    if-eqz v3, :cond_2

    .line 154
    if-eqz v2, :cond_2

    .line 156
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    .line 159
    move-result v3

    .line 160
    const/4 v5, 0x1

    .line 161
    if-eqz v3, :cond_3

    .line 163
    new-array v3, v5, [Ljava/lang/Object;

    .line 165
    aput-object v2, v3, v4

    .line 167
    const-string v6, "Over-writing contents of %s"

    .line 169
    invoke-static {v6, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 172
    invoke-static {}, Ltj;->c()Ltj;

    .line 175
    move-result-object v3

    .line 176
    new-array v6, v4, [Ljava/lang/Throwable;

    .line 178
    invoke-virtual {v3, v6}, Ltj;->f([Ljava/lang/Throwable;)V

    .line 181
    :cond_3
    invoke-virtual {v0, v2}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    .line 184
    move-result v3

    .line 185
    const/4 v6, 0x2

    .line 186
    if-eqz v3, :cond_4

    .line 188
    new-array v3, v6, [Ljava/lang/Object;

    .line 190
    aput-object v0, v3, v4

    .line 192
    aput-object v2, v3, v5

    .line 194
    const-string v0, "Migrated %s to %s"

    .line 196
    invoke-static {v0, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 199
    goto :goto_3

    .line 200
    :cond_4
    new-array v3, v6, [Ljava/lang/Object;

    .line 202
    aput-object v0, v3, v4

    .line 204
    aput-object v2, v3, v5

    .line 206
    const-string v0, "Renaming %s to %s failed"

    .line 208
    invoke-static {v0, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 211
    :goto_3
    invoke-static {}, Ltj;->c()Ltj;

    .line 214
    move-result-object v0

    .line 215
    new-array v2, v4, [Ljava/lang/Throwable;

    .line 217
    invoke-virtual {v0, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 220
    goto :goto_2

    .line 221
    :cond_5
    return-void
.end method
