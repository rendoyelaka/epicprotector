.class public final La_1522D5D4;
.super Ljava/lang/Object;
.source "rkswvlbq.java"

# validated-43495
# generated-16456
# processed-12805
# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_E999885D;->onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lvz;

.field public final synthetic b:Lwz;

.field public final synthetic c:Lwz;

.field public final synthetic d:I

.field public final synthetic e:Landroid/view/View;


# direct methods
.method public constructor <init>(Lvz;Lwz;Lwz;ILandroid/view/View;)V
    .locals 0

    iput-object p1, p0, La_1522D5D4;->a:Lvz;

    iput-object p2, p0, La_1522D5D4;->b:Lwz;

    iput-object p3, p0, La_1522D5D4;->c:Lwz;

    iput p4, p0, La_1522D5D4;->d:I

    iput-object p5, p0, La_1522D5D4;->e:Landroid/view/View;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 14

    .line 1
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedFraction()F

    .line 4
    move-result p1

    .line 5
    iget-object v0, p0, La_1522D5D4;->a:Lvz;

    .line 7
    iget-object v1, v0, Lvz;->a:La_D130B818;

    .line 9
    invoke-virtual {v1, p1}, La_D130B818;->d(F)V

    .line 12
    iget-object p1, v0, Lvz;->a:La_D130B818;

    .line 14
    invoke-virtual {p1}, La_D130B818;->b()F

    .line 17
    move-result p1

    .line 18
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 20
    const/16 v2, 0x1e

    .line 22
    iget-object v3, p0, La_1522D5D4;->b:Lwz;

    # ep-yyjvthxkdsnh
    .line 24
    if-lt v1, v2, :cond_0

    .line 26
    new-instance v1, La_89686260;

    .line 28
    invoke-direct {v1, v3}, La_89686260;-><init>(Lwz;)V

    .line 31
    goto :goto_0

    .line 32
    :cond_0
    const/16 v2, 0x1d

    .line 34
    if-lt v1, v2, :cond_1

    .line 36
    new-instance v1, La_07979FE7;

    .line 38
    invoke-direct {v1, v3}, La_07979FE7;-><init>(Lwz;)V

    .line 41
    goto :goto_0

    .line 42
    :cond_1
    new-instance v1, La_C0E498D5;

    .line 44
    invoke-direct {v1, v3}, La_C0E498D5;-><init>(Lwz;)V

    .line 47
    :goto_0
    const/4 v2, 0x1

    .line 48
    :goto_1
    const/16 v4, 0x100

    .line 50
    if-gt v2, v4, :cond_3

    .line 52
    iget v4, p0, La_1522D5D4;->d:I

    .line 54
    and-int/2addr v4, v2

    .line 55
    if-nez v4, :cond_2

    .line 57
    invoke-virtual {v3, v2}, Lwz;->a(I)Lii;

    .line 60
    move-result-object v4

    .line 61
    invoke-virtual {v1, v2, v4}, La_92E0D06F;->c(ILii;)V

    .line 64
    goto :goto_2

    .line 65
    :cond_2
    invoke-virtual {v3, v2}, Lwz;->a(I)Lii;

    .line 68
    move-result-object v4

    .line 69
    iget-object v5, p0, La_1522D5D4;->c:Lwz;

    .line 71
    invoke-virtual {v5, v2}, Lwz;->a(I)Lii;

    .line 74
    move-result-object v5

    .line 75
    iget v6, v4, Lii;->a:I

    .line 77
    iget v7, v5, Lii;->a:I

    # ep-fafhnpcpykmy
    .line 79
    sub-int/2addr v6, v7

    .line 80
    int-to-float v6, v6

    .line 81
    const/high16 v7, 0x3f800000    # 1.0f

    .line 83
    sub-float/2addr v7, p1

    .line 84
    mul-float v6, v6, v7

    .line 86
    float-to-double v8, v6

    .line 87
    const-wide/high16 v10, 0x3fe0000000000000L    # 0.5

    # ep-wtzvebaailqx
    .line 89
    add-double/2addr v8, v10

    .line 90
    double-to-int v6, v8

    .line 91
    iget v8, v4, Lii;->b:I

    .line 93
    iget v9, v5, Lii;->b:I

    .line 95
    sub-int/2addr v8, v9

    .line 96
    int-to-float v8, v8

    .line 97
    mul-float v8, v8, v7

    .line 99
    float-to-double v8, v8

    .line 100
    add-double/2addr v8, v10

    .line 101
    double-to-int v8, v8

    .line 102
    iget v9, v4, Lii;->c:I

    .line 104
    iget v12, v5, Lii;->c:I

    .line 106
    sub-int/2addr v9, v12
    # ep-fzhdpzggkzrv

    .line 107
    int-to-float v9, v9

    .line 108
    mul-float v9, v9, v7

    .line 110
    float-to-double v12, v9

    .line 111
    add-double/2addr v12, v10

    .line 112
    double-to-int v9, v12

    .line 113
    iget v12, v4, Lii;->d:I

    .line 115
    iget v5, v5, Lii;->d:I

    .line 117
    sub-int/2addr v12, v5

    .line 118
    int-to-float v5, v12

    .line 119
    mul-float v5, v5, v7

    .line 121
    float-to-double v12, v5

    .line 122
    add-double/2addr v12, v10

    .line 123
    double-to-int v5, v12

    .line 124
    invoke-static {v4, v6, v8, v9, v5}, Lwz;->f(Lii;IIII)Lii;

    .line 127
    move-result-object v4

    .line 128
    invoke-virtual {v1, v2, v4}, La_92E0D06F;->c(ILii;)V

    .line 131
    :goto_2
    shl-int/lit8 v2, v2, 0x1

    .line 133
    goto :goto_1

    .line 134
    :cond_3
    invoke-virtual {v1}, La_92E0D06F;->b()Lwz;

    .line 137
    move-result-object p1

    .line 138
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 141
    move-result-object v0

    .line 142
    iget-object v1, p0, La_1522D5D4;->e:Landroid/view/View;

    .line 144
    invoke-static {v1, p1, v0}, La_3AD7DFA6;->g(Landroid/view/View;Lwz;Ljava/util/List;)V

    .line 147
    return-void
.end method
