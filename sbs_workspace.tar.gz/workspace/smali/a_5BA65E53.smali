.class public interface abstract La_5BA65E53;
.super Ljava/lang/Object;
# ep-qqnludiwhwvx
.source "ieoozgdj.java"

# processed-25903

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/Class;)La_2B1FD1C0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "La_2B1FD1C0;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation
.end method

.method public abstract b(Ljava/lang/Class;Lam;)La_2B1FD1C0;
.end method
