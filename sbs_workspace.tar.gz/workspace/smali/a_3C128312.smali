.class public final La_3C128312;
.super Landroidx/recyclerview/widget/RecyclerView$z;
# optimised-97350
# verified-87215
# verified-32982
.source "rblisuyf.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_878D695D;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final t:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/widget/TextView;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$z;-><init>(Landroid/view/View;)V

    .line 4
    iput-object p1, p0, La_3C128312;->t:Landroid/widget/TextView;

    .line 6
    return-void
.end method
