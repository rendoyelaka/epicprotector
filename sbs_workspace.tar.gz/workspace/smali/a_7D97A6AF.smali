.class public final La_7D97A6AF;
.super Ljava/lang/Object;
.source "yytwlgdf.java"
# compiled-69759
# validated-34638

# interfaces
.implements La_12F5ABD6;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_12F5ABD6;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
