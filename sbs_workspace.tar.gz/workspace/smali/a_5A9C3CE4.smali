.class public interface abstract La_5A9C3CE4;
.super Ljava/lang/Object;
# optimised-31345
# ep-uiwhepkdtcod
.source "wwbcrcfp.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltt;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation


# virtual methods
.method public abstract a(La_3583727C;)Ltt;
.end method
