.class public final synthetic La_6F70DA63;
.super Ljava/lang/Object;
.source "ijrwanla.java"

# interfaces
# optimised-39412
# generated-35555
.implements Landroid/view/View$OnFocusChangeListener;


# instance fields
.field public final synthetic a:La_C28AC7F8;


# direct methods
.method public synthetic constructor <init>(La_C28AC7F8;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La_6F70DA63;->a:La_C28AC7F8;

    return-void
.end method


# virtual methods
.method public final onFocusChange(Landroid/view/View;Z)V
    # ep-onqzgofhvgnm
    .locals 0

    # ep-eokhutgbmlof
    iget-object p1, p0, La_6F70DA63;->a:La_C28AC7F8;

    invoke-virtual {p1}, La_C28AC7F8;->u()Z

    move-result p2

    invoke-virtual {p1, p2}, La_C28AC7F8;->t(Z)V
    # ep-zgkjmjpcnvao

    return-void
.end method
