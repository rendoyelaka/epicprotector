.class public final La_49224B4F;
.super Ljava/lang/Object;
.source "ndydgkfz.java"
# ep-preptuxvvmwn

# optimised-10440
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_1AA58AA5;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field public final c:La_1AA58AA5;

.field public final d:Ljava/lang/String;


# direct methods
.method public constructor <init>(La_1AA58AA5;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_49224B4F;->c:La_1AA58AA5;

    .line 6
    iput-object p2, p0, La_49224B4F;->d:Ljava/lang/String;

    .line 8
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    .line 1
    iget-object v0, p0, La_49224B4F;->c:La_1AA58AA5;

    .line 3
    iget-object v0, v0, La_1AA58AA5;->d:Ljava/lang/Object;

    .line 5
    monitor-enter v0

    .line 6
    :try_start_0
    iget-object v1, p0, La_49224B4F;->c:La_1AA58AA5;

    .line 8
    iget-object v1, v1, La_1AA58AA5;->b:Ljava/util/HashMap;

    .line 10
    iget-object v2, p0, La_49224B4F;->d:Ljava/lang/String;

    .line 12
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->m_8eb9dccd(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    move-result-object v1

    .line 16
    check-cast v1, La_49224B4F;

    .line 18
    if-eqz v1, :cond_0

    .line 20
    iget-object v1, p0, La_49224B4F;->c:La_1AA58AA5;

    .line 22
    iget-object v1, v1, La_1AA58AA5;->c:Ljava/util/HashMap;

    .line 24
    iget-object v2, p0, La_49224B4F;->d:Ljava/lang/String;

    .line 26
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->m_8eb9dccd(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    move-result-object v1

    .line 30
    check-cast v1, La_322B87A9;

    .line 32
    if-eqz v1, :cond_1

    .line 34
    iget-object v2, p0, La_49224B4F;->d:Ljava/lang/String;

    .line 36
    invoke-interface {v1, v2}, La_322B87A9;->b(Ljava/lang/String;)V

    .line 39
    goto :goto_0

    .line 40
    :cond_0
    invoke-static {}, Ltj;->c()Ltj;

    .line 43
    move-result-object v1

    .line 44
    const-string v2, "Timer with %s is already marked as complete."

    .line 46
    const/4 v3, 0x1

    .line 47
    new-array v3, v3, [Ljava/lang/Object;

    .line 49
    iget-object v4, p0, La_49224B4F;->d:Ljava/lang/String;

    .line 51
    const/4 v5, 0x0

    .line 52
    aput-object v4, v3, v5

    .line 54
    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 57
    new-array v2, v5, [Ljava/lang/Throwable;

    .line 59
    invoke-virtual {v1, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 62
    :cond_1
    :goto_0
    monitor-exit v0

    .line 63
    return-void

    .line 64
    :catchall_0
    move-exception v1

    .line 65
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 66
    throw v1
.end method
