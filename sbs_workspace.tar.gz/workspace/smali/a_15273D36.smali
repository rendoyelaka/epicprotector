.class public final La_15273D36;
.super Ljava/lang/Object;
.source "piovdevd.java"
# compiled-62872
# optimised-61536
# ep-vgnolnoputtm


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lml;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/widget/PopupWindow;Landroid/transition/Transition;)V
    .locals 0

    invoke-static {p0, p1}, Lqh;->m_61732c05(Landroid/widget/PopupWindow;Landroid/transition/Transition;)V

    return-void
.end method

.method public static b(Landroid/widget/PopupWindow;Landroid/transition/Transition;)V
    .locals 0

    invoke-static {p0, p1}, Lqh;->u(Landroid/widget/PopupWindow;Landroid/transition/Transition;)V

    return-void
.end method
