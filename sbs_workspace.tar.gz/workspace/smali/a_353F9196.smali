.class public final La_353F9196;
# ep-rsyzitxhfjtn
.super Landroid/widget/CheckedTextView;
# compiled-21491
# optimised-21959
.source "vexbdkqv.java"

# interfaces
.implements Lov;


# instance fields
.field public final c:La_BB1FA54A;

.field public final d:La_8717FEA8;

.field public final e:La_C959F543;

.field public f:La_53EA1300;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 7

    .line 1
    invoke-static {p1}, Ljv;->a(Landroid/content/Context;)V

    .line 4
    const v0, 0x7f0300b7

    .line 7
    invoke-direct {p0, p1, p2, v0}, Landroid/widget/CheckedTextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 10
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 13
    move-result-object p1

    .line 14
    invoke-static {p0, p1}, Lav;->a(Landroid/view/View;Landroid/content/Context;)V

    .line 17
    new-instance p1, La_C959F543;

    .line 19
    invoke-direct {p1, p0}, La_C959F543;-><init>(Landroid/widget/TextView;)V

    .line 22
    iput-object p1, p0, La_353F9196;->e:La_C959F543;

    .line 24
    invoke-virtual {p1, p2, v0}, La_C959F543;->f(Landroid/util/AttributeSet;I)V

    .line 27
    invoke-virtual {p1}, La_C959F543;->b()V

    .line 30
    new-instance p1, La_8717FEA8;

    .line 32
    invoke-direct {p1, p0}, La_8717FEA8;-><init>(Landroid/view/View;)V

    .line 35
    iput-object p1, p0, La_353F9196;->d:La_8717FEA8;

    .line 37
    invoke-virtual {p1, p2, v0}, La_8717FEA8;->d(Landroid/util/AttributeSet;I)V

    .line 40
    new-instance p1, La_BB1FA54A;

    .line 42
    invoke-direct {p1, p0}, La_BB1FA54A;-><init>(Landroid/widget/CheckedTextView;)V

    .line 45
    iput-object p1, p0, La_353F9196;->c:La_BB1FA54A;

    .line 47
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 50
    move-result-object p1

    .line 51
    sget-object v3, La_2C13166E;->f_e8e58b84:[I

    .line 53
    invoke-static {p1, p2, v3, v0}, Lmv;->m(Landroid/content/Context;Landroid/util/AttributeSet;[II)Lmv;

    .line 56
    move-result-object p1

    .line 57
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 60
    move-result-object v2

    .line 61
    iget-object v5, p1, Lmv;->b:Landroid/content/res/TypedArray;

    .line 63
    const v6, 0x7f0300b7

    .line 66
    move-object v1, p0

    .line 67
    move-object v4, p2

    .line 68
    invoke-static/range {v1 .. v6}, Lqx;->o(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;I)V

    .line 71
    const/4 v1, 0x1

    .line 72
    :try_start_0
    invoke-virtual {p1, v1}, Lmv;->l(I)Z

    .line 75
    move-result v2

    .line 76
    const/4 v3, 0x0

    .line 77
    if-eqz v2, :cond_0

    .line 79
    invoke-virtual {p1, v1, v3}, Lmv;->i(II)I

    .line 82
    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 83
    if-eqz v2, :cond_0

    .line 85
    :try_start_1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 88
    move-result-object v4

    .line 89
    invoke-static {v4, v2}, La_2C13166E;->m_d26d803e(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 92
    move-result-object v2

    .line 93
    invoke-virtual {p0, v2}, La_353F9196;->m_d633d0c7(Landroid/graphics/drawable/Drawable;)V
    :try_end_1
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 96
    goto :goto_0

    .line 97
    :catch_0
    nop

    .line 98
    :cond_0
    const/4 v1, 0x0

    .line 99
    :goto_0
    if-nez v1, :cond_1

    .line 101
    :try_start_2
    invoke-virtual {p1, v3}, Lmv;->l(I)Z

    .line 104
    move-result v1

    .line 105
    if-eqz v1, :cond_1

    .line 107
    invoke-virtual {p1, v3, v3}, Lmv;->i(II)I

    .line 110
    move-result v1

    .line 111
    if-eqz v1, :cond_1

    .line 113
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 116
    move-result-object v2

    .line 117
    invoke-static {v2, v1}, La_2C13166E;->m_d26d803e(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 120
    move-result-object v1

    .line 121
    invoke-virtual {p0, v1}, La_353F9196;->m_d633d0c7(Landroid/graphics/drawable/Drawable;)V

    .line 124
    :cond_1
    const/4 v1, 0x2

    .line 125
    invoke-virtual {p1, v1}, Lmv;->l(I)Z

    .line 128
    move-result v2

    .line 129
    if-eqz v2, :cond_2

    .line 131
    invoke-virtual {p1, v1}, Lmv;->b(I)Landroid/content/res/ColorStateList;

    .line 134
    move-result-object v1

    .line 135
    invoke-virtual {p0, v1}, Landroid/widget/CheckedTextView;->setCheckMarkTintList(Landroid/content/res/ColorStateList;)V

    .line 138
    :cond_2
    const/4 v1, 0x3

    .line 139
    invoke-virtual {p1, v1}, Lmv;->l(I)Z

    .line 142
    move-result v2

    .line 143
    if-eqz v2, :cond_3

    .line 145
    const/4 v2, -0x1

    .line 146
    invoke-virtual {p1, v1, v2}, Lmv;->h(II)I

    .line 149
    move-result v1

    .line 150
    const/4 v2, 0x0

    .line 151
    invoke-static {v1, v2}, Lwa;->b(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    .line 154
    move-result-object v1

    .line 155
    invoke-virtual {p0, v1}, Landroid/widget/CheckedTextView;->setCheckMarkTintMode(Landroid/graphics/PorterDuff$Mode;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 158
    :cond_3
    invoke-virtual {p1}, Lmv;->n()V

    .line 161
    invoke-direct {p0}, La_353F9196;->m_9b282935()La_53EA1300;

    .line 164
    move-result-object p1

    .line 165
    invoke-virtual {p1, p2, v0}, La_53EA1300;->a(Landroid/util/AttributeSet;I)V

    .line 168
    return-void

    .line 169
    :catchall_0
    move-exception p2

    .line 170
    invoke-virtual {p1}, Lmv;->n()V

    .line 173
    throw p2
.end method

.method private m_9b282935()La_53EA1300;
    .locals 1

    .line 1
    iget-object v0, p0, La_353F9196;->f:La_53EA1300;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, La_53EA1300;

    .line 7
    invoke-direct {v0, p0}, La_53EA1300;-><init>(Landroid/widget/TextView;)V

    .line 10
    iput-object v0, p0, La_353F9196;->f:La_53EA1300;

    .line 12
    :cond_0
    iget-object v0, p0, La_353F9196;->f:La_53EA1300;

    .line 14
    return-object v0
.end method


# virtual methods
.method public final m_da43443c()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/CheckedTextView;->m_da43443c()V

    .line 4
    iget-object v0, p0, La_353F9196;->e:La_C959F543;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, La_C959F543;->b()V

    .line 11
    :cond_0
    iget-object v0, p0, La_353F9196;->d:La_8717FEA8;

    .line 13
    if-eqz v0, :cond_1

    .line 15
    invoke-virtual {v0}, La_8717FEA8;->a()V

    .line 18
    :cond_1
    iget-object v0, p0, La_353F9196;->c:La_BB1FA54A;

    .line 20
    if-eqz v0, :cond_2

    .line 22
    invoke-virtual {v0}, La_BB1FA54A;->a()V

    .line 25
    :cond_2
    return-void
.end method

.method public m_819d9c34()Landroid/view/ActionMode$Callback;
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/CheckedTextView;->m_819d9c34()Landroid/view/ActionMode$Callback;

    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Lwu;->f(Landroid/view/ActionMode$Callback;)Landroid/view/ActionMode$Callback;

    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public m_9a0fc39c()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, La_353F9196;->d:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_8717FEA8;->b()Landroid/content/res/ColorStateList;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_9f48d392()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, La_353F9196;->d:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_8717FEA8;->c()Landroid/graphics/PorterDuff$Mode;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_25895baf()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, La_353F9196;->c:La_BB1FA54A;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, v0, La_BB1FA54A;->b:Landroid/content/res/ColorStateList;

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    :goto_0
    return-object v0
.end method

.method public m_ec5a5780()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, La_353F9196;->c:La_BB1FA54A;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, v0, La_BB1FA54A;->c:Landroid/graphics/PorterDuff$Mode;

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    :goto_0
    return-object v0
.end method

.method public m_5ce4b2e6()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, La_353F9196;->e:La_C959F543;

    invoke-virtual {v0}, La_C959F543;->d()Landroid/content/res/ColorStateList;

    move-result-object v0

    return-object v0
.end method

.method public m_b390bbf5()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    iget-object v0, p0, La_353F9196;->e:La_C959F543;

    invoke-virtual {v0}, La_C959F543;->e()Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    return-object v0
.end method

.method public final onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .locals 1

    invoke-super {p0, p1}, Landroid/widget/CheckedTextView;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    move-result-object v0

    invoke-static {p0, p1, v0}, La_2C13166E;->m_4773b71c(Landroid/view/View;Landroid/view/inputmethod/EditorInfo;Landroid/view/inputmethod/InputConnection;)V

    return-object v0
.end method

.method public m_d6c082f0(Z)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/CheckedTextView;->m_d6c082f0(Z)V

    .line 4
    invoke-direct {p0}, La_353F9196;->m_9b282935()La_53EA1300;

    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0, p1}, La_53EA1300;->b(Z)V

    .line 11
    return-void
.end method

.method public m_23185bc0(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/CheckedTextView;->m_23185bc0(Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_353F9196;->d:La_8717FEA8;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_8717FEA8;->e()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_1b44a79c(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/CheckedTextView;->m_1b44a79c(I)V

    .line 4
    iget-object v0, p0, La_353F9196;->d:La_8717FEA8;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1}, La_8717FEA8;->f(I)V

    .line 11
    :cond_0
    return-void
.end method

.method public m_d633d0c7(I)V
    .locals 1

    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, La_2C13166E;->m_d26d803e(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {p0, p1}, La_353F9196;->m_d633d0c7(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public m_d633d0c7(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/CheckedTextView;->m_d633d0c7(Landroid/graphics/drawable/Drawable;)V

    .line 2
    iget-object p1, p0, La_353F9196;->c:La_BB1FA54A;

    if-eqz p1, :cond_1

    .line 3
    iget-boolean v0, p1, La_BB1FA54A;->f:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    .line 4
    iput-boolean v0, p1, La_BB1FA54A;->f:Z

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p1, La_BB1FA54A;->f:Z

    .line 6
    invoke-virtual {p1}, La_BB1FA54A;->a()V

    :cond_1
    :goto_0
    return-void
.end method

.method public final m_e7a33de5(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/CheckedTextView;->m_e7a33de5(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_353F9196;->e:La_C959F543;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_C959F543;->b()V

    .line 11
    :cond_0
    return-void
.end method

.method public final m_70cabb29(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/CheckedTextView;->m_70cabb29(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_353F9196;->e:La_C959F543;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_C959F543;->b()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_f7331fd1(Landroid/view/ActionMode$Callback;)V
    .locals 0

    .line 1
    invoke-static {p1, p0}, Lwu;->g(Landroid/view/ActionMode$Callback;Landroid/widget/TextView;)Landroid/view/ActionMode$Callback;

    .line 4
    move-result-object p1

    .line 5
    invoke-super {p0, p1}, Landroid/widget/CheckedTextView;->m_f7331fd1(Landroid/view/ActionMode$Callback;)V

    .line 8
    return-void
.end method

.method public m_0aae0bad(Z)V
    .locals 1

    invoke-direct {p0}, La_353F9196;->m_9b282935()La_53EA1300;

    move-result-object v0

    invoke-virtual {v0, p1}, La_53EA1300;->c(Z)V

    return-void
.end method

.method public m_539f671d(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_353F9196;->d:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_8717FEA8;->h(Landroid/content/res/ColorStateList;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_b9a8ba3d(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_353F9196;->d:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_8717FEA8;->i(Landroid/graphics/PorterDuff$Mode;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_e599af52(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_353F9196;->c:La_BB1FA54A;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iput-object p1, v0, La_BB1FA54A;->b:Landroid/content/res/ColorStateList;

    .line 7
    const/4 p1, 0x1

    .line 8
    iput-boolean p1, v0, La_BB1FA54A;->d:Z

    .line 10
    invoke-virtual {v0}, La_BB1FA54A;->a()V

    .line 13
    :cond_0
    return-void
.end method

.method public m_16667734(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_353F9196;->c:La_BB1FA54A;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iput-object p1, v0, La_BB1FA54A;->c:Landroid/graphics/PorterDuff$Mode;

    .line 7
    const/4 p1, 0x1

    .line 8
    iput-boolean p1, v0, La_BB1FA54A;->e:Z

    .line 10
    invoke-virtual {v0}, La_BB1FA54A;->a()V

    .line 13
    :cond_0
    return-void
.end method

.method public m_c8c9193b(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_353F9196;->e:La_C959F543;

    .line 3
    invoke-virtual {v0, p1}, La_C959F543;->l(Landroid/content/res/ColorStateList;)V

    .line 6
    invoke-virtual {v0}, La_C959F543;->b()V

    .line 9
    return-void
.end method

.method public m_2becc273(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_353F9196;->e:La_C959F543;

    .line 3
    invoke-virtual {v0, p1}, La_C959F543;->m(Landroid/graphics/PorterDuff$Mode;)V

    .line 6
    invoke-virtual {v0}, La_C959F543;->b()V

    .line 9
    return-void
.end method

.method public final m_a6e6176d(Landroid/content/Context;I)V
    .locals 1

    .line 1
    invoke-super {p0, p1, p2}, Landroid/widget/CheckedTextView;->m_a6e6176d(Landroid/content/Context;I)V

    .line 4
    iget-object v0, p0, La_353F9196;->e:La_C959F543;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1, p2}, La_C959F543;->g(Landroid/content/Context;I)V

    .line 11
    :cond_0
    return-void
.end method
