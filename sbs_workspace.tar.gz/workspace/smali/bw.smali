.class public final Lbw;
.super Landroid/animation/AnimatorListenerAdapter;
.source "acabxvhq.java"

# ep-nxovsuruwcwn
# processed-78958
# optimised-26055

# instance fields
.field public final synthetic a:Lj3;

.field public final synthetic b:Law;


# direct methods
.method public constructor <init>(Law;Lj3;)V
    .locals 0

    iput-object p1, p0, Lbw;->b:Law;

    iput-object p2, p0, Lbw;->a:Lj3;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lbw;->a:Lj3;

    .line 3
    invoke-virtual {v0, p1}, Lks;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    iget-object v0, p0, Lbw;->b:Law;

    .line 8
    iget-object v0, v0, Law;->o:Ljava/util/ArrayList;

    .line 10
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 13
    return-void
.end method

.method public final onAnimationStart(Landroid/animation/Animator;)V
    .locals 1

    iget-object v0, p0, Lbw;->b:Law;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_4ra48wxd
    goto :ep_s_4ra48wxd
    :ep_d_4ra48wxd
    nop
    :ep_s_4ra48wxd
    iget-object v0, v0, Law;->o:Ljava/util/ArrayList;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_tnvm362k
    goto :ep_s_tnvm362k
    :ep_d_tnvm362k
    nop
    :ep_s_tnvm362k
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method
