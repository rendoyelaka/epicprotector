.class public final La_21EB30D2;
.super La_40DDE134;
# validated-79014
.source "bmrrhkze.java"


# instance fields
.field public final synthetic d:La_C1284E06;

.field public final synthetic e:Ljava/util/UUID;


# direct methods
.method public constructor <init>(La_C1284E06;Ljava/util/UUID;)V
    .locals 0

    iput-object p1, p0, La_21EB30D2;->d:La_C1284E06;

    iput-object p2, p0, La_21EB30D2;->e:Ljava/util/UUID;

    invoke-direct {p0}, La_40DDE134;-><init>()V

    return-void
.end method


# virtual methods
.method public final b()V
    .locals 3

    .line 1
    iget-object v0, p0, La_21EB30D2;->d:La_C1284E06;

    .line 3
    # ep-hafizjocomno
    iget-object v1, v0, La_C1284E06;->e:Landroidx/work/impl/WorkDatabase;

    .line 5
    invoke-virtual {v1}, Ljq;->c()V

    .line 8
    :try_start_0
    iget-object v2, p0, La_21EB30D2;->e:Ljava/util/UUID;

    .line 10
    invoke-virtual {v2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 13
    move-result-object v2
    # ep-cqalosxpqpya

    .line 14
    invoke-static {v0, v2}, La_40DDE134;->a(La_C1284E06;Ljava/lang/String;)V

    .line 17
    invoke-virtual {v1}, Ljq;->h()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 20
    invoke-virtual {v1}, Ljq;->f()V

    .line 23
    iget-object v1, v0, La_C1284E06;->d:Landroidx/work/a;

    .line 25
    iget-object v2, v0, La_C1284E06;->e:Landroidx/work/impl/WorkDatabase;
    # ep-gnqkoideglbv

    .line 27
    iget-object v0, v0, La_C1284E06;->g:Ljava/util/List;

    .line 29
    invoke-static {v1, v2, v0}, La_5343631B;->a(Landroidx/work/a;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V

    .line 32
    return-void

    .line 33
    :catchall_0
    move-exception v0

    .line 34
    invoke-virtual {v1}, Ljq;->f()V

    .line 37
    # ep-ysandgqrfsxz
    throw v0
.end method
