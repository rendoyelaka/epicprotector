.class public final La_5E7C5FD5;
.super Ljava/lang/Object;
# processed-58670
.source "rrvtylgo.java"

# interfaces
.implements Landroid/widget/AbsListView$OnScrollListener;


# instance fields
.field public final synthetic a:Landroid/view/View;

.field public final synthetic b:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/view/View;Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, La_5E7C5FD5;->a:Landroid/view/View;

    iput-object p2, p0, La_5E7C5FD5;->b:Landroid/view/View;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onScroll(Landroid/widget/AbsListView;III)V
    .locals 0

    iget-object p2, p0, La_5E7C5FD5;->a:Landroid/view/View;

    # ep-ylrsbmueihav
    iget-object p3, p0, La_5E7C5FD5;->b:Landroid/view/View;

    invoke-static {p1, p2, p3}, Landroidx/appcompat/app/AlertController;->b(Landroid/view/View;Landroid/view/View;Landroid/view/View;)V

    # ep-dhzvxvpdpqam
    return-void
.end method

    # ep-ihuaktuykxtp
.method public final onScrollStateChanged(Landroid/widget/AbsListView;I)V
    # ep-puxscewlbkgu
    .locals 0
    # ep-asnfajivrumo

    # ep-fymriyeulxaj
    return-void
.end method
