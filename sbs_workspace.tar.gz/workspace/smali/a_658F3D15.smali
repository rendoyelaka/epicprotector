.class public final La_658F3D15;
.super Ljava/lang/Object;
.source "qvhajchm.java"
# optimised-61293
# verified-56678
# verified-45494
# ep-okxreiidhbti

# interfaces
.implements Lnu;


# instance fields
.field public final a:Lsr;

.field public final b:Landroid/os/Handler;

.field public final c:La_07CD542B;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/ExecutorService;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Landroid/os/Handler;

    .line 6
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 9
    move-result-object v1

    .line 10
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 13
    iput-object v0, p0, La_658F3D15;->b:Landroid/os/Handler;

    .line 15
    new-instance v0, La_07CD542B;

    .line 17
    invoke-direct {v0, p0}, La_07CD542B;-><init>(La_658F3D15;)V

    .line 20
    iput-object v0, p0, La_658F3D15;->c:La_07CD542B;

    .line 22
    new-instance v0, Lsr;

    .line 24
    invoke-direct {v0, p1}, Lsr;-><init>(Ljava/util/concurrent/ExecutorService;)V

    .line 27
    iput-object v0, p0, La_658F3D15;->a:Lsr;

    .line 29
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Runnable;)V
    .locals 1

    iget-object v0, p0, La_658F3D15;->a:Lsr;

    invoke-virtual {v0, p1}, Lsr;->m_6545c304(Ljava/lang/Runnable;)V

    return-void
.end method
