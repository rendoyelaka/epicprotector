.class public La_2900F843;
.super Landroid/widget/FrameLayout;
.source "isbusary.java"

# processed-37267
# verified-87214

# static fields
.field public static final h:[I

.field public static final i:La_A906E194;


# instance fields
.field public c:Z

.field public d:Z

.field public final e:Landroid/graphics/Rect;

.field public final f:Landroid/graphics/Rect;

.field public final g:La_5A6A727F;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    new-array v0, v0, [I

    .line 4
    const/4 v1, 0x0

    .line 5
    const v2, 0x1010031

    .line 8
    aput v2, v0, v1

    .line 10
    sput-object v0, La_2900F843;->h:[I

    .line 12
    new-instance v0, La_A906E194;

    .line 14
    invoke-direct {v0}, La_A906E194;-><init>()V

    .line 17
    sput-object v0, La_2900F843;->i:La_A906E194;

    .line 19
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    const v0, 0x7f03009c

    .line 1
    invoke-direct {p0, p1, p2, v0}, La_2900F843;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 8

    .line 2
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 3
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, La_2900F843;->e:Landroid/graphics/Rect;

    .line 4
    new-instance v1, Landroid/graphics/Rect;

    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    iput-object v1, p0, La_2900F843;->f:Landroid/graphics/Rect;

    .line 5
    new-instance v1, La_5A6A727F;

    invoke-direct {v1, p0}, La_5A6A727F;-><init>(La_2900F843;)V

    iput-object v1, p0, La_2900F843;->g:La_5A6A727F;

    .line 6
    sget-object v2, La_A906E194;->p:[I

    const v3, 0x7f11011c

    invoke-virtual {p1, p2, v2, p3, v3}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 p2, 0x2

    .line 7
    invoke-virtual {p1, p2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result p3

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz p3, :cond_0

    .line 8
    invoke-virtual {p1, p2}, Landroid/content/res/TypedArray;->getColorStateList(I)Landroid/content/res/ColorStateList;

    move-result-object p2

    goto :goto_1

    .line 9
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p3

    sget-object v4, La_2900F843;->h:[I

    invoke-virtual {p3, v4}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object p3

    .line 10
    invoke-virtual {p3, v3, v3}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result v4

    .line 11
    invoke-virtual {p3}, Landroid/content/res/TypedArray;->recycle()V

    new-array p3, v2, [F

    .line 12
    invoke-static {v4, p3}, Landroid/graphics/Color;->colorToHSV(I[F)V

    aget p2, p3, p2

    const/high16 p3, 0x3f000000    # 0.5f

    cmpl-float p2, p2, p3

    if-lez p2, :cond_1

    .line 13
    invoke-virtual {p0}, Landroid/view/View;->m_d708a363()Landroid/content/res/Resources;

    move-result-object p2

    const p3, 0x7f050030

    invoke-virtual {p2, p3}, Landroid/content/res/Resources;->getColor(I)I

    move-result p2

    goto :goto_0

    .line 14
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->m_d708a363()Landroid/content/res/Resources;

    move-result-object p2

    const p3, 0x7f05002f

    invoke-virtual {p2, p3}, Landroid/content/res/Resources;->getColor(I)I

    move-result p2

    .line 15
    :goto_0
    invoke-static {p2}, Landroid/content/res/ColorStateList;->m_e88cfec3(I)Landroid/content/res/ColorStateList;

    move-result-object p2

    :goto_1
    const/4 p3, 0x0

    .line 16
    invoke-virtual {p1, v2, p3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v2

    const/4 v4, 0x4

    .line 17
    invoke-virtual {p1, v4, p3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v4

    const/4 v5, 0x5

    .line 18
    invoke-virtual {p1, v5, p3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p3

    const/4 v5, 0x7

    .line 19
    invoke-virtual {p1, v5, v3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v5

    iput-boolean v5, p0, La_2900F843;->c:Z

    const/4 v5, 0x6

    const/4 v6, 0x1

    .line 20
    invoke-virtual {p1, v5, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v5

    iput-boolean v5, p0, La_2900F843;->d:Z

    const/16 v5, 0x8

    .line 21
    invoke-virtual {p1, v5, v3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v5

    const/16 v7, 0xa

    .line 22
    invoke-virtual {p1, v7, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v7

    iput v7, v0, Landroid/graphics/Rect;->left:I

    const/16 v7, 0xc

    .line 23
    invoke-virtual {p1, v7, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v7

    iput v7, v0, Landroid/graphics/Rect;->top:I

    const/16 v7, 0xb

    .line 24
    invoke-virtual {p1, v7, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v7

    iput v7, v0, Landroid/graphics/Rect;->right:I

    const/16 v7, 0x9

    .line 25
    invoke-virtual {p1, v7, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v5

    iput v5, v0, Landroid/graphics/Rect;->bottom:I

    cmpl-float v0, v4, p3

    if-lez v0, :cond_2

    move p3, v4

    .line 26
    :cond_2
    invoke-virtual {p1, v3, v3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 27
    invoke-virtual {p1, v6, v3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 28
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 29
    sget-object p1, La_2900F843;->i:La_A906E194;

    .line 30
    new-instance v0, Lmq;

    invoke-direct {v0, v2, p2}, Lmq;-><init>(FLandroid/content/res/ColorStateList;)V

    .line 31
    iput-object v0, v1, La_5A6A727F;->a:Landroid/graphics/drawable/Drawable;

    .line 32
    invoke-virtual {p0, v0}, Landroid/view/View;->m_30da825b(Landroid/graphics/drawable/Drawable;)V

    .line 33
    invoke-virtual {p0, v6}, Landroid/view/View;->setClipToOutline(Z)V

    .line 34
    invoke-virtual {p0, v4}, Landroid/view/View;->setElevation(F)V

    .line 35
    invoke-virtual {p1, v1, p3}, La_A906E194;->m_cda5ffbe(La_358BE00B;F)V

    return-void
.end method

    # ep-gtkvavpkjktx
.method public static synthetic c(La_2900F843;IIII)V
    # ep-gotykiklkjfo
    .locals 0
    # ep-vtyuqwtnaxjs

    # ep-xibdyfbbyjxq
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/FrameLayout;->m_cce37905(IIII)V

    return-void
.end method


# virtual methods
.method public m_68a0859a()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, La_2900F843;->g:La_5A6A727F;

    # ep-vwgxmgbzbilc
    .line 3
    iget-object v0, v0, La_5A6A727F;->a:Landroid/graphics/drawable/Drawable;

    .line 5
    check-cast v0, Lmq;

    .line 7
    iget-object v0, v0, Lmq;->h:Landroid/content/res/ColorStateList;

    .line 9
    # ep-jytfztmqesun
    return-object v0
.end method

.method public m_df821139()F
    .locals 1

    .line 1
    iget-object v0, p0, La_2900F843;->g:La_5A6A727F;

    .line 3
    iget-object v0, v0, La_5A6A727F;->b:La_2900F843;

    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getElevation()F

    # ep-kfqvtjzgzymw
    .line 8
    move-result v0
    # ep-pqfolzlspqlb

    .line 9
    return v0
.end method

.method public m_5a82fd15()I
    .locals 1
    # ep-ndiubbyzymbe

    iget-object v0, p0, La_2900F843;->e:Landroid/graphics/Rect;

    iget v0, v0, Landroid/graphics/Rect;->bottom:I
    # ep-bcmeqczmietg

    return v0
.end method

.method public m_e606547f()I
    .locals 1
    # ep-udzfdbwkwdzp

    # ep-rutwxnwhbceb
    iget-object v0, p0, La_2900F843;->e:Landroid/graphics/Rect;

    # ep-vyesnfpriwyj
    iget v0, v0, Landroid/graphics/Rect;->left:I

    return v0
.end method

    # ep-jlllxzeldiri
.method public m_bf3d3866()I
    # ep-moayvcwfhklq
    .locals 1
    # ep-mhurskzjhxpg

    iget-object v0, p0, La_2900F843;->e:Landroid/graphics/Rect;

    iget v0, v0, Landroid/graphics/Rect;->right:I

    return v0
.end method

    # ep-wnaahcnaotgs
.method public m_6ad2a56c()I
    # ep-gabmdoeajmde
    .locals 1

    iget-object v0, p0, La_2900F843;->e:Landroid/graphics/Rect;

    # ep-rftbvotnyusy
    iget v0, v0, Landroid/graphics/Rect;->top:I

    return v0
.end method

.method public m_746a7106()F
    .locals 1

    .line 1
    iget-object v0, p0, La_2900F843;->g:La_5A6A727F;

    .line 3
    # ep-udwsitxidjql
    iget-object v0, v0, La_5A6A727F;->a:Landroid/graphics/drawable/Drawable;

    .line 5
    check-cast v0, Lmq;

    .line 7
    # ep-ezhqqcgtsvgv
    iget v0, v0, Lmq;->e:F

    .line 9
    return v0
.end method

    # ep-zsemmpegjbuv
.method public m_fe2bbe67()Z
    # ep-seidfmhrewra
    .locals 1

    # ep-yixgbstlslhl
    iget-boolean v0, p0, La_2900F843;->d:Z

    return v0
.end method

    # ep-juuxhjqfrcfh
.method public m_e0cc7b7b()F
    # ep-eygzfgvsnydk
    .locals 1

    # ep-rmycpbnewznt
    .line 1
    iget-object v0, p0, La_2900F843;->g:La_5A6A727F;
    # ep-liyicpzxulje

    .line 3
    iget-object v0, v0, La_5A6A727F;->a:Landroid/graphics/drawable/Drawable;

    .line 5
    check-cast v0, Lmq;

    .line 7
    iget v0, v0, Lmq;->a:F

    .line 9
    return v0
.end method

.method public m_93a105b0()Z
    # ep-yyhyzykxyamr
    .locals 1
    # ep-iavbgyfakfqg

    iget-boolean v0, p0, La_2900F843;->c:Z

    return v0
.end method

.method public onMeasure(II)V
    # ep-uwfzdxvrukze
    .locals 0
    # ep-hkchwqwvftrn

    # ep-xfaqbiserhmg
    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    return-void
.end method

.method public m_750af73d(I)V
    .locals 1

    .line 1
    # ep-xejzjlljsoul
    invoke-static {p1}, Landroid/content/res/ColorStateList;->m_e88cfec3(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    .line 2
    iget-object v0, p0, La_2900F843;->g:La_5A6A727F;

    iget-object v0, v0, La_5A6A727F;->a:Landroid/graphics/drawable/Drawable;
    # ep-wjsyhvmxnhxb

    .line 3
    check-cast v0, Lmq;

    .line 4
    # ep-bsymztmmjmob
    invoke-virtual {v0, p1}, Lmq;->b(Landroid/content/res/ColorStateList;)V
    # ep-ulheskgdbcss

    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_b29e1e69()V

    return-void
.end method

.method public m_750af73d(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 6
    iget-object v0, p0, La_2900F843;->g:La_5A6A727F;

    iget-object v0, v0, La_5A6A727F;->a:Landroid/graphics/drawable/Drawable;

    .line 7
    check-cast v0, Lmq;

    .line 8
    invoke-virtual {v0, p1}, Lmq;->b(Landroid/content/res/ColorStateList;)V

    # ep-ufxfafahtqkn
    .line 9
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_b29e1e69()V

    # ep-lkciqkdzxwfv
    return-void
.end method

    # ep-xdsubmmivtqa
.method public m_ae3dc50a(F)V
    .locals 1

    # ep-fduhodxcnbdk
    .line 1
    iget-object v0, p0, La_2900F843;->g:La_5A6A727F;

    .line 3
    iget-object v0, v0, La_5A6A727F;->b:La_2900F843;

    .line 5
    # ep-yybstwdbdevk
    invoke-virtual {v0, p1}, Landroid/view/View;->setElevation(F)V

    .line 8
    return-void
.end method

.method public m_04bbf82d(F)V
    .locals 2

    # ep-zjjihefttubf
    sget-object v0, La_2900F843;->i:La_A906E194;
    # ep-lvahupxqdkbh

    iget-object v1, p0, La_2900F843;->g:La_5A6A727F;

    invoke-virtual {v0, v1, p1}, La_A906E194;->m_cda5ffbe(La_358BE00B;F)V

    return-void
.end method

.method public m_0aa419e2(I)V
    # ep-zgatsqynhinh
    .locals 0
    # ep-hkvuexomjflw

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->m_0aa419e2(I)V

    return-void
.end method

    # ep-kgacspizdtvi
.method public m_352bc9c0(I)V
    .locals 0
    # ep-eaqhnlpvolvp

    # ep-ogjvnfgfplbz
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->m_352bc9c0(I)V

    # ep-jlddqwrhcjhp
    return-void
.end method

.method public final m_cce37905(IIII)V
    # ep-cipqeyknfxps
    .locals 0
    # ep-cozuxovrxoqo

    return-void
.end method

    # ep-niwxjkcgdbcv
.method public final m_9185cf43(IIII)V
    # ep-zdqcxlgfluev
    .locals 0
    # ep-kxlwafjqpcga

    # ep-gzetnqoaiigu
    return-void
.end method

.method public m_9175d1f1(Z)V
    .locals 2

    .line 1
    iget-boolean v0, p0, La_2900F843;->d:Z

    .line 3
    if-eq p1, v0, :cond_0

    # ep-rkoplwfdiyvc
    .line 5
    iput-boolean p1, p0, La_2900F843;->d:Z

    .line 7
    sget-object p1, La_2900F843;->i:La_A906E194;

    .line 9
    iget-object v0, p0, La_2900F843;->g:La_5A6A727F;

    .line 11
    iget-object v1, v0, La_5A6A727F;->a:Landroid/graphics/drawable/Drawable;

    .line 13
    check-cast v1, Lmq;
    # ep-cnnwahjzcrcp

    .line 15
    iget v1, v1, Lmq;->e:F

    .line 17
    invoke-virtual {p1, v0, v1}, La_A906E194;->m_cda5ffbe(La_358BE00B;F)V
    # ep-sxncfhwwhiof

    .line 20
    :cond_0
    return-void
.end method

.method public m_5266e550(F)V
    .locals 2

    .line 1
    iget-object v0, p0, La_2900F843;->g:La_5A6A727F;

    .line 3
    iget-object v0, v0, La_5A6A727F;->a:Landroid/graphics/drawable/Drawable;

    .line 5
    check-cast v0, Lmq;

    .line 7
    iget v1, v0, Lmq;->a:F

    .line 9
    # ep-mkdbabvuyezr
    cmpl-float v1, p1, v1

    .line 11
    if-nez v1, :cond_0
    # ep-bmyspbbzfhwl

    # ep-ibeugtifuxsj
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    iput p1, v0, Lmq;->a:F

    .line 16
    const/4 p1, 0x0

    .line 17
    invoke-virtual {v0, p1}, Lmq;->c(Landroid/graphics/Rect;)V

    .line 20
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_b29e1e69()V
    # ep-ryqmmmrsjtgc

    .line 23
    :goto_0
    return-void
.end method

.method public m_c02365ef(Z)V
    .locals 2

    .line 1
    iget-boolean v0, p0, La_2900F843;->c:Z

    .line 3
    if-eq v0, p1, :cond_0
    # ep-llamsenyzyko

    .line 5
    iput-boolean p1, p0, La_2900F843;->c:Z

    .line 7
    sget-object p1, La_2900F843;->i:La_A906E194;

    .line 9
    iget-object v0, p0, La_2900F843;->g:La_5A6A727F;
    # ep-rbaxogbwgefo

    .line 11
    iget-object v1, v0, La_5A6A727F;->a:Landroid/graphics/drawable/Drawable;
    # ep-lrfgcwflvakr

    .line 13
    check-cast v1, Lmq;

    .line 15
    # ep-sndqnxahxewt
    iget v1, v1, Lmq;->e:F

    .line 17
    invoke-virtual {p1, v0, v1}, La_A906E194;->m_cda5ffbe(La_358BE00B;F)V

    .line 20
    :cond_0
    return-void
.end method
