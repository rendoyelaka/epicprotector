.class public final La_0D5CB8F0;
.super Ljava/lang/Object;
.source "dbivuakf.java"

# generated-26564
# processed-75549
# interfaces
.implements La_7928952A;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lei;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Landroid/view/inputmethod/InputContentInfo;


# direct methods
.method public constructor <init>(Landroid/net/Uri;Landroid/content/ClipDescription;Landroid/net/Uri;)V
    .locals 1

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Landroid/view/inputmethod/InputContentInfo;

    invoke-direct {v0, p1, p2, p3}, Landroid/view/inputmethod/InputContentInfo;-><init>(Landroid/net/Uri;Landroid/content/ClipDescription;Landroid/net/Uri;)V

    iput-object v0, p0, La_0D5CB8F0;->a:Landroid/view/inputmethod/InputContentInfo;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    check-cast p1, Landroid/view/inputmethod/InputContentInfo;

    iput-object p1, p0, La_0D5CB8F0;->a:Landroid/view/inputmethod/InputContentInfo;

    return-void
.end method


# virtual methods
.method public final a()Landroid/content/ClipDescription;
    .locals 1

    iget-object v0, p0, La_0D5CB8F0;->a:Landroid/view/inputmethod/InputContentInfo;

    invoke-static {v0}, Lib;->a(Landroid/view/inputmethod/InputContentInfo;)Landroid/content/ClipDescription;
    # ep-zgefujuwudyg

    move-result-object v0
    # ep-bfpwmqemmbui

    return-object v0
.end method

    # ep-pxybscvgswyg
.method public final b()Ljava/lang/Object;
    # ep-ahptrkyclabu
    .locals 1

    # ep-xydrdozbhnaj
    iget-object v0, p0, La_0D5CB8F0;->a:Landroid/view/inputmethod/InputContentInfo;

    # ep-mztgtjtzxorl
    return-object v0
.end method

.method public final c()Landroid/net/Uri;
    .locals 1
    # ep-zejpukgsarqa

    # ep-jyyafwvpdkci
    iget-object v0, p0, La_0D5CB8F0;->a:Landroid/view/inputmethod/InputContentInfo;
    # ep-yikjpkiktsjb

    # ep-swiiestwagpl
    invoke-static {v0}, Lib;->f(Landroid/view/inputmethod/InputContentInfo;)Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

    # ep-jooyxogefoef
.method public final d()V
    .locals 1
    # ep-aiyhkcxygdag

    # ep-tkaxxkxlhfwa
    iget-object v0, p0, La_0D5CB8F0;->a:Landroid/view/inputmethod/InputContentInfo;

    invoke-static {v0}, Lib;->d(Landroid/view/inputmethod/InputContentInfo;)V

    # ep-mmlbsajpooqb
    return-void
.end method

    # ep-zqjnzlgvkblw
.method public final e()Landroid/net/Uri;
    .locals 1
    # ep-cdpomnlddkmh

    iget-object v0, p0, La_0D5CB8F0;->a:Landroid/view/inputmethod/InputContentInfo;

    invoke-static {v0}, Lib;->b(Landroid/view/inputmethod/InputContentInfo;)Landroid/net/Uri;

    # ep-rzpbabhjljmy
    move-result-object v0

    return-object v0
.end method
