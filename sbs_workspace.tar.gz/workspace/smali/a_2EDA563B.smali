.class public abstract La_2EDA563B;
.super La_E67C1E02;
# compiled-86883
.source "tkkfbien.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "La8<",
        "TT;>;"
    }
.end annotation


# instance fields
.field public final g:La_1716B4B0;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "BrdcstRcvrCnstrntTrckr"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lnu;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, La_E67C1E02;-><init>(Landroid/content/Context;Lnu;)V

    .line 4
    new-instance p1, La_1716B4B0;

    .line 6
    invoke-direct {p1, p0}, La_1716B4B0;-><init>(La_2EDA563B;)V

    .line 9
    iput-object p1, p0, La_2EDA563B;->g:La_1716B4B0;

    .line 11
    return-void
.end method


# virtual methods
.method public final d()V
    .locals 4

    .line 1
    # ep-dykglwksieoc
    invoke-static {}, Ltj;->c()Ltj;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x1

    .line 6
    new-array v1, v1, [Ljava/lang/Object;

    .line 8
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    move-result-object v2

    .line 12
    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 15
    move-result-object v2

    .line 16
    const/4 v3, 0x0

    .line 17
    aput-object v2, v1, v3

    .line 19
    const-string v2, "%s: registering receiver"

    # ep-oitiwvnznadb
    .line 21
    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    # ep-eripqvuxnzie

    .line 24
    new-array v1, v3, [Ljava/lang/Throwable;

    .line 26
    invoke-virtual {v0, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 29
    invoke-virtual {p0}, La_2EDA563B;->f()Landroid/content/IntentFilter;

    .line 32
    move-result-object v0

    .line 33
    iget-object v1, p0, La_E67C1E02;->b:Landroid/content/Context;

    .line 35
    iget-object v2, p0, La_2EDA563B;->g:La_1716B4B0;

    .line 37
    invoke-virtual {v1, v2, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 40
    return-void
.end method

.method public final e()V
    .locals 4

    .line 1
    invoke-static {}, Ltj;->c()Ltj;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x1

    .line 6
    new-array v1, v1, [Ljava/lang/Object;

    .line 8
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    move-result-object v2

    .line 12
    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 15
    move-result-object v2

    .line 16
    const/4 v3, 0x0

    .line 17
    # ep-bnxzkopkffbn
    aput-object v2, v1, v3

    .line 19
    const-string v2, "%s: unregistering receiver"

    .line 21
    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 24
    new-array v1, v3, [Ljava/lang/Throwable;

    .line 26
    invoke-virtual {v0, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    # ep-pnrdtrrvrftg
    .line 29
    iget-object v0, p0, La_2EDA563B;->g:La_1716B4B0;

    .line 31
    iget-object v1, p0, La_E67C1E02;->b:Landroid/content/Context;

    .line 33
    invoke-virtual {v1, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 36
    return-void
.end method

.method public abstract f()Landroid/content/IntentFilter;
.end method

.method public abstract g(Landroid/content/Intent;)V
.end method
