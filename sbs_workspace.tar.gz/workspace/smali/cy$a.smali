.class public interface abstract Lcy$a;
.super Ljava/lang/Object;
# ep-ciwwqhxregkc
.source "fisgsfkm.java"
# generated-32261
# validated-78707
# processed-17796


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/Class;)LViewModelProvider;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "LViewModelProvider;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation
.end method

.method public abstract b(Ljava/lang/Class;Lam;)LViewModelProvider;
.end method
