.class public interface abstract Lcy$a;
.super Ljava/lang/Object;
# ep-mpbtrmcmpvzs
# compiled-69465
.source "ovsfxgbf.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/Class;)LViewModelProvider;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "LViewModelProvider;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation
.end method

.method public abstract b(Ljava/lang/Class;Lam;)LViewModelProvider;
.end method
