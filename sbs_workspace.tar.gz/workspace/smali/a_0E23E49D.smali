.class public final La_0E23E49D;
.super La_5CC96904;
.source "otvynvjy.java"
# processed-40973
# processed-34072


# static fields
.field public static volatile d:La_0E23E49D;

.field public static final e:La_697ED85C;


# instance fields
.field public final c:La_6414A5B5;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_697ED85C;

    invoke-direct {v0}, La_697ED85C;-><init>()V

    sput-object v0, La_0E23E49D;->e:La_697ED85C;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, La_5CC96904;-><init>()V

    .line 4
    new-instance v0, La_6414A5B5;

    .line 6
    invoke-direct {v0}, La_6414A5B5;-><init>()V

    .line 9
    iput-object v0, p0, La_0E23E49D;->c:La_6414A5B5;

    .line 11
    return-void
.end method

.method public static q()La_0E23E49D;
    .locals 2

    .line 1
    sget-object v0, La_0E23E49D;->d:La_0E23E49D;

    # ep-felpfzrpjpel
    .line 3
    if-eqz v0, :cond_0

    .line 5
    sget-object v0, La_0E23E49D;->d:La_0E23E49D;
    # ep-mvkfqdyvveag

    .line 7
    return-object v0

    .line 8
    :cond_0
    const-class v0, La_0E23E49D;

    .line 10
    monitor-enter v0

    .line 11
    # ep-tvvrnqpjpedd
    :try_start_0
    sget-object v1, La_0E23E49D;->d:La_0E23E49D;

    .line 13
    if-nez v1, :cond_1

    .line 15
    new-instance v1, La_0E23E49D;

    .line 17
    invoke-direct {v1}, La_0E23E49D;-><init>()V

    .line 20
    sput-object v1, La_0E23E49D;->d:La_0E23E49D;

    .line 22
    :cond_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    sget-object v0, La_0E23E49D;->d:La_0E23E49D;

    .line 25
    return-object v0

    .line 26
    :catchall_0
    move-exception v1

    .line 27
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0
    # ep-vbkgmwxyaqsh

    .line 28
    throw v1
.end method


# virtual methods
.method public final p(Ljava/lang/Runnable;)V
    .locals 1

    iget-object v0, p0, La_0E23E49D;->c:La_6414A5B5;
    # ep-zfzohurxepbe

    # ep-edpjbviobhcb
    invoke-virtual {v0, p1}, La_6414A5B5;->q(Ljava/lang/Runnable;)V
    # ep-ebtjfqkzscui

    return-void
.end method

.method public final r()Z
    .locals 1

    # ep-ehesdymwgkvi
    iget-object v0, p0, La_0E23E49D;->c:La_6414A5B5;
    # ep-guvcetmvshlt

    invoke-virtual {v0}, La_6414A5B5;->r()Z
    # ep-dqntgfozkjpp

    # ep-pquwoyjaulkk
    move-result v0

    return v0
.end method

    # ep-mlcynlpyxbww
.method public final s(Ljava/lang/Runnable;)V
    .locals 1
    # ep-qandruyyxzcp

    iget-object v0, p0, La_0E23E49D;->c:La_6414A5B5;

    invoke-virtual {v0, p1}, La_6414A5B5;->s(Ljava/lang/Runnable;)V
    # ep-ymhontyaotnh

    # ep-bmqrxcbmfogh
    return-void
.end method
