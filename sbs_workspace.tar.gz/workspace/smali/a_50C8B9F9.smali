.class public La_50C8B9F9;
.super La_6F41FBA1;
# ep-zaxcfdnjntdo
.source "mcndqxva.java"

# optimised-27082
# validated-90206
# optimised-47618

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "g"
.end annotation


# instance fields
.field public m:Lii;


# direct methods
.method public constructor <init>(Lwz;Landroid/view/WindowInsets;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, La_6F41FBA1;-><init>(Lwz;Landroid/view/WindowInsets;)V

    .line 4
    const/4 p1, 0x0

    .line 5
    iput-object p1, p0, La_50C8B9F9;->m:Lii;

    .line 7
    return-void
.end method


# virtual methods
.method public b()Lwz;
    .locals 2

    .line 1
    iget-object v0, p0, La_6F41FBA1;->c:Landroid/view/WindowInsets;

    .line 3
    invoke-virtual {v0}, Landroid/view/WindowInsets;->consumeStableInsets()Landroid/view/WindowInsets;

    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-static {v1, v0}, Lwz;->h(Landroid/view/View;Landroid/view/WindowInsets;)Lwz;

    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method

.method public c()Lwz;
    .locals 2

    .line 1
    iget-object v0, p0, La_6F41FBA1;->c:Landroid/view/WindowInsets;

    .line 3
    invoke-virtual {v0}, Landroid/view/WindowInsets;->consumeSystemWindowInsets()Landroid/view/WindowInsets;

    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-static {v1, v0}, Lwz;->h(Landroid/view/View;Landroid/view/WindowInsets;)Lwz;

    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method

.method public final h()Lii;
    .locals 4

    .line 1
    iget-object v0, p0, La_50C8B9F9;->m:Lii;

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, La_6F41FBA1;->c:Landroid/view/WindowInsets;

    .line 7
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetLeft()I

    .line 10
    move-result v1

    .line 11
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetTop()I

    .line 14
    move-result v2

    .line 15
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetRight()I

    .line 18
    move-result v3

    .line 19
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetBottom()I

    .line 22
    move-result v0

    .line 23
    invoke-static {v1, v2, v3, v0}, Lii;->b(IIII)Lii;

    .line 26
    move-result-object v0

    .line 27
    iput-object v0, p0, La_50C8B9F9;->m:Lii;

    .line 29
    :cond_0
    iget-object v0, p0, La_50C8B9F9;->m:Lii;

    .line 31
    return-object v0
.end method

.method public m()Z
    .locals 1

    iget-object v0, p0, La_6F41FBA1;->c:Landroid/view/WindowInsets;

    invoke-virtual {v0}, Landroid/view/WindowInsets;->isConsumed()Z

    move-result v0

    return v0
.end method

.method public q(Lii;)V
    .locals 0

    iput-object p1, p0, La_50C8B9F9;->m:Lii;

    return-void
.end method
