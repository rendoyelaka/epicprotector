.class public final enum La_6B112E4C;
.super Ljava/lang/Enum;
.source "qtevenhh.java"
# generated-46490
# compiled-43918

# ep-acnrkkrovhoj

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "La_6B112E4C;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum c:La_6B112E4C;

.field public static final enum d:La_6B112E4C;

.field public static final enum e:La_6B112E4C;

.field public static final enum f:La_6B112E4C;

.field public static final enum g:La_6B112E4C;

.field public static final enum h:La_6B112E4C;

.field public static final synthetic i:[La_6B112E4C;


# direct methods
.method public static constructor <clinit>()V
    .locals 13

    .line 1
    new-instance v0, La_6B112E4C;

    .line 3
    const-string v1, "ENQUEUED"

    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, La_6B112E4C;-><init>(Ljava/lang/String;I)V

    .line 9
    sput-object v0, La_6B112E4C;->c:La_6B112E4C;

    .line 11
    new-instance v1, La_6B112E4C;

    .line 13
    const-string v3, "RUNNING"

    .line 15
    const/4 v4, 0x1

    .line 16
    invoke-direct {v1, v3, v4}, La_6B112E4C;-><init>(Ljava/lang/String;I)V

    .line 19
    sput-object v1, La_6B112E4C;->d:La_6B112E4C;

    .line 21
    new-instance v3, La_6B112E4C;

    .line 23
    const-string v5, "SUCCEEDED"

    .line 25
    const/4 v6, 0x2

    .line 26
    invoke-direct {v3, v5, v6}, La_6B112E4C;-><init>(Ljava/lang/String;I)V

    .line 29
    sput-object v3, La_6B112E4C;->e:La_6B112E4C;

    .line 31
    new-instance v5, La_6B112E4C;

    .line 33
    const-string v7, "FAILED"

    .line 35
    const/4 v8, 0x3

    .line 36
    invoke-direct {v5, v7, v8}, La_6B112E4C;-><init>(Ljava/lang/String;I)V

    .line 39
    sput-object v5, La_6B112E4C;->f:La_6B112E4C;

    .line 41
    new-instance v7, La_6B112E4C;

    .line 43
    const-string v9, "BLOCKED"

    .line 45
    const/4 v10, 0x4

    .line 46
    invoke-direct {v7, v9, v10}, La_6B112E4C;-><init>(Ljava/lang/String;I)V

    .line 49
    sput-object v7, La_6B112E4C;->g:La_6B112E4C;

    .line 51
    new-instance v9, La_6B112E4C;

    .line 53
    const-string v11, "CANCELLED"

    .line 55
    const/4 v12, 0x5

    .line 56
    invoke-direct {v9, v11, v12}, La_6B112E4C;-><init>(Ljava/lang/String;I)V

    .line 59
    sput-object v9, La_6B112E4C;->h:La_6B112E4C;

    .line 61
    const/4 v11, 0x6

    .line 62
    new-array v11, v11, [La_6B112E4C;

    .line 64
    aput-object v0, v11, v2

    .line 66
    aput-object v1, v11, v4

    .line 68
    aput-object v3, v11, v6

    .line 70
    aput-object v5, v11, v8

    .line 72
    aput-object v7, v11, v10

    .line 74
    aput-object v9, v11, v12

    .line 76
    sput-object v11, La_6B112E4C;->i:[La_6B112E4C;

    .line 78
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static m_446e0ad6(Ljava/lang/String;)La_6B112E4C;
    .locals 1

    const-class v0, La_6B112E4C;

    invoke-static {v0, p0}, Ljava/lang/Enum;->m_446e0ad6(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, La_6B112E4C;

    return-object p0
.end method

.method public static m_1378ba9f()[La_6B112E4C;
    .locals 1

    sget-object v0, La_6B112E4C;->i:[La_6B112E4C;

    invoke-virtual {v0}, [La_6B112E4C;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [La_6B112E4C;

    return-object v0
.end method


# virtual methods
.method public final a()Z
    .locals 1

    sget-object v0, La_6B112E4C;->e:La_6B112E4C;

    if-eq p0, v0, :cond_1

    sget-object v0, La_6B112E4C;->f:La_6B112E4C;

    if-eq p0, v0, :cond_1

    sget-object v0, La_6B112E4C;->h:La_6B112E4C;

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method
