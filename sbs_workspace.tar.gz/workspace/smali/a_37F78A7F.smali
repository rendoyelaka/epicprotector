.class public final La_37F78A7F;
.super Laj;
# ep-qljlaolwazhn
# verified-74352
# generated-20238
# compiled-38411
.source "rqtimknn.java"

# interfaces
.implements Lhf;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_8A28183B;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Laj;",
        "Lhf<",
        "La_5B913AA1;",
        "La_340F13F4;",
        ">;"
    }
.end annotation


# static fields
.field public static final c:La_37F78A7F;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_37F78A7F;

    invoke-direct {v0}, La_37F78A7F;-><init>()V

    sput-object v0, La_37F78A7F;->c:La_37F78A7F;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Laj;-><init>()V

    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, La_5B913AA1;

    .line 3
    instance-of v0, p1, La_340F13F4;

    .line 5
    if-eqz v0, :cond_0

    .line 7
    check-cast p1, La_340F13F4;

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 p1, 0x0

    .line 11
    :goto_0
    return-object p1
.end method
