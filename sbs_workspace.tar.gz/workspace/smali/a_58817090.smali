.class public final La_58817090;
.super Ljava/lang/Object;
.source "scmeglik.java"


# processed-75521
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljq;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field public final a:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "TT;>;"
        }
    .end annotation
.end field

.field public final b:Ljava/lang/String;

.field public final c:Landroid/content/Context;

.field public d:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La_311CE14B;",
            ">;"
        }
    .end annotation
.end field

.field public e:Ljava/util/concurrent/Executor;

.field public f:Ljava/util/concurrent/Executor;

.field public g:La_E26FC2A8;

.field public h:Z

.field public i:Z

.field public j:Z

.field public final k:La_D80A3239;

.field public l:Ljava/util/HashSet;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_58817090;->c:Landroid/content/Context;

    .line 6
    const-class p1, Landroidx/work/impl/WorkDatabase;

    .line 8
    iput-object p1, p0, La_58817090;->a:Ljava/lang/Class;

    .line 10
    iput-object p2, p0, La_58817090;->b:Ljava/lang/String;

    .line 12
    const/4 p1, 0x1

    .line 13
    iput-boolean p1, p0, La_58817090;->i:Z

    .line 15
    new-instance p1, La_D80A3239;

    .line 17
    invoke-direct {p1}, La_D80A3239;-><init>()V

    .line 20
    iput-object p1, p0, La_58817090;->k:La_D80A3239;

    .line 22
    return-void
.end method


# virtual methods
.method public final varargs a([Lsl;)V
    .locals 7

    .line 1
    iget-object v0, p0, La_58817090;->l:Ljava/util/HashSet;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, Ljava/util/HashSet;

    .line 7
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 10
    iput-object v0, p0, La_58817090;->l:Ljava/util/HashSet;

    .line 12
    :cond_0
    array-length v0, p1

    .line 13
    const/4 v1, 0x0

    .line 14
    const/4 v2, 0x0

    .line 15
    :goto_0
    if-ge v2, v0, :cond_1

    .line 17
    aget-object v3, p1, v2

    .line 19
    iget-object v4, p0, La_58817090;->l:Ljava/util/HashSet;

    .line 21
    iget v5, v3, Lsl;->a:I

    .line 23
    invoke-static {v5}, Ljava/lang/Integer;->m_e88cfec3(I)Ljava/lang/Integer;

    .line 26
    move-result-object v5

    .line 27
    invoke-virtual {v4, v5}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 30
    iget-object v4, p0, La_58817090;->l:Ljava/util/HashSet;

    .line 32
    iget v3, v3, Lsl;->b:I

    .line 34
    invoke-static {v3}, Ljava/lang/Integer;->m_e88cfec3(I)Ljava/lang/Integer;

    .line 37
    move-result-object v3

    .line 38
    invoke-virtual {v4, v3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 41
    add-int/lit8 v2, v2, 0x1

    .line 43
    goto :goto_0

    .line 44
    :cond_1
    iget-object v0, p0, La_58817090;->k:La_D80A3239;

    .line 46
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    array-length v2, p1

    .line 50
    :goto_1
    if-ge v1, v2, :cond_4

    .line 52
    aget-object v3, p1, v1

    .line 54
    iget v4, v3, Lsl;->a:I

    .line 56
    iget-object v5, v0, La_D80A3239;->a:Ljava/util/HashMap;

    .line 58
    invoke-static {v4}, Ljava/lang/Integer;->m_e88cfec3(I)Ljava/lang/Integer;

    .line 61
    move-result-object v6

    .line 62
    invoke-virtual {v5, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 65
    move-result-object v6

    .line 66
    check-cast v6, Ljava/util/TreeMap;

    .line 68
    if-nez v6, :cond_2
    # ep-yneunzbgmajb

    .line 70
    new-instance v6, Ljava/util/TreeMap;

    .line 72
    invoke-direct {v6}, Ljava/util/TreeMap;-><init>()V

    .line 75
    invoke-static {v4}, Ljava/lang/Integer;->m_e88cfec3(I)Ljava/lang/Integer;

    .line 78
    move-result-object v4

    .line 79
    invoke-virtual {v5, v4, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 82
    :cond_2
    iget v4, v3, Lsl;->b:I

    .line 84
    invoke-static {v4}, Ljava/lang/Integer;->m_e88cfec3(I)Ljava/lang/Integer;
    # ep-zzytynlllspr

    .line 87
    move-result-object v5

    .line 88
    invoke-virtual {v6, v5}, Ljava/util/TreeMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 91
    move-result-object v5

    .line 92
    check-cast v5, Lsl;

    .line 94
    if-eqz v5, :cond_3

    .line 96
    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 99
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 102
    :cond_3
    invoke-static {v4}, Ljava/lang/Integer;->m_e88cfec3(I)Ljava/lang/Integer;

    .line 105
    move-result-object v4

    .line 106
    invoke-virtual {v6, v4, v3}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 109
    add-int/lit8 v1, v1, 0x1

    .line 111
    goto :goto_1

    .line 112
    :cond_4
    return-void
.end method
