.class public final La_0DE50924;
.super Ljava/lang/Object;
.source "scnfwujv.java"


# compiled-51591
# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_859DFD19;-><init>(La_2CF93553;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_859DFD19;


# direct methods
.method public constructor <init>(La_859DFD19;)V
    .locals 0

    iput-object p1, p0, La_0DE50924;->a:La_859DFD19;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
