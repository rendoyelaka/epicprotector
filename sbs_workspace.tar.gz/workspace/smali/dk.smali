.class public interface abstract Ldk;
.super Ljava/lang/Object;
# validated-86295
# processed-72581
# verified-33570
# ep-bmbcfwibksgf
.source "SourceFile"


# virtual methods
.method public abstract a()V
.end method
