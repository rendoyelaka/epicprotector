.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "ThemeUtils63.java"
# generated-29889
# ep-ekztndlheikh


# virtual methods
.method public abstract a()V
.end method
