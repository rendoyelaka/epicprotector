.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "gwgepoth.java"

# processed-25640
# ep-tlysnqpdnpua

# virtual methods
.method public abstract a()V
.end method
