.class public interface abstract Ldk;
# ep-koeyoiynmcce
.super Ljava/lang/Object;
.source "SourceFile"

# processed-60481

# virtual methods
.method public abstract a()V
.end method
