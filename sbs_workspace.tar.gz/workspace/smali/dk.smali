.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "vozcufjo.java"
# generated-40933
# validated-63993
# ep-ymfputhszteg


# virtual methods
.method public abstract a()V
.end method
