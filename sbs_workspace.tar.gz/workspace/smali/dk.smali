.class public interface abstract Ldk;
# ep-yazepuhgynio
# verified-36211
# verified-58945
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()V
.end method
