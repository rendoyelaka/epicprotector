.class public interface abstract Ldk;
.super Ljava/lang/Object;
# ep-eddhtnmgeyss
.source "SourceFile"

# processed-77343
# compiled-59150
# optimised-60684

# virtual methods
.method public abstract a()V
.end method
