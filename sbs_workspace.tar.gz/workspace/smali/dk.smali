.class public interface abstract Ldk;
# ep-faoranalffnm
.super Ljava/lang/Object;
# validated-47887
# generated-52756
.source "SourceFile"


# virtual methods
.method public abstract a()V
.end method
