.class public interface abstract Ldk;
# ep-iqxpwcydebft
# validated-37332
# processed-51251
# validated-38085
.super Ljava/lang/Object;
.source "trnvgqkl.java"


# virtual methods
.method public abstract a()V
.end method
