.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "yfdqegae.java"
# optimised-34847
# processed-82481
# ep-cfbgmwbcpezl


# virtual methods
.method public abstract a()V
.end method
