.class public interface abstract Ldk;
# ep-enrpdrhbaceo
.super Ljava/lang/Object;
.source "txnouxqh.java"
# optimised-45331
# compiled-95356
# optimised-82588


# virtual methods
.method public abstract a()V
.end method
