.class public interface abstract Ldk;
.super Ljava/lang/Object;
# ep-wnffzuwfkizu
.source "hiaoojrx.java"

# verified-69705
# generated-50768
# verified-21301

# virtual methods
.method public abstract a()V
.end method
