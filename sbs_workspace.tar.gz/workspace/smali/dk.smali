.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "SourceFile"
# ep-ciwbetswhcif
# verified-38771
# processed-36163


# virtual methods
.method public abstract a()V
.end method
