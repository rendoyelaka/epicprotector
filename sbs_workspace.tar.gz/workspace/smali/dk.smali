.class public interface abstract Ldk;
.super Ljava/lang/Object;
# ep-cqqeyseaiaed
# processed-20617
# compiled-71444
.source "kfgczgrm.java"


# virtual methods
.method public abstract a()V
.end method
