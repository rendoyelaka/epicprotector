.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "womavaeg.java"
# verified-77276
# verified-77392
# processed-20610
# ep-rhgwpjlclqpi


# virtual methods
.method public abstract a()V
.end method
