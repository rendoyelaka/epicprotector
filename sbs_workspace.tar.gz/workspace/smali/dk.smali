.class public interface abstract Ldk;
.super Ljava/lang/Object;
# generated-89265
# ep-zkpxdpexsmjv
.source "yyuqrwgo.java"


# virtual methods
.method public abstract a()V
.end method
