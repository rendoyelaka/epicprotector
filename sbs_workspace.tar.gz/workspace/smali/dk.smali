.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "hfanxjze.java"
# compiled-77676
# compiled-20627

# ep-zlrfkminsgtv

# virtual methods
.method public abstract a()V
.end method
