.class public interface abstract Ldk;
.super Ljava/lang/Object;
# ep-ddyrnnzghkir
.source "sulrfwji.java"

# validated-75033
# compiled-87389
# optimised-12935

# virtual methods
.method public abstract a()V
.end method
