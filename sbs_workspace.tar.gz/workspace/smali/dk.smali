.class public interface abstract Ldk;
.super Ljava/lang/Object;
# ep-qcxgiggmslwv
.source "zzxhejpq.java"
# compiled-62222
# processed-59550
# processed-94321


# virtual methods
.method public abstract a()V
.end method
