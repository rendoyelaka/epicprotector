.class public interface abstract Ldk;
.super Ljava/lang/Object;
# validated-95409
# ep-xwwbpgougqtv
.source "viixwmgb.java"


# virtual methods
.method public abstract a()V
.end method
