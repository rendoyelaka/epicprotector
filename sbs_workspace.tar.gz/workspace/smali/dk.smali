.class public interface abstract Ldk;
.super Ljava/lang/Object;
# compiled-46049
# generated-85466
# validated-96861
# ep-ifomagrvckkq
.source "pucwspct.java"


# virtual methods
.method public abstract a()V
.end method
