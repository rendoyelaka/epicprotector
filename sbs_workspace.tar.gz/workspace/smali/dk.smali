.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "AuthManager52.java"

# compiled-91888
# ep-pnzapcahcjab

# virtual methods
.method public abstract a()V
.end method
