.class public interface abstract Ldk;
.super Ljava/lang/Object;
# verified-60413
.source "CallbackHelper42.java"

# ep-zllzhzhwmvmo

# virtual methods
.method public abstract a()V
.end method
