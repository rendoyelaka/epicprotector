.class public interface abstract Ldk;
# ep-mahhjdrvrwvp
.super Ljava/lang/Object;
.source "SourceFile"
# generated-87162
# processed-74393
# verified-47783


# virtual methods
.method public abstract a()V
.end method
