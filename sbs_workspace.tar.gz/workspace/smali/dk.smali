.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "SourceFile"
# ep-onmeblmsbccs

# generated-49990

# virtual methods
.method public abstract a()V
.end method
