.class public interface abstract Ldk;
# ep-xekpbxqohygg
.super Ljava/lang/Object;
.source "SourceFile"
# compiled-46016
# optimised-31589


# virtual methods
.method public abstract a()V
.end method
