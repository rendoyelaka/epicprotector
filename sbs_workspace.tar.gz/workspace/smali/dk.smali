.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "mhayqzkc.java"

# verified-72713
# verified-77231
# processed-60676
# ep-wuxclojxzeim

# virtual methods
.method public abstract a()V
.end method
