.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "SourceFile"

# processed-59160
# validated-36945
# verified-47959
# ep-dodnydpjeoyp

# virtual methods
.method public abstract a()V
.end method
