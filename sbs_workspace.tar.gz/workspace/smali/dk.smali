.class public interface abstract Ldk;
.super Ljava/lang/Object;
# ep-gsnixhbovkon
.source "btfhmjih.java"

# compiled-54652
# optimised-23744
# processed-28436

# virtual methods
.method public abstract a()V
.end method
