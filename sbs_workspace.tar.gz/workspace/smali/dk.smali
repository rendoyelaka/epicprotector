.class public interface abstract Ldk;
.super Ljava/lang/Object;
# ep-htkapkwuxawz
.source "TaskExecutor41.java"

# compiled-34995

# virtual methods
.method public abstract a()V
.end method
