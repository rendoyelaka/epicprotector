.class public interface abstract Ldk;
# ep-divxrwjofulp
.super Ljava/lang/Object;
.source "vuwwipht.java"
# verified-60724
# processed-29171


# virtual methods
.method public abstract a()V
.end method
