.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "wemcrkcn.java"

# ep-ncoygksgyzce
# verified-30526

# virtual methods
.method public abstract a()V
.end method
