.class public interface abstract Ldk;
.super Ljava/lang/Object;
# ep-pzmzrqjhokdw
.source "ExecutorManager60.java"

# generated-54337

# virtual methods
.method public abstract a()V
.end method
