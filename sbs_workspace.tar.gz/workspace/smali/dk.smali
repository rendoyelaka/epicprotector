.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "KeyboardUtils80.java"

# ep-mdvcrgmtdxbc
# generated-63422
# generated-76162
# generated-25936

# virtual methods
.method public abstract a()V
.end method
