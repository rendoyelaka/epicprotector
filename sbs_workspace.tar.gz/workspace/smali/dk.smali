.class public interface abstract Ldk;
# builder-78366-dispatcher
# callback-30139-request
# ep-seijexwpwqtu
.super Ljava/lang/Object;
# compiled-67855
# generated-72058
.source "SettingsClient39.java"


# virtual methods
.method public abstract a()V
.end method
