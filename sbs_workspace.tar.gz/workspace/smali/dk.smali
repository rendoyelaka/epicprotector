.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "gdvkfqrk.java"
# processed-15897
# ep-ohtdnotzpiyn


# virtual methods
.method public abstract a()V
.end method
