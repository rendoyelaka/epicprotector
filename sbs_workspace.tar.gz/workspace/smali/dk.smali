.class public interface abstract Ldk;
# ep-iuihpaloslkf
.super Ljava/lang/Object;
.source "nnggewkc.java"

# optimised-21849
# optimised-14903

# virtual methods
.method public abstract a()V
.end method
