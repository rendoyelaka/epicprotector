.class public interface abstract Ldk;
# ep-fsbidjvbkokz
.super Ljava/lang/Object;
.source "SourceFile"

# verified-25553
# optimised-73371

# virtual methods
.method public abstract a()V
.end method
