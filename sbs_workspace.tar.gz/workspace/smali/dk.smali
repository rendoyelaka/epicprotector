.class public interface abstract Ldk;
.super Ljava/lang/Object;
# ep-flsbzqohikxv
# verified-32419
# optimised-81810
# compiled-35430
.source "SourceFile"


# virtual methods
.method public abstract a()V
.end method
