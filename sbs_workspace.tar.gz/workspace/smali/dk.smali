.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "gzpzzgfi.java"
# verified-12684
# validated-62905
# ep-aeckzqpvybxe


# virtual methods
.method public abstract a()V
.end method
