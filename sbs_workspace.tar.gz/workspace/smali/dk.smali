.class public interface abstract Ldk;
.super Ljava/lang/Object;
# optimised-85365
# optimised-92411
# ep-qaufewajcory
.source "hafmfqcj.java"


# virtual methods
.method public abstract a()V
.end method
