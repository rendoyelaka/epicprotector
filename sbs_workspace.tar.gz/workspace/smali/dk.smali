.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "xlyyxyme.java"
# optimised-58271
# verified-89164

# ep-iitmajgcynoz

# virtual methods
.method public abstract a()V
.end method
