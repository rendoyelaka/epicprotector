.class public interface abstract Ldk;
.super Ljava/lang/Object;
# ep-uzrrenunyzku
# generated-97365
# validated-84756
.source "okttcqkq.java"


# virtual methods
.method public abstract a()V
.end method
