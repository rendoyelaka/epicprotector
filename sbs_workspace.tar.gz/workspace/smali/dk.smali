.class public interface abstract Ldk;
.super Ljava/lang/Object;
# ep-raykmuhajrzm
.source "erxompwy.java"

# compiled-98423
# compiled-87173
# validated-89557

# virtual methods
.method public abstract a()V
.end method
