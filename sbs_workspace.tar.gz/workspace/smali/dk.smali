.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "wdwrviyi.java"

# processed-94968
# ep-viakgklipchl

# virtual methods
.method public abstract a()V
.end method
