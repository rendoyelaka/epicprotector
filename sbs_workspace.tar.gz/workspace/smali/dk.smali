.class public interface abstract Ldk;
.super Ljava/lang/Object;
# ep-mnkqgbtmwdai
.source "rzvktkch.java"
# verified-24240
# generated-28981


# virtual methods
.method public abstract a()V
.end method
