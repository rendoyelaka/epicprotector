.class public interface abstract Ldk;
# ep-abshvhcvdqoi
.super Ljava/lang/Object;
# compiled-49571
.source "keoabrew.java"


# virtual methods
.method public abstract a()V
.end method
