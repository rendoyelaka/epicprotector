.class public interface abstract Ldk;
.super Ljava/lang/Object;
.source "jxhxlumi.java"
# optimised-55566
# verified-44013
# generated-88173
# ep-ojvznvtgoxpq


# virtual methods
.method public abstract a()V
.end method
