.class public final LFragment$b;
.super Ljava/lang/Object;
# validated-12825
# generated-51208
.source "ykjosrkk.java"

# ep-plpczgeggtll

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LFragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public a:Z

.field public b:I

.field public c:I

.field public d:I

.field public e:I

.field public f:I

.field public g:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public h:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final i:Ljava/lang/Object;

.field public final j:Ljava/lang/Object;

.field public final k:Ljava/lang/Object;

.field public l:F

.field public m:Landroid/view/View;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    sget-object v0, LFragment;->S:Ljava/lang/Object;

    .line 6
    iput-object v0, p0, LFragment$b;->i:Ljava/lang/Object;

    .line 8
    iput-object v0, p0, LFragment$b;->j:Ljava/lang/Object;

    .line 10
    iput-object v0, p0, LFragment$b;->k:Ljava/lang/Object;

    .line 12
    const/high16 v0, 0x3f800000    # 1.0f

    .line 14
    iput v0, p0, LFragment$b;->l:F

    .line 16
    const/4 v0, 0x0

    .line 17
    iput-object v0, p0, LFragment$b;->m:Landroid/view/View;

    .line 19
    return-void
.end method
