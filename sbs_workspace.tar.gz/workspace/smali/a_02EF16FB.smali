.class public final La_02EF16FB;
# ep-ezinccceinqj
.super Ljava/lang/Object;
.source "isepkkef.java"

# processed-60740
# compiled-72149
# verified-59477

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
