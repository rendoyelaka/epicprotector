.class public final La_0CE9B999;
# ep-rftkmejjwupg
.super Ljava/lang/Object;
.source "ldkeuemo.java"
# processed-59668

# interfaces
.implements La_33BEBC85;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_44E9DAC8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv8$b<",
        "La_44E9DAC8;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic a:La_0CE9B999;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_0CE9B999;

    invoke-direct {v0}, La_0CE9B999;-><init>()V

    sput-object v0, La_0CE9B999;->a:La_0CE9B999;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
