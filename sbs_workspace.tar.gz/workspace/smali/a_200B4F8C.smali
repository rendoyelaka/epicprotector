.class public interface abstract La_200B4F8C;
# ep-wlaidiogsgmy
.super Ljava/lang/Object;
.source "qabxhkjj.java"

# optimised-53557

# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# virtual methods
.method public abstract onActionViewCollapsed()V
.end method

.method public abstract onActionViewExpanded()V
.end method
