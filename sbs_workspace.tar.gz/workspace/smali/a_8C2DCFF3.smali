.class public final La_8C2DCFF3;
.super Ljava/lang/Object;
# compiled-56041
# ep-azrazdfgpbat
.source "xvmkhbou.java"


# instance fields
.field public final a:Ljava/util/concurrent/CopyOnWriteArraySet;

.field public volatile b:Landroid/content/Context;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 6
    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>()V

    .line 9
    iput-object v0, p0, La_8C2DCFF3;->a:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 11
    return-void
.end method
