.class public final La_2FDF24D2;
.super Ljava/lang/Object;
.source "xtsbirlg.java"
# compiled-55419


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_E0CA2870;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public a:Ljava/net/Socket;

.field public b:Ljava/lang/String;

.field public c:La_5078A648;

.field public d:La_41447F9F;

.field public e:La_13EE40C9;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    sget-object v0, La_13EE40C9;->a:La_6737956A;

    .line 6
    iput-object v0, p0, La_2FDF24D2;->e:La_13EE40C9;

    .line 8
    return-void
.end method
