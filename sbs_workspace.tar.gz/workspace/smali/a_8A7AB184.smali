.class public final La_8A7AB184;
.super La_F5C4F8D6;
.source "vlhjbxbf.java"

# generated-97891
# optimised-43533
# ep-yqixhdkwoazi

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public f_811b1921:Z

.field public f_cd724aed:I

.field public final synthetic f_66dc5c3b:Lly;


# direct methods
.method public constructor <init>(Lly;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_8A7AB184;->f_66dc5c3b:Lly;

    .line 3
    invoke-direct {p0}, La_F5C4F8D6;-><init>()V

    .line 6
    const/4 p1, 0x0

    .line 7
    iput-boolean p1, p0, La_8A7AB184;->f_811b1921:Z

    .line 9
    iput p1, p0, La_8A7AB184;->f_cd724aed:I

    .line 11
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    .line 1
    iget v0, p0, La_8A7AB184;->f_cd724aed:I

    .line 3
    add-int/lit8 v0, v0, 0x1

    .line 5
    iput v0, p0, La_8A7AB184;->f_cd724aed:I

    .line 7
    iget-object v1, p0, La_8A7AB184;->f_66dc5c3b:Lly;

    .line 9
    iget-object v2, v1, Lly;->a:Ljava/util/ArrayList;

    .line 11
    invoke-virtual {v2}, Ljava/util/ArrayList;->m_414f6463()I

    .line 14
    move-result v2

    .line 15
    if-ne v0, v2, :cond_1

    .line 17
    iget-object v0, v1, Lly;->d:Lmy;

    .line 19
    if-eqz v0, :cond_0

    .line 21
    invoke-interface {v0}, Lmy;->a()V

    .line 24
    :cond_0
    const/4 v0, 0x0

    .line 25
    iput v0, p0, La_8A7AB184;->f_cd724aed:I

    .line 27
    iput-boolean v0, p0, La_8A7AB184;->f_811b1921:Z

    .line 29
    iput-boolean v0, v1, Lly;->e:Z

    .line 31
    :cond_1
    return-void
.end method

.method public final c()V
    .locals 1

    .line 1
    iget-boolean v0, p0, La_8A7AB184;->f_811b1921:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, La_8A7AB184;->f_811b1921:Z

    .line 9
    iget-object v0, p0, La_8A7AB184;->f_66dc5c3b:Lly;

    .line 11
    iget-object v0, v0, Lly;->d:Lmy;

    .line 13
    if-eqz v0, :cond_1

    .line 15
    invoke-interface {v0}, Lmy;->c()V

    .line 18
    :cond_1
    return-void
.end method
