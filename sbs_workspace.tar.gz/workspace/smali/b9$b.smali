.class public interface abstract Lb9$b;
# ep-ncdohfxpqctn
.super Ljava/lang/Object;
.source "geydjvcr.java"
# optimised-32055


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
