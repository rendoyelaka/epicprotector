.class public interface abstract Lb9$b;
# ep-pngorxdqavoj
.super Ljava/lang/Object;
# optimised-39704
.source "ecobkeir.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
