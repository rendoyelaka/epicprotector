.class public interface abstract Lb9$b;
.super Ljava/lang/Object;
.source "gfkijxji.java"
# generated-99463
# optimised-41351
# ep-gdpaqtfsbtmw


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
