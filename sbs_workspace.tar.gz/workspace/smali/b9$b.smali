.class public interface abstract Lb9$b;
.super Ljava/lang/Object;
.source "dxrifave.java"
# ep-yfxpnhpqnuiu

# optimised-31207
# compiled-62958
# generated-81502

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
