.class public interface abstract Lb9$b;
.super Ljava/lang/Object;
.source "facjmdyd.java"
# validated-77400
# verified-31687
# verified-54855
# ep-ydjccyjrlsnf


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
