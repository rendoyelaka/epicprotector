.class public interface abstract Lb9$b;
.super Ljava/lang/Object;
# ep-qcewhcgeaceq
.source "vawcxyjz.java"

# generated-88772
# validated-96404
# verified-24851

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
