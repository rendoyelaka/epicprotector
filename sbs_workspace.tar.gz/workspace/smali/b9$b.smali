.class public interface abstract Lb9$b;
.super Ljava/lang/Object;
# ep-ufpihajudwfy
# validated-28319
# compiled-82057
# validated-70523
.source "JsonManager81.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
