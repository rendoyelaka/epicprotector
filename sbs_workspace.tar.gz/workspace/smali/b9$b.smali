.class public interface abstract Lb9$b;
.super Ljava/lang/Object;
.source "odzpiaxi.java"
# ep-simsorrcedzt
# generated-66639
# verified-82801
# generated-67086


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
