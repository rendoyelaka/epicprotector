.class public final La_48138AA2;
.super Lia;
.source "yzhvyqyr.java"

# compiled-32433
# optimised-46471

# direct methods
.method public constructor <init>(Loz;)V
    .locals 0

    invoke-direct {p0, p1}, Lia;-><init>(Loz;)V

    return-void
.end method
