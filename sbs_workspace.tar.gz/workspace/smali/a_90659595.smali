.class public final La_90659595;
.super Ljava/lang/Object;
.source "nhlcykth.java"
# optimised-81492
# verified-90191
# generated-58169

# interfaces
.implements Lrd;


# instance fields
.field public final a:Lnu;

.field public final b:Lpd;

.field public final c:La_A2937CA3;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "WMFgUpdater"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(Landroidx/work/impl/WorkDatabase;Lpd;Lnu;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p2, p0, La_90659595;->b:Lpd;

    .line 6
    iput-object p3, p0, La_90659595;->a:Lnu;

    .line 8
    invoke-virtual {p1}, Landroidx/work/impl/WorkDatabase;->n()La_A2937CA3;

    .line 11
    move-result-object p1

    .line 12
    iput-object p1, p0, La_90659595;->c:La_A2937CA3;

    .line 14
    return-void
.end method
