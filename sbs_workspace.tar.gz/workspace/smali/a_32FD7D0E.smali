.class public final La_32FD7D0E;
# ep-goauetoziukl
# generated-27971
# verified-69484
.super Ljava/lang/Object;
.source "qvhqukex.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwu;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public static a(Landroid/widget/TextView;)I
    .locals 0

    invoke-static {p0}, La_F79784E5;->d(Landroid/widget/TextView;)I

    move-result p0

    return p0
.end method

.method public static b(Landroid/widget/TextView;)Landroid/content/res/ColorStateList;
    .locals 0

    invoke-static {p0}, Lqh;->e(Landroid/widget/TextView;)Landroid/content/res/ColorStateList;

    move-result-object p0

    return-object p0
.end method

.method public static c(Landroid/widget/TextView;)Landroid/graphics/PorterDuff$Mode;
    .locals 0

    invoke-static {p0}, Lqh;->f(Landroid/widget/TextView;)Landroid/graphics/PorterDuff$Mode;

    move-result-object p0

    return-object p0
.end method

.method public static d(Landroid/widget/TextView;)I
    .locals 0

    invoke-static {p0}, La_F79784E5;->m_61732c05(Landroid/widget/TextView;)I

    move-result p0

    return p0
.end method

.method public static e(Landroid/widget/TextView;I)V
    .locals 0

    invoke-static {p0, p1}, Lqh;->m_77d067b2(Landroid/widget/TextView;I)V

    return-void
.end method

.method public static f(Landroid/widget/TextView;Landroid/content/res/ColorStateList;)V
    .locals 0

    invoke-static {p0, p1}, Lqh;->x(Landroid/widget/TextView;Landroid/content/res/ColorStateList;)V

    return-void
.end method

.method public static g(Landroid/widget/TextView;Landroid/graphics/PorterDuff$Mode;)V
    .locals 0

    invoke-static {p0, p1}, Lqh;->y(Landroid/widget/TextView;Landroid/graphics/PorterDuff$Mode;)V

    return-void
.end method

.method public static h(Landroid/widget/TextView;I)V
    .locals 0

    invoke-static {p0, p1}, Lqh;->m_8461ad83(Landroid/widget/TextView;I)V

    return-void
.end method
