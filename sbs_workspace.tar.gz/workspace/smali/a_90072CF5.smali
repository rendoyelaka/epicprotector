.class public final La_90072CF5;
# ep-azdefmqktloh
# optimised-88111
.super La_6B590370;
.source "fkwjocat.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_A28F0D46;,
        La_0BD59318;,
        La_323F4791;,
        La_7637FD10;
    }
.end annotation


# static fields
.field public static final synthetic b:I


# direct methods
.method public static d(Landroid/app/Activity;[Ljava/lang/String;)V
    .locals 3

    .line 1
    array-length v0, p1

    .line 2
    const/4 v1, 0x0

    .line 3
    :goto_0
    if-ge v1, v0, :cond_1

    .line 5
    aget-object v2, p1, v1

    .line 7
    invoke-static {v2}, Landroid/text/TextUtils;->m_2bd5aeca(Ljava/lang/CharSequence;)Z

    .line 10
    move-result v2

    .line 11
    if-nez v2, :cond_0

    .line 13
    add-int/lit8 v1, v1, 0x1

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 18
    new-instance v0, Ljava/lang/StringBuilder;

    .line 20
    const-string v1, "Permission request for permissions "

    .line 22
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 25
    invoke-static {p1}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    .line 28
    move-result-object p1

    .line 29
    const-string v1, " must not contain null or empty values"

    .line 31
    invoke-static {v0, p1, v1}, Lps;->e(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 34
    move-result-object p1

    .line 35
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 38
    throw p0

    .line 39
    :cond_1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 41
    const/16 v1, 0x17

    .line 43
    if-lt v0, v1, :cond_3

    .line 45
    instance-of v0, p0, La_323F4791;

    .line 47
    if-eqz v0, :cond_2

    .line 49
    move-object v0, p0

    .line 50
    check-cast v0, La_323F4791;

    .line 52
    invoke-interface {v0}, La_323F4791;->f()V

    .line 55
    :cond_2
    const/16 v0, 0x7b

    .line 57
    invoke-static {p0, p1, v0}, La_A28F0D46;->b(Landroid/app/Activity;[Ljava/lang/String;I)V

    .line 60
    goto :goto_1

    .line 61
    :cond_3
    instance-of v0, p0, La_7637FD10;

    .line 63
    if-eqz v0, :cond_4

    .line 65
    new-instance v0, Landroid/os/Handler;

    .line 67
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 70
    move-result-object v1

    .line 71
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 74
    new-instance v1, La_8C5E251D;

    .line 76
    invoke-direct {v1, p0, p1}, La_8C5E251D;-><init>(Landroid/app/Activity;[Ljava/lang/String;)V

    .line 79
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 82
    :cond_4
    :goto_1
    return-void
.end method
