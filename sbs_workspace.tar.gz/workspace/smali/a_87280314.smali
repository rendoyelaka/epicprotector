.class public final synthetic La_87280314;
.super Ljava/lang/Object;
# compiled-71463
.source "iweaauuf.java"

# ep-jysifmybmfbp
# interfaces
.implements Lio/socket/emitter/Emitter$Listener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:La_9AA212C0;


# direct methods
.method public synthetic constructor <init>(La_9AA212C0;I)V
    .locals 0

    iput p2, p0, La_87280314;->a:I

    iput-object p1, p0, La_87280314;->b:La_9AA212C0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final call([Ljava/lang/Object;)V
    .locals 3

    .line 1
    iget v0, p0, La_87280314;->a:I

    .line 3
    iget-object v1, p0, La_87280314;->b:La_9AA212C0;

    .line 5
    const/4 v2, 0x0

    .line 6
    packed-switch v0, :pswitch_data_0

    .line 9
    goto :goto_0

    .line 10
    :pswitch_0
    iput-boolean v2, v1, La_9AA212C0;->c:Z

    .line 12
    return-void

    .line 13
    :pswitch_1
    iput-boolean v2, v1, La_9AA212C0;->c:Z

    .line 15
    invoke-virtual {v1}, La_9AA212C0;->d()V

    .line 18
    return-void

    .line 19
    :goto_0
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    :try_start_0
    aget-object p1, p1, v2

    .line 24
    check-cast p1, Lorg/json/JSONObject;

    .line 26
    iget-object v0, v1, La_9AA212C0;->e:Ljava/util/LinkedList;

    .line 28
    invoke-virtual {v0, p1}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z

    .line 31
    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 34
    invoke-virtual {v1}, La_9AA212C0;->d()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 37
    :catch_0
    return-void

    .line 38
    nop

    .line 39
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
