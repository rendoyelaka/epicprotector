.class public final Lc5;
.super Ljava/lang/Object;
# ep-fzfkhrreoqtw
# optimised-45807
# optimised-63632
# compiled-64188
.source "cpqctovf.java"

# interfaces
.implements Loi;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static b(Ljava/lang/String;)Z
    .locals 1

    .line 1
    const-string v0, "Connection"

    .line 3
    invoke-virtual {v0, p0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 9
    const-string v0, "Keep-Alive"

    .line 11
    invoke-virtual {v0, p0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_0

    .line 17
    const-string v0, "Proxy-Authenticate"

    .line 19
    invoke-virtual {v0, p0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_0

    .line 25
    const-string v0, "Proxy-Authorization"

    .line 27
    invoke-virtual {v0, p0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_0

    .line 33
    const-string v0, "TE"

    .line 35
    invoke-virtual {v0, p0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 38
    move-result v0

    .line 39
    if-nez v0, :cond_0

    .line 41
    const-string v0, "Trailers"

    .line 43
    invoke-virtual {v0, p0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 46
    move-result v0

    .line 47
    if-nez v0, :cond_0

    .line 49
    const-string v0, "Transfer-Encoding"

    .line 51
    invoke-virtual {v0, p0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 54
    move-result v0

    .line 55
    if-nez v0, :cond_0

    .line 57
    const-string v0, "Upgrade"

    .line 59
    invoke-virtual {v0, p0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 62
    move-result p0

    .line 63
    if-nez p0, :cond_0

    .line 65
    const/4 p0, 0x1

    .line 66
    goto :goto_0

    .line 67
    :cond_0
    const/4 p0, 0x0

    .line 68
    :goto_0
    return p0
.end method

.method public static c(LOkHttpResponse;)LOkHttpResponse;
    .locals 1

    .line 1
    if-eqz p0, :cond_0

    .line 3
    iget-object v0, p0, LOkHttpResponse;->i:Ldq;

    .line 5
    if-eqz v0, :cond_0

    .line 7
    new-instance v0, LOkHttpResponse$a;

    .line 9
    invoke-direct {v0, p0}, LOkHttpResponse$a;-><init>(LOkHttpResponse;)V

    .line 12
    const/4 p0, 0x0

    .line 13
    iput-object p0, v0, LOkHttpResponse$a;->g:Ldq;

    .line 15
    invoke-virtual {v0}, LOkHttpResponse$a;->a()LOkHttpResponse;

    .line 18
    move-result-object p0

    .line 19
    :cond_0
    return-object p0
.end method


# virtual methods
.method public final a(Lfp;)LOkHttpResponse;
    .locals 14

    .line 1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 4
    iget-object v0, p1, Lfp;->f:Lnp;

    .line 6
    new-instance v1, Ld5;

    .line 8
    const/4 v2, 0x0

    .line 9
    invoke-direct {v1, v0, v2}, Ld5;-><init>(Lnp;LOkHttpResponse;)V

    .line 12
    if-eqz v0, :cond_1

    .line 14
    iget-object v3, v0, Lnp;->e:Lb5;

    .line 16
    if-eqz v3, :cond_0

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    iget-object v3, v0, Lnp;->c:Ljg;

    .line 21
    invoke-static {v3}, Lb5;->a(Ljg;)Lb5;

    .line 24
    move-result-object v3

    .line 25
    iput-object v3, v0, Lnp;->e:Lb5;

    .line 27
    :goto_0
    iget-boolean v0, v3, Lb5;->j:Z

    .line 29
    if-eqz v0, :cond_1

    .line 31
    new-instance v1, Ld5;

    .line 33
    invoke-direct {v1, v2, v2}, Ld5;-><init>(Lnp;LOkHttpResponse;)V

    .line 36
    :cond_1
    iget-object v0, v1, Ld5;->a:Lnp;

    .line 38
    iget-object v1, v1, Ld5;->b:LOkHttpResponse;

    .line 40
    if-nez v0, :cond_2

    .line 42
    if-nez v1, :cond_2

    .line 44
    new-instance v0, LOkHttpResponse$a;

    .line 46
    invoke-direct {v0}, LOkHttpResponse$a;-><init>()V

    .line 49
    iget-object p1, p1, Lfp;->f:Lnp;

    .line 51
    iput-object p1, v0, LOkHttpResponse$a;->a:Lnp;

    .line 53
    sget-object p1, Lvo;->e:Lvo;

    .line 55
    iput-object p1, v0, LOkHttpResponse$a;->b:Lvo;

    .line 57
    const/16 p1, 0x1f8

    .line 59
    iput p1, v0, LOkHttpResponse$a;->c:I

    .line 61
    const-string p1, "Unsatisfiable Request (only-if-cached)"

    .line 63
    iput-object p1, v0, LOkHttpResponse$a;->d:Ljava/lang/String;

    .line 65
    sget-object p1, Lex;->c:Lcq;

    .line 67
    iput-object p1, v0, LOkHttpResponse$a;->g:Ldq;

    .line 69
    const-wide/16 v1, -0x1

    .line 71
    iput-wide v1, v0, LOkHttpResponse$a;->k:J

    .line 73
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 76
    move-result-wide v1

    .line 77
    iput-wide v1, v0, LOkHttpResponse$a;->l:J

    .line 79
    invoke-virtual {v0}, LOkHttpResponse$a;->a()LOkHttpResponse;

    .line 82
    move-result-object p1

    .line 83
    return-object p1

    .line 84
    :cond_2
    const-string v3, "cacheResponse"

    .line 86
    if-nez v0, :cond_4

    .line 88
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 91
    new-instance p1, LOkHttpResponse$a;

    .line 93
    invoke-direct {p1, v1}, LOkHttpResponse$a;-><init>(LOkHttpResponse;)V

    .line 96
    invoke-static {v1}, Lc5;->c(LOkHttpResponse;)LOkHttpResponse;

    .line 99
    move-result-object v0

    .line 100
    if-eqz v0, :cond_3

    .line 102
    invoke-static {v3, v0}, LOkHttpResponse$a;->b(Ljava/lang/String;LOkHttpResponse;)V

    .line 105
    :cond_3
    iput-object v0, p1, LOkHttpResponse$a;->i:LOkHttpResponse;

    .line 107
    invoke-virtual {p1}, LOkHttpResponse$a;->a()LOkHttpResponse;

    .line 110
    move-result-object p1

    .line 111
    return-object p1

    .line 112
    :cond_4
    :try_start_0
    iget-object v4, p1, Lfp;->c:Lfh;

    .line 114
    iget-object v5, p1, Lfp;->d:Lo7;

    .line 116
    iget-object v6, p1, Lfp;->b:Lft;

    .line 118
    invoke-virtual {p1, v0, v6, v4, v5}, Lfp;->a(Lnp;Lft;Lfh;Lo7;)LOkHttpResponse;

    .line 121
    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 122
    const-string v0, "networkResponse"

    .line 124
    if-eqz v1, :cond_f

    .line 126
    iget v4, p1, LOkHttpResponse;->e:I

    .line 128
    const/16 v5, 0x130

    .line 130
    if-ne v4, v5, :cond_e

    .line 132
    new-instance v4, LOkHttpResponse$a;

    .line 134
    invoke-direct {v4, v1}, LOkHttpResponse$a;-><init>(LOkHttpResponse;)V

    .line 137
    new-instance v5, Ljava/util/ArrayList;

    .line 139
    const/16 v6, 0x14

    .line 141
    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(I)V

    .line 144
    iget-object v6, v1, LOkHttpResponse;->h:Ljg;

    .line 146
    iget-object v7, v6, Ljg;->a:[Ljava/lang/String;

    .line 148
    array-length v7, v7

    .line 149
    div-int/lit8 v7, v7, 0x2

    .line 151
    const/4 v8, 0x0

    .line 152
    const/4 v9, 0x0

    .line 153
    :goto_1
    iget-object v10, p1, LOkHttpResponse;->h:Ljg;

    .line 155
    if-ge v9, v7, :cond_8

    .line 157
    invoke-virtual {v6, v9}, Ljg;->b(I)Ljava/lang/String;

    .line 160
    move-result-object v11

    .line 161
    invoke-virtual {v6, v9}, Ljg;->d(I)Ljava/lang/String;

    .line 164
    move-result-object v12

    .line 165
    const-string v13, "Warning"

    .line 167
    invoke-virtual {v13, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 170
    move-result v13

    .line 171
    if-eqz v13, :cond_5

    .line 173
    const-string v13, "1"

    .line 175
    invoke-virtual {v12, v13}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 178
    move-result v13

    .line 179
    if-eqz v13, :cond_5

    .line 181
    goto :goto_2

    .line 182
    :cond_5
    invoke-static {v11}, Lc5;->b(Ljava/lang/String;)Z

    .line 185
    move-result v13

    .line 186
    if-eqz v13, :cond_6

    .line 188
    invoke-virtual {v10, v11}, Ljg;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 191
    move-result-object v10

    .line 192
    if-nez v10, :cond_7

    .line 194
    :cond_6
    sget-object v10, Lpi;->a:Lan$a;

    .line 196
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 199
    invoke-virtual {v5, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 202
    invoke-virtual {v12}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 205
    move-result-object v10

    .line 206
    invoke-virtual {v5, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 209
    :cond_7
    :goto_2
    add-int/lit8 v9, v9, 0x1

    .line 211
    goto :goto_1

    .line 212
    :cond_8
    iget-object v6, v10, Ljg;->a:[Ljava/lang/String;

    .line 214
    array-length v6, v6

    .line 215
    div-int/lit8 v6, v6, 0x2

    .line 217
    :goto_3
    if-ge v8, v6, :cond_b

    .line 219
    invoke-virtual {v10, v8}, Ljg;->b(I)Ljava/lang/String;

    .line 222
    move-result-object v7

    .line 223
    const-string v9, "Content-Length"

    .line 225
    invoke-virtual {v9, v7}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 228
    move-result v9

    .line 229
    if-eqz v9, :cond_9

    .line 231
    goto :goto_4

    .line 232
    :cond_9
    invoke-static {v7}, Lc5;->b(Ljava/lang/String;)Z

    .line 235
    move-result v9

    .line 236
    if-eqz v9, :cond_a

    .line 238
    sget-object v9, Lpi;->a:Lan$a;

    .line 240
    invoke-virtual {v10, v8}, Ljg;->d(I)Ljava/lang/String;

    .line 243
    move-result-object v11

    .line 244
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 247
    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 250
    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 253
    move-result-object v7

    .line 254
    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 257
    :cond_a
    :goto_4
    add-int/lit8 v8, v8, 0x1

    .line 259
    goto :goto_3

    .line 260
    :cond_b
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 263
    move-result v6

    .line 264
    new-array v6, v6, [Ljava/lang/String;

    .line 266
    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 269
    move-result-object v5

    .line 270
    check-cast v5, [Ljava/lang/String;

    .line 272
    new-instance v6, Ljg$a;

    .line 274
    invoke-direct {v6}, Ljg$a;-><init>()V

    .line 277
    iget-object v7, v6, Ljg$a;->a:Ljava/util/ArrayList;

    .line 279
    invoke-static {v7, v5}, Ljava/util/Collections;->addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z

    .line 282
    iput-object v6, v4, LOkHttpResponse$a;->f:Ljg$a;

    .line 284
    iget-wide v5, p1, LOkHttpResponse;->m:J

    .line 286
    iput-wide v5, v4, LOkHttpResponse$a;->k:J

    .line 288
    iget-wide v5, p1, LOkHttpResponse;->n:J

    .line 290
    iput-wide v5, v4, LOkHttpResponse$a;->l:J

    .line 292
    invoke-static {v1}, Lc5;->c(LOkHttpResponse;)LOkHttpResponse;

    .line 295
    move-result-object v1

    .line 296
    if-eqz v1, :cond_c

    .line 298
    invoke-static {v3, v1}, LOkHttpResponse$a;->b(Ljava/lang/String;LOkHttpResponse;)V

    .line 301
    :cond_c
    iput-object v1, v4, LOkHttpResponse$a;->i:LOkHttpResponse;

    .line 303
    invoke-static {p1}, Lc5;->c(LOkHttpResponse;)LOkHttpResponse;

    .line 306
    move-result-object v1

    .line 307
    if-eqz v1, :cond_d

    .line 309
    invoke-static {v0, v1}, LOkHttpResponse$a;->b(Ljava/lang/String;LOkHttpResponse;)V

    .line 312
    :cond_d
    iput-object v1, v4, LOkHttpResponse$a;->h:LOkHttpResponse;

    .line 314
    invoke-virtual {v4}, LOkHttpResponse$a;->a()LOkHttpResponse;

    .line 317
    iget-object p1, p1, LOkHttpResponse;->i:Ldq;

    .line 319
    invoke-virtual {p1}, Ldq;->close()V

    .line 322
    throw v2

    .line 323
    :cond_e
    iget-object v2, v1, LOkHttpResponse;->i:Ldq;

    .line 325
    invoke-static {v2}, Lex;->a(Ljava/io/Closeable;)V

    .line 328
    :cond_f
    new-instance v2, LOkHttpResponse$a;

    .line 330
    invoke-direct {v2, p1}, LOkHttpResponse$a;-><init>(LOkHttpResponse;)V

    .line 333
    invoke-static {v1}, Lc5;->c(LOkHttpResponse;)LOkHttpResponse;

    .line 336
    move-result-object v1

    .line 337
    if-eqz v1, :cond_10

    .line 339
    invoke-static {v3, v1}, LOkHttpResponse$a;->b(Ljava/lang/String;LOkHttpResponse;)V

    .line 342
    :cond_10
    iput-object v1, v2, LOkHttpResponse$a;->i:LOkHttpResponse;

    .line 344
    invoke-static {p1}, Lc5;->c(LOkHttpResponse;)LOkHttpResponse;

    .line 347
    move-result-object p1

    .line 348
    if-eqz p1, :cond_11

    .line 350
    invoke-static {v0, p1}, LOkHttpResponse$a;->b(Ljava/lang/String;LOkHttpResponse;)V

    .line 353
    :cond_11
    iput-object p1, v2, LOkHttpResponse$a;->h:LOkHttpResponse;

    .line 355
    invoke-virtual {v2}, LOkHttpResponse$a;->a()LOkHttpResponse;

    .line 358
    move-result-object p1

    .line 359
    invoke-static {p1}, Lhh;->b(LOkHttpResponse;)Z

    .line 362
    return-object p1

    .line 363
    :catchall_0
    move-exception p1

    .line 364
    throw p1
.end method
