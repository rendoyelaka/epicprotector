.class public final La_2DF70AEF;
# ep-tusmekhnxman
.super La_C8019479;
# verified-39050
.source "dcpdserp.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_C8019479;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_C8019479;-><init>()V

    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 1

    const-string v0, "SUCCESS"

    return-object v0
.end method
