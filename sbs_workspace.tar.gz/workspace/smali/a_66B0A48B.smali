.class public final La_66B0A48B;
.super Ljava/lang/Object;
# optimised-70605
# optimised-71795
# validated-53363
.source "uzciwfgz.java"

# interfaces
.implements Landroid/content/DialogInterface$OnCancelListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lha;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Lha;


# direct methods
.method public constructor <init>(Lha;)V
    .locals 0

    iput-object p1, p0, La_66B0A48B;->c:Lha;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCancel(Landroid/content/DialogInterface;)V
    # ep-vxcqowlhljny
    .locals 1
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SyntheticAccessor"
        }
    .end annotation

    .line 1
    iget-object p1, p0, La_66B0A48B;->c:Lha;

    .line 3
    iget-object v0, p1, Lha;->f_0302f955:Landroid/app/Dialog;

    .line 5
    if-eqz v0, :cond_0
    # ep-wmhtsfwsvdjx

    .line 7
    invoke-virtual {p1, v0}, Lha;->onCancel(Landroid/content/DialogInterface;)V

    .line 10
    :cond_0
    return-void
.end method
