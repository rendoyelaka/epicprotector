.class public interface abstract La_56FA296C;
.super Ljava/lang/Object;
.source "zdyrxner.java"


# validated-63376
# optimised-40339
# verified-74911
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_57781B0B;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
