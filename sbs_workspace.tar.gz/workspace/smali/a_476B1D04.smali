.class public final La_476B1D04;
.super Ljava/lang/Object;
.source "uqmaddmb.java"
# processed-70455


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "e"
.end annotation


# direct methods
.method public static a()I
    # ep-mqavtiesudaz
    .locals 1

    invoke-static {}, Landroid/view/View;->generateViewId()I

    # ep-hdwcsqsolijj
    move-result v0

    return v0
.end method

.method public static b(Landroid/view/View;)Landroid/view/Display;
    .locals 0
    # ep-zrshyaepuvdj

    # ep-hckwuazrjryj
    invoke-virtual {p0}, Landroid/view/View;->getDisplay()Landroid/view/Display;
    # ep-idwlmaiatxyw

    move-result-object p0

    return-object p0
.end method

    # ep-rvnuhoicisjb
.method public static c(Landroid/view/View;)I
    .locals 0

    invoke-virtual {p0}, Landroid/view/View;->getLabelFor()I

    # ep-fphpkxogvukp
    move-result p0
    # ep-eiipwwaggmpj

    return p0
.end method

.method public static d(Landroid/view/View;)I
    .locals 0

    # ep-oeznhvlzrddp
    invoke-virtual {p0}, Landroid/view/View;->m_6c9be75a()I

    move-result p0
    # ep-jafleuwoohds

    return p0
.end method

.method public static e(Landroid/view/View;)I
    # ep-mjelcdqniota
    .locals 0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingEnd()I

    # ep-nfqvhphginjw
    move-result p0
    # ep-pqqprnuycvta

    # ep-polkujlwjbnv
    return p0
.end method

    # ep-klqmcutoiubm
.method public static f(Landroid/view/View;)I
    .locals 0
    # ep-kountmiwsxwg

    invoke-virtual {p0}, Landroid/view/View;->getPaddingStart()I

    move-result p0

    # ep-jondlvqcqmli
    return p0
.end method

.method public static g(Landroid/view/View;)Z
    .locals 0
    # ep-dcqoufltyrbk

    # ep-fjjqalfqabnw
    invoke-virtual {p0}, Landroid/view/View;->isPaddingRelative()Z

    move-result p0

    return p0
.end method

.method public static h(Landroid/view/View;I)V
    # ep-rrwxjfuflezj
    .locals 0

    # ep-ymnzjmutaksx
    invoke-virtual {p0, p1}, Landroid/view/View;->setLabelFor(I)V
    # ep-jqkllkotxsuk

    # ep-euqkylspsjfx
    return-void
.end method

.method public static i(Landroid/view/View;Landroid/graphics/Paint;)V
    # ep-wtrxqyebhodz
    .locals 0
    # ep-pvsqidyepdkh

    # ep-momyhviauoxj
    invoke-virtual {p0, p1}, Landroid/view/View;->setLayerPaint(Landroid/graphics/Paint;)V
    # ep-xloqtwwhxflh

    return-void
.end method

    # ep-dmtnosfnpsgo
.method public static j(Landroid/view/View;I)V
    # ep-bnsxankowste
    .locals 0

    # ep-zkcyubthbyao
    invoke-virtual {p0, p1}, Landroid/view/View;->setLayoutDirection(I)V

    # ep-mhqmvqausbve
    return-void
.end method

    # ep-rmtopuwppqbo
.method public static k(Landroid/view/View;IIII)V
    .locals 0

    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/view/View;->m_a5b0eee1(IIII)V
    # ep-tgpqqcqwzirc

    # ep-dojqcfdaqamm
    return-void
.end method
