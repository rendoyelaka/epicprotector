.class public final La_33A2C74A;
.super La_3DDFDA47;
# compiled-58393
# verified-57148
.source "jdgwfaha.java"
# ep-mqbmkjyehbky


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lx7<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Landroid/content/Context;Lnu;)V
    .locals 0

    .line 1
    invoke-static {p1, p2}, Lxv;->a(Landroid/content/Context;Lnu;)Lxv;

    .line 4
    move-result-object p1

    .line 5
    iget-object p1, p1, Lxv;->b:La_16C5AD09;

    .line 7
    invoke-direct {p0, p1}, La_3DDFDA47;-><init>(La_08E533F6;)V

    .line 10
    return-void
.end method


# virtual methods
.method public final b(La_AA524E44;)Z
    .locals 0

    .line 1
    iget-object p1, p1, La_AA524E44;->j:La_DB594D1B;

    .line 3
    iget-boolean p1, p1, La_DB594D1B;->d:Z

    .line 5
    return p1
.end method

.method public final c(Ljava/lang/Object;)Z
    .locals 0

    .line 1
    check-cast p1, Ljava/lang/Boolean;

    .line 3
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 6
    move-result p1

    .line 7
    xor-int/lit8 p1, p1, 0x1

    .line 9
    return p1
.end method
