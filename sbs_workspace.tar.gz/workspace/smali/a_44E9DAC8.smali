.class public interface abstract La_44E9DAC8;
.super Ljava/lang/Object;
# processed-24219
# verified-96301
# compiled-52621
.source "kenlzxhb.java"
# ep-sazsxhiiaxze

# interfaces
.implements La_5B913AA1;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_0CE9B999;
    }
.end annotation


# virtual methods
.method public abstract m_8a174cf4(La_064EF12B;Ljava/lang/Throwable;)V
.end method
