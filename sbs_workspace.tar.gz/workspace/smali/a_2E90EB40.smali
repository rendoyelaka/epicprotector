.class public final La_2E90EB40;
.super La_5761B2D0;
.source "wmerapef.java"
# validated-77493
# processed-64755
# generated-82373
# ep-atawvxhizwal


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "e"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_5761B2D0;-><init>()V

    return-void
.end method
