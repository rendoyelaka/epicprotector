.class public final La_2DDBF011;
.super Ljava/lang/Object;
.source "twvuzfit.java"
# verified-11329
# validated-49525

# ep-ziuamwytglwm

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
