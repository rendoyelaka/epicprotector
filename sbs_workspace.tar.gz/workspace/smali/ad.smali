.class public Lad;
.super Landroid/view/ViewGroup;
.source "SourceFile"
# validated-50890
# ep-ahbnfgkckvnu


# instance fields
.field public c:I

.field public d:I

.field public e:Z

.field public f:I


# virtual methods
.method public a()Z
    .locals 1

    iget-boolean v0, p0, Lad;->e:Z

    return v0
.end method

.method public getItemSpacing()I
    .locals 1

    iget v0, p0, Lad;->d:I

    return v0
.end method

.method public getLineSpacing()I
    .locals 1

    iget v0, p0, Lad;->c:I

    return v0
.end method

.method public getRowCount()I
    .locals 1

    iget v0, p0, Lad;->f:I

    return v0
.end method

.method public final onLayout(ZIIII)V
    .locals 10

    .line 1
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 4
    move-result p1

    .line 5
    const/4 p3, 0x0

    .line 6
    if-nez p1, :cond_0

    .line 8
    iput p3, p0, Lad;->f:I

    .line 10
    return-void

    .line 11
    :cond_0
    const/4 p1, 0x1

    .line 12
    iput p1, p0, Lad;->f:I

    .line 14
    sget-object p5, Lqx;->a:Ljava/util/WeakHashMap;

    .line 16
    invoke-static {p0}, Lqx$e;->d(Landroid/view/View;)I

    .line 19
    move-result p5

    .line 20
    if-ne p5, p1, :cond_1

    .line 22
    const/4 p5, 0x1

    .line 23
    goto :goto_0

    .line 24
    :cond_1
    const/4 p5, 0x0

    .line 25
    :goto_0
    if-eqz p5, :cond_2

    .line 27
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 30
    move-result v0

    .line 31
    goto :goto_1

    .line 32
    :cond_2
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 35
    move-result v0

    .line 36
    :goto_1
    if-eqz p5, :cond_3

    .line 38
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 41
    move-result v1

    .line 42
    goto :goto_2

    .line 43
    :cond_3
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 46
    move-result v1

    .line 47
    :goto_2
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 50
    move-result v2

    .line 51
    sub-int/2addr p4, p2

    .line 52
    sub-int/2addr p4, v1

    .line 53
    move v3, v0

    .line 54
    move p2, v2

    .line 55
    const/4 v1, 0x0

    .line 56
    :goto_3
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 59
    move-result v4

    .line 60
    if-ge v1, v4, :cond_8

    .line 62
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 65
    move-result-object v4

    .line 66
    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    .line 69
    move-result v5

    .line 70
    const/16 v6, 0x8

    .line 72
    const v7, 0x7f090165

    .line 75
    if-ne v5, v6, :cond_4

    .line 77
    const/4 v5, -0x1

    .line 78
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 81
    move-result-object v5

    .line 82
    invoke-virtual {v4, v7, v5}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 85
    goto :goto_6

    .line 86
    :cond_4
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 89
    move-result-object v5

    .line 90
    instance-of v6, v5, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 92
    if-eqz v6, :cond_5

    .line 94
    check-cast v5, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 96
    invoke-static {v5}, Lck;->c(Landroid/view/ViewGroup$MarginLayoutParams;)I

    .line 99
    move-result v6

    .line 100
    invoke-static {v5}, Lck;->b(Landroid/view/ViewGroup$MarginLayoutParams;)I

    .line 103
    move-result v5

    .line 104
    goto :goto_4

    .line 105
    :cond_5
    const/4 v5, 0x0

    .line 106
    const/4 v6, 0x0

    .line 107
    :goto_4
    add-int v8, v3, v6

    .line 109
    invoke-virtual {v4}, Landroid/view/View;->getMeasuredWidth()I

    .line 112
    move-result v9

    .line 113
    add-int/2addr v9, v8

    .line 114
    iget-boolean v8, p0, Lad;->e:Z

    .line 116
    if-nez v8, :cond_6

    .line 118
    if-le v9, p4, :cond_6

    .line 120
    iget p2, p0, Lad;->c:I

    .line 122
    add-int/2addr p2, v2

    .line 123
    iget v2, p0, Lad;->f:I

    .line 125
    add-int/2addr v2, p1

    .line 126
    iput v2, p0, Lad;->f:I

    .line 128
    move v3, v0

    .line 129
    :cond_6
    iget v2, p0, Lad;->f:I

    .line 131
    sub-int/2addr v2, p1

    .line 132
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 135
    move-result-object v2

    .line 136
    invoke-virtual {v4, v7, v2}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 139
    add-int v2, v3, v6

    .line 141
    invoke-virtual {v4}, Landroid/view/View;->getMeasuredWidth()I

    .line 144
    move-result v7

    .line 145
    add-int/2addr v7, v2

    .line 146
    invoke-virtual {v4}, Landroid/view/View;->getMeasuredHeight()I

    .line 149
    move-result v8

    .line 150
    add-int/2addr v8, p2

    .line 151
    if-eqz p5, :cond_7

    .line 153
    sub-int v2, p4, v7

    .line 155
    sub-int v7, p4, v3

    .line 157
    sub-int/2addr v7, v6

    .line 158
    invoke-virtual {v4, v2, p2, v7, v8}, Landroid/view/View;->layout(IIII)V

    .line 161
    goto :goto_5

    .line 162
    :cond_7
    invoke-virtual {v4, v2, p2, v7, v8}, Landroid/view/View;->layout(IIII)V

    .line 165
    :goto_5
    add-int/2addr v6, v5

    .line 166
    invoke-virtual {v4}, Landroid/view/View;->getMeasuredWidth()I

    .line 169
    move-result v2

    .line 170
    add-int/2addr v2, v6

    .line 171
    iget v4, p0, Lad;->d:I

    .line 173
    add-int/2addr v2, v4

    .line 174
    add-int/2addr v3, v2

    .line 175
    move v2, v8

    .line 176
    :goto_6
    add-int/lit8 v1, v1, 0x1

    .line 178
    goto :goto_3

    .line 179
    :cond_8
    return-void
.end method

.method public final onMeasure(II)V
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 3
    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 6
    move-result v1

    .line 7
    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 10
    move-result v2

    .line 11
    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 14
    move-result v3

    .line 15
    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 18
    move-result v4

    .line 19
    const/high16 v5, 0x40000000    # 2.0f

    .line 21
    const/high16 v6, -0x80000000

    .line 23
    if-eq v2, v6, :cond_1

    .line 25
    if-ne v2, v5, :cond_0

    .line 27
    goto :goto_0

    .line 28
    :cond_0
    const v7, 0x7fffffff

    .line 31
    goto :goto_1

    .line 32
    :cond_1
    :goto_0
    move v7, v1

    .line 33
    :goto_1
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    .line 36
    move-result v8

    .line 37
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingTop()I

    .line 40
    move-result v9

    .line 41
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingRight()I

    .line 44
    move-result v10

    .line 45
    sub-int/2addr v7, v10

    .line 46
    move v11, v9

    .line 47
    const/4 v12, 0x0

    .line 48
    const/4 v13, 0x0

    .line 49
    :goto_2
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 52
    move-result v14

    .line 53
    if-ge v12, v14, :cond_7

    .line 55
    invoke-virtual {v0, v12}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 58
    move-result-object v14

    .line 59
    invoke-virtual {v14}, Landroid/view/View;->getVisibility()I

    .line 62
    move-result v15

    .line 63
    const/16 v5, 0x8

    .line 65
    if-ne v15, v5, :cond_2

    .line 67
    move/from16 v15, p2

    .line 69
    const/16 v16, 0x0

    .line 71
    goto :goto_4

    .line 72
    :cond_2
    move/from16 v5, p1

    .line 74
    move/from16 v15, p2

    .line 76
    invoke-virtual {v0, v14, v5, v15}, Landroid/view/ViewGroup;->measureChild(Landroid/view/View;II)V

    .line 79
    invoke-virtual {v14}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 82
    move-result-object v6

    .line 83
    instance-of v10, v6, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 85
    if-eqz v10, :cond_3

    .line 87
    check-cast v6, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 89
    iget v10, v6, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 91
    const/16 v16, 0x0

    .line 93
    add-int/lit8 v10, v10, 0x0

    .line 95
    iget v6, v6, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 97
    add-int/lit8 v6, v6, 0x0

    .line 99
    goto :goto_3

    .line 100
    :cond_3
    const/16 v16, 0x0

    .line 102
    const/4 v6, 0x0

    .line 103
    const/4 v10, 0x0

    .line 104
    :goto_3
    add-int v17, v8, v10

    .line 106
    invoke-virtual {v14}, Landroid/view/View;->getMeasuredWidth()I

    .line 109
    move-result v18

    .line 110
    add-int v5, v18, v17

    .line 112
    if-le v5, v7, :cond_4

    .line 114
    invoke-virtual/range {p0 .. p0}, Lad;->a()Z

    .line 117
    move-result v5

    .line 118
    if-nez v5, :cond_4

    .line 120
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    .line 123
    move-result v8

    .line 124
    iget v5, v0, Lad;->c:I

    .line 126
    add-int v11, v5, v9

    .line 128
    :cond_4
    add-int v5, v8, v10

    .line 130
    invoke-virtual {v14}, Landroid/view/View;->getMeasuredWidth()I

    .line 133
    move-result v9

    .line 134
    add-int/2addr v9, v5

    .line 135
    invoke-virtual {v14}, Landroid/view/View;->getMeasuredHeight()I

    .line 138
    move-result v5

    .line 139
    add-int/2addr v5, v11

    .line 140
    if-le v9, v13, :cond_5

    .line 142
    move v13, v9

    .line 143
    :cond_5
    add-int/2addr v10, v6

    .line 144
    invoke-virtual {v14}, Landroid/view/View;->getMeasuredWidth()I

    .line 147
    move-result v9

    .line 148
    add-int/2addr v9, v10

    .line 149
    iget v10, v0, Lad;->d:I

    .line 151
    add-int/2addr v9, v10

    .line 152
    add-int/2addr v9, v8

    .line 153
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 156
    move-result v8

    .line 157
    add-int/lit8 v8, v8, -0x1

    .line 159
    if-ne v12, v8, :cond_6

    .line 161
    add-int/2addr v13, v6

    .line 162
    :cond_6
    move v8, v9

    .line 163
    move v9, v5

    .line 164
    :goto_4
    add-int/lit8 v12, v12, 0x1

    .line 166
    const/high16 v5, 0x40000000    # 2.0f

    .line 168
    const/high16 v6, -0x80000000

    .line 170
    goto :goto_2

    .line 171
    :cond_7
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingRight()I

    .line 174
    move-result v5

    .line 175
    add-int/2addr v5, v13

    .line 176
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingBottom()I

    .line 179
    move-result v6

    .line 180
    add-int/2addr v6, v9

    .line 181
    const/high16 v7, -0x80000000

    .line 183
    if-eq v2, v7, :cond_8

    .line 185
    const/high16 v8, 0x40000000    # 2.0f

    .line 187
    if-eq v2, v8, :cond_9

    .line 189
    move v1, v5

    .line 190
    goto :goto_5

    .line 191
    :cond_8
    const/high16 v8, 0x40000000    # 2.0f

    .line 193
    invoke-static {v5, v1}, Ljava/lang/Math;->min(II)I

    .line 196
    move-result v1

    .line 197
    :cond_9
    :goto_5
    if-eq v4, v7, :cond_a

    .line 199
    if-eq v4, v8, :cond_b

    .line 201
    move v3, v6

    .line 202
    goto :goto_6

    .line 203
    :cond_a
    invoke-static {v6, v3}, Ljava/lang/Math;->min(II)I

    .line 206
    move-result v3

    .line 207
    :cond_b
    :goto_6
    invoke-virtual {v0, v1, v3}, Landroid/view/View;->setMeasuredDimension(II)V

    .line 210
    return-void
.end method

.method public setItemSpacing(I)V
    .locals 0

    iput p1, p0, Lad;->d:I

    return-void
.end method

.method public setLineSpacing(I)V
    .locals 0

    iput p1, p0, Lad;->c:I

    return-void
.end method

.method public setSingleLine(Z)V
    .locals 0

    iput-boolean p1, p0, Lad;->e:Z

    return-void
.end method
