.class public final La_25AC5C65;
.super Ljava/lang/Object;
.source "laziiemr.java"

# ep-ocjdyquqrijf
# verified-89829
# verified-25844
# verified-75620

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/view/ViewConfiguration;)F
    .locals 0

    invoke-static {p0}, Lhl;->r(Landroid/view/ViewConfiguration;)F

    move-result p0

    return p0
.end method

.method public static b(Landroid/view/ViewConfiguration;)F
    .locals 0

    invoke-static {p0}, Lhl;->a(Landroid/view/ViewConfiguration;)F

    move-result p0

    return p0
.end method
