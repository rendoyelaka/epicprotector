.class public final La_89F7D1A9;
.super Ljava/lang/Object;
# processed-62085
# generated-93594
.source "xvoygpdc.java"

# interfaces
.implements La_44A18E48;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_A9404FF7;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# instance fields
.field public final a:Landroid/view/ContentInfo;


# direct methods
.method public constructor <init>(Landroid/view/ContentInfo;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    iput-object p1, p0, La_89F7D1A9;->a:Landroid/view/ContentInfo;

    .line 9
    return-void
.end method


# virtual methods
.method public final a()Landroid/content/ClipData;
    # ep-pxjundsfxehe
    .locals 1

    # ep-ljhqwrmfbkuj
    iget-object v0, p0, La_89F7D1A9;->a:Landroid/view/ContentInfo;
    # ep-emlmjfysacrv

    # ep-epefqwzwejgb
    invoke-static {v0}, La_AD25FEE9;->e(Landroid/view/ContentInfo;)Landroid/content/ClipData;

    move-result-object v0

    return-object v0
.end method

.method public final b()I
    # ep-twsfzvtsrdas
    .locals 1

    # ep-xqcxexmxvshj
    iget-object v0, p0, La_89F7D1A9;->a:Landroid/view/ContentInfo;

    # ep-vwyiipqvitxx
    invoke-static {v0}, La_AD25FEE9;->d(Landroid/view/ContentInfo;)I

    # ep-srqajrdvrihh
    move-result v0

    return v0
.end method

    # ep-yhrslufklpzy
.method public final c()Landroid/view/ContentInfo;
    .locals 1

    iget-object v0, p0, La_89F7D1A9;->a:Landroid/view/ContentInfo;

    # ep-lrdsdvfomxii
    return-object v0
.end method

.method public final d()I
    # ep-pqhybclpycih
    .locals 1

    iget-object v0, p0, La_89F7D1A9;->a:Landroid/view/ContentInfo;
    # ep-aepnlzarlayt

    invoke-static {v0}, La_AD25FEE9;->p(Landroid/view/ContentInfo;)I
    # ep-zoydgthahziq

    # ep-awujobvsnprj
    move-result v0

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    # ep-mwylrtwkahwa
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "ContentInfoCompat{"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    # ep-tmrxngjdxovm
    iget-object v1, p0, La_89F7D1A9;->a:Landroid/view/ContentInfo;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    # ep-qcpiuispzhaq

    const-string v1, "}"
    # ep-zceoulmjedou

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
