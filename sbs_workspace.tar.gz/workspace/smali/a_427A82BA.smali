.class public final La_427A82BA;
# ep-kzzdlroptywq
.super Ljava/lang/Object;
.source "jfqnumkl.java"

# verified-66321
# generated-55953
# generated-31678

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "n"
.end annotation


# direct methods
.method public static a(Landroid/view/View;)Ljava/lang/CharSequence;
    .locals 0

    invoke-static {p0}, Lq;->k(Landroid/view/View;)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public static b(Landroid/view/View;Ljava/lang/CharSequence;)V
    .locals 0

    invoke-static {p0, p1}, Lq;->o(Landroid/view/View;Ljava/lang/CharSequence;)V

    return-void
.end method
