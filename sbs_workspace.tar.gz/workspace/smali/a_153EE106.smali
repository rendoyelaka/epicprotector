.class public final La_153EE106;
.super La_F14ECA7B;
# validated-19719
# generated-25934
# processed-17010
# ep-rokmlwtwnlky
.source "biinqnif.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_1CAFA37F;->n(Landroid/content/Context;Lmv;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Ljava/lang/ref/WeakReference;

.field public final synthetic d:La_1CAFA37F;


# direct methods
.method public constructor <init>(La_1CAFA37F;IILjava/lang/ref/WeakReference;)V
    .locals 0

    iput-object p1, p0, La_153EE106;->d:La_1CAFA37F;

    iput p2, p0, La_153EE106;->a:I

    iput p3, p0, La_153EE106;->b:I

    iput-object p4, p0, La_153EE106;->c:Ljava/lang/ref/WeakReference;

    invoke-direct {p0}, La_F14ECA7B;-><init>()V

    return-void
.end method


# virtual methods
.method public final c(I)V
    .locals 0

    return-void
.end method

.method public final d(Landroid/graphics/Typeface;)V
    .locals 3

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1c

    .line 5
    if-lt v0, v1, :cond_1

    .line 7
    const/4 v0, -0x1

    .line 8
    iget v1, p0, La_153EE106;->a:I

    .line 10
    if-eq v1, v0, :cond_1

    .line 12
    iget v0, p0, La_153EE106;->b:I

    .line 14
    and-int/lit8 v0, v0, 0x2

    .line 16
    if-eqz v0, :cond_0

    .line 18
    const/4 v0, 0x1

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v0, 0x0

    .line 21
    :goto_0
    invoke-static {p1, v1, v0}, La_242FD51A;->a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    .line 24
    move-result-object p1

    .line 25
    :cond_1
    iget-object v0, p0, La_153EE106;->d:La_1CAFA37F;

    .line 27
    iget-boolean v1, v0, La_1CAFA37F;->m:Z

    .line 29
    if-eqz v1, :cond_3

    .line 31
    iput-object p1, v0, La_1CAFA37F;->l:Landroid/graphics/Typeface;

    .line 33
    iget-object v1, p0, La_153EE106;->c:Ljava/lang/ref/WeakReference;

    .line 35
    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 38
    move-result-object v1

    .line 39
    check-cast v1, Landroid/widget/TextView;

    .line 41
    if-eqz v1, :cond_3

    .line 43
    sget-object v2, Lqx;->a:Ljava/util/WeakHashMap;

    .line 45
    invoke-static {v1}, La_E52A1C04;->b(Landroid/view/View;)Z

    .line 48
    move-result v2

    .line 49
    if-eqz v2, :cond_2

    .line 51
    iget v0, v0, La_1CAFA37F;->j:I

    .line 53
    new-instance v2, La_6EBB38F8;

    .line 55
    invoke-direct {v2, v1, p1, v0}, La_6EBB38F8;-><init>(Landroid/widget/TextView;Landroid/graphics/Typeface;I)V

    .line 58
    invoke-virtual {v1, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 61
    goto :goto_1

    .line 62
    :cond_2
    iget v0, v0, La_1CAFA37F;->j:I

    .line 64
    invoke-virtual {v1, p1, v0}, Landroid/widget/TextView;->m_ded7c3e0(Landroid/graphics/Typeface;I)V

    .line 67
    :cond_3
    :goto_1
    return-void
.end method
