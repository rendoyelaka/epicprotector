.class public interface abstract Lbv;
# ep-wrqyzaxtqwfs
.super Ljava/lang/Object;
.source "dbjrzlic.java"
# compiled-95807
# compiled-52545

# interfaces
.implements Landroid/widget/SpinnerAdapter;


# virtual methods
.method public abstract a()V
.end method

.method public abstract getDropDownViewTheme()Landroid/content/res/Resources$Theme;
.end method
