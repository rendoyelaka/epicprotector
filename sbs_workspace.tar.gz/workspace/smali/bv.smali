.class public interface abstract Lbv;
# ep-mrqoebmvhcox
.super Ljava/lang/Object;
.source "ueorcook.java"
# generated-32131
# verified-80788

# interfaces
.implements Landroid/widget/SpinnerAdapter;


# virtual methods
.method public abstract a()V
.end method

.method public abstract getDropDownViewTheme()Landroid/content/res/Resources$Theme;
.end method
