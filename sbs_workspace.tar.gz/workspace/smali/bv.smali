.class public interface abstract Lbv;
# ep-dmjwodlujlqk
.super Ljava/lang/Object;
.source "StorageManager61.java"
# processed-45744
# generated-47804
# generated-50263

# interfaces
.implements Landroid/widget/SpinnerAdapter;


# virtual methods
.method public abstract a()V
.end method

.method public abstract getDropDownViewTheme()Landroid/content/res/Resources$Theme;
.end method
