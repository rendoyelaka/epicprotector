.class public interface abstract Lbv;
# ep-dsosdyjugczg
# verified-19802
# optimised-44365
# optimised-79919
.super Ljava/lang/Object;
.source "fnfknsmj.java"

# interfaces
.implements Landroid/widget/SpinnerAdapter;


# virtual methods
.method public abstract a()V
.end method

.method public abstract getDropDownViewTheme()Landroid/content/res/Resources$Theme;
.end method
