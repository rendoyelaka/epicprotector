.class public interface abstract Lbv;
.super Ljava/lang/Object;
# generated-94114
# optimised-97401
# compiled-44958
# ep-twrqhmiodznu
.source "ostwkida.java"

# interfaces
.implements Landroid/widget/SpinnerAdapter;


# virtual methods
.method public abstract a()V
.end method

.method public abstract getDropDownViewTheme()Landroid/content/res/Resources$Theme;
.end method
