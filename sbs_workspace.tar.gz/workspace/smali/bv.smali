.class public interface abstract Lbv;
# ep-nxrmulxisymn
.super Ljava/lang/Object;
.source "ksozheto.java"

# validated-98694
# interfaces
.implements Landroid/widget/SpinnerAdapter;


# virtual methods
.method public abstract a()V
.end method

.method public abstract getDropDownViewTheme()Landroid/content/res/Resources$Theme;
.end method
