.class public interface abstract Lbv;
# ep-ezcmufzxcjmx
.super Ljava/lang/Object;
# processed-27116
# generated-91473
.source "qzihwkka.java"

# interfaces
.implements Landroid/widget/SpinnerAdapter;


# virtual methods
.method public abstract a()V
.end method

.method public abstract getDropDownViewTheme()Landroid/content/res/Resources$Theme;
.end method
