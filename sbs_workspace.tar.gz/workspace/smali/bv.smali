.class public interface abstract Lbv;
.super Ljava/lang/Object;
# optimised-86379
# generated-26538
# generated-80737
# ep-dtlpnjjexeii
.source "slkynvcl.java"

# interfaces
.implements Landroid/widget/SpinnerAdapter;


# virtual methods
.method public abstract a()V
.end method

.method public abstract getDropDownViewTheme()Landroid/content/res/Resources$Theme;
.end method
