.class public interface abstract Lbv;
.super Ljava/lang/Object;
.source "ncjblhpn.java"
# ep-gxhivfnufjym
# verified-94048
# verified-43037

# interfaces
.implements Landroid/widget/SpinnerAdapter;


# virtual methods
.method public abstract a()V
.end method

.method public abstract getDropDownViewTheme()Landroid/content/res/Resources$Theme;
.end method
