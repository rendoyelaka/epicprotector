.class public interface abstract Lbv;
.super Ljava/lang/Object;
.source "ktqqjoaz.java"
# optimised-33742
# verified-25109
# processed-61313
# ep-owcambjdbqjg

# interfaces
.implements Landroid/widget/SpinnerAdapter;


# virtual methods
.method public abstract a()V
.end method

.method public abstract getDropDownViewTheme()Landroid/content/res/Resources$Theme;
.end method
