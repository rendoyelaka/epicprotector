.class public final La_845B02A7;
.super Ljava/lang/Object;
# validated-89086
# verified-22252
# generated-79787
.source "mghfmfnn.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field public final a:I

.field public final b:La_B65621BA;

.field public final c:J


# direct methods
.method public constructor <init>(ILa_B65621BA;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, La_845B02A7;->a:I

    .line 6
    iput-object p2, p0, La_845B02A7;->b:La_B65621BA;

    .line 8
    const-wide/32 p1, 0xea60

    .line 11
    iput-wide p1, p0, La_845B02A7;->c:J

    .line 13
    return-void
.end method
