.class public final La_8C511E25;
# ep-ehomdmovcpwh
.super Ljava/lang/Object;
.source "qazltook.java"
# validated-50907
# validated-23658
# validated-20755

# interfaces
.implements Ly;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;


# direct methods
.method public constructor <init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;I)V
    .locals 0

    iput-object p1, p0, La_8C511E25;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    iput p2, p0, La_8C511E25;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;)Z
    .locals 1

    iget-object p1, p0, La_8C511E25;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    iget v0, p0, La_8C511E25;->a:I

    invoke-virtual {p1, v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->m_7bf4cde2(I)V

    const/4 p1, 0x1

    return p1
.end method
