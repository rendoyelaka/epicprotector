.class public final La_6C28DDD2;
.super Ljava/lang/Object;
.source "tyriiavc.java"
# verified-57527
# verified-78716

# ep-hstmdqhegcyq

# instance fields
.field public final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "La_D3507BAE;",
            ">;"
        }
    .end annotation
.end field

.field public b:I

.field public c:Z

.field public d:Z


# direct methods
.method public constructor <init>(Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "La_D3507BAE;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, La_6C28DDD2;->b:I

    .line 7
    iput-object p1, p0, La_6C28DDD2;->a:Ljava/util/List;

    .line 9
    return-void
.end method


# virtual methods
.method public final a(Ljavax/net/ssl/SSLSocket;)La_D3507BAE;
    .locals 11

    .line 1
    iget v0, p0, La_6C28DDD2;->b:I

    .line 3
    iget-object v1, p0, La_6C28DDD2;->a:Ljava/util/List;

    .line 5
    invoke-interface {v1}, Ljava/util/List;->m_79017b7d()I

    .line 8
    move-result v2

    .line 9
    :goto_0
    const/4 v3, 0x1

    .line 10
    if-ge v0, v2, :cond_1

    .line 12
    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 15
    move-result-object v4

    .line 16
    check-cast v4, La_D3507BAE;

    .line 18
    invoke-virtual {v4, p1}, La_D3507BAE;->a(Ljavax/net/ssl/SSLSocket;)Z

    .line 21
    move-result v5

    .line 22
    if-eqz v5, :cond_0

    .line 24
    add-int/2addr v0, v3

    .line 25
    iput v0, p0, La_6C28DDD2;->b:I

    .line 27
    goto :goto_1

    .line 28
    :cond_0
    add-int/lit8 v0, v0, 0x1

    .line 30
    goto :goto_0

    .line 31
    :cond_1
    const/4 v4, 0x0

    .line 32
    :goto_1
    if-eqz v4, :cond_b

    .line 34
    iget v0, p0, La_6C28DDD2;->b:I

    .line 36
    :goto_2
    invoke-interface {v1}, Ljava/util/List;->m_79017b7d()I

    .line 39
    move-result v2

    .line 40
    const/4 v5, 0x0

    .line 41
    if-ge v0, v2, :cond_3

    .line 43
    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 46
    move-result-object v2

    .line 47
    check-cast v2, La_D3507BAE;

    .line 49
    invoke-virtual {v2, p1}, La_D3507BAE;->a(Ljavax/net/ssl/SSLSocket;)Z

    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_2

    .line 55
    const/4 v0, 0x1

    .line 56
    goto :goto_3

    .line 57
    :cond_2
    add-int/lit8 v0, v0, 0x1

    .line 59
    goto :goto_2

    .line 60
    :cond_3
    const/4 v0, 0x0

    .line 61
    :goto_3
    iput-boolean v0, p0, La_6C28DDD2;->c:Z

    .line 63
    sget-object v0, Lpi;->a:La_5520255D;

    .line 65
    iget-boolean v1, p0, La_6C28DDD2;->d:Z

    .line 67
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 70
    iget-object v0, v4, La_D3507BAE;->c:[Ljava/lang/String;

    .line 72
    if-eqz v0, :cond_4

    .line 74
    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getEnabledCipherSuites()[Ljava/lang/String;

    .line 77
    move-result-object v2

    .line 78
    invoke-static {v0, v2}, Lex;->j([Ljava/lang/Object;[Ljava/lang/Object;)[Ljava/lang/Object;

    .line 81
    move-result-object v0

    .line 82
    check-cast v0, [Ljava/lang/String;

    .line 84
    goto :goto_4

    .line 85
    :cond_4
    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getEnabledCipherSuites()[Ljava/lang/String;

    .line 88
    move-result-object v0

    .line 89
    :goto_4
    iget-object v2, v4, La_D3507BAE;->d:[Ljava/lang/String;

    .line 91
    if-eqz v2, :cond_5

    .line 93
    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getEnabledProtocols()[Ljava/lang/String;

    .line 96
    move-result-object v6

    .line 97
    invoke-static {v2, v6}, Lex;->j([Ljava/lang/Object;[Ljava/lang/Object;)[Ljava/lang/Object;

    .line 100
    move-result-object v2

    .line 101
    check-cast v2, [Ljava/lang/String;

    .line 103
    goto :goto_5

    .line 104
    :cond_5
    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getEnabledProtocols()[Ljava/lang/String;

    .line 107
    move-result-object v2

    .line 108
    :goto_5
    if-eqz v1, :cond_8

    .line 110
    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getSupportedCipherSuites()[Ljava/lang/String;

    .line 113
    move-result-object v1

    .line 114
    sget-object v6, Lex;->a:[B

    .line 116
    array-length v6, v1

    .line 117
    const/4 v7, 0x0

    .line 118
    :goto_6
    const/4 v8, -0x1

    .line 119
    const-string v9, "TLS_FALLBACK_SCSV"

    .line 121
    if-ge v7, v6, :cond_7

    .line 123
    aget-object v10, v1, v7

    .line 125
    invoke-static {v10, v9}, Lex;->f(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 128
    move-result v10

    .line 129
    if-eqz v10, :cond_6

    .line 131
    goto :goto_7

    .line 132
    :cond_6
    add-int/lit8 v7, v7, 0x1

    .line 134
    goto :goto_6

    .line 135
    :cond_7
    const/4 v7, -0x1

    .line 136
    :goto_7
    if-eq v7, v8, :cond_8

    .line 138
    array-length v1, v0

    .line 139
    add-int/2addr v1, v3

    .line 140
    new-array v3, v1, [Ljava/lang/String;

    .line 142
    array-length v6, v0

    .line 143
    invoke-static {v0, v5, v3, v5, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 146
    add-int/2addr v1, v8

    .line 147
    aput-object v9, v3, v1

    .line 149
    move-object v0, v3

    .line 150
    :cond_8
    new-instance v1, La_74FDB7F6;

    .line 152
    invoke-direct {v1, v4}, La_74FDB7F6;-><init>(La_D3507BAE;)V

    .line 155
    invoke-virtual {v1, v0}, La_74FDB7F6;->a([Ljava/lang/String;)V

    .line 158
    invoke-virtual {v1, v2}, La_74FDB7F6;->c([Ljava/lang/String;)V

    .line 161
    new-instance v0, La_D3507BAE;

    .line 163
    invoke-direct {v0, v1}, La_D3507BAE;-><init>(La_74FDB7F6;)V

    .line 166
    iget-object v1, v0, La_D3507BAE;->d:[Ljava/lang/String;

    .line 168
    if-eqz v1, :cond_9

    .line 170
    invoke-virtual {p1, v1}, Ljavax/net/ssl/SSLSocket;->setEnabledProtocols([Ljava/lang/String;)V

    .line 173
    :cond_9
    iget-object v0, v0, La_D3507BAE;->c:[Ljava/lang/String;

    .line 175
    if-eqz v0, :cond_a

    .line 177
    invoke-virtual {p1, v0}, Ljavax/net/ssl/SSLSocket;->setEnabledCipherSuites([Ljava/lang/String;)V

    .line 180
    :cond_a
    return-object v4

    .line 181
    :cond_b
    new-instance v0, Ljava/net/UnknownServiceException;

    .line 183
    new-instance v2, Ljava/lang/StringBuilder;

    .line 185
    const-string v3, "Unable to find acceptable protocols. isFallback="

    .line 187
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 190
    iget-boolean v3, p0, La_6C28DDD2;->d:Z

    .line 192
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 195
    const-string v3, ", modes="

    .line 197
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 200
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 203
    const-string v1, ", supported protocols="

    .line 205
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 208
    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getEnabledProtocols()[Ljava/lang/String;

    .line 211
    move-result-object p1

    .line 212
    invoke-static {p1}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    .line 215
    move-result-object p1

    .line 216
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 219
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 222
    move-result-object p1

    .line 223
    invoke-direct {v0, p1}, Ljava/net/UnknownServiceException;-><init>(Ljava/lang/String;)V

    .line 226
    throw v0
.end method
