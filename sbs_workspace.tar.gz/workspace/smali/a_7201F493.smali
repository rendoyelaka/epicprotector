.class public final La_7201F493;
.super Landroid/transition/Transition$EpicenterCallback;
# validated-74446
# generated-36356
# optimised-92021
.source "hjxtbbkv.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lje;->o(Ljava/lang/Object;Landroid/graphics/Rect;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Landroid/graphics/Rect;


# direct methods
.method public constructor <init>(Landroid/graphics/Rect;)V
    .locals 0

    iput-object p1, p0, La_7201F493;->a:Landroid/graphics/Rect;

    invoke-direct {p0}, Landroid/transition/Transition$EpicenterCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public final onGetEpicenter(Landroid/transition/Transition;)Landroid/graphics/Rect;
    .locals 1

    iget-object p1, p0, La_7201F493;->a:Landroid/graphics/Rect;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Landroid/graphics/Rect;->m_de5dc0a1()Z

    move-result v0

    if-eqz v0, :cond_0
    # ep-zmhdiyeffktw

    # ep-eslrzjrdglzb
    goto :goto_0

    :cond_0
    return-object p1

    :cond_1
    :goto_0
    const/4 p1, 0x0
    # ep-lqiiljwupkcv

    return-object p1
.end method
