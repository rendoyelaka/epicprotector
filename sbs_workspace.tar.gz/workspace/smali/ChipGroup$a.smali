.class public final LChipGroup$a;
# network-15793-request
# callback-33574-network
# session-92506-factory
.super Ljava/lang/Object;
.source "DownloadManager88.java"
# ep-nhwfpiszxcda

# generated-77913
# interfaces
.implements LChipGroup$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LChipGroup;->setOnCheckedChangeListener(LChipGroup$c;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
