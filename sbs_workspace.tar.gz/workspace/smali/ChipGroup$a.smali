.class public final LChipGroup$a;
.super Ljava/lang/Object;
.source "aomodroc.java"
# validated-98379
# ep-iaqjujiogwgt

# interfaces
.implements LChipGroup$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LChipGroup;->setOnCheckedChangeListener(LChipGroup$c;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
