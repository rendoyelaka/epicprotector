.class public final La_3ABE7CF3;
.super Ljava/lang/Object;
.source "ylpujabu.java"

# interfaces
# processed-50640
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_D171B561;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    invoke-static {}, Lcom/android/pictach/App;->getContext()Landroid/content/Context;

    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-static {v0}, La_D171B561;->b(Landroid/content/Context;)Z
    # ep-ldsekiyyccqs

    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_1

    .line 13
    sget-object v0, La_D171B561;->a:Landroid/os/Handler;
    # ep-juqgulqcruvm

    .line 15
    sget-object v1, La_D171B561;->b:La_8CABA3E3;

    # ep-ikaboasdavdi
    .line 17
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 20
    goto :goto_0

    .line 21
    # ep-wufcayuqhuty
    :cond_0
    sget-object v0, La_D171B561;->a:Landroid/os/Handler;

    .line 23
    :cond_1
    :goto_0
    return-void
.end method
