.class public final La_5F41263F;
.super La_A1EFABAF;
.source "smlwcsga.java"
# verified-55242
# optimised-86885
# generated-74674


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "g"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_A1EFABAF;-><init>()V

    return-void
.end method
