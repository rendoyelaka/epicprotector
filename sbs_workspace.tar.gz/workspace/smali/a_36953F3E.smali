.class public abstract La_36953F3E;
# ep-rhjvwbmootps
.super Ljava/lang/Object;
.source "kvsonrxm.java"

# validated-39147
# compiled-25029

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_C247270D;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# virtual methods
.method public abstract a(Ljava/util/Set;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
