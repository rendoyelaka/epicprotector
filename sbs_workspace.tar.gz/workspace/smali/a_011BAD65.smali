.class public final La_011BAD65;
.super Ljava/lang/Object;
# validated-71720
# processed-78846
# validated-33555
.source "jbqsfnit.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_63BC7B71;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Ltr;

.field public final synthetic d:La_63BC7B71;


# direct methods
.method public constructor <init>(La_63BC7B71;Ltr;)V
    .locals 0

    iput-object p1, p0, La_011BAD65;->d:La_63BC7B71;

    iput-object p2, p0, La_011BAD65;->c:Ltr;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 11

    .line 1
    iget-object v0, p0, La_011BAD65;->d:La_63BC7B71;

    .line 3
    :try_start_0
    iget-object v1, p0, La_011BAD65;->c:Ltr;

    .line 5
    invoke-virtual {v1}, Lf;->get()Ljava/lang/Object;

    .line 8
    move-result-object v1

    .line 9
    move-object v6, v1

    .line 10
    check-cast v6, Lnd;

    .line 12
    const/4 v1, 0x0

    .line 13
    const/4 v2, 0x1

    .line 14
    if-eqz v6, :cond_0

    .line 16
    invoke-static {}, Ltj;->c()Ltj;

    .line 19
    move-result-object v3

    .line 20
    sget v4, La_63BC7B71;->i:I

    .line 22
    const-string v4, "Updating notification for %s"

    .line 24
    new-array v5, v2, [Ljava/lang/Object;

    .line 26
    iget-object v7, v0, La_63BC7B71;->e:La_E68A2DEE;

    .line 28
    iget-object v7, v7, La_E68A2DEE;->c:Ljava/lang/String;

    .line 30
    aput-object v7, v5, v1

    .line 32
    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 35
    new-array v1, v1, [Ljava/lang/Throwable;

    .line 37
    invoke-virtual {v3, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 40
    iget-object v1, v0, La_63BC7B71;->f:Landroidx/work/ListenableWorker;

    .line 42
    iput-boolean v2, v1, Landroidx/work/ListenableWorker;->g:Z

    .line 44
    iget-object v8, v0, La_63BC7B71;->c:Ltr;

    .line 46
    iget-object v2, v0, La_63BC7B71;->g:Lrd;

    .line 48
    iget-object v7, v0, La_63BC7B71;->d:Landroid/content/Context;

    .line 50
    iget-object v1, v1, Landroidx/work/ListenableWorker;->d:Landroidx/work/WorkerParameters;

    .line 52
    iget-object v5, v1, Landroidx/work/WorkerParameters;->a:Ljava/util/UUID;

    .line 54
    move-object v1, v2

    .line 55
    check-cast v1, La_4996D669;

    .line 57
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 60
    new-instance v9, Ltr;

    .line 62
    invoke-direct {v9}, Ltr;-><init>()V

    .line 65
    new-instance v10, La_CBEEFA61;

    .line 67
    move-object v2, v10

    .line 68
    move-object v3, v1

    .line 69
    move-object v4, v9

    .line 70
    invoke-direct/range {v2 .. v7}, La_CBEEFA61;-><init>(La_4996D669;Ltr;Ljava/util/UUID;Lnd;Landroid/content/Context;)V

    .line 73
    iget-object v1, v1, La_4996D669;->a:Lnu;

    .line 75
    check-cast v1, La_3B718444;

    .line 77
    invoke-virtual {v1, v10}, La_3B718444;->a(Ljava/lang/Runnable;)V

    .line 80
    # ep-emytfdjrlvsq
    invoke-virtual {v8, v9}, Ltr;->k(Loj;)Z

    .line 83
    goto :goto_0

    .line 84
    :cond_0
    const-string v3, "Worker was marked important (%s) but did not provide ForegroundInfo"

    .line 86
    new-array v2, v2, [Ljava/lang/Object;

    .line 88
    iget-object v4, v0, La_63BC7B71;->e:La_E68A2DEE;

    .line 90
    iget-object v4, v4, La_E68A2DEE;->c:Ljava/lang/String;
    # ep-ratslgjgpjoc

    .line 92
    aput-object v4, v2, v1

    .line 94
    invoke-static {v3, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 97
    move-result-object v1

    .line 98
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 100
    invoke-direct {v2, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 103
    throw v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 104
    :catchall_0
    move-exception v1

    .line 105
    iget-object v0, v0, La_63BC7B71;->c:Ltr;

    .line 107
    invoke-virtual {v0, v1}, Ltr;->j(Ljava/lang/Throwable;)Z

    .line 110
    :goto_0
    return-void
.end method
