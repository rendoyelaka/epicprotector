.class public final Lb8;
# ep-psmmdhsoicov
.super Ljava/lang/Object;
# validated-79562
# optimised-43480
# processed-63528
.source "ipyqdtpt.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Landroidx/work/impl/workers/ConstraintTrackingWorker;


# direct methods
.method public constructor <init>(Landroidx/work/impl/workers/ConstraintTrackingWorker;)V
    .locals 0

    iput-object p1, p0, Lb8;->c:Landroidx/work/impl/workers/ConstraintTrackingWorker;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 8

    .line 1
    iget-object v0, p0, Lb8;->c:Landroidx/work/impl/workers/ConstraintTrackingWorker;

    .line 3
    iget-object v1, v0, Landroidx/work/ListenableWorker;->d:Landroidx/work/WorkerParameters;

    .line 5
    iget-object v1, v1, Landroidx/work/WorkerParameters;->b:Landroidx/work/b;

    .line 7
    const-string v2, "androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME"

    .line 9
    iget-object v1, v1, Landroidx/work/b;->a:Ljava/util/HashMap;

    .line 11
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    move-result-object v1

    .line 15
    instance-of v2, v1, Ljava/lang/String;

    .line 17
    if-eqz v2, :cond_0

    .line 19
    check-cast v1, Ljava/lang/String;

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 v1, 0x0

    .line 23
    :goto_0
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 26
    move-result v2

    .line 27
    const/4 v3, 0x0

    .line 28
    if-eqz v2, :cond_1

    .line 30
    invoke-static {}, Ltj;->c()Ltj;

    .line 33
    move-result-object v1

    .line 34
    sget v2, Landroidx/work/impl/workers/ConstraintTrackingWorker;->m:I

    .line 36
    new-array v2, v3, [Ljava/lang/Throwable;

    .line 38
    invoke-virtual {v1, v2}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 41
    new-instance v1, Landroidx/work/ListenableWorker$a$a;

    .line 43
    invoke-direct {v1}, Landroidx/work/ListenableWorker$a$a;-><init>()V

    .line 46
    iget-object v0, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->k:Ltr;

    .line 48
    invoke-virtual {v0, v1}, Ltr;->i(Ljava/lang/Object;)Z

    .line 51
    goto/16 :goto_2

    .line 53
    :cond_1
    iget-object v2, v0, Landroidx/work/ListenableWorker;->d:Landroidx/work/WorkerParameters;

    .line 55
    iget-object v2, v2, Landroidx/work/WorkerParameters;->d:Lh10;

    .line 57
    iget-object v4, v0, Landroidx/work/ListenableWorker;->c:Landroid/content/Context;

    .line 59
    iget-object v5, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->h:Landroidx/work/WorkerParameters;

    .line 61
    invoke-virtual {v2, v4, v1, v5}, Lh10;->a(Landroid/content/Context;Ljava/lang/String;Landroidx/work/WorkerParameters;)Landroidx/work/ListenableWorker;

    .line 64
    move-result-object v2

    .line 65
    iput-object v2, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->l:Landroidx/work/ListenableWorker;

    .line 67
    if-nez v2, :cond_2

    .line 69
    invoke-static {}, Ltj;->c()Ltj;

    .line 72
    move-result-object v1

    .line 73
    sget v2, Landroidx/work/impl/workers/ConstraintTrackingWorker;->m:I

    .line 75
    new-array v2, v3, [Ljava/lang/Throwable;

    .line 77
    invoke-virtual {v1, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 80
    new-instance v1, Landroidx/work/ListenableWorker$a$a;

    .line 82
    invoke-direct {v1}, Landroidx/work/ListenableWorker$a$a;-><init>()V

    .line 85
    iget-object v0, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->k:Ltr;

    .line 87
    invoke-virtual {v0, v1}, Ltr;->i(Ljava/lang/Object;)Z

    .line 90
    goto/16 :goto_2

    .line 92
    :cond_2
    iget-object v2, v0, Landroidx/work/ListenableWorker;->c:Landroid/content/Context;

    .line 94
    invoke-static {v2}, LWorkManagerImpl;->s(Landroid/content/Context;)LWorkManagerImpl;

    .line 97
    move-result-object v2

    .line 98
    iget-object v2, v2, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 100
    invoke-virtual {v2}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 103
    move-result-object v2

    .line 104
    iget-object v4, v0, Landroidx/work/ListenableWorker;->d:Landroidx/work/WorkerParameters;

    .line 106
    iget-object v4, v4, Landroidx/work/WorkerParameters;->a:Ljava/util/UUID;

    .line 108
    invoke-virtual {v4}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 111
    move-result-object v4

    .line 112
    check-cast v2, LWorkSpecDao;

    .line 114
    invoke-virtual {v2, v4}, LWorkSpecDao;->h(Ljava/lang/String;)LWorkSpec;

    .line 117
    move-result-object v2

    .line 118
    if-nez v2, :cond_3

    .line 120
    new-instance v1, Landroidx/work/ListenableWorker$a$a;

    .line 122
    invoke-direct {v1}, Landroidx/work/ListenableWorker$a$a;-><init>()V

    .line 125
    iget-object v0, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->k:Ltr;

    .line 127
    invoke-virtual {v0, v1}, Ltr;->i(Ljava/lang/Object;)Z

    .line 130
    goto/16 :goto_2

    .line 132
    :cond_3
    new-instance v4, Le00;

    .line 134
    iget-object v5, v0, Landroidx/work/ListenableWorker;->c:Landroid/content/Context;

    .line 136
    invoke-static {v5}, LWorkManagerImpl;->s(Landroid/content/Context;)LWorkManagerImpl;

    .line 139
    move-result-object v6

    .line 140
    iget-object v6, v6, LWorkManagerImpl;->f:Lnu;

    .line 142
    invoke-direct {v4, v5, v6, v0}, Le00;-><init>(Landroid/content/Context;Lnu;Ld00;)V

    .line 145
    invoke-static {v2}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 148
    move-result-object v2

    .line 149
    invoke-virtual {v4, v2}, Le00;->c(Ljava/util/Collection;)V

    .line 152
    iget-object v2, v0, Landroidx/work/ListenableWorker;->d:Landroidx/work/WorkerParameters;

    .line 154
    iget-object v2, v2, Landroidx/work/WorkerParameters;->a:Ljava/util/UUID;

    .line 156
    invoke-virtual {v2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 159
    move-result-object v2

    .line 160
    invoke-virtual {v4, v2}, Le00;->a(Ljava/lang/String;)Z

    .line 163
    move-result v2

    .line 164
    const/4 v4, 0x1

    .line 165
    if-eqz v2, :cond_5

    .line 167
    invoke-static {}, Ltj;->c()Ltj;

    .line 170
    move-result-object v2

    .line 171
    sget v5, Landroidx/work/impl/workers/ConstraintTrackingWorker;->m:I

    .line 173
    const-string v5, "Constraints met for delegate %s"

    .line 175
    new-array v6, v4, [Ljava/lang/Object;

    .line 177
    aput-object v1, v6, v3

    .line 179
    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 182
    new-array v5, v3, [Ljava/lang/Throwable;

    .line 184
    invoke-virtual {v2, v5}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 187
    :try_start_0
    iget-object v2, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->l:Landroidx/work/ListenableWorker;

    .line 189
    invoke-virtual {v2}, Landroidx/work/ListenableWorker;->d()Ltr;

    .line 192
    move-result-object v2

    .line 193
    new-instance v5, Lc8;

    .line 195
    invoke-direct {v5, v0, v2}, Lc8;-><init>(Landroidx/work/impl/workers/ConstraintTrackingWorker;Loj;)V

    .line 198
    iget-object v6, v0, Landroidx/work/ListenableWorker;->d:Landroidx/work/WorkerParameters;

    .line 200
    iget-object v6, v6, Landroidx/work/WorkerParameters;->c:Ljava/util/concurrent/Executor;

    .line 202
    invoke-virtual {v2, v5, v6}, Lf;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 205
    goto :goto_2

    .line 206
    :catchall_0
    move-exception v2

    .line 207
    invoke-static {}, Ltj;->c()Ltj;

    .line 210
    move-result-object v5

    .line 211
    sget v6, Landroidx/work/impl/workers/ConstraintTrackingWorker;->m:I

    .line 213
    const-string v6, "Delegated worker %s threw exception in startWork."

    .line 215
    new-array v7, v4, [Ljava/lang/Object;

    .line 217
    aput-object v1, v7, v3

    .line 219
    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 222
    new-array v1, v4, [Ljava/lang/Throwable;

    .line 224
    aput-object v2, v1, v3

    .line 226
    invoke-virtual {v5, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 229
    iget-object v2, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->i:Ljava/lang/Object;

    .line 231
    monitor-enter v2

    .line 232
    :try_start_1
    iget-boolean v1, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->j:Z

    .line 234
    if-eqz v1, :cond_4

    .line 236
    invoke-static {}, Ltj;->c()Ltj;

    .line 239
    move-result-object v1

    .line 240
    new-array v3, v3, [Ljava/lang/Throwable;

    .line 242
    invoke-virtual {v1, v3}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 245
    new-instance v1, Landroidx/work/ListenableWorker$a$b;

    .line 247
    invoke-direct {v1}, Landroidx/work/ListenableWorker$a$b;-><init>()V

    .line 250
    iget-object v0, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->k:Ltr;

    .line 252
    invoke-virtual {v0, v1}, Ltr;->i(Ljava/lang/Object;)Z

    .line 255
    goto :goto_1

    .line 256
    :cond_4
    new-instance v1, Landroidx/work/ListenableWorker$a$a;

    .line 258
    invoke-direct {v1}, Landroidx/work/ListenableWorker$a$a;-><init>()V

    .line 261
    iget-object v0, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->k:Ltr;

    .line 263
    invoke-virtual {v0, v1}, Ltr;->i(Ljava/lang/Object;)Z

    .line 266
    :goto_1
    monitor-exit v2

    .line 267
    goto :goto_2

    .line 268
    :catchall_1
    move-exception v0

    .line 269
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 270
    throw v0

    .line 271
    :cond_5
    invoke-static {}, Ltj;->c()Ltj;

    .line 274
    move-result-object v2

    .line 275
    sget v5, Landroidx/work/impl/workers/ConstraintTrackingWorker;->m:I

    .line 277
    const-string v5, "Constraints not met for delegate %s. Requesting retry."

    .line 279
    new-array v4, v4, [Ljava/lang/Object;

    .line 281
    aput-object v1, v4, v3

    .line 283
    invoke-static {v5, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 286
    new-array v1, v3, [Ljava/lang/Throwable;

    .line 288
    invoke-virtual {v2, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 291
    new-instance v1, Landroidx/work/ListenableWorker$a$b;

    .line 293
    invoke-direct {v1}, Landroidx/work/ListenableWorker$a$b;-><init>()V

    .line 296
    iget-object v0, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->k:Ltr;

    .line 298
    invoke-virtual {v0, v1}, Ltr;->i(Ljava/lang/Object;)Z

    .line 301
    :goto_2
    return-void
.end method
