.class public final La_2CFBC994;
.super Ljava/lang/Object;
.source "kukfwtqr.java"

# processed-50189
# validated-82263
# compiled-28643
# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lge;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator<",
        "Lge;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1

    new-instance v0, Lge;
    # ep-hsldslhaeqes

    invoke-direct {v0, p1}, Lge;-><init>(Landroid/os/Parcel;)V
    # ep-bdoubbukuego

    return-object v0
.end method

    # ep-dqrftxlrvwpa
.method public final newArray(I)[Ljava/lang/Object;
    .locals 0

    # ep-ulldbarodtdc
    new-array p1, p1, [Lge;

    # ep-kbvoltevypzj
    return-object p1
.end method
