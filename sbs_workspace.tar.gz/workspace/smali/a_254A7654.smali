.class public final La_254A7654;
.super Ljava/lang/Object;
.source "uljxfcvu.java"
# optimised-73679


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_F43B5B5B;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public a:I

.field public b:I

.field public c:I

.field public d:I

.field public e:I

.field public f:I

.field public g:I

.field public h:Z

.field public i:Z

.field public j:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
