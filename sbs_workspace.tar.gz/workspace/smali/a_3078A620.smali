.class public final La_3078A620;
.super Ljava/lang/Object;
.source "jhbuujsj.java"

# generated-96264
# processed-19403

# instance fields
.field public final a:La_32FED543;

.field public final b:La_32FED543;

.field public final c:La_32FED543;

.field public final d:La_32FED543;

.field public final e:La_32FED543;

.field public final f:La_32FED543;

.field public final g:La_32FED543;

.field public final h:Landroid/graphics/Paint;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const-class v0, Lcom/google/android/material/datepicker/c;

    .line 6
    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 9
    move-result-object v0

    .line 10
    const v1, 0x7f0302db

    .line 13
    invoke-static {v1, p1, v0}, Lek;->c(ILandroid/content/Context;Ljava/lang/String;)Landroid/util/TypedValue;

    .line 16
    move-result-object v0

    .line 17
    iget v0, v0, Landroid/util/TypedValue;->data:I

    .line 19
    sget-object v1, La_1F00E1F9;->f_e740afbf:[I

    .line 21
    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    .line 24
    move-result-object v0

    .line 25
    const/4 v1, 0x3

    .line 26
    const/4 v2, 0x0

    .line 27
    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 30
    move-result v1

    .line 31
    invoke-static {p1, v1}, La_32FED543;->a(Landroid/content/Context;I)La_32FED543;

    .line 34
    move-result-object v1

    .line 35
    iput-object v1, p0, La_3078A620;->a:La_32FED543;

    .line 37
    const/4 v1, 0x1

    .line 38
    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 41
    move-result v1

    .line 42
    invoke-static {p1, v1}, La_32FED543;->a(Landroid/content/Context;I)La_32FED543;

    .line 45
    move-result-object v1

    .line 46
    iput-object v1, p0, La_3078A620;->g:La_32FED543;

    .line 48
    const/4 v1, 0x2

    .line 49
    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 52
    move-result v1

    .line 53
    invoke-static {p1, v1}, La_32FED543;->a(Landroid/content/Context;I)La_32FED543;

    .line 56
    move-result-object v1

    .line 57
    iput-object v1, p0, La_3078A620;->b:La_32FED543;

    .line 59
    const/4 v1, 0x4

    .line 60
    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 63
    move-result v1

    .line 64
    invoke-static {p1, v1}, La_32FED543;->a(Landroid/content/Context;I)La_32FED543;

    .line 67
    move-result-object v1

    .line 68
    iput-object v1, p0, La_3078A620;->c:La_32FED543;

    .line 70
    const/4 v1, 0x6

    .line 71
    invoke-static {p1, v0, v1}, Lal;->b(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 74
    move-result-object v1

    .line 75
    const/16 v3, 0x8

    .line 77
    invoke-virtual {v0, v3, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 80
    move-result v3

    .line 81
    invoke-static {p1, v3}, La_32FED543;->a(Landroid/content/Context;I)La_32FED543;

    .line 84
    move-result-object v3

    .line 85
    iput-object v3, p0, La_3078A620;->d:La_32FED543;

    .line 87
    const/4 v3, 0x7

    .line 88
    invoke-virtual {v0, v3, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 91
    move-result v3

    .line 92
    invoke-static {p1, v3}, La_32FED543;->a(Landroid/content/Context;I)La_32FED543;

    .line 95
    move-result-object v3

    .line 96
    iput-object v3, p0, La_3078A620;->e:La_32FED543;

    .line 98
    const/16 v3, 0x9

    .line 100
    invoke-virtual {v0, v3, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 103
    move-result v2

    .line 104
    invoke-static {p1, v2}, La_32FED543;->a(Landroid/content/Context;I)La_32FED543;

    .line 107
    move-result-object p1

    .line 108
    iput-object p1, p0, La_3078A620;->f:La_32FED543;

    .line 110
    new-instance p1, Landroid/graphics/Paint;

    .line 112
    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    .line 115
    iput-object p1, p0, La_3078A620;->h:Landroid/graphics/Paint;

    .line 117
    invoke-virtual {v1}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    .line 120
    move-result v1

    .line 121
    invoke-virtual {p1, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 124
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    .line 127
    return-void
.end method
