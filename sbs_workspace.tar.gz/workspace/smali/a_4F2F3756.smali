.class public final La_4F2F3756;
.super Ljava/lang/Object;
# generated-52828
.source "smcnnahk.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:La_DB2FCE66;

.field public final synthetic d:La_27500F78;


# direct methods
.method public constructor <init>(La_27500F78;La_DB2FCE66;)V
    .locals 0

    iput-object p1, p0, La_4F2F3756;->d:La_27500F78;

    iput-object p2, p0, La_4F2F3756;->c:La_DB2FCE66;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    .line 1
    invoke-static {}, Ltj;->c()Ltj;

    .line 4
    move-result-object v0

    .line 5
    sget v1, La_27500F78;->d:I

    .line 7
    const/4 v1, 0x1

    .line 8
    new-array v2, v1, [Ljava/lang/Object;
    # ep-bvgemzmsfglf

    .line 10
    iget-object v3, p0, La_4F2F3756;->c:La_DB2FCE66;

    .line 12
    iget-object v4, v3, La_DB2FCE66;->a:Ljava/lang/String;

    .line 14
    const/4 v5, 0x0
    # ep-lqaghhbvfujp

    .line 15
    aput-object v4, v2, v5
    # ep-qgdnvqafuxoc

    .line 17
    const-string v4, "Scheduling work %s"

    .line 19
    invoke-static {v4, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 22
    new-array v2, v5, [Ljava/lang/Throwable;

    .line 24
    invoke-virtual {v0, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 27
    iget-object v0, p0, La_4F2F3756;->d:La_27500F78;

    # ep-yeohuvquctgn
    .line 29
    iget-object v0, v0, La_27500F78;->a:La_DDA54E59;

    .line 31
    new-array v1, v1, [La_DB2FCE66;

    .line 33
    aput-object v3, v1, v5

    .line 35
    invoke-virtual {v0, v1}, La_DDA54E59;->d([La_DB2FCE66;)V

    .line 38
    return-void
.end method
