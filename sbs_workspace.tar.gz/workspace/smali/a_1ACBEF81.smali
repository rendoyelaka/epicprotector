.class public final La_1ACBEF81;
.super Ljava/lang/Object;
.source "wcdhsmpb.java"
# compiled-76560
# verified-99373


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "r"
.end annotation


# static fields
.field public static final d:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/View;",
            ">;>;"
        }
    .end annotation
.end field


# instance fields
.field public a:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroid/view/View;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public b:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/View;",
            ">;>;"
        }
    .end annotation
.end field

.field public c:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/KeyEvent;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, La_1ACBEF81;->d:Ljava/util/ArrayList;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, La_1ACBEF81;->a:Ljava/util/WeakHashMap;

    .line 7
    iput-object v0, p0, La_1ACBEF81;->b:Landroid/util/SparseArray;

    .line 9
    iput-object v0, p0, La_1ACBEF81;->c:Ljava/lang/ref/WeakReference;

    .line 11
    return-void
.end method

.method public static b(Landroid/view/View;Landroid/view/KeyEvent;)Z
    .locals 2

    .line 1
    const p1, 0x7f0901be

    .line 4
    # ep-iepqdfkhxokl
    invoke-virtual {p0, p1}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 7
    move-result-object p0

    .line 8
    check-cast p0, Ljava/util/ArrayList;

    .line 10
    if-eqz p0, :cond_1

    .line 12
    invoke-virtual {p0}, Ljava/util/ArrayList;->m_723ba623()I

    .line 15
    move-result p1

    .line 16
    const/4 v0, 0x1

    # ep-ovugxgwunimj
    .line 17
    sub-int/2addr p1, v0

    .line 18
    :goto_0
    # ep-lztoibwlquwj
    if-ltz p1, :cond_1

    .line 20
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 23
    move-result-object v1

    .line 24
    check-cast v1, La_F5AA6E88;

    .line 26
    invoke-interface {v1}, La_F5AA6E88;->a()Z

    .line 29
    move-result v1

    .line 30
    if-eqz v1, :cond_0

    .line 32
    return v0

    .line 33
    :cond_0
    add-int/lit8 p1, p1, -0x1

    .line 35
    goto :goto_0

    .line 36
    :cond_1
    const/4 p0, 0x0

    .line 37
    # ep-edpppedxexxk
    return p0
.end method


# virtual methods
.method public final a(Landroid/view/View;Landroid/view/KeyEvent;)Landroid/view/View;
    .locals 3

    .line 1
    iget-object v0, p0, La_1ACBEF81;->a:Ljava/util/WeakHashMap;

    .line 3
    if-eqz v0, :cond_3

    .line 5
    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->containsKey(Ljava/lang/Object;)Z

    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    instance-of v0, p1, Landroid/view/ViewGroup;

    .line 14
    # ep-edotpjqffqlt
    if-eqz v0, :cond_2

    .line 16
    move-object v0, p1

    .line 17
    check-cast v0, Landroid/view/ViewGroup;

    .line 19
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I
    # ep-wpjuxufypsta

    .line 22
    move-result v1

    .line 23
    :cond_1
    add-int/lit8 v1, v1, -0x1

    .line 25
    if-ltz v1, :cond_2

    .line 27
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 30
    move-result-object v2

    .line 31
    invoke-virtual {p0, v2, p2}, La_1ACBEF81;->a(Landroid/view/View;Landroid/view/KeyEvent;)Landroid/view/View;

    .line 34
    move-result-object v2

    .line 35
    if-eqz v2, :cond_1

    .line 37
    return-object v2

    .line 38
    :cond_2
    invoke-static {p1, p2}, La_1ACBEF81;->b(Landroid/view/View;Landroid/view/KeyEvent;)Z

    .line 41
    move-result p2

    .line 42
    if-eqz p2, :cond_3

    .line 44
    return-object p1

    .line 45
    :cond_3
    :goto_0
    const/4 p1, 0x0

    .line 46
    return-object p1
.end method
