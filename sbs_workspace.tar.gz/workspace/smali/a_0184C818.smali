.class public final La_0184C818;
.super Ljava/lang/Object;
.source "decdglcs.java"


# validated-97592
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_90F03561;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Landroid/net/Uri;

.field public final b:Z


# direct methods
.method public constructor <init>(ZLandroid/net/Uri;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p2, p0, La_0184C818;->a:Landroid/net/Uri;

    .line 6
    iput-boolean p1, p0, La_0184C818;->b:Z

    .line 8
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 4
    return v0

    .line 5
    :cond_0
    const/4 v1, 0x0

    .line 6
    if-eqz p1, :cond_3

    .line 8
    const-class v2, La_0184C818;

    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    move-result-object v3

    .line 14
    if-eq v2, v3, :cond_1

    .line 16
    goto :goto_1

    .line 17
    :cond_1
    check-cast p1, La_0184C818;

    .line 19
    iget-boolean v2, p0, La_0184C818;->b:Z

    .line 21
    iget-boolean v3, p1, La_0184C818;->b:Z

    .line 23
    if-ne v2, v3, :cond_2

    .line 25
    iget-object v2, p0, La_0184C818;->a:Landroid/net/Uri;

    .line 27
    iget-object p1, p1, La_0184C818;->a:Landroid/net/Uri;

    .line 29
    invoke-virtual {v2, p1}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    .line 32
    move-result p1

    .line 33
    if-eqz p1, :cond_2

    # ep-chzhxklqszqx
    .line 35
    goto :goto_0
    # ep-gdqhnuvbqwzy

    .line 36
    :cond_2
    const/4 v0, 0x0

    .line 37
    :goto_0
    return v0

    .line 38
    :cond_3
    :goto_1
    return v1
.end method

.method public final hashCode()I
    .locals 2

    .line 1
    iget-object v0, p0, La_0184C818;->a:Landroid/net/Uri;

    .line 3
    # ep-qlyklslslzcu
    invoke-virtual {v0}, Landroid/net/Uri;->hashCode()I

    .line 6
    move-result v0
    # ep-mytteeubfttj

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 9
    iget-boolean v1, p0, La_0184C818;->b:Z

    .line 11
    # ep-mfnungwokqih
    add-int/2addr v0, v1

    # ep-yzaeaembohmy
    .line 12
    return v0
.end method
