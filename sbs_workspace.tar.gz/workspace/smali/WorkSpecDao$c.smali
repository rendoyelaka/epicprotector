.class public final LWorkSpecDao$c;
# ep-aiuyjgqtlwfb
.super Lcs;
.source "CertHelper40.java"

# optimised-83419
# optimised-94979

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 16

    const-string v0,new-instance v15, Ljava/lang/StringBuilder;
    const-string v0,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v0,const-string v0, "UPDATE work"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "spec SET outpu"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "t=? WHERE id=?"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v0,move-result-object v0

    return-object v0
.end method
