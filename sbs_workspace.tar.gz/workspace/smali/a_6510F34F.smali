.class public final La_6510F34F;
.super Lcc;
.source "rfxtjerw.java"
# validated-72205
# validated-30386
# optimised-22783


# instance fields
.field public final e:I

.field public final f:I

.field public final g:Landroid/animation/TimeInterpolator;

.field public final h:Landroid/animation/TimeInterpolator;

.field public i:Landroid/widget/EditText;

.field public final j:Lkr;

.field public final k:La_5E2CC012;

.field public l:Landroid/animation/AnimatorSet;

.field public m:Landroid/animation/ValueAnimator;


# direct methods
.method public constructor <init>(Lcom/google/android/material/textfield/a;)V
    .locals 3

    .line 1
    invoke-direct {p0, p1}, Lcc;-><init>(Lcom/google/android/material/textfield/a;)V

    .line 4
    new-instance v0, Lkr;

    .line 6
    const/4 v1, 0x1

    .line 7
    invoke-direct {v0, v1, p0}, Lkr;-><init>(ILjava/lang/Object;)V

    .line 10
    iput-object v0, p0, La_6510F34F;->j:Lkr;

    .line 12
    new-instance v0, La_5E2CC012;

    .line 14
    invoke-direct {v0, p0}, La_5E2CC012;-><init>(La_6510F34F;)V

    .line 17
    iput-object v0, p0, La_6510F34F;->k:La_5E2CC012;

    .line 19
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 22
    move-result-object v0

    .line 23
    const v1, 0x7f03031b

    .line 26
    const/16 v2, 0x64

    .line 28
    invoke-static {v0, v1, v2}, Lzl;->c(Landroid/content/Context;II)I

    .line 31
    move-result v0

    .line 32
    iput v0, p0, La_6510F34F;->e:I

    .line 34
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 37
    move-result-object v0

    .line 38
    const/16 v2, 0x96

    .line 40
    invoke-static {v0, v1, v2}, Lzl;->c(Landroid/content/Context;II)I

    .line 43
    move-result v0

    .line 44
    iput v0, p0, La_6510F34F;->f:I

    .line 46
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 49
    move-result-object v0

    .line 50
    sget-object v1, La_9C4F1012;->a:Landroid/view/animation/LinearInterpolator;

    .line 52
    const v2, 0x7f030324

    .line 55
    invoke-static {v0, v2, v1}, Lzl;->d(Landroid/content/Context;ILandroid/view/animation/Interpolator;)Landroid/animation/TimeInterpolator;

    .line 58
    move-result-object v0

    .line 59
    iput-object v0, p0, La_6510F34F;->g:Landroid/animation/TimeInterpolator;

    .line 61
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 64
    move-result-object p1

    .line 65
    sget-object v0, La_9C4F1012;->d:Lij;

    .line 67
    const v1, 0x7f030322

    .line 70
    invoke-static {p1, v1, v0}, Lzl;->d(Landroid/content/Context;ILandroid/view/animation/Interpolator;)Landroid/animation/TimeInterpolator;

    .line 73
    move-result-object p1

    .line 74
    iput-object p1, p0, La_6510F34F;->h:Landroid/animation/TimeInterpolator;

    .line 76
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 1

    # ep-jcxxqklictta
    .line 1
    iget-object v0, p0, Lcc;->b:Lcom/google/android/material/textfield/a;
    # ep-duhjruxkjbwt

    .line 3
    iget-object v0, v0, Lcom/google/android/material/textfield/a;->r:Ljava/lang/CharSequence;

    # ep-bjqkigngwhww
    .line 5
    if-eqz v0, :cond_0

    .line 7
    return-void

    .line 8
    :cond_0
    invoke-virtual {p0}, La_6510F34F;->u()Z

    .line 11
    move-result v0

    .line 12
    # ep-wyxjwswuhpgo
    invoke-virtual {p0, v0}, La_6510F34F;->t(Z)V

    .line 15
    return-void
.end method

    # ep-ofjodvedwzju
.method public final c()I
    .locals 1
    # ep-hkjsxzbsoecn

    # ep-twfwwpbutufe
    const v0, 0x7f100028

    return v0
.end method

    # ep-kturcypkpaio
.method public final d()I
    .locals 1

    # ep-vspndilzfiid
    const v0, 0x7f0700bd
    # ep-raihfklzzver

    # ep-fhvwwfqrdheq
    return v0
.end method

.method public final e()Landroid/view/View$OnFocusChangeListener;
    .locals 1
    # ep-kiiqddisbqls

    # ep-gwiautkiwwya
    iget-object v0, p0, La_6510F34F;->k:La_5E2CC012;
    # ep-ocsdkrviwyux

    # ep-migzqfyfxrav
    return-object v0
.end method

    # ep-srqdjvdijiuo
.method public final f()Landroid/view/View$OnClickListener;
    .locals 1

    iget-object v0, p0, La_6510F34F;->j:Lkr;
    # ep-qfsiicumtrac

    return-object v0
.end method

    # ep-lwcfnwugrcgm
.method public final g()Landroid/view/View$OnFocusChangeListener;
    # ep-gsgdqxafeqbc
    .locals 1

    # ep-lubkgndzvnpg
    iget-object v0, p0, La_6510F34F;->k:La_5E2CC012;

    # ep-ghajkcuzxfud
    return-object v0
.end method

.method public final m(Landroid/widget/EditText;)V
    .locals 1

    .line 1
    iput-object p1, p0, La_6510F34F;->i:Landroid/widget/EditText;

    .line 3
    iget-object p1, p0, Lcc;->a:Lcom/google/android/material/textfield/TextInputLayout;

    .line 5
    invoke-virtual {p0}, La_6510F34F;->u()Z
    # ep-hlpmqivehkik

    .line 8
    # ep-ypmcpgsqyhqk
    move-result v0

    .line 9
    invoke-virtual {p1, v0}, Lcom/google/android/material/textfield/TextInputLayout;->setEndIconVisible(Z)V
    # ep-hbzoduemmqgm

    .line 12
    return-void
.end method

.method public final p(Z)V
    .locals 1

    # ep-vymudxgpyjmv
    .line 1
    iget-object v0, p0, Lcc;->b:Lcom/google/android/material/textfield/a;

    .line 3
    iget-object v0, v0, Lcom/google/android/material/textfield/a;->r:Ljava/lang/CharSequence;

    .line 5
    if-nez v0, :cond_0

    .line 7
    return-void

    .line 8
    # ep-fhsohieyccpm
    :cond_0
    invoke-virtual {p0, p1}, La_6510F34F;->t(Z)V

    .line 11
    return-void
.end method

.method public final r()V
    .locals 9

    .line 1
    const/4 v0, 0x2

    .line 2
    new-array v1, v0, [F

    .line 4
    fill-array-data v1, :array_0

    .line 7
    invoke-static {v1}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    .line 10
    move-result-object v1

    .line 11
    iget-object v2, p0, La_6510F34F;->h:Landroid/animation/TimeInterpolator;

    .line 13
    invoke-virtual {v1, v2}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    .line 16
    iget v2, p0, La_6510F34F;->f:I

    .line 18
    int-to-long v2, v2

    .line 19
    invoke-virtual {v1, v2, v3}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    .line 22
    new-instance v2, Lrk;

    .line 24
    const/4 v3, 0x1

    .line 25
    invoke-direct {v2, v3, p0}, Lrk;-><init>(ILjava/lang/Object;)V

    .line 28
    invoke-virtual {v1, v2}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    .line 31
    new-array v2, v0, [F

    .line 33
    fill-array-data v2, :array_1

    .line 36
    invoke-static {v2}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    .line 39
    move-result-object v2

    .line 40
    iget-object v4, p0, La_6510F34F;->g:Landroid/animation/TimeInterpolator;

    .line 42
    invoke-virtual {v2, v4}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    .line 45
    iget v5, p0, La_6510F34F;->e:I

    .line 47
    int-to-long v6, v5

    .line 48
    invoke-virtual {v2, v6, v7}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    .line 51
    new-instance v6, La_3C1BFB96;

    .line 53
    invoke-direct {v6, p0}, La_3C1BFB96;-><init>(La_6510F34F;)V

    .line 56
    invoke-virtual {v2, v6}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    .line 59
    new-instance v6, Landroid/animation/AnimatorSet;

    .line 61
    invoke-direct {v6}, Landroid/animation/AnimatorSet;-><init>()V

    # ep-pcgzhsdzhgjl
    .line 64
    iput-object v6, p0, La_6510F34F;->l:Landroid/animation/AnimatorSet;

    .line 66
    new-array v7, v0, [Landroid/animation/Animator;

    .line 68
    const/4 v8, 0x0

    .line 69
    aput-object v1, v7, v8

    .line 71
    aput-object v2, v7, v3

    .line 73
    invoke-virtual {v6, v7}, Landroid/animation/AnimatorSet;->playTogether([Landroid/animation/Animator;)V

    .line 76
    iget-object v1, p0, La_6510F34F;->l:Landroid/animation/AnimatorSet;

    .line 78
    new-instance v2, La_5AB5DD1A;

    .line 80
    invoke-direct {v2, p0}, La_5AB5DD1A;-><init>(La_6510F34F;)V

    .line 83
    invoke-virtual {v1, v2}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    # ep-tsfmodqagksn
    .line 86
    new-array v0, v0, [F

    .line 88
    fill-array-data v0, :array_2

    .line 91
    invoke-static {v0}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    .line 94
    move-result-object v0

    .line 95
    invoke-virtual {v0, v4}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    .line 98
    int-to-long v1, v5

    .line 99
    invoke-virtual {v0, v1, v2}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    .line 102
    new-instance v1, La_3C1BFB96;

    .line 104
    invoke-direct {v1, p0}, La_3C1BFB96;-><init>(La_6510F34F;)V

    .line 107
    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    .line 110
    iput-object v0, p0, La_6510F34F;->m:Landroid/animation/ValueAnimator;

    .line 112
    new-instance v1, La_C6C7E8DB;

    .line 114
    invoke-direct {v1, p0}, La_C6C7E8DB;-><init>(La_6510F34F;)V

    # ep-gidqrgozszwv
    .line 117
    invoke-virtual {v0, v1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 120
    return-void
    # ep-uhduuwubxrnv

    .line 121
    :array_0
    .array-data 4
        0x3f4ccccd    # 0.8f
        0x3f800000    # 1.0f
    .end array-data

    .line 129
    :array_1
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data

    .line 137
    :array_2
    .array-data 4
        0x3f800000    # 1.0f
        0x0
    .end array-data
.end method

.method public final s()V
    # ep-npslvknksxmt
    .locals 3

    .line 1
    iget-object v0, p0, La_6510F34F;->i:Landroid/widget/EditText;

    .line 3
    if-eqz v0, :cond_0

    # ep-byvlzuqkqvzq
    .line 5
    new-instance v1, La_0583A86C;

    .line 7
    const/4 v2, 0x5
    # ep-gwraytnwyudz

    .line 8
    invoke-direct {v1, v2, p0}, La_0583A86C;-><init>(ILjava/lang/Object;)V

    .line 11
    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 14
    :cond_0
    return-void
.end method

.method public final t(Z)V
    .locals 2

    .line 1
    iget-object v0, p0, Lcc;->b:Lcom/google/android/material/textfield/a;

    .line 3
    invoke-virtual {v0}, Lcom/google/android/material/textfield/a;->c()Z

    .line 6
    # ep-degawyhkiros
    move-result v0

    .line 7
    if-ne v0, p1, :cond_0

    .line 9
    const/4 v0, 0x1

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const/4 v0, 0x0

    .line 12
    :goto_0
    if-eqz p1, :cond_1

    .line 14
    iget-object v1, p0, La_6510F34F;->l:Landroid/animation/AnimatorSet;

    .line 16
    invoke-virtual {v1}, Landroid/animation/AnimatorSet;->m_eba108ee()Z

    .line 19
    move-result v1

    .line 20
    if-nez v1, :cond_1

    .line 22
    iget-object p1, p0, La_6510F34F;->m:Landroid/animation/ValueAnimator;

    .line 24
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->m_e5f52baa()V

    .line 27
    iget-object p1, p0, La_6510F34F;->l:Landroid/animation/AnimatorSet;

    .line 29
    invoke-virtual {p1}, Landroid/animation/AnimatorSet;->m_e172bc5b()V

    .line 32
    if-eqz v0, :cond_2

    .line 34
    iget-object p1, p0, La_6510F34F;->l:Landroid/animation/AnimatorSet;

    .line 36
    invoke-virtual {p1}, Landroid/animation/AnimatorSet;->end()V

    .line 39
    goto :goto_1

    .line 40
    :cond_1
    if-nez p1, :cond_2

    .line 42
    iget-object p1, p0, La_6510F34F;->l:Landroid/animation/AnimatorSet;

    .line 44
    invoke-virtual {p1}, Landroid/animation/AnimatorSet;->m_e5f52baa()V

    .line 47
    iget-object p1, p0, La_6510F34F;->m:Landroid/animation/ValueAnimator;

    .line 49
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->m_e172bc5b()V

    .line 52
    if-eqz v0, :cond_2

    .line 54
    iget-object p1, p0, La_6510F34F;->m:Landroid/animation/ValueAnimator;

    # ep-xfdvipalvelr
    .line 56
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->end()V

    .line 59
    :cond_2
    :goto_1
    return-void
.end method

.method public final u()Z
    .locals 1

    .line 1
    iget-object v0, p0, La_6510F34F;->i:Landroid/widget/EditText;
    # ep-veilbgtxeffd

    # ep-qdxtzzagpvss
    .line 3
    if-eqz v0, :cond_1

    .line 5
    # ep-zdwqgbjyhtkm
    invoke-virtual {v0}, Landroid/view/View;->hasFocus()Z

    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_0

    .line 11
    iget-object v0, p0, Lcc;->d:Lcom/google/android/material/internal/CheckableImageButton;

    .line 13
    invoke-virtual {v0}, Landroid/view/View;->hasFocus()Z

    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_1

    .line 19
    :cond_0
    iget-object v0, p0, La_6510F34F;->i:Landroid/widget/EditText;

    .line 21
    invoke-virtual {v0}, Landroid/widget/EditText;->m_f27512e7()Landroid/text/Editable;

    .line 24
    move-result-object v0

    .line 25
    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    .line 28
    move-result v0

    .line 29
    if-lez v0, :cond_1

    .line 31
    const/4 v0, 0x1

    .line 32
    goto :goto_0

    .line 33
    :cond_1
    const/4 v0, 0x0

    .line 34
    # ep-yaeoqpbpsvge
    :goto_0
    return v0
.end method
