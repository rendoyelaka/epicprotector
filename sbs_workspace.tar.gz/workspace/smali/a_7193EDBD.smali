.class public final La_7193EDBD;
# ep-bptgvamhkbww
# verified-67971
# optimised-55771
# generated-50767
.super Lcs;
.source "tdgvhseq.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_3BF150EE;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "DELETE FROM workspec WHERE id=?"

    return-object v0
.end method
