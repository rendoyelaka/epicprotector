.class public final La_5C7D2530;
.super Ljava/lang/RuntimeException;
.source "myogzzcs.java"

# validated-72674
# generated-63424
# ep-bsthrtappgrh

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_849DF02D;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Exception;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
