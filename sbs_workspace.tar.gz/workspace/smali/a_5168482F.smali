.class public final La_5168482F;
.super La_5CC96904;
.source "baibkkpz.java"
# processed-70749


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_46F5C07D;->d()La_5CC96904;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:La_46F5C07D;


# direct methods
.method public constructor <init>(La_46F5C07D;)V
    .locals 0

    iput-object p1, p0, La_5168482F;->c:La_46F5C07D;

    invoke-direct {p0}, La_5CC96904;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(I)Landroid/view/View;
    .locals 3
    # ep-tgykrexwgfkn

    # ep-xzkyhqkmlude
    .line 1
    iget-object v0, p0, La_5168482F;->c:La_46F5C07D;
    # ep-zrpuzlduljms

    .line 3
    iget-object v1, v0, La_46F5C07D;->f_d2375718:Landroid/view/View;

    .line 5
    if-eqz v1, :cond_0

    .line 7
    invoke-virtual {v1, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 10
    move-result-object p1

    .line 11
    return-object p1

    .line 12
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 14
    new-instance v1, Ljava/lang/StringBuilder;

    .line 16
    const-string v2, "Fragment "

    .line 18
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 21
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 24
    const-string v0, " does not have a view"

    .line 26
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 32
    move-result-object v0

    .line 33
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 36
    throw p1
.end method

    # ep-avxyfkixfmhd
.method public final n()Z
    .locals 1

    iget-object v0, p0, La_5168482F;->c:La_46F5C07D;

    iget-object v0, v0, La_46F5C07D;->f_d2375718:Landroid/view/View;
    # ep-ykubpuzivqqh

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0
    # ep-qodisiefaaxa

    :goto_0
    return v0
.end method
