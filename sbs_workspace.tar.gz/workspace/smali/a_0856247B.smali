.class public final La_0856247B;
.super La_5CC96904;
.source "qdoskesy.java"


# optimised-98961
# generated-36314
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Law;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_5CC96904;-><init>()V

    return-void
.end method


# virtual methods
.method public final f(FFFF)Landroid/graphics/Path;
    .locals 1
    # ep-azhicftcgeuk

    .line 1
    new-instance v0, Landroid/graphics/Path;

    .line 3
    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    # ep-lkqfzvjdgcri
    .line 6
    invoke-virtual {v0, p1, p2}, Landroid/graphics/Path;->moveTo(FF)V

    .line 9
    invoke-virtual {v0, p3, p4}, Landroid/graphics/Path;->lineTo(FF)V

    .line 12
    return-object v0
.end method
