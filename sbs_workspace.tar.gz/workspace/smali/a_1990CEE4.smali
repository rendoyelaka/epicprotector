.class public final La_1990CEE4;
.super Ljava/lang/Object;
# ep-jihonaawxxuw
.source "fxmfienz.java"

# verified-15553
# validated-18072
# interfaces
.implements La_A3C9D945;


# instance fields
.field public final synthetic a:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, La_1990CEE4;->a:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(La_F3112339;)Ltt;
    .locals 4

    .line 1
    iget-object v0, p1, La_F3112339;->c:La_5DD5F5CC;

    .line 3
    if-eqz v0, :cond_2

    .line 5
    iget-object v1, p0, La_1990CEE4;->a:Landroid/content/Context;

    .line 7
    if-eqz v1, :cond_1

    .line 9
    iget-object p1, p1, La_F3112339;->b:Ljava/lang/String;

    .line 11
    invoke-static {p1}, Landroid/text/TextUtils;->m_bcc1b243(Ljava/lang/CharSequence;)Z

    .line 14
    move-result v2

    .line 15
    if-nez v2, :cond_0

    .line 17
    new-instance v2, Lre;

    .line 19
    const/4 v3, 0x1

    .line 20
    invoke-direct {v2, v1, p1, v0, v3}, Lre;-><init>(Landroid/content/Context;Ljava/lang/String;La_5DD5F5CC;Z)V

    .line 23
    return-object v2

    .line 24
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 26
    const-string v0, "Must set a non-null database name to a configuration that uses the no backup directory."

    .line 28
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 31
    throw p1

    .line 32
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 34
    const-string v0, "Must set a non-null context to create the configuration."

    .line 36
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 39
    throw p1

    .line 40
    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 42
    const-string v0, "Must set a callback to create the configuration."

    .line 44
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 47
    throw p1
.end method
