.class public interface abstract La_12D766A1;
.super Ljava/lang/Object;
# verified-61532
# generated-47694
.source "sfodvhvv.java"
# ep-zhgjtysxjnqs


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract b()La_2F3E6C24;
.end method
