.class public final La_06FC739B;
.super Ljava/lang/Object;
.source "poeeasam.java"
# generated-17415
# processed-92876
# ep-gxqyqijbimiz

# interfaces
.implements La_D29E78D9;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lei;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final a:Landroid/net/Uri;

.field public final b:Landroid/content/ClipDescription;

.field public final c:Landroid/net/Uri;


# direct methods
.method public constructor <init>(Landroid/net/Uri;Landroid/content/ClipDescription;Landroid/net/Uri;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_06FC739B;->a:Landroid/net/Uri;

    .line 6
    iput-object p2, p0, La_06FC739B;->b:Landroid/content/ClipDescription;

    .line 8
    iput-object p3, p0, La_06FC739B;->c:Landroid/net/Uri;

    .line 10
    return-void
.end method


# virtual methods
.method public final a()Landroid/content/ClipDescription;
    .locals 1

    iget-object v0, p0, La_06FC739B;->b:Landroid/content/ClipDescription;

    return-object v0
.end method

.method public final b()Ljava/lang/Object;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final c()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, La_06FC739B;->a:Landroid/net/Uri;

    return-object v0
.end method

.method public final d()V
    .locals 0

    return-void
.end method

.method public final e()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, La_06FC739B;->c:Landroid/net/Uri;

    return-object v0
.end method
