.class public interface abstract La_59CA130D;
.super Ljava/lang/Object;
# ep-cgjgkqqhxaks
.source "fxtjheek.java"
# optimised-59194
# verified-68610


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method
