.class public interface abstract La_8FA807FE;
.super Ljava/lang/Object;
.source "znuzechl.java"


# optimised-77466
# generated-38581
# virtual methods
.method public abstract e()V
.end method

.method public abstract h()V
.end method

.method public abstract k()V
.end method
