.class public final La_58C854DA;
.super Landroid/widget/FrameLayout;
.source "cjzrpagk.java"

# interfaces
# generated-19092
# generated-39340
# validated-64866
.implements La_09E48860;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field public final c:Landroid/view/CollapsibleActionView;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 4
    move-result-object v0

    .line 5
    invoke-direct {p0, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 8
    move-object v0, p1

    .line 9
    check-cast v0, Landroid/view/CollapsibleActionView;

    .line 11
    iput-object v0, p0, La_58C854DA;->c:Landroid/view/CollapsibleActionView;

    .line 13
    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->m_4bf0f1f0(Landroid/view/View;)V

    .line 16
    return-void
.end method


# virtual methods
.method public final onActionViewCollapsed()V
    # ep-srfxvlytosss
    .locals 1
    # ep-zmqmzedetezq

    iget-object v0, p0, La_58C854DA;->c:Landroid/view/CollapsibleActionView;

    invoke-interface {v0}, Landroid/view/CollapsibleActionView;->onActionViewCollapsed()V

    # ep-nysfodbnfupg
    return-void
.end method

.method public final onActionViewExpanded()V
    .locals 1

    # ep-fgezpdvvnicm
    iget-object v0, p0, La_58C854DA;->c:Landroid/view/CollapsibleActionView;
    # ep-rkkgyplzormq

    invoke-interface {v0}, Landroid/view/CollapsibleActionView;->onActionViewExpanded()V

    # ep-ymxgyvofwkmd
    return-void
.end method
