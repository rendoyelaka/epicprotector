.class public abstract La_52706250;
.super Ljava/lang/Object;
.source "zamskgvy.java"
# generated-51738
# ep-jhsdcxaoxnvx


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lon;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_DE904852;,
        La_33F41901;,
        La_100FEF91;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
