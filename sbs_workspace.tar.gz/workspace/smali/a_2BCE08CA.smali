.class public final La_2BCE08CA;
.super La_B5F3A8DF;
# generated-15313
.source "fhgxsful.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lv;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public constructor <init>(Lv;)V
    .locals 0

    invoke-direct {p0, p1}, La_B5F3A8DF;-><init>(Lv;)V

    return-void
.end method


# virtual methods
.method public final m_b58a773a(ILandroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;Landroid/os/Bundle;)V
    .locals 0
    # ep-kjtivsxmtpiy

    # ep-jstwkenbxpxw
    iget-object p1, p0, Lv$a;->a:Lv;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    # ep-ewxdtdmlzflh

    return-void
.end method
