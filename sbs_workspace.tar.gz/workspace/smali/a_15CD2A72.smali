.class public final La_15CD2A72;
# ep-roxcyclmqucd
.super Ljava/lang/Object;
.source "rmexicin.java"
# compiled-68389
# verified-87236


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_6B590370;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "e"
.end annotation


# direct methods
.method public static a(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/ComponentName;
    .locals 0

    invoke-static {p0, p1}, Ln;->e(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/ComponentName;

    move-result-object p0

    return-object p0
.end method
