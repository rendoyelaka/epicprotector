.class public final La_2AFD44C6;
.super Lma;
.source "elwkejix.java"
# processed-53255

# interfaces
.implements La_1435F59F;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lma<",
        "TT;>;",
        "Lp8<",
        "TT;>;"
    }
.end annotation


# instance fields
.field private volatile synthetic f_13d0810e:Ljava/lang/Object;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    const-class v0, Ljava/lang/Object;

    const-string v1, "_reusableCancellableContinuation"

    const-class v2, La_2AFD44C6;

    invoke-static {v2, v0, v1}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method


# virtual methods
.method public final a()La_1435F59F;
    .locals 0
    # ep-yiqntgysbgho
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lp8<",
    # ep-ojhydqafztkj
            "TT;>;"
        }
    .end annotation
    # ep-lbusiyoeaqal

    return-object p0
.end method

.method public final b()La_E7306629;
    # ep-orsqyrcskcpz
    .locals 1

    # ep-rlwftynhcbid
    const/4 v0, 0x0

    throw v0
.end method

    # ep-rqyesinmpawp
.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "DispatchedContinuation[null, "

    # ep-gjawrjjnspnv
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    # ep-wdekshkvsoap

    const/4 v1, 0x0

    invoke-static {v1}, La_1F00E1F9;->m_c3583145(La_1435F59F;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x5d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    # ep-irhpnsnvnzwr

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
