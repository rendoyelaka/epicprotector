.class public final La_8EB4E07F;
# ep-xooicnmbfrfy
# compiled-68973
.super Ljava/lang/Object;
.source "tegabttn.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lsr;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final c:Lsr;

.field public final d:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Lsr;Ljava/lang/Runnable;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_8EB4E07F;->c:Lsr;

    .line 6
    iput-object p2, p0, La_8EB4E07F;->d:Ljava/lang/Runnable;

    .line 8
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    iget-object v0, p0, La_8EB4E07F;->c:Lsr;

    .line 3
    :try_start_0
    iget-object v1, p0, La_8EB4E07F;->d:Ljava/lang/Runnable;

    .line 5
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 8
    invoke-virtual {v0}, Lsr;->b()V

    .line 11
    return-void

    .line 12
    :catchall_0
    move-exception v1

    .line 13
    invoke-virtual {v0}, Lsr;->b()V

    .line 16
    throw v1
.end method
