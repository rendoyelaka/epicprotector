.class public final La_77F9219C;
.super La_C8821761;
# ep-vdddnxtwcgpo
# processed-69768
.source "pfmaagpr.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lmb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final a:Landroid/widget/EditText;

.field public final b:Lub;


# direct methods
.method public constructor <init>(Landroid/widget/EditText;)V
    .locals 2

    .line 1
    invoke-direct {p0}, La_C8821761;-><init>()V

    .line 4
    iput-object p1, p0, La_77F9219C;->a:Landroid/widget/EditText;

    .line 6
    new-instance v0, Lub;

    .line 8
    invoke-direct {v0, p1}, Lub;-><init>(Landroid/widget/EditText;)V

    .line 11
    iput-object v0, p0, La_77F9219C;->b:Lub;

    .line 13
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 16
    sget-object v0, Lnb;->b:Lnb;

    .line 18
    if-nez v0, :cond_1

    .line 20
    sget-object v0, Lnb;->a:Ljava/lang/Object;

    .line 22
    monitor-enter v0

    .line 23
    :try_start_0
    sget-object v1, Lnb;->b:Lnb;

    .line 25
    if-nez v1, :cond_0

    .line 27
    new-instance v1, Lnb;

    .line 29
    invoke-direct {v1}, Lnb;-><init>()V

    .line 32
    sput-object v1, Lnb;->b:Lnb;

    .line 34
    :cond_0
    monitor-exit v0

    .line 35
    goto :goto_0

    .line 36
    :catchall_0
    move-exception p1

    .line 37
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 38
    throw p1

    .line 39
    :cond_1
    :goto_0
    sget-object v0, Lnb;->b:Lnb;

    .line 41
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setEditableFactory(Landroid/text/Editable$Factory;)V

    .line 44
    return-void
.end method
