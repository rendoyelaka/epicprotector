.class public final LWorkManagerImpl;
.super Ln00;
# validated-54410
# generated-58422
.source "vekxhsrd.java"
# ep-iafkurtzcapw


# static fields
.field public static l:LWorkManagerImpl;

.field public static m:LWorkManagerImpl;

.field public static final n:Ljava/lang/Object;


# instance fields
.field public c:Landroid/content/Context;

.field public d:Landroidx/work/a;

.field public e:Landroidx/work/impl/WorkDatabase;

.field public f:Lnu;

.field public g:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lhr;",
            ">;"
        }
    .end annotation
.end field

.field public h:Luo;

.field public i:Lqo;

.field public j:Z

.field public k:Landroid/content/BroadcastReceiver$PendingResult;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 1
    const-string v1, "8GOM/M8Jjunqz2qZhLzF"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    const/4 v0, 0x0

    .line 7
    sput-object v0, LWorkManagerImpl;->l:LWorkManagerImpl;

    .line 9
    sput-object v0, LWorkManagerImpl;->m:LWorkManagerImpl;

    .line 11
    new-instance v0, Ljava/lang/Object;

    .line 13
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 16
    sput-object v0, LWorkManagerImpl;->n:Ljava/lang/Object;

    .line 18
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/work/a;Lp00;)V
    .locals 26

    .line 1
    move-object/from16 v1, p0

    .line 3
    move-object/from16 v8, p2

    .line 5
    move-object/from16 v9, p3

    .line 7
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 10
    move-result-object v0

    .line 11
    const v2, 0x7f040006

    .line 14
    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getBoolean(I)Z

    .line 17
    move-result v0

    .line 18
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 21
    move-result-object v2

    .line 22
    iget-object v3, v9, Lp00;->a:Lsr;

    .line 24
    sget v4, Landroidx/work/impl/WorkDatabase;->k:I

    .line 26
    const/4 v4, 0x0

    .line 27
    const/4 v5, 0x1

    .line 28
    if-eqz v0, :cond_0

    .line 30
    new-instance v0, Ljq$a;

    .line 32
    invoke-direct {v0, v2, v4}, Ljq$a;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 35
    iput-boolean v5, v0, Ljq$a;->h:Z

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    sget-object v0, Li00;->a:[Ljava/lang/String;

    .line 40
    new-instance v0, Ljq$a;

    .line 42
    const-string v25, "xmKa5e0BhPCj3XeiguLeQzM9V5E="
    invoke-static {v25}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v6

    .line 44
    invoke-direct {v0, v2, v6}, Ljq$a;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 47
    new-instance v6, Lg00;

    .line 49
    invoke-direct {v6, v2}, Lg00;-><init>(Landroid/content/Context;)V

    .line 52
    iput-object v6, v0, Ljq$a;->g:Ltt$c;

    .line 54
    :goto_0
    iput-object v3, v0, Ljq$a;->e:Ljava/util/concurrent/Executor;

    .line 56
    new-instance v3, Lh00;

    .line 58
    invoke-direct {v3}, Lh00;-><init>()V

    .line 61
    iget-object v6, v0, Ljq$a;->d:Ljava/util/ArrayList;

    .line 63
    if-nez v6, :cond_1

    .line 65
    new-instance v6, Ljava/util/ArrayList;

    .line 67
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 70
    iput-object v6, v0, Ljq$a;->d:Ljava/util/ArrayList;

    .line 72
    :cond_1
    iget-object v6, v0, Ljq$a;->d:Ljava/util/ArrayList;

    .line 74
    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 77
    new-array v3, v5, [Lsl;

    .line 79
    sget-object v6, Landroidx/work/impl/a;->a:Landroidx/work/impl/a$a;

    .line 81
    const/4 v10, 0x0

    .line 82
    aput-object v6, v3, v10

    .line 84
    invoke-virtual {v0, v3}, Ljq$a;->a([Lsl;)V

    .line 87
    new-array v3, v5, [Lsl;

    .line 89
    new-instance v6, Landroidx/work/impl/a$h;

    .line 91
    const/4 v7, 0x2

    .line 92
    const/4 v11, 0x3

    .line 93
    invoke-direct {v6, v2, v7, v11}, Landroidx/work/impl/a$h;-><init>(Landroid/content/Context;II)V

    .line 96
    aput-object v6, v3, v10

    .line 98
    invoke-virtual {v0, v3}, Ljq$a;->a([Lsl;)V

    .line 101
    new-array v3, v5, [Lsl;

    .line 103
    sget-object v6, Landroidx/work/impl/a;->b:Landroidx/work/impl/a$b;

    .line 105
    aput-object v6, v3, v10

    .line 107
    invoke-virtual {v0, v3}, Ljq$a;->a([Lsl;)V

    .line 110
    new-array v3, v5, [Lsl;

    .line 112
    sget-object v6, Landroidx/work/impl/a;->c:Landroidx/work/impl/a$c;

    .line 114
    aput-object v6, v3, v10

    .line 116
    invoke-virtual {v0, v3}, Ljq$a;->a([Lsl;)V

    .line 119
    new-array v3, v5, [Lsl;

    .line 121
    new-instance v6, Landroidx/work/impl/a$h;

    .line 123
    const/4 v12, 0x5

    .line 124
    const/4 v13, 0x6

    .line 125
    invoke-direct {v6, v2, v12, v13}, Landroidx/work/impl/a$h;-><init>(Landroid/content/Context;II)V

    .line 128
    aput-object v6, v3, v10

    .line 130
    invoke-virtual {v0, v3}, Ljq$a;->a([Lsl;)V

    .line 133
    new-array v3, v5, [Lsl;

    .line 135
    sget-object v6, Landroidx/work/impl/a;->d:Landroidx/work/impl/a$d;

    .line 137
    aput-object v6, v3, v10

    .line 139
    invoke-virtual {v0, v3}, Ljq$a;->a([Lsl;)V

    .line 142
    new-array v3, v5, [Lsl;

    .line 144
    sget-object v6, Landroidx/work/impl/a;->e:Landroidx/work/impl/a$e;

    .line 146
    aput-object v6, v3, v10

    .line 148
    invoke-virtual {v0, v3}, Ljq$a;->a([Lsl;)V

    .line 151
    new-array v3, v5, [Lsl;

    .line 153
    sget-object v6, Landroidx/work/impl/a;->f:Landroidx/work/impl/a$f;

    .line 155
    aput-object v6, v3, v10

    .line 157
    invoke-virtual {v0, v3}, Ljq$a;->a([Lsl;)V

    .line 160
    new-array v3, v5, [Lsl;

    .line 162
    new-instance v6, Landroidx/work/impl/a$i;

    .line 164
    invoke-direct {v6, v2}, Landroidx/work/impl/a$i;-><init>(Landroid/content/Context;)V

    .line 167
    aput-object v6, v3, v10

    .line 169
    invoke-virtual {v0, v3}, Ljq$a;->a([Lsl;)V

    .line 172
    new-array v3, v5, [Lsl;

    .line 174
    new-instance v6, Landroidx/work/impl/a$h;

    .line 176
    const/16 v12, 0xa

    .line 178
    const/16 v13, 0xb

    .line 180
    invoke-direct {v6, v2, v12, v13}, Landroidx/work/impl/a$h;-><init>(Landroid/content/Context;II)V

    .line 183
    aput-object v6, v3, v10

    .line 185
    invoke-virtual {v0, v3}, Ljq$a;->a([Lsl;)V

    .line 188
    new-array v2, v5, [Lsl;

    .line 190
    sget-object v3, Landroidx/work/impl/a;->g:Landroidx/work/impl/a$g;

    .line 192
    aput-object v3, v2, v10

    .line 194
    invoke-virtual {v0, v2}, Ljq$a;->a([Lsl;)V

    .line 197
    iput-boolean v10, v0, Ljq$a;->i:Z

    .line 199
    iput-boolean v5, v0, Ljq$a;->j:Z

    .line 201
    iget-object v13, v0, Ljq$a;->c:Landroid/content/Context;

    .line 203
    if-eqz v13, :cond_10

    .line 205
    iget-object v2, v0, Ljq$a;->a:Ljava/lang/Class;

    .line 207
    if-eqz v2, :cond_f

    .line 209
    iget-object v3, v0, Ljq$a;->e:Ljava/util/concurrent/Executor;

    .line 211
    if-nez v3, :cond_2

    .line 213
    iget-object v6, v0, Ljq$a;->f:Ljava/util/concurrent/Executor;

    .line 215
    if-nez v6, :cond_2

    .line 217
    sget-object v3, Le3;->e:Le3$a;

    .line 219
    iput-object v3, v0, Ljq$a;->f:Ljava/util/concurrent/Executor;

    .line 221
    iput-object v3, v0, Ljq$a;->e:Ljava/util/concurrent/Executor;

    .line 223
    goto :goto_1

    .line 224
    :cond_2
    if-eqz v3, :cond_3

    .line 226
    iget-object v6, v0, Ljq$a;->f:Ljava/util/concurrent/Executor;

    .line 228
    if-nez v6, :cond_3

    .line 230
    iput-object v3, v0, Ljq$a;->f:Ljava/util/concurrent/Executor;

    .line 232
    goto :goto_1

    .line 233
    :cond_3
    if-nez v3, :cond_4

    .line 235
    iget-object v3, v0, Ljq$a;->f:Ljava/util/concurrent/Executor;

    .line 237
    if-eqz v3, :cond_4

    .line 239
    iput-object v3, v0, Ljq$a;->e:Ljava/util/concurrent/Executor;

    .line 241
    :cond_4
    :goto_1
    iget-object v3, v0, Ljq$a;->g:Ltt$c;

    .line 243
    if-nez v3, :cond_5

    .line 245
    new-instance v3, Lse;

    .line 247
    invoke-direct {v3}, Lse;-><init>()V

    .line 250
    iput-object v3, v0, Ljq$a;->g:Ltt$c;

    .line 252
    :cond_5
    new-instance v3, Li9;

    .line 254
    iget-object v14, v0, Ljq$a;->b:Ljava/lang/String;

    .line 256
    iget-object v15, v0, Ljq$a;->g:Ltt$c;

    .line 258
    iget-object v6, v0, Ljq$a;->k:Ljq$c;

    .line 260
    iget-object v12, v0, Ljq$a;->d:Ljava/util/ArrayList;

    .line 262
    iget-boolean v4, v0, Ljq$a;->h:Z

    .line 264
    const-string v25, "xm+K/vQBlPE="
    invoke-static {v25}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v10

    .line 266
    invoke-virtual {v13, v10}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 269
    move-result-object v10

    .line 270
    check-cast v10, Landroid/app/ActivityManager;

    .line 272
    if-eqz v10, :cond_6

    .line 274
    invoke-virtual {v10}, Landroid/app/ActivityManager;->isLowRamDevice()Z

    .line 277
    move-result v10

    .line 278
    if-nez v10, :cond_6

    .line 280
    const/4 v10, 0x3

    .line 281
    goto :goto_2

    .line 282
    :cond_6
    const/4 v10, 0x2

    .line 283
    :goto_2
    iget-object v7, v0, Ljq$a;->e:Ljava/util/concurrent/Executor;

    .line 285
    iget-object v11, v0, Ljq$a;->f:Ljava/util/concurrent/Executor;

    .line 287
    iget-boolean v5, v0, Ljq$a;->i:Z

    .line 289
    iget-boolean v0, v0, Ljq$a;->j:Z

    .line 291
    move-object/from16 v24, v12

    .line 293
    move-object v12, v3

    .line 294
    move-object/from16 v16, v6

    .line 296
    move-object/from16 v17, v24

    .line 298
    move/from16 v18, v4

    .line 300
    move/from16 v19, v10

    .line 302
    move-object/from16 v20, v7

    .line 304
    move-object/from16 v21, v11

    .line 306
    move/from16 v22, v5

    .line 308
    move/from16 v23, v0

    .line 310
    invoke-direct/range {v12 .. v23}, Li9;-><init>(Landroid/content/Context;Ljava/lang/String;Ltt$c;Ljq$c;Ljava/util/ArrayList;ZILjava/util/concurrent/Executor;Ljava/util/concurrent/Executor;ZZ)V

    .line 313
    invoke-virtual {v2}, Ljava/lang/Class;->getPackage()Ljava/lang/Package;

    .line 316
    move-result-object v0

    .line 317
    invoke-virtual {v0}, Ljava/lang/Package;->getName()Ljava/lang/String;

    .line 320
    move-result-object v0

    .line 321
    invoke-virtual {v2}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 324
    move-result-object v5

    .line 325
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 328
    move-result v6

    .line 329
    if-eqz v6, :cond_7

    .line 331
    goto :goto_3

    .line 332
    :cond_7
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 335
    move-result v6

    .line 336
    const/4 v11, 0x1

    .line 337
    add-int/2addr v6, v11

    .line 338
    invoke-virtual {v5, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 341
    move-result-object v5

    .line 342
    :goto_3
    new-instance v6, Ljava/lang/StringBuilder;

    .line 344
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 347
    const/16 v11, 0x2e

    .line 349
    const/16 v12, 0x5f

    .line 351
    invoke-virtual {v5, v11, v12}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    .line 354
    move-result-object v5

    .line 355
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 358
    const-string v25, "+EWT5+4="
    invoke-static {v25}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v5

    .line 360
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 363
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 366
    move-result-object v5

    .line 367
    :try_start_0
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 370
    move-result v6

    .line 371
    if-eqz v6, :cond_8

    .line 373
    move-object v0, v5

    .line 374
    goto :goto_4

    .line 375
    :cond_8
    new-instance v6, Ljava/lang/StringBuilder;

    .line 377
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 380
    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 383
    const-string v0, "."

    .line 385
    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 388
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 391
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 394
    move-result-object v0

    .line 395
    :goto_4
    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 398
    move-result-object v0

    .line 399
    invoke-virtual {v0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    .line 402
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_0

    .line 403
    check-cast v0, Ljq;

    .line 405
    invoke-virtual {v0, v3}, Ljq;->e(Li9;)Ltt;

    .line 408
    move-result-object v2

    .line 409
    iput-object v2, v0, Ljq;->c:Ltt;

    .line 411
    instance-of v5, v2, Lvq;

    .line 413
    if-eqz v5, :cond_9

    .line 415
    move-object v5, v2

    .line 416
    check-cast v5, Lvq;

    .line 418
    iput-object v3, v5, Lvq;->c:Li9;

    .line 420
    :cond_9
    const/4 v3, 0x3

    .line 421
    if-ne v10, v3, :cond_a

    .line 423
    const/4 v3, 0x1

    .line 424
    goto :goto_5

    .line 425
    :cond_a
    const/4 v3, 0x0

    .line 426
    :goto_5
    invoke-interface {v2, v3}, Ltt;->setWriteAheadLoggingEnabled(Z)V

    .line 429
    move-object/from16 v2, v24

    .line 431
    iput-object v2, v0, Ljq;->g:Ljava/util/List;

    .line 433
    iput-object v7, v0, Ljq;->b:Ljava/util/concurrent/Executor;

    .line 435
    new-instance v2, Ljava/util/ArrayDeque;

    .line 437
    invoke-direct {v2}, Ljava/util/ArrayDeque;-><init>()V

    .line 440
    iput-boolean v4, v0, Ljq;->e:Z

    .line 442
    iput-boolean v3, v0, Ljq;->f:Z

    .line 444
    move-object v10, v0

    .line 445
    check-cast v10, Landroidx/work/impl/WorkDatabase;

    .line 447
    invoke-direct/range {p0 .. p0}, Ln00;-><init>()V

    .line 450
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 453
    move-result-object v2

    .line 454
    new-instance v0, Ltj$a;

    .line 456
    iget v3, v8, Landroidx/work/a;->f:I

    .line 458
    invoke-direct {v0, v3}, Ltj$a;-><init>(I)V

    .line 461
    const-class v3, Ltj;

    .line 463
    monitor-enter v3

    .line 464
    :try_start_1
    sput-object v0, Ltj;->a:Ltj;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 466
    monitor-exit v3

    .line 467
    const/4 v0, 0x2

    .line 468
    new-array v3, v0, [Lhr;

    .line 470
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 472
    sget v4, LSchedulers;->a:I

    .line 474
    const/16 v4, 0x17

    .line 476
    if-lt v0, v4, :cond_b

    .line 478
    new-instance v0, Lhu;

    .line 480
    invoke-direct {v0, v2, v1}, Lhu;-><init>(Landroid/content/Context;LWorkManagerImpl;)V

    .line 483
    const-class v4, Landroidx/work/impl/background/systemjob/SystemJobService;

    .line 485
    const/4 v5, 0x1

    .line 486
    invoke-static {v2, v4, v5}, Lqn;->a(Landroid/content/Context;Ljava/lang/Class;Z)V

    .line 489
    invoke-static {}, Ltj;->c()Ltj;

    .line 492
    move-result-object v4

    .line 493
    const/4 v6, 0x0

    .line 494
    new-array v7, v6, [Ljava/lang/Throwable;

    .line 496
    invoke-virtual {v4, v7}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 499
    const/4 v7, 0x0

    .line 500
    goto :goto_7

    .line 501
    :cond_b
    const/4 v5, 0x1

    .line 502
    :try_start_2
    const-string v25, "xmKa5e0BhPCj3XeiguLAQTE6HZFDGO5XfDtEN9pEe0rKIrn07zuD4OjObbyMvg=="
    invoke-static {v25}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 504
    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 507
    move-result-object v0

    .line 508
    new-array v4, v5, [Ljava/lang/Class;

    .line 510
    const-class v6, Landroid/content/Context;

    .line 512
    const/4 v7, 0x0

    .line 513
    aput-object v6, v4, v7

    .line 515
    invoke-virtual {v0, v4}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 518
    move-result-object v0

    .line 519
    new-array v4, v5, [Ljava/lang/Object;

    .line 521
    aput-object v2, v4, v7

    .line 523
    invoke-virtual {v0, v4}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 526
    move-result-object v0

    .line 527
    check-cast v0, Lhr;

    .line 529
    invoke-static {}, Ltj;->c()Ltj;

    .line 532
    move-result-object v4

    .line 533
    const-string v25, "5H6b9vYNhKio2Q=="
    invoke-static {v25}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v5

    .line 535
    const/4 v6, 0x1

    .line 536
    new-array v7, v6, [Ljava/lang/Object;

    .line 538
    const-string v25, "xmKa5e0BhPCj3XeiguLAQTE6HZFDGO5XfDtEN9pEe0rKIrn07zuD4OjObbyMvg=="
    invoke-static {v25}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v6

    .line 540
    const/4 v11, 0x0

    .line 541
    aput-object v6, v7, v11

    .line 543
    invoke-static {v5, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 546
    new-array v5, v11, [Ljava/lang/Throwable;

    .line 548
    invoke-virtual {v4, v5}, Ltj;->a([Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 551
    move-object v4, v0

    .line 552
    const/4 v5, 0x1

    .line 553
    const/4 v7, 0x0

    .line 554
    goto :goto_6

    .line 555
    :catchall_0
    move-exception v0

    .line 556
    invoke-static {}, Ltj;->c()Ltj;

    .line 559
    move-result-object v4

    .line 560
    const/4 v5, 0x1

    .line 561
    new-array v6, v5, [Ljava/lang/Throwable;

    .line 563
    const/4 v7, 0x0

    .line 564
    aput-object v0, v6, v7

    .line 566
    invoke-virtual {v4, v6}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 569
    const/4 v4, 0x0

    .line 570
    :goto_6
    if-nez v4, :cond_c

    .line 572
    new-instance v0, LSystemAlarmScheduler;

    .line 574
    invoke-direct {v0, v2}, LSystemAlarmScheduler;-><init>(Landroid/content/Context;)V

    .line 577
    const-class v4, Landroidx/work/impl/background/systemalarm/SystemAlarmService;

    .line 579
    invoke-static {v2, v4, v5}, Lqn;->a(Landroid/content/Context;Ljava/lang/Class;Z)V

    .line 582
    invoke-static {}, Ltj;->c()Ltj;

    .line 585
    move-result-object v4

    .line 586
    new-array v6, v7, [Ljava/lang/Throwable;

    .line 588
    invoke-virtual {v4, v6}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 591
    goto :goto_7

    .line 592
    :cond_c
    move-object v0, v4

    .line 593
    :goto_7
    aput-object v0, v3, v7

    .line 595
    new-instance v0, LGreedyScheduler;

    .line 597
    invoke-direct {v0, v2, v8, v9, v1}, LGreedyScheduler;-><init>(Landroid/content/Context;Landroidx/work/a;Lp00;LWorkManagerImpl;)V

    .line 600
    aput-object v0, v3, v5

    .line 602
    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 605
    move-result-object v0

    .line 606
    new-instance v11, Luo;

    .line 608
    move-object v2, v11

    .line 609
    move-object/from16 v3, p1

    .line 611
    move-object/from16 v4, p2

    .line 613
    move-object/from16 v5, p3

    .line 615
    move-object v6, v10

    .line 616
    move-object v7, v0

    .line 617
    invoke-direct/range {v2 .. v7}, Luo;-><init>(Landroid/content/Context;Landroidx/work/a;Lp00;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V

    .line 620
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 623
    move-result-object v2

    .line 624
    iput-object v2, v1, LWorkManagerImpl;->c:Landroid/content/Context;

    .line 626
    iput-object v8, v1, LWorkManagerImpl;->d:Landroidx/work/a;

    .line 628
    iput-object v9, v1, LWorkManagerImpl;->f:Lnu;

    .line 630
    iput-object v10, v1, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 632
    iput-object v0, v1, LWorkManagerImpl;->g:Ljava/util/List;

    .line 634
    iput-object v11, v1, LWorkManagerImpl;->h:Luo;

    .line 636
    new-instance v0, Lqo;

    .line 638
    invoke-direct {v0, v10}, Lqo;-><init>(Landroidx/work/impl/WorkDatabase;)V

    .line 641
    iput-object v0, v1, LWorkManagerImpl;->i:Lqo;

    .line 643
    const/4 v3, 0x0

    .line 644
    iput-boolean v3, v1, LWorkManagerImpl;->j:Z

    .line 646
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 648
    const/16 v3, 0x18

    .line 650
    if-lt v0, v3, :cond_e

    .line 652
    invoke-static {v2}, Lt;->w(Landroid/content/Context;)Z

    .line 655
    move-result v0

    .line 656
    if-nez v0, :cond_d

    .line 658
    goto :goto_8

    .line 659
    :cond_d
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 661
    const-string v25, "5G2Q+e0cwOHjw2y5iKDAViR2ZJxQEMhRYDVWPMxKdUeHaJfl5wuUqO/Fd6TJocZIJA=="
    invoke-static {v25}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 663
    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 666
    throw v0

    .line 667
    :cond_e
    :goto_8
    iget-object v0, v1, LWorkManagerImpl;->f:Lnu;

    .line 669
    new-instance v3, Landroidx/work/impl/utils/ForceStopRunnable;

    .line 671
    invoke-direct {v3, v2, v1}, Landroidx/work/impl/utils/ForceStopRunnable;-><init>(Landroid/content/Context;LWorkManagerImpl;)V

    .line 674
    check-cast v0, Lp00;

    .line 676
    invoke-virtual {v0, v3}, Lp00;->a(Ljava/lang/Runnable;)V

    .line 679
    return-void

    .line 680
    :catchall_1
    move-exception v0

    .line 681
    move-object v2, v0

    .line 682
    monitor-exit v3

    .line 683
    throw v2

    .line 684
    :catch_0
    new-instance v0, Ljava/lang/RuntimeException;

    .line 686
    new-instance v3, Ljava/lang/StringBuilder;

    .line 688
    const-string v25, "4W2X++cMwPziinuijK3dSWE3XdNLFfZEbzpSPJ4Fegk="
    invoke-static {v25}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4

    .line 690
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 693
    invoke-virtual {v2}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 696
    move-result-object v2

    .line 697
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 700
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 703
    move-result-object v2

    .line 704
    invoke-direct {v0, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 707
    throw v0

    .line 708
    :catch_1
    new-instance v0, Ljava/lang/RuntimeException;

    .line 710
    new-instance v3, Ljava/lang/StringBuilder;

    .line 712
    const-string v25, "5G2Q+e0cwOnuyX2jmuzdRCR2UJxMCPFCezdFNsw="
    invoke-static {v25}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4

    .line 714
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 717
    invoke-virtual {v2}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 720
    move-result-object v2

    .line 721
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 724
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 727
    move-result-object v2

    .line 728
    invoke-direct {v0, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 731
    throw v0

    .line 732
    :catch_2
    new-instance v0, Ljava/lang/RuntimeException;

    .line 734
    new-instance v3, Ljava/lang/StringBuilder;

    .line 736
    const-string v25, "xG2Q+e0cwO7kxHzwgKHZQCQ7Vp1WGvFZYToRP9EYPA=="
    invoke-static {v25}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4

    .line 738
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 741
    invoke-virtual {v2}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 744
    move-result-object v2

    .line 745
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 748
    const-string v25, "iSw="
    invoke-static {v25}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 750
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 753
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 756
    const-string v25, "h2iR8vFIjuf5in2ogL/d"
    invoke-static {v25}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 758
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 761
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 764
    move-result-object v2

    .line 765
    invoke-direct {v0, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 768
    throw v0

    .line 769
    :cond_f
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 771
    const-string v25, "6nmN46IYkuf7w3y1ya3HDCA0QIdQGuZELjddOM0ZPF3PbYq35xCU7ePOa/C7o8ZBBTdHkkAa9lU="
    invoke-static {v25}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 773
    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 776
    throw v0

    .line 777
    :cond_10
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 779
    const-string v25, "5G2Q+e0cwPj/xW65jamJQjQ6X9NBFOtEayxFedgFbgnTZJu35gmU6e/La7XH"
    invoke-static {v25}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 781
    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 784
    throw v0
.end method

.method public static r()LWorkManagerImpl;
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    sget-object v0, LWorkManagerImpl;->n:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    sget-object v1, LWorkManagerImpl;->l:LWorkManagerImpl;

    .line 6
    if-eqz v1, :cond_0

    .line 8
    monitor-exit v0

    .line 9
    return-object v1

    .line 10
    :cond_0
    sget-object v1, LWorkManagerImpl;->m:LWorkManagerImpl;

    .line 12
    monitor-exit v0

    .line 13
    return-object v1

    .line 14
    :catchall_0
    move-exception v1

    .line 15
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 16
    throw v1
.end method

.method public static s(Landroid/content/Context;)LWorkManagerImpl;
    .locals 2

    .line 1
    sget-object v0, LWorkManagerImpl;->n:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    invoke-static {}, LWorkManagerImpl;->r()LWorkManagerImpl;

    .line 7
    move-result-object v1

    .line 8
    if-nez v1, :cond_1

    .line 10
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 13
    move-result-object p0

    .line 14
    instance-of v1, p0, Landroidx/work/a$b;

    .line 16
    if-eqz v1, :cond_0

    .line 18
    move-object v1, p0

    .line 19
    check-cast v1, Landroidx/work/a$b;

    .line 21
    invoke-interface {v1}, Landroidx/work/a$b;->a()Landroidx/work/a;

    .line 24
    move-result-object v1

    .line 25
    invoke-static {p0, v1}, LWorkManagerImpl;->t(Landroid/content/Context;Landroidx/work/a;)V

    .line 28
    invoke-static {p0}, LWorkManagerImpl;->s(Landroid/content/Context;)LWorkManagerImpl;

    .line 31
    move-result-object v1

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 35
    const-string v1, "WorkManager is not initialized properly.  You have explicitly disabled WorkManagerInitializer in your manifest, have not manually called WorkManager#initialize at this point, and your Application does not implement Configuration.Provider."

    .line 37
    invoke-direct {p0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 40
    throw p0

    .line 41
    :cond_1
    :goto_0
    monitor-exit v0

    .line 42
    return-object v1

    .line 43
    :catchall_0
    move-exception p0

    .line 44
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 45
    throw p0
.end method

.method public static t(Landroid/content/Context;Landroidx/work/a;)V
    .locals 4

    .line 1
    sget-object v0, LWorkManagerImpl;->n:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    sget-object v1, LWorkManagerImpl;->l:LWorkManagerImpl;

    .line 6
    if-eqz v1, :cond_1

    .line 8
    sget-object v2, LWorkManagerImpl;->m:LWorkManagerImpl;

    .line 10
    if-nez v2, :cond_0

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 15
    const-string p1, "WorkManager is already initialized.  Did you try to initialize it manually without disabling WorkManagerInitializer? See WorkManager#initialize(Context, Configuration) or the class level Javadoc for more information."

    .line 17
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 20
    throw p0

    .line 21
    :cond_1
    :goto_0
    if-nez v1, :cond_3

    .line 23
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 26
    move-result-object p0

    .line 27
    sget-object v1, LWorkManagerImpl;->m:LWorkManagerImpl;

    .line 29
    if-nez v1, :cond_2

    .line 31
    new-instance v1, LWorkManagerImpl;

    .line 33
    new-instance v2, Lp00;

    .line 35
    iget-object v3, p1, Landroidx/work/a;->b:Ljava/util/concurrent/ExecutorService;

    .line 37
    invoke-direct {v2, v3}, Lp00;-><init>(Ljava/util/concurrent/ExecutorService;)V

    .line 40
    invoke-direct {v1, p0, p1, v2}, LWorkManagerImpl;-><init>(Landroid/content/Context;Landroidx/work/a;Lp00;)V

    .line 43
    sput-object v1, LWorkManagerImpl;->m:LWorkManagerImpl;

    .line 45
    :cond_2
    sget-object p0, LWorkManagerImpl;->m:LWorkManagerImpl;

    .line 47
    sput-object p0, LWorkManagerImpl;->l:LWorkManagerImpl;

    .line 49
    :cond_3
    monitor-exit v0

    .line 50
    return-void

    .line 51
    :catchall_0
    move-exception p0

    .line 52
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 53
    throw p0
.end method


# virtual methods
.method public final p(Ljava/util/List;)Lon;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Lx00;",
            ">;)",
            "Lon;"
        }
    .end annotation

    .line 1
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_0

    .line 7
    new-instance v0, LWorkContinuationImpl;

    .line 9
    const/4 v3, 0x0

    .line 10
    sget-object v4, Lkc;->d:Lkc;

    .line 12
    const/4 v6, 0x0

    .line 13
    move-object v1, v0

    .line 14
    move-object v2, p0

    .line 15
    move-object v5, p1

    .line 16
    invoke-direct/range {v1 .. v6}, LWorkContinuationImpl;-><init>(LWorkManagerImpl;Ljava/lang/String;Lkc;Ljava/util/List;I)V

    .line 19
    invoke-virtual {v0}, LWorkContinuationImpl;->p()Lon;

    .line 22
    move-result-object p1

    .line 23
    return-object p1

    .line 24
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 26
    const-string v7, "wmKP4ucdhajjz320muzIWGE6VpJRD6VfYDERDtEYd3vCfYvy8RzO"
    invoke-static {v7}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 28
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 31
    throw p1
.end method

.method public final q(Ljava/util/List;)Lon;
    .locals 4

    .line 1
    sget-object v0, Lkc;->c:Lkc;

    .line 3
    new-instance v1, LWorkContinuationImpl;

    .line 5
    const-string v3, "wn+N8uwcienh9W+/m6c="
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 7
    invoke-direct {v1, p0, v2, v0, p1}, LWorkContinuationImpl;-><init>(LWorkManagerImpl;Ljava/lang/String;Lkc;Ljava/util/List;)V

    .line 10
    invoke-virtual {v1}, LWorkContinuationImpl;->p()Lon;

    .line 13
    move-result-object p1

    .line 14
    return-object p1
.end method

.method public final u()V
    .locals 2

    .line 1
    sget-object v0, LWorkManagerImpl;->n:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    const/4 v1, 0x1

    .line 5
    :try_start_0
    iput-boolean v1, p0, LWorkManagerImpl;->j:Z

    .line 7
    iget-object v1, p0, LWorkManagerImpl;->k:Landroid/content/BroadcastReceiver$PendingResult;

    .line 9
    if-eqz v1, :cond_0

    .line 11
    invoke-virtual {v1}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    .line 14
    const/4 v1, 0x0

    .line 15
    iput-object v1, p0, LWorkManagerImpl;->k:Landroid/content/BroadcastReceiver$PendingResult;

    .line 17
    :cond_0
    monitor-exit v0

    .line 18
    return-void

    .line 19
    :catchall_0
    move-exception v1

    .line 20
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 21
    throw v1
.end method

.method public final v()V
    .locals 5

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x17

    .line 5
    if-lt v0, v1, :cond_0

    .line 7
    iget-object v0, p0, LWorkManagerImpl;->c:Landroid/content/Context;

    .line 9
    sget v1, Lhu;->g:I

    .line 11
    const-string v4, "zWOc5OEAhez4xn2i"
    invoke-static {v4}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 13
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 16
    move-result-object v1

    .line 17
    check-cast v1, Landroid/app/job/JobScheduler;

    .line 19
    if-eqz v1, :cond_0

    .line 21
    invoke-static {v0, v1}, Lhu;->e(Landroid/content/Context;Landroid/app/job/JobScheduler;)Ljava/util/ArrayList;

    .line 24
    move-result-object v0

    .line 25
    if-eqz v0, :cond_0

    .line 27
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 30
    move-result v2

    .line 31
    if-nez v2, :cond_0

    .line 33
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 36
    move-result-object v0

    .line 37
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 40
    move-result v2

    .line 41
    if-eqz v2, :cond_0

    .line 43
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 46
    move-result-object v2

    .line 47
    check-cast v2, Landroid/app/job/JobInfo;

    .line 49
    invoke-virtual {v2}, Landroid/app/job/JobInfo;->getId()I

    .line 52
    move-result v2

    .line 53
    invoke-static {v1, v2}, Lhu;->a(Landroid/app/job/JobScheduler;I)V

    .line 56
    goto :goto_0

    .line 57
    :cond_0
    iget-object v0, p0, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 59
    invoke-virtual {v0}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 62
    move-result-object v0

    .line 63
    check-cast v0, LWorkSpecDao;

    .line 65
    iget-object v1, v0, LWorkSpecDao;->a:Ljq;

    .line 67
    invoke-virtual {v1}, Ljq;->b()V

    .line 70
    iget-object v0, v0, LWorkSpecDao;->i:LWorkSpecDao$h;

    .line 72
    invoke-virtual {v0}, Lcs;->a()Lue;

    .line 75
    move-result-object v2

    .line 76
    invoke-virtual {v1}, Ljq;->c()V

    .line 79
    :try_start_0
    invoke-virtual {v2}, Lue;->u()I

    .line 82
    invoke-virtual {v1}, Ljq;->h()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 85
    invoke-virtual {v1}, Ljq;->f()V

    .line 88
    invoke-virtual {v0, v2}, Lcs;->c(Lue;)V

    .line 91
    iget-object v0, p0, LWorkManagerImpl;->d:Landroidx/work/a;

    .line 93
    iget-object v1, p0, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 95
    iget-object v2, p0, LWorkManagerImpl;->g:Ljava/util/List;

    .line 97
    invoke-static {v0, v1, v2}, LSchedulers;->a(Landroidx/work/a;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V

    .line 100
    return-void

    .line 101
    :catchall_0
    move-exception v3

    .line 102
    invoke-virtual {v1}, Ljq;->f()V

    .line 105
    invoke-virtual {v0, v2}, Lcs;->c(Lue;)V

    .line 108
    throw v3
.end method

.method public final w(Ljava/lang/String;Landroidx/work/WorkerParameters$a;)V
    .locals 2

    .line 1
    iget-object v0, p0, LWorkManagerImpl;->f:Lnu;

    .line 3
    new-instance v1, Lxs;

    .line 5
    invoke-direct {v1, p0, p1, p2}, Lxs;-><init>(LWorkManagerImpl;Ljava/lang/String;Landroidx/work/WorkerParameters$a;)V

    .line 8
    check-cast v0, Lp00;

    .line 10
    invoke-virtual {v0, v1}, Lp00;->a(Ljava/lang/Runnable;)V

    .line 13
    return-void
.end method

.method public final x(Ljava/lang/String;)V
    .locals 3

    iget-object v0, p0, LWorkManagerImpl;->f:Lnu;

    new-instance v1, LStopWorkRunnable;

    const/4 v2, 0x0

    invoke-direct {v1, p0, p1, v2}, LStopWorkRunnable;-><init>(LWorkManagerImpl;Ljava/lang/String;Z)V

    check-cast v0, Lp00;

    invoke-virtual {v0, v1}, Lp00;->a(Ljava/lang/Runnable;)V

    return-void
.end method
