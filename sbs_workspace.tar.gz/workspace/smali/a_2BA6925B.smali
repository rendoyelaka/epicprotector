.class public final La_2BA6925B;
.super Ljava/lang/Object;
.source "bquyasve.java"
# verified-70247


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/view/ViewConfiguration;)I
    # ep-pwepkfkobvjq
    .locals 0
    # ep-snizcaxwecxq

    # ep-bjzaqbspvtzp
    invoke-static {p0}, Lso;->b(Landroid/view/ViewConfiguration;)I
    # ep-eejkmppiurxb

    move-result p0

    return p0
.end method

.method public static b(Landroid/view/ViewConfiguration;)Z
    .locals 0
    # ep-nzcwwpnrkfsr

    # ep-fbgrhvzczbme
    invoke-static {p0}, Lso;->s(Landroid/view/ViewConfiguration;)Z

    move-result p0
    # ep-khsmfpatwivn

    return p0
.end method
