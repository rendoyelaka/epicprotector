.class public LDefaultCoroutineDispatcher;
.super Ljc;
.source "ResponseParser77.java"
# optimised-27853
# ep-pbizddzdmuwu


# instance fields
.field public final d:Lkotlinx/coroutines/scheduling/a;


# direct methods
.method public constructor <init>(IIJ)V
    .locals 7

    .line 1
    const-string v5, "DefaultDispatcher"

    .line 3
    invoke-direct {p0}, Ljc;-><init>()V

    .line 6
    new-instance v6, Lkotlinx/coroutines/scheduling/a;

    .line 8
    move-object v0, v6

    .line 9
    move v1, p1

    .line 10
    move v2, p2

    .line 11
    move-wide v3, p3

    .line 12
    invoke-direct/range {v0 .. v5}, Lkotlinx/coroutines/scheduling/a;-><init>(IIJLjava/lang/String;)V

    .line 15
    iput-object v6, p0, LDefaultCoroutineDispatcher;->d:Lkotlinx/coroutines/scheduling/a;

    .line 17
    return-void
.end method


# virtual methods
.method public final j(Lv8;Ljava/lang/Runnable;)V
    .locals 2

    .line 1
    sget-object p1, Lkotlinx/coroutines/scheduling/a;->j:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    .line 3
    sget-object p1, Lpu;->f:Lk3;

    .line 5
    const/4 v0, 0x0

    .line 6
    iget-object v1, p0, LDefaultCoroutineDispatcher;->d:Lkotlinx/coroutines/scheduling/a;

    .line 8
    invoke-virtual {v1, p2, p1, v0}, Lkotlinx/coroutines/scheduling/a;->j(Ljava/lang/Runnable;Lmu;Z)V

    .line 11
    return-void
.end method
