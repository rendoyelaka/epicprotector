.class public final La_7477FB2B;
.super Ld;
.source "bqlzlxuv.java"

# ep-htjgfpalojig
# optimised-77923

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_055A5B73;
    }
.end annotation


# static fields
.field public static final c:La_055A5B73;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_055A5B73;

    invoke-direct {v0}, La_055A5B73;-><init>()V

    sput-object v0, La_7477FB2B;->c:La_055A5B73;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    sget-object v0, La_7477FB2B;->c:La_055A5B73;

    invoke-direct {p0, v0}, Ld;-><init>(La_FED45020;)V

    return-void
.end method
