.class public final Lcy;
.super Ljava/lang/Object;
# validated-88338
# processed-56084
# verified-33677
# ep-uwyobqxbhxvn
.source "phdynvbv.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcy$a;,
        Lcy$b;
    }
.end annotation


# instance fields
.field public final a:Ldy;

.field public final b:Lcy$a;

.field public final c:Lb9;


# direct methods
.method public constructor <init>(Ldy;Lcy$a;)V
    .locals 1

    const-string v0, "store"

    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 5
    sget-object v0, Lb9$a;->b:Lb9$a;

    .line 6
    invoke-direct {p0, p1, p2, v0}, Lcy;-><init>(Ldy;Lcy$a;Lb9;)V

    return-void
.end method

.method public constructor <init>(Ldy;Lcy$a;Lb9;)V
    .locals 1

    const-string v0, "store"

    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    const-string v0, "defaultCreationExtras"

    invoke-static {v0, p3}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcy;->a:Ldy;

    .line 3
    iput-object p2, p0, Lcy;->b:Lcy$a;

    .line 4
    iput-object p3, p0, Lcy;->c:Lb9;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Class;)LViewModelProvider;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "LViewModelProvider;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    .line 1
    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    const-string v1, "androidx.lifecycle.ViewModelProvider.DefaultKey:"

    .line 9
    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {p0, p1, v0}, Lcy;->b(Ljava/lang/Class;Ljava/lang/String;)LViewModelProvider;

    .line 16
    move-result-object p1

    .line 17
    return-object p1

    .line 18
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 20
    const-string v0, "Local and anonymous classes can not be ViewModels"

    .line 22
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 25
    throw p1
.end method

.method public final b(Ljava/lang/Class;Ljava/lang/String;)LViewModelProvider;
    .locals 4

    .line 1
    const-string v0, "key"

    .line 3
    invoke-static {v0, p2}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    iget-object v0, p0, Lcy;->a:Ldy;

    .line 8
    iget-object v1, v0, Ldy;->a:Ljava/util/HashMap;

    .line 10
    invoke-virtual {v1, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    move-result-object v1

    .line 14
    check-cast v1, LViewModelProvider;

    .line 16
    invoke-virtual {p1, v1}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    .line 19
    move-result v2

    .line 20
    iget-object v3, p0, Lcy;->b:Lcy$a;

    .line 22
    if-eqz v2, :cond_3

    .line 24
    instance-of p1, v3, Lcy$b;

    .line 26
    if-eqz p1, :cond_0

    .line 28
    check-cast v3, Lcy$b;

    .line 30
    goto :goto_0

    .line 31
    :cond_0
    const/4 v3, 0x0

    .line 32
    :goto_0
    if-eqz v3, :cond_1

    .line 34
    const-string p1, "viewModel"

    .line 36
    invoke-static {p1, v1}, Lqi;->c(Ljava/lang/String;Ljava/lang/Object;)V

    .line 39
    :cond_1
    if-eqz v1, :cond_2

    .line 41
    return-object v1

    .line 42
    :cond_2
    new-instance p1, Ljava/lang/NullPointerException;

    .line 44
    const-string p2, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get"

    .line 46
    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 49
    throw p1

    .line 50
    :cond_3
    new-instance v1, Lam;

    .line 52
    iget-object v2, p0, Lcy;->c:Lb9;

    .line 54
    invoke-direct {v1, v2}, Lam;-><init>(Lb9;)V

    .line 57
    sget-object v2, Lp2;->U0:Lp2;

    .line 59
    invoke-virtual {v1, v2, p2}, Lam;->a(Lb9$b;Ljava/lang/Object;)V

    .line 62
    :try_start_0
    invoke-interface {v3, p1, v1}, Lcy$a;->b(Ljava/lang/Class;Lam;)LViewModelProvider;

    .line 65
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/AbstractMethodError; {:try_start_0 .. :try_end_0} :catch_0

    .line 66
    goto :goto_1

    .line 67
    :catch_0
    invoke-interface {v3, p1}, Lcy$a;->a(Ljava/lang/Class;)LViewModelProvider;

    .line 70
    move-result-object p1

    .line 71
    :goto_1
    iget-object v0, v0, Ldy;->a:Ljava/util/HashMap;

    .line 73
    invoke-virtual {v0, p2, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    move-result-object p2

    .line 77
    check-cast p2, LViewModelProvider;

    .line 79
    if-eqz p2, :cond_4

    .line 81
    invoke-virtual {p2}, LViewModelProvider;->a()V

    .line 84
    :cond_4
    return-object p1
.end method
