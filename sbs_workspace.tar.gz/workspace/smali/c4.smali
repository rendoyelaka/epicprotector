.class public final Lc4;
.super Ljava/lang/Object;
# processed-65031
# verified-78198
# processed-26775
.source "pxpoobit.java"
# ep-fxubloofzrpa

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    iput-object p1, p0, Lc4;->c:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, Lc4;->c:Landroid/content/Context;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_p2t47n9w
    goto :ep_s_p2t47n9w
    :ep_d_p2t47n9w
    nop
    :ep_s_p2t47n9w
    invoke-static {v0}, Ld4;->a(Landroid/content/Context;)V

    return-void
.end method
