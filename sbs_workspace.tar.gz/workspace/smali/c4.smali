.class public final Lc4;
# session-75264-helper
# database-82351-factory
# manager-36439-session
# ep-gabnmoietmwv
.super Ljava/lang/Object;
# processed-45600
# compiled-60709
# processed-16458
.source "EntityUtils68.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    iput-object p1, p0, Lc4;->c:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, Lc4;->c:Landroid/content/Context;

    invoke-static {v0}, Ld4;->a(Landroid/content/Context;)V

    return-void
.end method
