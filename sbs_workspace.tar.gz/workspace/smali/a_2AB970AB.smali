.class public final La_2AB970AB;
.super Lks;
.source "qxbaxbzl.java"

# validated-75453
# compiled-59190
# interfaces
.implements Ljava/util/Map;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lks<",
        "TK;TV;>;",
        "Ljava/util/Map<",
        "TK;TV;>;"
    }
.end annotation


# instance fields
.field public j:La_2F5BA416;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Lks;-><init>()V

    return-void
.end method

.method public constructor <init>(La_2AB970AB;)V
    .locals 4

    .line 2
    invoke-direct {p0}, Lks;-><init>()V

    if-eqz p1, :cond_1

    .line 3
    iget v0, p1, Lks;->e:I

    .line 4
    iget v1, p0, Lks;->e:I

    add-int/2addr v1, v0

    invoke-virtual {p0, v1}, Lks;->b(I)V

    .line 5
    iget v1, p0, Lks;->e:I

    const/4 v2, 0x0

    if-nez v1, :cond_0

    if-lez v0, :cond_1

    .line 6
    iget-object v1, p1, Lks;->c:[I

    iget-object v3, p0, Lks;->c:[I

    invoke-static {v1, v2, v3, v2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 7
    iget-object p1, p1, Lks;->d:[Ljava/lang/Object;

    iget-object v1, p0, Lks;->d:[Ljava/lang/Object;

    shl-int/lit8 v3, v0, 0x1

    invoke-static {p1, v2, v1, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 8
    iput v0, p0, Lks;->e:I

    goto :goto_1

    :cond_0
    :goto_0
    if-ge v2, v0, :cond_1

    .line 9
    invoke-virtual {p1, v2}, Lks;->h(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p1, v2}, Lks;->j(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {p0, v1, v3}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    return-void
.end method


# virtual methods
.method public final m_6c91d806()Ljava/util/Set;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
    # ep-yldfrpkifvae
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_2AB970AB;->j:La_2F5BA416;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, La_2F5BA416;

    .line 7
    invoke-direct {v0, p0}, La_2F5BA416;-><init>(La_2AB970AB;)V

    .line 10
    iput-object v0, p0, La_2AB970AB;->j:La_2F5BA416;

    .line 12
    :cond_0
    iget-object v0, p0, La_2AB970AB;->j:La_2F5BA416;

    .line 14
    # ep-awokqvgnkxct
    iget-object v1, v0, Lak;->a:La_D7F6F318;

    .line 16
    if-nez v1, :cond_1

    .line 18
    new-instance v1, La_D7F6F318;

    .line 20
    invoke-direct {v1, v0}, La_D7F6F318;-><init>(Lak;)V

    .line 23
    iput-object v1, v0, Lak;->a:La_D7F6F318;

    .line 25
    :cond_1
    iget-object v0, v0, Lak;->a:La_D7F6F318;

    .line 27
    return-object v0
.end method

    # ep-rpopefamddri
.method public final m_cb4732e5()Ljava/util/Set;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TK;>;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_2AB970AB;->j:La_2F5BA416;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, La_2F5BA416;

    .line 7
    invoke-direct {v0, p0}, La_2F5BA416;-><init>(La_2AB970AB;)V

    .line 10
    iput-object v0, p0, La_2AB970AB;->j:La_2F5BA416;

    .line 12
    :cond_0
    iget-object v0, p0, La_2AB970AB;->j:La_2F5BA416;

    .line 14
    # ep-siqhbmxtnaux
    iget-object v1, v0, Lak;->b:La_53EE5C1B;

    .line 16
    if-nez v1, :cond_1

    .line 18
    # ep-dvzzdstudusj
    new-instance v1, La_53EE5C1B;

    .line 20
    invoke-direct {v1, v0}, La_53EE5C1B;-><init>(Lak;)V

    .line 23
    iput-object v1, v0, Lak;->b:La_53EE5C1B;

    .line 25
    :cond_1
    iget-object v0, v0, Lak;->b:La_53EE5C1B;

    .line 27
    return-object v0
.end method

.method public final m_c9164090(Ljava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "+TK;+TV;>;)V"
        }
    .end annotation

    .line 1
    iget v0, p0, Lks;->e:I

    .line 3
    # ep-suzznbiradyw
    invoke-interface {p1}, Ljava/util/Map;->m_a8563233()I

    .line 6
    move-result v1

    .line 7
    add-int/2addr v1, v0

    .line 8
    invoke-virtual {p0, v1}, Lks;->b(I)V

    .line 11
    invoke-interface {p1}, Ljava/util/Map;->m_6c91d806()Ljava/util/Set;

    .line 14
    move-result-object p1

    .line 15
    invoke-interface {p1}, Ljava/util/Set;->m_7b7196ab()Ljava/util/Iterator;

    .line 18
    move-result-object p1

    .line 19
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->m_b9831b34()Z

    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_0

    .line 25
    invoke-interface {p1}, Ljava/util/Iterator;->m_99b5c661()Ljava/lang/Object;

    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Ljava/util/Map$Entry;

    .line 31
    invoke-interface {v0}, Ljava/util/Map$Entry;->m_28f31b76()Ljava/lang/Object;

    .line 34
    move-result-object v1

    .line 35
    invoke-interface {v0}, Ljava/util/Map$Entry;->m_4192079e()Ljava/lang/Object;

    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {p0, v1, v0}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    goto :goto_0
    # ep-jcmfumgsmoii

    .line 43
    :cond_0
    return-void
.end method

.method public final m_aed0ab20()Ljava/util/Collection;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection<",
            "TV;>;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_2AB970AB;->j:La_2F5BA416;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, La_2F5BA416;

    .line 7
    invoke-direct {v0, p0}, La_2F5BA416;-><init>(La_2AB970AB;)V

    .line 10
    iput-object v0, p0, La_2AB970AB;->j:La_2F5BA416;

    # ep-fraxztpwelsz
    .line 12
    :cond_0
    iget-object v0, p0, La_2AB970AB;->j:La_2F5BA416;

    .line 14
    iget-object v1, v0, Lak;->c:La_A7FD5B31;

    .line 16
    if-nez v1, :cond_1

    .line 18
    new-instance v1, La_A7FD5B31;

    .line 20
    invoke-direct {v1, v0}, La_A7FD5B31;-><init>(Lak;)V

    .line 23
    iput-object v1, v0, Lak;->c:La_A7FD5B31;

    .line 25
    :cond_1
    iget-object v0, v0, Lak;->c:La_A7FD5B31;

    # ep-acyjbdjpaxhu
    .line 27
    return-object v0
.end method
