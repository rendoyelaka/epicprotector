.class public final La_6195F8D7;
.super Ljava/lang/Object;
# ep-ivkrvgzsaazl
# generated-31864
.source "cgmxicfi.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_E86E9D05;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/view/View;)Z
    .locals 0

    invoke-virtual {p0}, Landroid/view/View;->isInLayout()Z

    move-result p0

    return p0
.end method
