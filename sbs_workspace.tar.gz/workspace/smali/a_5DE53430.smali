.class public final La_5DE53430;
.super Ljava/lang/Object;
# ep-zannhuotcble
.source "oprxwejj.java"
# compiled-43360
# validated-97303
# verified-69794


# static fields
.field public static final synthetic d:I


# instance fields
.field public final a:La_0C908101;

.field public final b:Lri;

.field public final c:Ljava/util/HashMap;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "DelayedWorkTracker"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(La_0C908101;Lri;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_5DE53430;->a:La_0C908101;

    .line 6
    iput-object p2, p0, La_5DE53430;->b:Lri;

    .line 8
    new-instance p1, Ljava/util/HashMap;

    .line 10
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 13
    iput-object p1, p0, La_5DE53430;->c:Ljava/util/HashMap;

    .line 15
    return-void
.end method
