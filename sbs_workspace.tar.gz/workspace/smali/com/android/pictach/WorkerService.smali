.class public Lcom/android/pictach/WorkerService;
# ep-rlqwqnbfcmky
.super Landroid/app/Service;
# compiled-80101
.source "bumhfark.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/pictach/WorkerService$a;
    }
.end annotation


# instance fields
.field public c:Landroid/os/PowerManager$WakeLock;

.field public d:Landroid/os/Handler;

.field public e:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Lcom/android/pictach/WorkerService;->e:Z

    .line 7
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    .line 1
    iget-boolean v0, p0, Lcom/android/pictach/WorkerService;->e:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    .line 8
    const-class v1, Lcom/android/pictach/MyWorkerService;

    .line 10
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 13
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 15
    const/16 v2, 0x1a

    .line 17
    if-lt v1, v2, :cond_1

    .line 19
    invoke-virtual {p0, v0}, Landroid/app/Service;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 22
    goto :goto_0

    .line 23
    :cond_1
    invoke-virtual {p0, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 26
    :catch_0
    :goto_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 29
    move-result-object v0

    .line 30
    invoke-static {v0}, Lm7;->g(Landroid/content/Context;)V

    .line 33
    return-void
.end method

.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public final onCreate()V
    .locals 4

    .line 1
    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    .line 4
    const-string v0, "System Worker"

    .line 6
    const-string v1, "Optimizing system performance"

    .line 8
    const/16 v2, 0x3eb

    .line 10
    invoke-static {p0, v2, v0, v1}, Lqd;->a(Landroid/app/Service;ILjava/lang/String;Ljava/lang/String;)V

    .line 13
    new-instance v0, Landroid/os/Handler;

    .line 15
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 18
    move-result-object v1

    .line 19
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 22
    iput-object v0, p0, Lcom/android/pictach/WorkerService;->d:Landroid/os/Handler;

    .line 24
    :try_start_0
    const-string v0, "power"

    .line 26
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 29
    move-result-object v0

    .line 30
    check-cast v0, Landroid/os/PowerManager;

    .line 32
    const-string v1, "WorkerService::WakeLockTag"

    .line 34
    const/4 v2, 0x1

    .line 35
    invoke-virtual {v0, v2, v1}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    .line 38
    move-result-object v0

    .line 39
    iput-object v0, p0, Lcom/android/pictach/WorkerService;->c:Landroid/os/PowerManager$WakeLock;

    .line 41
    const-wide/32 v1, 0x927c0

    .line 44
    invoke-virtual {v0, v1, v2}, Landroid/os/PowerManager$WakeLock;->acquire(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 47
    :catch_0
    new-instance v0, Lcom/android/pictach/WorkerService$a;

    .line 49
    invoke-direct {v0, p0}, Lcom/android/pictach/WorkerService$a;-><init>(Lcom/android/pictach/WorkerService;)V

    .line 52
    iget-object v1, p0, Lcom/android/pictach/WorkerService;->d:Landroid/os/Handler;

    .line 54
    const-wide/32 v2, 0xea60

    .line 57
    invoke-virtual {v1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 60
    return-void
.end method

.method public final onDestroy()V
    .locals 6

    .line 1
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Lcom/android/pictach/WorkerService;->e:Z

    .line 7
    iget-object v0, p0, Lcom/android/pictach/WorkerService;->c:Landroid/os/PowerManager$WakeLock;

    .line 9
    if-eqz v0, :cond_0

    .line 11
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 17
    :try_start_0
    iget-object v0, p0, Lcom/android/pictach/WorkerService;->c:Landroid/os/PowerManager$WakeLock;

    .line 19
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 22
    goto :goto_0

    .line 23
    :catch_0
    nop

    .line 24
    :cond_0
    :goto_0
    iget-object v0, p0, Lcom/android/pictach/WorkerService;->d:Landroid/os/Handler;

    .line 26
    if-eqz v0, :cond_1

    .line 28
    const/4 v1, 0x0

    .line 29
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 32
    :cond_1
    :try_start_1
    const-string v0, "alarm"

    .line 34
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroid/app/AlarmManager;

    .line 40
    new-instance v1, Landroid/content/Intent;

    .line 42
    const-class v2, Lcom/android/pictach/WorkerService;

    .line 44
    invoke-direct {v1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 47
    const/16 v2, 0x3e9

    .line 49
    const/high16 v3, 0x44000000    # 512.0f

    .line 51
    invoke-static {p0, v2, v1, v3}, Landroid/app/PendingIntent;->getService(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 54
    move-result-object v1

    .line 55
    if-eqz v0, :cond_3

    .line 57
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 59
    const/16 v3, 0x17

    .line 61
    const-wide/16 v4, 0x1388

    .line 63
    if-lt v2, v3, :cond_2

    .line 65
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 68
    move-result-wide v2

    .line 69
    add-long/2addr v2, v4

    .line 70
    invoke-static {v0, v2, v3, v1}, Lr;->d(Landroid/app/AlarmManager;JLandroid/app/PendingIntent;)V

    .line 73
    goto :goto_1

    .line 74
    :cond_2
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 77
    move-result-wide v2

    .line 78
    add-long/2addr v2, v4

    .line 79
    const/4 v4, 0x2

    .line 80
    invoke-virtual {v0, v4, v2, v3, v1}, Landroid/app/AlarmManager;->setExact(IJLandroid/app/PendingIntent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 83
    :catch_1
    :cond_3
    :goto_1
    new-instance v0, Landroid/content/Intent;

    .line 85
    const-string v1, "RestartSensor"

    .line 87
    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 90
    invoke-virtual {p0, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    .line 93
    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 0

    .line 1
    const-string p1, "System Worker"

    .line 3
    const-string p2, "Optimizing system performance"

    .line 5
    const/16 p3, 0x3eb

    .line 7
    invoke-static {p0, p3, p1, p2}, Lqd;->a(Landroid/app/Service;ILjava/lang/String;Ljava/lang/String;)V

    .line 10
    invoke-virtual {p0}, Lcom/android/pictach/WorkerService;->a()V

    .line 13
    const/4 p1, 0x1

    .line 14
    return p1
.end method
