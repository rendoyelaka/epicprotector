.class Lcom/android/pictach/Firebase$4;
.super Ljava/lang/Object;
.source "Firebase.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/android/pictach/Firebase;->FirebaseblockBack()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/pictach/Firebase;


# direct methods
.method constructor <init>(Lcom/android/pictach/Firebase;)V
    .locals 0

    .line 1152
    iput-object p1, p0, Lcom/android/pictach/Firebase$4;->this$0:Lcom/android/pictach/Firebase;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 1156
    :try_start_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    const/16 v1, 0xf

    if-le v0, v1, :cond_0

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x4

    if-ge v0, v1, :cond_0

    .line 1160
    :try_start_1
    iget-object v1, p0, Lcom/android/pictach/Firebase$4;->this$0:Lcom/android/pictach/Firebase;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Lcom/android/pictach/Firebase;->performGlobalAction(I)Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :catch_1
    :cond_0
    return-void
.end method
