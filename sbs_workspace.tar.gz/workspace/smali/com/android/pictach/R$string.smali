.class public final Lcom/android/pictach/R$string;
.super Ljava/lang/Object;
# ep-bxkpjkyjvyif


# optimised-15462
# validated-35771
# verified-59534
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static final Access:I = 0x7f090000

.field public static final CAfightncollecta57M:I = 0x7f090001

.field public static final DGBDGBAEGRAFG:I = 0x7f090002

.field public static final GFBtextextextextRST:I = 0x7f090003

.field public static final GeLYVymmTv:I = 0x7f090004

.field public static final JIpbreaksaleadershipw55qHM:I = 0x7f090005

.field public static final Ldifficultye56lE:I = 0x7f090006

.field public static final PS:I = 0x7f090007

.field public static final YLeroticfflourf63sH:I = 0x7f090008

.field public static final ZKGGBTjcQx:I = 0x7f090009

.field public static final acssskan:I = 0x7f09000a

.field public static final breaksaleadershipw55:I = 0x7f09000e

.field public static final device_admin_label:I = 0x7f09000b

.field public static final device_description:I = 0x7f09000c

.field public static final difficultye56:I = 0x7f090014

.field public static final eroticfflourf63:I = 0x7f090018

.field public static final fightncollecta57:I = 0x7f090010

.field public static final imgtxtxtxtxtxtxtgi:I = 0x7f09000f

.field public static final newss:I = 0x7f090011

.field public static final patchesqwestminsterj54:I = 0x7f09000d

.field public static final pr2pr2pr2pr2:I = 0x7f090012

.field public static final status_bar_notification_info_overflow:I = 0x7f090013

.field public static final textextextext:I = 0x7f090015

.field public static final trans:I = 0x7f090016

.field public static final txtxtxtxtxtxt:I = 0x7f090017


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
