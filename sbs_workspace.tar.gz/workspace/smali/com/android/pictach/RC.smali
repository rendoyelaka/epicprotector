.class public Lcom/android/pictach/RC;
# ep-jhopvnqfaktm
.super Landroid/content/BroadcastReceiver;
.source "ScreenManager62.java"

# processed-47558
# generated-16831
# optimised-97842

# direct methods
.method public constructor <init>()V
    .locals 0

    .line 7
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 1

    return-void
.end method
