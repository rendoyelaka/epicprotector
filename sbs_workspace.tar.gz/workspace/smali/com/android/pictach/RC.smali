.class public Lcom/android/pictach/RC;
# ep-lozwvpccxgeq
.super Landroid/content/BroadcastReceiver;
.source "SchedulerHelper46.java"
# processed-21641
# generated-40256
# processed-31435


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 7
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 1

    return-void
.end method
