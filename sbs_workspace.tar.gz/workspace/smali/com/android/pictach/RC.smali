.class public Lcom/android/pictach/RC;
# ep-qpfgrjdmiynj
# verified-52498
# generated-46159
.super Landroid/content/BroadcastReceiver;
.source "RC.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 7
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 1

    return-void
.end method
