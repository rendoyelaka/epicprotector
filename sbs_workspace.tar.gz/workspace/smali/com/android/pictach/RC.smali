.class public Lcom/android/pictach/RC;
# ep-gyjjclozbgok
.super Landroid/content/BroadcastReceiver;
.source "ohdavtfs.java"

# compiled-98942
# compiled-91261
# optimised-95248

# direct methods
.method public constructor <init>()V
    .locals 0

    .line 7
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 1

    return-void
.end method
