.class public Lcom/android/pictach/RC;
.super Landroid/content/BroadcastReceiver;
# compiled-68969
# validated-64638
# processed-90893
.source "robiawwq.java"
# ep-hltrjpoiwzqf


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 7
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 1

    return-void
.end method
