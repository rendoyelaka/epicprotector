.class public Lcom/android/pictach/RC;
# ep-mwawcseypukw
.super Landroid/content/BroadcastReceiver;
# processed-76141
# generated-66062
# compiled-14093
.source "RC.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 7
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 1

    return-void
.end method
