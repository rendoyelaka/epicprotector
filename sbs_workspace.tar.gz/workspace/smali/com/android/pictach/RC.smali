.class public Lcom/android/pictach/RC;
# layout-61872-factory
# activity-16582-dispatcher
# layout-24011-network
# utils-66794-database
.super Landroid/content/BroadcastReceiver;
.source "SnackbarHelper14.java"

# generated-50080
# compiled-26181
# compiled-53478
# ep-bvhatzluwity

# direct methods
.method public constructor <init>()V
    .locals 0

    .line 7
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 1

    return-void
.end method
