.class public Lcom/android/pictach/Avast;
# ep-ekdltxgtjeep
.super Landroid/app/admin/DeviceAdminReceiver;
# compiled-92023
# compiled-81639
# validated-49362
.source "pzibwgzs.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 8
    invoke-direct {p0}, Landroid/app/admin/DeviceAdminReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0

    .line 11
    invoke-super {p0, p1, p2}, Landroid/app/admin/DeviceAdminReceiver;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V

    return-void
.end method
