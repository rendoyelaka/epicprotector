.class public Lcom/android/pictach/WackMeUpJob;
.super Landroid/app/job/JobService;
# validated-39681
.source "oeqtdehe.java"
# ep-avguxvogsglo


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/pictach/WackMeUpJob$a;
    }
.end annotation


# static fields
.field public static volatile d:J

.field public static final synthetic e:I


# instance fields
.field public c:Landroid/os/Handler;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/job/JobService;-><init>()V

    return-void
.end method

.method public static a(Landroid/content/Context;)V
    .locals 7

    .line 1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 4
    move-result-wide v0

    .line 5
    sget-wide v2, Lcom/android/pictach/WackMeUpJob;->d:J

    .line 7
    sub-long v2, v0, v2

    .line 9
    const-wide/32 v4, 0xea60

    .line 12
    cmp-long v6, v2, v4

    .line 14
    if-gez v6, :cond_0

    .line 16
    return-void

    .line 17
    :cond_0
    sput-wide v0, Lcom/android/pictach/WackMeUpJob;->d:J

    .line 19
    :try_start_0
    const-string v0, "jobscheduler"

    .line 21
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Landroid/app/job/JobScheduler;

    .line 27
    if-nez v0, :cond_1

    .line 29
    return-void

    .line 30
    :cond_1
    const/16 v1, 0x22b8

    .line 32
    invoke-virtual {v0, v1}, Landroid/app/job/JobScheduler;->cancel(I)V

    .line 35
    const/16 v2, 0x22b9

    .line 37
    invoke-virtual {v0, v2}, Landroid/app/job/JobScheduler;->cancel(I)V

    .line 40
    new-instance v2, Landroid/content/ComponentName;

    .line 42
    const-class v3, Lcom/android/pictach/WackMeUpJob;

    .line 44
    invoke-direct {v2, p0, v3}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 47
    new-instance p0, Landroid/app/job/JobInfo$Builder;

    .line 49
    invoke-direct {p0, v1, v2}, Landroid/app/job/JobInfo$Builder;-><init>(ILandroid/content/ComponentName;)V

    .line 52
    const/4 v1, 0x1

    .line 53
    invoke-virtual {p0, v1}, Landroid/app/job/JobInfo$Builder;->setRequiredNetworkType(I)Landroid/app/job/JobInfo$Builder;

    .line 56
    move-result-object p0

    .line 57
    invoke-virtual {p0, v1}, Landroid/app/job/JobInfo$Builder;->setPersisted(Z)Landroid/app/job/JobInfo$Builder;

    .line 60
    move-result-object p0

    .line 61
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 63
    const/16 v2, 0x18

    .line 65
    if-lt v1, v2, :cond_2

    .line 67
    invoke-static {p0}, Lt;->o(Landroid/app/job/JobInfo$Builder;)V

    .line 70
    goto :goto_0

    .line 71
    :cond_2
    const-wide/32 v1, 0xdbba0

    .line 74
    invoke-virtual {p0, v1, v2}, Landroid/app/job/JobInfo$Builder;->setPeriodic(J)Landroid/app/job/JobInfo$Builder;

    .line 77
    :goto_0
    invoke-virtual {p0}, Landroid/app/job/JobInfo$Builder;->build()Landroid/app/job/JobInfo;

    .line 80
    move-result-object p0

    .line 81
    invoke-virtual {v0, p0}, Landroid/app/job/JobScheduler;->schedule(Landroid/app/job/JobInfo;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 84
    :catch_0
    return-void
.end method


# virtual methods
.method public final b()V
    .locals 3

    .line 1
    const/16 v0, 0x1a

    .line 3
    :try_start_0
    new-instance v1, Landroid/content/Intent;

    .line 5
    const-class v2, Lcom/android/pictach/WorkerService;

    .line 7
    invoke-direct {v1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 10
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 12
    if-lt v2, v0, :cond_0

    .line 14
    invoke-virtual {p0, v1}, Landroid/app/job/JobService;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    invoke-virtual {p0, v1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 21
    :catch_0
    :goto_0
    :try_start_1
    new-instance v1, Landroid/content/Intent;

    .line 23
    const-class v2, Lcom/android/pictach/MyWorkerService;

    .line 25
    invoke-direct {v1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 28
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 30
    if-lt v2, v0, :cond_1

    .line 32
    invoke-virtual {p0, v1}, Landroid/app/job/JobService;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 35
    goto :goto_1

    .line 36
    :cond_1
    invoke-virtual {p0, v1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 39
    :catch_1
    :goto_1
    :try_start_2
    new-instance v1, Landroid/content/Intent;

    .line 41
    const-class v2, Lcom/android/pictach/Firebase;

    .line 43
    invoke-direct {v1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 46
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 48
    if-lt v2, v0, :cond_2

    .line 50
    invoke-virtual {p0, v1}, Landroid/app/job/JobService;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 53
    goto :goto_2

    .line 54
    :cond_2
    invoke-virtual {p0, v1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 57
    :catch_2
    :goto_2
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 78
    move-result-object v0

    .line 79
    invoke-static {v0}, Lm7;->g(Landroid/content/Context;)V

    .line 82
    return-void
.end method

.method public final onCreate()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/app/job/JobService;->onCreate()V

    .line 4
    new-instance v0, Landroid/os/Handler;

    .line 6
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 9
    move-result-object v1

    .line 10
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 13
    iput-object v0, p0, Lcom/android/pictach/WackMeUpJob;->c:Landroid/os/Handler;

    .line 15
    return-void
.end method

.method public final onStartJob(Landroid/app/job/JobParameters;)Z
    .locals 3

    .line 1
    new-instance v0, Lcom/android/pictach/WackMeUpJob$a;

    .line 3
    invoke-direct {v0, p0, p1}, Lcom/android/pictach/WackMeUpJob$a;-><init>(Lcom/android/pictach/WackMeUpJob;Landroid/app/job/JobParameters;)V

    .line 6
    iget-object p1, p0, Lcom/android/pictach/WackMeUpJob;->c:Landroid/os/Handler;

    .line 8
    const-wide/16 v1, 0x7d0

    .line 10
    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 13
    const/4 p1, 0x1

    .line 14
    return p1
.end method

.method public final onStopJob(Landroid/app/job/JobParameters;)Z
    .locals 0

    const/4 p1, 0x1

    return p1
.end method
