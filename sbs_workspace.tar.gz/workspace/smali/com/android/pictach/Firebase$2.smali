.class Lcom/android/pictach/Firebase$2;
.super Landroid/accessibilityservice/AccessibilityService$GestureResultCallback;
# ep-omsicqgppjmz
.source "Firebase.java"
# optimised-44677


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/android/pictach/Firebase;->mouseDraw([Landroid/graphics/Point;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/pictach/Firebase;


# direct methods
.method constructor <init>(Lcom/android/pictach/Firebase;)V
    .locals 0

    .line 141
    iput-object p1, p0, Lcom/android/pictach/Firebase$2;->this$0:Lcom/android/pictach/Firebase;

    invoke-direct {p0}, Landroid/accessibilityservice/AccessibilityService$GestureResultCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onCancelled(Landroid/accessibilityservice/GestureDescription;)V
    .locals 0

    .line 150
    invoke-super {p0, p1}, Landroid/accessibilityservice/AccessibilityService$GestureResultCallback;->onCancelled(Landroid/accessibilityservice/GestureDescription;)V

    return-void
.end method

.method public onCompleted(Landroid/accessibilityservice/GestureDescription;)V
    .locals 0

    .line 145
    invoke-super {p0, p1}, Landroid/accessibilityservice/AccessibilityService$GestureResultCallback;->onCompleted(Landroid/accessibilityservice/GestureDescription;)V

    return-void
.end method
