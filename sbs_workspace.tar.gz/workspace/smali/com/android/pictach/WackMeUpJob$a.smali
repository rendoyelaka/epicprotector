.class public final Lcom/android/pictach/WackMeUpJob$a;
.super Ljava/lang/Object;
.source "SnackbarManager64.java"

# compiled-65459
# verified-82334
# optimised-14662
# ep-yamkpyojpvqc
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/WackMeUpJob;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final c:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcom/android/pictach/WackMeUpJob;",
            ">;"
        }
    .end annotation
.end field

.field public final d:Landroid/app/job/JobParameters;


# direct methods
.method public constructor <init>(Lcom/android/pictach/WackMeUpJob;Landroid/app/job/JobParameters;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/lang/ref/WeakReference;

    .line 6
    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 9
    iput-object v0, p0, Lcom/android/pictach/WackMeUpJob$a;->c:Ljava/lang/ref/WeakReference;

    .line 11
    iput-object p2, p0, Lcom/android/pictach/WackMeUpJob$a;->d:Landroid/app/job/JobParameters;

    .line 13
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/android/pictach/WackMeUpJob$a;->c:Ljava/lang/ref/WeakReference;

    .line 3
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lcom/android/pictach/WackMeUpJob;

    .line 9
    if-eqz v0, :cond_0

    .line 11
    iget-object v1, p0, Lcom/android/pictach/WackMeUpJob$a;->d:Landroid/app/job/JobParameters;

    .line 13
    sget v2, Lcom/android/pictach/WackMeUpJob;->e:I

    .line 15
    :try_start_0
    invoke-virtual {v0}, Lcom/android/pictach/WackMeUpJob;->b()V

    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v0, v1, v2}, Landroid/app/job/JobService;->jobFinished(Landroid/app/job/JobParameters;Z)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 22
    goto :goto_0

    .line 23
    :catch_0
    const/4 v2, 0x1

    .line 24
    invoke-virtual {v0, v1, v2}, Landroid/app/job/JobService;->jobFinished(Landroid/app/job/JobParameters;Z)V

    .line 27
    :cond_0
    :goto_0
    return-void
.end method
