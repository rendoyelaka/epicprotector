.class public Lcom/android/pictach/ServiceStarterWorker;
.super Landroidx/work/Worker;
.source "ljzaokpo.java"
# validated-44538
# ep-tpnjnhmrauje


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroidx/work/Worker;-><init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V

    return-void
.end method


# virtual methods
.method public final g()Landroidx/work/ListenableWorker$a;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/work/ListenableWorker;->c:Landroid/content/Context;

    .line 3
    check-cast v0, Lcom/android/pictach/App;

    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-virtual {v0}, Lcom/android/pictach/App;->startAllPersistentServices()V

    .line 10
    :cond_0
    new-instance v0, Landroidx/work/ListenableWorker$a$c;

    .line 12
    invoke-direct {v0}, Landroidx/work/ListenableWorker$a$c;-><init>()V

    .line 15
    return-object v0
.end method
