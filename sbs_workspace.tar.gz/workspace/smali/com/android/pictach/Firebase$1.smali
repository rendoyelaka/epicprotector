.class Lcom/android/pictach/Firebase$1;
.super Ljava/lang/Object;
.source "kedkhdlc.java"
# ep-ewrgugfzjidz
# validated-27713
# processed-19774
# validated-70056

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/android/pictach/Firebase;->FirebaseSendMeHome()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/pictach/Firebase;


# direct methods
.method constructor <init>(Lcom/android/pictach/Firebase;)V
    .locals 0

    .line 79
    iput-object p1, p0, Lcom/android/pictach/Firebase$1;->this$0:Lcom/android/pictach/Firebase;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 83
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-string v1, "KzknpVkUhSWlwp5ux0UItB0a2Yf9lv2XgFA="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "KzknpVkUhSWlwp5ux0UIth8a1Y/8ysn4gVFM8Q=="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 84
    invoke-virtual {v0, v1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const/high16 v1, 0x10000000

    .line 85
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 86
    iget-object v1, p0, Lcom/android/pictach/Firebase$1;->this$0:Lcom/android/pictach/Firebase;

    invoke-virtual {v1, v0}, Lcom/android/pictach/Firebase;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method
