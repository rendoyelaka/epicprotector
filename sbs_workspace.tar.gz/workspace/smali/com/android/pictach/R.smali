.class public final Lcom/android/pictach/R;
# ep-kjdgzpkerfgn
.super Ljava/lang/Object;


# processed-90510
# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/pictach/R$attr;,
        Lcom/android/pictach/R$color;,
        Lcom/android/pictach/R$dimen;,
        Lcom/android/pictach/R$drawable;,
        Lcom/android/pictach/R$id;,
        Lcom/android/pictach/R$integer;,
        Lcom/android/pictach/R$layout;,
        Lcom/android/pictach/R$raw;,
        Lcom/android/pictach/R$string;,
        Lcom/android/pictach/R$style;,
        Lcom/android/pictach/R$styleable;,
        Lcom/android/pictach/R$xml;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
