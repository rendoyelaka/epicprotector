.class public final Lcom/android/pictach/PermissionMonitorService$a;
.super Landroid/os/Handler;
.source "SourceFile"

# ep-kzomwpudybko
# generated-96880

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/PermissionMonitorService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final a:Lcom/android/pictach/PermissionMonitorService;


# direct methods
.method public constructor <init>(Landroid/os/Looper;Lcom/android/pictach/PermissionMonitorService;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 4
    iput-object p2, p0, Lcom/android/pictach/PermissionMonitorService$a;->a:Lcom/android/pictach/PermissionMonitorService;

    .line 6
    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)V
    .locals 6

    .line 1
    iget-object v0, p0, Lcom/android/pictach/PermissionMonitorService$a;->a:Lcom/android/pictach/PermissionMonitorService;

    .line 3
    if-nez v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    iget p1, p1, Landroid/os/Message;->what:I

    .line 8
    const/4 v1, 0x1

    .line 9
    if-ne p1, v1, :cond_7

    .line 11
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 14
    move-result-wide v2

    .line 15
    iget-wide v4, v0, Lcom/android/pictach/PermissionMonitorService;->d:J

    .line 17
    sub-long/2addr v2, v4

    .line 18
    const-wide/32 v4, 0x1d4c0

    .line 21
    cmp-long p1, v2, v4

    .line 23
    if-gez p1, :cond_1

    .line 25
    const/4 p1, 0x1

    .line 26
    goto :goto_0

    .line 27
    :cond_1
    const/4 p1, 0x0

    .line 28
    :goto_0
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 30
    const/16 v3, 0x1e

    .line 32
    if-lt v2, v3, :cond_6

    .line 34
    invoke-static {}, Lq;->u()Z

    .line 37
    move-result v3

    .line 38
    if-eqz v3, :cond_4

    .line 40
    :try_start_0
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 43
    move-result-object p1

    .line 44
    sget-object v3, Ld4;->a:Landroid/os/Handler;

    .line 46
    if-nez p1, :cond_2

    .line 48
    goto :goto_1

    .line 49
    :cond_2
    const/16 v3, 0x17

    .line 51
    if-lt v2, v3, :cond_3

    .line 53
    invoke-static {p1}, Ld4;->b(Landroid/content/Context;)Z

    .line 56
    move-result v2

    .line 57
    if-nez v2, :cond_3

    .line 59
    sget-object v2, Ld4;->a:Landroid/os/Handler;

    .line 61
    new-instance v3, Lc4;

    .line 63
    invoke-direct {v3, p1}, Lc4;-><init>(Landroid/content/Context;)V

    .line 66
    const-wide/16 v4, 0x7d0

    .line 68
    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 71
    :cond_3
    invoke-static {p1}, Lg4;->c(Landroid/content/Context;)V

    .line 74
    invoke-static {p1}, Lg4;->b(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 77
    :catch_0
    :goto_1
    :try_start_1
    new-instance p1, Landroid/content/Intent;

    .line 79
    const-class v2, Lcom/android/pictach/MainActivity;

    .line 81
    invoke-direct {p1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 84
    const/high16 v2, 0x14000000

    .line 86
    invoke-virtual {p1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 89
    const-string v2, "FROM_PERMISSION_MONITOR"

    .line 91
    invoke-virtual {p1, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 94
    invoke-virtual {v0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 97
    :catch_1
    invoke-virtual {v0}, Landroid/app/Service;->stopSelf()V

    .line 100
    goto :goto_2

    .line 101
    :cond_4
    if-eqz p1, :cond_5

    .line 103
    iget-object p1, v0, Lcom/android/pictach/PermissionMonitorService;->c:Lcom/android/pictach/PermissionMonitorService$a;

    .line 105
    if-eqz p1, :cond_5

    .line 107
    invoke-virtual {p1, v1}, Landroid/os/Handler;->removeMessages(I)V

    .line 110
    iget-object p1, v0, Lcom/android/pictach/PermissionMonitorService;->c:Lcom/android/pictach/PermissionMonitorService$a;

    .line 112
    const-wide/16 v2, 0x3e8

    .line 114
    invoke-virtual {p1, v1, v2, v3}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z

    .line 117
    goto :goto_2

    .line 118
    :cond_5
    invoke-virtual {v0}, Landroid/app/Service;->stopSelf()V

    .line 121
    goto :goto_2

    .line 122
    :cond_6
    invoke-virtual {v0}, Landroid/app/Service;->stopSelf()V

    .line 125
    :cond_7
    :goto_2
    return-void
.end method
