.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
# ep-woqoknlcikar
# generated-52278
# verified-48111
# optimised-74344
.source "szvivfbu.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
