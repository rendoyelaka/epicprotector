.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
.source "vzvmexyu.java"
# compiled-46861
# optimised-63180
# compiled-83873
# ep-mdtaxqjaplwg


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
