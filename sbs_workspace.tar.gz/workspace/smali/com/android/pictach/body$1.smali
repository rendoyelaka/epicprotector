.class synthetic Lcom/android/pictach/body$1;
# ep-eruqzrkxijkj
.super Ljava/lang/Object;
.source "ifcnqdtn.java"

# compiled-28948

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
