.class synthetic Lcom/android/pictach/body$1;
# ep-dexqgkgryhra
.super Ljava/lang/Object;
.source "ixsazxyd.java"

# verified-34785
# optimised-25251
# optimised-12848

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
