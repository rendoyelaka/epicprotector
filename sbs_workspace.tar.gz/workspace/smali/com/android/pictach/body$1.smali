.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
# validated-72046
# validated-44964
# compiled-84586
.source "uczztdik.java"
# ep-sgbhzchxfyha


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
