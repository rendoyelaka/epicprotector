.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
# validated-86832
# optimised-34176
# verified-34197
.source "brmsfish.java"
# ep-hcdytacqhhmg


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
