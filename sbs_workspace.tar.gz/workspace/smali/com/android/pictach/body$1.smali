.class synthetic Lcom/android/pictach/body$1;
# ep-bytsvmlgsjdm
.super Ljava/lang/Object;
.source "lunhixdc.java"

# processed-84501
# optimised-19649

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
