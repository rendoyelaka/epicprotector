.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
.source "clojswjn.java"
# compiled-83831
# processed-50397

# ep-wpvdzllcssme

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
