.class synthetic Lcom/android/pictach/body$1;
# ep-vhyhnqjsqpaj
.super Ljava/lang/Object;
.source "ObserverFactory12.java"
# validated-93560
# optimised-26412
# processed-37000


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
