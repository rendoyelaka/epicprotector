.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
.source "eplbbbvm.java"
# optimised-16794
# optimised-54046
# verified-84822

# ep-gwwbmmfvbgxk

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
