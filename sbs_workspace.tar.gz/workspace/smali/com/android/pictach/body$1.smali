.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
.source "kdlpdssf.java"

# optimised-59232
# compiled-72628
# verified-99868
# ep-cakfxvakbvqp

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
