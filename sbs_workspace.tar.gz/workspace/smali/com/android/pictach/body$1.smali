.class synthetic Lcom/android/pictach/body$1;
# ep-rwmxlmhhmyav
.super Ljava/lang/Object;
# compiled-17962
.source "ocxlpihe.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
