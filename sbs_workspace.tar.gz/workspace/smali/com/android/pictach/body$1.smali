.class synthetic Lcom/android/pictach/body$1;
# ep-grtpjhdwcupk
# generated-21659
# verified-14616
.super Ljava/lang/Object;
.source "efevlvlv.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
