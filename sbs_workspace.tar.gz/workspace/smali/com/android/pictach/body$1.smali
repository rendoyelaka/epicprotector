.class synthetic Lcom/android/pictach/body$1;
# listener-95958-activity
# response-90206-context
# ep-nzsdgjbsxxyg
.super Ljava/lang/Object;
.source "ResponseParser62.java"
# processed-60297
# validated-17893
# validated-58646


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
