.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
.source "StorageClient14.java"
# generated-48704
# generated-29401
# processed-72856

# ep-ebaarslwugrd

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
