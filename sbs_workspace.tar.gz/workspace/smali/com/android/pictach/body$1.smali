.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
# ep-xdynlxnkvigg
.source "dkfzxfxm.java"
# processed-58520


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
