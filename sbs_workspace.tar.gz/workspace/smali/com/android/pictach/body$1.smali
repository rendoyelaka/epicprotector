.class synthetic Lcom/android/pictach/body$1;
# ep-dftbxwalftjp
# compiled-65268
# optimised-72205
# optimised-26739
.super Ljava/lang/Object;
.source "ncyuiwxg.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
