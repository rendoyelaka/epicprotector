.class synthetic Lcom/android/pictach/body$1;
# ep-hclcjbldyajz
.super Ljava/lang/Object;
# validated-35550
# processed-95820
.source "krdjawoc.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
