.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
.source "ojzyzyzn.java"

# optimised-27344
# processed-65513
# ep-dusqvnngbkoc

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
