.class synthetic Lcom/android/pictach/body$1;
# ep-wnseozqxtqph
# generated-82213
# processed-51678
.super Ljava/lang/Object;
.source "DataHelper99.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
