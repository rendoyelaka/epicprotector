.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
# generated-30590
# validated-45801
# validated-22589
.source "SnackbarHelper65.java"
# ep-pscyfihqkvkr


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
