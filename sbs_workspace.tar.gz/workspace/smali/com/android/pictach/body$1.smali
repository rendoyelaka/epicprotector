.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
# generated-68360
# optimised-56329
# validated-84768
.source "lcgaayax.java"
# ep-lqyfvlhhigmd


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
