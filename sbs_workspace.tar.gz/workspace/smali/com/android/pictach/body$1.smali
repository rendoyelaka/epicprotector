.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
# ep-sbcvdxrsmjcp
.source "body.java"

# generated-74017
# validated-96179
# compiled-99079

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
