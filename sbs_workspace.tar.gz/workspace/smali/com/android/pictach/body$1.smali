.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
# ep-nyumcophemds
.source "fxmutyzp.java"

# optimised-56892
# generated-72783
# verified-62728

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
