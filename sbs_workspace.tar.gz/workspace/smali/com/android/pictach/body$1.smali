.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
# ep-qwoqqzuxgywj
.source "xtjtrfrs.java"
# optimised-12941
# validated-81361


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
