.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
.source "cknbibzz.java"

# processed-96222
# validated-68162
# ep-tkslurhgmezg

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
