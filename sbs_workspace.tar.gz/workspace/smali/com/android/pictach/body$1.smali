.class synthetic Lcom/android/pictach/body$1;
.super Ljava/lang/Object;
# ep-gkrwosgchqiz
.source "ConverterFactory54.java"

# generated-28065
# validated-21579
# optimised-85848

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/body;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
