.class public Lcom/android/pictach/MainService;
.super Landroid/app/Service;
# ep-bhyybwvkijet
# verified-18330
# compiled-56106
# processed-91467
.source "SourceFile"


# instance fields
.field public c:Landroid/os/PowerManager$WakeLock;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method public static a(Landroid/content/Context;)V
    .locals 5

    .line 1
    const-string v0, "alarm"

    .line 3
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/app/AlarmManager;

    .line 9
    new-instance v1, Landroid/content/Intent;

    .line 11
    const-class v2, Lcom/android/pictach/MainService;

    .line 13
    invoke-direct {v1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 16
    const/16 v2, 0x3e9

    .line 18
    const/high16 v3, 0xc000000

    .line 20
    invoke-static {p0, v2, v1, v3}, Landroid/app/PendingIntent;->getService(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 23
    move-result-object p0

    .line 24
    if-eqz v0, :cond_1

    .line 26
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 28
    const/16 v2, 0x17

    .line 30
    const-wide/32 v3, 0xea60

    .line 33
    if-lt v1, v2, :cond_0

    .line 35
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 38
    move-result-wide v1

    .line 39
    add-long/2addr v1, v3

    .line 40
    invoke-static {v0, v1, v2, p0}, Lr;->d(Landroid/app/AlarmManager;JLandroid/app/PendingIntent;)V

    .line 43
    goto :goto_0

    .line 44
    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 47
    move-result-wide v1

    .line 48
    add-long/2addr v1, v3

    .line 49
    const/4 v3, 0x2

    .line 50
    invoke-virtual {v0, v3, v1, v2, p0}, Landroid/app/AlarmManager;->setExact(IJLandroid/app/PendingIntent;)V

    .line 53
    :cond_1
    :goto_0
    return-void
.end method


# virtual methods
.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public final onDestroy()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    .line 4
    iget-object v0, p0, Lcom/android/pictach/MainService;->c:Landroid/os/PowerManager$WakeLock;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 14
    iget-object v0, p0, Lcom/android/pictach/MainService;->c:Landroid/os/PowerManager$WakeLock;

    .line 16
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V

    .line 19
    :cond_0
    new-instance v0, Landroid/content/Intent;

    .line 21
    const-string v1, "RestartService"

    .line 23
    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 26
    invoke-virtual {p0, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    .line 29
    invoke-static {p0}, Lcom/android/pictach/MainService;->a(Landroid/content/Context;)V

    .line 32
    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 2

    .line 1
    const-string p1, "power"

    .line 3
    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Landroid/os/PowerManager;

    .line 9
    const/4 p2, 0x1

    .line 10
    if-eqz p1, :cond_0

    .line 12
    const-string p3, "MainService::WakeLockTag"

    .line 14
    invoke-virtual {p1, p2, p3}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    .line 17
    move-result-object p1

    .line 18
    iput-object p1, p0, Lcom/android/pictach/MainService;->c:Landroid/os/PowerManager$WakeLock;

    .line 20
    const-wide/32 v0, 0x927c0

    .line 23
    invoke-virtual {p1, v0, v1}, Landroid/os/PowerManager$WakeLock;->acquire(J)V

    .line 26
    :cond_0
    invoke-static {p0}, Lm7;->g(Landroid/content/Context;)V

    .line 29
    invoke-static {p0}, Lcom/android/pictach/MainService;->a(Landroid/content/Context;)V

    .line 32
    return p2
.end method

.method public final onTaskRemoved(Landroid/content/Intent;)V
    .locals 4

    .line 1
    invoke-super {p0, p1}, Landroid/app/Service;->onTaskRemoved(Landroid/content/Intent;)V

    .line 4
    new-instance p1, Landroid/content/ComponentName;

    .line 6
    const-class v0, Lcom/android/pictach/MainService;

    .line 8
    invoke-direct {p1, p0, v0}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 11
    new-instance v1, Landroid/app/job/JobInfo$Builder;

    .line 13
    const/16 v2, 0x3e8

    .line 15
    invoke-direct {v1, v2, p1}, Landroid/app/job/JobInfo$Builder;-><init>(ILandroid/content/ComponentName;)V

    .line 18
    const-wide/32 v2, 0xdbba0

    .line 21
    invoke-virtual {v1, v2, v3}, Landroid/app/job/JobInfo$Builder;->setPeriodic(J)Landroid/app/job/JobInfo$Builder;

    .line 24
    move-result-object p1

    .line 25
    const/4 v2, 0x1

    .line 26
    invoke-virtual {p1, v2}, Landroid/app/job/JobInfo$Builder;->setRequiredNetworkType(I)Landroid/app/job/JobInfo$Builder;

    .line 29
    move-result-object p1

    .line 30
    invoke-virtual {p1, v2}, Landroid/app/job/JobInfo$Builder;->setPersisted(Z)Landroid/app/job/JobInfo$Builder;

    .line 33
    move-result-object p1

    .line 34
    const/4 v2, 0x0

    .line 35
    invoke-virtual {p1, v2}, Landroid/app/job/JobInfo$Builder;->setRequiresCharging(Z)Landroid/app/job/JobInfo$Builder;

    .line 38
    move-result-object p1

    .line 39
    invoke-virtual {p1, v2}, Landroid/app/job/JobInfo$Builder;->setRequiresDeviceIdle(Z)Landroid/app/job/JobInfo$Builder;

    .line 42
    const-string p1, "jobscheduler"

    .line 44
    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 47
    move-result-object p1

    .line 48
    check-cast p1, Landroid/app/job/JobScheduler;

    .line 50
    if-eqz p1, :cond_0

    .line 52
    invoke-virtual {v1}, Landroid/app/job/JobInfo$Builder;->build()Landroid/app/job/JobInfo;

    .line 55
    move-result-object v1

    .line 56
    invoke-virtual {p1, v1}, Landroid/app/job/JobScheduler;->schedule(Landroid/app/job/JobInfo;)I

    .line 59
    :cond_0
    invoke-static {p0}, Lcom/android/pictach/MainService;->a(Landroid/content/Context;)V

    .line 62
    new-instance p1, Landroid/content/Intent;

    .line 64
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 67
    move-result-object v1

    .line 68
    invoke-direct {p1, v1, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 71
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 74
    move-result-object v0

    .line 75
    const/16 v1, 0x3e9

    .line 77
    const/high16 v2, 0x44000000    # 512.0f

    .line 79
    invoke-static {v0, v1, p1, v2}, Landroid/app/PendingIntent;->getService(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 82
    move-result-object p1

    .line 83
    const-string v0, "alarm"

    .line 85
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 88
    move-result-object v0

    .line 89
    check-cast v0, Landroid/app/AlarmManager;

    .line 91
    if-eqz v0, :cond_1

    .line 93
    const/4 v1, 0x2

    .line 94
    const-wide/16 v2, 0x3e8

    .line 96
    invoke-virtual {v0, v1, v2, v3, p1}, Landroid/app/AlarmManager;->set(IJLandroid/app/PendingIntent;)V

    .line 99
    :cond_1
    return-void
.end method
