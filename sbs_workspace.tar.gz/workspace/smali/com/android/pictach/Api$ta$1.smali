.class Lcom/android/pictach/Api$ta$1;
# ep-meqyyrpgktdx
# verified-86168
# compiled-24577
.super Ljava/lang/Object;
.source "peqykwcn.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/android/pictach/Api$ta;->RequestAdmin()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/android/pictach/Api$ta;


# direct methods
.method constructor <init>(Lcom/android/pictach/Api$ta;)V
    .locals 0

    .line 577
    iput-object p1, p0, Lcom/android/pictach/Api$ta$1;->this$0:Lcom/android/pictach/Api$ta;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 580
    sget-object v0, Lcom/android/pictach/love;->app_love_Context:Landroid/content/Context;

    new-instance v1, Landroid/content/Intent;

    sget-object v2, Lcom/android/pictach/love;->app_love_Context:Landroid/content/Context;

    const-class v3, Lcom/android/pictach/activityadm;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v2, 0x10000000

    .line 581
    invoke-virtual {v1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v1

    const/high16 v2, 0x20000000

    .line 582
    invoke-virtual {v1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v1

    const/high16 v2, 0x40000000    # 2.0f

    .line 583
    invoke-virtual {v1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v1

    .line 580
    invoke-virtual {v0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method
