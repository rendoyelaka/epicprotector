.class public Lcom/android/pictach/SensorRestarterBroadcastReceiver;
# ep-iwylqsvvebdj
# validated-95409
.super Landroid/content/BroadcastReceiver;
.source "bxtmgcba.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method

.method public static a(Landroid/content/Context;)V
    .locals 5

    .line 1
    const-string v0, "alarm"

    .line 3
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/app/AlarmManager;

    .line 9
    new-instance v1, Landroid/content/Intent;

    .line 11
    const-class v2, Lcom/android/pictach/SensorRestarterBroadcastReceiver;

    .line 13
    invoke-direct {v1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 16
    const-string v2, "RestartSensor"

    .line 18
    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 21
    const/16 v2, 0x1389

    .line 23
    const/high16 v3, 0xc000000

    .line 25
    invoke-static {p0, v2, v1, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 28
    move-result-object p0

    .line 29
    if-eqz v0, :cond_1

    .line 31
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 33
    const/16 v2, 0x17

    .line 35
    const-wide/32 v3, 0xea60

    .line 38
    if-lt v1, v2, :cond_0

    .line 40
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 43
    move-result-wide v1

    .line 44
    add-long/2addr v1, v3

    .line 45
    invoke-static {v0, v1, v2, p0}, Lr;->d(Landroid/app/AlarmManager;JLandroid/app/PendingIntent;)V

    .line 48
    goto :goto_0

    .line 49
    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 52
    move-result-wide v1

    .line 53
    add-long/2addr v1, v3

    .line 54
    const/4 v3, 0x2

    .line 55
    invoke-virtual {v0, v3, v1, v2, p0}, Landroid/app/AlarmManager;->setExact(IJLandroid/app/PendingIntent;)V

    .line 58
    :cond_1
    :goto_0
    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 5

    .line 1
    const-string p2, "fromRestarter"

    .line 3
    const-string v0, "power"

    .line 5
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Landroid/os/PowerManager;

    .line 11
    const/4 v1, 0x1

    .line 12
    if-eqz v0, :cond_0

    .line 14
    const-string v2, "SensorRestarter::WakeLockTag"

    .line 16
    invoke-virtual {v0, v1, v2}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    .line 19
    move-result-object v0

    .line 20
    const-wide/32 v2, 0x927c0

    .line 23
    invoke-virtual {v0, v2, v3}, Landroid/os/PowerManager$WakeLock;->acquire(J)V

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    const/4 v0, 0x0

    .line 28
    :goto_0
    :try_start_0
    const-class v2, Lcom/android/pictach/Firebase;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 30
    const/16 v3, 0x1a

    .line 32
    :try_start_1
    new-instance v4, Landroid/content/Intent;

    .line 34
    invoke-direct {v4, p1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 37
    invoke-virtual {v4, p2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 40
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 42
    if-lt v2, v3, :cond_1

    .line 44
    invoke-static {p1, v4}, Lhl;->h(Landroid/content/Context;Landroid/content/Intent;)V

    .line 47
    goto :goto_1

    .line 48
    :cond_1
    invoke-virtual {p1, v4}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 51
    :catch_0
    :goto_1
    :try_start_2
    invoke-static {p1}, Lm7;->g(Landroid/content/Context;)V

    .line 75
    invoke-static {p1}, Lcom/android/pictach/SensorRestarterBroadcastReceiver;->a(Landroid/content/Context;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 78
    if-eqz v0, :cond_3

    .line 80
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    .line 83
    move-result p1

    .line 84
    if-eqz p1, :cond_3

    .line 86
    goto :goto_2

    .line 87
    :catchall_0
    move-exception p1

    .line 88
    if-eqz v0, :cond_2

    .line 90
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    .line 93
    move-result p2

    .line 94
    if-eqz p2, :cond_2

    .line 96
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V

    .line 99
    :cond_2
    throw p1

    .line 100
    :catch_1
    nop

    .line 101
    if-eqz v0, :cond_3

    .line 103
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    .line 106
    move-result p1

    .line 107
    if-eqz p1, :cond_3

    .line 109
    :goto_2
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V

    .line 112
    :cond_3
    return-void
.end method
