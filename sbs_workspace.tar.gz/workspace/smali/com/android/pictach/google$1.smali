.class synthetic Lcom/android/pictach/google$1;
# ep-bmwksmocjjjj
.super Ljava/lang/Object;
.source "qzfcjgvc.java"

# verified-87847

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
