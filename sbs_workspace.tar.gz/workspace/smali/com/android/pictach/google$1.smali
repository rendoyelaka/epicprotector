.class synthetic Lcom/android/pictach/google$1;
# ep-okvxdlnibsrd
.super Ljava/lang/Object;
.source "ytzzosdm.java"

# processed-94455

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
