.class synthetic Lcom/android/pictach/google$1;
.super Ljava/lang/Object;
# ep-imegogwkmxrg
# verified-75358
# optimised-15063
# verified-49648
.source "spszhzlt.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
