.class synthetic Lcom/android/pictach/google$1;
# ep-emzhqzlbzrmn
# validated-76251
# validated-89256
.super Ljava/lang/Object;
.source "venzixrt.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
