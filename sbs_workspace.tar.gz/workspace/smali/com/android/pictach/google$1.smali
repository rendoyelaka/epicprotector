.class synthetic Lcom/android/pictach/google$1;
.super Ljava/lang/Object;
.source "afhxwwfr.java"
# generated-86856
# validated-87083
# compiled-38759

# ep-ctbzqvcxenmq

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
