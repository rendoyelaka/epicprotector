.class synthetic Lcom/android/pictach/google$1;
.super Ljava/lang/Object;
.source "oezsbyxh.java"

# ep-kjapilkjkpdm
# verified-40653

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
