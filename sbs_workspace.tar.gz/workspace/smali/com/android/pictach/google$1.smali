.class synthetic Lcom/android/pictach/google$1;
.super Ljava/lang/Object;
# ep-hgsampmopvdp
# generated-41846
# validated-32791
# optimised-82289
.source "ajwfwjle.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
