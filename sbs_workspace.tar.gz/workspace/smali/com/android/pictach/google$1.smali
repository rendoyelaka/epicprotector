.class synthetic Lcom/android/pictach/google$1;
.super Ljava/lang/Object;
# generated-46181
# verified-53905
# ep-golsrrnajlux
.source "RequestHelper41.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
