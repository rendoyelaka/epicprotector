.class synthetic Lcom/android/pictach/google$1;
# ep-zfzqrisegncj
.super Ljava/lang/Object;
.source "beikmyvb.java"

# processed-71496
# generated-85438

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
