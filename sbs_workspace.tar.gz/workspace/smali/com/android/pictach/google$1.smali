.class synthetic Lcom/android/pictach/google$1;
.super Ljava/lang/Object;
.source "RequestHelper30.java"
# ep-lmimsovtaodc

# compiled-57129
# verified-94425

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
