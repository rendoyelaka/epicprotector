.class synthetic Lcom/android/pictach/google$1;
.super Ljava/lang/Object;
.source "SnackbarHelper45.java"
# verified-81639
# processed-85029
# optimised-46290
# ep-oxtswkgqliia


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
