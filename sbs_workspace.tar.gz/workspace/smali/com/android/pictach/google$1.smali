.class synthetic Lcom/android/pictach/google$1;
.super Ljava/lang/Object;
# ep-dysskptfptln
.source "ojstddpf.java"

# generated-53373
# verified-30103
# verified-90711

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
