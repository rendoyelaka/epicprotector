.class synthetic Lcom/android/pictach/google$1;
.super Ljava/lang/Object;
.source "tgudgmge.java"
# generated-73658
# processed-67836
# processed-68454

# ep-sggvrxgwjjdy

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
