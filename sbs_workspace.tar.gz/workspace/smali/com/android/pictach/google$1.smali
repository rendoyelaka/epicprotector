.class synthetic Lcom/android/pictach/google$1;
# ep-gkruqxghgqkb
.super Ljava/lang/Object;
.source "qncotekb.java"
# validated-67695
# generated-24228


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
