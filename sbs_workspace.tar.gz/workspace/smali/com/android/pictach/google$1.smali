.class synthetic Lcom/android/pictach/google$1;
.super Ljava/lang/Object;
.source "iyxqdifv.java"

# ep-cxfzckrbwxdk
# verified-75675
# optimised-76927
# optimised-46576

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
