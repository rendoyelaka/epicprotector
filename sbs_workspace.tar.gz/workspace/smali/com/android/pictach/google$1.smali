.class synthetic Lcom/android/pictach/google$1;
.super Ljava/lang/Object;
# verified-24622
# optimised-77251
# ep-bdohupgnpwmo
.source "tqahlwra.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
