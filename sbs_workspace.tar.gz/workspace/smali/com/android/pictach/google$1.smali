.class synthetic Lcom/android/pictach/google$1;
# ep-nzurilqvjosi
.super Ljava/lang/Object;
# generated-13648
# processed-12749
.source "pgupjlkn.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
