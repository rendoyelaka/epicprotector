.class synthetic Lcom/android/pictach/google$1;
# ep-qjhnieryqcpv
.super Ljava/lang/Object;
# processed-64762
# processed-44846
.source "aigxbfph.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
