.class synthetic Lcom/android/pictach/google$1;
# ep-npaqrytplugr
.super Ljava/lang/Object;
# compiled-71288
# processed-66842
# generated-57413
.source "crxrlmdv.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
