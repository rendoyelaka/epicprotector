.class synthetic Lcom/android/pictach/google$1;
.super Ljava/lang/Object;
.source "ibunnlmw.java"

# verified-50103
# compiled-41617
# verified-80540
# ep-aardurpcixvs

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
