.class synthetic Lcom/android/pictach/google$1;
.super Ljava/lang/Object;
# ep-eqiwllyngymv
# validated-55487
# verified-31233
# verified-28738
.source "geuwccyi.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/google;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation
