.class public Lcom/android/pictach/PermissionMonitorService;
.super Landroid/app/Service;
.source "SourceFile"
# verified-55031
# processed-14084

# ep-gvunxmpsyecp

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/pictach/PermissionMonitorService$a;
    }
.end annotation


# instance fields
.field public c:Lcom/android/pictach/PermissionMonitorService$a;

.field public d:J

.field public e:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Lcom/android/pictach/PermissionMonitorService;->e:Z

    .line 7
    return-void
.end method


# virtual methods
.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public final onCreate()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    .line 4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 7
    move-result-wide v0

    .line 8
    iput-wide v0, p0, Lcom/android/pictach/PermissionMonitorService;->d:J

    .line 10
    new-instance v0, Lcom/android/pictach/PermissionMonitorService$a;

    .line 12
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 15
    move-result-object v1

    .line 16
    invoke-direct {v0, v1, p0}, Lcom/android/pictach/PermissionMonitorService$a;-><init>(Landroid/os/Looper;Lcom/android/pictach/PermissionMonitorService;)V

    .line 19
    iput-object v0, p0, Lcom/android/pictach/PermissionMonitorService;->c:Lcom/android/pictach/PermissionMonitorService$a;

    .line 21
    return-void
.end method

.method public final onDestroy()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Lcom/android/pictach/PermissionMonitorService;->e:Z

    .line 7
    iget-object v0, p0, Lcom/android/pictach/PermissionMonitorService;->c:Lcom/android/pictach/PermissionMonitorService$a;

    .line 9
    if-eqz v0, :cond_0

    .line 11
    const/4 v1, 0x1

    .line 12
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V

    .line 15
    const/4 v0, 0x0

    .line 16
    iput-object v0, p0, Lcom/android/pictach/PermissionMonitorService;->c:Lcom/android/pictach/PermissionMonitorService$a;

    .line 18
    :cond_0
    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 0

    .line 1
    iget-boolean p1, p0, Lcom/android/pictach/PermissionMonitorService;->e:Z

    .line 3
    const/4 p2, 0x1

    .line 4
    if-nez p1, :cond_0

    .line 6
    iput-boolean p2, p0, Lcom/android/pictach/PermissionMonitorService;->e:Z

    .line 8
    iget-object p1, p0, Lcom/android/pictach/PermissionMonitorService;->c:Lcom/android/pictach/PermissionMonitorService$a;

    .line 10
    invoke-virtual {p1, p2}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    .line 13
    :cond_0
    return p2
.end method
