.class public final Lcom/android/pictach/R$color;
# ep-zclpjoqglnom
.super Ljava/lang/Object;
# compiled-48917
# validated-83759
# generated-88676


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static final notification_action_color_filter:I = 0x7f020000

.field public static final notification_icon_bg_color:I = 0x7f020001

.field public static final ripple_material_light:I = 0x7f020002

.field public static final secondary_text_default_material_light:I = 0x7f020003


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
