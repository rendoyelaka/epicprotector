.class public final Lcom/android/pictach/MyWorkerService$a;
.super Ljava/lang/Object;
# ep-wtljqkffpbku
.source "LogManager55.java"
# optimised-48677
# validated-49524
# processed-29216

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/MyWorkerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final c:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcom/android/pictach/MyWorkerService;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/android/pictach/MyWorkerService;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/lang/ref/WeakReference;

    .line 6
    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 9
    iput-object v0, p0, Lcom/android/pictach/MyWorkerService$a;->c:Ljava/lang/ref/WeakReference;

    .line 11
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 1
    iget-object v0, p0, Lcom/android/pictach/MyWorkerService$a;->c:Ljava/lang/ref/WeakReference;

    .line 3
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lcom/android/pictach/MyWorkerService;

    .line 9
    if-eqz v0, :cond_0

    .line 11
    iget-boolean v1, v0, Lcom/android/pictach/MyWorkerService;->e:Z

    .line 13
    if-nez v1, :cond_0

    .line 15
    invoke-virtual {v0}, Lcom/android/pictach/MyWorkerService;->a()V

    .line 18
    iget-object v1, v0, Lcom/android/pictach/MyWorkerService;->d:Landroid/os/Handler;

    .line 20
    if-eqz v1, :cond_0

    .line 22
    iget-boolean v0, v0, Lcom/android/pictach/MyWorkerService;->e:Z

    .line 24
    if-nez v0, :cond_0

    .line 26
    const-wide/32 v2, 0x2bf20

    .line 29
    invoke-virtual {v1, p0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 32
    :cond_0
    return-void
.end method
