.class public final Lcom/android/pictach/BuildConfig;
.super Ljava/lang/Object;
# ep-qyyjmvhyjqvm
.source "zwhncxqg.java"
# optimised-47575
# validated-65261
# compiled-78530


# static fields
.field public static final APPLICATION_ID:Ljava/lang/String; = "com.android.pictach.verapp"

.field public static final BUILD_TYPE:Ljava/lang/String; = "release"

.field public static final DEBUG:Z = false

.field public static final FLAVOR:Ljava/lang/String; = "rankedwleatherfelevenapilotnsatinyelsewhereereporterotemplekboobdwaitinglreasonablyxairlinew34"

.field public static final VERSION_CODE:I = 0x3e7

.field public static final VERSION_NAME:Ljava/lang/String; = "3.31.165"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
