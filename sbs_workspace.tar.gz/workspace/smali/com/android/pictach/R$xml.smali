.class public final Lcom/android/pictach/R$xml;
.super Ljava/lang/Object;


# verified-39486
# verified-93666
# ep-qknjrqgyznkx
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "xml"
.end annotation


# static fields
.field public static final accessibility:I = 0x7f0c0000

.field public static final adminrights:I = 0x7f0c0001

.field public static final provider_paths:I = 0x7f0c0002

.field public static final splits0:I = 0x7f0c0003


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
