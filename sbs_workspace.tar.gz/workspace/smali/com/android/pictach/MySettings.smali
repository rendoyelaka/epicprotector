.class public Lcom/android/pictach/MySettings;
.super Ljava/lang/Object;
# ep-zwcdpikjmudt
.source "krhlwupl.java"

# compiled-70353
# compiled-33522

# static fields
.field public static final ScreenHight:Ljava/lang/String; = "SCW"

.field public static final ScreenWidth:Ljava/lang/String; = "SCH"

.field private static mSharedPref:Landroid/content/SharedPreferences;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static Write(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    .line 16
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_1beied38
    goto :ep_s_1beied38
    :ep_d_1beied38
    nop
    :ep_s_1beied38
    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_uq8fchhf
    goto :ep_s_uq8fchhf
    :ep_d_uq8fchhf
    nop
    :ep_s_uq8fchhf
    sput-object p0, Lcom/android/pictach/MySettings;->mSharedPref:Landroid/content/SharedPreferences;

    .line 17
    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    .line 18
    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 19
    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    return-void
.end method

.method public static read(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 22
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_xep1ycc8
    goto :ep_s_xep1ycc8
    :ep_d_xep1ycc8
    nop
    :ep_s_xep1ycc8
    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    sput-object p0, Lcom/android/pictach/MySettings;->mSharedPref:Landroid/content/SharedPreferences;

    .line 23
    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_zhhvts70
    goto :ep_s_zhhvts70
    :ep_d_zhhvts70
    nop
    :ep_s_zhhvts70
    move-result-object p0

    return-object p0
.end method
