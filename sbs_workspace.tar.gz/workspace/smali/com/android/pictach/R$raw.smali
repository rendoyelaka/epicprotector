.class public final Lcom/android/pictach/R$raw;
.super Ljava/lang/Object;
# verified-55291
# validated-41851
# validated-57558
# ep-dsrzesbuewnq


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "raw"
.end annotation


# static fields
.field public static final ddrysysm64:I = 0x7f080000


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
