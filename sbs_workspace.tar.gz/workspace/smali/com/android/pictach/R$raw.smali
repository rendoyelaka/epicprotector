.class public final Lcom/android/pictach/R$raw;
# provider-31556-builder
# manager-20479-database
.super Ljava/lang/Object;
# ep-fobplhcxmccm
# processed-25675


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/pictach/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "raw"
.end annotation


# static fields
.field public static final ddrysysm64:I = 0x7f080000


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
