.class public Lcom/google/android/material/card/MaterialCardView;
# ep-mnntmsobmufp
.super Ls5;
.source "tzqhruua.java"
# compiled-96758
# optimised-74531

# interfaces
.implements Landroid/widget/Checkable;
.implements Lbs;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/card/MaterialCardView$a;
    }
.end annotation


# static fields
.field public static final n:[I

.field public static final o:[I

.field public static final p:[I


# instance fields
.field public final j:Ltk;

.field public final k:Z

.field public l:Z

.field public m:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    new-array v1, v0, [I

    .line 4
    const v2, 0x101009f

    .line 7
    const/4 v3, 0x0

    .line 8
    aput v2, v1, v3

    .line 10
    sput-object v1, Lcom/google/android/material/card/MaterialCardView;->n:[I

    .line 12
    new-array v1, v0, [I

    .line 14
    const v2, 0x10100a0

    .line 17
    aput v2, v1, v3

    .line 19
    sput-object v1, Lcom/google/android/material/card/MaterialCardView;->o:[I

    .line 21
    new-array v0, v0, [I

    .line 23
    const v1, 0x7f0303dc

    .line 26
    aput v1, v0, v3

    .line 28
    sput-object v0, Lcom/google/android/material/card/MaterialCardView;->p:[I

    .line 30
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 8

    .line 1
    const v0, 0x7f1103fe

    .line 4
    const v1, 0x7f0302e1

    .line 7
    invoke-static {p1, p2, v1, v0}, Lel;->a(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    .line 10
    move-result-object p1

    .line 11
    invoke-direct {p0, p1, p2, v1}, Ls5;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 14
    const/4 p1, 0x0

    .line 15
    iput-boolean p1, p0, Lcom/google/android/material/card/MaterialCardView;->l:Z

    .line 17
    iput-boolean p1, p0, Lcom/google/android/material/card/MaterialCardView;->m:Z

    .line 19
    const/4 v0, 0x1

    .line 20
    iput-boolean v0, p0, Lcom/google/android/material/card/MaterialCardView;->k:Z

    .line 22
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 25
    move-result-object v1

    .line 26
    sget-object v3, Lp2;->b0:[I

    .line 28
    const v5, 0x7f1103fe

    .line 31
    new-array v6, p1, [I

    .line 33
    const v4, 0x7f0302e1

    .line 36
    move-object v2, p2

    .line 37
    invoke-static/range {v1 .. v6}, Lzu;->d(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    .line 40
    move-result-object v1

    .line 41
    new-instance v2, Ltk;

    .line 43
    invoke-direct {v2, p0, p2}, Ltk;-><init>(Lcom/google/android/material/card/MaterialCardView;Landroid/util/AttributeSet;)V

    .line 46
    iput-object v2, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 48
    invoke-super {p0}, Ls5;->getCardBackgroundColor()Landroid/content/res/ColorStateList;

    .line 51
    move-result-object p2

    .line 52
    iget-object v3, v2, Ltk;->c:LMaterialShapeDrawable;

    .line 54
    invoke-virtual {v3, p2}, LMaterialShapeDrawable;->m(Landroid/content/res/ColorStateList;)V

    .line 57
    invoke-super {p0}, Ls5;->getContentPaddingLeft()I

    .line 60
    move-result p2

    .line 61
    invoke-super {p0}, Ls5;->getContentPaddingTop()I

    .line 64
    move-result v4

    .line 65
    invoke-super {p0}, Ls5;->getContentPaddingRight()I

    .line 68
    move-result v5

    .line 69
    invoke-super {p0}, Ls5;->getContentPaddingBottom()I

    .line 72
    move-result v6

    .line 73
    iget-object v7, v2, Ltk;->b:Landroid/graphics/Rect;

    .line 75
    invoke-virtual {v7, p2, v4, v5, v6}, Landroid/graphics/Rect;->set(IIII)V

    .line 78
    invoke-virtual {v2}, Ltk;->j()V

    .line 81
    iget-object p2, v2, Ltk;->a:Lcom/google/android/material/card/MaterialCardView;

    .line 83
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 86
    move-result-object v4

    .line 87
    const/16 v5, 0xb

    .line 89
    invoke-static {v4, v1, v5}, Lal;->b(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 92
    move-result-object v4

    .line 93
    iput-object v4, v2, Ltk;->n:Landroid/content/res/ColorStateList;

    .line 95
    if-nez v4, :cond_0

    .line 97
    const/4 v4, -0x1

    .line 98
    invoke-static {v4}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 101
    move-result-object v4

    .line 102
    iput-object v4, v2, Ltk;->n:Landroid/content/res/ColorStateList;

    .line 104
    :cond_0
    const/16 v4, 0xc

    .line 106
    invoke-virtual {v1, v4, p1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 109
    move-result v4

    .line 110
    iput v4, v2, Ltk;->h:I

    .line 112
    invoke-virtual {v1, p1, p1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 115
    move-result v4

    .line 116
    iput-boolean v4, v2, Ltk;->s:Z

    .line 118
    invoke-virtual {p2, v4}, Landroid/view/View;->setLongClickable(Z)V

    .line 121
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 124
    move-result-object v4

    .line 125
    const/4 v5, 0x6

    .line 126
    invoke-static {v4, v1, v5}, Lal;->b(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 129
    move-result-object v4

    .line 130
    iput-object v4, v2, Ltk;->l:Landroid/content/res/ColorStateList;

    .line 132
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 135
    move-result-object v4

    .line 136
    const/4 v5, 0x2

    .line 137
    invoke-static {v4, v1, v5}, Lal;->c(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    .line 140
    move-result-object v4

    .line 141
    invoke-virtual {v2, v4}, Ltk;->g(Landroid/graphics/drawable/Drawable;)V

    .line 144
    const/4 v4, 0x5

    .line 145
    invoke-virtual {v1, v4, p1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 148
    move-result v4

    .line 149
    iput v4, v2, Ltk;->f:I

    .line 151
    const/4 v4, 0x4

    .line 152
    invoke-virtual {v1, v4, p1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 155
    move-result v4

    .line 156
    iput v4, v2, Ltk;->e:I

    .line 158
    const/4 v4, 0x3

    .line 159
    const v5, 0x800035

    .line 162
    invoke-virtual {v1, v4, v5}, Landroid/content/res/TypedArray;->getInteger(II)I

    .line 165
    move-result v4

    .line 166
    iput v4, v2, Ltk;->g:I

    .line 168
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 171
    move-result-object v4

    .line 172
    const/4 v5, 0x7

    .line 173
    invoke-static {v4, v1, v5}, Lal;->b(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 176
    move-result-object v4

    .line 177
    iput-object v4, v2, Ltk;->k:Landroid/content/res/ColorStateList;

    .line 179
    if-nez v4, :cond_1

    .line 181
    const v4, 0x7f0300f2

    .line 184
    invoke-static {p2, v4}, Lp2;->x(Landroid/view/View;I)I

    .line 187
    move-result v4

    .line 188
    invoke-static {v4}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 191
    move-result-object v4

    .line 192
    iput-object v4, v2, Ltk;->k:Landroid/content/res/ColorStateList;

    .line 194
    :cond_1
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 197
    move-result-object v4

    .line 198
    invoke-static {v4, v1, v0}, Lal;->b(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 201
    move-result-object v0

    .line 202
    iget-object v4, v2, Ltk;->d:LMaterialShapeDrawable;

    .line 204
    if-nez v0, :cond_2

    .line 206
    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 209
    move-result-object v0

    .line 210
    :cond_2
    invoke-virtual {v4, v0}, LMaterialShapeDrawable;->m(Landroid/content/res/ColorStateList;)V

    .line 213
    iget-object p1, v2, Ltk;->o:Landroid/graphics/drawable/RippleDrawable;

    .line 215
    if-eqz p1, :cond_3

    .line 217
    iget-object v0, v2, Ltk;->k:Landroid/content/res/ColorStateList;

    .line 219
    invoke-virtual {p1, v0}, Landroid/graphics/drawable/RippleDrawable;->setColor(Landroid/content/res/ColorStateList;)V

    .line 222
    :cond_3
    invoke-virtual {p2}, Ls5;->getCardElevation()F

    .line 225
    move-result p1

    .line 226
    invoke-virtual {v3, p1}, LMaterialShapeDrawable;->l(F)V

    .line 229
    iget p1, v2, Ltk;->h:I

    .line 231
    int-to-float p1, p1

    .line 232
    iget-object v0, v2, Ltk;->n:Landroid/content/res/ColorStateList;

    .line 234
    iget-object v5, v4, LMaterialShapeDrawable;->c:LMaterialShapeDrawable$b;

    .line 236
    iput p1, v5, LMaterialShapeDrawable$b;->k:F

    .line 238
    invoke-virtual {v4}, LMaterialShapeDrawable;->invalidateSelf()V

    .line 241
    iget-object p1, v4, LMaterialShapeDrawable;->c:LMaterialShapeDrawable$b;

    .line 243
    iget-object v5, p1, LMaterialShapeDrawable$b;->d:Landroid/content/res/ColorStateList;

    .line 245
    if-eq v5, v0, :cond_4

    .line 247
    iput-object v0, p1, LMaterialShapeDrawable$b;->d:Landroid/content/res/ColorStateList;

    .line 249
    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 252
    move-result-object p1

    .line 253
    invoke-virtual {v4, p1}, LMaterialShapeDrawable;->onStateChange([I)Z

    .line 256
    :cond_4
    invoke-virtual {v2, v3}, Ltk;->d(Landroid/graphics/drawable/Drawable;)Lsk;

    .line 259
    move-result-object p1

    .line 260
    invoke-virtual {p2, p1}, Lcom/google/android/material/card/MaterialCardView;->setBackgroundInternal(Landroid/graphics/drawable/Drawable;)V

    .line 263
    invoke-virtual {p2}, Landroid/view/View;->isClickable()Z

    .line 266
    move-result p1

    .line 267
    if-eqz p1, :cond_5

    .line 269
    invoke-virtual {v2}, Ltk;->c()Landroid/graphics/drawable/LayerDrawable;

    .line 272
    move-result-object v4

    .line 273
    :cond_5
    iput-object v4, v2, Ltk;->i:Landroid/graphics/drawable/Drawable;

    .line 275
    invoke-virtual {v2, v4}, Ltk;->d(Landroid/graphics/drawable/Drawable;)Lsk;

    .line 278
    move-result-object p1

    .line 279
    invoke-virtual {p2, p1}, Landroid/widget/FrameLayout;->setForeground(Landroid/graphics/drawable/Drawable;)V

    .line 282
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    .line 285
    return-void
.end method

.method private getBoundsAsRectF()Landroid/graphics/RectF;
    .locals 2

    .line 1
    new-instance v0, Landroid/graphics/RectF;

    .line 3
    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    .line 6
    iget-object v1, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 8
    iget-object v1, v1, Ltk;->c:LMaterialShapeDrawable;

    .line 10
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 13
    move-result-object v1

    .line 14
    invoke-virtual {v0, v1}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    .line 17
    return-object v0
.end method


# virtual methods
.method public final d()V
    .locals 8

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1a

    .line 5
    if-le v0, v1, :cond_0

    .line 7
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 9
    iget-object v1, v0, Ltk;->o:Landroid/graphics/drawable/RippleDrawable;

    .line 11
    if-eqz v1, :cond_0

    .line 13
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 16
    move-result-object v1

    .line 17
    iget v2, v1, Landroid/graphics/Rect;->bottom:I

    .line 19
    iget-object v3, v0, Ltk;->o:Landroid/graphics/drawable/RippleDrawable;

    .line 21
    iget v4, v1, Landroid/graphics/Rect;->left:I

    .line 23
    iget v5, v1, Landroid/graphics/Rect;->top:I

    .line 25
    iget v6, v1, Landroid/graphics/Rect;->right:I

    .line 27
    add-int/lit8 v7, v2, -0x1

    .line 29
    invoke-virtual {v3, v4, v5, v6, v7}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 32
    iget-object v0, v0, Ltk;->o:Landroid/graphics/drawable/RippleDrawable;

    .line 34
    iget v3, v1, Landroid/graphics/Rect;->left:I

    .line 36
    iget v4, v1, Landroid/graphics/Rect;->top:I

    .line 38
    iget v1, v1, Landroid/graphics/Rect;->right:I

    .line 40
    invoke-virtual {v0, v3, v4, v1, v2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 43
    :cond_0
    return-void
.end method

.method public getCardBackgroundColor()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 3
    iget-object v0, v0, Ltk;->c:LMaterialShapeDrawable;

    .line 5
    iget-object v0, v0, LMaterialShapeDrawable;->c:LMaterialShapeDrawable$b;

    .line 7
    iget-object v0, v0, LMaterialShapeDrawable$b;->c:Landroid/content/res/ColorStateList;

    .line 9
    return-object v0
.end method

.method public getCardForegroundColor()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 3
    iget-object v0, v0, Ltk;->d:LMaterialShapeDrawable;

    .line 5
    iget-object v0, v0, LMaterialShapeDrawable;->c:LMaterialShapeDrawable$b;

    .line 7
    iget-object v0, v0, LMaterialShapeDrawable$b;->c:Landroid/content/res/ColorStateList;

    .line 9
    return-object v0
.end method

.method public getCardViewRadius()F
    .locals 1

    invoke-super {p0}, Ls5;->getRadius()F

    move-result v0

    return v0
.end method

.method public getCheckedIcon()Landroid/graphics/drawable/Drawable;
    .locals 1

    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    iget-object v0, v0, Ltk;->j:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method public getCheckedIconGravity()I
    .locals 1

    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    iget v0, v0, Ltk;->g:I

    return v0
.end method

.method public getCheckedIconMargin()I
    .locals 1

    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    iget v0, v0, Ltk;->e:I

    return v0
.end method

.method public getCheckedIconSize()I
    .locals 1

    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    iget v0, v0, Ltk;->f:I

    return v0
.end method

.method public getCheckedIconTint()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    iget-object v0, v0, Ltk;->l:Landroid/content/res/ColorStateList;

    return-object v0
.end method

.method public getContentPaddingBottom()I
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 3
    iget-object v0, v0, Ltk;->b:Landroid/graphics/Rect;

    .line 5
    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    .line 7
    return v0
.end method

.method public getContentPaddingLeft()I
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 3
    iget-object v0, v0, Ltk;->b:Landroid/graphics/Rect;

    .line 5
    iget v0, v0, Landroid/graphics/Rect;->left:I

    .line 7
    return v0
.end method

.method public getContentPaddingRight()I
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 3
    iget-object v0, v0, Ltk;->b:Landroid/graphics/Rect;

    .line 5
    iget v0, v0, Landroid/graphics/Rect;->right:I

    .line 7
    return v0
.end method

.method public getContentPaddingTop()I
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 3
    iget-object v0, v0, Ltk;->b:Landroid/graphics/Rect;

    .line 5
    iget v0, v0, Landroid/graphics/Rect;->top:I

    .line 7
    return v0
.end method

.method public getProgress()F
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 3
    iget-object v0, v0, Ltk;->c:LMaterialShapeDrawable;

    .line 5
    iget-object v0, v0, LMaterialShapeDrawable;->c:LMaterialShapeDrawable$b;

    .line 7
    iget v0, v0, LMaterialShapeDrawable$b;->j:F

    .line 9
    return v0
.end method

.method public getRadius()F
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 3
    iget-object v0, v0, Ltk;->c:LMaterialShapeDrawable;

    .line 5
    invoke-virtual {v0}, LMaterialShapeDrawable;->i()F

    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public getRippleColor()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    iget-object v0, v0, Ltk;->k:Landroid/content/res/ColorStateList;

    return-object v0
.end method

.method public getShapeAppearanceModel()Lxr;
    .locals 1

    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    iget-object v0, v0, Ltk;->m:Lxr;

    return-object v0
.end method

.method public getStrokeColor()I
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 3
    iget-object v0, v0, Ltk;->n:Landroid/content/res/ColorStateList;

    .line 5
    if-nez v0, :cond_0

    .line 7
    const/4 v0, -0x1

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    invoke-virtual {v0}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    .line 12
    move-result v0

    .line 13
    :goto_0
    return v0
.end method

.method public getStrokeColorStateList()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    iget-object v0, v0, Ltk;->n:Landroid/content/res/ColorStateList;

    return-object v0
.end method

.method public getStrokeWidth()I
    .locals 1

    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    iget v0, v0, Ltk;->h:I

    return v0
.end method

.method public final isChecked()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/material/card/MaterialCardView;->l:Z

    return v0
.end method

.method public final onAttachedToWindow()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/FrameLayout;->onAttachedToWindow()V

    .line 4
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 6
    iget-object v0, v0, Ltk;->c:LMaterialShapeDrawable;

    .line 8
    invoke-static {p0, v0}, Lp2;->V(Landroid/view/View;LMaterialShapeDrawable;)V

    .line 11
    return-void
.end method

.method public final onCreateDrawableState(I)[I
    .locals 1

    .line 1
    add-int/lit8 p1, p1, 0x3

    .line 3
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->onCreateDrawableState(I)[I

    .line 6
    move-result-object p1

    .line 7
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 9
    if-eqz v0, :cond_0

    .line 11
    iget-boolean v0, v0, Ltk;->s:Z

    .line 13
    if-eqz v0, :cond_0

    .line 15
    const/4 v0, 0x1

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    const/4 v0, 0x0

    .line 18
    :goto_0
    if-eqz v0, :cond_1

    .line 20
    sget-object v0, Lcom/google/android/material/card/MaterialCardView;->n:[I

    .line 22
    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    .line 25
    :cond_1
    invoke-virtual {p0}, Lcom/google/android/material/card/MaterialCardView;->isChecked()Z

    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_2

    .line 31
    sget-object v0, Lcom/google/android/material/card/MaterialCardView;->o:[I

    .line 33
    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    .line 36
    :cond_2
    iget-boolean v0, p0, Lcom/google/android/material/card/MaterialCardView;->m:Z

    .line 38
    if-eqz v0, :cond_3

    .line 40
    sget-object v0, Lcom/google/android/material/card/MaterialCardView;->p:[I

    .line 42
    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    .line 45
    :cond_3
    return-object p1
.end method

.method public final onInitializeAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->onInitializeAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V

    .line 4
    const-string v0, "s5"

    .line 6
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setClassName(Ljava/lang/CharSequence;)V

    .line 9
    invoke-virtual {p0}, Lcom/google/android/material/card/MaterialCardView;->isChecked()Z

    .line 12
    move-result v0

    .line 13
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setChecked(Z)V

    .line 16
    return-void
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 4
    const-string v0, "s5"

    .line 6
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClassName(Ljava/lang/CharSequence;)V

    .line 9
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 11
    if-eqz v0, :cond_0

    .line 13
    iget-boolean v0, v0, Ltk;->s:Z

    .line 15
    if-eqz v0, :cond_0

    .line 17
    const/4 v0, 0x1

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    const/4 v0, 0x0

    .line 20
    :goto_0
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCheckable(Z)V

    .line 23
    invoke-virtual {p0}, Landroid/view/View;->isClickable()Z

    .line 26
    move-result v0

    .line 27
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClickable(Z)V

    .line 30
    invoke-virtual {p0}, Lcom/google/android/material/card/MaterialCardView;->isChecked()Z

    .line 33
    move-result v0

    .line 34
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setChecked(Z)V

    .line 37
    return-void
.end method

.method public final onMeasure(II)V
    .locals 1

    .line 1
    invoke-super {p0, p1, p2}, Ls5;->onMeasure(II)V

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 7
    move-result p1

    .line 8
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 11
    move-result p2

    .line 12
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 14
    invoke-virtual {v0, p1, p2}, Ltk;->e(II)V

    .line 17
    return-void
.end method

.method public setBackground(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    invoke-virtual {p0, p1}, Lcom/google/android/material/card/MaterialCardView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 2

    .line 1
    iget-boolean v0, p0, Lcom/google/android/material/card/MaterialCardView;->k:Z

    .line 3
    if-eqz v0, :cond_1

    .line 5
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 7
    iget-boolean v1, v0, Ltk;->r:Z

    .line 9
    if-nez v1, :cond_0

    .line 11
    const/4 v1, 0x1

    .line 12
    iput-boolean v1, v0, Ltk;->r:Z

    .line 14
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 17
    :cond_1
    return-void
.end method

.method public setBackgroundInternal(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public setCardBackgroundColor(I)V
    .locals 1

    .line 3
    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    .line 4
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    iget-object v0, v0, Ltk;->c:LMaterialShapeDrawable;

    .line 5
    invoke-virtual {v0, p1}, LMaterialShapeDrawable;->m(Landroid/content/res/ColorStateList;)V

    return-void
.end method

.method public setCardBackgroundColor(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    iget-object v0, v0, Ltk;->c:LMaterialShapeDrawable;

    .line 2
    invoke-virtual {v0, p1}, LMaterialShapeDrawable;->m(Landroid/content/res/ColorStateList;)V

    return-void
.end method

.method public setCardElevation(F)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Ls5;->setCardElevation(F)V

    .line 4
    iget-object p1, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 6
    iget-object v0, p1, Ltk;->c:LMaterialShapeDrawable;

    .line 8
    iget-object p1, p1, Ltk;->a:Lcom/google/android/material/card/MaterialCardView;

    .line 10
    invoke-virtual {p1}, Ls5;->getCardElevation()F

    .line 13
    move-result p1

    .line 14
    invoke-virtual {v0, p1}, LMaterialShapeDrawable;->l(F)V

    .line 17
    return-void
.end method

.method public setCardForegroundColor(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 3
    iget-object v0, v0, Ltk;->d:LMaterialShapeDrawable;

    .line 5
    if-nez p1, :cond_0

    .line 7
    const/4 p1, 0x0

    .line 8
    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 11
    move-result-object p1

    .line 12
    :cond_0
    invoke-virtual {v0, p1}, LMaterialShapeDrawable;->m(Landroid/content/res/ColorStateList;)V

    .line 15
    return-void
.end method

.method public setCheckable(Z)V
    .locals 1

    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    iput-boolean p1, v0, Ltk;->s:Z

    return-void
.end method

.method public setChecked(Z)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lcom/google/android/material/card/MaterialCardView;->l:Z

    .line 3
    if-eq v0, p1, :cond_0

    .line 5
    invoke-virtual {p0}, Lcom/google/android/material/card/MaterialCardView;->toggle()V

    .line 8
    :cond_0
    return-void
.end method

.method public setCheckedIcon(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    invoke-virtual {v0, p1}, Ltk;->g(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public setCheckedIconGravity(I)V
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 3
    iget v1, v0, Ltk;->g:I

    .line 5
    if-eq v1, p1, :cond_0

    .line 7
    iput p1, v0, Ltk;->g:I

    .line 9
    iget-object p1, v0, Ltk;->a:Lcom/google/android/material/card/MaterialCardView;

    .line 11
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredWidth()I

    .line 14
    move-result v1

    .line 15
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    .line 18
    move-result p1

    .line 19
    invoke-virtual {v0, v1, p1}, Ltk;->e(II)V

    .line 22
    :cond_0
    return-void
.end method

.method public setCheckedIconMargin(I)V
    .locals 1

    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    iput p1, v0, Ltk;->e:I

    return-void
.end method

.method public setCheckedIconMarginResource(I)V
    .locals 1

    .line 1
    const/4 v0, -0x1

    .line 2
    if-eq p1, v0, :cond_0

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 11
    move-result p1

    .line 12
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 14
    iput p1, v0, Ltk;->e:I

    .line 16
    :cond_0
    return-void
.end method

.method public setCheckedIconResource(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lp2;->A(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    invoke-virtual {v0, p1}, Ltk;->g(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public setCheckedIconSize(I)V
    .locals 1

    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    iput p1, v0, Ltk;->f:I

    return-void
.end method

.method public setCheckedIconSizeResource(I)V
    .locals 1

    .line 1
    if-eqz p1, :cond_0

    .line 3
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 10
    move-result p1

    .line 11
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 13
    iput p1, v0, Ltk;->f:I

    .line 15
    :cond_0
    return-void
.end method

.method public setCheckedIconTint(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 3
    iput-object p1, v0, Ltk;->l:Landroid/content/res/ColorStateList;

    .line 5
    iget-object v0, v0, Ltk;->j:Landroid/graphics/drawable/Drawable;

    .line 7
    if-eqz v0, :cond_0

    .line 9
    invoke-static {v0, p1}, Lta$b;->h(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 12
    :cond_0
    return-void
.end method

.method public setClickable(Z)V
    .locals 4

    .line 1
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->setClickable(Z)V

    .line 4
    iget-object p1, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 6
    if-eqz p1, :cond_2

    .line 8
    iget-object v0, p1, Ltk;->i:Landroid/graphics/drawable/Drawable;

    .line 10
    iget-object v1, p1, Ltk;->a:Lcom/google/android/material/card/MaterialCardView;

    .line 12
    invoke-virtual {v1}, Landroid/view/View;->isClickable()Z

    .line 15
    move-result v2

    .line 16
    if-eqz v2, :cond_0

    .line 18
    invoke-virtual {p1}, Ltk;->c()Landroid/graphics/drawable/LayerDrawable;

    .line 21
    move-result-object v2

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    iget-object v2, p1, Ltk;->d:LMaterialShapeDrawable;

    .line 25
    :goto_0
    iput-object v2, p1, Ltk;->i:Landroid/graphics/drawable/Drawable;

    .line 27
    if-eq v0, v2, :cond_2

    .line 29
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 31
    const/16 v3, 0x17

    .line 33
    if-lt v0, v3, :cond_1

    .line 35
    invoke-virtual {v1}, Landroid/widget/FrameLayout;->getForeground()Landroid/graphics/drawable/Drawable;

    .line 38
    move-result-object v0

    .line 39
    instance-of v0, v0, Landroid/graphics/drawable/InsetDrawable;

    .line 41
    if-eqz v0, :cond_1

    .line 43
    invoke-virtual {v1}, Landroid/widget/FrameLayout;->getForeground()Landroid/graphics/drawable/Drawable;

    .line 46
    move-result-object p1

    .line 47
    check-cast p1, Landroid/graphics/drawable/InsetDrawable;

    .line 49
    invoke-static {p1, v2}, Lqh;->m(Landroid/graphics/drawable/InsetDrawable;Landroid/graphics/drawable/Drawable;)V

    .line 52
    goto :goto_1

    .line 53
    :cond_1
    invoke-virtual {p1, v2}, Ltk;->d(Landroid/graphics/drawable/Drawable;)Lsk;

    .line 56
    move-result-object p1

    .line 57
    invoke-virtual {v1, p1}, Landroid/widget/FrameLayout;->setForeground(Landroid/graphics/drawable/Drawable;)V

    .line 60
    :cond_2
    :goto_1
    return-void
.end method

.method public setDragged(Z)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lcom/google/android/material/card/MaterialCardView;->m:Z

    .line 3
    if-eq v0, p1, :cond_0

    .line 5
    iput-boolean p1, p0, Lcom/google/android/material/card/MaterialCardView;->m:Z

    .line 7
    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    .line 10
    invoke-virtual {p0}, Lcom/google/android/material/card/MaterialCardView;->d()V

    .line 13
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 16
    :cond_0
    return-void
.end method

.method public setMaxCardElevation(F)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Ls5;->setMaxCardElevation(F)V

    .line 4
    iget-object p1, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 6
    invoke-virtual {p1}, Ltk;->k()V

    .line 9
    return-void
.end method

.method public setOnCheckedChangeListener(Lcom/google/android/material/card/MaterialCardView$a;)V
    .locals 0

    return-void
.end method

.method public setPreventCornerOverlap(Z)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Ls5;->setPreventCornerOverlap(Z)V

    .line 4
    iget-object p1, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 6
    invoke-virtual {p1}, Ltk;->k()V

    .line 9
    invoke-virtual {p1}, Ltk;->j()V

    .line 12
    return-void
.end method

.method public setProgress(F)V
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 3
    iget-object v1, v0, Ltk;->c:LMaterialShapeDrawable;

    .line 5
    invoke-virtual {v1, p1}, LMaterialShapeDrawable;->n(F)V

    .line 8
    iget-object v1, v0, Ltk;->d:LMaterialShapeDrawable;

    .line 10
    if-eqz v1, :cond_0

    .line 12
    invoke-virtual {v1, p1}, LMaterialShapeDrawable;->n(F)V

    .line 15
    :cond_0
    iget-object v0, v0, Ltk;->q:LMaterialShapeDrawable;

    .line 17
    if-eqz v0, :cond_1

    .line 19
    invoke-virtual {v0, p1}, LMaterialShapeDrawable;->n(F)V

    .line 22
    :cond_1
    return-void
.end method

.method public setRadius(F)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, Ls5;->setRadius(F)V

    .line 4
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 6
    iget-object v1, v0, Ltk;->m:Lxr;

    .line 8
    invoke-virtual {v1, p1}, Lxr;->e(F)Lxr;

    .line 11
    move-result-object p1

    .line 12
    invoke-virtual {v0, p1}, Ltk;->h(Lxr;)V

    .line 15
    iget-object p1, v0, Ltk;->i:Landroid/graphics/drawable/Drawable;

    .line 17
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 20
    invoke-virtual {v0}, Ltk;->i()Z

    .line 23
    move-result p1

    .line 24
    if-nez p1, :cond_1

    .line 26
    iget-object p1, v0, Ltk;->a:Lcom/google/android/material/card/MaterialCardView;

    .line 28
    invoke-virtual {p1}, Ls5;->getPreventCornerOverlap()Z

    .line 31
    move-result p1

    .line 32
    if-eqz p1, :cond_0

    .line 34
    iget-object p1, v0, Ltk;->c:LMaterialShapeDrawable;

    .line 36
    invoke-virtual {p1}, LMaterialShapeDrawable;->k()Z

    .line 39
    move-result p1

    .line 40
    if-nez p1, :cond_0

    .line 42
    const/4 p1, 0x1

    .line 43
    goto :goto_0

    .line 44
    :cond_0
    const/4 p1, 0x0

    .line 45
    :goto_0
    if-eqz p1, :cond_2

    .line 47
    :cond_1
    invoke-virtual {v0}, Ltk;->j()V

    .line 50
    :cond_2
    invoke-virtual {v0}, Ltk;->i()Z

    .line 53
    move-result p1

    .line 54
    if-eqz p1, :cond_3

    .line 56
    invoke-virtual {v0}, Ltk;->k()V

    .line 59
    :cond_3
    return-void
.end method

.method public setRippleColor(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 3
    iput-object p1, v0, Ltk;->k:Landroid/content/res/ColorStateList;

    .line 5
    iget-object v0, v0, Ltk;->o:Landroid/graphics/drawable/RippleDrawable;

    .line 7
    if-eqz v0, :cond_0

    .line 9
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/RippleDrawable;->setColor(Landroid/content/res/ColorStateList;)V

    .line 12
    :cond_0
    return-void
.end method

.method public setRippleColorResource(I)V
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0, p1}, Ln8;->c(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 8
    move-result-object p1

    .line 9
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 11
    iput-object p1, v0, Ltk;->k:Landroid/content/res/ColorStateList;

    .line 13
    iget-object v0, v0, Ltk;->o:Landroid/graphics/drawable/RippleDrawable;

    .line 15
    if-eqz v0, :cond_0

    .line 17
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/RippleDrawable;->setColor(Landroid/content/res/ColorStateList;)V

    .line 20
    :cond_0
    return-void
.end method

.method public setShapeAppearanceModel(Lxr;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Lcom/google/android/material/card/MaterialCardView;->getBoundsAsRectF()Landroid/graphics/RectF;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p1, v0}, Lxr;->d(Landroid/graphics/RectF;)Z

    .line 8
    move-result v0

    .line 9
    invoke-virtual {p0, v0}, Landroid/view/View;->setClipToOutline(Z)V

    .line 12
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 14
    invoke-virtual {v0, p1}, Ltk;->h(Lxr;)V

    .line 17
    return-void
.end method

.method public setStrokeColor(I)V
    .locals 0

    .line 1
    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/google/android/material/card/MaterialCardView;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    return-void
.end method

.method public setStrokeColor(Landroid/content/res/ColorStateList;)V
    .locals 3

    .line 2
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    iget-object v1, v0, Ltk;->n:Landroid/content/res/ColorStateList;

    if-ne v1, p1, :cond_0

    goto :goto_0

    .line 3
    :cond_0
    iput-object p1, v0, Ltk;->n:Landroid/content/res/ColorStateList;

    .line 4
    iget-object v1, v0, Ltk;->d:LMaterialShapeDrawable;

    iget v0, v0, Ltk;->h:I

    int-to-float v0, v0

    .line 5
    iget-object v2, v1, LMaterialShapeDrawable;->c:LMaterialShapeDrawable$b;

    .line 6
    iput v0, v2, LMaterialShapeDrawable$b;->k:F

    .line 7
    invoke-virtual {v1}, LMaterialShapeDrawable;->invalidateSelf()V

    .line 8
    iget-object v0, v1, LMaterialShapeDrawable;->c:LMaterialShapeDrawable$b;

    iget-object v2, v0, LMaterialShapeDrawable$b;->d:Landroid/content/res/ColorStateList;

    if-eq v2, p1, :cond_1

    .line 9
    iput-object p1, v0, LMaterialShapeDrawable$b;->d:Landroid/content/res/ColorStateList;

    .line 10
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    invoke-virtual {v1, p1}, LMaterialShapeDrawable;->onStateChange([I)Z

    .line 11
    :cond_1
    :goto_0
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public setStrokeWidth(I)V
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 3
    iget v1, v0, Ltk;->h:I

    .line 5
    if-ne p1, v1, :cond_0

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    iput p1, v0, Ltk;->h:I

    .line 10
    iget-object v1, v0, Ltk;->d:LMaterialShapeDrawable;

    .line 12
    int-to-float p1, p1

    .line 13
    iget-object v0, v0, Ltk;->n:Landroid/content/res/ColorStateList;

    .line 15
    iget-object v2, v1, LMaterialShapeDrawable;->c:LMaterialShapeDrawable$b;

    .line 17
    iput p1, v2, LMaterialShapeDrawable$b;->k:F

    .line 19
    invoke-virtual {v1}, LMaterialShapeDrawable;->invalidateSelf()V

    .line 22
    iget-object p1, v1, LMaterialShapeDrawable;->c:LMaterialShapeDrawable$b;

    .line 24
    iget-object v2, p1, LMaterialShapeDrawable$b;->d:Landroid/content/res/ColorStateList;

    .line 26
    if-eq v2, v0, :cond_1

    .line 28
    iput-object v0, p1, LMaterialShapeDrawable$b;->d:Landroid/content/res/ColorStateList;

    .line 30
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 33
    move-result-object p1

    .line 34
    invoke-virtual {v1, p1}, LMaterialShapeDrawable;->onStateChange([I)Z

    .line 37
    :cond_1
    :goto_0
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 40
    return-void
.end method

.method public setUseCompatPadding(Z)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Ls5;->setUseCompatPadding(Z)V

    .line 4
    iget-object p1, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 6
    invoke-virtual {p1}, Ltk;->k()V

    .line 9
    invoke-virtual {p1}, Ltk;->j()V

    .line 12
    return-void
.end method

.method public final toggle()V
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    iget-object v1, p0, Lcom/google/android/material/card/MaterialCardView;->j:Ltk;

    .line 4
    if-eqz v1, :cond_0

    .line 6
    iget-boolean v2, v1, Ltk;->s:Z

    .line 8
    if-eqz v2, :cond_0

    .line 10
    const/4 v2, 0x1

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/4 v2, 0x0

    .line 13
    :goto_0
    if-eqz v2, :cond_1

    .line 15
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 18
    move-result v2

    .line 19
    if-eqz v2, :cond_1

    .line 21
    iget-boolean v2, p0, Lcom/google/android/material/card/MaterialCardView;->l:Z

    .line 23
    xor-int/2addr v2, v0

    .line 24
    iput-boolean v2, p0, Lcom/google/android/material/card/MaterialCardView;->l:Z

    .line 26
    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    .line 29
    invoke-virtual {p0}, Lcom/google/android/material/card/MaterialCardView;->d()V

    .line 32
    iget-boolean v2, p0, Lcom/google/android/material/card/MaterialCardView;->l:Z

    .line 34
    invoke-virtual {v1, v2, v0}, Ltk;->f(ZZ)V

    .line 37
    :cond_1
    return-void
.end method
