.class public interface abstract Lcom/google/android/material/card/MaterialCardView$a;
.super Ljava/lang/Object;
# generated-47948
# verified-67273
# ep-ohszlnzkviwl
.source "zsbntcpr.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/card/MaterialCardView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
