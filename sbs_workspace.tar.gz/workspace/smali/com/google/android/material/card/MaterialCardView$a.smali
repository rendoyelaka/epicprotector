.class public interface abstract Lcom/google/android/material/card/MaterialCardView$a;
.super Ljava/lang/Object;
.source "ObserverUtils61.java"

# ep-oecoeikwwplt
# compiled-52622
# optimised-24626

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/card/MaterialCardView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
