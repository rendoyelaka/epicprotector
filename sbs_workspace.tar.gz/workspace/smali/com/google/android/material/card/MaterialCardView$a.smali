.class public interface abstract Lcom/google/android/material/card/MaterialCardView$a;
# ep-jftrlyopugsm
# verified-75685
# validated-45484
.super Ljava/lang/Object;
.source "uzqzggpn.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/card/MaterialCardView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
