.class public interface abstract Lcom/google/android/material/card/MaterialCardView$a;
# ep-dzatzlmbxsvm
.super Ljava/lang/Object;
.source "gudafsqu.java"
# generated-99038
# optimised-39855
# verified-40589


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/card/MaterialCardView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
