.class public interface abstract Lcom/google/android/material/card/MaterialCardView$a;
# builder-34533-database
# handler-15534-fragment
# loader-14662-layout
# network-12570-response
# fragment-94983-adapter
.super Ljava/lang/Object;
# ep-vkykjvpdofbs
.source "DataManager64.java"
# optimised-30534


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/card/MaterialCardView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
