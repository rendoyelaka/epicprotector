.class public interface abstract Lcom/google/android/material/card/MaterialCardView$a;
.super Ljava/lang/Object;
# optimised-80498
# verified-90936
.source "przbfwjm.java"
# ep-bdpcgmpvhrbv


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/card/MaterialCardView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
