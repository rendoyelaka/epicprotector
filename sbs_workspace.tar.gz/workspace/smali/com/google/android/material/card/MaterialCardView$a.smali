.class public interface abstract Lcom/google/android/material/card/MaterialCardView$a;
# ep-ztrvfbsakpkn
# processed-58342
# processed-99432
.super Ljava/lang/Object;
.source "kxbzkapn.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/card/MaterialCardView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
