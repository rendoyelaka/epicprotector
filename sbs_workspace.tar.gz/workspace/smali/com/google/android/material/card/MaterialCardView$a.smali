.class public interface abstract Lcom/google/android/material/card/MaterialCardView$a;
.super Ljava/lang/Object;
.source "lferbxci.java"
# generated-78379
# validated-94578
# validated-73410

# ep-bykzypxauelg

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/card/MaterialCardView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
