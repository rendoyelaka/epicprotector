.class public interface abstract Lcom/google/android/material/card/MaterialCardView$a;
# ep-ytrjagkenhrv
.super Ljava/lang/Object;
.source "dtxfgbbq.java"

# compiled-22704

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/card/MaterialCardView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
