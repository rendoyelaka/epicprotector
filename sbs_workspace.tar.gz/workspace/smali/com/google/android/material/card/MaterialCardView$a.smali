.class public interface abstract Lcom/google/android/material/card/MaterialCardView$a;
.super Ljava/lang/Object;
.source "ParserManager94.java"

# optimised-60910
# ep-yzqxmzdrpifq

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/card/MaterialCardView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
