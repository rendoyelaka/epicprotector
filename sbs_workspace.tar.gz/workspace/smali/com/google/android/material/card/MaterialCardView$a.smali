.class public interface abstract Lcom/google/android/material/card/MaterialCardView$a;
# ep-mbmjndiyajoc
# compiled-66107
# generated-45705
# processed-12970
.super Ljava/lang/Object;
.source "cgmpbpjv.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/card/MaterialCardView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
