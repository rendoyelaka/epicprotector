.class public final Lcom/google/android/material/button/MaterialButtonToggleGroup$c;
.super Ljava/lang/Object;
# ep-vppuwivevmic
# validated-22739
# processed-65370
.source "jhvkngmw.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButtonToggleGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# static fields
.field public static final e:Lc;


# instance fields
.field public final a:Lu8;

.field public final b:Lu8;

.field public final c:Lu8;

.field public final d:Lu8;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    new-instance v0, Lc;

    const/4 v1, 0x0

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_8lmg6hrc
    goto :ep_s_8lmg6hrc
    :ep_d_8lmg6hrc
    nop
    :ep_s_8lmg6hrc
    invoke-direct {v0, v1}, Lc;-><init>(F)V

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_cq2qxx3w
    goto :ep_s_cq2qxx3w
    :ep_d_cq2qxx3w
    nop
    :ep_s_cq2qxx3w
    sput-object v0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->e:Lc;

    return-void
.end method

.method public constructor <init>(Lu8;Lu8;Lu8;Lu8;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->a:Lu8;

    .line 6
    iput-object p3, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->b:Lu8;

    .line 8
    iput-object p4, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->c:Lu8;

    .line 10
    iput-object p2, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->d:Lu8;

    .line 12
    return-void
.end method
