.class public interface abstract Lcom/google/android/material/button/MaterialButtonToggleGroup$d;
.super Ljava/lang/Object;
# ep-nipumufcqcnj
.source "sisnmtfu.java"

# generated-47656
# processed-53847
# validated-53151

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButtonToggleGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method
