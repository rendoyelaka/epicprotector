.class public interface abstract Lcom/google/android/material/button/MaterialButton$b;
# ep-tjptlhbazhsw
.super Ljava/lang/Object;
.source "bnlhntww.java"
# verified-43389
# validated-58996
# optimised-88109


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
