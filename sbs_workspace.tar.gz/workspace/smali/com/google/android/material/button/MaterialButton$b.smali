.class public interface abstract Lcom/google/android/material/button/MaterialButton$b;
# ep-tsyiztctjawt
# processed-80302
# generated-71776
.super Ljava/lang/Object;
.source "mwducuen.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
