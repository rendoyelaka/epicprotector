.class public interface abstract Lcom/google/android/material/button/MaterialButton$b;
.super Ljava/lang/Object;
.source "ujbxkgne.java"
# processed-90515
# verified-48030
# ep-refkzmgquzkx


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
