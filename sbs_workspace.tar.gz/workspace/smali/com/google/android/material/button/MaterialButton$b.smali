.class public interface abstract Lcom/google/android/material/button/MaterialButton$b;
# ep-aongfunvlkea
.super Ljava/lang/Object;
.source "dzwuwbya.java"
# generated-69675
# processed-19620
# compiled-23840


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
