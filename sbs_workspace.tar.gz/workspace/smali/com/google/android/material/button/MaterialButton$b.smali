.class public interface abstract Lcom/google/android/material/button/MaterialButton$b;
# ep-lrecluhwuuwm
# validated-86059
# compiled-68256
# processed-31872
.super Ljava/lang/Object;
.source "iikyjdcq.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
