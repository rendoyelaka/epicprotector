.class public interface abstract Lcom/google/android/material/button/MaterialButton$b;
# ep-yqigxwnhcryd
.super Ljava/lang/Object;
# processed-45158
# optimised-23383
# validated-30838
.source "mwnlsruy.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
