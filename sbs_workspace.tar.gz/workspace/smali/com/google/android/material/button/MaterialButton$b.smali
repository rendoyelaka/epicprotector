.class public interface abstract Lcom/google/android/material/button/MaterialButton$b;
# ep-icuiggbtmyxy
.super Ljava/lang/Object;
.source "uyhmfkgl.java"
# generated-63391


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
