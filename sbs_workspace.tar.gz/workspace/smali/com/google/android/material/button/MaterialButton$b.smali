.class public interface abstract Lcom/google/android/material/button/MaterialButton$b;
# ep-jtxnnbuaakmv
# compiled-47474
.super Ljava/lang/Object;
.source "wlhtkvms.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
