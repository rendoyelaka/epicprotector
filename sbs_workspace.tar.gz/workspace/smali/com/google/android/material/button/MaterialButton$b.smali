.class public interface abstract Lcom/google/android/material/button/MaterialButton$b;
# ep-fecghzilwhge
.super Ljava/lang/Object;
# generated-25685
# generated-14914
# compiled-96760
.source "spjukkqr.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
