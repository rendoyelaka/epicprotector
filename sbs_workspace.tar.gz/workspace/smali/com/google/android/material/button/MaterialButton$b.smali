.class public interface abstract Lcom/google/android/material/button/MaterialButton$b;
# ep-xvpnvnvbgzwc
# processed-48172
.super Ljava/lang/Object;
.source "VideoUtils51.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
