.class public interface abstract Lcom/google/android/material/button/MaterialButton$b;
.super Ljava/lang/Object;
.source "hygmlmha.java"
# verified-57836

# ep-oxymvkwaynwp

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
