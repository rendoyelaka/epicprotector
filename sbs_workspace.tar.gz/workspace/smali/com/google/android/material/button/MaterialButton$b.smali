.class public interface abstract Lcom/google/android/material/button/MaterialButton$b;
.super Ljava/lang/Object;
.source "dafwkauf.java"
# ep-ixweufjvfajb
# processed-16428
# processed-75798
# verified-96317


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
