.class public interface abstract Lcom/google/android/material/button/MaterialButton$b;
# ep-shveauzttjbi
.super Ljava/lang/Object;
.source "fzakqngw.java"

# validated-74036
# compiled-22235
# validated-21509

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
