.class public interface abstract Lcom/google/android/material/button/MaterialButton$b;
# ep-flqtsadmqjhn
.super Ljava/lang/Object;
.source "vkeyltnx.java"
# validated-71325
# verified-67450
# validated-91267


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
