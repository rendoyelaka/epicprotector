.class public interface abstract Lcom/google/android/material/button/MaterialButton$a;
# ep-xdeveynahulh
# generated-76346
.super Ljava/lang/Object;
.source "WorkerClient49.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()V
.end method
