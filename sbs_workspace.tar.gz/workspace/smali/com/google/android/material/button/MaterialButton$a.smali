.class public interface abstract Lcom/google/android/material/button/MaterialButton$a;
# ep-ujslrelwfofa
.super Ljava/lang/Object;
# verified-10273
# compiled-78177
# processed-22958
.source "mohbhffs.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()V
.end method
