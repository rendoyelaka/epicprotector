.class public interface abstract Lcom/google/android/material/button/MaterialButton$a;
# ep-ymypwtwqeqow
.super Ljava/lang/Object;
.source "ttkrrzsh.java"
# verified-50201
# processed-18294
# validated-74438


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()V
.end method
