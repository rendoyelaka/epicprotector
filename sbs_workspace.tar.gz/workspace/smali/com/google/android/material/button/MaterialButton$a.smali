.class public interface abstract Lcom/google/android/material/button/MaterialButton$a;
# ep-eckwvgozvbxy
.super Ljava/lang/Object;
# compiled-81471
# validated-58162
# verified-30480
.source "ffzrjerh.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()V
.end method
