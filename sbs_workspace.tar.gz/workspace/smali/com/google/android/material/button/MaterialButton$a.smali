.class public interface abstract Lcom/google/android/material/button/MaterialButton$a;
# ep-iygrndpmhayy
.super Ljava/lang/Object;
# generated-96940
# compiled-50458
# compiled-25757
.source "ewdqxgwj.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()V
.end method
