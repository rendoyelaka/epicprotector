.class public interface abstract Lcom/google/android/material/button/MaterialButton$a;
# builder-80716-helper
# activity-86650-layout
.super Ljava/lang/Object;
.source "StorageClient94.java"
# validated-68532
# generated-51941
# compiled-20030
# ep-hjbkezqpnggv


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()V
.end method
