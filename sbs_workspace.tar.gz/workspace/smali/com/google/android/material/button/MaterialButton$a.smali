.class public interface abstract Lcom/google/android/material/button/MaterialButton$a;
# ep-jnlrseyztgvx
.super Ljava/lang/Object;
# compiled-96822
# verified-81429
# generated-77338
.source "anhskjeb.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()V
.end method
