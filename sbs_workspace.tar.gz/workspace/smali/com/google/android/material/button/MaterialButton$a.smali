.class public interface abstract Lcom/google/android/material/button/MaterialButton$a;
.super Ljava/lang/Object;
.source "rlxgejus.java"
# verified-63770
# validated-56133
# ep-felqqmlbfjyq


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()V
.end method
