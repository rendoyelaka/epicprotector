.class public interface abstract Lcom/google/android/material/button/MaterialButton$a;
# ep-mbfgiclzqsgr
# verified-12172
# optimised-91976
.super Ljava/lang/Object;
.source "csckhqkz.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()V
.end method
