.class public interface abstract Lcom/google/android/material/button/MaterialButton$a;
# ep-pxzumjogehrm
.super Ljava/lang/Object;
.source "smrmliru.java"
# processed-19215
# verified-99302
# optimised-31068


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()V
.end method
