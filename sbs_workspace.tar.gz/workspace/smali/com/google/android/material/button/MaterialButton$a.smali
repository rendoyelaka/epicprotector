.class public interface abstract Lcom/google/android/material/button/MaterialButton$a;
# ep-ncchhvjqoihh
.super Ljava/lang/Object;
.source "vqzmohfa.java"
# compiled-83769
# processed-98468


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()V
.end method
