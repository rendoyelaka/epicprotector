.class public interface abstract Lcom/google/android/material/button/MaterialButton$a;
# ep-scljypzyxeef
.super Ljava/lang/Object;
.source "vsukerdu.java"
# processed-75544


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()V
.end method
