.class public interface abstract Lcom/google/android/material/button/MaterialButton$a;
# ep-okrbydkcrusy
.super Ljava/lang/Object;
.source "nqlqmyhq.java"

# generated-32363
# validated-61422

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()V
.end method
