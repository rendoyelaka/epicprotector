.class public interface abstract Lcom/google/android/material/button/MaterialButton$a;
.super Ljava/lang/Object;
.source "zjlcqwmy.java"
# ep-pitqcrilomiv

# validated-97657
# validated-97431

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()V
.end method
