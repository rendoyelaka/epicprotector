.class public interface abstract Lcom/google/android/material/button/MaterialButton$a;
# ep-dokylwdwaboi
.super Ljava/lang/Object;
# processed-89849
# verified-61316
# verified-61888
.source "grrfxcua.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()V
.end method
