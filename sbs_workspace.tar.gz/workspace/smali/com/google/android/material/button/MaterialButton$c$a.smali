.class public final Lcom/google/android/material/button/MaterialButton$c$a;
# ep-euycyfdsbdds
# generated-46571
.super Ljava/lang/Object;
.source "ekehocbl.java"

# interfaces
.implements Landroid/os/Parcelable$ClassLoaderCreator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButton$c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$ClassLoaderCreator<",
        "Lcom/google/android/material/button/MaterialButton$c;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 2

    .line 2
    new-instance v0, Lcom/google/android/material/button/MaterialButton$c;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_y5ora4yo
    goto :ep_s_y5ora4yo
    :ep_d_y5ora4yo
    nop
    :ep_s_y5ora4yo
    const/4 v1, 0x0

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_g8xe6mfw
    goto :ep_s_g8xe6mfw
    :ep_d_g8xe6mfw
    nop
    :ep_s_g8xe6mfw
    invoke-direct {v0, p1, v1}, Lcom/google/android/material/button/MaterialButton$c;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    return-object v0
.end method

.method public final createFromParcel(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Ljava/lang/Object;
    .locals 1

    .line 1
    new-instance v0, Lcom/google/android/material/button/MaterialButton$c;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_klawrbnc
    goto :ep_s_klawrbnc
    :ep_d_klawrbnc
    nop
    :ep_s_klawrbnc
    invoke-direct {v0, p1, p2}, Lcom/google/android/material/button/MaterialButton$c;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    return-object v0
.end method

.method public final newArray(I)[Ljava/lang/Object;
    .locals 0

    new-array p1, p1, [Lcom/google/android/material/button/MaterialButton$c;

    return-object p1
.end method
