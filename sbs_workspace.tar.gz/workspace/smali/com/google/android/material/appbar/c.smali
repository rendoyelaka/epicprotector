.class public final Lcom/google/android/material/appbar/c;
.super Ljava/lang/Object;
.source "SourceFile"
# optimised-75343
# processed-63482

# ep-vwpmizeomtri
# interfaces
.implements Ly;


# instance fields
.field public final synthetic a:Lcom/google/android/material/appbar/AppBarLayout;

.field public final synthetic b:Z


# direct methods
.method public constructor <init>(Lcom/google/android/material/appbar/AppBarLayout;Z)V
    .locals 0

    iput-object p1, p0, Lcom/google/android/material/appbar/c;->a:Lcom/google/android/material/appbar/AppBarLayout;

    iput-boolean p2, p0, Lcom/google/android/material/appbar/c;->b:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;)Z
    .locals 1

    iget-object p1, p0, Lcom/google/android/material/appbar/c;->a:Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_kfhe15rx
    goto :ep_s_kfhe15rx
    :ep_d_kfhe15rx
    nop
    :ep_s_kfhe15rx
    iget-boolean v0, p0, Lcom/google/android/material/appbar/c;->b:Z

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_r2yge3i2
    goto :ep_s_r2yge3i2
    :ep_d_r2yge3i2
    nop
    :ep_s_r2yge3i2
    invoke-virtual {p1, v0}, Lcom/google/android/material/appbar/AppBarLayout;->setExpanded(Z)V

    const/4 p1, 0x1

    return p1
.end method
