.class public final Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b$a;
.super Ljava/lang/Object;
# ep-hmfizypwyhub
.source "tfpiwvwz.java"

# compiled-68900
# interfaces
.implements Landroid/os/Parcelable$ClassLoaderCreator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$ClassLoaderCreator<",
        "Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 2

    .line 2
    new-instance v0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_uoghf79n
    goto :ep_s_uoghf79n
    :ep_d_uoghf79n
    nop
    :ep_s_uoghf79n
    const/4 v1, 0x0

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_b38xybag
    goto :ep_s_b38xybag
    :ep_d_b38xybag
    nop
    :ep_s_b38xybag
    invoke-direct {v0, p1, v1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    return-object v0
.end method

.method public final createFromParcel(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Ljava/lang/Object;
    .locals 1

    .line 1
    new-instance v0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_zk5g8ggn
    goto :ep_s_zk5g8ggn
    :ep_d_zk5g8ggn
    nop
    :ep_s_zk5g8ggn
    invoke-direct {v0, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    return-object v0
.end method

.method public final newArray(I)[Ljava/lang/Object;
    .locals 0

    new-array p1, p1, [Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

    return-object p1
.end method
