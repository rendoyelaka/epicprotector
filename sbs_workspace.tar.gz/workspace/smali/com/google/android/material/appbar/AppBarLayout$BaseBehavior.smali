.class public Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;
.super Lhg;
.source "iyzrmxqe.java"
# optimised-99406
# ep-eezfbjmdmamx


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/appbar/AppBarLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "BaseBehavior"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Lcom/google/android/material/appbar/AppBarLayout;",
        ">",
        "Lhg<",
        "TT;>;"
    }
.end annotation


# instance fields
.field public j:I

.field public k:I

.field public l:Landroid/animation/ValueAnimator;

.field public m:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

.field public n:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field public o:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Lhg;-><init>()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    .line 2
    invoke-direct {p0, p1, p2}, Lhg;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public static C(Landroid/view/KeyEvent;Landroid/view/View;Lcom/google/android/material/appbar/AppBarLayout;)V
    .locals 6

    .line 1
    invoke-virtual {p0}, Landroid/view/KeyEvent;->getAction()I

    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {p0}, Landroid/view/KeyEvent;->getAction()I

    .line 11
    move-result v0

    .line 12
    if-ne v0, v1, :cond_4

    .line 14
    :cond_0
    invoke-virtual {p0}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 17
    move-result p0

    .line 18
    const/16 v0, 0x13

    .line 20
    if-eq p0, v0, :cond_3

    .line 22
    const/16 v0, 0x118

    .line 24
    if-eq p0, v0, :cond_3

    .line 26
    const/16 v0, 0x5c

    .line 28
    if-ne p0, v0, :cond_1

    .line 30
    goto :goto_0

    .line 31
    :cond_1
    const/16 v0, 0x14

    .line 33
    if-eq p0, v0, :cond_2

    .line 35
    const/16 v0, 0x119

    .line 37
    if-eq p0, v0, :cond_2

    .line 39
    const/16 v0, 0x5d

    .line 41
    if-ne p0, v0, :cond_4

    .line 43
    :cond_2
    invoke-virtual {p1}, Landroid/view/View;->getScrollY()I

    .line 46
    move-result p0

    .line 47
    if-lez p0, :cond_4

    .line 49
    const/4 p0, 0x0

    .line 50
    invoke-virtual {p2, p0}, Lcom/google/android/material/appbar/AppBarLayout;->setExpanded(Z)V

    .line 53
    goto :goto_1

    .line 54
    :cond_3
    :goto_0
    invoke-virtual {p1}, Landroid/view/View;->getScrollY()I

    .line 57
    move-result p0

    .line 58
    int-to-double v2, p0

    .line 59
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    .line 62
    move-result p0

    .line 63
    int-to-double p0, p0

    .line 64
    const-wide v4, 0x3fb999999999999aL    # 0.1

    .line 69
    mul-double p0, p0, v4

    .line 71
    cmpg-double v0, v2, p0

    .line 73
    if-gez v0, :cond_4

    .line 75
    invoke-virtual {p2, v1}, Lcom/google/android/material/appbar/AppBarLayout;->setExpanded(Z)V

    .line 78
    :cond_4
    :goto_1
    return-void
.end method

.method public static D(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)Landroid/view/View;
    .locals 4

    .line 1
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    :goto_0
    if-ge v1, v0, :cond_2

    .line 8
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 11
    move-result-object v2

    .line 12
    instance-of v3, v2, Lgm;

    .line 14
    if-nez v3, :cond_1

    .line 16
    instance-of v3, v2, Landroid/widget/AbsListView;

    .line 18
    if-nez v3, :cond_1

    .line 20
    instance-of v3, v2, Landroid/widget/ScrollView;

    .line 22
    if-eqz v3, :cond_0

    .line 24
    goto :goto_1

    .line 25
    :cond_0
    add-int/lit8 v1, v1, 0x1

    .line 27
    goto :goto_0

    .line 28
    :cond_1
    :goto_1
    return-object v2

    .line 29
    :cond_2
    const/4 p0, 0x0

    .line 30
    return-object p0
.end method

.method public static I(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;IIZ)V
    .locals 7

    .line 1
    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    .line 4
    move-result v0

    .line 5
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x0

    .line 10
    const/4 v3, 0x0

    .line 11
    :goto_0
    const/4 v4, 0x0

    .line 12
    if-ge v3, v1, :cond_1

    .line 14
    invoke-virtual {p1, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 17
    move-result-object v5

    .line 18
    invoke-virtual {v5}, Landroid/view/View;->getTop()I

    .line 21
    move-result v6

    .line 22
    if-lt v0, v6, :cond_0

    .line 24
    invoke-virtual {v5}, Landroid/view/View;->getBottom()I

    .line 27
    move-result v6

    .line 28
    if-gt v0, v6, :cond_0

    .line 30
    goto :goto_1

    .line 31
    :cond_0
    add-int/lit8 v3, v3, 0x1

    .line 33
    goto :goto_0

    .line 34
    :cond_1
    move-object v5, v4

    .line 35
    :goto_1
    const/4 v0, 0x1

    .line 36
    if-eqz v5, :cond_3

    .line 38
    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 41
    move-result-object v1

    .line 42
    check-cast v1, Lcom/google/android/material/appbar/AppBarLayout$c;

    .line 44
    iget v1, v1, Lcom/google/android/material/appbar/AppBarLayout$c;->a:I

    .line 46
    and-int/lit8 v3, v1, 0x1

    .line 48
    if-eqz v3, :cond_3

    .line 50
    sget-object v3, Lqx;->a:Ljava/util/WeakHashMap;

    .line 52
    invoke-static {v5}, Lqx$d;->d(Landroid/view/View;)I

    .line 55
    move-result v3

    .line 56
    if-lez p3, :cond_2

    .line 58
    and-int/lit8 p3, v1, 0xc

    .line 60
    if-eqz p3, :cond_2

    .line 62
    neg-int p2, p2

    .line 63
    invoke-virtual {v5}, Landroid/view/View;->getBottom()I

    .line 66
    move-result p3

    .line 67
    sub-int/2addr p3, v3

    .line 68
    invoke-virtual {p1}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    .line 71
    move-result v1

    .line 72
    sub-int/2addr p3, v1

    .line 73
    if-lt p2, p3, :cond_3

    .line 75
    goto :goto_2

    .line 76
    :cond_2
    and-int/lit8 p3, v1, 0x2

    .line 78
    if-eqz p3, :cond_3

    .line 80
    neg-int p2, p2

    .line 81
    invoke-virtual {v5}, Landroid/view/View;->getBottom()I

    .line 84
    move-result p3

    .line 85
    sub-int/2addr p3, v3

    .line 86
    invoke-virtual {p1}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    .line 89
    move-result v1

    .line 90
    sub-int/2addr p3, v1

    .line 91
    if-lt p2, p3, :cond_3

    .line 93
    :goto_2
    const/4 p2, 0x1

    .line 94
    goto :goto_3

    .line 95
    :cond_3
    const/4 p2, 0x0

    .line 96
    :goto_3
    iget-boolean p3, p1, Lcom/google/android/material/appbar/AppBarLayout;->m:Z

    .line 98
    if-eqz p3, :cond_4

    .line 100
    invoke-static {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->D(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)Landroid/view/View;

    .line 103
    move-result-object p2

    .line 104
    invoke-virtual {p1, p2}, Lcom/google/android/material/appbar/AppBarLayout;->e(Landroid/view/View;)Z

    .line 107
    move-result p2

    .line 108
    :cond_4
    invoke-virtual {p1, p2}, Lcom/google/android/material/appbar/AppBarLayout;->d(Z)Z

    .line 111
    move-result p2

    .line 112
    if-nez p4, :cond_8

    .line 114
    if-eqz p2, :cond_9

    .line 116
    iget-object p2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->d:La5;

    .line 118
    iget-object p2, p2, La5;->b:Ljava/lang/Object;

    .line 120
    check-cast p2, Lks;

    .line 122
    invoke-virtual {p2, p1, v4}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 125
    move-result-object p2

    .line 126
    check-cast p2, Ljava/util/List;

    .line 128
    iget-object p0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljava/util/ArrayList;

    .line 130
    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    .line 133
    if-eqz p2, :cond_5

    .line 135
    invoke-virtual {p0, p2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 138
    :cond_5
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 141
    move-result p2

    .line 142
    const/4 p3, 0x0

    .line 143
    :goto_4
    if-ge p3, p2, :cond_7

    .line 145
    invoke-interface {p0, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 148
    move-result-object p4

    .line 149
    check-cast p4, Landroid/view/View;

    .line 151
    invoke-virtual {p4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 154
    move-result-object p4

    .line 155
    check-cast p4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 157
    iget-object p4, p4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 159
    instance-of v1, p4, Lcom/google/android/material/appbar/AppBarLayout$ScrollingViewBehavior;

    .line 161
    if-eqz v1, :cond_6

    .line 163
    check-cast p4, Lcom/google/android/material/appbar/AppBarLayout$ScrollingViewBehavior;

    .line 165
    iget p0, p4, Lig;->f:I

    .line 167
    if-eqz p0, :cond_7

    .line 169
    const/4 v2, 0x1

    .line 170
    goto :goto_5

    .line 171
    :cond_6
    add-int/lit8 p3, p3, 0x1

    .line 173
    goto :goto_4

    .line 174
    :cond_7
    :goto_5
    if-eqz v2, :cond_9

    .line 176
    :cond_8
    invoke-virtual {p1}, Landroid/view/View;->jumpDrawablesToCurrentState()V

    .line 179
    :cond_9
    return-void
.end method


# virtual methods
.method public final B(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;I)V
    .locals 4

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->x()I

    .line 4
    move-result v0

    .line 5
    sub-int/2addr v0, p3

    .line 6
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    .line 9
    move-result v0

    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    .line 14
    move-result v2

    .line 15
    cmpl-float v1, v2, v1

    .line 17
    if-lez v1, :cond_0

    .line 19
    int-to-float v0, v0

    .line 20
    div-float/2addr v0, v2

    .line 21
    const/high16 v1, 0x447a0000    # 1000.0f

    .line 23
    mul-float v0, v0, v1

    .line 25
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    .line 28
    move-result v0

    .line 29
    mul-int/lit8 v0, v0, 0x3

    .line 31
    goto :goto_0

    .line 32
    :cond_0
    int-to-float v0, v0

    .line 33
    invoke-virtual {p2}, Landroid/view/View;->getHeight()I

    .line 36
    move-result v1

    .line 37
    int-to-float v1, v1

    .line 38
    div-float/2addr v0, v1

    .line 39
    const/high16 v1, 0x3f800000    # 1.0f

    .line 41
    add-float/2addr v0, v1

    .line 42
    const/high16 v1, 0x43160000    # 150.0f

    .line 44
    mul-float v0, v0, v1

    .line 46
    float-to-int v0, v0

    .line 47
    :goto_0
    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->x()I

    .line 50
    move-result v1

    .line 51
    if-ne v1, p3, :cond_1

    .line 53
    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->l:Landroid/animation/ValueAnimator;

    .line 55
    if-eqz p1, :cond_3

    .line 57
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->isRunning()Z

    .line 60
    move-result p1

    .line 61
    if-eqz p1, :cond_3

    .line 63
    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->l:Landroid/animation/ValueAnimator;

    .line 65
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->cancel()V

    .line 68
    goto :goto_2

    .line 69
    :cond_1
    iget-object v2, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->l:Landroid/animation/ValueAnimator;

    .line 71
    if-nez v2, :cond_2

    .line 73
    new-instance v2, Landroid/animation/ValueAnimator;

    .line 75
    invoke-direct {v2}, Landroid/animation/ValueAnimator;-><init>()V

    .line 78
    iput-object v2, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->l:Landroid/animation/ValueAnimator;

    .line 80
    sget-object v3, Ld1;->e:Landroid/view/animation/DecelerateInterpolator;

    .line 82
    invoke-virtual {v2, v3}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    .line 85
    iget-object v2, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->l:Landroid/animation/ValueAnimator;

    .line 87
    new-instance v3, Lcom/google/android/material/appbar/a;

    .line 89
    invoke-direct {v3, p0, p1, p2}, Lcom/google/android/material/appbar/a;-><init>(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V

    .line 92
    invoke-virtual {v2, v3}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    .line 95
    goto :goto_1

    .line 96
    :cond_2
    invoke-virtual {v2}, Landroid/animation/ValueAnimator;->cancel()V

    .line 99
    :goto_1
    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->l:Landroid/animation/ValueAnimator;

    .line 101
    const/16 p2, 0x258

    .line 103
    invoke-static {v0, p2}, Ljava/lang/Math;->min(II)I

    .line 106
    move-result p2

    .line 107
    int-to-long v2, p2

    .line 108
    invoke-virtual {p1, v2, v3}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    .line 111
    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->l:Landroid/animation/ValueAnimator;

    .line 113
    const/4 p2, 0x2

    .line 114
    new-array p2, p2, [I

    .line 116
    const/4 v0, 0x0

    .line 117
    aput v1, p2, v0

    .line 119
    const/4 v0, 0x1

    .line 120
    aput p3, p2, v0

    .line 122
    invoke-virtual {p1, p2}, Landroid/animation/ValueAnimator;->setIntValues([I)V

    .line 125
    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->l:Landroid/animation/ValueAnimator;

    .line 127
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->start()V

    .line 130
    :cond_3
    :goto_2
    return-void
.end method

.method public final E(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;I[I)V
    .locals 8

    .line 1
    if-eqz p4, :cond_1

    .line 3
    if-gez p4, :cond_0

    .line 5
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    .line 8
    move-result v0

    .line 9
    neg-int v0, v0

    .line 10
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getDownNestedPreScrollRange()I

    .line 13
    move-result v1

    .line 14
    add-int/2addr v1, v0

    .line 15
    move v6, v0

    .line 16
    move v7, v1

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getUpNestedPreScrollRange()I

    .line 21
    move-result v0

    .line 22
    neg-int v0, v0

    .line 23
    const/4 v1, 0x0

    .line 24
    move v6, v0

    .line 25
    const/4 v7, 0x0

    .line 26
    :goto_0
    if-eq v6, v7, :cond_1

    .line 28
    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->x()I

    .line 31
    move-result v0

    .line 32
    sub-int v5, v0, p4

    .line 34
    move-object v2, p0

    .line 35
    move-object v3, p1

    .line 36
    move-object v4, p2

    .line 37
    invoke-virtual/range {v2 .. v7}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->z(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;III)I

    .line 40
    move-result p1

    .line 41
    const/4 p4, 0x1

    .line 42
    aput p1, p5, p4

    .line 44
    :cond_1
    iget-boolean p1, p2, Lcom/google/android/material/appbar/AppBarLayout;->m:Z

    .line 46
    if-eqz p1, :cond_2

    .line 48
    invoke-virtual {p2, p3}, Lcom/google/android/material/appbar/AppBarLayout;->e(Landroid/view/View;)Z

    .line 51
    move-result p1

    .line 52
    invoke-virtual {p2, p1}, Lcom/google/android/material/appbar/AppBarLayout;->d(Z)Z

    .line 55
    :cond_2
    return-void
.end method

.method public final F(Landroid/os/Parcelable;Lcom/google/android/material/appbar/AppBarLayout;)Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcelable;",
            "TT;)",
            "Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;"
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, Lfy;->s()I

    .line 4
    move-result v0

    .line 5
    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x0

    .line 10
    const/4 v3, 0x0

    .line 11
    :goto_0
    if-ge v3, v1, :cond_5

    .line 13
    invoke-virtual {p2, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 16
    move-result-object v4

    .line 17
    invoke-virtual {v4}, Landroid/view/View;->getBottom()I

    .line 20
    move-result v5

    .line 21
    add-int/2addr v5, v0

    .line 22
    invoke-virtual {v4}, Landroid/view/View;->getTop()I

    .line 25
    move-result v6

    .line 26
    add-int/2addr v6, v0

    .line 27
    if-gtz v6, :cond_4

    .line 29
    if-ltz v5, :cond_4

    .line 31
    new-instance v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

    .line 33
    if-nez p1, :cond_0

    .line 35
    sget-object p1, Lb;->d:Lb$a;

    .line 37
    :cond_0
    invoke-direct {v1, p1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;-><init>(Landroid/os/Parcelable;)V

    .line 40
    const/4 p1, 0x1

    .line 41
    if-nez v0, :cond_1

    .line 43
    const/4 v6, 0x1

    .line 44
    goto :goto_1

    .line 45
    :cond_1
    const/4 v6, 0x0

    .line 46
    :goto_1
    iput-boolean v6, v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;->f:Z

    .line 48
    if-nez v6, :cond_2

    .line 50
    neg-int v0, v0

    .line 51
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    .line 54
    move-result v6

    .line 55
    if-lt v0, v6, :cond_2

    .line 57
    const/4 v0, 0x1

    .line 58
    goto :goto_2

    .line 59
    :cond_2
    const/4 v0, 0x0

    .line 60
    :goto_2
    iput-boolean v0, v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;->e:Z

    .line 62
    iput v3, v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;->g:I

    .line 64
    sget-object v0, Lqx;->a:Ljava/util/WeakHashMap;

    .line 66
    invoke-static {v4}, Lqx$d;->d(Landroid/view/View;)I

    .line 69
    move-result v0

    .line 70
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    .line 73
    move-result p2

    .line 74
    add-int/2addr p2, v0

    .line 75
    if-ne v5, p2, :cond_3

    .line 77
    const/4 v2, 0x1

    .line 78
    :cond_3
    iput-boolean v2, v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;->i:Z

    .line 80
    int-to-float p1, v5

    .line 81
    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    .line 84
    move-result p2

    .line 85
    int-to-float p2, p2

    .line 86
    div-float/2addr p1, p2

    .line 87
    iput p1, v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;->h:F

    .line 89
    return-object v1

    .line 90
    :cond_4
    add-int/lit8 v3, v3, 0x1

    .line 92
    goto :goto_0

    .line 93
    :cond_5
    const/4 p1, 0x0

    .line 94
    return-object p1
.end method

.method public final G(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;)V"
        }
    .end annotation

    .line 1
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    .line 4
    move-result v0

    .line 5
    invoke-virtual {p2}, Landroid/view/View;->getPaddingTop()I

    .line 8
    move-result v1

    .line 9
    add-int/2addr v1, v0

    .line 10
    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->x()I

    .line 13
    move-result v0

    .line 14
    sub-int/2addr v0, v1

    .line 15
    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    .line 18
    move-result v2

    .line 19
    const/4 v3, 0x0

    .line 20
    const/4 v4, 0x0

    .line 21
    :goto_0
    const/4 v5, 0x1

    .line 22
    const/16 v6, 0x20

    .line 24
    if-ge v4, v2, :cond_3

    .line 26
    invoke-virtual {p2, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 29
    move-result-object v7

    .line 30
    invoke-virtual {v7}, Landroid/view/View;->getTop()I

    .line 33
    move-result v8

    .line 34
    invoke-virtual {v7}, Landroid/view/View;->getBottom()I

    .line 37
    move-result v9

    .line 38
    invoke-virtual {v7}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 41
    move-result-object v7

    .line 42
    check-cast v7, Lcom/google/android/material/appbar/AppBarLayout$c;

    .line 44
    iget v10, v7, Lcom/google/android/material/appbar/AppBarLayout$c;->a:I

    .line 46
    and-int/2addr v10, v6

    .line 47
    if-ne v10, v6, :cond_0

    .line 49
    const/4 v10, 0x1

    .line 50
    goto :goto_1

    .line 51
    :cond_0
    const/4 v10, 0x0

    .line 52
    :goto_1
    if-eqz v10, :cond_1

    .line 54
    iget v10, v7, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 56
    sub-int/2addr v8, v10

    .line 57
    iget v7, v7, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 59
    add-int/2addr v9, v7

    .line 60
    :cond_1
    neg-int v7, v0

    .line 61
    if-gt v8, v7, :cond_2

    .line 63
    if-lt v9, v7, :cond_2

    .line 65
    goto :goto_2

    .line 66
    :cond_2
    add-int/lit8 v4, v4, 0x1

    .line 68
    goto :goto_0

    .line 69
    :cond_3
    const/4 v4, -0x1

    .line 70
    :goto_2
    if-ltz v4, :cond_d

    .line 72
    invoke-virtual {p2, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 75
    move-result-object v2

    .line 76
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 79
    move-result-object v7

    .line 80
    check-cast v7, Lcom/google/android/material/appbar/AppBarLayout$c;

    .line 82
    iget v8, v7, Lcom/google/android/material/appbar/AppBarLayout$c;->a:I

    .line 84
    and-int/lit8 v9, v8, 0x11

    .line 86
    const/16 v10, 0x11

    .line 88
    if-ne v9, v10, :cond_d

    .line 90
    invoke-virtual {v2}, Landroid/view/View;->getTop()I

    .line 93
    move-result v9

    .line 94
    neg-int v9, v9

    .line 95
    invoke-virtual {v2}, Landroid/view/View;->getBottom()I

    .line 98
    move-result v10

    .line 99
    neg-int v10, v10

    .line 100
    if-nez v4, :cond_4

    .line 102
    sget-object v4, Lqx;->a:Ljava/util/WeakHashMap;

    .line 104
    invoke-static {p2}, Lqx$d;->b(Landroid/view/View;)Z

    .line 107
    move-result v4

    .line 108
    if-eqz v4, :cond_4

    .line 110
    invoke-static {v2}, Lqx$d;->b(Landroid/view/View;)Z

    .line 113
    move-result v4

    .line 114
    if-eqz v4, :cond_4

    .line 116
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    .line 119
    move-result v4

    .line 120
    sub-int/2addr v9, v4

    .line 121
    :cond_4
    and-int/lit8 v4, v8, 0x2

    .line 123
    const/4 v11, 0x2

    .line 124
    if-ne v4, v11, :cond_5

    .line 126
    const/4 v4, 0x1

    .line 127
    goto :goto_3

    .line 128
    :cond_5
    const/4 v4, 0x0

    .line 129
    :goto_3
    if-eqz v4, :cond_6

    .line 131
    sget-object v4, Lqx;->a:Ljava/util/WeakHashMap;

    .line 133
    invoke-static {v2}, Lqx$d;->d(Landroid/view/View;)I

    .line 136
    move-result v2

    .line 137
    add-int/2addr v10, v2

    .line 138
    goto :goto_5

    .line 139
    :cond_6
    and-int/lit8 v4, v8, 0x5

    .line 141
    const/4 v12, 0x5

    .line 142
    if-ne v4, v12, :cond_7

    .line 144
    const/4 v4, 0x1

    .line 145
    goto :goto_4

    .line 146
    :cond_7
    const/4 v4, 0x0

    .line 147
    :goto_4
    if-eqz v4, :cond_9

    .line 149
    sget-object v4, Lqx;->a:Ljava/util/WeakHashMap;

    .line 151
    invoke-static {v2}, Lqx$d;->d(Landroid/view/View;)I

    .line 154
    move-result v2

    .line 155
    add-int/2addr v2, v10

    .line 156
    if-ge v0, v2, :cond_8

    .line 158
    move v9, v2

    .line 159
    goto :goto_5

    .line 160
    :cond_8
    move v10, v2

    .line 161
    :cond_9
    :goto_5
    and-int/lit8 v2, v8, 0x20

    .line 163
    if-ne v2, v6, :cond_a

    .line 165
    goto :goto_6

    .line 166
    :cond_a
    const/4 v5, 0x0

    .line 167
    :goto_6
    if-eqz v5, :cond_b

    .line 169
    iget v2, v7, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 171
    add-int/2addr v9, v2

    .line 172
    iget v2, v7, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 174
    sub-int/2addr v10, v2

    .line 175
    :cond_b
    add-int v2, v10, v9

    .line 177
    div-int/2addr v2, v11

    .line 178
    if-ge v0, v2, :cond_c

    .line 180
    move v9, v10

    .line 181
    :cond_c
    add-int/2addr v9, v1

    .line 182
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    .line 185
    move-result v0

    .line 186
    neg-int v0, v0

    .line 187
    invoke-static {v9, v0, v3}, Lp2;->n(III)I

    .line 190
    move-result v0

    .line 191
    invoke-virtual {p0, p1, p2, v0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->B(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;I)V

    .line 194
    :cond_d
    return-void
.end method

.method public final H(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;)V"
        }
    .end annotation

    .line 1
    sget-object v0, Lu$a;->f:Lu$a;

    .line 3
    invoke-virtual {v0}, Lu$a;->a()I

    .line 6
    move-result v0

    .line 7
    invoke-static {p1, v0}, Lqx;->m(Landroid/view/View;I)V

    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-static {p1, v0}, Lqx;->i(Landroid/view/View;I)V

    .line 14
    sget-object v1, Lu$a;->g:Lu$a;

    .line 16
    invoke-virtual {v1}, Lu$a;->a()I

    .line 19
    move-result v1

    .line 20
    invoke-static {p1, v1}, Lqx;->m(Landroid/view/View;I)V

    .line 23
    invoke-static {p1, v0}, Lqx;->i(Landroid/view/View;I)V

    .line 26
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    .line 29
    move-result v1

    .line 30
    if-nez v1, :cond_0

    .line 32
    return-void

    .line 33
    :cond_0
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    .line 36
    move-result v1

    .line 37
    const/4 v2, 0x0

    .line 38
    :goto_0
    if-ge v2, v1, :cond_2

    .line 40
    invoke-virtual {p1, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 43
    move-result-object v3

    .line 44
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 47
    move-result-object v4

    .line 48
    check-cast v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 50
    iget-object v4, v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 52
    instance-of v4, v4, Lcom/google/android/material/appbar/AppBarLayout$ScrollingViewBehavior;

    .line 54
    if-eqz v4, :cond_1

    .line 56
    goto :goto_1

    .line 57
    :cond_1
    add-int/lit8 v2, v2, 0x1

    .line 59
    goto :goto_0

    .line 60
    :cond_2
    const/4 v3, 0x0

    .line 61
    :goto_1
    move-object v8, v3

    .line 62
    if-nez v8, :cond_3

    .line 64
    return-void

    .line 65
    :cond_3
    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    .line 68
    move-result v1

    .line 69
    const/4 v2, 0x0

    .line 70
    :goto_2
    const/4 v3, 0x1

    .line 71
    if-ge v2, v1, :cond_5

    .line 73
    invoke-virtual {p2, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 76
    move-result-object v4

    .line 77
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 80
    move-result-object v4

    .line 81
    check-cast v4, Lcom/google/android/material/appbar/AppBarLayout$c;

    .line 83
    iget v4, v4, Lcom/google/android/material/appbar/AppBarLayout$c;->a:I

    .line 85
    if-eqz v4, :cond_4

    .line 87
    const/4 v1, 0x1

    .line 88
    goto :goto_3

    .line 89
    :cond_4
    add-int/lit8 v2, v2, 0x1

    .line 91
    goto :goto_2

    .line 92
    :cond_5
    const/4 v1, 0x0

    .line 93
    :goto_3
    if-nez v1, :cond_6

    .line 95
    return-void

    .line 96
    :cond_6
    invoke-static {p1}, Lqx;->c(Landroid/view/View;)Landroid/view/View$AccessibilityDelegate;

    .line 99
    move-result-object v1

    .line 100
    if-eqz v1, :cond_7

    .line 102
    const/4 v1, 0x1

    .line 103
    goto :goto_4

    .line 104
    :cond_7
    const/4 v1, 0x0

    .line 105
    :goto_4
    if-nez v1, :cond_8

    .line 107
    new-instance v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$a;

    .line 109
    invoke-direct {v1, p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$a;-><init>(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;)V

    .line 112
    invoke-static {p1, v1}, Lqx;->p(Landroid/view/View;Li;)V

    .line 115
    :cond_8
    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->x()I

    .line 118
    move-result v1

    .line 119
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    .line 122
    move-result v2

    .line 123
    neg-int v2, v2

    .line 124
    if-eq v1, v2, :cond_9

    .line 126
    sget-object v1, Lu$a;->f:Lu$a;

    .line 128
    new-instance v2, Lcom/google/android/material/appbar/c;

    .line 130
    invoke-direct {v2, p2, v0}, Lcom/google/android/material/appbar/c;-><init>(Lcom/google/android/material/appbar/AppBarLayout;Z)V

    .line 133
    invoke-static {p1, v1, v2}, Lqx;->n(Landroid/view/View;Lu$a;Ly;)V

    .line 136
    const/4 v0, 0x1

    .line 137
    :cond_9
    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->x()I

    .line 140
    move-result v1

    .line 141
    if-eqz v1, :cond_b

    .line 143
    const/4 v1, -0x1

    .line 144
    invoke-virtual {v8, v1}, Landroid/view/View;->canScrollVertically(I)Z

    .line 147
    move-result v1

    .line 148
    if-eqz v1, :cond_a

    .line 150
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getDownNestedPreScrollRange()I

    .line 153
    move-result v1

    .line 154
    neg-int v9, v1

    .line 155
    if-eqz v9, :cond_b

    .line 157
    sget-object v0, Lu$a;->g:Lu$a;

    .line 159
    new-instance v1, Lcom/google/android/material/appbar/b;

    .line 161
    move-object v4, v1

    .line 162
    move-object v5, p0

    .line 163
    move-object v6, p1

    .line 164
    move-object v7, p2

    .line 165
    invoke-direct/range {v4 .. v9}, Lcom/google/android/material/appbar/b;-><init>(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;I)V

    .line 168
    invoke-static {p1, v0, v1}, Lqx;->n(Landroid/view/View;Lu$a;Ly;)V

    .line 171
    goto :goto_5

    .line 172
    :cond_a
    sget-object v0, Lu$a;->g:Lu$a;

    .line 174
    new-instance v1, Lcom/google/android/material/appbar/c;

    .line 176
    invoke-direct {v1, p2, v3}, Lcom/google/android/material/appbar/c;-><init>(Lcom/google/android/material/appbar/AppBarLayout;Z)V

    .line 179
    invoke-static {p1, v0, v1}, Lqx;->n(Landroid/view/View;Lu$a;Ly;)V

    .line 182
    goto :goto_5

    .line 183
    :cond_b
    move v3, v0

    .line 184
    :goto_5
    iput-boolean v3, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->o:Z

    .line 186
    return-void
.end method

.method public final h(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z
    .locals 4

    .line 1
    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    .line 3
    invoke-super {p0, p1, p2, p3}, Lfy;->h(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z

    .line 6
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getPendingAction()I

    .line 9
    move-result p3

    .line 10
    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->m:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

    .line 12
    const/4 v1, 0x0

    .line 13
    const/4 v2, 0x1

    .line 14
    if-eqz v0, :cond_3

    .line 16
    and-int/lit8 v3, p3, 0x8

    .line 18
    if-nez v3, :cond_3

    .line 20
    iget-boolean p3, v0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;->e:Z

    .line 22
    if-eqz p3, :cond_0

    .line 24
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    .line 27
    move-result p3

    .line 28
    neg-int p3, p3

    .line 29
    invoke-virtual {p0, p1, p2, p3}, Lhg;->A(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)V

    .line 32
    goto :goto_2

    .line 33
    :cond_0
    iget-boolean p3, v0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;->f:Z

    .line 35
    if-eqz p3, :cond_1

    .line 37
    invoke-virtual {p0, p1, p2, v1}, Lhg;->A(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)V

    .line 40
    goto :goto_2

    .line 41
    :cond_1
    iget p3, v0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;->g:I

    .line 43
    invoke-virtual {p2, p3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 46
    move-result-object p3

    .line 47
    invoke-virtual {p3}, Landroid/view/View;->getBottom()I

    .line 50
    move-result v0

    .line 51
    neg-int v0, v0

    .line 52
    iget-object v3, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->m:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

    .line 54
    iget-boolean v3, v3, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;->i:Z

    .line 56
    if-eqz v3, :cond_2

    .line 58
    invoke-static {p3}, Lqx$d;->d(Landroid/view/View;)I

    .line 61
    move-result p3

    .line 62
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    .line 65
    move-result v3

    .line 66
    add-int/2addr v3, p3

    .line 67
    add-int/2addr v3, v0

    .line 68
    goto :goto_0

    .line 69
    :cond_2
    invoke-virtual {p3}, Landroid/view/View;->getHeight()I

    .line 72
    move-result p3

    .line 73
    int-to-float p3, p3

    .line 74
    iget-object v3, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->m:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

    .line 76
    iget v3, v3, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;->h:F

    .line 78
    mul-float p3, p3, v3

    .line 80
    invoke-static {p3}, Ljava/lang/Math;->round(F)I

    .line 83
    move-result p3

    .line 84
    add-int v3, p3, v0

    .line 86
    :goto_0
    invoke-virtual {p0, p1, p2, v3}, Lhg;->A(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)V

    .line 89
    goto :goto_2

    .line 90
    :cond_3
    if-eqz p3, :cond_8

    .line 92
    and-int/lit8 v0, p3, 0x4

    .line 94
    if-eqz v0, :cond_4

    .line 96
    const/4 v0, 0x1

    .line 97
    goto :goto_1

    .line 98
    :cond_4
    const/4 v0, 0x0

    .line 99
    :goto_1
    and-int/lit8 v3, p3, 0x2

    .line 101
    if-eqz v3, :cond_6

    .line 103
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getUpNestedPreScrollRange()I

    .line 106
    move-result p3

    .line 107
    neg-int p3, p3

    .line 108
    if-eqz v0, :cond_5

    .line 110
    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->B(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;I)V

    .line 113
    goto :goto_2

    .line 114
    :cond_5
    invoke-virtual {p0, p1, p2, p3}, Lhg;->A(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)V

    .line 117
    goto :goto_2

    .line 118
    :cond_6
    and-int/2addr p3, v2

    .line 119
    if-eqz p3, :cond_8

    .line 121
    if-eqz v0, :cond_7

    .line 123
    invoke-virtual {p0, p1, p2, v1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->B(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;I)V

    .line 126
    goto :goto_2

    .line 127
    :cond_7
    invoke-virtual {p0, p1, p2, v1}, Lhg;->A(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)V

    .line 130
    :cond_8
    :goto_2
    iput v1, p2, Lcom/google/android/material/appbar/AppBarLayout;->h:I

    .line 132
    const/4 p3, 0x0

    .line 133
    iput-object p3, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->m:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

    .line 135
    invoke-virtual {p0}, Lfy;->s()I

    .line 138
    move-result p3

    .line 139
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    .line 142
    move-result v0

    .line 143
    neg-int v0, v0

    .line 144
    invoke-static {p3, v0, v1}, Lp2;->n(III)I

    .line 147
    move-result p3

    .line 148
    iget-object v0, p0, Lfy;->a:Lgy;

    .line 150
    if-eqz v0, :cond_9

    .line 152
    iget v3, v0, Lgy;->d:I

    .line 154
    if-eq v3, p3, :cond_a

    .line 156
    iput p3, v0, Lgy;->d:I

    .line 158
    invoke-virtual {v0}, Lgy;->a()V

    .line 161
    goto :goto_3

    .line 162
    :cond_9
    iput p3, p0, Lfy;->b:I

    .line 164
    :cond_a
    :goto_3
    invoke-virtual {p0}, Lfy;->s()I

    .line 167
    move-result p3

    .line 168
    invoke-static {p1, p2, p3, v1, v2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->I(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;IIZ)V

    .line 171
    invoke-virtual {p0}, Lfy;->s()I

    .line 174
    move-result p3

    .line 175
    iput p3, p2, Lcom/google/android/material/appbar/AppBarLayout;->c:I

    .line 177
    invoke-virtual {p2}, Landroid/view/View;->willNotDraw()Z

    .line 180
    move-result p3

    .line 181
    if-nez p3, :cond_b

    .line 183
    sget-object p3, Lqx;->a:Ljava/util/WeakHashMap;

    .line 185
    invoke-static {p2}, Lqx$d;->k(Landroid/view/View;)V

    .line 188
    :cond_b
    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->H(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V

    .line 191
    invoke-static {p1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->D(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)Landroid/view/View;

    .line 194
    move-result-object p1

    .line 195
    if-eqz p1, :cond_d

    .line 197
    sget p3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 199
    const/16 v0, 0x1c

    .line 201
    if-lt p3, v0, :cond_c

    .line 203
    new-instance p3, Lh1;

    .line 205
    invoke-direct {p3, p0, p1, p2}, Lh1;-><init>(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;Landroid/view/View;Lcom/google/android/material/appbar/AppBarLayout;)V

    .line 208
    invoke-static {p1, p3}, Lo;->q(Landroid/view/View;Lh1;)V

    .line 211
    goto :goto_4

    .line 212
    :cond_c
    new-instance p3, Li1;

    .line 214
    invoke-direct {p3, p0, p1, p2}, Li1;-><init>(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;Landroid/view/View;Lcom/google/android/material/appbar/AppBarLayout;)V

    .line 217
    invoke-virtual {p1, p3}, Landroid/view/View;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 220
    :cond_d
    :goto_4
    return v2
.end method

.method public final i(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;III)Z
    .locals 2

    .line 1
    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    .line 3
    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 6
    move-result-object p5

    .line 7
    check-cast p5, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 9
    iget p5, p5, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 11
    const/4 v0, -0x2

    .line 12
    const/4 v1, 0x0

    .line 13
    if-ne p5, v0, :cond_0

    .line 15
    invoke-static {v1, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 18
    move-result p5

    .line 19
    invoke-virtual {p1, p2, p3, p4, p5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->q(Landroid/view/View;III)V

    .line 22
    const/4 v1, 0x1

    .line 23
    :cond_0
    return v1
.end method

.method public final bridge synthetic k(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;II[II)V
    .locals 6

    move-object v2, p2

    check-cast v2, Lcom/google/android/material/appbar/AppBarLayout;

    move-object v0, p0

    move-object v1, p1

    move-object v3, p3

    move v4, p5

    move-object v5, p6

    invoke-virtual/range {v0 .. v5}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->E(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;I[I)V

    return-void
.end method

.method public final l(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;III[I)V
    .locals 6

    .line 1
    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    .line 3
    if-gez p5, :cond_0

    .line 5
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getDownNestedScrollRange()I

    .line 8
    move-result p3

    .line 9
    neg-int v4, p3

    .line 10
    const/4 v5, 0x0

    .line 11
    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->x()I

    .line 14
    move-result p3

    .line 15
    sub-int v3, p3, p5

    .line 17
    move-object v0, p0

    .line 18
    move-object v1, p1

    .line 19
    move-object v2, p2

    .line 20
    invoke-virtual/range {v0 .. v5}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->z(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;III)I

    .line 23
    move-result p3

    .line 24
    const/4 p4, 0x1

    .line 25
    aput p3, p6, p4

    .line 27
    :cond_0
    if-nez p5, :cond_1

    .line 29
    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->H(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V

    .line 32
    :cond_1
    return-void
.end method

.method public final n(Landroid/view/View;Landroid/os/Parcelable;)V
    .locals 0

    .line 1
    check-cast p1, Lcom/google/android/material/appbar/AppBarLayout;

    .line 3
    instance-of p1, p2, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

    .line 5
    if-eqz p1, :cond_0

    .line 7
    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

    .line 9
    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->m:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

    .line 11
    iput-object p2, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->m:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 p1, 0x0

    .line 15
    iput-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->m:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

    .line 17
    :goto_0
    return-void
.end method

.method public final o(Landroid/view/View;)Landroid/os/Parcelable;
    .locals 1

    .line 1
    check-cast p1, Lcom/google/android/material/appbar/AppBarLayout;

    .line 3
    sget-object v0, Landroid/view/View$BaseSavedState;->EMPTY_STATE:Landroid/view/AbsSavedState;

    .line 5
    invoke-virtual {p0, v0, p1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->F(Landroid/os/Parcelable;Lcom/google/android/material/appbar/AppBarLayout;)Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

    .line 8
    move-result-object p1

    .line 9
    if-nez p1, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    move-object v0, p1

    .line 13
    :goto_0
    return-object v0
.end method

.method public final p(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;Landroid/view/View;II)Z
    .locals 1

    .line 1
    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    .line 3
    and-int/lit8 p4, p5, 0x2

    .line 5
    const/4 p5, 0x0

    .line 6
    if-eqz p4, :cond_3

    .line 8
    iget-boolean p4, p2, Lcom/google/android/material/appbar/AppBarLayout;->m:Z

    .line 10
    const/4 v0, 0x1

    .line 11
    if-nez p4, :cond_2

    .line 13
    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    .line 16
    move-result p4

    .line 17
    if-eqz p4, :cond_0

    .line 19
    const/4 p4, 0x1

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    const/4 p4, 0x0

    .line 22
    :goto_0
    if-eqz p4, :cond_1

    .line 24
    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    .line 27
    move-result p1

    .line 28
    invoke-virtual {p3}, Landroid/view/View;->getHeight()I

    .line 31
    move-result p3

    .line 32
    sub-int/2addr p1, p3

    .line 33
    invoke-virtual {p2}, Landroid/view/View;->getHeight()I

    .line 36
    move-result p2

    .line 37
    if-gt p1, p2, :cond_1

    .line 39
    const/4 p1, 0x1

    .line 40
    goto :goto_1

    .line 41
    :cond_1
    const/4 p1, 0x0

    .line 42
    :goto_1
    if-eqz p1, :cond_3

    .line 44
    :cond_2
    const/4 p5, 0x1

    .line 45
    :cond_3
    if-eqz p5, :cond_4

    .line 47
    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->l:Landroid/animation/ValueAnimator;

    .line 49
    if-eqz p1, :cond_4

    .line 51
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->cancel()V

    .line 54
    :cond_4
    const/4 p1, 0x0

    .line 55
    iput-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->n:Ljava/lang/ref/WeakReference;

    .line 57
    iput p6, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->k:I

    .line 59
    return p5
.end method

.method public final q(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;I)V
    .locals 1

    .line 1
    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    .line 3
    iget v0, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->k:I

    .line 5
    if-eqz v0, :cond_0

    .line 7
    const/4 v0, 0x1

    .line 8
    if-ne p4, v0, :cond_1

    .line 10
    :cond_0
    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->G(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V

    .line 13
    iget-boolean p1, p2, Lcom/google/android/material/appbar/AppBarLayout;->m:Z

    .line 15
    if-eqz p1, :cond_1

    .line 17
    invoke-virtual {p2, p3}, Lcom/google/android/material/appbar/AppBarLayout;->e(Landroid/view/View;)Z

    .line 20
    move-result p1

    .line 21
    invoke-virtual {p2, p1}, Lcom/google/android/material/appbar/AppBarLayout;->d(Z)Z

    .line 24
    :cond_1
    new-instance p1, Ljava/lang/ref/WeakReference;

    .line 26
    invoke-direct {p1, p3}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 29
    iput-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->n:Ljava/lang/ref/WeakReference;

    .line 31
    return-void
.end method

.method public final u(Landroid/view/View;)Z
    .locals 1

    .line 1
    check-cast p1, Lcom/google/android/material/appbar/AppBarLayout;

    .line 3
    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->n:Ljava/lang/ref/WeakReference;

    .line 5
    if-eqz p1, :cond_1

    .line 7
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 10
    move-result-object p1

    .line 11
    check-cast p1, Landroid/view/View;

    .line 13
    if-eqz p1, :cond_0

    .line 15
    invoke-virtual {p1}, Landroid/view/View;->isShown()Z

    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_0

    .line 21
    const/4 v0, -0x1

    .line 22
    invoke-virtual {p1, v0}, Landroid/view/View;->canScrollVertically(I)Z

    .line 25
    move-result p1

    .line 26
    if-nez p1, :cond_0

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    const/4 p1, 0x0

    .line 30
    goto :goto_1

    .line 31
    :cond_1
    :goto_0
    const/4 p1, 0x1

    .line 32
    :goto_1
    return p1
.end method

.method public final v(Landroid/view/View;)I
    .locals 0

    .line 1
    check-cast p1, Lcom/google/android/material/appbar/AppBarLayout;

    .line 3
    invoke-virtual {p1}, Lcom/google/android/material/appbar/AppBarLayout;->getDownNestedScrollRange()I

    .line 6
    move-result p1

    .line 7
    neg-int p1, p1

    .line 8
    return p1
.end method

.method public final w(Landroid/view/View;)I
    .locals 0

    .line 1
    check-cast p1, Lcom/google/android/material/appbar/AppBarLayout;

    .line 3
    invoke-virtual {p1}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    .line 6
    move-result p1

    .line 7
    return p1
.end method

.method public final x()I
    .locals 2

    invoke-virtual {p0}, Lfy;->s()I

    move-result v0

    iget v1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->j:I

    add-int/2addr v0, v1

    return v0
.end method

.method public final y(Landroid/view/View;Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V
    .locals 1

    .line 1
    check-cast p1, Lcom/google/android/material/appbar/AppBarLayout;

    .line 3
    invoke-virtual {p0, p2, p1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->G(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V

    .line 6
    iget-boolean v0, p1, Lcom/google/android/material/appbar/AppBarLayout;->m:Z

    .line 8
    if-eqz v0, :cond_0

    .line 10
    invoke-static {p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->D(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)Landroid/view/View;

    .line 13
    move-result-object p2

    .line 14
    invoke-virtual {p1, p2}, Lcom/google/android/material/appbar/AppBarLayout;->e(Landroid/view/View;)Z

    .line 17
    move-result p2

    .line 18
    invoke-virtual {p1, p2}, Lcom/google/android/material/appbar/AppBarLayout;->d(Z)Z

    .line 21
    :cond_0
    return-void
.end method

.method public final z(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;III)I
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    move/from16 v2, p4

    .line 7
    move-object/from16 v3, p2

    .line 9
    check-cast v3, Lcom/google/android/material/appbar/AppBarLayout;

    .line 11
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->x()I

    .line 14
    move-result v4

    .line 15
    const/4 v5, 0x0

    .line 16
    if-eqz v2, :cond_10

    .line 18
    if-lt v4, v2, :cond_10

    .line 20
    move/from16 v6, p5

    .line 22
    if-gt v4, v6, :cond_10

    .line 24
    invoke-static/range {p3 .. p5}, Lp2;->n(III)I

    .line 27
    move-result v2

    .line 28
    if-eq v4, v2, :cond_11

    .line 30
    iget-boolean v6, v3, Lcom/google/android/material/appbar/AppBarLayout;->g:Z

    .line 32
    if-eqz v6, :cond_4

    .line 34
    invoke-static {v2}, Ljava/lang/Math;->abs(I)I

    .line 37
    move-result v6

    .line 38
    invoke-virtual {v3}, Landroid/view/ViewGroup;->getChildCount()I

    .line 41
    move-result v7

    .line 42
    const/4 v8, 0x0

    .line 43
    :goto_0
    if-ge v8, v7, :cond_4

    .line 45
    invoke-virtual {v3, v8}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 48
    move-result-object v9

    .line 49
    invoke-virtual {v9}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 52
    move-result-object v10

    .line 53
    check-cast v10, Lcom/google/android/material/appbar/AppBarLayout$c;

    .line 55
    iget-object v11, v10, Lcom/google/android/material/appbar/AppBarLayout$c;->c:Landroid/view/animation/Interpolator;

    .line 57
    invoke-virtual {v9}, Landroid/view/View;->getTop()I

    .line 60
    move-result v12

    .line 61
    if-lt v6, v12, :cond_3

    .line 63
    invoke-virtual {v9}, Landroid/view/View;->getBottom()I

    .line 66
    move-result v12

    .line 67
    if-gt v6, v12, :cond_3

    .line 69
    if-eqz v11, :cond_4

    .line 71
    iget v7, v10, Lcom/google/android/material/appbar/AppBarLayout$c;->a:I

    .line 73
    and-int/lit8 v8, v7, 0x1

    .line 75
    if-eqz v8, :cond_0

    .line 77
    invoke-virtual {v9}, Landroid/view/View;->getHeight()I

    .line 80
    move-result v8

    .line 81
    iget v12, v10, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 83
    add-int/2addr v8, v12

    .line 84
    iget v10, v10, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 86
    add-int/2addr v8, v10

    .line 87
    add-int/2addr v8, v5

    .line 88
    and-int/lit8 v7, v7, 0x2

    .line 90
    if-eqz v7, :cond_1

    .line 92
    sget-object v7, Lqx;->a:Ljava/util/WeakHashMap;

    .line 94
    invoke-static {v9}, Lqx$d;->d(Landroid/view/View;)I

    .line 97
    move-result v7

    .line 98
    sub-int/2addr v8, v7

    .line 99
    goto :goto_1

    .line 100
    :cond_0
    const/4 v8, 0x0

    .line 101
    :cond_1
    :goto_1
    sget-object v7, Lqx;->a:Ljava/util/WeakHashMap;

    .line 103
    invoke-static {v9}, Lqx$d;->b(Landroid/view/View;)Z

    .line 106
    move-result v7

    .line 107
    if-eqz v7, :cond_2

    .line 109
    invoke-virtual {v3}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    .line 112
    move-result v7

    .line 113
    sub-int/2addr v8, v7

    .line 114
    :cond_2
    if-lez v8, :cond_4

    .line 116
    invoke-virtual {v9}, Landroid/view/View;->getTop()I

    .line 119
    move-result v7

    .line 120
    sub-int/2addr v6, v7

    .line 121
    int-to-float v7, v8

    .line 122
    int-to-float v6, v6

    .line 123
    div-float/2addr v6, v7

    .line 124
    invoke-interface {v11, v6}, Landroid/animation/TimeInterpolator;->getInterpolation(F)F

    .line 127
    move-result v6

    .line 128
    mul-float v6, v6, v7

    .line 130
    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    .line 133
    move-result v6

    .line 134
    invoke-static {v2}, Ljava/lang/Integer;->signum(I)I

    .line 137
    move-result v7

    .line 138
    invoke-virtual {v9}, Landroid/view/View;->getTop()I

    .line 141
    move-result v8

    .line 142
    add-int/2addr v8, v6

    .line 143
    mul-int v8, v8, v7

    .line 145
    goto :goto_2

    .line 146
    :cond_3
    add-int/lit8 v8, v8, 0x1

    .line 148
    goto :goto_0

    .line 149
    :cond_4
    move v8, v2

    .line 150
    :goto_2
    iget-object v6, v0, Lfy;->a:Lgy;

    .line 152
    const/4 v7, 0x1

    .line 153
    if-eqz v6, :cond_6

    .line 155
    iget v9, v6, Lgy;->d:I

    .line 157
    if-eq v9, v8, :cond_5

    .line 159
    iput v8, v6, Lgy;->d:I

    .line 161
    invoke-virtual {v6}, Lgy;->a()V

    .line 164
    const/4 v6, 0x1

    .line 165
    goto :goto_4

    .line 166
    :cond_5
    :goto_3
    const/4 v6, 0x0

    .line 167
    goto :goto_4

    .line 168
    :cond_6
    iput v8, v0, Lfy;->b:I

    .line 170
    goto :goto_3

    .line 171
    :goto_4
    sub-int v9, v4, v2

    .line 173
    sub-int v8, v2, v8

    .line 175
    iput v8, v0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->j:I

    .line 177
    const/4 v8, 0x0

    .line 178
    if-eqz v6, :cond_b

    .line 180
    const/4 v10, 0x0

    .line 181
    :goto_5
    invoke-virtual {v3}, Landroid/view/ViewGroup;->getChildCount()I

    .line 184
    move-result v11

    .line 185
    if-ge v10, v11, :cond_b

    .line 187
    invoke-virtual {v3, v10}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 190
    move-result-object v11

    .line 191
    invoke-virtual {v11}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 194
    move-result-object v11

    .line 195
    check-cast v11, Lcom/google/android/material/appbar/AppBarLayout$c;

    .line 197
    iget-object v12, v11, Lcom/google/android/material/appbar/AppBarLayout$c;->b:Lcom/google/android/material/appbar/AppBarLayout$b;

    .line 199
    if-eqz v12, :cond_a

    .line 201
    iget v11, v11, Lcom/google/android/material/appbar/AppBarLayout$c;->a:I

    .line 203
    and-int/2addr v11, v7

    .line 204
    if-eqz v11, :cond_a

    .line 206
    invoke-virtual {v3, v10}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 209
    move-result-object v11

    .line 210
    invoke-virtual/range {p0 .. p0}, Lfy;->s()I

    .line 213
    move-result v13

    .line 214
    int-to-float v13, v13

    .line 215
    iget-object v14, v12, Lcom/google/android/material/appbar/AppBarLayout$b;->a:Landroid/graphics/Rect;

    .line 217
    invoke-virtual {v11, v14}, Landroid/view/View;->getDrawingRect(Landroid/graphics/Rect;)V

    .line 220
    invoke-virtual {v3, v11, v14}, Landroid/view/ViewGroup;->offsetDescendantRectToMyCoords(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 223
    invoke-virtual {v3}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    .line 226
    move-result v15

    .line 227
    neg-int v15, v15

    .line 228
    invoke-virtual {v14, v5, v15}, Landroid/graphics/Rect;->offset(II)V

    .line 231
    iget v15, v14, Landroid/graphics/Rect;->top:I

    .line 233
    int-to-float v15, v15

    .line 234
    invoke-static {v13}, Ljava/lang/Math;->abs(F)F

    .line 237
    move-result v13

    .line 238
    sub-float/2addr v15, v13

    .line 239
    const/4 v13, 0x0

    .line 240
    cmpg-float v16, v15, v13

    .line 242
    if-gtz v16, :cond_9

    .line 244
    invoke-virtual {v14}, Landroid/graphics/Rect;->height()I

    .line 247
    move-result v7

    .line 248
    int-to-float v7, v7

    .line 249
    div-float v7, v15, v7

    .line 251
    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    .line 254
    move-result v7

    .line 255
    const/high16 v16, 0x3f800000    # 1.0f

    .line 257
    cmpg-float v17, v7, v13

    .line 259
    if-gez v17, :cond_7

    .line 261
    goto :goto_6

    .line 262
    :cond_7
    cmpl-float v13, v7, v16

    .line 264
    if-lez v13, :cond_8

    .line 266
    const/high16 v13, 0x3f800000    # 1.0f

    .line 268
    goto :goto_6

    .line 269
    :cond_8
    move v13, v7

    .line 270
    :goto_6
    neg-float v7, v15

    .line 271
    sub-float v13, v16, v13

    .line 273
    mul-float v13, v13, v13

    .line 275
    sub-float v16, v16, v13

    .line 277
    invoke-virtual {v14}, Landroid/graphics/Rect;->height()I

    .line 280
    move-result v13

    .line 281
    int-to-float v13, v13

    .line 282
    const v14, 0x3e99999a    # 0.3f

    .line 285
    mul-float v13, v13, v14

    .line 287
    mul-float v13, v13, v16

    .line 289
    sub-float/2addr v7, v13

    .line 290
    invoke-virtual {v11, v7}, Landroid/view/View;->setTranslationY(F)V

    .line 293
    iget-object v12, v12, Lcom/google/android/material/appbar/AppBarLayout$b;->b:Landroid/graphics/Rect;

    .line 295
    invoke-virtual {v11, v12}, Landroid/view/View;->getDrawingRect(Landroid/graphics/Rect;)V

    .line 298
    neg-float v7, v7

    .line 299
    float-to-int v7, v7

    .line 300
    invoke-virtual {v12, v5, v7}, Landroid/graphics/Rect;->offset(II)V

    .line 303
    sget-object v7, Lqx;->a:Ljava/util/WeakHashMap;

    .line 305
    invoke-static {v11, v12}, Lqx$f;->c(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 308
    goto :goto_7

    .line 309
    :cond_9
    sget-object v7, Lqx;->a:Ljava/util/WeakHashMap;

    .line 311
    invoke-static {v11, v8}, Lqx$f;->c(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 314
    invoke-virtual {v11, v13}, Landroid/view/View;->setTranslationY(F)V

    .line 317
    :cond_a
    :goto_7
    add-int/lit8 v10, v10, 0x1

    .line 319
    const/4 v7, 0x1

    .line 320
    goto/16 :goto_5

    .line 322
    :cond_b
    if-nez v6, :cond_d

    .line 324
    iget-boolean v6, v3, Lcom/google/android/material/appbar/AppBarLayout;->g:Z

    .line 326
    if-eqz v6, :cond_d

    .line 328
    iget-object v6, v1, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->d:La5;

    .line 330
    iget-object v6, v6, La5;->b:Ljava/lang/Object;

    .line 332
    check-cast v6, Lks;

    .line 334
    invoke-virtual {v6, v3, v8}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 337
    move-result-object v6

    .line 338
    check-cast v6, Ljava/util/List;

    .line 340
    if-eqz v6, :cond_d

    .line 342
    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    .line 345
    move-result v7

    .line 346
    if-nez v7, :cond_d

    .line 348
    const/4 v7, 0x0

    .line 349
    :goto_8
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 352
    move-result v8

    .line 353
    if-ge v7, v8, :cond_d

    .line 355
    invoke-interface {v6, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 358
    move-result-object v8

    .line 359
    check-cast v8, Landroid/view/View;

    .line 361
    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 364
    move-result-object v10

    .line 365
    check-cast v10, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 367
    iget-object v10, v10, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 369
    if-eqz v10, :cond_c

    .line 371
    invoke-virtual {v10, v1, v8, v3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->d(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z

    .line 374
    :cond_c
    add-int/lit8 v7, v7, 0x1

    .line 376
    goto :goto_8

    .line 377
    :cond_d
    invoke-virtual/range {p0 .. p0}, Lfy;->s()I

    .line 380
    move-result v6

    .line 381
    iput v6, v3, Lcom/google/android/material/appbar/AppBarLayout;->c:I

    .line 383
    invoke-virtual {v3}, Landroid/view/View;->willNotDraw()Z

    .line 386
    move-result v6

    .line 387
    if-nez v6, :cond_e

    .line 389
    sget-object v6, Lqx;->a:Ljava/util/WeakHashMap;

    .line 391
    invoke-static {v3}, Lqx$d;->k(Landroid/view/View;)V

    .line 394
    :cond_e
    if-ge v2, v4, :cond_f

    .line 396
    const/4 v7, -0x1

    .line 397
    goto :goto_9

    .line 398
    :cond_f
    const/4 v7, 0x1

    .line 399
    :goto_9
    invoke-static {v1, v3, v2, v7, v5}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->I(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;IIZ)V

    .line 402
    move v5, v9

    .line 403
    goto :goto_a

    .line 404
    :cond_10
    iput v5, v0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->j:I

    .line 406
    :cond_11
    :goto_a
    invoke-virtual {v0, v1, v3}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->H(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V

    .line 409
    return v5
.end method
