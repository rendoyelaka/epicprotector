.class public interface abstract Lcom/google/android/material/appbar/AppBarLayout$d;
.super Ljava/lang/Object;
# compiled-41532
# processed-28178
# validated-65650
# ep-hvhzhicxghdj
.source "whayfunr.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/appbar/AppBarLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method
