.class public interface abstract Lcom/google/android/material/appbar/AppBarLayout$d;
.super Ljava/lang/Object;
.source "SnackbarManager94.java"
# generated-46097
# compiled-25979
# validated-91675
# ep-dxhhbsoimmaz


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/appbar/AppBarLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method
