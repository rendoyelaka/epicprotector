.class public abstract Lcom/google/android/material/appbar/AppBarLayout$a;
# ep-aonvvqbjmovq
.super Ljava/lang/Object;
.source "xblnaxeb.java"

# compiled-10162
# generated-52534
# optimised-40159

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/appbar/AppBarLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
