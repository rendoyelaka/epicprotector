.class public abstract Lcom/google/android/material/appbar/AppBarLayout$a;
# layout-82372-config
# adapter-53979-provider
# observer-49875-adapter
.super Ljava/lang/Object;
# ep-bikozirubben
.source "ValidationUtils11.java"

# optimised-99618
# validated-88375
# verified-67992

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/appbar/AppBarLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
