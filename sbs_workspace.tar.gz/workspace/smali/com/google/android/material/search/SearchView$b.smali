.class public interface abstract Lcom/google/android/material/search/SearchView$b;
# ep-hwylcbnxxtea
# optimised-27861
# processed-18334
# optimised-59910
.super Ljava/lang/Object;
.source "bacsfhih.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/search/SearchView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method
