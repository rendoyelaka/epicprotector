.class public interface abstract Lcom/google/android/material/search/SearchView$b;
# ep-fkhapbwmsykw
.super Ljava/lang/Object;
.source "hlwqdemt.java"
# compiled-41006
# compiled-22220
# compiled-47540


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/search/SearchView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method
