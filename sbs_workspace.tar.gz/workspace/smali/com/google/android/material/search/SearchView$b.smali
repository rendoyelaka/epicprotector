.class public interface abstract Lcom/google/android/material/search/SearchView$b;
# ep-sqxgehbonzjk
.super Ljava/lang/Object;
.source "iwuoczwl.java"

# validated-34922
# optimised-90608

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/search/SearchView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method
