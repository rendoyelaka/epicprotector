.class public interface abstract Lcom/google/android/material/search/SearchView$b;
.super Ljava/lang/Object;
# validated-46228
.source "aesifpim.java"
# ep-oslojtkahqzc


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/search/SearchView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method
