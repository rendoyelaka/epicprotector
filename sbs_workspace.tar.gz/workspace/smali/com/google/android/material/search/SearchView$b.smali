.class public interface abstract Lcom/google/android/material/search/SearchView$b;
# ep-fraswtcsicqg
.super Ljava/lang/Object;
.source "leszlxup.java"
# generated-49719
# optimised-14770
# optimised-90706


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/search/SearchView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method
