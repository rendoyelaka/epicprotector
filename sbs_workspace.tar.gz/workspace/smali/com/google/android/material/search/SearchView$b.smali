.class public interface abstract Lcom/google/android/material/search/SearchView$b;
# ep-hbqnitnqmpsr
.super Ljava/lang/Object;
# verified-75579
# processed-45675
.source "uhporfwo.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/search/SearchView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method
