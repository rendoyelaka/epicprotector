.class public interface abstract Lcom/google/android/material/search/SearchView$b;
# session-30035-session
# database-38889-utils
# config-71890-layout
.super Ljava/lang/Object;
.source "SerializerHelper39.java"

# ep-dizqqahgdwfu
# optimised-80398
# compiled-51742
# validated-32142

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/search/SearchView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method
