.class public interface abstract Lcom/google/android/material/search/SearchView$b;
.super Ljava/lang/Object;
# ep-kojagpwwaftd
.source "yqrxowfd.java"
# optimised-59986
# validated-88232
# processed-63914


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/search/SearchView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method
