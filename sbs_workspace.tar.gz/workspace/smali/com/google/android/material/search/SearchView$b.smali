.class public interface abstract Lcom/google/android/material/search/SearchView$b;
# ep-bcumrdibixwv
.super Ljava/lang/Object;
# verified-35598
# optimised-36244
# processed-16015
.source "TokenHelper31.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/search/SearchView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method
