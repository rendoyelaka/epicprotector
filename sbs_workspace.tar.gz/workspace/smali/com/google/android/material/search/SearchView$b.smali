.class public interface abstract Lcom/google/android/material/search/SearchView$b;
# ep-hsozkuqvykgv
.super Ljava/lang/Object;
.source "znvecvfo.java"
# compiled-84568
# compiled-65162
# verified-13686


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/search/SearchView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method
