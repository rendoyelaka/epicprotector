.class public interface abstract Lcom/google/android/material/search/SearchView$b;
# ep-pvxlehnqoxym
.super Ljava/lang/Object;
.source "oehaxekl.java"

# generated-17047

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/search/SearchView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method
