.class public final Lcom/google/android/material/search/SearchBar$a$a;
.super Ljava/lang/Object;
# ep-qjtsiztgfjpw
.source "euhqngqw.java"
# processed-98209
# generated-27815
# optimised-15680

# interfaces
.implements Landroid/os/Parcelable$ClassLoaderCreator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/search/SearchBar$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$ClassLoaderCreator<",
        "Lcom/google/android/material/search/SearchBar$a;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 2

    .line 2
    new-instance v0, Lcom/google/android/material/search/SearchBar$a;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_662wyh62
    goto :ep_s_662wyh62
    :ep_d_662wyh62
    nop
    :ep_s_662wyh62
    const/4 v1, 0x0

    .line 3
    invoke-direct {v0, p1, v1}, Lcom/google/android/material/search/SearchBar$a;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    return-object v0
.end method

.method public final createFromParcel(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Ljava/lang/Object;
    .locals 1

    .line 1
    new-instance v0, Lcom/google/android/material/search/SearchBar$a;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_e5ynjned
    goto :ep_s_e5ynjned
    :ep_d_e5ynjned
    nop
    :ep_s_e5ynjned
    invoke-direct {v0, p1, p2}, Lcom/google/android/material/search/SearchBar$a;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    return-object v0
.end method

.method public final newArray(I)[Ljava/lang/Object;
    .locals 0

    new-array p1, p1, [Lcom/google/android/material/search/SearchBar$a;

    return-object p1
.end method
