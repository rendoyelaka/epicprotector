.class public final Lcom/google/android/material/search/SearchBar$a$a;
# ep-pmmjebkmudnx
.super Ljava/lang/Object;
.source "epzxjzgr.java"
# verified-15058

# interfaces
.implements Landroid/os/Parcelable$ClassLoaderCreator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/search/SearchBar$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$ClassLoaderCreator<",
        "Lcom/google/android/material/search/SearchBar$a;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 2

    .line 2
    new-instance v0, Lcom/google/android/material/search/SearchBar$a;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_q596xmm4
    goto :ep_s_q596xmm4
    :ep_d_q596xmm4
    nop
    :ep_s_q596xmm4
    const/4 v1, 0x0

    .line 3
    invoke-direct {v0, p1, v1}, Lcom/google/android/material/search/SearchBar$a;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    return-object v0
.end method

.method public final createFromParcel(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Ljava/lang/Object;
    .locals 1

    .line 1
    new-instance v0, Lcom/google/android/material/search/SearchBar$a;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_ia7vha66
    goto :ep_s_ia7vha66
    :ep_d_ia7vha66
    nop
    :ep_s_ia7vha66
    invoke-direct {v0, p1, p2}, Lcom/google/android/material/search/SearchBar$a;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    return-object v0
.end method

.method public final newArray(I)[Ljava/lang/Object;
    .locals 0

    new-array p1, p1, [Lcom/google/android/material/search/SearchBar$a;

    return-object p1
.end method
