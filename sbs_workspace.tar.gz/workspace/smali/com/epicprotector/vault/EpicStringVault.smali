.class public final Lcom/epicprotector/vault/EpicStringVault;
.super Ljava/lang/Object;
.source "A.java"

.field private static final KA:[B
.field private static final KB:[B

.method static constructor <clinit>()V
    .locals 3
    :try_start_0
    const/16 v0, 16
    new-array v0, v0, [B
    const/4 v1, 0
    const/16 v2, 14
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 1
    const/16 v2, -43
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 2
    const/16 v2, -41
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 3
    const/16 v2, 0
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 4
    const/16 v2, -14
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 5
    const/16 v2, 104
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 6
    const/16 v2, -88
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 7
    const/16 v2, 114
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 8
    const/16 v2, 103
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 9
    const/16 v2, -96
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 10
    const/16 v2, -46
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 11
    const/16 v2, 84
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 12
    const/16 v2, 105
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 13
    const/16 v2, -117
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 14
    const/16 v2, -2
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 15
    const/16 v2, 70
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    sput-object v0, Lcom/epicprotector/vault/EpicStringVault;->KA:[B
    const/16 v0, 16
    new-array v0, v0, [B
    const/4 v1, 0
    const/16 v2, -103
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 1
    const/16 v2, 59
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 2
    const/16 v2, 114
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 3
    const/16 v2, -109
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 4
    const/16 v2, -76
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 5
    const/16 v2, 121
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 6
    const/16 v2, 71
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 7
    const/16 v2, -13
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 8
    const/16 v2, 110
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 9
    const/16 v2, 55
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 10
    const/16 v2, -107
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 11
    const/16 v2, 0
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 12
    const/16 v2, -118
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 13
    const/16 v2, -9
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 14
    const/16 v2, -71
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/16 v1, 15
    const/16 v2, -93
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    sput-object v0, Lcom/epicprotector/vault/EpicStringVault;->KB:[B
    :try_end_0
    return-void
    :catch_0
    return-void
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
.end method

.method public static r(Ljava/lang/String;)Ljava/lang/String;
    .locals 7
    :try_start_r
    const/4 v0, 0x0
    invoke-static {p0, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B
    move-result-object v0
    array-length v1, v0
    new-array v2, v1, [B
    sget-object v5, Lcom/epicprotector/vault/EpicStringVault;->KA:[B
    array-length v3, v5
    sget-object v6, Lcom/epicprotector/vault/EpicStringVault;->KB:[B
    array-length v4, v6
    add-int/2addr v3, v4
    const/4 v4, 0x0
    :loop_r
    if-ge v4, v1, :end_r
    rem-int v6, v4, v3
    sget-object v5, Lcom/epicprotector/vault/EpicStringVault;->KA:[B
    array-length v5, v5
    if-ge v6, v5, :use_kb_r
    sget-object v5, Lcom/epicprotector/vault/EpicStringVault;->KA:[B
    aget-byte v5, v5, v6
    goto :xor_r
    :use_kb_r
    sget-object v5, Lcom/epicprotector/vault/EpicStringVault;->KA:[B
    array-length v5, v5
    sub-int/2addr v6, v5
    sget-object v5, Lcom/epicprotector/vault/EpicStringVault;->KB:[B
    aget-byte v5, v5, v6
    :xor_r
    aget-byte v6, v0, v4
    xor-int/2addr v6, v5
    int-to-byte v6, v6
    aput-byte v6, v2, v4
    add-int/lit8 v4, v4, 0x1
    goto :loop_r
    :end_r
    new-instance v4, Ljava/lang/String;
    const-string v5, "UTF-8"
    invoke-direct {v4, v2, v5}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_r
    return-object v4
    :catch_r
    return-object p0
    .catch Ljava/lang/Exception; {:try_start_r .. :try_end_r} :catch_r
.end method
