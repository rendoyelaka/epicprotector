.class public final Lcom/epicprotector/vault/EpicStringVault;
.super Ljava/lang/Object;
.source "A.java"

.field private static final KA:[B
.field private static final KB:[B

.method static constructor <clinit>()V
    .locals 3
    :try_start_0
    const/16 v0, 16
    new-array v0, v0, [B
    const/4 v1, 0
    const/16 v2, -89
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 1
    const/16 v2, 12
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 2
    const/16 v2, -2
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 3
    const/16 v2, -105
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 4
    const/16 v2, -126
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 5
    const/16 v2, 104
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 6
    const/16 v2, -32
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 7
    const/16 v2, -120
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 8
    const/16 v2, -115
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 9
    const/16 v2, -86
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 10
    const/16 v2, 24
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 11
    const/16 v2, -48
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 12
    const/16 v2, -23
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 13
    const/16 v2, -52
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 14
    const/16 v2, -87
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 15
    const/16 v2, 44
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    sput-object v0, Lcom/epicprotector/vault/EpicStringVault;->KA:[B
    const/16 v0, 16
    new-array v0, v0, [B
    const/4 v1, 0
    const/16 v2, 65
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 1
    const/16 v2, 86
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 2
    const/16 v2, 51
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 3
    const/16 v2, -13
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 4
    const/16 v2, 34
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 5
    const/16 v2, 123
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 6
    const/16 v2, -123
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 7
    const/16 v2, 48
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 8
    const/16 v2, 14
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 9
    const/16 v2, 84
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 10
    const/16 v2, 49
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 11
    const/16 v2, 89
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 12
    const/16 v2, -66
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 13
    const/16 v2, 106
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 14
    const/16 v2, 28
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    const/4 v1, 15
    const/16 v2, 41
    int-to-byte v2, v2
    aput-byte v2, v0, v1
    sput-object v0, Lcom/epicprotector/vault/EpicStringVault;->KB:[B
    :try_end_0
    return-void
    :catch_0
    return-void
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
.end method

.method public static r(Ljava/lang/String;)Ljava/lang/String;
    .locals 6
    :try_start_r
    const/4 v0, 0x0
    invoke-static {p0, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B
    move-result-object v0
    array-length v1, v0
    new-array v2, v1, [B
    const/4 v3, 0x0
    sget-object v4, Lcom/epicprotector/vault/EpicStringVault;->KA:[B
    array-length v4, v4
    sget-object v5, Lcom/epicprotector/vault/EpicStringVault;->KB:[B
    array-length v5, v5
    add-int/2addr v4, v5
    :loop_r
    if-ge v3, v1, :end_r
    rem-int v5, v3, v4
    sget-object v4, Lcom/epicprotector/vault/EpicStringVault;->KA:[B
    array-length v4, v4
    if-ge v5, v4, :use_kb_r
    sget-object v4, Lcom/epicprotector/vault/EpicStringVault;->KA:[B
    aget-byte v4, v4, v5
    goto :xor_r
    :use_kb_r
    sget-object v4, Lcom/epicprotector/vault/EpicStringVault;->KB:[B
    array-length v5, v4
    rem-int v5, v3, v5
    aget-byte v4, v4, v5
    :xor_r
    aget-byte v5, v0, v3
    xor-int/2addr v5, v4
    int-to-byte v5, v5
    aput-byte v5, v2, v3
    add-int/lit8 v3, v3, 0x1
    sget-object v4, Lcom/epicprotector/vault/EpicStringVault;->KA:[B
    array-length v4, v4
    sget-object v5, Lcom/epicprotector/vault/EpicStringVault;->KB:[B
    array-length v5, v5
    add-int/2addr v4, v5
    goto :loop_r
    :end_r
    new-instance v3, Ljava/lang/String;
    const-string v4, "UTF-8"
    invoke-direct {v3, v2, v4}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_r
    return-object v3
    :catch_r
    return-object p0
    .catch Ljava/lang/Exception; {:try_start_r .. :try_end_r} :catch_r
.end method
