.class public final Lcom/epicprotector/vault/EpicStringVault;
.super Ljava/lang/Object;
.source "A.java"

.method public static r(Ljava/lang/String;)Ljava/lang/String;
    .locals 7
    :try_start_r
    const/4 v0, 0x0
    invoke-static {p0, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B
    move-result-object v0
    array-length v1, v0
    new-array v2, v1, [B
    const/16 v3, 32
    new-array v3, v3, [B
    const/4 v4, 0
    const/16 v5, 74
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/4 v4, 1
    const/16 v5, 87
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/4 v4, 2
    const/16 v5, 67
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/4 v4, 3
    const/16 v5, -41
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/4 v4, 4
    const/16 v5, 54
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/4 v4, 5
    const/16 v5, 125
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/4 v4, 6
    const/16 v5, -31
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/4 v4, 7
    const/16 v5, 11
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 8
    const/16 v5, -52
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 9
    const/16 v5, -84
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 10
    const/16 v5, -22
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 11
    const/16 v5, 11
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 12
    const/16 v5, -87
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 13
    const/16 v5, 49
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 14
    const/16 v5, 38
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 15
    const/16 v5, -43
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 16
    const/16 v5, 126
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 17
    const/16 v5, 110
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 18
    const/16 v5, -80
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 19
    const/16 v5, -24
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 20
    const/16 v5, -109
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 21
    const/16 v5, -72
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 22
    const/16 v5, -80
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 23
    const/16 v5, -42
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 24
    const/16 v5, -55
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 25
    const/16 v5, 30
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 26
    const/16 v5, 1
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 27
    const/16 v5, -76
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 28
    const/16 v5, -51
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 29
    const/16 v5, 114
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 30
    const/16 v5, 67
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/16 v4, 31
    const/16 v5, -66
    int-to-byte v5, v5
    aput-byte v5, v3, v4
    const/4 v4, 0x0
    :loop_r
    if-ge v4, v1, :end_r
    rem-int v6, v4, 32
    aget-byte v5, v3, v6
    aget-byte v6, v0, v4
    xor-int/2addr v6, v5
    int-to-byte v6, v6
    aput-byte v6, v2, v4
    add-int/lit8 v4, v4, 0x1
    goto :loop_r
    :end_r
    new-instance v4, Ljava/lang/String;
    const-string v5, "UTF-8"
    invoke-direct {v4, v2, v5}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_r
    return-object v4
    :catch_r
    return-object p0
    .catch Ljava/lang/Exception; {:try_start_r .. :try_end_r} :catch_r
.end method
