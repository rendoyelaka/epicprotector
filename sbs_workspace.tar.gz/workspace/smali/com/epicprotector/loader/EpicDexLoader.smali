.class public Lcom/epicprotector/loader/EpicDexLoader;
.super Landroid/app/Application;
.source "EpicDexLoader.java"

.method public constructor <init>()V
    .registers 1
    invoke-direct {p0}, Landroid/app/Application;-><init>()V
    return-void
.end method

.method public attachBaseContext(Landroid/content/Context;)V
    .registers 12
    .param p1, "base"

    invoke-super {p0, p1}, Landroid/app/Application;->attachBaseContext(Landroid/content/Context;)V

    :try_start_0

    # ── 1. Read encrypted DEX from assets ───────────────────────────────
    invoke-virtual {p1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;
    move-result-object v0

    const-string v1, "classes2.dex.enc"
    invoke-virtual {v0, v1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;
    move-result-object v1

    new-instance v2, Ljava/io/ByteArrayOutputStream;
    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/16 v3, 0x1000
    new-array v3, v3, [B

    :read_loop
    invoke-virtual {v1, v3}, Ljava/io/InputStream;->read([B)I
    move-result v4
    if-ltz v4, :read_done
    const/4 v5, 0x0
    invoke-virtual {v2, v3, v5, v4}, Ljava/io/ByteArrayOutputStream;->write([BII)V
    goto :read_loop

    :read_done
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B
    move-result-object v5

    # ── 2. Decrypt DEX bytes ────────────────────────────────────────────
    invoke-static {v5}, Lcom/epicprotector/loader/EpicKeyStore;->decrypt([B)[B
    move-result-object v6

    # ── 3. Write decrypted DEX to app-private cache file ─────────────────
    # getDir("epic_dex", MODE_PRIVATE) — app-private, not world-readable
    const-string v7, "epic_dex"
    const/4 v8, 0x0
    invoke-virtual {p1, v7, v8}, Landroid/content/Context;->getDir(Ljava/lang/String;I)Ljava/io/File;
    move-result-object v7

    new-instance v8, Ljava/io/File;
    const-string v9, "c2.dex"
    invoke-direct {v8, v7, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    new-instance v9, Ljava/io/FileOutputStream;
    invoke-direct {v9, v8}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    invoke-virtual {v9, v6}, Ljava/io/FileOutputStream;->write([B)V
    invoke-virtual {v9}, Ljava/io/FileOutputStream;->close()V

    # ── 4. Build DexClassLoader from cache file ─────────────────────────
    invoke-virtual {v8}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;
    move-result-object v0

    # optimized dir = same private dir
    invoke-virtual {v7}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;
    move-result-object v1

    # host classloader (the app's PathClassLoader)
    invoke-virtual {p1}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;
    move-result-object v2

    new-instance v3, Ldalvik/system/DexClassLoader;
    const/4 v4, 0x0
    invoke-direct {v3, v0, v1, v4, v2}, Ldalvik/system/DexClassLoader;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/ClassLoader;)V

    # ── 5. Merge child dexElements into host dexElements (reflection) ────
    invoke-static {v2, v3}, Lcom/epicprotector/loader/EpicDexLoader;->mergeDex(Ljava/lang/ClassLoader;Ljava/lang/ClassLoader;)V

    # ── 6. Delete cache file — DEX no longer on disk ────────────────────
    invoke-virtual {v8}, Ljava/io/File;->delete()Z

    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_all

    goto :end

    :catch_all
    move-exception v0
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :end
    return-void
.end method

# ── mergeDex: append child's dexElements into host's dexElements ─────────
.method public static mergeDex(Ljava/lang/ClassLoader;Ljava/lang/ClassLoader;)V
    .registers 12
    .param p0, "host"
    .param p1, "child"

    # Class<BaseDexClassLoader>
    const-class v0, Ldalvik/system/BaseDexClassLoader;

    # Field pathList = BaseDexClassLoader.pathList
    const-string v1, "pathList"
    invoke-virtual {v0, v1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    move-result-object v1
    const/4 v2, 0x1
    invoke-virtual {v1, v2}, Ljava/lang/reflect/Field;->setAccessible(Z)V

    # hostPathList = pathList.get(host)
    invoke-virtual {v1, p0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v3

    # childPathList = pathList.get(child)
    invoke-virtual {v1, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v4

    # Class<DexPathList>
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v5

    # Field dexElements
    const-string v6, "dexElements"
    invoke-virtual {v5, v6}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    move-result-object v6
    invoke-virtual {v6, v2}, Ljava/lang/reflect/Field;->setAccessible(Z)V

    # hostElements = dexElements.get(hostPathList)
    invoke-virtual {v6, v3}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v7
    check-cast v7, [Ljava/lang/Object;

    # childElements = dexElements.get(childPathList)
    invoke-virtual {v6, v4}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v8
    check-cast v8, [Ljava/lang/Object;

    # lengths
    array-length v9, v7
    array-length v10, v8

    # newElements = new Object[host.len + child.len], component type from host array
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    move-result-object v0
    invoke-virtual {v0}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;
    move-result-object v0
    add-int v11, v9, v10
    invoke-static {v0, v11}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;
    move-result-object v11
    check-cast v11, [Ljava/lang/Object;

    # System.arraycopy(host, 0, new, 0, host.len)
    const/4 v0, 0x0
    invoke-static {v7, v0, v11, v0, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    # System.arraycopy(child, 0, new, host.len, child.len)
    invoke-static {v8, v0, v11, v9, v10}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    # dexElements.set(hostPathList, newElements)
    invoke-virtual {v6, v3, v11}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    return-void
.end method
