.class public Lcom/epicprotector/loader/EpicKeyStore;
.super Ljava/lang/Object;
.source "EpicKeyStore.java"

.method public static getKey()[B
    .registers 4
    const-string v0, "d94d4b41bdc30cd154478f527a2cdf6d"
    const-string v1, "e626cbd5c6bc48f81ffc8a2117100e56"
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    invoke-static {v0}, Lcom/epicprotector/loader/EpicKeyStore;->hexToBytes(Ljava/lang/String;)[B
    move-result-object v0
    return-object v0
.end method

.method private static hexToBytes(Ljava/lang/String;)[B
    .registers 7
    invoke-virtual {p0}, Ljava/lang/String;->length()I
    move-result v0
    const/4 v1, 0x2
    div-int v0, v0, v1
    new-array v2, v0, [B
    const/4 v3, 0x0
    :loop
    if-ge v3, v0, :done
    mul-int/lit8 v4, v3, 0x2
    add-int/lit8 v5, v4, 0x2
    invoke-virtual {p0, v4, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    move-result-object v4
    const/16 v5, 0x10
    invoke-static {v4, v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I
    move-result v4
    int-to-byte v4, v4
    aput-byte v4, v2, v3
    add-int/lit8 v3, v3, 0x1
    goto :loop
    :done
    return-object v2
.end method

.method public static decrypt([B)[B
    .registers 7
    invoke-static {}, Lcom/epicprotector/loader/EpicKeyStore;->getKey()[B
    move-result-object v0
    array-length v1, p0
    new-array v2, v1, [B
    const/4 v3, 0x0
    array-length v4, v0
    :loop
    if-ge v3, v1, :done
    rem-int v5, v3, v4
    aget-byte v5, v0, v5
    aget-byte v6, p0, v3
    xor-int/2addr v6, v5
    int-to-byte v6, v6
    aput-byte v6, v2, v3
    add-int/lit8 v3, v3, 0x1
    goto :loop
    :done
    return-object v2
.end method
