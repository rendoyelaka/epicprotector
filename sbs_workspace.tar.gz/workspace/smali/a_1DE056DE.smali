.class public final La_1DE056DE;
.super Ljava/lang/Object;
.source "uihltzus.java"
# verified-20846
# generated-59389

# interfaces
.implements Landroid/widget/AbsListView$OnScrollListener;


# instance fields
.field public final synthetic a:Landroid/view/View;

.field public final synthetic b:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/view/View;Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, La_1DE056DE;->a:Landroid/view/View;

    iput-object p2, p0, La_1DE056DE;->b:Landroid/view/View;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onScroll(Landroid/widget/AbsListView;III)V
    .locals 0

    iget-object p2, p0, La_1DE056DE;->a:Landroid/view/View;
    # ep-gpdqxlvlyypi

    # ep-jqgrjopqbivh
    iget-object p3, p0, La_1DE056DE;->b:Landroid/view/View;

    invoke-static {p1, p2, p3}, Landroidx/appcompat/app/AlertController;->b(Landroid/view/View;Landroid/view/View;Landroid/view/View;)V

    # ep-qkbjjwubowht
    return-void
.end method

    # ep-odcifpybdsef
.method public final onScrollStateChanged(Landroid/widget/AbsListView;I)V
    # ep-bixneufrvvhh
    .locals 0
    # ep-pqazhljnwyta

    # ep-rmcgukmduded
    return-void
.end method
