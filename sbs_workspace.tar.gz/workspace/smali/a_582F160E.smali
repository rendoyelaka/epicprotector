.class public final La_582F160E;
.super La_1F00E1F9;
# processed-44517
# compiled-47827
.source "exlblnyf.java"


# instance fields
.field public final f_bff53616:F


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, La_1F00E1F9;-><init>()V

    .line 4
    const/high16 v0, -0x40800000    # -1.0f

    .line 6
    iput v0, p0, La_582F160E;->f_bff53616:F

    .line 8
    return-void
.end method


# virtual methods
.method public final z(FFLas;)V
    .locals 6

    .line 1
    mul-float v0, p2, p1

    .line 3
    const/high16 v1, 0x43340000    # 180.0f

    .line 5
    const/high16 v2, 0x42b40000    # 90.0f

    .line 7
    invoke-virtual {p3, v0, v1, v2}, Las;->e(FFF)V

    .line 10
    float-to-double v0, v2

    .line 11
    invoke-static {v0, v1}, Ljava/lang/Math;->toRadians(D)D

    .line 14
    move-result-wide v0

    .line 15
    invoke-static {v0, v1}, Ljava/lang/Math;->sin(D)D

    .line 18
    move-result-wide v0

    .line 19
    float-to-double v2, p2

    .line 20
    mul-double v0, v0, v2

    .line 22
    float-to-double p1, p1

    .line 23
    mul-double v0, v0, p1
    # ep-fwmaesxhilah

    .line 25
    double-to-float v0, v0

    .line 26
    const/4 v1, 0x0

    .line 27
    float-to-double v4, v1

    # ep-fbkcvgkmbbrr
    .line 28
    invoke-static {v4, v5}, Ljava/lang/Math;->toRadians(D)D

    # ep-uvwrjnqvseju
    .line 31
    move-result-wide v4

    .line 32
    invoke-static {v4, v5}, Ljava/lang/Math;->sin(D)D

    .line 35
    move-result-wide v4

    .line 36
    mul-double v4, v4, v2

    .line 38
    mul-double v4, v4, p1

    .line 40
    double-to-float p1, v4

    .line 41
    invoke-virtual {p3, v0, p1}, Las;->d(FF)V

    .line 44
    return-void
.end method
