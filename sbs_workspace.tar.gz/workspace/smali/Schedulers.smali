.class public final LSchedulers;
.super Ljava/lang/Object;
.source "kshizmmu.java"
# verified-64669

# ep-cbrngkylqvmx

# static fields
.field public static final synthetic a:I


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "Schedulers"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public static a(Landroidx/work/a;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/work/a;",
            "Landroidx/work/impl/WorkDatabase;",
            "Ljava/util/List<",
            "Lhr;",
            ">;)V"
        }
    .end annotation

    .line 1
    if-eqz p2, :cond_7

    .line 3
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 9
    goto/16 :goto_3

    .line 11
    :cond_0
    invoke-virtual {p1}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {p1}, Ljq;->c()V

    .line 18
    :try_start_0
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 20
    iget p0, p0, Landroidx/work/a;->h:I

    .line 22
    const/16 v2, 0x17

    .line 24
    if-ne v1, v2, :cond_1

    .line 26
    div-int/lit8 p0, p0, 0x2

    .line 28
    :cond_1
    check-cast v0, LWorkSpecDao;

    .line 30
    invoke-virtual {v0, p0}, LWorkSpecDao;->c(I)Ljava/util/ArrayList;

    .line 33
    move-result-object p0

    .line 34
    invoke-virtual {v0}, LWorkSpecDao;->b()Ljava/util/ArrayList;

    .line 37
    move-result-object v1

    .line 38
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 41
    move-result v2

    .line 42
    if-lez v2, :cond_2

    .line 44
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 47
    move-result-wide v2

    .line 48
    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 51
    move-result-object v4

    .line 52
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 55
    move-result v5

    .line 56
    if-eqz v5, :cond_2

    .line 58
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 61
    move-result-object v5

    .line 62
    check-cast v5, LWorkSpec;

    .line 64
    iget-object v5, v5, LWorkSpec;->a:Ljava/lang/String;

    .line 66
    invoke-virtual {v0, v5, v2, v3}, LWorkSpecDao;->j(Ljava/lang/String;J)I

    .line 69
    goto :goto_0

    .line 70
    :cond_2
    invoke-virtual {p1}, Ljq;->h()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 73
    invoke-virtual {p1}, Ljq;->f()V

    .line 76
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 79
    move-result p1

    .line 80
    if-lez p1, :cond_4

    .line 82
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 85
    move-result p1

    .line 86
    new-array p1, p1, [LWorkSpec;

    .line 88
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 91
    move-result-object p0

    .line 92
    check-cast p0, [LWorkSpec;

    .line 94
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 97
    move-result-object p1

    .line 98
    :cond_3
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 101
    move-result v0

    .line 102
    if-eqz v0, :cond_4

    .line 104
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 107
    move-result-object v0

    .line 108
    check-cast v0, Lhr;

    .line 110
    invoke-interface {v0}, Lhr;->f()Z

    .line 113
    move-result v2

    .line 114
    if-eqz v2, :cond_3

    .line 116
    invoke-interface {v0, p0}, Lhr;->d([LWorkSpec;)V

    .line 119
    goto :goto_1

    .line 120
    :cond_4
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 123
    move-result p0

    .line 124
    if-lez p0, :cond_6

    .line 126
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 129
    move-result p0

    .line 130
    new-array p0, p0, [LWorkSpec;

    .line 132
    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 135
    move-result-object p0

    .line 136
    check-cast p0, [LWorkSpec;

    .line 138
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 141
    move-result-object p1

    .line 142
    :cond_5
    :goto_2
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 145
    move-result p2

    .line 146
    if-eqz p2, :cond_6

    .line 148
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 151
    move-result-object p2

    .line 152
    check-cast p2, Lhr;

    .line 154
    invoke-interface {p2}, Lhr;->f()Z

    .line 157
    move-result v0

    .line 158
    if-nez v0, :cond_5

    .line 160
    invoke-interface {p2, p0}, Lhr;->d([LWorkSpec;)V

    .line 163
    goto :goto_2

    .line 164
    :cond_6
    return-void

    .line 165
    :catchall_0
    move-exception p0

    .line 166
    invoke-virtual {p1}, Ljq;->f()V

    .line 169
    throw p0

    .line 170
    :cond_7
    :goto_3
    return-void
.end method
