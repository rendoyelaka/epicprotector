.class public abstract La_47C62CCB;
.super Ljava/lang/Object;
.source "vrxkbcpt.java"
# ep-vlxilabutrwx

# processed-64869

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_0C975F5D;
    }
.end annotation


# instance fields
.field public final a:Ljava/util/UUID;

.field public final b:La_F9B89BF9;

.field public final c:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/UUID;La_F9B89BF9;Ljava/util/HashSet;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_47C62CCB;->a:Ljava/util/UUID;

    .line 6
    iput-object p2, p0, La_47C62CCB;->b:La_F9B89BF9;

    .line 8
    iput-object p3, p0, La_47C62CCB;->c:Ljava/util/Set;

    .line 10
    return-void
.end method
