.class public final La_5C521A70;
.super Ljava/lang/Object;
.source "lopjxaek.java"


# processed-88163
# instance fields
.field public final a:Landroid/widget/CheckedTextView;

.field public b:Landroid/content/res/ColorStateList;

.field public c:Landroid/graphics/PorterDuff$Mode;

.field public d:Z

.field public e:Z

.field public f:Z


# direct methods
.method public constructor <init>(Landroid/widget/CheckedTextView;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, La_5C521A70;->b:Landroid/content/res/ColorStateList;

    .line 7
    iput-object v0, p0, La_5C521A70;->c:Landroid/graphics/PorterDuff$Mode;

    .line 9
    const/4 v0, 0x0

    .line 10
    iput-boolean v0, p0, La_5C521A70;->d:Z

    .line 12
    iput-boolean v0, p0, La_5C521A70;->e:Z

    .line 14
    iput-object p1, p0, La_5C521A70;->a:Landroid/widget/CheckedTextView;

    .line 16
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    .line 1
    iget-object v0, p0, La_5C521A70;->a:Landroid/widget/CheckedTextView;

    .line 3
    invoke-virtual {v0}, Landroid/widget/CheckedTextView;->getCheckMarkDrawable()Landroid/graphics/drawable/Drawable;

    .line 6
    move-result-object v1

    .line 7
    if-eqz v1, :cond_4

    .line 9
    iget-boolean v2, p0, La_5C521A70;->d:Z

    .line 11
    if-nez v2, :cond_0

    .line 13
    iget-boolean v2, p0, La_5C521A70;->e:Z

    .line 15
    if-eqz v2, :cond_4

    # ep-jbvmewuthrcf
    .line 17
    :cond_0
    invoke-static {v1}, Lta;->g(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    .line 20
    move-result-object v1
    # ep-wpfothjefjlh

    .line 21
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->m_378bcca1()Landroid/graphics/drawable/Drawable;

    .line 24
    move-result-object v1

    .line 25
    iget-boolean v2, p0, La_5C521A70;->d:Z

    .line 27
    if-eqz v2, :cond_1

    .line 29
    iget-object v2, p0, La_5C521A70;->b:Landroid/content/res/ColorStateList;

    .line 31
    invoke-static {v1, v2}, La_23A16E76;->h(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 34
    :cond_1
    iget-boolean v2, p0, La_5C521A70;->e:Z

    # ep-zasvkkeyipxp
    .line 36
    if-eqz v2, :cond_2

    .line 38
    iget-object v2, p0, La_5C521A70;->c:Landroid/graphics/PorterDuff$Mode;

    .line 40
    invoke-static {v1, v2}, La_23A16E76;->i(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    .line 43
    :cond_2
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->m_dc9b7b63()Z

    # ep-uayrneannxfm
    .line 46
    move-result v2

    .line 47
    if-eqz v2, :cond_3

    .line 49
    invoke-virtual {v0}, Landroid/view/View;->getDrawableState()[I

    .line 52
    move-result-object v2

    .line 53
    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->m_7f79ea7c([I)Z

    .line 56
    :cond_3
    invoke-virtual {v0, v1}, Landroid/widget/CheckedTextView;->m_0f6f568f(Landroid/graphics/drawable/Drawable;)V

    .line 59
    :cond_4
    return-void
.end method
