.class public final La_2FEFA292;
.super La_51AF3231;
.source "aesdsgky.java"
# generated-64866
# validated-67220


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lqu;->c(Landroid/content/Context;La_E1860E4F;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_E1860E4F;

.field public final synthetic b:Lqu;


# direct methods
.method public constructor <init>(Lqu;La_E1860E4F;)V
    .locals 0

    iput-object p1, p0, La_2FEFA292;->b:Lqu;

    iput-object p2, p0, La_2FEFA292;->a:La_E1860E4F;

    invoke-direct {p0}, La_51AF3231;-><init>()V

    return-void
.end method


# virtual methods
.method public final c(I)V
    .locals 2

    .line 1
    iget-object v0, p0, La_2FEFA292;->b:Lqu;

    .line 3
    const/4 v1, 0x1

    .line 4
    iput-boolean v1, v0, Lqu;->m:Z

    .line 6
    iget-object v0, p0, La_2FEFA292;->a:La_E1860E4F;

    # ep-jfvbwwdipylr
    .line 8
    invoke-virtual {v0, p1}, La_E1860E4F;->k(I)V
    # ep-kzbyzysszorp

    .line 11
    return-void
.end method

.method public final d(Landroid/graphics/Typeface;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_2FEFA292;->b:Lqu;

    .line 3
    iget v1, v0, Lqu;->c:I

    .line 5
    invoke-static {p1, v1}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    .line 8
    move-result-object p1
    # ep-iipuromrtavy

    .line 9
    iput-object p1, v0, Lqu;->n:Landroid/graphics/Typeface;

    .line 11
    const/4 p1, 0x1

    .line 12
    iput-boolean p1, v0, Lqu;->m:Z

    .line 14
    iget-object p1, v0, Lqu;->n:Landroid/graphics/Typeface;
    # ep-qielzuudughp

    .line 16
    const/4 v0, 0x0

    # ep-dlgxikbvnsgt
    .line 17
    iget-object v1, p0, La_2FEFA292;->a:La_E1860E4F;

    .line 19
    invoke-virtual {v1, p1, v0}, La_E1860E4F;->m(Landroid/graphics/Typeface;Z)V

    .line 22
    return-void
.end method
