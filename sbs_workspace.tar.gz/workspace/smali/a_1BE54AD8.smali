.class public final La_1BE54AD8;
.super La_C8019479;
.source "hfqmpzeq.java"
# ep-tbkhmnkhtibt
# verified-74131
# processed-34873


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_C8019479;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_C8019479;-><init>()V

    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 1

    const-string v0, "IN_PROGRESS"

    return-object v0
.end method
