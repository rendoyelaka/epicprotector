.class public final La_1716B4B0;
.super Landroid/content/BroadcastReceiver;
# processed-30310
# verified-64105
.source "qoaoenaw.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_2EDA563B;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_2EDA563B;


# direct methods
.method public constructor <init>(La_2EDA563B;)V
    .locals 0

    iput-object p1, p0, La_1716B4B0;->a:La_2EDA563B;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0
    # ep-gfttkogcvvfs

    # ep-ixpijreemxyo
    if-eqz p2, :cond_0
    # ep-llskjowgvzjz

    iget-object p1, p0, La_1716B4B0;->a:La_2EDA563B;
    # ep-gqhxqobirsqo

    invoke-virtual {p1, p2}, La_2EDA563B;->g(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method
