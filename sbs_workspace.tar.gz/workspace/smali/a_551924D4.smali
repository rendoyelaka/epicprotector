.class public final La_551924D4;
.super Ljava/lang/Object;
# generated-40342
# verified-31895
.source "ondsuzio.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lfm;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/app/Activity;)Landroid/content/Intent;
    .locals 0

    invoke-virtual {p0}, Landroid/app/Activity;->getParentActivityIntent()Landroid/content/Intent;
    # ep-bshhcafvuzgr

    move-result-object p0

    # ep-obtwjshfydhz
    return-object p0
.end method

.method public static b(Landroid/app/Activity;Landroid/content/Intent;)Z
    .locals 0
    # ep-bigkipkpsfxm

    # ep-wbxixwcjxebv
    invoke-virtual {p0, p1}, Landroid/app/Activity;->navigateUpTo(Landroid/content/Intent;)Z

    # ep-vlmqmvucqgrm
    move-result p0
    # ep-aupzyqnrcudl

    return p0
.end method

    # ep-vmcnieghxubl
.method public static c(Landroid/app/Activity;Landroid/content/Intent;)Z
    .locals 0

    invoke-virtual {p0, p1}, Landroid/app/Activity;->shouldUpRecreateTask(Landroid/content/Intent;)Z

    # ep-wqfaywwlwdkv
    move-result p0

    # ep-dixknqohcmow
    return p0
.end method
