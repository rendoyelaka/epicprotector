.class public final synthetic Lai;
.super Ljava/lang/Object;
# ep-lywpwisrstue
.source "SourceFile"

# optimised-35188
# optimised-17465
# interfaces
.implements Ldi;
.implements Ll;


# instance fields
.field public final synthetic a:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;)V
    .locals 0

    iput-object p1, p0, Lai;->a:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lei;ILandroid/os/Bundle;)Z
    .locals 7

    .line 1
    iget-object v0, p0, Lai;->a:Ljava/lang/Object;

    .line 3
    check-cast v0, Landroid/view/View;

    .line 5
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 7
    const/16 v2, 0x19

    .line 9
    const/4 v3, 0x0

    .line 10
    const/4 v4, 0x1

    .line 11
    if-lt v1, v2, :cond_1

    .line 13
    and-int/2addr p2, v4

    .line 14
    if-eqz p2, :cond_1

    .line 16
    :try_start_0
    iget-object p2, p1, Lei;->a:Lei$c;

    .line 18
    invoke-interface {p2}, Lei$c;->d()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 21
    iget-object p2, p1, Lei;->a:Lei$c;

    .line 23
    invoke-interface {p2}, Lei$c;->b()Ljava/lang/Object;

    .line 26
    move-result-object p2

    .line 27
    check-cast p2, Landroid/view/inputmethod/InputContentInfo;

    .line 29
    if-nez p3, :cond_0

    .line 31
    new-instance p3, Landroid/os/Bundle;

    .line 33
    invoke-direct {p3}, Landroid/os/Bundle;-><init>()V

    .line 36
    goto :goto_0

    .line 37
    :cond_0
    new-instance v2, Landroid/os/Bundle;

    .line 39
    invoke-direct {v2, p3}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    .line 42
    move-object p3, v2

    .line 43
    :goto_0
    const-string v2, "androidx.core.view.extra.INPUT_CONTENT_INFO"

    .line 45
    invoke-virtual {p3, v2, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 48
    :cond_1
    new-instance p2, Landroid/content/ClipData;

    .line 50
    iget-object v2, p1, Lei;->a:Lei$c;

    .line 52
    invoke-interface {v2}, Lei$c;->a()Landroid/content/ClipDescription;

    .line 55
    move-result-object v2

    .line 56
    new-instance v5, Landroid/content/ClipData$Item;

    .line 58
    iget-object p1, p1, Lei;->a:Lei$c;

    .line 60
    invoke-interface {p1}, Lei$c;->c()Landroid/net/Uri;

    .line 63
    move-result-object v6

    .line 64
    invoke-direct {v5, v6}, Landroid/content/ClipData$Item;-><init>(Landroid/net/Uri;)V

    .line 67
    invoke-direct {p2, v2, v5}, Landroid/content/ClipData;-><init>(Landroid/content/ClipDescription;Landroid/content/ClipData$Item;)V

    .line 70
    const/16 v2, 0x1f

    .line 72
    const/4 v5, 0x2

    .line 73
    if-lt v1, v2, :cond_2

    .line 75
    new-instance v1, Lk8$a;

    .line 77
    invoke-direct {v1, p2, v5}, Lk8$a;-><init>(Landroid/content/ClipData;I)V

    .line 80
    goto :goto_1

    .line 81
    :cond_2
    new-instance v1, Lk8$c;

    .line 83
    invoke-direct {v1, p2, v5}, Lk8$c;-><init>(Landroid/content/ClipData;I)V

    .line 86
    :goto_1
    invoke-interface {p1}, Lei$c;->e()Landroid/net/Uri;

    .line 89
    move-result-object p1

    .line 90
    invoke-interface {v1, p1}, Lk8$b;->a(Landroid/net/Uri;)V

    .line 93
    invoke-interface {v1, p3}, Lk8$b;->setExtras(Landroid/os/Bundle;)V

    .line 96
    invoke-interface {v1}, Lk8$b;->build()Lk8;

    .line 99
    move-result-object p1

    .line 100
    invoke-static {v0, p1}, Lqx;->l(Landroid/view/View;Lk8;)Lk8;

    .line 103
    move-result-object p1

    .line 104
    if-nez p1, :cond_3

    .line 106
    const/4 v3, 0x1

    .line 107
    :catch_0
    :cond_3
    return v3
.end method
