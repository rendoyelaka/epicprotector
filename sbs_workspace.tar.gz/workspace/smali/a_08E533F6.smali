.class public abstract La_08E533F6;
# ep-fbanpcpapfac
# validated-66832
# verified-63861
.super Ljava/lang/Object;
.source "jhtsoqyw.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# static fields
.field public static final synthetic f:I


# instance fields
.field public final a:Lnu;

.field public final b:Landroid/content/Context;

.field public final c:Ljava/lang/Object;

.field public final d:Ljava/util/LinkedHashSet;

.field public e:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "ConstraintTracker"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lnu;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/lang/Object;

    .line 6
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 9
    iput-object v0, p0, La_08E533F6;->c:Ljava/lang/Object;

    .line 11
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 13
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 16
    iput-object v0, p0, La_08E533F6;->d:Ljava/util/LinkedHashSet;

    .line 18
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 21
    move-result-object p1

    .line 22
    iput-object p1, p0, La_08E533F6;->b:Landroid/content/Context;

    .line 24
    iput-object p2, p0, La_08E533F6;->a:Lnu;

    .line 26
    return-void
.end method


# virtual methods
.method public abstract a()Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation
.end method

.method public final b(La_3DDFDA47;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_08E533F6;->c:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, La_08E533F6;->d:Ljava/util/LinkedHashSet;

    .line 6
    invoke-interface {v1, p1}, Ljava/util/Set;->m_8eb9dccd(Ljava/lang/Object;)Z

    .line 9
    move-result p1

    .line 10
    if-eqz p1, :cond_0

    .line 12
    iget-object p1, p0, La_08E533F6;->d:Ljava/util/LinkedHashSet;

    .line 14
    invoke-interface {p1}, Ljava/util/Set;->m_2bd5aeca()Z

    .line 17
    move-result p1

    .line 18
    if-eqz p1, :cond_0

    .line 20
    invoke-virtual {p0}, La_08E533F6;->e()V

    .line 23
    :cond_0
    monitor-exit v0

    .line 24
    return-void

    .line 25
    :catchall_0
    move-exception p1

    .line 26
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 27
    throw p1
.end method

.method public final c(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_08E533F6;->c:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, La_08E533F6;->e:Ljava/lang/Object;

    .line 6
    if-eq v1, p1, :cond_1

    .line 8
    if-eqz v1, :cond_0

    .line 10
    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 13
    move-result v1

    .line 14
    if-eqz v1, :cond_0

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    iput-object p1, p0, La_08E533F6;->e:Ljava/lang/Object;

    .line 19
    new-instance p1, Ljava/util/ArrayList;

    .line 21
    iget-object v1, p0, La_08E533F6;->d:Ljava/util/LinkedHashSet;

    .line 23
    invoke-direct {p1, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 26
    iget-object v1, p0, La_08E533F6;->a:Lnu;

    .line 28
    check-cast v1, La_068AFB71;

    .line 30
    iget-object v1, v1, La_068AFB71;->c:La_2F7E2D95;

    .line 32
    new-instance v2, La_2546C946;

    .line 34
    invoke-direct {v2, p0, p1}, La_2546C946;-><init>(La_08E533F6;Ljava/util/ArrayList;)V

    .line 37
    invoke-virtual {v1, v2}, La_2F7E2D95;->m_a6484c79(Ljava/lang/Runnable;)V

    .line 40
    monitor-exit v0

    .line 41
    return-void

    .line 42
    :cond_1
    :goto_0
    monitor-exit v0

    .line 43
    return-void

    .line 44
    :catchall_0
    move-exception p1

    .line 45
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 46
    throw p1
.end method

.method public abstract d()V
.end method

.method public abstract e()V
.end method
