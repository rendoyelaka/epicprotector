.class public final La_88593610;
.super Ljava/io/IOException;
.source "urfujjqt.java"


# generated-35213
# compiled-14113
# processed-24910
# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/io/IOException;-><init>()V

    return-void
.end method
