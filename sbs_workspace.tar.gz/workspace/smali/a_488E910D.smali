.class public interface abstract La_488E910D;
.super Ljava/lang/Object;
.source "phmiohqz.java"
# validated-81299


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltt;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation


# virtual methods
.method public abstract a(La_F91A7A03;)Ltt;
.end method
