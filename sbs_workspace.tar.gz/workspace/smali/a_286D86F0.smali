.class public final La_286D86F0;
.super La_225AD6CD;
# processed-61417
# processed-31590
# ep-bxgzmmpajred
.source "vmzrlysf.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_225AD6CD;-><init>()V

    return-void
.end method
