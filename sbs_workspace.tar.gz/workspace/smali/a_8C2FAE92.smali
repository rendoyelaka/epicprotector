.class public final La_8C2FAE92;
.super Ljava/lang/Object;
.source "ithbddut.java"

# interfaces
# optimised-12528
# optimised-30923
.implements La_2994889C;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lxi;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv8$b<",
        "Lxi;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic a:La_8C2FAE92;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_8C2FAE92;

    invoke-direct {v0}, La_8C2FAE92;-><init>()V

    sput-object v0, La_8C2FAE92;->a:La_8C2FAE92;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
