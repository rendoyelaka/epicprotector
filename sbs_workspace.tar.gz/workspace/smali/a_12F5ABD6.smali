.class public interface abstract La_12F5ABD6;
.super Ljava/lang/Object;
.source "quoasaht.java"

# validated-58947
# validated-53277
# processed-42742

# static fields
.field public static final a:La_7D97A6AF;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_7D97A6AF;

    invoke-direct {v0}, La_7D97A6AF;-><init>()V

    sput-object v0, La_12F5ABD6;->a:La_7D97A6AF;

    return-void
.end method
