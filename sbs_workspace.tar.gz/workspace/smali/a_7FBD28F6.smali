.class public final La_7FBD28F6;
.super Ljava/lang/Object;
.source "ytzsoioy.java"
# processed-81390
# verified-29214

# ep-urcwusesckhd
# interfaces
.implements Landroid/os/Handler$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Los;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Los;


# direct methods
.method public constructor <init>(Los;)V
    .locals 0

    iput-object p1, p0, La_7FBD28F6;->a:Los;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_22b1e3af(Landroid/os/Message;)Z
    .locals 1

    .line 1
    iget v0, p1, Landroid/os/Message;->what:I

    .line 3
    if-eqz v0, :cond_0

    .line 5
    const/4 p1, 0x0

    .line 6
    return p1

    .line 7
    :cond_0
    iget-object v0, p0, La_7FBD28F6;->a:Los;

    .line 9
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 11
    check-cast p1, La_A8E08B56;

    .line 13
    iget-object v0, v0, Los;->a:Ljava/lang/Object;

    .line 15
    monitor-enter v0

    .line 16
    if-eqz p1, :cond_1

    .line 18
    if-eqz p1, :cond_1

    .line 20
    :try_start_0
    monitor-exit v0

    .line 21
    const/4 p1, 0x1

    .line 22
    return p1

    .line 23
    :cond_1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    const/4 p1, 0x0

    .line 27
    throw p1

    .line 28
    :goto_0
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 29
    throw p1

    .line 30
    :catchall_0
    move-exception p1

    .line 31
    goto :goto_0
.end method
