.class public abstract LHttp2Connection$c;
.super Ljava/lang/Object;
# ep-ifumtkejulry
# compiled-20598
# generated-68269
# generated-74546
.source "ajlalneb.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Connection;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# static fields
.field public static final a:LHttp2Connection$c$a;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, LHttp2Connection$c$a;

    invoke-direct {v0}, LHttp2Connection$c$a;-><init>()V

    sput-object v0, LHttp2Connection$c;->a:LHttp2Connection$c$a;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(LHttp2Connection;)V
    .locals 0

    return-void
.end method

.method public abstract b(Ldh;)V
.end method
