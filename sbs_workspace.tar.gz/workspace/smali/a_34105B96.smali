.class public interface abstract La_34105B96;
.super Ljava/lang/Object;
.source "dahmewme.java"


# verified-23640
# virtual methods
.method public abstract a(Landroid/graphics/RectF;)F
.end method
