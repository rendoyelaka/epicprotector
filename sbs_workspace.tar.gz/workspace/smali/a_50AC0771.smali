.class public final La_50AC0771;
.super Llj;
.source "nmcxfmlv.java"
# optimised-35675
# verified-85561
# ep-dapufbotuzqb

# interfaces
.implements La_B18CE1A0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_2F7A58B8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "g"
.end annotation


# instance fields
.field public f_5c7c3982:Ljava/lang/CharSequence;

.field public f_859a07ae:Landroid/widget/ListAdapter;

.field public final f_4fd05212:Landroid/graphics/Rect;

.field public f_393a67c6:I

.field public final synthetic f_199ed379:La_2F7A58B8;


# direct methods
.method public constructor <init>(La_2F7A58B8;Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 1

    .line 1
    iput-object p1, p0, La_50AC0771;->f_199ed379:La_2F7A58B8;

    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-direct {p0, p2, p3, p4, v0}, Llj;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    .line 7
    new-instance p2, Landroid/graphics/Rect;

    .line 9
    invoke-direct {p2}, Landroid/graphics/Rect;-><init>()V

    .line 12
    iput-object p2, p0, La_50AC0771;->f_4fd05212:Landroid/graphics/Rect;

    .line 14
    iput-object p1, p0, Llj;->q:Landroid/view/View;

    .line 16
    const/4 p1, 0x1

    .line 17
    iput-boolean p1, p0, Llj;->f_a1e82d85:Z

    .line 19
    iget-object p2, p0, Llj;->f_79d589a6:La_A064435F;

    .line 21
    invoke-virtual {p2, p1}, Landroid/widget/PopupWindow;->setFocusable(Z)V

    .line 24
    new-instance p1, La_F0F0C316;

    .line 26
    invoke-direct {p1, p0}, La_F0F0C316;-><init>(La_50AC0771;)V

    .line 29
    iput-object p1, p0, Llj;->r:Landroid/widget/AdapterView$OnItemClickListener;

    .line 31
    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/CharSequence;)V
    .locals 0

    iput-object p1, p0, La_50AC0771;->f_5c7c3982:Ljava/lang/CharSequence;

    return-void
.end method

.method public final k(I)V
    .locals 0

    iput p1, p0, La_50AC0771;->f_393a67c6:I

    return-void
.end method

.method public final m(II)V
    .locals 5

    .line 1
    invoke-virtual {p0}, Llj;->b()Z

    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, La_50AC0771;->s()V

    .line 8
    const/4 v1, 0x2

    .line 9
    iget-object v2, p0, Llj;->f_79d589a6:La_A064435F;

    .line 11
    invoke-virtual {v2, v1}, Landroid/widget/PopupWindow;->setInputMethodMode(I)V

    .line 14
    invoke-virtual {p0}, Llj;->d()V

    .line 17
    iget-object v1, p0, Llj;->e:Lya;

    .line 19
    const/4 v3, 0x1

    .line 20
    invoke-virtual {v1, v3}, Landroid/widget/AbsListView;->setChoiceMode(I)V

    .line 23
    invoke-static {v1, p1}, La_94A51C01;->d(Landroid/view/View;I)V

    .line 26
    invoke-static {v1, p2}, La_94A51C01;->c(Landroid/view/View;I)V

    .line 29
    iget-object p1, p0, La_50AC0771;->f_199ed379:La_2F7A58B8;

    .line 31
    invoke-virtual {p1}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 34
    move-result p2

    .line 35
    iget-object v1, p0, Llj;->e:Lya;

    .line 37
    invoke-virtual {p0}, Llj;->b()Z

    .line 40
    move-result v4

    .line 41
    if-eqz v4, :cond_0

    .line 43
    if-eqz v1, :cond_0

    .line 45
    const/4 v4, 0x0

    .line 46
    invoke-virtual {v1, v4}, Lya;->setListSelectionHidden(Z)V

    .line 49
    invoke-virtual {v1, p2}, Landroid/widget/AdapterView;->setSelection(I)V

    .line 52
    invoke-virtual {v1}, Landroid/widget/AbsListView;->getChoiceMode()I

    .line 55
    move-result v4

    .line 56
    if-eqz v4, :cond_0

    .line 58
    invoke-virtual {v1, p2, v3}, Landroid/widget/AbsListView;->setItemChecked(IZ)V

    .line 61
    :cond_0
    if-eqz v0, :cond_1

    .line 63
    return-void

    .line 64
    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 67
    move-result-object p1

    .line 68
    if-eqz p1, :cond_2

    .line 70
    new-instance p2, La_420FCE42;

    .line 72
    invoke-direct {p2, p0}, La_420FCE42;-><init>(La_50AC0771;)V

    .line 75
    invoke-virtual {p1, p2}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 78
    new-instance p1, La_4C26672B;

    .line 80
    invoke-direct {p1, p0, p2}, La_4C26672B;-><init>(La_50AC0771;La_420FCE42;)V

    .line 83
    invoke-virtual {v2, p1}, Landroid/widget/PopupWindow;->setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V

    .line 86
    :cond_2
    return-void
.end method

.method public final o()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, La_50AC0771;->f_5c7c3982:Ljava/lang/CharSequence;

    return-object v0
.end method

.method public final p(Landroid/widget/ListAdapter;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Llj;->p(Landroid/widget/ListAdapter;)V

    .line 4
    iput-object p1, p0, La_50AC0771;->f_859a07ae:Landroid/widget/ListAdapter;

    .line 6
    return-void
.end method

.method public final s()V
    .locals 9

    .line 1
    invoke-virtual {p0}, Llj;->f()Landroid/graphics/drawable/Drawable;

    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, La_50AC0771;->f_199ed379:La_2F7A58B8;

    .line 7
    if-eqz v0, :cond_1

    .line 9
    iget-object v2, v1, La_2F7A58B8;->j:Landroid/graphics/Rect;

    .line 11
    invoke-virtual {v0, v2}, Landroid/graphics/drawable/Drawable;->m_96030b53(Landroid/graphics/Rect;)Z

    .line 14
    invoke-static {v1}, Lty;->a(Landroid/view/View;)Z

    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 20
    iget-object v0, v1, La_2F7A58B8;->j:Landroid/graphics/Rect;

    .line 22
    iget v0, v0, Landroid/graphics/Rect;->right:I

    .line 24
    goto :goto_0

    .line 25
    :cond_0
    iget-object v0, v1, La_2F7A58B8;->j:Landroid/graphics/Rect;

    .line 27
    iget v0, v0, Landroid/graphics/Rect;->left:I

    .line 29
    neg-int v0, v0

    .line 30
    goto :goto_0

    .line 31
    :cond_1
    iget-object v0, v1, La_2F7A58B8;->j:Landroid/graphics/Rect;

    .line 33
    const/4 v2, 0x0

    .line 34
    iput v2, v0, Landroid/graphics/Rect;->right:I

    .line 36
    iput v2, v0, Landroid/graphics/Rect;->left:I

    .line 38
    const/4 v0, 0x0

    .line 39
    :goto_0
    invoke-virtual {v1}, Landroid/view/View;->getPaddingLeft()I

    .line 42
    move-result v2

    .line 43
    invoke-virtual {v1}, Landroid/view/View;->getPaddingRight()I

    .line 46
    move-result v3

    .line 47
    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    .line 50
    move-result v4

    .line 51
    iget v5, v1, La_2F7A58B8;->i:I

    .line 53
    const/4 v6, -0x2

    .line 54
    if-ne v5, v6, :cond_3

    .line 56
    iget-object v5, p0, La_50AC0771;->f_859a07ae:Landroid/widget/ListAdapter;

    .line 58
    check-cast v5, Landroid/widget/SpinnerAdapter;

    .line 60
    invoke-virtual {p0}, Llj;->f()Landroid/graphics/drawable/Drawable;

    .line 63
    move-result-object v6

    .line 64
    invoke-virtual {v1, v5, v6}, La_2F7A58B8;->a(Landroid/widget/SpinnerAdapter;Landroid/graphics/drawable/Drawable;)I

    .line 67
    move-result v5

    .line 68
    invoke-virtual {v1}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    .line 71
    move-result-object v6

    .line 72
    invoke-virtual {v6}, Landroid/content/Context;->m_117d8ed5()Landroid/content/res/Resources;

    .line 75
    move-result-object v6

    .line 76
    invoke-virtual {v6}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 79
    move-result-object v6

    .line 80
    iget v6, v6, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 82
    iget-object v7, v1, La_2F7A58B8;->j:Landroid/graphics/Rect;

    .line 84
    iget v8, v7, Landroid/graphics/Rect;->left:I

    .line 86
    sub-int/2addr v6, v8

    .line 87
    iget v7, v7, Landroid/graphics/Rect;->right:I

    .line 89
    sub-int/2addr v6, v7

    .line 90
    if-le v5, v6, :cond_2

    .line 92
    move v5, v6

    .line 93
    :cond_2
    sub-int v6, v4, v2

    .line 95
    sub-int/2addr v6, v3

    .line 96
    invoke-static {v5, v6}, Ljava/lang/Math;->max(II)I

    .line 99
    move-result v5

    .line 100
    invoke-virtual {p0, v5}, Llj;->r(I)V

    .line 103
    goto :goto_1

    .line 104
    :cond_3
    const/4 v6, -0x1

    .line 105
    if-ne v5, v6, :cond_4

    .line 107
    sub-int v5, v4, v2

    .line 109
    sub-int/2addr v5, v3

    .line 110
    invoke-virtual {p0, v5}, Llj;->r(I)V

    .line 113
    goto :goto_1

    .line 114
    :cond_4
    invoke-virtual {p0, v5}, Llj;->r(I)V

    .line 117
    :goto_1
    invoke-static {v1}, Lty;->a(Landroid/view/View;)Z

    .line 120
    move-result v1

    .line 121
    if-eqz v1, :cond_5

    .line 123
    sub-int/2addr v4, v3

    .line 124
    iget v1, p0, Llj;->g:I

    .line 126
    sub-int/2addr v4, v1

    .line 127
    iget v1, p0, La_50AC0771;->f_393a67c6:I

    .line 129
    sub-int/2addr v4, v1

    .line 130
    add-int/2addr v4, v0

    .line 131
    goto :goto_2

    .line 132
    :cond_5
    iget v1, p0, La_50AC0771;->f_393a67c6:I

    .line 134
    add-int/2addr v2, v1

    .line 135
    add-int v4, v2, v0

    .line 137
    :goto_2
    iput v4, p0, Llj;->h:I

    .line 139
    return-void
.end method
