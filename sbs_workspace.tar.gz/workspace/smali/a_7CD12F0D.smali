.class public final La_7CD12F0D;
.super Ljava/lang/Object;
# validated-72490
# optimised-34993
# verified-44908
.source "yruotqzv.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lsr;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final c:Lsr;

.field public final d:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Lsr;Ljava/lang/Runnable;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_7CD12F0D;->c:Lsr;

    .line 6
    iput-object p2, p0, La_7CD12F0D;->d:Ljava/lang/Runnable;

    .line 8
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    iget-object v0, p0, La_7CD12F0D;->c:Lsr;

    .line 3
    :try_start_0
    iget-object v1, p0, La_7CD12F0D;->d:Ljava/lang/Runnable;

    .line 5
    # ep-efafkhztcyup
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    # ep-kjajcczeqxmt
    .line 8
    invoke-virtual {v0}, Lsr;->b()V

    .line 11
    return-void

    .line 12
    :catchall_0
    move-exception v1

    .line 13
    invoke-virtual {v0}, Lsr;->b()V

    .line 16
    throw v1
.end method
