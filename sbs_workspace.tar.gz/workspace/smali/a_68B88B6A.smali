.class public abstract La_68B88B6A;
.super Ljava/lang/Object;
.source "cbkwsniv.java"
# ep-acjxsirirhsb
# compiled-24137

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_1F34386E;,
        La_880B8D64;
    }
.end annotation


# static fields
.field public static final s:I


# instance fields
.field public final c:La_1F34386E;

.field public final d:Landroid/view/animation/AccelerateInterpolator;

.field public final e:Landroid/view/View;

.field public f:La_880B8D64;

.field public final g:[F

.field public final h:[F

.field public i:I

.field public j:I

.field public final k:[F

.field public final l:[F

.field public final m:[F

.field public n:Z

.field public o:Z

.field public p:Z

.field public q:Z

.field public r:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    invoke-static {}, Landroid/view/ViewConfiguration;->getTapTimeout()I

    move-result v0

    sput v0, La_68B88B6A;->s:I

    return-void
.end method

.method public constructor <init>(Landroid/view/View;)V
    .locals 10

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, La_1F34386E;

    .line 6
    invoke-direct {v0}, La_1F34386E;-><init>()V

    .line 9
    iput-object v0, p0, La_68B88B6A;->c:La_1F34386E;

    .line 11
    new-instance v1, Landroid/view/animation/AccelerateInterpolator;

    .line 13
    invoke-direct {v1}, Landroid/view/animation/AccelerateInterpolator;-><init>()V

    .line 16
    iput-object v1, p0, La_68B88B6A;->d:Landroid/view/animation/AccelerateInterpolator;

    .line 18
    const/4 v1, 0x2

    .line 19
    new-array v2, v1, [F

    .line 21
    fill-array-data v2, :array_0

    .line 24
    iput-object v2, p0, La_68B88B6A;->g:[F

    .line 26
    new-array v3, v1, [F

    .line 28
    fill-array-data v3, :array_1

    .line 31
    iput-object v3, p0, La_68B88B6A;->h:[F

    .line 33
    new-array v4, v1, [F

    .line 35
    fill-array-data v4, :array_2

    .line 38
    iput-object v4, p0, La_68B88B6A;->k:[F

    .line 40
    new-array v5, v1, [F

    .line 42
    fill-array-data v5, :array_3

    .line 45
    iput-object v5, p0, La_68B88B6A;->l:[F

    .line 47
    new-array v1, v1, [F

    .line 49
    fill-array-data v1, :array_4

    .line 52
    iput-object v1, p0, La_68B88B6A;->m:[F

    .line 54
    iput-object p1, p0, La_68B88B6A;->e:Landroid/view/View;

    .line 56
    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    .line 59
    move-result-object p1

    .line 60
    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 63
    move-result-object p1

    .line 64
    iget p1, p1, Landroid/util/DisplayMetrics;->density:F

    .line 66
    const v6, 0x44c4e000    # 1575.0f

    .line 69
    mul-float v6, v6, p1

    .line 71
    const/high16 v7, 0x3f000000    # 0.5f

    .line 73
    add-float/2addr v6, v7

    .line 74
    float-to-int v6, v6

    .line 75
    const v8, 0x439d8000    # 315.0f

    .line 78
    mul-float p1, p1, v8

    .line 80
    add-float/2addr p1, v7

    .line 81
    float-to-int p1, p1

    .line 82
    int-to-float v6, v6

    .line 83
    const/high16 v7, 0x447a0000    # 1000.0f

    .line 85
    div-float/2addr v6, v7

    .line 86
    const/4 v8, 0x0

    .line 87
    aput v6, v1, v8

    .line 89
    const/4 v9, 0x1

    .line 90
    aput v6, v1, v9

    .line 92
    int-to-float p1, p1

    .line 93
    div-float/2addr p1, v7

    .line 94
    aput p1, v5, v8

    .line 96
    aput p1, v5, v9

    .line 98
    iput v9, p0, La_68B88B6A;->i:I

    .line 100
    const p1, 0x7f7fffff    # Float.MAX_VALUE

    .line 103
    aput p1, v3, v8

    .line 105
    aput p1, v3, v9

    .line 107
    const p1, 0x3e4ccccd    # 0.2f

    .line 110
    aput p1, v2, v8

    .line 112
    aput p1, v2, v9

    .line 114
    const p1, 0x3a83126f    # 0.001f

    .line 117
    aput p1, v4, v8

    .line 119
    aput p1, v4, v9

    .line 121
    sget p1, La_68B88B6A;->s:I

    .line 123
    iput p1, p0, La_68B88B6A;->j:I

    .line 125
    const/16 p1, 0x1f4

    .line 127
    iput p1, v0, La_1F34386E;->a:I

    .line 129
    iput p1, v0, La_1F34386E;->b:I

    .line 131
    return-void

    .line 132
    nop

    .line 133
    :array_0
    .array-data 4
        0x0
        0x0
    .end array-data

    .line 141
    :array_1
    .array-data 4
        0x7f7fffff    # Float.MAX_VALUE
        0x7f7fffff    # Float.MAX_VALUE
    .end array-data

    .line 149
    :array_2
    .array-data 4
        0x0
        0x0
    .end array-data

    .line 157
    :array_3
    .array-data 4
        0x0
        0x0
    .end array-data

    .line 165
    :array_4
    .array-data 4
        0x7f7fffff    # Float.MAX_VALUE
        0x7f7fffff    # Float.MAX_VALUE
    .end array-data
.end method

.method public static b(FFF)F
    .locals 1

    cmpl-float v0, p0, p2

    if-lez v0, :cond_0

    return p2

    :cond_0
    cmpg-float p2, p0, p1

    if-gez p2, :cond_1

    return p1

    :cond_1
    return p0
.end method


# virtual methods
.method public final a(FFFI)F
    .locals 3

    .line 1
    iget-object v0, p0, La_68B88B6A;->g:[F

    .line 3
    aget v0, v0, p4

    .line 5
    iget-object v1, p0, La_68B88B6A;->h:[F

    .line 7
    aget v1, v1, p4

    .line 9
    mul-float v0, v0, p2

    .line 11
    const/4 v2, 0x0

    .line 12
    invoke-static {v0, v2, v1}, La_68B88B6A;->b(FFF)F

    .line 15
    move-result v0

    .line 16
    invoke-virtual {p0, p1, v0}, La_68B88B6A;->c(FF)F

    .line 19
    move-result v1

    .line 20
    sub-float/2addr p2, p1

    .line 21
    invoke-virtual {p0, p2, v0}, La_68B88B6A;->c(FF)F

    .line 24
    move-result p1

    .line 25
    sub-float/2addr p1, v1

    .line 26
    iget-object p2, p0, La_68B88B6A;->d:Landroid/view/animation/AccelerateInterpolator;

    .line 28
    cmpg-float v0, p1, v2

    .line 30
    if-gez v0, :cond_0

    .line 32
    neg-float p1, p1

    .line 33
    invoke-virtual {p2, p1}, Landroid/view/animation/AccelerateInterpolator;->m_387febd5(F)F

    .line 36
    move-result p1

    .line 37
    neg-float p1, p1

    .line 38
    goto :goto_0

    .line 39
    :cond_0
    cmpl-float v0, p1, v2

    .line 41
    if-lez v0, :cond_1

    .line 43
    invoke-virtual {p2, p1}, Landroid/view/animation/AccelerateInterpolator;->m_387febd5(F)F

    .line 46
    move-result p1

    .line 47
    :goto_0
    const/high16 p2, -0x40800000    # -1.0f

    .line 49
    const/high16 v0, 0x3f800000    # 1.0f

    .line 51
    invoke-static {p1, p2, v0}, La_68B88B6A;->b(FFF)F

    .line 54
    move-result p1

    .line 55
    goto :goto_1

    .line 56
    :cond_1
    const/4 p1, 0x0

    .line 57
    :goto_1
    cmpl-float p2, p1, v2

    .line 59
    if-nez p2, :cond_2

    .line 61
    return v2

    .line 62
    :cond_2
    iget-object v0, p0, La_68B88B6A;->k:[F

    .line 64
    aget v0, v0, p4

    .line 66
    iget-object v1, p0, La_68B88B6A;->l:[F

    .line 68
    aget v1, v1, p4

    .line 70
    iget-object v2, p0, La_68B88B6A;->m:[F

    .line 72
    aget p4, v2, p4

    .line 74
    mul-float v0, v0, p3

    .line 76
    if-lez p2, :cond_3

    .line 78
    mul-float p1, p1, v0

    .line 80
    invoke-static {p1, v1, p4}, La_68B88B6A;->b(FFF)F

    .line 83
    move-result p1

    .line 84
    return p1

    .line 85
    :cond_3
    neg-float p1, p1

    .line 86
    mul-float p1, p1, v0

    .line 88
    invoke-static {p1, v1, p4}, La_68B88B6A;->b(FFF)F

    .line 91
    move-result p1

    .line 92
    neg-float p1, p1

    .line 93
    return p1
.end method

.method public final c(FF)F
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    cmpl-float v1, p2, v0

    .line 4
    if-nez v1, :cond_0

    .line 6
    return v0

    .line 7
    :cond_0
    iget v1, p0, La_68B88B6A;->i:I

    .line 9
    const/4 v2, 0x1

    .line 10
    if-eqz v1, :cond_2

    .line 12
    if-eq v1, v2, :cond_2

    .line 14
    const/4 v2, 0x2

    .line 15
    if-eq v1, v2, :cond_1

    .line 17
    goto :goto_0

    .line 18
    :cond_1
    cmpg-float v1, p1, v0

    .line 20
    if-gez v1, :cond_4

    .line 22
    neg-float p2, p2

    .line 23
    div-float/2addr p1, p2

    .line 24
    return p1

    .line 25
    :cond_2
    cmpg-float v3, p1, p2

    .line 27
    if-gez v3, :cond_4

    .line 29
    const/high16 v3, 0x3f800000    # 1.0f

    .line 31
    cmpl-float v4, p1, v0

    .line 33
    if-ltz v4, :cond_3

    .line 35
    div-float/2addr p1, p2

    .line 36
    sub-float/2addr v3, p1

    .line 37
    return v3

    .line 38
    :cond_3
    iget-boolean p1, p0, La_68B88B6A;->q:Z

    .line 40
    if-eqz p1, :cond_4

    .line 42
    if-ne v1, v2, :cond_4

    .line 44
    return v3

    .line 45
    :cond_4
    :goto_0
    return v0
.end method

.method public final d()V
    .locals 6

    .line 1
    iget-boolean v0, p0, La_68B88B6A;->o:Z

    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 6
    iput-boolean v1, p0, La_68B88B6A;->q:Z

    .line 8
    goto :goto_1

    .line 9
    :cond_0
    iget-object v0, p0, La_68B88B6A;->c:La_1F34386E;

    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    .line 17
    move-result-wide v2

    .line 18
    iget-wide v4, v0, La_1F34386E;->e:J

    .line 20
    sub-long v4, v2, v4

    .line 22
    long-to-int v5, v4

    .line 23
    iget v4, v0, La_1F34386E;->b:I

    .line 25
    if-le v5, v4, :cond_1

    .line 27
    move v1, v4

    .line 28
    goto :goto_0

    .line 29
    :cond_1
    if-gez v5, :cond_2

    .line 31
    goto :goto_0

    .line 32
    :cond_2
    move v1, v5

    .line 33
    :goto_0
    iput v1, v0, La_1F34386E;->i:I

    .line 35
    invoke-virtual {v0, v2, v3}, La_1F34386E;->a(J)F

    .line 38
    move-result v1

    .line 39
    iput v1, v0, La_1F34386E;->h:F

    .line 41
    iput-wide v2, v0, La_1F34386E;->g:J

    .line 43
    :goto_1
    return-void
.end method

.method public final e()Z
    .locals 9

    .line 1
    iget-object v0, p0, La_68B88B6A;->c:La_1F34386E;

    .line 3
    iget v1, v0, La_1F34386E;->d:F

    .line 5
    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    .line 8
    move-result v2

    .line 9
    div-float/2addr v1, v2

    .line 10
    float-to-int v1, v1

    .line 11
    iget v0, v0, La_1F34386E;->c:F

    .line 13
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 16
    move-result v2

    .line 17
    div-float/2addr v0, v2

    .line 18
    float-to-int v0, v0

    .line 19
    const/4 v2, 0x0

    .line 20
    if-eqz v1, :cond_5

    .line 22
    move-object v3, p0

    .line 23
    check-cast v3, Lmj;

    .line 25
    iget-object v3, v3, Lmj;->t:Landroid/widget/ListView;

    .line 27
    invoke-virtual {v3}, Landroid/widget/AdapterView;->getCount()I

    .line 30
    move-result v4

    .line 31
    const/4 v5, 0x1

    .line 32
    if-nez v4, :cond_1

    .line 34
    :cond_0
    :goto_0
    const/4 v1, 0x0

    .line 35
    goto :goto_1

    .line 36
    :cond_1
    invoke-virtual {v3}, Landroid/view/ViewGroup;->getChildCount()I

    .line 39
    move-result v6

    .line 40
    invoke-virtual {v3}, Landroid/widget/AdapterView;->getFirstVisiblePosition()I

    .line 43
    move-result v7

    .line 44
    add-int v8, v7, v6

    .line 46
    if-lez v1, :cond_2

    .line 48
    if-lt v8, v4, :cond_3

    .line 50
    sub-int/2addr v6, v5

    .line 51
    invoke-virtual {v3, v6}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 54
    move-result-object v1

    .line 55
    invoke-virtual {v1}, Landroid/view/View;->getBottom()I

    .line 58
    move-result v1

    .line 59
    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    .line 62
    move-result v3

    .line 63
    if-gt v1, v3, :cond_3

    .line 65
    goto :goto_0

    .line 66
    :cond_2
    if-gez v1, :cond_0

    .line 68
    if-gtz v7, :cond_3

    .line 70
    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 73
    move-result-object v1

    .line 74
    invoke-virtual {v1}, Landroid/view/View;->getTop()I

    .line 77
    move-result v1

    .line 78
    if-ltz v1, :cond_3

    .line 80
    goto :goto_0

    .line 81
    :cond_3
    const/4 v1, 0x1

    .line 82
    :goto_1
    if-nez v1, :cond_4

    .line 84
    goto :goto_2

    .line 85
    :cond_4
    const/4 v2, 0x1

    .line 86
    :cond_5
    :goto_2
    return v2
.end method

.method public final onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 7

    .line 1
    iget-boolean v0, p0, La_68B88B6A;->r:Z

    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 6
    return v1

    .line 7
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 10
    move-result v0

    .line 11
    const/4 v2, 0x1

    .line 12
    if-eqz v0, :cond_2

    .line 14
    if-eq v0, v2, :cond_1

    .line 16
    const/4 v3, 0x2

    .line 17
    if-eq v0, v3, :cond_3

    .line 19
    const/4 p1, 0x3

    .line 20
    if-eq v0, p1, :cond_1

    .line 22
    goto :goto_1

    .line 23
    :cond_1
    invoke-virtual {p0}, La_68B88B6A;->d()V

    .line 26
    goto :goto_1

    .line 27
    :cond_2
    iput-boolean v2, p0, La_68B88B6A;->p:Z

    .line 29
    iput-boolean v1, p0, La_68B88B6A;->n:Z

    .line 31
    :cond_3
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    .line 34
    move-result v0

    .line 35
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    .line 38
    move-result v3

    .line 39
    int-to-float v3, v3

    .line 40
    iget-object v4, p0, La_68B88B6A;->e:Landroid/view/View;

    .line 42
    invoke-virtual {v4}, Landroid/view/View;->getWidth()I

    .line 45
    move-result v5

    .line 46
    int-to-float v5, v5

    .line 47
    invoke-virtual {p0, v0, v3, v5, v1}, La_68B88B6A;->a(FFFI)F

    .line 50
    move-result v0

    .line 51
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    .line 54
    move-result p2

    .line 55
    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    .line 58
    move-result p1

    .line 59
    int-to-float p1, p1

    .line 60
    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    .line 63
    move-result v3

    .line 64
    int-to-float v3, v3

    .line 65
    invoke-virtual {p0, p2, p1, v3, v2}, La_68B88B6A;->a(FFFI)F

    .line 68
    move-result p1

    .line 69
    iget-object p2, p0, La_68B88B6A;->c:La_1F34386E;

    .line 71
    iput v0, p2, La_1F34386E;->c:F

    .line 73
    iput p1, p2, La_1F34386E;->d:F

    .line 75
    iget-boolean p1, p0, La_68B88B6A;->q:Z

    .line 77
    if-nez p1, :cond_6

    .line 79
    invoke-virtual {p0}, La_68B88B6A;->e()Z

    .line 82
    move-result p1

    .line 83
    if-eqz p1, :cond_6

    .line 85
    iget-object p1, p0, La_68B88B6A;->f:La_880B8D64;

    .line 87
    if-nez p1, :cond_4

    .line 89
    new-instance p1, La_880B8D64;

    .line 91
    invoke-direct {p1, p0}, La_880B8D64;-><init>(La_68B88B6A;)V

    .line 94
    iput-object p1, p0, La_68B88B6A;->f:La_880B8D64;

    .line 96
    :cond_4
    iput-boolean v2, p0, La_68B88B6A;->q:Z

    .line 98
    iput-boolean v2, p0, La_68B88B6A;->o:Z

    .line 100
    iget-boolean p1, p0, La_68B88B6A;->n:Z

    .line 102
    if-nez p1, :cond_5

    .line 104
    iget p1, p0, La_68B88B6A;->j:I

    .line 106
    if-lez p1, :cond_5

    .line 108
    iget-object p2, p0, La_68B88B6A;->f:La_880B8D64;

    .line 110
    int-to-long v5, p1

    .line 111
    sget-object p1, Lqx;->a:Ljava/util/WeakHashMap;

    .line 113
    invoke-static {v4, p2, v5, v6}, La_19221068;->n(Landroid/view/View;Ljava/lang/Runnable;J)V

    .line 116
    goto :goto_0

    .line 117
    :cond_5
    iget-object p1, p0, La_68B88B6A;->f:La_880B8D64;

    .line 119
    invoke-virtual {p1}, La_880B8D64;->run()V

    .line 122
    :goto_0
    iput-boolean v2, p0, La_68B88B6A;->n:Z

    .line 124
    :cond_6
    :goto_1
    return v1
.end method
