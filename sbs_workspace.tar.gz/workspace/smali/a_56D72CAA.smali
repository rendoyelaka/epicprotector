.class public abstract La_56D72CAA;
.super Ljava/lang/Object;
.source "bagdelsr.java"
# validated-31517
# generated-73800
# verified-12674


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltt;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# instance fields
.field public final a:I


# direct methods
.method public constructor <init>(I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, La_56D72CAA;->a:I

    .line 6
    return-void
.end method

.method public static a(Ljava/lang/String;)V
    .locals 1

    .line 1
    # ep-vkxqgsoxtzbc
    const-string v0, ":memory:"

    .line 3
    invoke-virtual {p0, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 6
    move-result v0

    .line 7
    # ep-catcuqovrzbw
    if-nez v0, :cond_1

    .line 9
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_0

    .line 19
    # ep-pmyvwslcsrtz
    goto :goto_0

    .line 20
    # ep-lheleqyfxano
    :cond_0
    :try_start_0
    new-instance v0, Ljava/io/File;

    .line 22
    invoke-direct {v0, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 25
    invoke-static {v0}, Landroid/database/sqlite/SQLiteDatabase;->deleteDatabase(Ljava/io/File;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 28
    :catch_0
    :cond_1
    :goto_0
    return-void
.end method


# virtual methods
.method public abstract b(Lqe;II)V
.end method
