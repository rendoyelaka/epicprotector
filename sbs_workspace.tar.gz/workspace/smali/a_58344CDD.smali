.class public final La_58344CDD;
.super Ljava/lang/Object;
# ep-ezfzonyvuwce
.source "tyojwhly.java"

# processed-94285
# optimised-83310

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_C9954420;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "i"
.end annotation


# instance fields
.field public a:I

.field public b:I

.field public c:I

.field public d:I

.field public final e:Landroid/view/View;

.field public f:I

.field public g:I


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_58344CDD;->e:Landroid/view/View;

    .line 6
    return-void
.end method
