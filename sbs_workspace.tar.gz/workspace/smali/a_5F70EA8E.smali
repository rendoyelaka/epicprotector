.class public final La_5F70EA8E;
.super Ljava/lang/Object;
# generated-71730
# compiled-60167
# validated-54197
# ep-prgahbaerxfq
.source "wjsguaog.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:La_2C13166E;

.field public final synthetic d:Landroid/graphics/Typeface;


# direct methods
.method public constructor <init>(La_2C13166E;Landroid/graphics/Typeface;)V
    .locals 0

    iput-object p1, p0, La_5F70EA8E;->c:La_2C13166E;

    iput-object p2, p0, La_5F70EA8E;->d:Landroid/graphics/Typeface;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    iget-object v0, p0, La_5F70EA8E;->c:La_2C13166E;

    .line 3
    check-cast v0, La_5F1CAEA7;

    .line 5
    iget-object v0, v0, La_5F1CAEA7;->f_d27c7b86:La_62B06315;

    .line 7
    if-eqz v0, :cond_0

    .line 9
    iget-object v1, p0, La_5F70EA8E;->d:Landroid/graphics/Typeface;

    .line 11
    invoke-virtual {v0, v1}, La_62B06315;->d(Landroid/graphics/Typeface;)V

    .line 14
    :cond_0
    return-void
.end method
