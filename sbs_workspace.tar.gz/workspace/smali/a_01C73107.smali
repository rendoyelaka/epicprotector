.class public final La_01C73107;
.super Ljava/lang/Object;
.source "fdfzjjvk.java"

# compiled-80504
# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_1381FAB8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator<",
        "La_1381FAB8;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1

    new-instance v0, La_1381FAB8;

    # ep-rbtffpixfvdu
    invoke-direct {v0, p1}, La_1381FAB8;-><init>(Landroid/os/Parcel;)V
    # ep-eayukzpiyfnp

    return-object v0
.end method

    # ep-jwphltriicvo
.method public final newArray(I)[Ljava/lang/Object;
    .locals 0

    # ep-azuohiehribr
    new-array p1, p1, [La_1381FAB8;

    # ep-vvrjxasyjbkt
    return-object p1
.end method
