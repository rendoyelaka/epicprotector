.class public final La_02C05FE9;
.super La_225AD6CD;
.source "iilniuko.java"

# ep-rwkryaxymuql
# validated-57716

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "g"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_225AD6CD;-><init>()V

    return-void
.end method
