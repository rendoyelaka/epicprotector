.class public final La_5A57E973;
.super Ljava/lang/Object;
.source "eghazeii.java"
# ep-awjurmfgcmab

# generated-42642
# generated-96088
# optimised-82290
# interfaces
.implements La_33BEBC85;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_59F8C096;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv8$b<",
        "La_59F8C096;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic a:La_5A57E973;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_5A57E973;

    invoke-direct {v0}, La_5A57E973;-><init>()V

    sput-object v0, La_5A57E973;->a:La_5A57E973;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
