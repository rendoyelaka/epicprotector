.class public final La_670107F4;
.super La_B2C873BB;
.source "wcgdxbls.java"
# validated-54992

# ep-uejzliceteei

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Loe;->o(Ljava/lang/Object;Landroid/graphics/Rect;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_B2C873BB;-><init>()V

    return-void
.end method
