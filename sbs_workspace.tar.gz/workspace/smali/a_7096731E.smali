.class public final La_7096731E;
.super La_A1EFABAF;
.source "xzbgukad.java"

# optimised-14440
# compiled-34279
# verified-36260

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_A1EFABAF;-><init>()V

    return-void
.end method
