.class public final La_4A0AA96C;
# ep-gprpnogeldut
.super Ljava/lang/Error;
# compiled-25333
.source "gdkxcswx.java"


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
