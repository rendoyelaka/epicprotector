.class public interface abstract La_3265C419;
.super Ljava/lang/Object;
.source "otjvajpp.java"
