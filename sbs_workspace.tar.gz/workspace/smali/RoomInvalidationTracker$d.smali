.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
.source "pomyzuzk.java"

# generated-87535
# ep-wvxtijnqgdow

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
