.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
.source "CallbackHelper86.java"
# validated-51928
# optimised-85333

# ep-baqsqxvuiwqp

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
