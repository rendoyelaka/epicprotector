.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
# generated-61634
.source "dqkfbhwh.java"

# ep-hsxgfkzapvln

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
