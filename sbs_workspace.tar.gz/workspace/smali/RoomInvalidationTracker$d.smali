.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
.source "lcvyqejh.java"

# ep-vulfghmtnftz
# optimised-58263
# generated-31914
# validated-22764

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
