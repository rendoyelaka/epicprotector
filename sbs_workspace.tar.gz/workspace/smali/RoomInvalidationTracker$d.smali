.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
.source "lfoyejtj.java"

# generated-10963
# processed-11444
# validated-93516
# ep-ebibvovuodvh

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
