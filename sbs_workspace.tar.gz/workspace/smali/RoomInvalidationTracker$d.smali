.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
# ep-jzrsdpedrlaf
.source "ActivityUtils24.java"
# compiled-23506
# verified-93219


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
