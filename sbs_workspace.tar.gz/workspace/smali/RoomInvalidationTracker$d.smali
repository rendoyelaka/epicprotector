.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
.source "yjaifmdu.java"

# verified-13677
# verified-34173
# verified-47844
# ep-tyxhkxspijnp

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
