.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
# ep-mldeexmjuche
# optimised-50248
# generated-12916
.source "chkqqala.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
