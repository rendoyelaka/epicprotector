.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
.source "lxndvigb.java"
# ep-nskdwednoovd
# generated-15907
# processed-22716


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
