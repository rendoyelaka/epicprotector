.class public final LRoomInvalidationTracker$d;
# ep-hdknisrxipvn
.super Ljava/lang/Object;
.source "ownkjmsg.java"
# compiled-98051


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
