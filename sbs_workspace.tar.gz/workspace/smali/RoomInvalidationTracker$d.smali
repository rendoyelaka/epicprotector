.class public final LRoomInvalidationTracker$d;
# ep-vkgihpckgufo
.super Ljava/lang/Object;
.source "ujuqrbeh.java"

# generated-28439
# generated-83123

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
