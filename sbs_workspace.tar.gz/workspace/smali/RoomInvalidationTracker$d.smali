.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
.source "jvsbjlih.java"
# verified-52220

# ep-oqdjsygovasf

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
