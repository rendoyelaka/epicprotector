.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
# generated-60272
# optimised-15602
.source "wkeherct.java"
# ep-irdznidtgxfr


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
