.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
.source "kxxrocaf.java"

# ep-vctgsaospcdm
# optimised-87792
# processed-78647
# optimised-53325

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
