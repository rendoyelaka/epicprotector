.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
.source "fstuxzye.java"
# processed-44715

# ep-foyykiqlafed

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
