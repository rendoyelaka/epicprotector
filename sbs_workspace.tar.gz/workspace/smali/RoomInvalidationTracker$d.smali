.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
# ep-txtijsxzyuoh
.source "DelegateUtils13.java"
# processed-42182


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
