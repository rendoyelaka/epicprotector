.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
.source "ozhbcgvn.java"
# processed-29030
# ep-tamranznchxc


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
