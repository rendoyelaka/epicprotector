.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
.source "zxkkmrzc.java"
# generated-22670
# validated-28591
# ep-ysqjweqlyquw


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
