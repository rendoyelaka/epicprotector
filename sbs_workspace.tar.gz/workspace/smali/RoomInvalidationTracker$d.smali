.class public final LRoomInvalidationTracker$d;
# ep-svrsgjqvwqgl
.super Ljava/lang/Object;
# generated-27417
# validated-10201
.source "hbhejjto.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
