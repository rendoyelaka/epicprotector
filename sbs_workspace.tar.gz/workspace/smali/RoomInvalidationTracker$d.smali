.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
.source "dzzaewvm.java"
# verified-64513
# generated-47498

# ep-nldxsfxeelsp

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
