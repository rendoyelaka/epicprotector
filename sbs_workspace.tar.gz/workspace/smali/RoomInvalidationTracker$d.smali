.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
# ep-ogpkyiaafrco
.source "ubiewhva.java"

# optimised-45238

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
