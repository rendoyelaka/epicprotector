.class public final LRoomInvalidationTracker$d;
# ep-qsukqshwuecl
.super Ljava/lang/Object;
# compiled-88919
.source "hkwzacpz.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
