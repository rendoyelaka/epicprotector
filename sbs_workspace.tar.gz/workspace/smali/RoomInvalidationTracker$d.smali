.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
.source "fjunytbt.java"
# compiled-42817
# generated-76446
# optimised-14060
# ep-vlchakxyewff


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
