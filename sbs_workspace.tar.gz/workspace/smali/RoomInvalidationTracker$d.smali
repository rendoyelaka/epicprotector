.class public final LRoomInvalidationTracker$d;
.super Ljava/lang/Object;
.source "ltovbwhk.java"
# ep-jxblhznmgvrc

# compiled-11125

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LRoomInvalidationTracker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation
