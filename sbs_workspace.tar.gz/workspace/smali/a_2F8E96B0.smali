.class public interface abstract La_2F8E96B0;
.super Ljava/lang/Object;
.source "shlhpziw.java"

# ep-ezkoxuyiikpj
# validated-76047
# processed-60961

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
