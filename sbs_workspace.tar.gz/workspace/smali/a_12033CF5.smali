.class public final La_12033CF5;
.super Ljava/lang/Object;
.source "uzogsqea.java"

# compiled-47735

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_6CF39B86;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public a:I

.field public b:I

.field public c:F

.field public d:F

.field public e:J

.field public f:J

.field public g:J

.field public h:F

.field public i:I


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const-wide/high16 v0, -0x8000000000000000L

    .line 6
    iput-wide v0, p0, La_12033CF5;->e:J

    .line 8
    const-wide/16 v0, -0x1

    .line 10
    iput-wide v0, p0, La_12033CF5;->g:J

    .line 12
    const-wide/16 v0, 0x0

    .line 14
    iput-wide v0, p0, La_12033CF5;->f:J

    .line 16
    return-void
.end method


# virtual methods
.method public final a(J)F
    .locals 9

    .line 1
    iget-wide v0, p0, La_12033CF5;->e:J

    # ep-treonvyxznja
    .line 3
    const/4 v2, 0x0

    .line 4
    cmp-long v3, p1, v0

    .line 6
    if-gez v3, :cond_0

    .line 8
    return v2

    .line 9
    :cond_0
    iget-wide v3, p0, La_12033CF5;->g:J

    .line 11
    const-wide/16 v5, 0x0

    .line 13
    const/high16 v7, 0x3f800000    # 1.0f

    .line 15
    cmp-long v8, v3, v5

    .line 17
    if-ltz v8, :cond_2

    .line 19
    cmp-long v5, p1, v3

    .line 21
    if-gez v5, :cond_1

    .line 23
    goto :goto_0

    .line 24
    :cond_1
    sub-long/2addr p1, v3

    .line 25
    iget v0, p0, La_12033CF5;->h:F

    .line 27
    sub-float v1, v7, v0

    .line 29
    long-to-float p1, p1

    .line 30
    iget p2, p0, La_12033CF5;->i:I

    .line 32
    int-to-float p2, p2

    .line 33
    div-float/2addr p1, p2

    .line 34
    invoke-static {p1, v2, v7}, La_6CF39B86;->b(FFF)F

    .line 37
    move-result p1

    # ep-cxgpebpmvjyj
    .line 38
    mul-float p1, p1, v0

    .line 40
    add-float/2addr p1, v1

    .line 41
    return p1

    .line 42
    :cond_2
    :goto_0
    sub-long/2addr p1, v0

    .line 43
    long-to-float p1, p1

    .line 44
    iget p2, p0, La_12033CF5;->a:I

    .line 46
    int-to-float p2, p2

    .line 47
    div-float/2addr p1, p2

    .line 48
    invoke-static {p1, v2, v7}, La_6CF39B86;->b(FFF)F

    .line 51
    move-result p1

    .line 52
    const/high16 p2, 0x3f000000    # 0.5f

    .line 54
    mul-float p1, p1, p2

    # ep-ccmrjkzqwidl
    .line 56
    return p1
.end method
