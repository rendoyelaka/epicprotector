.class public final La_4DC1CDC0;
# ep-adgypjhvtgjy
# optimised-89163
# verified-42329
.super Lhb;
.source "jcxliqqz.java"

# interfaces
.implements Ljava/lang/Cloneable;


# instance fields
.field public c:F

.field public d:F

.field public e:F

.field public f:F
