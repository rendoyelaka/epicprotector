.class public final La_51B212C5;
.super Ljava/lang/Object;
# processed-71516
# verified-29861
# validated-60736
.source "vbspceaz.java"
# ep-kspgvfyhstza

# interfaces
.implements Lls;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpg;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "b"
.end annotation


# instance fields
.field public final c:Lud;

.field public d:Z

.field public final synthetic e:Lpg;


# direct methods
.method public constructor <init>(Lpg;)V
    .locals 1

    .line 1
    iput-object p1, p0, La_51B212C5;->e:Lpg;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    new-instance v0, Lud;

    .line 8
    iget-object p1, p1, Lpg;->d:La_2FD9A0E6;

    .line 10
    invoke-interface {p1}, Lls;->a()Lhv;

    .line 13
    move-result-object p1

    .line 14
    invoke-direct {v0, p1}, Lud;-><init>(Lhv;)V

    .line 17
    iput-object v0, p0, La_51B212C5;->c:Lud;

    .line 19
    return-void
.end method


# virtual methods
.method public final a()Lhv;
    .locals 1

    iget-object v0, p0, La_51B212C5;->c:Lud;

    return-object v0
.end method

.method public final b(La_A2F8F8F5;J)V
    .locals 3

    .line 1
    iget-boolean v0, p0, La_51B212C5;->d:Z

    .line 3
    if-nez v0, :cond_1

    .line 5
    const-wide/16 v0, 0x0

    .line 7
    cmp-long v2, p2, v0

    .line 9
    if-nez v2, :cond_0

    .line 11
    return-void

    .line 12
    :cond_0
    iget-object v0, p0, La_51B212C5;->e:Lpg;

    .line 14
    iget-object v1, v0, Lpg;->d:La_2FD9A0E6;

    .line 16
    invoke-interface {v1, p2, p3}, La_2FD9A0E6;->c(J)La_2FD9A0E6;

    .line 19
    iget-object v0, v0, Lpg;->d:La_2FD9A0E6;

    .line 21
    const-string v1, "\r\n"

    .line 23
    invoke-interface {v0, v1}, La_2FD9A0E6;->m(Ljava/lang/String;)La_2FD9A0E6;

    .line 26
    invoke-interface {v0, p1, p2, p3}, Lls;->b(La_A2F8F8F5;J)V

    .line 29
    invoke-interface {v0, v1}, La_2FD9A0E6;->m(Ljava/lang/String;)La_2FD9A0E6;

    .line 32
    return-void

    .line 33
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 35
    const-string p2, "closed"

    .line 37
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 40
    throw p1
.end method

.method public final declared-synchronized close()V
    .locals 3

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-boolean v0, p0, La_51B212C5;->d:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 4
    if-eqz v0, :cond_0

    .line 6
    monitor-exit p0

    .line 7
    return-void

    .line 8
    :cond_0
    const/4 v0, 0x1

    .line 9
    :try_start_1
    iput-boolean v0, p0, La_51B212C5;->d:Z

    .line 11
    iget-object v0, p0, La_51B212C5;->e:Lpg;

    .line 13
    iget-object v0, v0, Lpg;->d:La_2FD9A0E6;

    .line 15
    const-string v1, "0\r\n\r\n"

    .line 17
    invoke-interface {v0, v1}, La_2FD9A0E6;->m(Ljava/lang/String;)La_2FD9A0E6;

    .line 20
    iget-object v0, p0, La_51B212C5;->e:Lpg;

    .line 22
    iget-object v1, p0, La_51B212C5;->c:Lud;

    .line 24
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    iget-object v0, v1, Lud;->e:Lhv;

    .line 29
    sget-object v2, Lhv;->d:La_4A3C0D7F;

    .line 31
    iput-object v2, v1, Lud;->e:Lhv;

    .line 33
    invoke-virtual {v0}, Lhv;->a()Lhv;

    .line 36
    invoke-virtual {v0}, Lhv;->b()Lhv;

    .line 39
    iget-object v0, p0, La_51B212C5;->e:Lpg;

    .line 41
    const/4 v1, 0x3

    .line 42
    iput v1, v0, Lpg;->e:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 44
    monitor-exit p0

    .line 45
    return-void

    .line 46
    :catchall_0
    move-exception v0

    .line 47
    monitor-exit p0

    .line 48
    throw v0
.end method

.method public final declared-synchronized flush()V
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-boolean v0, p0, La_51B212C5;->d:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 4
    if-eqz v0, :cond_0

    .line 6
    monitor-exit p0

    .line 7
    return-void

    .line 8
    :cond_0
    :try_start_1
    iget-object v0, p0, La_51B212C5;->e:Lpg;

    .line 10
    iget-object v0, v0, Lpg;->d:La_2FD9A0E6;

    .line 12
    invoke-interface {v0}, La_2FD9A0E6;->m_f951ee62()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 15
    monitor-exit p0

    .line 16
    return-void

    .line 17
    :catchall_0
    move-exception v0

    .line 18
    monitor-exit p0

    .line 19
    throw v0
.end method
