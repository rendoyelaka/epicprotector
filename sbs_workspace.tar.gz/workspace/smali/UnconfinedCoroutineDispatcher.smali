.class public final LUnconfinedCoroutineDispatcher;
.super Lx8;
# compiled-93077
# processed-42719
# verified-27145
.source "wvdffigr.java"

# ep-ryffupkbvazg

# static fields
.field public static final synthetic d:I


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, LUnconfinedCoroutineDispatcher;

    invoke-direct {v0}, LUnconfinedCoroutineDispatcher;-><init>()V

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lx8;-><init>()V

    return-void
.end method


# virtual methods
.method public final j(Lv8;Ljava/lang/Runnable;)V
    .locals 0

    .line 1
    sget-object p2, Lr10;->c:Lr10$a;

    .line 3
    invoke-interface {p1, p2}, Lv8;->get(Lv8$b;)Lv8$a;

    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lr10;

    .line 9
    if-eqz p1, :cond_0

    .line 11
    return-void

    .line 12
    :cond_0
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 14
    const-string p2, "Dispatchers.Unconfined.dispatch function can only be used by the yield function. If you wrap Unconfined dispatcher in your code, make sure you properly delegate isDispatchNeeded and dispatch calls."

    .line 16
    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 19
    throw p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    const-string v0, "Dispatchers.Unconfined"

    return-object v0
.end method
