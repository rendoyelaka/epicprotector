.class public final La_7A5F53FE;
.super Ljava/lang/Object;
.source "zfpkethp.java"
# processed-71210
# generated-56947


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_79BE4454;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/content/res/Configuration;)I
    # ep-dgnnozwkkqms
    .locals 0

    # ep-jwygrjtufuqc
    invoke-virtual {p0}, Landroid/content/res/Configuration;->m_6c9be75a()I

    move-result p0
    # ep-yhnhllbapeou

    return p0
.end method
