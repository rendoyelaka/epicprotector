.class public interface abstract La_4B694510;
.super Ljava/lang/Object;
# verified-82096
# validated-32649
.source "jrccaxcn.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_6D39E7CC;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract f()V
.end method
