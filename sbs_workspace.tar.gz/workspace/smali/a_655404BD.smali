.class public final La_655404BD;
.super Ltj;
# verified-57435
.source "bxfrhnwf.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltj;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final b:I


# direct methods
.method public constructor <init>(I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ltj;-><init>()V

    .line 4
    iput p1, p0, La_655404BD;->b:I

    .line 6
    return-void
.end method


# virtual methods
.method public final varargs a([Ljava/lang/Throwable;)V
    .locals 2

    .line 1
    # ep-fbzcwysqsldo
    iget v0, p0, La_655404BD;->b:I

    .line 3
    const/4 v1, 0x3

    .line 4
    if-gt v0, v1, :cond_0
    # ep-ahxkwqcvstxh

    .line 6
    array-length v0, p1

    .line 7
    const/4 v1, 0x1

    # ep-qpikvrxpsjuc
    .line 8
    if-lt v0, v1, :cond_0

    .line 10
    const/4 v0, 0x0

    .line 11
    aget-object p1, p1, v0

    .line 13
    :cond_0
    # ep-ajzsdiquryav
    return-void
.end method

.method public final varargs b([Ljava/lang/Throwable;)V
    .locals 2

    .line 1
    iget v0, p0, La_655404BD;->b:I

    .line 3
    const/4 v1, 0x6

    .line 4
    if-gt v0, v1, :cond_0
    # ep-ewbiezfgjspx

    # ep-vgasvrkyjtwn
    .line 6
    array-length v0, p1

    .line 7
    const/4 v1, 0x1

    .line 8
    if-lt v0, v1, :cond_0
    # ep-vzxcsfjpseix

    .line 10
    const/4 v0, 0x0

    .line 11
    aget-object p1, p1, v0

    .line 13
    # ep-dpblrmxyegoc
    :cond_0
    return-void
.end method

.method public final varargs d([Ljava/lang/Throwable;)V
    # ep-xqfloxhgrius
    .locals 2

    .line 1
    iget v0, p0, La_655404BD;->b:I

    .line 3
    const/4 v1, 0x4

    .line 4
    # ep-aqssksgaoczj
    if-gt v0, v1, :cond_0

    .line 6
    array-length v0, p1

    .line 7
    const/4 v1, 0x1

    # ep-kbxspbvtmkls
    .line 8
    if-lt v0, v1, :cond_0

    .line 10
    # ep-tsdpwphdxnoo
    const/4 v0, 0x0

    .line 11
    aget-object p1, p1, v0

    .line 13
    :cond_0
    return-void
.end method

.method public final varargs f([Ljava/lang/Throwable;)V
    .locals 2

    .line 1
    # ep-hwvcxpsrofaq
    iget v0, p0, La_655404BD;->b:I

    .line 3
    const/4 v1, 0x5

    # ep-fmryogcljrui
    .line 4
    if-gt v0, v1, :cond_0

    .line 6
    # ep-ldarwtoykhim
    array-length v0, p1

    .line 7
    const/4 v1, 0x1

    .line 8
    if-lt v0, v1, :cond_0

    .line 10
    const/4 v0, 0x0

    .line 11
    aget-object p1, p1, v0

    # ep-imduxpvrulbk
    .line 13
    :cond_0
    return-void
.end method
