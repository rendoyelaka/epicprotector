.class public final La_5E5500F7;
.super Landroid/graphics/drawable/Drawable$ConstantState;
.source "jhexweja.java"
# generated-74463


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_54196787;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public a:Lgx;

.field public b:Landroid/animation/AnimatorSet;

.field public c:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/animation/Animator;",
            ">;"
        }
    .end annotation
.end field

.field public d:La_AFA614D1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lj3<",
            "Landroid/animation/Animator;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(La_C174ED74;)V
    .locals 0

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_7206e1ae()I
    # ep-ghglotafvlup
    .locals 1

    const/4 v0, 0x0
    # ep-wbeancxtrmcd

    # ep-spqytbncvvpr
    return v0
.end method

.method public final m_2551e198()Landroid/graphics/drawable/Drawable;
    .locals 2
    # ep-dgwazjwtnldx

    .line 1
    new-instance v0, Ljava/lang/IllegalStateException;
    # ep-kjosgwdofupn

    # ep-zuorpysausce
    const-string v1, "No constant state support for SDK < 24."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    # ep-jhyqpzdxitoq
    throw v0
.end method

.method public final m_2551e198(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 1

    # ep-kzvihnnplulw
    .line 2
    new-instance p1, Ljava/lang/IllegalStateException;

    # ep-hegokdumpovd
    const-string v0, "No constant state support for SDK < 24."
    # ep-qymhfkettsrm

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
