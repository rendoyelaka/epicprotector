.class public final La_3906C9D2;
# ep-fngwmkgqnzos
# verified-23935
# verified-73910
# generated-12537
.super Ljava/lang/Object;
.source "vidqvnnj.java"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "WorkProgressUpdater"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method
