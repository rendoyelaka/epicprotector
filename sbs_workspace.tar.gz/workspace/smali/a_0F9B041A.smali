.class public final La_0F9B041A;
.super Ljava/lang/Object;
# optimised-64829
# compiled-34619
# verified-22924
.source "bkbmuumk.java"

# interfaces
.implements La_7928952A;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lei;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final a:Landroid/net/Uri;

.field public final b:Landroid/content/ClipDescription;

.field public final c:Landroid/net/Uri;


# direct methods
.method public constructor <init>(Landroid/net/Uri;Landroid/content/ClipDescription;Landroid/net/Uri;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_0F9B041A;->a:Landroid/net/Uri;

    .line 6
    iput-object p2, p0, La_0F9B041A;->b:Landroid/content/ClipDescription;

    .line 8
    iput-object p3, p0, La_0F9B041A;->c:Landroid/net/Uri;

    .line 10
    return-void
.end method


# virtual methods
.method public final a()Landroid/content/ClipDescription;
    # ep-tqhmicndxocr
    .locals 1
    # ep-zsalbhquuguz

    # ep-arhsdtesqntc
    iget-object v0, p0, La_0F9B041A;->b:Landroid/content/ClipDescription;
    # ep-abypkfvfsnsh

    return-object v0
.end method

.method public final b()Ljava/lang/Object;
    # ep-pejhjmybcqms
    .locals 1
    # ep-axctbmmzcfky

    const/4 v0, 0x0
    # ep-ubxoqrqevrho

    # ep-gvabosjqnmrw
    return-object v0
.end method

    # ep-czdjsjpocpnr
.method public final c()Landroid/net/Uri;
    # ep-axpgonmwrupo
    .locals 1

    iget-object v0, p0, La_0F9B041A;->a:Landroid/net/Uri;
    # ep-zdrhtrzgnkcj

    # ep-uttokjrdcabv
    return-object v0
.end method

    # ep-zaviqjrixxvu
.method public final d()V
    # ep-xbfnlxjelqze
    .locals 0
    # ep-abyumxzxbmxf

    return-void
.end method

.method public final e()Landroid/net/Uri;
    .locals 1
    # ep-hkofzwndnoam

    iget-object v0, p0, La_0F9B041A;->c:Landroid/net/Uri;
    # ep-yjesvepgksuq

    # ep-jgygdyltqflq
    return-object v0
.end method
