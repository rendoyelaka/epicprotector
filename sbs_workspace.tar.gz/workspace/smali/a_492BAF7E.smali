.class public final La_492BAF7E;
.super Ljava/lang/Object;
# compiled-38063
# processed-57087
.source "uewfydrp.java"


# instance fields
.field public final a:Lnp;

.field public final b:La_690BE074;


# direct methods
.method public constructor <init>(Lnp;La_690BE074;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_492BAF7E;->a:Lnp;

    .line 6
    iput-object p2, p0, La_492BAF7E;->b:La_690BE074;

    .line 8
    return-void
.end method
