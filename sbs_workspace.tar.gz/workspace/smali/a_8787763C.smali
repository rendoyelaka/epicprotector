.class public final La_8787763C;
.super La_07EFADCD;
.source "hhduzlph.java"
# compiled-77129
# processed-97373

# ep-oicaudzzrtok

# static fields
.field public static volatile d:La_8787763C;

.field public static final e:La_9F468D1F;


# instance fields
.field public final c:La_40F58483;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_9F468D1F;

    invoke-direct {v0}, La_9F468D1F;-><init>()V

    sput-object v0, La_8787763C;->e:La_9F468D1F;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, La_07EFADCD;-><init>()V

    .line 4
    new-instance v0, La_40F58483;

    .line 6
    invoke-direct {v0}, La_40F58483;-><init>()V

    .line 9
    iput-object v0, p0, La_8787763C;->c:La_40F58483;

    .line 11
    return-void
.end method

.method public static q()La_8787763C;
    .locals 2

    .line 1
    sget-object v0, La_8787763C;->d:La_8787763C;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    sget-object v0, La_8787763C;->d:La_8787763C;

    .line 7
    return-object v0

    .line 8
    :cond_0
    const-class v0, La_8787763C;

    .line 10
    monitor-enter v0

    .line 11
    :try_start_0
    sget-object v1, La_8787763C;->d:La_8787763C;

    .line 13
    if-nez v1, :cond_1

    .line 15
    new-instance v1, La_8787763C;

    .line 17
    invoke-direct {v1}, La_8787763C;-><init>()V

    .line 20
    sput-object v1, La_8787763C;->d:La_8787763C;

    .line 22
    :cond_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    sget-object v0, La_8787763C;->d:La_8787763C;

    .line 25
    return-object v0

    .line 26
    :catchall_0
    move-exception v1

    .line 27
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 28
    throw v1
.end method


# virtual methods
.method public final p(Ljava/lang/Runnable;)V
    .locals 1

    iget-object v0, p0, La_8787763C;->c:La_40F58483;

    invoke-virtual {v0, p1}, La_40F58483;->q(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final r()Z
    .locals 1

    iget-object v0, p0, La_8787763C;->c:La_40F58483;

    invoke-virtual {v0}, La_40F58483;->r()Z

    move-result v0

    return v0
.end method

.method public final s(Ljava/lang/Runnable;)V
    .locals 1

    iget-object v0, p0, La_8787763C;->c:La_40F58483;

    invoke-virtual {v0, p1}, La_40F58483;->s(Ljava/lang/Runnable;)V

    return-void
.end method
