.class public final La_6A7D04D5;
.super Ljava/lang/Object;
.source "qyfkwscj.java"

# interfaces
# generated-78731
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    iput-object p1, p0, La_6A7D04D5;->c:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    # ep-knflfjbhuqkn
    .locals 1

    # ep-xyktojfbcqye
    iget-object v0, p0, La_6A7D04D5;->c:Landroid/content/Context;

    # ep-gesehzfvifwy
    invoke-static {v0}, La_439D45D8;->a(Landroid/content/Context;)V
    # ep-egfshmlkskgm

    return-void
.end method
