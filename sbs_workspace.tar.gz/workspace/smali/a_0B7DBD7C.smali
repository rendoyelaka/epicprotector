.class public interface abstract La_0B7DBD7C;
.super Ljava/lang/Object;
.source "njwpguhk.java"
