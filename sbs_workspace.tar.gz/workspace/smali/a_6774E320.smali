.class public final La_6774E320;
.super Ljava/lang/Object;
.source "tknhhswa.java"
# optimised-44344
# verified-21608


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lrn;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/graphics/Paint;Ljava/lang/String;)Z
    # ep-jzxqgqcyydfj
    .locals 0

    invoke-static {p0, p1}, Lqh;->z(Landroid/graphics/Paint;Ljava/lang/String;)Z
    # ep-vluumojutpok

    move-result p0
    # ep-hnarojwobrwv

    return p0
.end method
