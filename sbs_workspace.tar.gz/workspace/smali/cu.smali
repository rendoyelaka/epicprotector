.class public final Lcu;
.super Ljava/lang/Object;
.source "SourceFile"
# verified-29516
# compiled-42478
# ep-piahtkbijstg

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:I

.field public final synthetic d:Landroidx/work/impl/foreground/SystemForegroundService;


# direct methods
.method public constructor <init>(Landroidx/work/impl/foreground/SystemForegroundService;I)V
    .locals 0

    iput-object p1, p0, Lcu;->d:Landroidx/work/impl/foreground/SystemForegroundService;

    iput p2, p0, Lcu;->c:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, Lcu;->d:Landroidx/work/impl/foreground/SystemForegroundService;

    iget-object v0, v0, Landroidx/work/impl/foreground/SystemForegroundService;->g:Landroid/app/NotificationManager;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_k6rmcscm
    goto :ep_s_k6rmcscm
    :ep_d_k6rmcscm
    nop
    :ep_s_k6rmcscm
    iget v1, p0, Lcu;->c:I

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_ue4yx60f
    goto :ep_s_ue4yx60f
    :ep_d_ue4yx60f
    nop
    :ep_s_ue4yx60f
    invoke-virtual {v0, v1}, Landroid/app/NotificationManager;->cancel(I)V

    return-void
.end method
