.class public final Lcu;
.super Ljava/lang/Object;
.source "SourceFile"
# generated-57655
# ep-tmzhzudifgjv

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:I

.field public final synthetic d:Landroidx/work/impl/foreground/SystemForegroundService;


# direct methods
.method public constructor <init>(Landroidx/work/impl/foreground/SystemForegroundService;I)V
    .locals 0

    iput-object p1, p0, Lcu;->d:Landroidx/work/impl/foreground/SystemForegroundService;

    iput p2, p0, Lcu;->c:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, Lcu;->d:Landroidx/work/impl/foreground/SystemForegroundService;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_jth3hak1
    goto :ep_s_jth3hak1
    :ep_d_jth3hak1
    nop
    :ep_s_jth3hak1
    iget-object v0, v0, Landroidx/work/impl/foreground/SystemForegroundService;->g:Landroid/app/NotificationManager;

    iget v1, p0, Lcu;->c:I

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_4mbznnd2
    goto :ep_s_4mbznnd2
    :ep_d_4mbznnd2
    nop
    :ep_s_4mbznnd2
    invoke-virtual {v0, v1}, Landroid/app/NotificationManager;->cancel(I)V

    return-void
.end method
