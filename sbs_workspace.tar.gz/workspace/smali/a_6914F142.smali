.class public interface abstract La_6914F142;
.super Ljava/lang/Object;
# processed-96848
# verified-15071
# processed-35937
# ep-akgttwfetflh
.source "skhqmvoo.java"


# virtual methods
.method public abstract a()Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end method
