.class public final La_081844F3;
.super La_2B1FD1C0;
.source "ynsfoksy.java"

# generated-59950
# ep-cpplvklkerzn

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpj;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# static fields
.field public static final d:La_AFA1E804;


# instance fields
.field public final c:Lts;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lts<",
            "La_82779D71;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_AFA1E804;

    invoke-direct {v0}, La_AFA1E804;-><init>()V

    sput-object v0, La_081844F3;->d:La_AFA1E804;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, La_2B1FD1C0;-><init>()V

    .line 4
    new-instance v0, Lts;

    .line 6
    invoke-direct {v0}, Lts;-><init>()V

    .line 9
    iput-object v0, p0, La_081844F3;->c:Lts;

    .line 11
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 6

    .line 1
    iget-object v0, p0, La_081844F3;->c:Lts;

    .line 3
    iget v1, v0, Lts;->e:I

    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x0

    .line 7
    if-gtz v1, :cond_1

    .line 9
    iget-object v4, v0, Lts;->d:[Ljava/lang/Object;

    .line 11
    const/4 v5, 0x0

    .line 12
    :goto_0
    if-ge v5, v1, :cond_0

    .line 14
    aput-object v3, v4, v5

    .line 16
    add-int/lit8 v5, v5, 0x1

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    iput v2, v0, Lts;->e:I

    .line 21
    return-void

    .line 22
    :cond_1
    iget-object v0, v0, Lts;->d:[Ljava/lang/Object;

    .line 24
    aget-object v0, v0, v2

    .line 26
    check-cast v0, La_82779D71;

    .line 28
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    throw v3
.end method
