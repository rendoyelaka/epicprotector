.class public final La_4C98941A;
.super La_5CC96904;
.source "yndzojgm.java"

# validated-95547
# validated-54320

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La_5CC96904;"
    }
.end annotation


# instance fields
.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Landroidx/activity/result/a;


# direct methods
.method public constructor <init>(Landroidx/activity/result/a;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, La_4C98941A;->d:Landroidx/activity/result/a;

    iput-object p2, p0, La_4C98941A;->c:Ljava/lang/String;

    invoke-direct {p0}, La_5CC96904;-><init>()V

    return-void
.end method
