.class public final La_0887F315;
.super Ljava/lang/Object;
.source "snqkavhu.java"


# verified-21107
# compiled-51390
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_73AFC5B6;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public static a(Ljava/lang/String;)Ljava/util/Locale;
    # ep-cchytzvqxnnc
    .locals 0
    # ep-tqbykizrtivn

    invoke-static {p0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;
    # ep-cpfheckmdxnt

    # ep-bonzowigvskh
    move-result-object p0

    return-object p0
.end method
