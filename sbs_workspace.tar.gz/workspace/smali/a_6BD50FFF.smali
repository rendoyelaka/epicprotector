.class public final La_6BD50FFF;
.super Ljava/lang/Object;
.source "fjdvefbg.java"

# validated-37869
# optimised-64382
# processed-93043
# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    iput-object p1, p0, La_6BD50FFF;->c:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    # ep-sljjlvaewdwt
    iget-object v0, p0, La_6BD50FFF;->c:Landroid/content/Context;

    # ep-elaoqhmpqhzu
    invoke-static {v0}, La_D171B561;->a(Landroid/content/Context;)V
    # ep-avaznuawunad

    # ep-manawnvupjzh
    return-void
.end method
