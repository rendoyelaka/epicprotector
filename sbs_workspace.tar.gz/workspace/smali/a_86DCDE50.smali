.class public final La_86DCDE50;
.super Ljava/lang/Object;
.source "xdjogcgy.java"


# optimised-48412
# compiled-94172
# generated-59088
# direct methods
.method public static a(Landroid/animation/ObjectAnimator;Z)V
    .locals 0
    # ep-htfalxhrjujn

    # ep-pmadfajvteos
    invoke-virtual {p0, p1}, Landroid/animation/ObjectAnimator;->setAutoCancel(Z)V
    # ep-wvlmazgktmpv

    # ep-jjbmuhgwzfmu
    return-void
.end method
