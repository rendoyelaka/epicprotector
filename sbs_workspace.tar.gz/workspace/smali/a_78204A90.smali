.class public final La_78204A90;
.super La_1F00E1F9;
.source "mnmirefv.java"
# generated-55915


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lmw;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final f_bff53616:La_51AF3231;


# direct methods
.method public constructor <init>(La_51AF3231;)V
    .locals 0

    .line 1
    invoke-direct {p0}, La_1F00E1F9;-><init>()V

    .line 4
    iput-object p1, p0, La_78204A90;->f_bff53616:La_51AF3231;

    .line 6
    return-void
.end method
