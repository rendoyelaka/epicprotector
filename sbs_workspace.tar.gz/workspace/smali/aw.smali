.class public abstract Law;
.super Ljava/lang/Object;
.source "pttvaeuz.java"
# processed-87352

# ep-cknippsxvluo
# interfaces
.implements Ljava/lang/Cloneable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Law$c;,
        Law$b;,
        Law$d;
    }
.end annotation


# static fields
.field public static final w:[I

.field public static final x:Law$a;

.field public static final y:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Lj3<",
            "Landroid/animation/Animator;",
            "Law$b;",
            ">;>;"
        }
    .end annotation
.end field


# instance fields
.field public final c:Ljava/lang/String;

.field public d:J

.field public e:J

.field public f:Landroid/animation/TimeInterpolator;

.field public final g:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public final h:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field public i:La5;

.field public j:La5;

.field public k:Lfw;

.field public final l:[I

.field public m:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lhw;",
            ">;"
        }
    .end annotation
.end field

.field public n:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lhw;",
            ">;"
        }
    .end annotation
.end field

.field public final o:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/animation/Animator;",
            ">;"
        }
    .end annotation
.end field

.field public p:I

.field public q:Z

.field public r:Z

.field public s:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Law$d;",
            ">;"
        }
    .end annotation
.end field

.field public t:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/animation/Animator;",
            ">;"
        }
    .end annotation
.end field

.field public u:Law$c;

.field public v:Ln00;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const/4 v0, 0x4

    .line 2
    new-array v0, v0, [I

    .line 4
    fill-array-data v0, :array_0

    .line 7
    sput-object v0, Law;->w:[I

    .line 9
    new-instance v0, Law$a;

    .line 11
    invoke-direct {v0}, Law$a;-><init>()V

    .line 14
    sput-object v0, Law;->x:Law$a;

    .line 16
    new-instance v0, Ljava/lang/ThreadLocal;

    .line 18
    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    .line 21
    sput-object v0, Law;->y:Ljava/lang/ThreadLocal;

    .line 23
    return-void

    .line 24
    nop

    .line 25
    :array_0
    .array-data 4
        0x2
        0x1
        0x3
        0x4
    .end array-data
.end method

.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 11
    move-result-object v0

    .line 12
    iput-object v0, p0, Law;->c:Ljava/lang/String;

    .line 14
    const-wide/16 v0, -0x1

    .line 16
    iput-wide v0, p0, Law;->d:J

    .line 18
    iput-wide v0, p0, Law;->e:J

    .line 20
    const/4 v0, 0x0

    .line 21
    iput-object v0, p0, Law;->f:Landroid/animation/TimeInterpolator;

    .line 23
    new-instance v1, Ljava/util/ArrayList;

    .line 25
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 28
    iput-object v1, p0, Law;->g:Ljava/util/ArrayList;

    .line 30
    new-instance v1, Ljava/util/ArrayList;

    .line 32
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 35
    iput-object v1, p0, Law;->h:Ljava/util/ArrayList;

    .line 37
    new-instance v1, La5;

    .line 39
    const/4 v2, 0x2

    .line 40
    invoke-direct {v1, v2}, La5;-><init>(I)V

    .line 43
    iput-object v1, p0, Law;->i:La5;

    .line 45
    new-instance v1, La5;

    .line 47
    invoke-direct {v1, v2}, La5;-><init>(I)V

    .line 50
    iput-object v1, p0, Law;->j:La5;

    .line 52
    iput-object v0, p0, Law;->k:Lfw;

    .line 54
    sget-object v1, Law;->w:[I

    .line 56
    iput-object v1, p0, Law;->l:[I

    .line 58
    new-instance v1, Ljava/util/ArrayList;

    .line 60
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 63
    iput-object v1, p0, Law;->o:Ljava/util/ArrayList;

    .line 65
    const/4 v1, 0x0

    .line 66
    iput v1, p0, Law;->p:I

    .line 68
    iput-boolean v1, p0, Law;->q:Z

    .line 70
    iput-boolean v1, p0, Law;->r:Z

    .line 72
    iput-object v0, p0, Law;->s:Ljava/util/ArrayList;

    .line 74
    new-instance v0, Ljava/util/ArrayList;

    .line 76
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 79
    iput-object v0, p0, Law;->t:Ljava/util/ArrayList;

    .line 81
    sget-object v0, Law;->x:Law$a;

    .line 83
    iput-object v0, p0, Law;->v:Ln00;

    .line 85
    return-void
.end method

.method public static c(La5;Landroid/view/View;Lhw;)V
    .locals 4

    .line 1
    iget-object v0, p0, La5;->a:Ljava/lang/Object;

    .line 3
    check-cast v0, Lj3;

    .line 5
    invoke-virtual {v0, p1, p2}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 11
    move-result p2

    .line 12
    const/4 v0, 0x0

    .line 13
    if-ltz p2, :cond_1

    .line 15
    iget-object v1, p0, La5;->b:Ljava/lang/Object;

    .line 17
    check-cast v1, Landroid/util/SparseArray;

    .line 19
    invoke-virtual {v1, p2}, Landroid/util/SparseArray;->indexOfKey(I)I

    .line 22
    move-result v2

    .line 23
    if-ltz v2, :cond_0

    .line 25
    invoke-virtual {v1, p2, v0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    invoke-virtual {v1, p2, p1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 32
    :cond_1
    :goto_0
    sget-object p2, Lqx;->a:Ljava/util/WeakHashMap;

    .line 34
    invoke-static {p1}, Lqx$i;->k(Landroid/view/View;)Ljava/lang/String;

    .line 37
    move-result-object p2

    .line 38
    if-eqz p2, :cond_3

    .line 40
    iget-object v1, p0, La5;->d:Ljava/lang/Object;

    .line 42
    check-cast v1, Lj3;

    .line 44
    invoke-virtual {v1, p2}, Lks;->containsKey(Ljava/lang/Object;)Z

    .line 47
    move-result v1

    .line 48
    if-eqz v1, :cond_2

    .line 50
    iget-object v1, p0, La5;->d:Ljava/lang/Object;

    .line 52
    check-cast v1, Lj3;

    .line 54
    invoke-virtual {v1, p2, v0}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 57
    goto :goto_1

    .line 58
    :cond_2
    iget-object v1, p0, La5;->d:Ljava/lang/Object;

    .line 60
    check-cast v1, Lj3;

    .line 62
    invoke-virtual {v1, p2, p1}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 65
    :cond_3
    :goto_1
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 68
    move-result-object p2

    .line 69
    instance-of p2, p2, Landroid/widget/ListView;

    .line 71
    if-eqz p2, :cond_6

    .line 73
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 76
    move-result-object p2

    .line 77
    check-cast p2, Landroid/widget/ListView;

    .line 79
    invoke-virtual {p2}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    .line 82
    move-result-object v1

    .line 83
    invoke-interface {v1}, Landroid/widget/Adapter;->hasStableIds()Z

    .line 86
    move-result v1

    .line 87
    if-eqz v1, :cond_6

    .line 89
    invoke-virtual {p2, p1}, Landroid/widget/AdapterView;->getPositionForView(Landroid/view/View;)I

    .line 92
    move-result v1

    .line 93
    invoke-virtual {p2, v1}, Landroid/widget/AdapterView;->getItemIdAtPosition(I)J

    .line 96
    move-result-wide v1

    .line 97
    iget-object p0, p0, La5;->c:Ljava/lang/Object;

    .line 99
    check-cast p0, Luj;

    .line 101
    iget-boolean p2, p0, Luj;->c:Z

    .line 103
    if-eqz p2, :cond_4

    .line 105
    invoke-virtual {p0}, Luj;->d()V

    .line 108
    :cond_4
    iget-object p2, p0, Luj;->d:[J

    .line 110
    iget v3, p0, Luj;->f:I

    .line 112
    invoke-static {p2, v3, v1, v2}, Lp2;->g([JIJ)I

    .line 115
    move-result p2

    .line 116
    if-ltz p2, :cond_5

    .line 118
    invoke-virtual {p0, v1, v2, v0}, Luj;->e(JLjava/lang/Long;)Ljava/lang/Object;

    .line 121
    move-result-object p1

    .line 122
    check-cast p1, Landroid/view/View;

    .line 124
    if-eqz p1, :cond_6

    .line 126
    const/4 p2, 0x0

    .line 127
    invoke-static {p1, p2}, Lqx$d;->r(Landroid/view/View;Z)V

    .line 130
    invoke-virtual {p0, v1, v2, v0}, Luj;->f(JLjava/lang/Object;)V

    .line 133
    goto :goto_2

    .line 134
    :cond_5
    const/4 p2, 0x1

    .line 135
    invoke-static {p1, p2}, Lqx$d;->r(Landroid/view/View;Z)V

    .line 138
    invoke-virtual {p0, v1, v2, p1}, Luj;->f(JLjava/lang/Object;)V

    .line 141
    :cond_6
    :goto_2
    return-void
.end method

.method public static o()Lj3;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lj3<",
            "Landroid/animation/Animator;",
            "Law$b;",
            ">;"
        }
    .end annotation

    .line 1
    sget-object v0, Law;->y:Ljava/lang/ThreadLocal;

    .line 3
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 6
    move-result-object v1

    .line 7
    check-cast v1, Lj3;

    .line 9
    if-nez v1, :cond_0

    .line 11
    new-instance v1, Lj3;

    .line 13
    invoke-direct {v1}, Lj3;-><init>()V

    .line 16
    invoke-virtual {v0, v1}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 19
    :cond_0
    return-object v1
.end method

.method public static t(Lhw;Lhw;Ljava/lang/String;)Z
    .locals 0

    .line 1
    iget-object p0, p0, Lhw;->a:Ljava/util/HashMap;

    .line 3
    invoke-virtual {p0, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    iget-object p1, p1, Lhw;->a:Ljava/util/HashMap;

    .line 9
    invoke-virtual {p1, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    move-result-object p1

    .line 13
    if-nez p0, :cond_0

    .line 15
    if-nez p1, :cond_0

    .line 17
    const/4 p0, 0x0

    .line 18
    goto :goto_1

    .line 19
    :cond_0
    const/4 p2, 0x1

    .line 20
    if-eqz p0, :cond_2

    .line 22
    if-nez p1, :cond_1

    .line 24
    goto :goto_0

    .line 25
    :cond_1
    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 28
    move-result p0

    .line 29
    xor-int/2addr p0, p2

    .line 30
    goto :goto_1

    .line 31
    :cond_2
    :goto_0
    const/4 p0, 0x1

    .line 32
    :goto_1
    return p0
.end method


# virtual methods
.method public A(Law$c;)V
    .locals 0

    iput-object p1, p0, Law;->u:Law$c;

    return-void
.end method

.method public B(Landroid/animation/TimeInterpolator;)V
    .locals 0

    iput-object p1, p0, Law;->f:Landroid/animation/TimeInterpolator;

    return-void
.end method

.method public C(Ln00;)V
    .locals 0

    .line 1
    if-nez p1, :cond_0

    .line 3
    sget-object p1, Law;->x:Law$a;

    .line 5
    iput-object p1, p0, Law;->v:Ln00;

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    iput-object p1, p0, Law;->v:Ln00;

    .line 10
    :goto_0
    return-void
.end method

.method public D()V
    .locals 0

    return-void
.end method

.method public E(J)V
    .locals 0

    iput-wide p1, p0, Law;->d:J

    return-void
.end method

.method public final F()V
    .locals 5

    .line 1
    iget v0, p0, Law;->p:I

    .line 3
    if-nez v0, :cond_1

    .line 5
    iget-object v0, p0, Law;->s:Ljava/util/ArrayList;

    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_0

    .line 10
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 13
    move-result v0

    .line 14
    if-lez v0, :cond_0

    .line 16
    iget-object v0, p0, Law;->s:Ljava/util/ArrayList;

    .line 18
    invoke-virtual {v0}, Ljava/util/ArrayList;->clone()Ljava/lang/Object;

    .line 21
    move-result-object v0

    .line 22
    check-cast v0, Ljava/util/ArrayList;

    .line 24
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 27
    move-result v2

    .line 28
    const/4 v3, 0x0

    .line 29
    :goto_0
    if-ge v3, v2, :cond_0

    .line 31
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 34
    move-result-object v4

    .line 35
    check-cast v4, Law$d;

    .line 37
    invoke-interface {v4}, Law$d;->a()V

    .line 40
    add-int/lit8 v3, v3, 0x1

    .line 42
    goto :goto_0

    .line 43
    :cond_0
    iput-boolean v1, p0, Law;->r:Z

    .line 45
    :cond_1
    iget v0, p0, Law;->p:I

    .line 47
    add-int/lit8 v0, v0, 0x1

    .line 49
    iput v0, p0, Law;->p:I

    .line 51
    return-void
.end method

.method public G(Ljava/lang/String;)Ljava/lang/String;
    .locals 7

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 6
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 16
    move-result-object p1

    .line 17
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    const-string p1, "@"

    .line 22
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 28
    move-result p1

    .line 29
    invoke-static {p1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 32
    move-result-object p1

    .line 33
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    const-string p1, ": "

    .line 38
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 44
    move-result-object p1

    .line 45
    iget-wide v0, p0, Law;->e:J

    .line 47
    const-string v2, ") "

    .line 49
    const-wide/16 v3, -0x1

    .line 51
    cmp-long v5, v0, v3

    .line 53
    if-eqz v5, :cond_0

    .line 55
    new-instance v0, Ljava/lang/StringBuilder;

    .line 57
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 60
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    const-string p1, "dur("

    .line 65
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    iget-wide v5, p0, Law;->e:J

    .line 70
    invoke-virtual {v0, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 73
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 76
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 79
    move-result-object p1

    .line 80
    :cond_0
    iget-wide v0, p0, Law;->d:J

    .line 82
    cmp-long v5, v0, v3

    .line 84
    if-eqz v5, :cond_1

    .line 86
    new-instance v0, Ljava/lang/StringBuilder;

    .line 88
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 91
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 94
    const-string p1, "dly("

    .line 96
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 99
    iget-wide v3, p0, Law;->d:J

    .line 101
    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 104
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 107
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 110
    move-result-object p1

    .line 111
    :cond_1
    iget-object v0, p0, Law;->f:Landroid/animation/TimeInterpolator;

    .line 113
    if-eqz v0, :cond_2

    .line 115
    new-instance v0, Ljava/lang/StringBuilder;

    .line 117
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 120
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 123
    const-string p1, "interp("

    .line 125
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 128
    iget-object p1, p0, Law;->f:Landroid/animation/TimeInterpolator;

    .line 130
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 133
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 136
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 139
    move-result-object p1

    .line 140
    :cond_2
    iget-object v0, p0, Law;->g:Ljava/util/ArrayList;

    .line 142
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 145
    move-result v1

    .line 146
    iget-object v2, p0, Law;->h:Ljava/util/ArrayList;

    .line 148
    if-gtz v1, :cond_3

    .line 150
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 153
    move-result v1

    .line 154
    if-lez v1, :cond_8

    .line 156
    :cond_3
    const-string v1, "tgts("

    .line 158
    invoke-static {p1, v1}, Lps;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 161
    move-result-object p1

    .line 162
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 165
    move-result v1

    .line 166
    const-string v3, ", "

    .line 168
    const/4 v4, 0x0

    .line 169
    if-lez v1, :cond_5

    .line 171
    const/4 v1, 0x0

    .line 172
    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 175
    move-result v5

    .line 176
    if-ge v1, v5, :cond_5

    .line 178
    if-lez v1, :cond_4

    .line 180
    invoke-static {p1, v3}, Lps;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 183
    move-result-object p1

    .line 184
    :cond_4
    new-instance v5, Ljava/lang/StringBuilder;

    .line 186
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 189
    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 192
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 195
    move-result-object p1

    .line 196
    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 199
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 202
    move-result-object p1

    .line 203
    add-int/lit8 v1, v1, 0x1

    .line 205
    goto :goto_0

    .line 206
    :cond_5
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 209
    move-result v0

    .line 210
    if-lez v0, :cond_7

    .line 212
    :goto_1
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 215
    move-result v0

    .line 216
    if-ge v4, v0, :cond_7

    .line 218
    if-lez v4, :cond_6

    .line 220
    invoke-static {p1, v3}, Lps;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 223
    move-result-object p1

    .line 224
    :cond_6
    new-instance v0, Ljava/lang/StringBuilder;

    .line 226
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 229
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 232
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 235
    move-result-object p1

    .line 236
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 239
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 242
    move-result-object p1

    .line 243
    add-int/lit8 v4, v4, 0x1

    .line 245
    goto :goto_1

    .line 246
    :cond_7
    const-string v0, ")"

    .line 248
    invoke-static {p1, v0}, Lps;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 251
    move-result-object p1

    .line 252
    :cond_8
    return-object p1
.end method

.method public a(Law$d;)V
    .locals 1

    .line 1
    iget-object v0, p0, Law;->s:Ljava/util/ArrayList;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, Ljava/util/ArrayList;

    .line 7
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 10
    iput-object v0, p0, Law;->s:Ljava/util/ArrayList;

    .line 12
    :cond_0
    iget-object v0, p0, Law;->s:Ljava/util/ArrayList;

    .line 14
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 17
    return-void
.end method

.method public b(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Law;->h:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 1

    invoke-virtual {p0}, Law;->j()Law;

    move-result-object v0

    return-object v0
.end method

.method public abstract d(Lhw;)V
.end method

.method public final e(Landroid/view/View;Z)V
    .locals 2

    .line 1
    if-nez p1, :cond_0

    .line 3
    return-void

    .line 4
    :cond_0
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 7
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 10
    move-result-object v0

    .line 11
    instance-of v0, v0, Landroid/view/ViewGroup;

    .line 13
    if-eqz v0, :cond_3

    .line 15
    new-instance v0, Lhw;

    .line 17
    invoke-direct {v0, p1}, Lhw;-><init>(Landroid/view/View;)V

    .line 20
    if-eqz p2, :cond_1

    .line 22
    invoke-virtual {p0, v0}, Law;->g(Lhw;)V

    .line 25
    goto :goto_0

    .line 26
    :cond_1
    invoke-virtual {p0, v0}, Law;->d(Lhw;)V

    .line 29
    :goto_0
    iget-object v1, v0, Lhw;->c:Ljava/util/ArrayList;

    .line 31
    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 34
    invoke-virtual {p0, v0}, Law;->f(Lhw;)V

    .line 37
    if-eqz p2, :cond_2

    .line 39
    iget-object v1, p0, Law;->i:La5;

    .line 41
    invoke-static {v1, p1, v0}, Law;->c(La5;Landroid/view/View;Lhw;)V

    .line 44
    goto :goto_1

    .line 45
    :cond_2
    iget-object v1, p0, Law;->j:La5;

    .line 47
    invoke-static {v1, p1, v0}, Law;->c(La5;Landroid/view/View;Lhw;)V

    .line 50
    :cond_3
    :goto_1
    instance-of v0, p1, Landroid/view/ViewGroup;

    .line 52
    if-eqz v0, :cond_4

    .line 54
    check-cast p1, Landroid/view/ViewGroup;

    .line 56
    const/4 v0, 0x0

    .line 57
    :goto_2
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    .line 60
    move-result v1

    .line 61
    if-ge v0, v1, :cond_4

    .line 63
    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 66
    move-result-object v1

    .line 67
    invoke-virtual {p0, v1, p2}, Law;->e(Landroid/view/View;Z)V

    .line 70
    add-int/lit8 v0, v0, 0x1

    .line 72
    goto :goto_2

    .line 73
    :cond_4
    return-void
.end method

.method public f(Lhw;)V
    .locals 0

    return-void
.end method

.method public abstract g(Lhw;)V
.end method

.method public final h(Landroid/view/ViewGroup;Z)V
    .locals 7

    .line 1
    invoke-virtual {p0, p2}, Law;->i(Z)V

    .line 4
    iget-object v0, p0, Law;->g:Ljava/util/ArrayList;

    .line 6
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 9
    move-result v1

    .line 10
    iget-object v2, p0, Law;->h:Ljava/util/ArrayList;

    .line 12
    if-gtz v1, :cond_1

    .line 14
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 17
    move-result v1

    .line 18
    if-lez v1, :cond_0

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    invoke-virtual {p0, p1, p2}, Law;->e(Landroid/view/View;Z)V

    .line 24
    goto/16 :goto_7

    .line 26
    :cond_1
    :goto_0
    const/4 v1, 0x0

    .line 27
    const/4 v3, 0x0

    .line 28
    :goto_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 31
    move-result v4

    .line 32
    if-ge v3, v4, :cond_5

    .line 34
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 37
    move-result-object v4

    .line 38
    check-cast v4, Ljava/lang/Integer;

    .line 40
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 43
    move-result v4

    .line 44
    invoke-virtual {p1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 47
    move-result-object v4

    .line 48
    if-eqz v4, :cond_4

    .line 50
    new-instance v5, Lhw;

    .line 52
    invoke-direct {v5, v4}, Lhw;-><init>(Landroid/view/View;)V

    .line 55
    if-eqz p2, :cond_2

    .line 57
    invoke-virtual {p0, v5}, Law;->g(Lhw;)V

    .line 60
    goto :goto_2

    .line 61
    :cond_2
    invoke-virtual {p0, v5}, Law;->d(Lhw;)V

    .line 64
    :goto_2
    iget-object v6, v5, Lhw;->c:Ljava/util/ArrayList;

    .line 66
    invoke-virtual {v6, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 69
    invoke-virtual {p0, v5}, Law;->f(Lhw;)V

    .line 72
    if-eqz p2, :cond_3

    .line 74
    iget-object v6, p0, Law;->i:La5;

    .line 76
    invoke-static {v6, v4, v5}, Law;->c(La5;Landroid/view/View;Lhw;)V

    .line 79
    goto :goto_3

    .line 80
    :cond_3
    iget-object v6, p0, Law;->j:La5;

    .line 82
    invoke-static {v6, v4, v5}, Law;->c(La5;Landroid/view/View;Lhw;)V

    .line 85
    :cond_4
    :goto_3
    add-int/lit8 v3, v3, 0x1

    .line 87
    goto :goto_1

    .line 88
    :cond_5
    :goto_4
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 91
    move-result p1

    .line 92
    if-ge v1, p1, :cond_8

    .line 94
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 97
    move-result-object p1

    .line 98
    check-cast p1, Landroid/view/View;

    .line 100
    new-instance v0, Lhw;

    .line 102
    invoke-direct {v0, p1}, Lhw;-><init>(Landroid/view/View;)V

    .line 105
    if-eqz p2, :cond_6

    .line 107
    invoke-virtual {p0, v0}, Law;->g(Lhw;)V

    .line 110
    goto :goto_5

    .line 111
    :cond_6
    invoke-virtual {p0, v0}, Law;->d(Lhw;)V

    .line 114
    :goto_5
    iget-object v3, v0, Lhw;->c:Ljava/util/ArrayList;

    .line 116
    invoke-virtual {v3, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 119
    invoke-virtual {p0, v0}, Law;->f(Lhw;)V

    .line 122
    if-eqz p2, :cond_7

    .line 124
    iget-object v3, p0, Law;->i:La5;

    .line 126
    invoke-static {v3, p1, v0}, Law;->c(La5;Landroid/view/View;Lhw;)V

    .line 129
    goto :goto_6

    .line 130
    :cond_7
    iget-object v3, p0, Law;->j:La5;

    .line 132
    invoke-static {v3, p1, v0}, Law;->c(La5;Landroid/view/View;Lhw;)V

    .line 135
    :goto_6
    add-int/lit8 v1, v1, 0x1

    .line 137
    goto :goto_4

    .line 138
    :cond_8
    :goto_7
    return-void
.end method

.method public final i(Z)V
    .locals 0

    .line 1
    if-eqz p1, :cond_0

    .line 3
    iget-object p1, p0, Law;->i:La5;

    .line 5
    iget-object p1, p1, La5;->a:Ljava/lang/Object;

    .line 7
    check-cast p1, Lj3;

    .line 9
    invoke-virtual {p1}, Lks;->clear()V

    .line 12
    iget-object p1, p0, Law;->i:La5;

    .line 14
    iget-object p1, p1, La5;->b:Ljava/lang/Object;

    .line 16
    check-cast p1, Landroid/util/SparseArray;

    .line 18
    invoke-virtual {p1}, Landroid/util/SparseArray;->clear()V

    .line 21
    iget-object p1, p0, Law;->i:La5;

    .line 23
    iget-object p1, p1, La5;->c:Ljava/lang/Object;

    .line 25
    check-cast p1, Luj;

    .line 27
    invoke-virtual {p1}, Luj;->b()V

    .line 30
    goto :goto_0

    .line 31
    :cond_0
    iget-object p1, p0, Law;->j:La5;

    .line 33
    iget-object p1, p1, La5;->a:Ljava/lang/Object;

    .line 35
    check-cast p1, Lj3;

    .line 37
    invoke-virtual {p1}, Lks;->clear()V

    .line 40
    iget-object p1, p0, Law;->j:La5;

    .line 42
    iget-object p1, p1, La5;->b:Ljava/lang/Object;

    .line 44
    check-cast p1, Landroid/util/SparseArray;

    .line 46
    invoke-virtual {p1}, Landroid/util/SparseArray;->clear()V

    .line 49
    iget-object p1, p0, Law;->j:La5;

    .line 51
    iget-object p1, p1, La5;->c:Ljava/lang/Object;

    .line 53
    check-cast p1, Luj;

    .line 55
    invoke-virtual {p1}, Luj;->b()V

    .line 58
    :goto_0
    return-void
.end method

.method public j()Law;
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_0
    invoke-super {p0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 5
    move-result-object v1

    .line 6
    check-cast v1, Law;

    .line 8
    new-instance v2, Ljava/util/ArrayList;

    .line 10
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 13
    iput-object v2, v1, Law;->t:Ljava/util/ArrayList;

    .line 15
    new-instance v2, La5;

    .line 17
    const/4 v3, 0x2

    .line 18
    invoke-direct {v2, v3}, La5;-><init>(I)V

    .line 21
    iput-object v2, v1, Law;->i:La5;

    .line 23
    new-instance v2, La5;

    .line 25
    invoke-direct {v2, v3}, La5;-><init>(I)V

    .line 28
    iput-object v2, v1, Law;->j:La5;

    .line 30
    iput-object v0, v1, Law;->m:Ljava/util/ArrayList;

    .line 32
    iput-object v0, v1, Law;->n:Ljava/util/ArrayList;
    :try_end_0
    .catch Ljava/lang/CloneNotSupportedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 34
    return-object v1

    .line 35
    :catch_0
    return-object v0
.end method

.method public k(Landroid/view/ViewGroup;Lhw;Lhw;)Landroid/animation/Animator;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public l(Landroid/view/ViewGroup;La5;La5;Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/ViewGroup;",
            "La5;",
            "La5;",
            "Ljava/util/ArrayList<",
            "Lhw;",
            ">;",
            "Ljava/util/ArrayList<",
            "Lhw;",
            ">;)V"
        }
    .end annotation

    .line 1
    move-object/from16 v6, p0

    .line 3
    move-object/from16 v7, p1

    .line 5
    invoke-static {}, Law;->o()Lj3;

    .line 8
    move-result-object v8

    .line 9
    new-instance v9, Landroid/util/SparseIntArray;

    .line 11
    invoke-direct {v9}, Landroid/util/SparseIntArray;-><init>()V

    .line 14
    invoke-virtual/range {p4 .. p4}, Ljava/util/ArrayList;->size()I

    .line 17
    move-result v10

    .line 18
    const/4 v12, 0x0

    .line 19
    :goto_0
    if-ge v12, v10, :cond_c

    .line 21
    move-object/from16 v13, p4

    .line 23
    invoke-virtual {v13, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Lhw;

    .line 29
    move-object/from16 v14, p5

    .line 31
    invoke-virtual {v14, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 34
    move-result-object v1

    .line 35
    check-cast v1, Lhw;

    .line 37
    const/4 v2, 0x0

    .line 38
    if-eqz v0, :cond_0

    .line 40
    iget-object v3, v0, Lhw;->c:Ljava/util/ArrayList;

    .line 42
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 45
    move-result v3

    .line 46
    if-nez v3, :cond_0

    .line 48
    move-object v0, v2

    .line 49
    :cond_0
    if-eqz v1, :cond_1

    .line 51
    iget-object v3, v1, Lhw;->c:Ljava/util/ArrayList;

    .line 53
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 56
    move-result v3

    .line 57
    if-nez v3, :cond_1

    .line 59
    move-object v1, v2

    .line 60
    :cond_1
    if-nez v0, :cond_3

    .line 62
    if-nez v1, :cond_3

    .line 64
    :cond_2
    move-object/from16 v15, p3

    .line 66
    goto/16 :goto_7

    .line 68
    :cond_3
    if-eqz v0, :cond_5

    .line 70
    if-eqz v1, :cond_5

    .line 72
    invoke-virtual {v6, v0, v1}, Law;->r(Lhw;Lhw;)Z

    .line 75
    move-result v3

    .line 76
    if-eqz v3, :cond_4

    .line 78
    goto :goto_1

    .line 79
    :cond_4
    const/4 v3, 0x0

    .line 80
    goto :goto_2

    .line 81
    :cond_5
    :goto_1
    const/4 v3, 0x1

    .line 82
    :goto_2
    if-eqz v3, :cond_2

    .line 84
    invoke-virtual {v6, v7, v0, v1}, Law;->k(Landroid/view/ViewGroup;Lhw;Lhw;)Landroid/animation/Animator;

    .line 87
    move-result-object v3

    .line 88
    if-eqz v3, :cond_2

    .line 90
    if-eqz v1, :cond_a

    .line 92
    invoke-virtual/range {p0 .. p0}, Law;->p()[Ljava/lang/String;

    .line 95
    move-result-object v0

    .line 96
    iget-object v1, v1, Lhw;->b:Landroid/view/View;

    .line 98
    if-eqz v0, :cond_9

    .line 100
    array-length v4, v0

    .line 101
    if-lez v4, :cond_9

    .line 103
    new-instance v4, Lhw;

    .line 105
    invoke-direct {v4, v1}, Lhw;-><init>(Landroid/view/View;)V

    .line 108
    move-object/from16 v15, p3

    .line 110
    iget-object v5, v15, La5;->a:Ljava/lang/Object;

    .line 112
    check-cast v5, Lj3;

    .line 114
    invoke-virtual {v5, v1, v2}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 117
    move-result-object v5

    .line 118
    check-cast v5, Lhw;

    .line 120
    if-eqz v5, :cond_6

    .line 122
    const/4 v11, 0x0

    .line 123
    :goto_3
    array-length v2, v0

    .line 124
    if-ge v11, v2, :cond_6

    .line 126
    iget-object v2, v4, Lhw;->a:Ljava/util/HashMap;

    .line 128
    move-object/from16 v17, v3

    .line 130
    aget-object v3, v0, v11

    .line 132
    move-object/from16 v18, v0

    .line 134
    iget-object v0, v5, Lhw;->a:Ljava/util/HashMap;

    .line 136
    invoke-virtual {v0, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 139
    move-result-object v0

    .line 140
    invoke-virtual {v2, v3, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 143
    add-int/lit8 v11, v11, 0x1

    .line 145
    move-object/from16 v3, v17

    .line 147
    move-object/from16 v0, v18

    .line 149
    goto :goto_3

    .line 150
    :cond_6
    move-object/from16 v17, v3

    .line 152
    iget v0, v8, Lks;->e:I

    .line 154
    const/4 v2, 0x0

    .line 155
    :goto_4
    if-ge v2, v0, :cond_8

    .line 157
    invoke-virtual {v8, v2}, Lks;->h(I)Ljava/lang/Object;

    .line 160
    move-result-object v3

    .line 161
    check-cast v3, Landroid/animation/Animator;

    .line 163
    const/4 v5, 0x0

    .line 164
    invoke-virtual {v8, v3, v5}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 167
    move-result-object v3

    .line 168
    check-cast v3, Law$b;

    .line 170
    iget-object v11, v3, Law$b;->c:Lhw;

    .line 172
    if-eqz v11, :cond_7

    .line 174
    iget-object v11, v3, Law$b;->a:Landroid/view/View;

    .line 176
    if-ne v11, v1, :cond_7

    .line 178
    iget-object v11, v3, Law$b;->b:Ljava/lang/String;

    .line 180
    iget-object v5, v6, Law;->c:Ljava/lang/String;

    .line 182
    invoke-virtual {v11, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 185
    move-result v5

    .line 186
    if-eqz v5, :cond_7

    .line 188
    iget-object v3, v3, Law$b;->c:Lhw;

    .line 190
    invoke-virtual {v3, v4}, Lhw;->equals(Ljava/lang/Object;)Z

    .line 193
    move-result v3

    .line 194
    if-eqz v3, :cond_7

    .line 196
    const/4 v2, 0x0

    .line 197
    goto :goto_5

    .line 198
    :cond_7
    add-int/lit8 v2, v2, 0x1

    .line 200
    goto :goto_4

    .line 201
    :cond_8
    move-object/from16 v2, v17

    .line 203
    goto :goto_5

    .line 204
    :cond_9
    move-object/from16 v15, p3

    .line 206
    move-object/from16 v17, v3

    .line 208
    move-object/from16 v2, v17

    .line 210
    const/4 v4, 0x0

    .line 211
    :goto_5
    move-object v11, v2

    .line 212
    move-object v5, v4

    .line 213
    goto :goto_6

    .line 214
    :cond_a
    move-object/from16 v15, p3

    .line 216
    move-object/from16 v17, v3

    .line 218
    iget-object v0, v0, Lhw;->b:Landroid/view/View;

    .line 220
    move-object v1, v0

    .line 221
    move-object/from16 v11, v17

    .line 223
    const/4 v5, 0x0

    .line 224
    :goto_6
    if-eqz v11, :cond_b

    .line 226
    new-instance v4, Law$b;

    .line 228
    iget-object v2, v6, Law;->c:Ljava/lang/String;

    .line 230
    sget-object v0, Lry;->a:Lvy;

    .line 232
    new-instance v3, Ltz;

    .line 234
    invoke-direct {v3, v7}, Ltz;-><init>(Landroid/view/View;)V

    .line 237
    move-object v0, v4

    .line 238
    move-object/from16 v16, v3

    .line 240
    move-object/from16 v3, p0

    .line 242
    move-object v7, v4

    .line 243
    move-object/from16 v4, v16

    .line 245
    invoke-direct/range {v0 .. v5}, Law$b;-><init>(Landroid/view/View;Ljava/lang/String;Law;Ltz;Lhw;)V

    .line 248
    invoke-virtual {v8, v11, v7}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 251
    iget-object v0, v6, Law;->t:Ljava/util/ArrayList;

    .line 253
    invoke-virtual {v0, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 256
    :cond_b
    :goto_7
    add-int/lit8 v12, v12, 0x1

    .line 258
    move-object/from16 v7, p1

    .line 260
    goto/16 :goto_0

    .line 262
    :cond_c
    invoke-virtual {v9}, Landroid/util/SparseIntArray;->size()I

    .line 265
    move-result v0

    .line 266
    if-eqz v0, :cond_d

    .line 268
    const/4 v11, 0x0

    .line 269
    :goto_8
    invoke-virtual {v9}, Landroid/util/SparseIntArray;->size()I

    .line 272
    move-result v0

    .line 273
    if-ge v11, v0, :cond_d

    .line 275
    invoke-virtual {v9, v11}, Landroid/util/SparseIntArray;->keyAt(I)I

    .line 278
    move-result v0

    .line 279
    iget-object v1, v6, Law;->t:Ljava/util/ArrayList;

    .line 281
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 284
    move-result-object v0

    .line 285
    check-cast v0, Landroid/animation/Animator;

    .line 287
    invoke-virtual {v9, v11}, Landroid/util/SparseIntArray;->valueAt(I)I

    .line 290
    move-result v1

    .line 291
    int-to-long v1, v1

    .line 292
    const-wide v3, 0x7fffffffffffffffL

    .line 297
    sub-long/2addr v1, v3

    .line 298
    invoke-virtual {v0}, Landroid/animation/Animator;->getStartDelay()J

    .line 301
    move-result-wide v3

    .line 302
    add-long/2addr v3, v1

    .line 303
    invoke-virtual {v0, v3, v4}, Landroid/animation/Animator;->setStartDelay(J)V

    .line 306
    add-int/lit8 v11, v11, 0x1

    .line 308
    goto :goto_8

    .line 309
    :cond_d
    return-void
.end method

.method public final m()V
    .locals 6

    .line 1
    iget v0, p0, Law;->p:I

    .line 3
    const/4 v1, 0x1

    .line 4
    sub-int/2addr v0, v1

    .line 5
    iput v0, p0, Law;->p:I

    .line 7
    if-nez v0, :cond_7

    .line 9
    iget-object v0, p0, Law;->s:Ljava/util/ArrayList;

    .line 11
    const/4 v2, 0x0

    .line 12
    if-eqz v0, :cond_0

    .line 14
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 17
    move-result v0

    .line 18
    if-lez v0, :cond_0

    .line 20
    iget-object v0, p0, Law;->s:Ljava/util/ArrayList;

    .line 22
    invoke-virtual {v0}, Ljava/util/ArrayList;->clone()Ljava/lang/Object;

    .line 25
    move-result-object v0

    .line 26
    check-cast v0, Ljava/util/ArrayList;

    .line 28
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 31
    move-result v3

    .line 32
    const/4 v4, 0x0

    .line 33
    :goto_0
    if-ge v4, v3, :cond_0

    .line 35
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 38
    move-result-object v5

    .line 39
    check-cast v5, Law$d;

    .line 41
    invoke-interface {v5, p0}, Law$d;->d(Law;)V

    .line 44
    add-int/lit8 v4, v4, 0x1

    .line 46
    goto :goto_0

    .line 47
    :cond_0
    const/4 v0, 0x0

    .line 48
    :goto_1
    iget-object v3, p0, Law;->i:La5;

    .line 50
    iget-object v3, v3, La5;->c:Ljava/lang/Object;

    .line 52
    check-cast v3, Luj;

    .line 54
    iget-boolean v4, v3, Luj;->c:Z

    .line 56
    if-eqz v4, :cond_1

    .line 58
    invoke-virtual {v3}, Luj;->d()V

    .line 61
    :cond_1
    iget v3, v3, Luj;->f:I

    .line 63
    if-ge v0, v3, :cond_3

    .line 65
    iget-object v3, p0, Law;->i:La5;

    .line 67
    iget-object v3, v3, La5;->c:Ljava/lang/Object;

    .line 69
    check-cast v3, Luj;

    .line 71
    invoke-virtual {v3, v0}, Luj;->g(I)Ljava/lang/Object;

    .line 74
    move-result-object v3

    .line 75
    check-cast v3, Landroid/view/View;

    .line 77
    if-eqz v3, :cond_2

    .line 79
    sget-object v4, Lqx;->a:Ljava/util/WeakHashMap;

    .line 81
    invoke-static {v3, v2}, Lqx$d;->r(Landroid/view/View;Z)V

    .line 84
    :cond_2
    add-int/lit8 v0, v0, 0x1

    .line 86
    goto :goto_1

    .line 87
    :cond_3
    const/4 v0, 0x0

    .line 88
    :goto_2
    iget-object v3, p0, Law;->j:La5;

    .line 90
    iget-object v3, v3, La5;->c:Ljava/lang/Object;

    .line 92
    check-cast v3, Luj;

    .line 94
    iget-boolean v4, v3, Luj;->c:Z

    .line 96
    if-eqz v4, :cond_4

    .line 98
    invoke-virtual {v3}, Luj;->d()V

    .line 101
    :cond_4
    iget v3, v3, Luj;->f:I

    .line 103
    if-ge v0, v3, :cond_6

    .line 105
    iget-object v3, p0, Law;->j:La5;

    .line 107
    iget-object v3, v3, La5;->c:Ljava/lang/Object;

    .line 109
    check-cast v3, Luj;

    .line 111
    invoke-virtual {v3, v0}, Luj;->g(I)Ljava/lang/Object;

    .line 114
    move-result-object v3

    .line 115
    check-cast v3, Landroid/view/View;

    .line 117
    if-eqz v3, :cond_5

    .line 119
    sget-object v4, Lqx;->a:Ljava/util/WeakHashMap;

    .line 121
    invoke-static {v3, v2}, Lqx$d;->r(Landroid/view/View;Z)V

    .line 124
    :cond_5
    add-int/lit8 v0, v0, 0x1

    .line 126
    goto :goto_2

    .line 127
    :cond_6
    iput-boolean v1, p0, Law;->r:Z

    .line 129
    :cond_7
    return-void
.end method

.method public final n(Landroid/view/View;Z)Lhw;
    .locals 5

    .line 1
    iget-object v0, p0, Law;->k:Lfw;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1, p2}, Law;->n(Landroid/view/View;Z)Lhw;

    .line 8
    move-result-object p1

    .line 9
    return-object p1

    .line 10
    :cond_0
    if-eqz p2, :cond_1

    .line 12
    iget-object v0, p0, Law;->m:Ljava/util/ArrayList;

    .line 14
    goto :goto_0

    .line 15
    :cond_1
    iget-object v0, p0, Law;->n:Ljava/util/ArrayList;

    .line 17
    :goto_0
    const/4 v1, 0x0

    .line 18
    if-nez v0, :cond_2

    .line 20
    return-object v1

    .line 21
    :cond_2
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 24
    move-result v2

    .line 25
    const/4 v3, 0x0

    .line 26
    :goto_1
    if-ge v3, v2, :cond_5

    .line 28
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 31
    move-result-object v4

    .line 32
    check-cast v4, Lhw;

    .line 34
    if-nez v4, :cond_3

    .line 36
    return-object v1

    .line 37
    :cond_3
    iget-object v4, v4, Lhw;->b:Landroid/view/View;

    .line 39
    if-ne v4, p1, :cond_4

    .line 41
    goto :goto_2

    .line 42
    :cond_4
    add-int/lit8 v3, v3, 0x1

    .line 44
    goto :goto_1

    .line 45
    :cond_5
    const/4 v3, -0x1

    .line 46
    :goto_2
    if-ltz v3, :cond_7

    .line 48
    if-eqz p2, :cond_6

    .line 50
    iget-object p1, p0, Law;->n:Ljava/util/ArrayList;

    .line 52
    goto :goto_3

    .line 53
    :cond_6
    iget-object p1, p0, Law;->m:Ljava/util/ArrayList;

    .line 55
    :goto_3
    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 58
    move-result-object p1

    .line 59
    move-object v1, p1

    .line 60
    check-cast v1, Lhw;

    .line 62
    :cond_7
    return-object v1
.end method

.method public p()[Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final q(Landroid/view/View;Z)Lhw;
    .locals 1

    .line 1
    iget-object v0, p0, Law;->k:Lfw;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1, p2}, Law;->q(Landroid/view/View;Z)Lhw;

    .line 8
    move-result-object p1

    .line 9
    return-object p1

    .line 10
    :cond_0
    if-eqz p2, :cond_1

    .line 12
    iget-object p2, p0, Law;->i:La5;

    .line 14
    goto :goto_0

    .line 15
    :cond_1
    iget-object p2, p0, Law;->j:La5;

    .line 17
    :goto_0
    iget-object p2, p2, La5;->a:Ljava/lang/Object;

    .line 19
    check-cast p2, Lj3;

    .line 21
    const/4 v0, 0x0

    .line 22
    invoke-virtual {p2, p1, v0}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    move-result-object p1

    .line 26
    check-cast p1, Lhw;

    .line 28
    return-object p1
.end method

.method public r(Lhw;Lhw;)Z
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p1, :cond_3

    .line 4
    if-eqz p2, :cond_3

    .line 6
    invoke-virtual {p0}, Law;->p()[Ljava/lang/String;

    .line 9
    move-result-object v1

    .line 10
    if-eqz v1, :cond_1

    .line 12
    array-length v2, v1

    .line 13
    const/4 v3, 0x0

    .line 14
    :goto_0
    if-ge v3, v2, :cond_3

    .line 16
    aget-object v4, v1, v3

    .line 18
    invoke-static {p1, p2, v4}, Law;->t(Lhw;Lhw;Ljava/lang/String;)Z

    .line 21
    move-result v4

    .line 22
    if-eqz v4, :cond_0

    .line 24
    goto :goto_1

    .line 25
    :cond_0
    add-int/lit8 v3, v3, 0x1

    .line 27
    goto :goto_0

    .line 28
    :cond_1
    iget-object v1, p1, Lhw;->a:Ljava/util/HashMap;

    .line 30
    invoke-virtual {v1}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    .line 33
    move-result-object v1

    .line 34
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 37
    move-result-object v1

    .line 38
    :cond_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 41
    move-result v2

    .line 42
    if-eqz v2, :cond_3

    .line 44
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 47
    move-result-object v2

    .line 48
    check-cast v2, Ljava/lang/String;

    .line 50
    invoke-static {p1, p2, v2}, Law;->t(Lhw;Lhw;Ljava/lang/String;)Z

    .line 53
    move-result v2

    .line 54
    if-eqz v2, :cond_2

    .line 56
    :goto_1
    const/4 v0, 0x1

    .line 57
    :cond_3
    return v0
.end method

.method public final s(Landroid/view/View;)Z
    .locals 5

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, Law;->g:Ljava/util/ArrayList;

    .line 7
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 10
    move-result v2

    .line 11
    const/4 v3, 0x1

    .line 12
    iget-object v4, p0, Law;->h:Ljava/util/ArrayList;

    .line 14
    if-nez v2, :cond_0

    .line 16
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 19
    move-result v2

    .line 20
    if-nez v2, :cond_0

    .line 22
    return v3

    .line 23
    :cond_0
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_2

    .line 33
    invoke-virtual {v4, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 36
    move-result p1

    .line 37
    if-eqz p1, :cond_1

    .line 39
    goto :goto_0

    .line 40
    :cond_1
    const/4 p1, 0x0

    .line 41
    return p1

    .line 42
    :cond_2
    :goto_0
    return v3
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, ""

    .line 3
    invoke-virtual {p0, v0}, Law;->G(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public u(Landroid/view/View;)V
    .locals 6

    .line 1
    iget-boolean v0, p0, Law;->r:Z

    .line 3
    if-nez v0, :cond_4

    .line 5
    invoke-static {}, Law;->o()Lj3;

    .line 8
    move-result-object v0

    .line 9
    iget v1, v0, Lks;->e:I

    .line 11
    sget-object v2, Lry;->a:Lvy;

    .line 13
    invoke-virtual {p1}, Landroid/view/View;->getWindowId()Landroid/view/WindowId;

    .line 16
    move-result-object p1

    .line 17
    const/4 v2, 0x1

    .line 18
    sub-int/2addr v1, v2

    .line 19
    :goto_0
    const/4 v3, 0x0

    .line 20
    if-ltz v1, :cond_2

    .line 22
    invoke-virtual {v0, v1}, Lks;->j(I)Ljava/lang/Object;

    .line 25
    move-result-object v4

    .line 26
    check-cast v4, Law$b;

    .line 28
    iget-object v5, v4, Law$b;->a:Landroid/view/View;

    .line 30
    if-eqz v5, :cond_1

    .line 32
    iget-object v4, v4, Law$b;->d:Luz;

    .line 34
    instance-of v5, v4, Ltz;

    .line 36
    if-eqz v5, :cond_0

    .line 38
    check-cast v4, Ltz;

    .line 40
    iget-object v4, v4, Ltz;->a:Landroid/view/WindowId;

    .line 42
    invoke-virtual {v4, p1}, Landroid/view/WindowId;->equals(Ljava/lang/Object;)Z

    .line 45
    move-result v4

    .line 46
    if-eqz v4, :cond_0

    .line 48
    const/4 v3, 0x1

    .line 49
    :cond_0
    if-eqz v3, :cond_1

    .line 51
    invoke-virtual {v0, v1}, Lks;->h(I)Ljava/lang/Object;

    .line 54
    move-result-object v3

    .line 55
    check-cast v3, Landroid/animation/Animator;

    .line 57
    invoke-virtual {v3}, Landroid/animation/Animator;->pause()V

    .line 60
    :cond_1
    add-int/lit8 v1, v1, -0x1

    .line 62
    goto :goto_0

    .line 63
    :cond_2
    iget-object p1, p0, Law;->s:Ljava/util/ArrayList;

    .line 65
    if-eqz p1, :cond_3

    .line 67
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 70
    move-result p1

    .line 71
    if-lez p1, :cond_3

    .line 73
    iget-object p1, p0, Law;->s:Ljava/util/ArrayList;

    .line 75
    invoke-virtual {p1}, Ljava/util/ArrayList;->clone()Ljava/lang/Object;

    .line 78
    move-result-object p1

    .line 79
    check-cast p1, Ljava/util/ArrayList;

    .line 81
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 84
    move-result v0

    .line 85
    :goto_1
    if-ge v3, v0, :cond_3

    .line 87
    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 90
    move-result-object v1

    .line 91
    check-cast v1, Law$d;

    .line 93
    invoke-interface {v1}, Law$d;->b()V

    .line 96
    add-int/lit8 v3, v3, 0x1

    .line 98
    goto :goto_1

    .line 99
    :cond_3
    iput-boolean v2, p0, Law;->q:Z

    .line 101
    :cond_4
    return-void
.end method

.method public v(Law$d;)V
    .locals 1

    .line 1
    iget-object v0, p0, Law;->s:Ljava/util/ArrayList;

    .line 3
    if-nez v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 9
    iget-object p1, p0, Law;->s:Ljava/util/ArrayList;

    .line 11
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 14
    move-result p1

    .line 15
    if-nez p1, :cond_1

    .line 17
    const/4 p1, 0x0

    .line 18
    iput-object p1, p0, Law;->s:Ljava/util/ArrayList;

    .line 20
    :cond_1
    return-void
.end method

.method public w(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Law;->h:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    return-void
.end method

.method public x(Landroid/view/ViewGroup;)V
    .locals 6

    .line 1
    iget-boolean v0, p0, Law;->q:Z

    .line 3
    if-eqz v0, :cond_4

    .line 5
    iget-boolean v0, p0, Law;->r:Z

    .line 7
    const/4 v1, 0x0

    .line 8
    if-nez v0, :cond_3

    .line 10
    invoke-static {}, Law;->o()Lj3;

    .line 13
    move-result-object v0

    .line 14
    iget v2, v0, Lks;->e:I

    .line 16
    sget-object v3, Lry;->a:Lvy;

    .line 18
    invoke-virtual {p1}, Landroid/view/View;->getWindowId()Landroid/view/WindowId;

    .line 21
    move-result-object p1

    .line 22
    const/4 v3, 0x1

    .line 23
    sub-int/2addr v2, v3

    .line 24
    :goto_0
    if-ltz v2, :cond_2

    .line 26
    invoke-virtual {v0, v2}, Lks;->j(I)Ljava/lang/Object;

    .line 29
    move-result-object v4

    .line 30
    check-cast v4, Law$b;

    .line 32
    iget-object v5, v4, Law$b;->a:Landroid/view/View;

    .line 34
    if-eqz v5, :cond_1

    .line 36
    iget-object v4, v4, Law$b;->d:Luz;

    .line 38
    instance-of v5, v4, Ltz;

    .line 40
    if-eqz v5, :cond_0

    .line 42
    check-cast v4, Ltz;

    .line 44
    iget-object v4, v4, Ltz;->a:Landroid/view/WindowId;

    .line 46
    invoke-virtual {v4, p1}, Landroid/view/WindowId;->equals(Ljava/lang/Object;)Z

    .line 49
    move-result v4

    .line 50
    if-eqz v4, :cond_0

    .line 52
    const/4 v4, 0x1

    .line 53
    goto :goto_1

    .line 54
    :cond_0
    const/4 v4, 0x0

    .line 55
    :goto_1
    if-eqz v4, :cond_1

    .line 57
    invoke-virtual {v0, v2}, Lks;->h(I)Ljava/lang/Object;

    .line 60
    move-result-object v4

    .line 61
    check-cast v4, Landroid/animation/Animator;

    .line 63
    invoke-virtual {v4}, Landroid/animation/Animator;->resume()V

    .line 66
    :cond_1
    add-int/lit8 v2, v2, -0x1

    .line 68
    goto :goto_0

    .line 69
    :cond_2
    iget-object p1, p0, Law;->s:Ljava/util/ArrayList;

    .line 71
    if-eqz p1, :cond_3

    .line 73
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 76
    move-result p1

    .line 77
    if-lez p1, :cond_3

    .line 79
    iget-object p1, p0, Law;->s:Ljava/util/ArrayList;

    .line 81
    invoke-virtual {p1}, Ljava/util/ArrayList;->clone()Ljava/lang/Object;

    .line 84
    move-result-object p1

    .line 85
    check-cast p1, Ljava/util/ArrayList;

    .line 87
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 90
    move-result v0

    .line 91
    const/4 v2, 0x0

    .line 92
    :goto_2
    if-ge v2, v0, :cond_3

    .line 94
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 97
    move-result-object v3

    .line 98
    check-cast v3, Law$d;

    .line 100
    invoke-interface {v3}, Law$d;->c()V

    .line 103
    add-int/lit8 v2, v2, 0x1

    .line 105
    goto :goto_2

    .line 106
    :cond_3
    iput-boolean v1, p0, Law;->q:Z

    .line 108
    :cond_4
    return-void
.end method

.method public y()V
    .locals 8

    .line 1
    invoke-virtual {p0}, Law;->F()V

    .line 4
    invoke-static {}, Law;->o()Lj3;

    .line 7
    move-result-object v0

    .line 8
    iget-object v1, p0, Law;->t:Ljava/util/ArrayList;

    .line 10
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 13
    move-result-object v1

    .line 14
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    move-result v2

    .line 18
    if-eqz v2, :cond_4

    .line 20
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    move-result-object v2

    .line 24
    check-cast v2, Landroid/animation/Animator;

    .line 26
    invoke-virtual {v0, v2}, Lks;->containsKey(Ljava/lang/Object;)Z

    .line 29
    move-result v3

    .line 30
    if-eqz v3, :cond_0

    .line 32
    invoke-virtual {p0}, Law;->F()V

    .line 35
    if-eqz v2, :cond_0

    .line 37
    new-instance v3, Lbw;

    .line 39
    invoke-direct {v3, p0, v0}, Lbw;-><init>(Law;Lj3;)V

    .line 42
    invoke-virtual {v2, v3}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 45
    iget-wide v3, p0, Law;->e:J

    .line 47
    const-wide/16 v5, 0x0

    .line 49
    cmp-long v7, v3, v5

    .line 51
    if-ltz v7, :cond_1

    .line 53
    invoke-virtual {v2, v3, v4}, Landroid/animation/Animator;->setDuration(J)Landroid/animation/Animator;

    .line 56
    :cond_1
    iget-wide v3, p0, Law;->d:J

    .line 58
    cmp-long v7, v3, v5

    .line 60
    if-ltz v7, :cond_2

    .line 62
    invoke-virtual {v2}, Landroid/animation/Animator;->getStartDelay()J

    .line 65
    move-result-wide v5

    .line 66
    add-long/2addr v5, v3

    .line 67
    invoke-virtual {v2, v5, v6}, Landroid/animation/Animator;->setStartDelay(J)V

    .line 70
    :cond_2
    iget-object v3, p0, Law;->f:Landroid/animation/TimeInterpolator;

    .line 72
    if-eqz v3, :cond_3

    .line 74
    invoke-virtual {v2, v3}, Landroid/animation/Animator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    .line 77
    :cond_3
    new-instance v3, Lcw;

    .line 79
    invoke-direct {v3, p0}, Lcw;-><init>(Law;)V

    .line 82
    invoke-virtual {v2, v3}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 85
    invoke-virtual {v2}, Landroid/animation/Animator;->start()V

    .line 88
    goto :goto_0

    .line 89
    :cond_4
    iget-object v0, p0, Law;->t:Ljava/util/ArrayList;

    .line 91
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 94
    invoke-virtual {p0}, Law;->m()V

    .line 97
    return-void
.end method

.method public z(J)V
    .locals 0

    iput-wide p1, p0, Law;->e:J

    return-void
.end method
