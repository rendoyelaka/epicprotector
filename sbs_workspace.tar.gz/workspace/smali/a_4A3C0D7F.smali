.class public final La_4A3C0D7F;
.super Lhv;
# ep-ropobttyphlx
# optimised-33969
.source "kxlxmxqn.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lhv;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lhv;-><init>()V

    return-void
.end method


# virtual methods
.method public final d(J)Lhv;
    .locals 0

    return-object p0
.end method

.method public final f()V
    .locals 0

    return-void
.end method

.method public final g(JLjava/util/concurrent/TimeUnit;)Lhv;
    .locals 0

    return-object p0
.end method
