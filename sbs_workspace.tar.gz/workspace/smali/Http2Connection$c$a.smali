.class public final LHttp2Connection$c$a;
# callback-63620-binding
# context-16494-provider
# provider-98494-loader
# observer-15492-dispatcher
# service-25731-factory
.super LHttp2Connection$c;
.source "CameraUtils16.java"
# validated-21383
# compiled-34865
# ep-oidjbpoeddze


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Connection$c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LHttp2Connection$c;-><init>()V

    return-void
.end method


# virtual methods
.method public final b(Ldh;)V
    .locals 1

    const/4 v0, 0x5

    invoke-virtual {p1, v0}, Ldh;->c(I)V

    return-void
.end method
