.class public final LHttp2Connection$c$a;
# ep-gmiceslyggns
# optimised-14583
# validated-81446
# optimised-99473
.super LHttp2Connection$c;
.source "oqfhfqck.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LHttp2Connection$c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LHttp2Connection$c;-><init>()V

    return-void
.end method


# virtual methods
.method public final b(Ldh;)V
    .locals 1

    const/4 v0, 0x5

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_ii37buil
    goto :ep_s_ii37buil
    :ep_d_ii37buil
    nop
    :ep_s_ii37buil
    invoke-virtual {p1, v0}, Ldh;->c(I)V

    return-void
.end method
