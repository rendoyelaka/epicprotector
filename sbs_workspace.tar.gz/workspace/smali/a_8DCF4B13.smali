.class public final La_8DCF4B13;
.super Ljava/lang/Object;
.source "yrwwvgra.java"

# ep-hsagkauubeyq
# compiled-36235
# verified-26192
# compiled-91878

# instance fields
.field public final a:Lih;

.field public final b:Lra;

.field public final c:Ljavax/net/SocketFactory;

.field public final d:La_119635E9;

.field public final e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lvo;",
            ">;"
        }
    .end annotation
.end field

.field public final f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "La_D3507BAE;",
            ">;"
        }
    .end annotation
.end field

.field public final g:Ljava/net/ProxySelector;

.field public final h:Ljava/net/Proxy;

.field public final i:Ljavax/net/ssl/SSLSocketFactory;

.field public final j:Ljavax/net/ssl/HostnameVerifier;

.field public final k:La_61B1C423;


# direct methods
.method public constructor <init>(Ljava/lang/String;ILra;Ljavax/net/SocketFactory;Ljavax/net/ssl/SSLSocketFactory;Ljavax/net/ssl/HostnameVerifier;La_61B1C423;La_119635E9;Ljava/net/Proxy;Ljava/util/List;Ljava/util/List;Ljava/net/ProxySelector;)V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "Lra;",
            "Ljavax/net/SocketFactory;",
            "Ljavax/net/ssl/SSLSocketFactory;",
            "Ljavax/net/ssl/HostnameVerifier;",
            "La_61B1C423;",
            "La_119635E9;",
            "Ljava/net/Proxy;",
            "Ljava/util/List<",
            "Lvo;",
            ">;",
            "Ljava/util/List<",
            "La_D3507BAE;",
            ">;",
            "Ljava/net/ProxySelector;",
            ")V"
        }
    .end annotation

    move-object v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p8

    move-object/from16 v7, p10

    move-object/from16 v8, p11

    move-object/from16 v9, p12

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v10, La_8D0BACFA;

    invoke-direct {v10}, La_8D0BACFA;-><init>()V

    const-string v11, "https"

    const-string v12, "http"

    if-eqz v5, :cond_0

    move-object v13, v11

    goto :goto_0

    :cond_0
    move-object v13, v12

    .line 3
    :goto_0
    invoke-virtual {v13, v12}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v14

    if-eqz v14, :cond_1

    .line 4
    iput-object v12, v10, La_8D0BACFA;->a:Ljava/lang/String;

    goto :goto_1

    .line 5
    :cond_1
    invoke-virtual {v13, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_b

    .line 6
    iput-object v11, v10, La_8D0BACFA;->a:Ljava/lang/String;

    :goto_1
    if-eqz v1, :cond_a

    const/4 v11, 0x0

    .line 7
    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->length()I

    move-result v12

    invoke-static {v11, v12, v1}, La_8D0BACFA;->b(IILjava/lang/String;)Ljava/lang/String;

    move-result-object v11

    if-eqz v11, :cond_9

    .line 8
    iput-object v11, v10, La_8D0BACFA;->d:Ljava/lang/String;

    if-lez v2, :cond_8

    const v1, 0xffff

    if-gt v2, v1, :cond_8

    .line 9
    iput v2, v10, La_8D0BACFA;->e:I

    .line 10
    invoke-virtual {v10}, La_8D0BACFA;->a()Lih;

    move-result-object v1

    iput-object v1, v0, La_8DCF4B13;->a:Lih;

    if-eqz v3, :cond_7

    .line 11
    iput-object v3, v0, La_8DCF4B13;->b:Lra;

    if-eqz v4, :cond_6

    .line 12
    iput-object v4, v0, La_8DCF4B13;->c:Ljavax/net/SocketFactory;

    if-eqz v6, :cond_5

    .line 13
    iput-object v6, v0, La_8DCF4B13;->d:La_119635E9;

    if-eqz v7, :cond_4

    .line 14
    sget-object v1, Lex;->a:[B

    .line 15
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1, v7}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    .line 16
    iput-object v1, v0, La_8DCF4B13;->e:Ljava/util/List;

    if-eqz v8, :cond_3

    .line 17
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1, v8}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    .line 18
    iput-object v1, v0, La_8DCF4B13;->f:Ljava/util/List;

    if-eqz v9, :cond_2

    .line 19
    iput-object v9, v0, La_8DCF4B13;->g:Ljava/net/ProxySelector;

    move-object/from16 v1, p9

    .line 20
    iput-object v1, v0, La_8DCF4B13;->h:Ljava/net/Proxy;

    .line 21
    iput-object v5, v0, La_8DCF4B13;->i:Ljavax/net/ssl/SSLSocketFactory;

    move-object/from16 v1, p6

    .line 22
    iput-object v1, v0, La_8DCF4B13;->j:Ljavax/net/ssl/HostnameVerifier;

    move-object/from16 v1, p7

    .line 23
    iput-object v1, v0, La_8DCF4B13;->k:La_61B1C423;

    return-void

    .line 24
    :cond_2
    new-instance v1, Ljava/lang/NullPointerException;

    const-string v2, "proxySelector == null"

    invoke-direct {v1, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 25
    :cond_3
    new-instance v1, Ljava/lang/NullPointerException;

    const-string v2, "connectionSpecs == null"

    invoke-direct {v1, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 26
    :cond_4
    new-instance v1, Ljava/lang/NullPointerException;

    const-string v2, "protocols == null"

    invoke-direct {v1, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 27
    :cond_5
    new-instance v1, Ljava/lang/NullPointerException;

    const-string v2, "proxyAuthenticator == null"

    invoke-direct {v1, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 28
    :cond_6
    new-instance v1, Ljava/lang/NullPointerException;

    const-string v2, "socketFactory == null"

    invoke-direct {v1, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 29
    :cond_7
    new-instance v1, Ljava/lang/NullPointerException;

    const-string v2, "dns == null"

    invoke-direct {v1, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 30
    :cond_8
    new-instance v1, Ljava/lang/IllegalArgumentException;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "unexpected port: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 31
    :cond_9
    new-instance v2, Ljava/lang/IllegalArgumentException;

    const-string v3, "unexpected host: "

    invoke-virtual {v3, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 32
    :cond_a
    new-instance v1, Ljava/lang/NullPointerException;

    const-string v2, "host == null"

    invoke-direct {v1, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 33
    :cond_b
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "unexpected scheme: "

    invoke-virtual {v2, v13}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    .line 1
    instance-of v0, p1, La_8DCF4B13;

    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 6
    check-cast p1, La_8DCF4B13;

    .line 8
    iget-object v0, p1, La_8DCF4B13;->a:Lih;

    .line 10
    iget-object v2, p0, La_8DCF4B13;->a:Lih;

    .line 12
    invoke-virtual {v2, v0}, Lih;->equals(Ljava/lang/Object;)Z

    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 18
    iget-object v0, p0, La_8DCF4B13;->b:Lra;

    .line 20
    iget-object v2, p1, La_8DCF4B13;->b:Lra;

    .line 22
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_0

    .line 28
    iget-object v0, p0, La_8DCF4B13;->d:La_119635E9;

    .line 30
    iget-object v2, p1, La_8DCF4B13;->d:La_119635E9;

    .line 32
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_0

    .line 38
    iget-object v0, p0, La_8DCF4B13;->e:Ljava/util/List;

    .line 40
    iget-object v2, p1, La_8DCF4B13;->e:Ljava/util/List;

    .line 42
    invoke-interface {v0, v2}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_0

    .line 48
    iget-object v0, p0, La_8DCF4B13;->f:Ljava/util/List;

    .line 50
    iget-object v2, p1, La_8DCF4B13;->f:Ljava/util/List;

    .line 52
    invoke-interface {v0, v2}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    .line 55
    move-result v0

    .line 56
    if-eqz v0, :cond_0

    .line 58
    iget-object v0, p0, La_8DCF4B13;->g:Ljava/net/ProxySelector;

    .line 60
    iget-object v2, p1, La_8DCF4B13;->g:Ljava/net/ProxySelector;

    .line 62
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 65
    move-result v0

    .line 66
    if-eqz v0, :cond_0

    .line 68
    iget-object v0, p0, La_8DCF4B13;->h:Ljava/net/Proxy;

    .line 70
    iget-object v2, p1, La_8DCF4B13;->h:Ljava/net/Proxy;

    .line 72
    invoke-static {v0, v2}, Lex;->f(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_0

    .line 78
    iget-object v0, p0, La_8DCF4B13;->i:Ljavax/net/ssl/SSLSocketFactory;

    .line 80
    iget-object v2, p1, La_8DCF4B13;->i:Ljavax/net/ssl/SSLSocketFactory;

    .line 82
    invoke-static {v0, v2}, Lex;->f(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 85
    move-result v0

    .line 86
    if-eqz v0, :cond_0

    .line 88
    iget-object v0, p0, La_8DCF4B13;->j:Ljavax/net/ssl/HostnameVerifier;

    .line 90
    iget-object v2, p1, La_8DCF4B13;->j:Ljavax/net/ssl/HostnameVerifier;

    .line 92
    invoke-static {v0, v2}, Lex;->f(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 95
    move-result v0

    .line 96
    if-eqz v0, :cond_0

    .line 98
    iget-object v0, p0, La_8DCF4B13;->k:La_61B1C423;

    .line 100
    iget-object p1, p1, La_8DCF4B13;->k:La_61B1C423;

    .line 102
    invoke-static {v0, p1}, Lex;->f(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 105
    move-result p1

    .line 106
    if-eqz p1, :cond_0

    .line 108
    const/4 v1, 0x1

    .line 109
    :cond_0
    return v1
.end method

.method public final hashCode()I
    .locals 3

    .line 1
    iget-object v0, p0, La_8DCF4B13;->a:Lih;

    .line 3
    invoke-virtual {v0}, Lih;->hashCode()I

    .line 6
    move-result v0

    .line 7
    add-int/lit16 v0, v0, 0x20f

    .line 9
    mul-int/lit8 v0, v0, 0x1f

    .line 11
    iget-object v1, p0, La_8DCF4B13;->b:Lra;

    .line 13
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 16
    move-result v1

    .line 17
    add-int/2addr v1, v0

    .line 18
    mul-int/lit8 v1, v1, 0x1f

    .line 20
    iget-object v0, p0, La_8DCF4B13;->d:La_119635E9;

    .line 22
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 25
    move-result v0

    .line 26
    add-int/2addr v0, v1

    .line 27
    mul-int/lit8 v0, v0, 0x1f

    .line 29
    iget-object v1, p0, La_8DCF4B13;->e:Ljava/util/List;

    .line 31
    invoke-interface {v1}, Ljava/util/List;->hashCode()I

    .line 34
    move-result v1

    .line 35
    add-int/2addr v1, v0

    .line 36
    mul-int/lit8 v1, v1, 0x1f

    .line 38
    iget-object v0, p0, La_8DCF4B13;->f:Ljava/util/List;

    .line 40
    invoke-interface {v0}, Ljava/util/List;->hashCode()I

    .line 43
    move-result v0

    .line 44
    add-int/2addr v0, v1

    .line 45
    mul-int/lit8 v0, v0, 0x1f

    .line 47
    iget-object v1, p0, La_8DCF4B13;->g:Ljava/net/ProxySelector;

    .line 49
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 52
    move-result v1

    .line 53
    add-int/2addr v1, v0

    .line 54
    mul-int/lit8 v1, v1, 0x1f

    .line 56
    const/4 v0, 0x0

    .line 57
    iget-object v2, p0, La_8DCF4B13;->h:Ljava/net/Proxy;

    .line 59
    if-eqz v2, :cond_0

    .line 61
    invoke-virtual {v2}, Ljava/net/Proxy;->hashCode()I

    .line 64
    move-result v2

    .line 65
    goto :goto_0

    .line 66
    :cond_0
    const/4 v2, 0x0

    .line 67
    :goto_0
    add-int/2addr v1, v2

    .line 68
    mul-int/lit8 v1, v1, 0x1f

    .line 70
    iget-object v2, p0, La_8DCF4B13;->i:Ljavax/net/ssl/SSLSocketFactory;

    .line 72
    if-eqz v2, :cond_1

    .line 74
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 77
    move-result v2

    .line 78
    goto :goto_1

    .line 79
    :cond_1
    const/4 v2, 0x0

    .line 80
    :goto_1
    add-int/2addr v1, v2

    .line 81
    mul-int/lit8 v1, v1, 0x1f

    .line 83
    iget-object v2, p0, La_8DCF4B13;->j:Ljavax/net/ssl/HostnameVerifier;

    .line 85
    if-eqz v2, :cond_2

    .line 87
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 90
    move-result v2

    .line 91
    goto :goto_2

    .line 92
    :cond_2
    const/4 v2, 0x0

    .line 93
    :goto_2
    add-int/2addr v1, v2

    .line 94
    mul-int/lit8 v1, v1, 0x1f

    .line 96
    iget-object v2, p0, La_8DCF4B13;->k:La_61B1C423;

    .line 98
    if-eqz v2, :cond_3

    .line 100
    invoke-virtual {v2}, La_61B1C423;->hashCode()I

    .line 103
    move-result v0

    .line 104
    :cond_3
    add-int/2addr v1, v0

    .line 105
    return v1
.end method
