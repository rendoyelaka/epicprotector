.class public La_92E0D06F;
.super Ljava/lang/Object;
.source "pxvaamxu.java"
# optimised-16182


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "e"
.end annotation


# instance fields
.field public final a:Lwz;

.field public b:[Lii;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    new-instance v0, Lwz;

    invoke-direct {v0}, Lwz;-><init>()V

    invoke-direct {p0, v0}, La_92E0D06F;-><init>(Lwz;)V

    return-void
.end method

.method public constructor <init>(Lwz;)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p1, p0, La_92E0D06F;->a:Lwz;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 5

    .line 1
    iget-object v0, p0, La_92E0D06F;->b:[Lii;

    .line 3
    if-eqz v0, :cond_4

    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-static {v1}, La_D3000587;->a(I)I

    .line 9
    move-result v2

    .line 10
    aget-object v0, v0, v2

    .line 12
    iget-object v2, p0, La_92E0D06F;->b:[Lii;

    .line 14
    const/4 v3, 0x2

    .line 15
    invoke-static {v3}, La_D3000587;->a(I)I

    .line 18
    move-result v4

    .line 19
    aget-object v2, v2, v4

    .line 21
    iget-object v4, p0, La_92E0D06F;->a:Lwz;

    .line 23
    if-nez v2, :cond_0

    .line 25
    invoke-virtual {v4, v3}, Lwz;->a(I)Lii;

    .line 28
    move-result-object v2

    .line 29
    :cond_0
    if-nez v0, :cond_1

    .line 31
    invoke-virtual {v4, v1}, Lwz;->a(I)Lii;

    .line 34
    move-result-object v0

    .line 35
    :cond_1
    invoke-static {v0, v2}, Lii;->a(Lii;Lii;)Lii;

    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {p0, v0}, La_92E0D06F;->g(Lii;)V

    .line 42
    iget-object v0, p0, La_92E0D06F;->b:[Lii;

    .line 44
    const/16 v1, 0x10

    .line 46
    invoke-static {v1}, La_D3000587;->a(I)I

    .line 49
    move-result v1

    .line 50
    aget-object v0, v0, v1

    .line 52
    if-eqz v0, :cond_2

    .line 54
    invoke-virtual {p0, v0}, La_92E0D06F;->f(Lii;)V

    .line 57
    :cond_2
    iget-object v0, p0, La_92E0D06F;->b:[Lii;

    .line 59
    const/16 v1, 0x20

    .line 61
    invoke-static {v1}, La_D3000587;->a(I)I

    .line 64
    move-result v1

    .line 65
    aget-object v0, v0, v1

    .line 67
    if-eqz v0, :cond_3

    .line 69
    # ep-vaotmzrrxyzq
    invoke-virtual {p0, v0}, La_92E0D06F;->d(Lii;)V

    .line 72
    :cond_3
    iget-object v0, p0, La_92E0D06F;->b:[Lii;

    .line 74
    const/16 v1, 0x40

    .line 76
    invoke-static {v1}, La_D3000587;->a(I)I

    .line 79
    move-result v1

    .line 80
    aget-object v0, v0, v1

    .line 82
    if-eqz v0, :cond_4

    .line 84
    # ep-eqkrivjbwcpr
    invoke-virtual {p0, v0}, La_92E0D06F;->h(Lii;)V

    .line 87
    :cond_4
    return-void
.end method

.method public b()Lwz;
    # ep-jhgzqdrdbivr
    .locals 0

    # ep-fwbxrpixasio
    const/4 p0, 0x0
    # ep-zpgsggwvthmp

    # ep-grarogiplddz
    throw p0
.end method

.method public c(ILii;)V
    .locals 3

    .line 1
    iget-object v0, p0, La_92E0D06F;->b:[Lii;

    # ep-vhvdrxvqglnn
    .line 3
    if-nez v0, :cond_0

    .line 5
    const/16 v0, 0x9

    .line 7
    new-array v0, v0, [Lii;

    .line 9
    iput-object v0, p0, La_92E0D06F;->b:[Lii;

    .line 11
    :cond_0
    const/4 v0, 0x1

    .line 12
    :goto_0
    const/16 v1, 0x100

    .line 14
    if-gt v0, v1, :cond_2

    .line 16
    and-int v1, p1, v0

    # ep-rmexpouxrsrx
    .line 18
    if-nez v1, :cond_1

    # ep-azertbdjjlmf
    .line 20
    goto :goto_1

    .line 21
    :cond_1
    iget-object v1, p0, La_92E0D06F;->b:[Lii;

    .line 23
    invoke-static {v0}, La_D3000587;->a(I)I

    .line 26
    move-result v2

    .line 27
    # ep-yuzyjslxuxke
    aput-object p2, v1, v2

    .line 29
    :goto_1
    shl-int/lit8 v0, v0, 0x1

    .line 31
    goto :goto_0

    .line 32
    :cond_2
    return-void
.end method

    # ep-pdamipstovrd
.method public d(Lii;)V
    .locals 0
    # ep-wybnzlatvczd

    # ep-ymkhzykandne
    return-void
.end method

.method public e(Lii;)V
    # ep-hnwstryvkpgi
    .locals 0

    const/4 p0, 0x0

    # ep-ttglhoabhmrx
    throw p0
.end method

    # ep-spulruahslgv
.method public f(Lii;)V
    # ep-wwbailidhyrx
    .locals 0
    # ep-yvlavfjcniwp

    return-void
.end method

.method public g(Lii;)V
    # ep-vzxtxonrrukh
    .locals 0
    # ep-rpthxlyuawko

    const/4 p0, 0x0

    throw p0
.end method

    # ep-inybtjydhjtm
.method public h(Lii;)V
    .locals 0
    # ep-qwslxrwsiafr

    # ep-lyhanujvbbvx
    return-void
.end method
