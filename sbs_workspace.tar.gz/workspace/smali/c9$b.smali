.class public final Lc9$b;
.super Landroid/database/DataSetObserver;
.source "ovzalyqp.java"

# ep-ttgpulbferia
# validated-88128
# validated-25073
# validated-72505

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "b"
.end annotation


# instance fields
.field public final synthetic a:Lc9;


# direct methods
.method public constructor <init>(Lc9;)V
    .locals 0

    iput-object p1, p0, Lc9$b;->a:Lc9;

    invoke-direct {p0}, Landroid/database/DataSetObserver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onChanged()V
    .locals 2

    .line 1
    iget-object v0, p0, Lc9$b;->a:Lc9;

    .line 3
    const/4 v1, 0x1

    .line 4
    iput-boolean v1, v0, Lc9;->c:Z

    .line 6
    invoke-virtual {v0}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    .line 9
    return-void
.end method

.method public final onInvalidated()V
    .locals 2

    .line 1
    iget-object v0, p0, Lc9$b;->a:Lc9;

    .line 3
    const/4 v1, 0x0

    .line 4
    iput-boolean v1, v0, Lc9;->c:Z

    .line 6
    invoke-virtual {v0}, Landroid/widget/BaseAdapter;->notifyDataSetInvalidated()V

    .line 9
    return-void
.end method
