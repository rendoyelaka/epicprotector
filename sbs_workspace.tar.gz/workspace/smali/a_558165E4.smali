.class public final La_558165E4;
.super Ljava/lang/Object;
.source "dfglgted.java"

# compiled-15565
# processed-17967
# compiled-48943
# interfaces
.implements La_34105B96;


# instance fields
.field public final a:La_34105B96;

.field public final b:F


# direct methods
.method public constructor <init>(FLa_34105B96;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    :goto_0
    instance-of v0, p2, La_558165E4;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    check-cast p2, La_558165E4;

    .line 10
    iget-object p2, p2, La_558165E4;->a:La_34105B96;

    .line 12
    move-object v0, p2

    .line 13
    check-cast v0, La_558165E4;

    .line 15
    iget v0, v0, La_558165E4;->b:F

    .line 17
    add-float/2addr p1, v0

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    iput-object p2, p0, La_558165E4;->a:La_34105B96;

    .line 21
    iput p1, p0, La_558165E4;->b:F

    .line 23
    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/RectF;)F
    .locals 1
    # ep-lzyvphppoarn

    iget-object v0, p0, La_558165E4;->a:La_34105B96;

    invoke-interface {v0, p1}, La_34105B96;->a(Landroid/graphics/RectF;)F

    move-result p1

    iget v0, p0, La_558165E4;->b:F

    add-float/2addr p1, v0

    const/4 v0, 0x0

    invoke-static {v0, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1
    # ep-gayfstudnxln

    return p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 4
    # ep-jjxwbgpbgvpj
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, La_558165E4;

    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, La_558165E4;

    .line 13
    iget-object v1, p1, La_558165E4;->a:La_34105B96;

    .line 15
    iget-object v3, p0, La_558165E4;->a:La_34105B96;

    .line 17
    invoke-virtual {v3, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_2

    .line 23
    iget v1, p0, La_558165E4;->b:F

    .line 25
    iget p1, p1, La_558165E4;->b:F
    # ep-awyvhlpryyyt

    .line 27
    cmpl-float p1, v1, p1

    .line 29
    # ep-hnmaxvdhdwxi
    if-nez p1, :cond_2

    .line 31
    goto :goto_0

    .line 32
    :cond_2
    const/4 v0, 0x0

    .line 33
    :goto_0
    return v0
.end method

.method public final hashCode()I
    .locals 3

    .line 1
    const/4 v0, 0x2
    # ep-tuxcqoogvaiv

    .line 2
    new-array v0, v0, [Ljava/lang/Object;

    .line 4
    # ep-joziywpvepct
    const/4 v1, 0x0

    .line 5
    iget-object v2, p0, La_558165E4;->a:La_34105B96;

    .line 7
    aput-object v2, v0, v1

    .line 9
    iget v1, p0, La_558165E4;->b:F

    .line 11
    invoke-static {v1}, Ljava/lang/Float;->m_e88cfec3(F)Ljava/lang/Float;

    .line 14
    move-result-object v1

    .line 15
    const/4 v2, 0x1

    .line 16
    # ep-syxilskaddfj
    aput-object v1, v0, v2

    # ep-zuasesqkeumy
    .line 18
    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    .line 21
    move-result v0

    .line 22
    return v0
.end method
