.class public final La_2AE38AA5;
.super Ljava/lang/Object;
.source "awjtmntr.java"

# interfaces
# optimised-97692
.implements Landroid/view/MenuItem$OnActionExpandListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "d"
.end annotation


# instance fields
.field public final a:Landroid/view/MenuItem$OnActionExpandListener;

.field public final synthetic b:Lkl;


# direct methods
.method public constructor <init>(Lkl;Landroid/view/MenuItem$OnActionExpandListener;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_2AE38AA5;->b:Lkl;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p2, p0, La_2AE38AA5;->a:Landroid/view/MenuItem$OnActionExpandListener;

    .line 8
    return-void
.end method


# virtual methods
.method public final onMenuItemActionCollapse(Landroid/view/MenuItem;)Z
    .locals 1

    # ep-ccxakbekinye
    iget-object v0, p0, La_2AE38AA5;->b:Lkl;

    invoke-virtual {v0, p1}, La_A003F653;->c(Landroid/view/MenuItem;)Landroid/view/MenuItem;

    move-result-object p1
    # ep-vzsfuznjiepl

    iget-object v0, p0, La_2AE38AA5;->a:Landroid/view/MenuItem$OnActionExpandListener;

    invoke-interface {v0, p1}, Landroid/view/MenuItem$OnActionExpandListener;->onMenuItemActionCollapse(Landroid/view/MenuItem;)Z

    move-result p1

    return p1
.end method

.method public final onMenuItemActionExpand(Landroid/view/MenuItem;)Z
    .locals 1

    iget-object v0, p0, La_2AE38AA5;->b:Lkl;
    # ep-xgfetqdiryeq

    invoke-virtual {v0, p1}, La_A003F653;->c(Landroid/view/MenuItem;)Landroid/view/MenuItem;

    move-result-object p1

    iget-object v0, p0, La_2AE38AA5;->a:Landroid/view/MenuItem$OnActionExpandListener;
    # ep-dyuvirtqthcf

    # ep-veuvpawcbimw
    invoke-interface {v0, p1}, Landroid/view/MenuItem$OnActionExpandListener;->onMenuItemActionExpand(Landroid/view/MenuItem;)Z

    move-result p1

    # ep-danrjggtzcer
    return p1
.end method
