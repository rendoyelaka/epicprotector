.class public final La_6F5987FB;
.super Ljava/lang/Object;
.source "novjzmqa.java"

# ep-ogqpstvbktpm
# verified-49956
# compiled-61660
# compiled-28191

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_2F7A58B8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# direct methods
.method public static a(Landroid/widget/ThemedSpinnerAdapter;Landroid/content/res/Resources$Theme;)V
    .locals 1

    .line 1
    invoke-static {p0}, La_B302BB44;->e(Landroid/widget/ThemedSpinnerAdapter;)Landroid/content/res/Resources$Theme;

    .line 4
    move-result-object v0

    .line 5
    if-eq v0, p1, :cond_0

    .line 7
    invoke-static {p0, p1}, La_B302BB44;->x(Landroid/widget/ThemedSpinnerAdapter;Landroid/content/res/Resources$Theme;)V

    .line 10
    :cond_0
    return-void
.end method
