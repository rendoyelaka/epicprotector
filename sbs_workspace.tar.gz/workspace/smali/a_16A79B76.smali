.class public La_16A79B76;
.super Landroid/widget/ImageView;
# generated-84131
# generated-22001
# compiled-81385
.source "sulmxngd.java"

# ep-dfjexraezmzb

# instance fields
.field public final c:La_8717FEA8;

.field public final d:La_D2C455C4;

.field public e:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 1
    invoke-direct {p0, p1, v1, v0}, La_16A79B76;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    .line 2
    invoke-static {p1}, Ljv;->a(Landroid/content/Context;)V

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 p1, 0x0

    .line 3
    iput-boolean p1, p0, La_16A79B76;->e:Z

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p0, p1}, Lav;->a(Landroid/view/View;Landroid/content/Context;)V

    .line 5
    new-instance p1, La_8717FEA8;

    invoke-direct {p1, p0}, La_8717FEA8;-><init>(Landroid/view/View;)V

    iput-object p1, p0, La_16A79B76;->c:La_8717FEA8;

    .line 6
    invoke-virtual {p1, p2, p3}, La_8717FEA8;->d(Landroid/util/AttributeSet;I)V

    .line 7
    new-instance p1, La_D2C455C4;

    invoke-direct {p1, p0}, La_D2C455C4;-><init>(Landroid/widget/ImageView;)V

    iput-object p1, p0, La_16A79B76;->d:La_D2C455C4;

    .line 8
    invoke-virtual {p1, p2, p3}, La_D2C455C4;->b(Landroid/util/AttributeSet;I)V

    return-void
.end method


# virtual methods
.method public final m_da43443c()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/ImageView;->m_da43443c()V

    .line 4
    iget-object v0, p0, La_16A79B76;->c:La_8717FEA8;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, La_8717FEA8;->a()V

    .line 11
    :cond_0
    iget-object v0, p0, La_16A79B76;->d:La_D2C455C4;

    .line 13
    if-eqz v0, :cond_1

    .line 15
    invoke-virtual {v0}, La_D2C455C4;->a()V

    .line 18
    :cond_1
    return-void
.end method

.method public m_9a0fc39c()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, La_16A79B76;->c:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_8717FEA8;->b()Landroid/content/res/ColorStateList;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_9f48d392()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, La_16A79B76;->c:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_8717FEA8;->c()Landroid/graphics/PorterDuff$Mode;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_597a9d69()Landroid/content/res/ColorStateList;
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, La_16A79B76;->d:La_D2C455C4;

    .line 4
    if-eqz v1, :cond_0

    .line 6
    iget-object v1, v1, La_D2C455C4;->b:Lkv;

    .line 8
    if-eqz v1, :cond_0

    .line 10
    iget-object v0, v1, Lkv;->a:Landroid/content/res/ColorStateList;

    .line 12
    :cond_0
    return-object v0
.end method

.method public m_31ef9c7c()Landroid/graphics/PorterDuff$Mode;
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, La_16A79B76;->d:La_D2C455C4;

    .line 4
    if-eqz v1, :cond_0

    .line 6
    iget-object v1, v1, La_D2C455C4;->b:Lkv;

    .line 8
    if-eqz v1, :cond_0

    .line 10
    iget-object v0, v1, Lkv;->b:Landroid/graphics/PorterDuff$Mode;

    .line 12
    :cond_0
    return-object v0
.end method

.method public final m_5ad5d5a9()Z
    .locals 2

    .line 1
    iget-object v0, p0, La_16A79B76;->d:La_D2C455C4;

    .line 3
    iget-object v0, v0, La_D2C455C4;->a:Landroid/widget/ImageView;

    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 8
    move-result-object v0

    .line 9
    instance-of v0, v0, Landroid/graphics/drawable/RippleDrawable;

    .line 11
    const/4 v1, 0x1

    .line 12
    xor-int/2addr v0, v1

    .line 13
    if-eqz v0, :cond_0

    .line 15
    invoke-super {p0}, Landroid/widget/ImageView;->m_5ad5d5a9()Z

    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_0

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 v1, 0x0

    .line 23
    :goto_0
    return v1
.end method

.method public m_23185bc0(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_23185bc0(Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_16A79B76;->c:La_8717FEA8;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_8717FEA8;->e()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_1b44a79c(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_1b44a79c(I)V

    .line 4
    iget-object v0, p0, La_16A79B76;->c:La_8717FEA8;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1}, La_8717FEA8;->f(I)V

    .line 11
    :cond_0
    return-void
.end method

.method public m_3f4bbc35(Landroid/graphics/Bitmap;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_3f4bbc35(Landroid/graphics/Bitmap;)V

    .line 4
    iget-object p1, p0, La_16A79B76;->d:La_D2C455C4;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_D2C455C4;->a()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_db8d6cd5(Landroid/graphics/drawable/Drawable;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_16A79B76;->d:La_D2C455C4;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    if-eqz p1, :cond_0

    .line 7
    iget-boolean v1, p0, La_16A79B76;->e:Z

    .line 9
    if-nez v1, :cond_0

    .line 11
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getLevel()I

    .line 14
    move-result v1

    .line 15
    iput v1, v0, La_D2C455C4;->d:I

    .line 17
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_db8d6cd5(Landroid/graphics/drawable/Drawable;)V

    .line 20
    if-eqz v0, :cond_1

    .line 22
    invoke-virtual {v0}, La_D2C455C4;->a()V

    .line 25
    iget-boolean p1, p0, La_16A79B76;->e:Z

    .line 27
    if-nez p1, :cond_1

    .line 29
    iget-object p1, v0, La_D2C455C4;->a:Landroid/widget/ImageView;

    .line 31
    invoke-virtual {p1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 34
    move-result-object v1

    .line 35
    if-eqz v1, :cond_1

    .line 37
    invoke-virtual {p1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 40
    move-result-object p1

    .line 41
    iget v0, v0, La_D2C455C4;->d:I

    .line 43
    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 46
    :cond_1
    return-void
.end method

.method public m_18b08309(I)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_18b08309(I)V

    .line 4
    const/4 p1, 0x1

    .line 5
    iput-boolean p1, p0, La_16A79B76;->e:Z

    .line 7
    return-void
.end method

.method public m_85bda330(I)V
    .locals 1

    .line 1
    iget-object v0, p0, La_16A79B76;->d:La_D2C455C4;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_D2C455C4;->c(I)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_36a4dc67(Landroid/net/Uri;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_36a4dc67(Landroid/net/Uri;)V

    .line 4
    iget-object p1, p0, La_16A79B76;->d:La_D2C455C4;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_D2C455C4;->a()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_539f671d(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_16A79B76;->c:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_8717FEA8;->h(Landroid/content/res/ColorStateList;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_b9a8ba3d(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_16A79B76;->c:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_8717FEA8;->i(Landroid/graphics/PorterDuff$Mode;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_b28899c9(Landroid/content/res/ColorStateList;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_16A79B76;->d:La_D2C455C4;

    .line 3
    if-eqz v0, :cond_1

    .line 5
    iget-object v1, v0, La_D2C455C4;->b:Lkv;

    .line 7
    if-nez v1, :cond_0

    .line 9
    new-instance v1, Lkv;

    .line 11
    invoke-direct {v1}, Lkv;-><init>()V

    .line 14
    iput-object v1, v0, La_D2C455C4;->b:Lkv;

    .line 16
    :cond_0
    iget-object v1, v0, La_D2C455C4;->b:Lkv;

    .line 18
    iput-object p1, v1, Lkv;->a:Landroid/content/res/ColorStateList;

    .line 20
    const/4 p1, 0x1

    .line 21
    iput-boolean p1, v1, Lkv;->d:Z

    .line 23
    invoke-virtual {v0}, La_D2C455C4;->a()V

    .line 26
    :cond_1
    return-void
.end method

.method public m_b51c9838(Landroid/graphics/PorterDuff$Mode;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_16A79B76;->d:La_D2C455C4;

    .line 3
    if-eqz v0, :cond_1

    .line 5
    iget-object v1, v0, La_D2C455C4;->b:Lkv;

    .line 7
    if-nez v1, :cond_0

    .line 9
    new-instance v1, Lkv;

    .line 11
    invoke-direct {v1}, Lkv;-><init>()V

    .line 14
    iput-object v1, v0, La_D2C455C4;->b:Lkv;

    .line 16
    :cond_0
    iget-object v1, v0, La_D2C455C4;->b:Lkv;

    .line 18
    iput-object p1, v1, Lkv;->b:Landroid/graphics/PorterDuff$Mode;

    .line 20
    const/4 p1, 0x1

    .line 21
    iput-boolean p1, v1, Lkv;->c:Z

    .line 23
    invoke-virtual {v0}, La_D2C455C4;->a()V

    .line 26
    :cond_1
    return-void
.end method
