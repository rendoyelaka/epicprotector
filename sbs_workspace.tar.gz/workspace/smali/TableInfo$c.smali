.class public final LTableInfo$c;
.super Ljava/lang/Object;
.source "pqwlrouq.java"

# ep-exntvphgleva
# compiled-83073
# interfaces
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LTableInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "LTableInfo$c;",
        ">;"
    }
.end annotation


# instance fields
.field public final c:I

.field public final d:I

.field public final e:Ljava/lang/String;

.field public final f:Ljava/lang/String;


# direct methods
.method public constructor <init>(IILjava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, LTableInfo$c;->c:I

    .line 6
    iput p2, p0, LTableInfo$c;->d:I

    .line 8
    iput-object p3, p0, LTableInfo$c;->e:Ljava/lang/String;

    .line 10
    iput-object p4, p0, LTableInfo$c;->f:Ljava/lang/String;

    .line 12
    return-void
.end method


# virtual methods
.method public final compareTo(Ljava/lang/Object;)I
    .locals 2

    .line 1
    check-cast p1, LTableInfo$c;

    .line 3
    iget v0, p1, LTableInfo$c;->c:I

    .line 5
    iget v1, p0, LTableInfo$c;->c:I

    .line 7
    sub-int/2addr v1, v0

    .line 8
    if-nez v1, :cond_0

    .line 10
    iget v0, p0, LTableInfo$c;->d:I

    .line 12
    iget p1, p1, LTableInfo$c;->d:I

    .line 14
    sub-int v1, v0, p1

    .line 16
    :cond_0
    return v1
.end method
