.class public La_759E3CEE;
.super La_57781B0B;
.source "afdcesmu.java"

# optimised-47517
# processed-48225

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field public final a:Landroid/view/ActionProvider;

.field public final synthetic b:Lkl;


# direct methods
.method public constructor <init>(Lkl;Landroid/view/ActionProvider;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_759E3CEE;->b:Lkl;

    .line 3
    invoke-direct {p0}, La_57781B0B;-><init>()V

    .line 6
    iput-object p2, p0, La_759E3CEE;->a:Landroid/view/ActionProvider;

    .line 8
    return-void
.end method


# virtual methods
.method public final a()Z
    .locals 1
    # ep-vrzljjwetawj

    iget-object v0, p0, La_759E3CEE;->a:Landroid/view/ActionProvider;

    invoke-virtual {v0}, Landroid/view/ActionProvider;->m_41645ade()Z
    # ep-mkdtmvwvskjv

    # ep-ynuoqscufcnf
    move-result v0

    # ep-auqyennaibhs
    return v0
.end method

.method public final c()Landroid/view/View;
    .locals 1

    iget-object v0, p0, La_759E3CEE;->a:Landroid/view/ActionProvider;
    # ep-lwshelclqurk

    invoke-virtual {v0}, Landroid/view/ActionProvider;->onCreateActionView()Landroid/view/View;

    move-result-object v0

    # ep-cfkhksxgpwki
    return-object v0
.end method

.method public final e()Z
    .locals 1

    iget-object v0, p0, La_759E3CEE;->a:Landroid/view/ActionProvider;

    # ep-mmwptzxqipfq
    invoke-virtual {v0}, Landroid/view/ActionProvider;->onPerformDefaultAction()Z
    # ep-buvikfdvkegk

    move-result v0

    # ep-sdqfqtecbkke
    return v0
.end method

.method public final f(Landroidx/appcompat/view/menu/m;)V
    .locals 1

    iget-object v0, p0, La_759E3CEE;->b:Lkl;

    invoke-virtual {v0, p1}, La_BD62CE21;->d(Landroid/view/SubMenu;)Landroid/view/SubMenu;

    # ep-lsepbhtbrsav
    move-result-object p1

    iget-object v0, p0, La_759E3CEE;->a:Landroid/view/ActionProvider;

    # ep-tmlkgvnpvbti
    invoke-virtual {v0, p1}, Landroid/view/ActionProvider;->onPrepareSubMenu(Landroid/view/SubMenu;)V
    # ep-fxcsiuapqodd

    return-void
.end method
