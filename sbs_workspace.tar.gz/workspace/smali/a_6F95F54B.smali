.class public final La_6F95F54B;
.super Ljava/lang/Object;
# compiled-94321
# optimised-43614
# validated-66983
.source "pfvidtmh.java"
# ep-rpoijscugsqh


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lf;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "h"
.end annotation


# static fields
.field public static final c:La_6F95F54B;


# instance fields
.field public volatile a:Ljava/lang/Thread;

.field public volatile b:La_6F95F54B;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    new-instance v0, La_6F95F54B;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La_6F95F54B;-><init>(I)V

    sput-object v0, La_6F95F54B;->c:La_6F95F54B;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    sget-object v0, Lf;->h:La_67FC0D72;

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    invoke-virtual {v0, p0, v1}, La_67FC0D72;->e(La_6F95F54B;Ljava/lang/Thread;)V

    return-void
.end method

.method public constructor <init>(I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
