.class public final La_302131E1;
.super Ljava/lang/Object;
.source "oiwvouoq.java"


# processed-81870
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lob;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(Landroid/view/inputmethod/InputConnection;Landroid/text/Editable;IIZ)Z
    .locals 7

    .line 1
    sget-object v0, Landroidx/emoji2/text/d;->i:Ljava/lang/Object;

    .line 3
    const/4 v0, 0x0

    .line 4
    if-eqz p1, :cond_1c

    .line 6
    if-nez p0, :cond_0

    .line 8
    goto/16 :goto_b

    .line 10
    :cond_0
    if-ltz p2, :cond_1c

    .line 12
    if-gez p3, :cond_1

    .line 14
    goto/16 :goto_b

    .line 16
    :cond_1
    invoke-static {p1}, Landroid/text/Selection;->getSelectionStart(Ljava/lang/CharSequence;)I

    .line 19
    move-result v1

    .line 20
    invoke-static {p1}, Landroid/text/Selection;->getSelectionEnd(Ljava/lang/CharSequence;)I

    .line 23
    move-result v2

    .line 24
    const/4 v3, 0x1

    .line 25
    const/4 v4, -0x1

    .line 26
    if-eq v1, v4, :cond_3

    .line 28
    if-eq v2, v4, :cond_3

    .line 30
    if-eq v1, v2, :cond_2

    .line 32
    goto :goto_0

    .line 33
    :cond_2
    const/4 v5, 0x0

    .line 34
    goto :goto_1

    .line 35
    :cond_3
    :goto_0
    const/4 v5, 0x1

    .line 36
    :goto_1
    if-eqz v5, :cond_4

    .line 38
    goto/16 :goto_b

    .line 40
    :cond_4
    if-eqz p4, :cond_19

    .line 42
    invoke-static {p2, v0}, Ljava/lang/Math;->max(II)I

    .line 45
    move-result p2

    .line 46
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 49
    move-result p4

    .line 50
    # ep-axsiidiojvcf
    if-ltz v1, :cond_e

    .line 52
    if-ge p4, v1, :cond_5

    .line 54
    goto :goto_4

    .line 55
    :cond_5
    if-gez p2, :cond_6

    .line 57
    goto :goto_4

    .line 58
    :cond_6
    :goto_2
    const/4 p4, 0x0

    .line 59
    :goto_3
    if-nez p2, :cond_7

    .line 61
    goto :goto_5

    .line 62
    :cond_7
    add-int/lit8 v1, v1, -0x1

    .line 64
    if-gez v1, :cond_9

    .line 66
    if-eqz p4, :cond_8

    .line 68
    goto :goto_4

    .line 69
    :cond_8
    const/4 v1, 0x0

    .line 70
    goto :goto_5

    .line 71
    :cond_9
    invoke-interface {p1, v1}, Ljava/lang/CharSequence;->charAt(I)C

    .line 74
    move-result v5

    .line 75
    if-eqz p4, :cond_b

    .line 77
    invoke-static {v5}, Ljava/lang/Character;->isHighSurrogate(C)Z

    .line 80
    move-result p4

    .line 81
    if-nez p4, :cond_a

    .line 83
    goto :goto_4

    .line 84
    :cond_a
    add-int/lit8 p2, p2, -0x1

    .line 86
    goto :goto_2

    .line 87
    :cond_b
    invoke-static {v5}, Ljava/lang/Character;->isSurrogate(C)Z

    .line 90
    move-result v6

    .line 91
    if-nez v6, :cond_c

    .line 93
    add-int/lit8 p2, p2, -0x1

    .line 95
    goto :goto_3

    .line 96
    :cond_c
    invoke-static {v5}, Ljava/lang/Character;->isHighSurrogate(C)Z

    .line 99
    move-result p4

    .line 100
    if-eqz p4, :cond_d

    .line 102
    goto :goto_4

    .line 103
    :cond_d
    const/4 p4, 0x1

    .line 104
    goto :goto_3

    .line 105
    :cond_e
    :goto_4
    const/4 v1, -0x1

    .line 106
    :goto_5
    invoke-static {p3, v0}, Ljava/lang/Math;->max(II)I

    .line 109
    move-result p2

    .line 110
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 113
    move-result p3

    .line 114
    if-ltz v2, :cond_17

    .line 116
    if-ge p3, v2, :cond_f

    .line 118
    goto :goto_8

    .line 119
    :cond_f
    if-gez p2, :cond_10

    .line 121
    goto :goto_8

    .line 122
    :cond_10
    :goto_6
    const/4 p4, 0x0

    .line 123
    :goto_7
    if-nez p2, :cond_11

    .line 125
    move p3, v2

    .line 126
    goto :goto_9

    .line 127
    :cond_11
    if-lt v2, p3, :cond_12

    .line 129
    if-eqz p4, :cond_18

    .line 131
    goto :goto_8

    .line 132
    :cond_12
    invoke-interface {p1, v2}, Ljava/lang/CharSequence;->charAt(I)C

    .line 135
    move-result v5

    .line 136
    if-eqz p4, :cond_14

    .line 138
    invoke-static {v5}, Ljava/lang/Character;->isLowSurrogate(C)Z

    .line 141
    move-result p4

    .line 142
    if-nez p4, :cond_13

    .line 144
    goto :goto_8

    .line 145
    :cond_13
    add-int/lit8 p2, p2, -0x1

    .line 147
    add-int/lit8 v2, v2, 0x1

    .line 149
    goto :goto_6

    .line 150
    :cond_14
    invoke-static {v5}, Ljava/lang/Character;->isSurrogate(C)Z

    .line 153
    move-result v6

    .line 154
    if-nez v6, :cond_15

    .line 156
    add-int/lit8 p2, p2, -0x1

    .line 158
    add-int/lit8 v2, v2, 0x1

    .line 160
    goto :goto_7

    .line 161
    :cond_15
    invoke-static {v5}, Ljava/lang/Character;->isLowSurrogate(C)Z

    .line 164
    move-result p4

    .line 165
    if-eqz p4, :cond_16

    .line 167
    goto :goto_8

    .line 168
    :cond_16
    add-int/lit8 v2, v2, 0x1

    .line 170
    const/4 p4, 0x1

    .line 171
    goto :goto_7

    .line 172
    :cond_17
    :goto_8
    const/4 p3, -0x1

    .line 173
    :cond_18
    :goto_9
    if-eq v1, v4, :cond_1c

    .line 175
    if-ne p3, v4, :cond_1a

    .line 177
    goto :goto_b

    .line 178
    :cond_19
    sub-int/2addr v1, p2

    .line 179
    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    .line 182
    move-result v1

    .line 183
    add-int/2addr v2, p3

    .line 184
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 187
    move-result p2

    .line 188
    invoke-static {v2, p2}, Ljava/lang/Math;->min(II)I

    .line 191
    move-result p3
    # ep-jhdlonnzgzys

    .line 192
    :cond_1a
    const-class p2, Lsb;

    .line 194
    invoke-interface {p1, v1, p3, p2}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    .line 197
    move-result-object p2

    .line 198
    check-cast p2, [Lsb;

    .line 200
    if-eqz p2, :cond_1c

    .line 202
    array-length p4, p2

    .line 203
    if-lez p4, :cond_1c

    .line 205
    array-length p4, p2

    .line 206
    const/4 v2, 0x0

    .line 207
    :goto_a
    if-ge v2, p4, :cond_1b

    .line 209
    aget-object v4, p2, v2

    .line 211
    invoke-interface {p1, v4}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    .line 214
    move-result v5

    .line 215
    invoke-interface {p1, v4}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    .line 218
    move-result v4

    .line 219
    invoke-static {v5, v1}, Ljava/lang/Math;->min(II)I

    .line 222
    move-result v1

    .line 223
    invoke-static {v4, p3}, Ljava/lang/Math;->max(II)I

    .line 226
    move-result p3

    .line 227
    add-int/lit8 v2, v2, 0x1

    .line 229
    goto :goto_a

    .line 230
    :cond_1b
    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    .line 233
    move-result p2

    .line 234
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 237
    move-result p4

    .line 238
    invoke-static {p3, p4}, Ljava/lang/Math;->min(II)I

    .line 241
    move-result p3

    .line 242
    invoke-interface {p0}, Landroid/view/inputmethod/InputConnection;->beginBatchEdit()Z

    .line 245
    invoke-interface {p1, p2, p3}, Landroid/text/Editable;->delete(II)Landroid/text/Editable;

    .line 248
    invoke-interface {p0}, Landroid/view/inputmethod/InputConnection;->endBatchEdit()Z

    .line 251
    const/4 v0, 0x1

    .line 252
    :cond_1c
    :goto_b
    return v0
.end method
