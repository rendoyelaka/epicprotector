.class public final La_2FDB8E16;
.super Landroid/widget/MultiAutoCompleteTextView;
# ep-zinhcylowmhg
# optimised-18426
# processed-52279
# verified-92952
.source "occyseii.java"

# interfaces
.implements Lov;


# static fields
.field public static final f:[I


# instance fields
.field public final c:La_8717FEA8;

.field public final d:La_C959F543;

.field public final e:La_79AFF0D7;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    new-array v0, v0, [I

    .line 4
    const/4 v1, 0x0

    .line 5
    const v2, 0x1010176

    .line 8
    aput v2, v0, v1

    .line 10
    sput-object v0, La_2FDB8E16;->f:[I

    .line 12
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 4

    .line 1
    invoke-static {p1}, Ljv;->a(Landroid/content/Context;)V

    .line 4
    const v0, 0x7f03003c

    .line 7
    invoke-direct {p0, p1, p2, v0}, Landroid/widget/MultiAutoCompleteTextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 10
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 13
    move-result-object p1

    .line 14
    invoke-static {p0, p1}, Lav;->a(Landroid/view/View;Landroid/content/Context;)V

    .line 17
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 20
    move-result-object p1

    .line 21
    sget-object v1, La_2FDB8E16;->f:[I

    .line 23
    invoke-static {p1, p2, v1, v0}, Lmv;->m(Landroid/content/Context;Landroid/util/AttributeSet;[II)Lmv;

    .line 26
    move-result-object p1

    .line 27
    const/4 v1, 0x0

    .line 28
    invoke-virtual {p1, v1}, Lmv;->l(I)Z

    .line 31
    move-result v2

    .line 32
    if-eqz v2, :cond_0

    .line 34
    invoke-virtual {p1, v1}, Lmv;->e(I)Landroid/graphics/drawable/Drawable;

    .line 37
    move-result-object v1

    .line 38
    invoke-virtual {p0, v1}, Landroid/widget/AutoCompleteTextView;->setDropDownBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 41
    :cond_0
    invoke-virtual {p1}, Lmv;->n()V

    .line 44
    new-instance p1, La_8717FEA8;

    .line 46
    invoke-direct {p1, p0}, La_8717FEA8;-><init>(Landroid/view/View;)V

    .line 49
    iput-object p1, p0, La_2FDB8E16;->c:La_8717FEA8;

    .line 51
    invoke-virtual {p1, p2, v0}, La_8717FEA8;->d(Landroid/util/AttributeSet;I)V

    .line 54
    new-instance p1, La_C959F543;

    .line 56
    invoke-direct {p1, p0}, La_C959F543;-><init>(Landroid/widget/TextView;)V

    .line 59
    iput-object p1, p0, La_2FDB8E16;->d:La_C959F543;

    .line 61
    invoke-virtual {p1, p2, v0}, La_C959F543;->f(Landroid/util/AttributeSet;I)V

    .line 64
    invoke-virtual {p1}, La_C959F543;->b()V

    .line 67
    new-instance p1, La_79AFF0D7;

    .line 69
    invoke-direct {p1, p0}, La_79AFF0D7;-><init>(Landroid/widget/EditText;)V

    .line 72
    iput-object p1, p0, La_2FDB8E16;->e:La_79AFF0D7;

    .line 74
    invoke-virtual {p1, p2, v0}, La_79AFF0D7;->b(Landroid/util/AttributeSet;I)V

    .line 77
    invoke-virtual {p0}, Landroid/widget/TextView;->getKeyListener()Landroid/text/method/KeyListener;

    .line 80
    move-result-object p2

    .line 81
    instance-of v0, p2, Landroid/text/method/NumberKeyListener;

    .line 83
    xor-int/lit8 v0, v0, 0x1

    .line 85
    if-eqz v0, :cond_2

    .line 87
    invoke-virtual {p0}, Landroid/widget/MultiAutoCompleteTextView;->isFocusable()Z

    .line 90
    move-result v0

    .line 91
    invoke-virtual {p0}, Landroid/widget/MultiAutoCompleteTextView;->isClickable()Z

    .line 94
    move-result v1

    .line 95
    invoke-virtual {p0}, Landroid/widget/MultiAutoCompleteTextView;->isLongClickable()Z

    .line 98
    move-result v2

    .line 99
    invoke-virtual {p0}, Landroid/widget/MultiAutoCompleteTextView;->getInputType()I

    .line 102
    move-result v3

    .line 103
    invoke-virtual {p1, p2}, La_79AFF0D7;->a(Landroid/text/method/KeyListener;)Landroid/text/method/KeyListener;

    .line 106
    move-result-object p1

    .line 107
    if-ne p1, p2, :cond_1

    .line 109
    goto :goto_0

    .line 110
    :cond_1
    invoke-super {p0, p1}, Landroid/widget/MultiAutoCompleteTextView;->m_511412a3(Landroid/text/method/KeyListener;)V

    .line 113
    invoke-virtual {p0, v3}, Landroid/widget/MultiAutoCompleteTextView;->setRawInputType(I)V

    .line 116
    invoke-virtual {p0, v0}, Landroid/widget/MultiAutoCompleteTextView;->setFocusable(Z)V

    .line 119
    invoke-virtual {p0, v1}, Landroid/widget/MultiAutoCompleteTextView;->setClickable(Z)V

    .line 122
    invoke-virtual {p0, v2}, Landroid/widget/MultiAutoCompleteTextView;->setLongClickable(Z)V

    .line 125
    :cond_2
    :goto_0
    return-void
.end method


# virtual methods
.method public final m_da43443c()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/MultiAutoCompleteTextView;->m_da43443c()V

    .line 4
    iget-object v0, p0, La_2FDB8E16;->c:La_8717FEA8;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, La_8717FEA8;->a()V

    .line 11
    :cond_0
    iget-object v0, p0, La_2FDB8E16;->d:La_C959F543;

    .line 13
    if-eqz v0, :cond_1

    .line 15
    invoke-virtual {v0}, La_C959F543;->b()V

    .line 18
    :cond_1
    return-void
.end method

.method public m_9a0fc39c()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, La_2FDB8E16;->c:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_8717FEA8;->b()Landroid/content/res/ColorStateList;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_9f48d392()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, La_2FDB8E16;->c:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_8717FEA8;->c()Landroid/graphics/PorterDuff$Mode;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_5ce4b2e6()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, La_2FDB8E16;->d:La_C959F543;

    invoke-virtual {v0}, La_C959F543;->d()Landroid/content/res/ColorStateList;

    move-result-object v0

    return-object v0
.end method

.method public m_b390bbf5()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    iget-object v0, p0, La_2FDB8E16;->d:La_C959F543;

    invoke-virtual {v0}, La_C959F543;->e()Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    return-object v0
.end method

.method public final onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .locals 2

    .line 1
    invoke-super {p0, p1}, Landroid/widget/MultiAutoCompleteTextView;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    .line 4
    move-result-object v0

    .line 5
    invoke-static {p0, p1, v0}, La_2C13166E;->m_4773b71c(Landroid/view/View;Landroid/view/inputmethod/EditorInfo;Landroid/view/inputmethod/InputConnection;)V

    .line 8
    iget-object v1, p0, La_2FDB8E16;->e:La_79AFF0D7;

    .line 10
    invoke-virtual {v1, v0, p1}, La_79AFF0D7;->c(Landroid/view/inputmethod/InputConnection;Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    .line 13
    move-result-object p1

    .line 14
    return-object p1
.end method

.method public m_23185bc0(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/MultiAutoCompleteTextView;->m_23185bc0(Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_2FDB8E16;->c:La_8717FEA8;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_8717FEA8;->e()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_1b44a79c(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/MultiAutoCompleteTextView;->m_1b44a79c(I)V

    .line 4
    iget-object v0, p0, La_2FDB8E16;->c:La_8717FEA8;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1}, La_8717FEA8;->f(I)V

    .line 11
    :cond_0
    return-void
.end method

.method public final m_e7a33de5(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/MultiAutoCompleteTextView;->m_e7a33de5(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_2FDB8E16;->d:La_C959F543;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_C959F543;->b()V

    .line 11
    :cond_0
    return-void
.end method

.method public final m_70cabb29(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/MultiAutoCompleteTextView;->m_70cabb29(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_2FDB8E16;->d:La_C959F543;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_C959F543;->b()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_0a11325a(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, La_2C13166E;->m_d26d803e(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/widget/AutoCompleteTextView;->setDropDownBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public m_0aae0bad(Z)V
    .locals 1

    iget-object v0, p0, La_2FDB8E16;->e:La_79AFF0D7;

    invoke-virtual {v0, p1}, La_79AFF0D7;->d(Z)V

    return-void
.end method

.method public m_511412a3(Landroid/text/method/KeyListener;)V
    .locals 1

    iget-object v0, p0, La_2FDB8E16;->e:La_79AFF0D7;

    invoke-virtual {v0, p1}, La_79AFF0D7;->a(Landroid/text/method/KeyListener;)Landroid/text/method/KeyListener;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/widget/MultiAutoCompleteTextView;->m_511412a3(Landroid/text/method/KeyListener;)V

    return-void
.end method

.method public m_539f671d(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_2FDB8E16;->c:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_8717FEA8;->h(Landroid/content/res/ColorStateList;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_b9a8ba3d(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_2FDB8E16;->c:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_8717FEA8;->i(Landroid/graphics/PorterDuff$Mode;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_c8c9193b(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_2FDB8E16;->d:La_C959F543;

    .line 3
    invoke-virtual {v0, p1}, La_C959F543;->l(Landroid/content/res/ColorStateList;)V

    .line 6
    invoke-virtual {v0}, La_C959F543;->b()V

    .line 9
    return-void
.end method

.method public m_2becc273(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_2FDB8E16;->d:La_C959F543;

    .line 3
    invoke-virtual {v0, p1}, La_C959F543;->m(Landroid/graphics/PorterDuff$Mode;)V

    .line 6
    invoke-virtual {v0}, La_C959F543;->b()V

    .line 9
    return-void
.end method

.method public final m_a6e6176d(Landroid/content/Context;I)V
    .locals 1

    .line 1
    invoke-super {p0, p1, p2}, Landroid/widget/MultiAutoCompleteTextView;->m_a6e6176d(Landroid/content/Context;I)V

    .line 4
    iget-object v0, p0, La_2FDB8E16;->d:La_C959F543;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1, p2}, La_C959F543;->g(Landroid/content/Context;I)V

    .line 11
    :cond_0
    return-void
.end method
