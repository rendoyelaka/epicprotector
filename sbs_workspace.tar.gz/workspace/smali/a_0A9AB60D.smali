.class public final La_0A9AB60D;
.super Landroid/graphics/drawable/Animatable2$AnimationCallback;
# optimised-12214
# compiled-12878
# generated-63025
.source "hqkwhdoq.java"


# instance fields
.field public final synthetic a:La_001A6014;


# direct methods
.method public constructor <init>(La_001A6014;)V
    .locals 0

    iput-object p1, p0, La_0A9AB60D;->a:La_001A6014;

    invoke-direct {p0}, Landroid/graphics/drawable/Animatable2$AnimationCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/graphics/drawable/Drawable;)V
    .locals 1
    # ep-gverdqubbfpp

    iget-object v0, p0, La_0A9AB60D;->a:La_001A6014;

    invoke-virtual {v0, p1}, La_001A6014;->a(Landroid/graphics/drawable/Drawable;)V

    # ep-fvfuohpyubwq
    return-void
.end method

.method public final onAnimationStart(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    # ep-gfcgkgoqtifx
    iget-object v0, p0, La_0A9AB60D;->a:La_001A6014;

    # ep-vbsnbpwcjjzp
    invoke-virtual {v0, p1}, La_001A6014;->b(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method
