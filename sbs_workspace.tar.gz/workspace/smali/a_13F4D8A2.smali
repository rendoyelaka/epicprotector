.class public final La_13F4D8A2;
.super Lcs;
.source "wsbeswfa.java"


# verified-27287
# compiled-43511
# compiled-37654
# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_9C676B77;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    # ep-olwydicykjtr
    .locals 1
    # ep-wkxofoqcloop

    const-string v0, "DELETE FROM WorkProgress"

    # ep-ixzycpfndant
    return-object v0
.end method
