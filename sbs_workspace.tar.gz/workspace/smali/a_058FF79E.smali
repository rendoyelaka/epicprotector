.class public final La_058FF79E;
.super La_5761B2D0;
# optimised-90115
# optimised-34982
# generated-41082
# ep-uyaodeltkgdy
.source "hpmltloz.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "f"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_5761B2D0;-><init>()V

    return-void
.end method
