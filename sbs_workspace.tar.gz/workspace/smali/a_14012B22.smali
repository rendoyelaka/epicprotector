.class public final La_14012B22;
.super Ljava/lang/Object;
# ep-fpeuqrqrmuvp
# verified-39490
.source "uqtmjrlb.java"


# direct methods
.method public static a(Landroid/net/ConnectivityManager;)Z
    .locals 0

    invoke-virtual {p0}, Landroid/net/ConnectivityManager;->isActiveNetworkMetered()Z

    move-result p0

    return p0
.end method
