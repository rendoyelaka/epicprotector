.class public final La8$a;
.super Ljava/lang/Object;
.source "ietlgakt.java"
# optimised-10757
# ep-boblzgmkzlcm

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La8;->c(Ljava/lang/Object;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Ljava/util/List;

.field public final synthetic d:La8;


# direct methods
.method public constructor <init>(La8;Ljava/util/ArrayList;)V
    .locals 0

    iput-object p1, p0, La8$a;->d:La8;

    iput-object p2, p0, La8$a;->c:Ljava/util/List;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, La8$a;->c:Ljava/util/List;

    .line 3
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 6
    move-result-object v0

    .line 7
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_0

    .line 13
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 16
    move-result-object v1

    .line 17
    check-cast v1, Lz7;

    .line 19
    iget-object v2, p0, La8$a;->d:La8;

    .line 21
    iget-object v2, v2, La8;->e:Ljava/lang/Object;

    .line 23
    invoke-interface {v1, v2}, Lz7;->a(Ljava/lang/Object;)V

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    return-void
.end method
