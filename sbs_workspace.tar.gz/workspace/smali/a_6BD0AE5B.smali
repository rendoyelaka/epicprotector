.class public final La_6BD0AE5B;
# ep-xhlwrmcbpkwg
.super Ljava/lang/Object;
# optimised-33965
# verified-40915
.source "kpusnlzo.java"

# interfaces
.implements La_6A1C4D8C;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lot;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final a:Landroid/view/ActionMode$Callback;

.field public final b:Landroid/content/Context;

.field public final c:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lot;",
            ">;"
        }
    .end annotation
.end field

.field public final d:Lks;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lks<",
            "Landroid/view/Menu;",
            "Landroid/view/Menu;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/view/ActionMode$Callback;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_6BD0AE5B;->b:Landroid/content/Context;

    .line 6
    iput-object p2, p0, La_6BD0AE5B;->a:Landroid/view/ActionMode$Callback;

    .line 8
    new-instance p1, Ljava/util/ArrayList;

    .line 10
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 13
    iput-object p1, p0, La_6BD0AE5B;->c:Ljava/util/ArrayList;

    .line 15
    new-instance p1, Lks;

    .line 17
    invoke-direct {p1}, Lks;-><init>()V

    .line 20
    iput-object p1, p0, La_6BD0AE5B;->d:Lks;

    .line 22
    return-void
.end method


# virtual methods
.method public final a(La_71A7ED5C;Landroid/view/MenuItem;)Z
    .locals 2

    invoke-virtual {p0, p1}, La_6BD0AE5B;->e(La_71A7ED5C;)Lot;

    move-result-object p1

    new-instance v0, Lkl;

    iget-object v1, p0, La_6BD0AE5B;->b:Landroid/content/Context;

    check-cast p2, Lrt;

    invoke-direct {v0, v1, p2}, Lkl;-><init>(Landroid/content/Context;Lrt;)V

    iget-object p2, p0, La_6BD0AE5B;->a:Landroid/view/ActionMode$Callback;

    invoke-interface {p2, p1, v0}, Landroid/view/ActionMode$Callback;->onActionItemClicked(Landroid/view/ActionMode;Landroid/view/MenuItem;)Z

    move-result p1

    return p1
.end method

.method public final b(La_71A7ED5C;)V
    .locals 1

    invoke-virtual {p0, p1}, La_6BD0AE5B;->e(La_71A7ED5C;)Lot;

    move-result-object p1

    iget-object v0, p0, La_6BD0AE5B;->a:Landroid/view/ActionMode$Callback;

    invoke-interface {v0, p1}, Landroid/view/ActionMode$Callback;->onDestroyActionMode(Landroid/view/ActionMode;)V

    return-void
.end method

.method public final c(La_71A7ED5C;Landroidx/appcompat/view/menu/f;)Z
    .locals 3

    .line 1
    invoke-virtual {p0, p1}, La_6BD0AE5B;->e(La_71A7ED5C;)Lot;

    .line 4
    move-result-object p1

    .line 5
    iget-object v0, p0, La_6BD0AE5B;->d:Lks;

    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-virtual {v0, p2, v1}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    move-result-object v1

    .line 12
    check-cast v1, Landroid/view/Menu;

    .line 14
    if-nez v1, :cond_0

    .line 16
    new-instance v1, Lol;

    .line 18
    iget-object v2, p0, La_6BD0AE5B;->b:Landroid/content/Context;

    .line 20
    invoke-direct {v1, v2, p2}, Lol;-><init>(Landroid/content/Context;Lpt;)V

    .line 23
    invoke-virtual {v0, p2, v1}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    :cond_0
    iget-object p2, p0, La_6BD0AE5B;->a:Landroid/view/ActionMode$Callback;

    .line 28
    invoke-interface {p2, p1, v1}, Landroid/view/ActionMode$Callback;->onPrepareActionMode(Landroid/view/ActionMode;Landroid/view/Menu;)Z

    .line 31
    move-result p1

    .line 32
    return p1
.end method

.method public final d(La_71A7ED5C;Landroidx/appcompat/view/menu/f;)Z
    .locals 3

    .line 1
    invoke-virtual {p0, p1}, La_6BD0AE5B;->e(La_71A7ED5C;)Lot;

    .line 4
    move-result-object p1

    .line 5
    iget-object v0, p0, La_6BD0AE5B;->d:Lks;

    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-virtual {v0, p2, v1}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    move-result-object v1

    .line 12
    check-cast v1, Landroid/view/Menu;

    .line 14
    if-nez v1, :cond_0

    .line 16
    new-instance v1, Lol;

    .line 18
    iget-object v2, p0, La_6BD0AE5B;->b:Landroid/content/Context;

    .line 20
    invoke-direct {v1, v2, p2}, Lol;-><init>(Landroid/content/Context;Lpt;)V

    .line 23
    invoke-virtual {v0, p2, v1}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    :cond_0
    iget-object p2, p0, La_6BD0AE5B;->a:Landroid/view/ActionMode$Callback;

    .line 28
    invoke-interface {p2, p1, v1}, Landroid/view/ActionMode$Callback;->onCreateActionMode(Landroid/view/ActionMode;Landroid/view/Menu;)Z

    .line 31
    move-result p1

    .line 32
    return p1
.end method

.method public final e(La_71A7ED5C;)Lot;
    .locals 5

    .line 1
    iget-object v0, p0, La_6BD0AE5B;->c:Ljava/util/ArrayList;

    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->m_414f6463()I

    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x0

    .line 8
    :goto_0
    if-ge v2, v1, :cond_1

    .line 10
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 13
    move-result-object v3

    .line 14
    check-cast v3, Lot;

    .line 16
    if-eqz v3, :cond_0

    .line 18
    iget-object v4, v3, Lot;->b:La_71A7ED5C;

    .line 20
    if-ne v4, p1, :cond_0

    .line 22
    return-object v3

    .line 23
    :cond_0
    add-int/lit8 v2, v2, 0x1

    .line 25
    goto :goto_0

    .line 26
    :cond_1
    new-instance v1, Lot;

    .line 28
    iget-object v2, p0, La_6BD0AE5B;->b:Landroid/content/Context;

    .line 30
    invoke-direct {v1, v2, p1}, Lot;-><init>(Landroid/content/Context;La_71A7ED5C;)V

    .line 33
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 36
    return-object v1
.end method
