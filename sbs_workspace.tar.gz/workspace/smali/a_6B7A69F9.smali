.class public interface abstract La_6B7A69F9;
.super Ljava/lang/Object;
# processed-91857
.source "mqovpift.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
