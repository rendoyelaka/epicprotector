.class public final La_1922A19C;
.super Ljava/lang/Object;
.source "pheeeigq.java"
# generated-17371

# ep-gmvauotrhana

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_52ACB80E;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p0, Landroid/app/SharedElementCallback$OnSharedElementsReadyListener;

    .line 3
    invoke-static {p0}, Lr;->e(Landroid/app/SharedElementCallback$OnSharedElementsReadyListener;)V

    .line 6
    return-void
.end method

.method public static b(Landroid/app/Activity;[Ljava/lang/String;I)V
    .locals 0

    invoke-static {p0, p1, p2}, Lr;->c(Landroid/app/Activity;[Ljava/lang/String;I)V

    return-void
.end method

.method public static c(Landroid/app/Activity;Ljava/lang/String;)Z
    .locals 0

    invoke-static {p0, p1}, Lr;->h(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method
