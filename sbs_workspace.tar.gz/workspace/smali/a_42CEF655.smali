.class public interface abstract La_42CEF655;
.super Ljava/lang/Object;
.source "xohgymyl.java"
