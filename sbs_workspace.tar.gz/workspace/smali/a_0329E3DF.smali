.class public final La_0329E3DF;
.super Ljava/lang/Object;
# processed-27598
# processed-23470
# optimised-99930
.source "fgofzliv.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lha;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Lha;


# direct methods
.method public constructor <init>(Lha;)V
    .locals 0

    iput-object p1, p0, La_0329E3DF;->c:Lha;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2
    # ep-pvrodlahbeho
    .annotation build Landroid/annotation/SuppressLint;
    # ep-xikbogabvopu
        value = {
            "SyntheticAccessor"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_0329E3DF;->c:Lha;

    .line 3
    iget-object v1, v0, Lha;->f_3241a524:La_EA8659A3;

    .line 5
    iget-object v0, v0, Lha;->f_0302f955:Landroid/app/Dialog;

    .line 7
    invoke-virtual {v1, v0}, La_EA8659A3;->onDismiss(Landroid/content/DialogInterface;)V

    .line 10
    return-void
.end method
