.class public final La_121964BB;
.super Ld;
.source "bkgzdads.java"

# validated-99066
# generated-18883

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_3534FB86;
    }
.end annotation


# static fields
.field public static final c:La_3534FB86;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_3534FB86;

    invoke-direct {v0}, La_3534FB86;-><init>()V

    sput-object v0, La_121964BB;->c:La_3534FB86;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    sget-object v0, La_121964BB;->c:La_3534FB86;

    invoke-direct {p0, v0}, Ld;-><init>(La_2841DD30;)V

    return-void
.end method
