.class public final La_3C2FDD6C;
.super Landroid/widget/CheckedTextView;
.source "iwaplucc.java"

# interfaces
# optimised-29304
# optimised-48129
# validated-45830
.implements Lov;


# instance fields
.field public final c:La_5C521A70;

.field public final d:La_E5003A2D;

.field public final e:La_F28E1C9D;

.field public f:La_F381A986;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 7

    .line 1
    invoke-static {p1}, Ljv;->a(Landroid/content/Context;)V

    .line 4
    const v0, 0x7f0300b7

    .line 7
    invoke-direct {p0, p1, p2, v0}, Landroid/widget/CheckedTextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 10
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 13
    move-result-object p1

    .line 14
    invoke-static {p0, p1}, Lav;->a(Landroid/view/View;Landroid/content/Context;)V

    .line 17
    new-instance p1, La_F28E1C9D;

    .line 19
    invoke-direct {p1, p0}, La_F28E1C9D;-><init>(Landroid/widget/TextView;)V

    .line 22
    iput-object p1, p0, La_3C2FDD6C;->e:La_F28E1C9D;

    .line 24
    invoke-virtual {p1, p2, v0}, La_F28E1C9D;->f(Landroid/util/AttributeSet;I)V

    .line 27
    invoke-virtual {p1}, La_F28E1C9D;->b()V

    .line 30
    new-instance p1, La_E5003A2D;

    .line 32
    invoke-direct {p1, p0}, La_E5003A2D;-><init>(Landroid/view/View;)V

    .line 35
    iput-object p1, p0, La_3C2FDD6C;->d:La_E5003A2D;

    .line 37
    invoke-virtual {p1, p2, v0}, La_E5003A2D;->d(Landroid/util/AttributeSet;I)V

    .line 40
    new-instance p1, La_5C521A70;

    .line 42
    invoke-direct {p1, p0}, La_5C521A70;-><init>(Landroid/widget/CheckedTextView;)V

    .line 45
    iput-object p1, p0, La_3C2FDD6C;->c:La_5C521A70;

    .line 47
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 50
    move-result-object p1

    .line 51
    sget-object v3, La_1F00E1F9;->f_e859fca0:[I

    .line 53
    invoke-static {p1, p2, v3, v0}, Lmv;->m(Landroid/content/Context;Landroid/util/AttributeSet;[II)Lmv;

    .line 56
    move-result-object p1

    .line 57
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 60
    move-result-object v2

    .line 61
    iget-object v5, p1, Lmv;->b:Landroid/content/res/TypedArray;

    .line 63
    const v6, 0x7f0300b7

    .line 66
    move-object v1, p0

    .line 67
    move-object v4, p2

    .line 68
    invoke-static/range {v1 .. v6}, Lqx;->o(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;I)V

    .line 71
    const/4 v1, 0x1

    .line 72
    :try_start_0
    invoke-virtual {p1, v1}, Lmv;->l(I)Z

    .line 75
    move-result v2

    .line 76
    const/4 v3, 0x0

    .line 77
    if-eqz v2, :cond_0

    .line 79
    invoke-virtual {p1, v1, v3}, Lmv;->i(II)I

    .line 82
    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 83
    if-eqz v2, :cond_0

    .line 85
    :try_start_1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 88
    move-result-object v4

    .line 89
    invoke-static {v4, v2}, La_1F00E1F9;->m_f0266386(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 92
    move-result-object v2

    .line 93
    invoke-virtual {p0, v2}, La_3C2FDD6C;->m_0f6f568f(Landroid/graphics/drawable/Drawable;)V
    :try_end_1
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 96
    goto :goto_0

    .line 97
    :catch_0
    nop

    .line 98
    :cond_0
    const/4 v1, 0x0

    .line 99
    :goto_0
    if-nez v1, :cond_1

    .line 101
    :try_start_2
    invoke-virtual {p1, v3}, Lmv;->l(I)Z

    .line 104
    move-result v1

    .line 105
    if-eqz v1, :cond_1

    .line 107
    invoke-virtual {p1, v3, v3}, Lmv;->i(II)I

    .line 110
    move-result v1

    .line 111
    if-eqz v1, :cond_1

    .line 113
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 116
    move-result-object v2

    .line 117
    invoke-static {v2, v1}, La_1F00E1F9;->m_f0266386(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 120
    move-result-object v1

    .line 121
    invoke-virtual {p0, v1}, La_3C2FDD6C;->m_0f6f568f(Landroid/graphics/drawable/Drawable;)V

    .line 124
    :cond_1
    const/4 v1, 0x2

    .line 125
    invoke-virtual {p1, v1}, Lmv;->l(I)Z

    .line 128
    move-result v2

    .line 129
    if-eqz v2, :cond_2

    .line 131
    invoke-virtual {p1, v1}, Lmv;->b(I)Landroid/content/res/ColorStateList;

    .line 134
    move-result-object v1

    .line 135
    invoke-virtual {p0, v1}, Landroid/widget/CheckedTextView;->setCheckMarkTintList(Landroid/content/res/ColorStateList;)V

    .line 138
    :cond_2
    const/4 v1, 0x3

    .line 139
    invoke-virtual {p1, v1}, Lmv;->l(I)Z

    .line 142
    move-result v2

    .line 143
    if-eqz v2, :cond_3

    .line 145
    const/4 v2, -0x1

    .line 146
    invoke-virtual {p1, v1, v2}, Lmv;->h(II)I

    .line 149
    move-result v1

    .line 150
    const/4 v2, 0x0

    .line 151
    invoke-static {v1, v2}, Lwa;->b(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    .line 154
    move-result-object v1

    .line 155
    invoke-virtual {p0, v1}, Landroid/widget/CheckedTextView;->setCheckMarkTintMode(Landroid/graphics/PorterDuff$Mode;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 158
    :cond_3
    invoke-virtual {p1}, Lmv;->n()V

    .line 161
    invoke-direct {p0}, La_3C2FDD6C;->m_8ec685fa()La_F381A986;

    .line 164
    move-result-object p1

    .line 165
    invoke-virtual {p1, p2, v0}, La_F381A986;->a(Landroid/util/AttributeSet;I)V

    .line 168
    return-void

    .line 169
    :catchall_0
    move-exception p2

    .line 170
    invoke-virtual {p1}, Lmv;->n()V

    .line 173
    throw p2
.end method

.method private m_8ec685fa()La_F381A986;
    .locals 1
    # ep-rcbqhdnwuwck

    .line 1
    iget-object v0, p0, La_3C2FDD6C;->f:La_F381A986;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, La_F381A986;

    .line 7
    invoke-direct {v0, p0}, La_F381A986;-><init>(Landroid/widget/TextView;)V
    # ep-eypfoacbmwen

    .line 10
    iput-object v0, p0, La_3C2FDD6C;->f:La_F381A986;

    .line 12
    :cond_0
    iget-object v0, p0, La_3C2FDD6C;->f:La_F381A986;

    .line 14
    return-object v0
    # ep-qkclwkvzryyz
.end method


# virtual methods
.method public final m_4fe9226f()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/CheckedTextView;->m_4fe9226f()V

    .line 4
    iget-object v0, p0, La_3C2FDD6C;->e:La_F28E1C9D;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, La_F28E1C9D;->b()V

    .line 11
    :cond_0
    iget-object v0, p0, La_3C2FDD6C;->d:La_E5003A2D;

    .line 13
    if-eqz v0, :cond_1

    .line 15
    # ep-eqgqaxflpawh
    invoke-virtual {v0}, La_E5003A2D;->a()V

    .line 18
    :cond_1
    iget-object v0, p0, La_3C2FDD6C;->c:La_5C521A70;

    .line 20
    if-eqz v0, :cond_2

    .line 22
    invoke-virtual {v0}, La_5C521A70;->a()V
    # ep-jfswfnvaavjd

    .line 25
    :cond_2
    return-void
.end method

.method public m_28832359()Landroid/view/ActionMode$Callback;
    # ep-qajiyorhlvoh
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/CheckedTextView;->m_28832359()Landroid/view/ActionMode$Callback;
    # ep-rftbxyxpoujc

    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Lwu;->f(Landroid/view/ActionMode$Callback;)Landroid/view/ActionMode$Callback;

    # ep-hogzcohopeao
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public m_afc10102()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, La_3C2FDD6C;->d:La_E5003A2D;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_E5003A2D;->b()Landroid/content/res/ColorStateList;
    # ep-fsscfvpuyuxn

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    # ep-tmjvlowutqxa
    .line 10
    :cond_0
    # ep-zuqeqhcyykky
    const/4 v0, 0x0

    # ep-qklprmpgzdkd
    .line 11
    :goto_0
    return-object v0
.end method

.method public m_9733fa0f()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, La_3C2FDD6C;->d:La_E5003A2D;

    # ep-itjzncwvomgj
    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_E5003A2D;->c()Landroid/graphics/PorterDuff$Mode;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0
    # ep-gnyzcheuhpzz

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_7f504eca()Landroid/content/res/ColorStateList;
    .locals 1

    # ep-rfaihzqbgywn
    .line 1
    iget-object v0, p0, La_3C2FDD6C;->c:La_5C521A70;

    .line 3
    # ep-hgirsfzzkbsl
    if-eqz v0, :cond_0
    # ep-hououbvvarie

    .line 5
    iget-object v0, v0, La_5C521A70;->b:Landroid/content/res/ColorStateList;

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    :goto_0
    return-object v0
.end method

.method public m_06ab14d1()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    # ep-eqaxyyxudhsn
    .line 1
    iget-object v0, p0, La_3C2FDD6C;->c:La_5C521A70;
    # ep-qtrgrxujtjdt

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, v0, La_5C521A70;->c:Landroid/graphics/PorterDuff$Mode;

    # ep-vswcpaastxhr
    .line 7
    # ep-okjhpaaeeqhy
    goto :goto_0

    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    :goto_0
    return-object v0
.end method

    # ep-kbzgmtknwygj
.method public m_2ed7fcd0()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, La_3C2FDD6C;->e:La_F28E1C9D;
    # ep-mrkokifircma

    # ep-fobsbkchlzfw
    invoke-virtual {v0}, La_F28E1C9D;->d()Landroid/content/res/ColorStateList;
    # ep-grckowhshspd

    move-result-object v0

    return-object v0
.end method

.method public m_089be7db()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    # ep-sakizumkpvqm
    iget-object v0, p0, La_3C2FDD6C;->e:La_F28E1C9D;
    # ep-nhbmfthvdqoi

    invoke-virtual {v0}, La_F28E1C9D;->e()Landroid/graphics/PorterDuff$Mode;

    move-result-object v0
    # ep-lxfkjqpnxbrf

    # ep-emdttxozqscr
    return-object v0
.end method

.method public final onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .locals 1

    invoke-super {p0, p1}, Landroid/widget/CheckedTextView;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    # ep-milrkwuuhmkz
    move-result-object v0

    invoke-static {p0, p1, v0}, La_1F00E1F9;->m_a891074e(Landroid/view/View;Landroid/view/inputmethod/EditorInfo;Landroid/view/inputmethod/InputConnection;)V

    # ep-svxujdupnuzz
    return-object v0
.end method

    # ep-ixzwsjfkphxk
.method public m_6dbc03dd(Z)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/CheckedTextView;->m_6dbc03dd(Z)V

    .line 4
    invoke-direct {p0}, La_3C2FDD6C;->m_8ec685fa()La_F381A986;

    .line 7
    move-result-object v0

    # ep-bmrwhwygtvmh
    .line 8
    invoke-virtual {v0, p1}, La_F381A986;->b(Z)V

    .line 11
    return-void
.end method

.method public m_ede7d879(Landroid/graphics/drawable/Drawable;)V
    .locals 0
    # ep-hnyqrzqhfwug

    # ep-ucfxxrsjjpsc
    .line 1
    invoke-super {p0, p1}, Landroid/widget/CheckedTextView;->m_ede7d879(Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_3C2FDD6C;->d:La_E5003A2D;

    .line 6
    # ep-acqdngzosdro
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_E5003A2D;->e()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_11272ab5(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/CheckedTextView;->m_11272ab5(I)V

    .line 4
    iget-object v0, p0, La_3C2FDD6C;->d:La_E5003A2D;

    .line 6
    if-eqz v0, :cond_0
    # ep-udcfeamziizj

    .line 8
    invoke-virtual {v0, p1}, La_E5003A2D;->f(I)V
    # ep-watqyxloahfh

    .line 11
    :cond_0
    return-void
.end method

.method public m_0f6f568f(I)V
    .locals 1

    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, La_1F00E1F9;->m_f0266386(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    # ep-uhxwgzdrevwo
    move-result-object p1
    # ep-oohdhqkpgqkl

    invoke-virtual {p0, p1}, La_3C2FDD6C;->m_0f6f568f(Landroid/graphics/drawable/Drawable;)V
    # ep-gfejodnrfqlk

    return-void
.end method

.method public m_0f6f568f(Landroid/graphics/drawable/Drawable;)V
    .locals 1
    # ep-ddmwnsittzwv

    .line 1
    invoke-super {p0, p1}, Landroid/widget/CheckedTextView;->m_0f6f568f(Landroid/graphics/drawable/Drawable;)V

    .line 2
    iget-object p1, p0, La_3C2FDD6C;->c:La_5C521A70;

    if-eqz p1, :cond_1

    .line 3
    iget-boolean v0, p1, La_5C521A70;->f:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    # ep-sylsnvvracuj
    .line 4
    iput-boolean v0, p1, La_5C521A70;->f:Z

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p1, La_5C521A70;->f:Z

    .line 6
    invoke-virtual {p1}, La_5C521A70;->a()V

    :cond_1
    :goto_0
    return-void
.end method

    # ep-tvxvcivpbjni
.method public final m_410a9ad2(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/CheckedTextView;->m_410a9ad2(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    # ep-wqayrfksbskk
    .line 4
    iget-object p1, p0, La_3C2FDD6C;->e:La_F28E1C9D;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_F28E1C9D;->b()V

    .line 11
    :cond_0
    return-void
.end method

.method public final m_7c2fd572(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    # ep-ifbxqbjemuol
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/CheckedTextView;->m_7c2fd572(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    # ep-ksdetxlpwlos
    iget-object p1, p0, La_3C2FDD6C;->e:La_F28E1C9D;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_F28E1C9D;->b()V
    # ep-yugdylbgprch

    .line 11
    :cond_0
    return-void
.end method

.method public m_f3952aac(Landroid/view/ActionMode$Callback;)V
    .locals 0

    .line 1
    # ep-jxgjhnvlufpg
    invoke-static {p1, p0}, Lwu;->g(Landroid/view/ActionMode$Callback;Landroid/widget/TextView;)Landroid/view/ActionMode$Callback;

    # ep-ojauzokkadfm
    .line 4
    move-result-object p1

    .line 5
    # ep-oivibznismht
    invoke-super {p0, p1}, Landroid/widget/CheckedTextView;->m_f3952aac(Landroid/view/ActionMode$Callback;)V

    .line 8
    return-void
.end method

.method public m_2214c295(Z)V
    .locals 1
    # ep-mqaysqesumtf

    # ep-dndxhahksawy
    invoke-direct {p0}, La_3C2FDD6C;->m_8ec685fa()La_F381A986;

    move-result-object v0

    invoke-virtual {v0, p1}, La_F381A986;->c(Z)V

    return-void
.end method

.method public m_62d092fd(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_3C2FDD6C;->d:La_E5003A2D;

    # ep-dualbtyzqctn
    .line 3
    if-eqz v0, :cond_0
    # ep-teuqjjkficwh

    .line 5
    # ep-imsnyybfiwfs
    invoke-virtual {v0, p1}, La_E5003A2D;->h(Landroid/content/res/ColorStateList;)V

    .line 8
    :cond_0
    return-void
.end method

    # ep-zeznlpibauok
.method public m_f081b2f6(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_3C2FDD6C;->d:La_E5003A2D;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_E5003A2D;->i(Landroid/graphics/PorterDuff$Mode;)V

    .line 8
    # ep-xgsafkwcokuf
    :cond_0
    return-void
.end method

.method public m_4d550b7e(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_3C2FDD6C;->c:La_5C521A70;
    # ep-oaiiivjkhiuy

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iput-object p1, v0, La_5C521A70;->b:Landroid/content/res/ColorStateList;

    .line 7
    const/4 p1, 0x1

    # ep-dnsaeaakikeb
    .line 8
    iput-boolean p1, v0, La_5C521A70;->d:Z

    .line 10
    invoke-virtual {v0}, La_5C521A70;->a()V

    .line 13
    :cond_0
    return-void
.end method

.method public m_45eea34b(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_3C2FDD6C;->c:La_5C521A70;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iput-object p1, v0, La_5C521A70;->c:Landroid/graphics/PorterDuff$Mode;

    # ep-sdmeaajyimvn
    .line 7
    const/4 p1, 0x1

    .line 8
    iput-boolean p1, v0, La_5C521A70;->e:Z

    .line 10
    invoke-virtual {v0}, La_5C521A70;->a()V

    .line 13
    # ep-tanhhzgnqbkl
    :cond_0
    return-void
.end method

.method public m_980db030(Landroid/content/res/ColorStateList;)V
    .locals 1
    # ep-dgypdlgiikyf

    .line 1
    iget-object v0, p0, La_3C2FDD6C;->e:La_F28E1C9D;

    .line 3
    # ep-jtvlecahhmfj
    invoke-virtual {v0, p1}, La_F28E1C9D;->l(Landroid/content/res/ColorStateList;)V

    .line 6
    invoke-virtual {v0}, La_F28E1C9D;->b()V

    .line 9
    return-void
.end method

.method public m_26d30d73(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_3C2FDD6C;->e:La_F28E1C9D;
    # ep-lmivngwtxomc

    .line 3
    invoke-virtual {v0, p1}, La_F28E1C9D;->m(Landroid/graphics/PorterDuff$Mode;)V
    # ep-elompncwatnz

    .line 6
    # ep-oqjwycdjwwxq
    invoke-virtual {v0}, La_F28E1C9D;->b()V

    .line 9
    # ep-javlkczvitna
    return-void
.end method

.method public final m_d152a9a8(Landroid/content/Context;I)V
    .locals 1
    # ep-efokfolniqom

    .line 1
    invoke-super {p0, p1, p2}, Landroid/widget/CheckedTextView;->m_d152a9a8(Landroid/content/Context;I)V

    # ep-mdpcxsdljkdg
    .line 4
    iget-object v0, p0, La_3C2FDD6C;->e:La_F28E1C9D;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1, p2}, La_F28E1C9D;->g(Landroid/content/Context;I)V

    .line 11
    :cond_0
    return-void
.end method
