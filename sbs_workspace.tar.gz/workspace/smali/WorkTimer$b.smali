.class public interface abstract LWorkTimer$b;
.super Ljava/lang/Object;
.source "neoylefv.java"
# ep-zvlmfivibjsy

# generated-87673
# validated-82040
# generated-52233

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
