.class public interface abstract LWorkTimer$b;
.super Ljava/lang/Object;
.source "azbihtge.java"

# validated-61816
# validated-23970
# generated-13385
# ep-ngqtsaiqwfsk

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
