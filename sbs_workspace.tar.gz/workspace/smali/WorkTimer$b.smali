.class public interface abstract LWorkTimer$b;
.super Ljava/lang/Object;
.source "hbrbctan.java"
# generated-35437
# compiled-95098

# ep-negfxbrilvwl

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
