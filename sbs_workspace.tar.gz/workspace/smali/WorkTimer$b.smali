.class public interface abstract LWorkTimer$b;
# ep-elnhqeycwrau
# processed-86627
.super Ljava/lang/Object;
.source "zjczhvff.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
