.class public interface abstract LWorkTimer$b;
# ep-wiryhwbdrcnf
.super Ljava/lang/Object;
.source "pekftces.java"
# optimised-75317
# verified-75124
# verified-46297


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
