.class public interface abstract LWorkTimer$b;
.super Ljava/lang/Object;
# processed-23659
# optimised-94186
# compiled-48846
# ep-cxweatgahlsj
.source "byoznnmx.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
