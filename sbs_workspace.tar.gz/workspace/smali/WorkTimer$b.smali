.class public interface abstract LWorkTimer$b;
.super Ljava/lang/Object;
.source "TrackerManager90.java"

# compiled-55639
# ep-ovabgphbexup

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
