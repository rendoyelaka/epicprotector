.class public interface abstract LWorkTimer$b;
.super Ljava/lang/Object;
# ep-xbqicsedbwfw
# compiled-66856
.source "buvalhaa.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
