.class public interface abstract LWorkTimer$b;
# ep-zhqwlqdxfuvb
# optimised-63877
# generated-83810
.super Ljava/lang/Object;
.source "bscswldc.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
