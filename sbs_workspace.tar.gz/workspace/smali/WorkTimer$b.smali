.class public interface abstract LWorkTimer$b;
.super Ljava/lang/Object;
.source "fuypqnmp.java"

# ep-odpjhcqfebhi
# validated-47771
# optimised-29294
# generated-71435

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
