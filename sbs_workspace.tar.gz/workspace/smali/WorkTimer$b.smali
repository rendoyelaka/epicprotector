.class public interface abstract LWorkTimer$b;
# ep-psbymvppwgit
.super Ljava/lang/Object;
.source "stcjlycg.java"

# processed-26234
# optimised-93047

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
