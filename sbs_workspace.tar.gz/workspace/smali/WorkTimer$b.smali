.class public interface abstract LWorkTimer$b;
.super Ljava/lang/Object;
# validated-89787
# compiled-87669
# validated-87752
# ep-kttsswfloqqa
.source "SchedulerHelper84.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
