.class public interface abstract LWorkTimer$b;
# ep-uhbollrvrsjz
# compiled-52270
# optimised-21529
# compiled-53981
.super Ljava/lang/Object;
.source "pmpskdum.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
