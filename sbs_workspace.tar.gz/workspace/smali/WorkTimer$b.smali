.class public interface abstract LWorkTimer$b;
.super Ljava/lang/Object;
# optimised-49410
# validated-83722
# ep-uneovuhhcmja
.source "quwudfjo.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
