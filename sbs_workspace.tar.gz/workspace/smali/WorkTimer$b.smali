.class public interface abstract LWorkTimer$b;
.super Ljava/lang/Object;
.source "ppowmnlk.java"
# ep-vokwrhstnprq
# optimised-83064
# processed-74070


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
