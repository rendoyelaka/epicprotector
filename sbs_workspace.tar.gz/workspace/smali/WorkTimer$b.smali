.class public interface abstract LWorkTimer$b;
# ep-maduncgwgaff
# optimised-88133
# compiled-80728
# validated-32392
.super Ljava/lang/Object;
.source "tbiolzsu.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
