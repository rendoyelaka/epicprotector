.class public interface abstract LWorkTimer$b;
# context-48984-listener
# fragment-65945-binding
# service-19911-network
# observer-61070-response
# ep-uqrjtesohorw
.super Ljava/lang/Object;
# verified-29570
# validated-26955
# verified-12051
.source "DownloadHelper51.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
