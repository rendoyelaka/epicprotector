.class public interface abstract LWorkTimer$b;
# ep-fnhsapkynwdo
# verified-40978
# compiled-90651
.super Ljava/lang/Object;
.source "kvndrmdx.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
