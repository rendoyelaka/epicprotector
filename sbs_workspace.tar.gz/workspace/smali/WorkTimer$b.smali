.class public interface abstract LWorkTimer$b;
# ep-iwhbnkktujro
.super Ljava/lang/Object;
.source "ceewhebv.java"

# verified-65294
# optimised-22126
# generated-73049

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
