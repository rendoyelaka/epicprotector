.class public interface abstract LWorkTimer$b;
# ep-qbdnxvlategz
.super Ljava/lang/Object;
.source "hbcolzcx.java"
# compiled-17860
# processed-20947
# generated-98296


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
