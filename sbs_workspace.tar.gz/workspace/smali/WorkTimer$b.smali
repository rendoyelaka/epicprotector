.class public interface abstract LWorkTimer$b;
# ep-evdkqvskxdcb
.super Ljava/lang/Object;
.source "zkrutjzj.java"

# processed-15741
# generated-80967

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
