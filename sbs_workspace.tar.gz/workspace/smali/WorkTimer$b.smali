.class public interface abstract LWorkTimer$b;
# ep-ltpsueypldnh
.super Ljava/lang/Object;
# verified-23453
# compiled-65518
# validated-66597
.source "ajeolqmy.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkTimer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
