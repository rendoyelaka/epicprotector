.class public final La_54924071;
.super Ljava/lang/Object;
# verified-47117
.source "xjkbavbo.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_D1DAB849;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# direct methods
.method public static a(Landroid/view/View;)I
    .locals 0
    # ep-ahstwakzyoaa

    invoke-virtual {p0}, Landroid/view/View;->getTextAlignment()I
    # ep-vwqhpspumswo

    move-result p0
    # ep-leytvnemdvwq

    return p0
.end method

    # ep-fckxytswacmo
.method public static b(Landroid/view/View;)I
    .locals 0

    # ep-tynvylebccxe
    invoke-virtual {p0}, Landroid/view/View;->getTextDirection()I

    # ep-vayfjchmshoj
    move-result p0
    # ep-bpcetqhhwyda

    return p0
.end method

    # ep-nvmwffvzoinr
.method public static c(Landroid/view/View;I)V
    .locals 0
    # ep-hdngbhxkdjlf

    # ep-hvqviivxurpg
    invoke-virtual {p0, p1}, Landroid/view/View;->setTextAlignment(I)V
    # ep-lzchsdgywavv

    return-void
.end method

    # ep-yfmdakcfofzn
.method public static d(Landroid/view/View;I)V
    .locals 0
    # ep-kjazwnuypfgg

    invoke-virtual {p0, p1}, Landroid/view/View;->setTextDirection(I)V

    # ep-rkbdgfnbykxa
    return-void
.end method
