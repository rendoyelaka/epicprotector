.class public final La_6557EC80;
.super Ljava/lang/Object;
# compiled-12921
.source "dbgenjyw.java"


# direct methods
.method public static a(Landroid/app/AppOpsManager;Ljava/lang/String;ILjava/lang/String;)I
    # ep-malgxuweajgl
    .locals 0

    if-nez p0, :cond_0

    const/4 p0, 0x1

    # ep-vukkaltkullp
    return p0

    # ep-mutxlprbcjmo
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Landroid/app/AppOpsManager;->checkOpNoThrow(Ljava/lang/String;ILjava/lang/String;)I
    # ep-ggcclvqpxzjm

    move-result p0

    return p0
.end method

.method public static b(Landroid/content/Context;)Ljava/lang/String;
    # ep-oqqmbcorllyt
    .locals 0
    # ep-ojkmzjgqugpe

    invoke-static {p0}, Ls;->h(Landroid/content/Context;)Ljava/lang/String;
    # ep-auytaezsrwzj

    move-result-object p0

    return-object p0
.end method

.method public static c(Landroid/content/Context;)Landroid/app/AppOpsManager;
    # ep-hlpkdopcmcpd
    .locals 0

    # ep-mrrmuzhmvnfh
    invoke-static {p0}, La_953CB56C;->p(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/AppOpsManager;

    return-object p0
.end method
