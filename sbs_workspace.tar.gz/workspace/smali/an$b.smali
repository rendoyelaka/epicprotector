.class public final Lan$b;
# ep-vnwpkhbeevsv
# processed-93900
.super Ljava/lang/Object;
.source "jgfvyqjn.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lan;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final a:LOkHttpDispatcher;

.field public b:Ljava/net/Proxy;

.field public c:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lvo;",
            ">;"
        }
    .end annotation
.end field

.field public final d:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LConnectionSpec;",
            ">;"
        }
    .end annotation
.end field

.field public final e:Ljava/util/ArrayList;

.field public final f:Ljava/util/ArrayList;

.field public final g:Ljava/net/ProxySelector;

.field public final h:Ls8;

.field public final i:Ljavax/net/SocketFactory;

.field public j:Ljavax/net/ssl/SSLSocketFactory;

.field public k:Ln00;

.field public l:Ljavax/net/ssl/HostnameVerifier;

.field public final m:Lw5;

.field public n:Lr3;

.field public final o:Lr3;

.field public final p:LConnectionPool;

.field public final q:Lra;

.field public final r:Z

.field public final s:Z

.field public final t:Z

.field public u:I

.field public v:I

.field public w:I

.field public final x:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lan$b;->e:Ljava/util/ArrayList;

    .line 3
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lan$b;->f:Ljava/util/ArrayList;

    .line 4
    new-instance v0, LOkHttpDispatcher;

    invoke-direct {v0}, LOkHttpDispatcher;-><init>()V

    iput-object v0, p0, Lan$b;->a:LOkHttpDispatcher;

    .line 5
    sget-object v0, Lan;->A:Ljava/util/List;

    iput-object v0, p0, Lan$b;->c:Ljava/util/List;

    .line 6
    sget-object v0, Lan;->B:Ljava/util/List;

    iput-object v0, p0, Lan$b;->d:Ljava/util/List;

    .line 7
    invoke-static {}, Ljava/net/ProxySelector;->getDefault()Ljava/net/ProxySelector;

    move-result-object v0

    iput-object v0, p0, Lan$b;->g:Ljava/net/ProxySelector;

    .line 8
    sget-object v0, Ls8;->a:Ls8$a;

    iput-object v0, p0, Lan$b;->h:Ls8;

    .line 9
    invoke-static {}, Ljavax/net/SocketFactory;->getDefault()Ljavax/net/SocketFactory;

    move-result-object v0

    iput-object v0, p0, Lan$b;->i:Ljavax/net/SocketFactory;

    .line 10
    sget-object v0, Lzm;->a:Lzm;

    iput-object v0, p0, Lan$b;->l:Ljavax/net/ssl/HostnameVerifier;

    .line 11
    sget-object v0, Lw5;->c:Lw5;

    iput-object v0, p0, Lan$b;->m:Lw5;

    .line 12
    sget-object v0, Lr3;->a:Lr3$a;

    iput-object v0, p0, Lan$b;->n:Lr3;

    .line 13
    iput-object v0, p0, Lan$b;->o:Lr3;

    .line 14
    new-instance v0, LConnectionPool;

    invoke-direct {v0}, LConnectionPool;-><init>()V

    iput-object v0, p0, Lan$b;->p:LConnectionPool;

    .line 15
    sget-object v0, Lra;->a:Lra$a;

    iput-object v0, p0, Lan$b;->q:Lra;

    const/4 v0, 0x1

    .line 16
    iput-boolean v0, p0, Lan$b;->r:Z

    .line 17
    iput-boolean v0, p0, Lan$b;->s:Z

    .line 18
    iput-boolean v0, p0, Lan$b;->t:Z

    const/16 v0, 0x2710

    .line 19
    iput v0, p0, Lan$b;->u:I

    .line 20
    iput v0, p0, Lan$b;->v:I

    .line 21
    iput v0, p0, Lan$b;->w:I

    const/4 v0, 0x0

    .line 22
    iput v0, p0, Lan$b;->x:I

    return-void
.end method

.method public constructor <init>(Lan;)V
    .locals 3

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lan$b;->e:Ljava/util/ArrayList;

    .line 25
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lan$b;->f:Ljava/util/ArrayList;

    .line 26
    iget-object v2, p1, Lan;->c:LOkHttpDispatcher;

    iput-object v2, p0, Lan$b;->a:LOkHttpDispatcher;

    .line 27
    iget-object v2, p1, Lan;->d:Ljava/net/Proxy;

    iput-object v2, p0, Lan$b;->b:Ljava/net/Proxy;

    .line 28
    iget-object v2, p1, Lan;->e:Ljava/util/List;

    iput-object v2, p0, Lan$b;->c:Ljava/util/List;

    .line 29
    iget-object v2, p1, Lan;->f:Ljava/util/List;

    iput-object v2, p0, Lan$b;->d:Ljava/util/List;

    .line 30
    iget-object v2, p1, Lan;->g:Ljava/util/List;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 31
    iget-object v0, p1, Lan;->h:Ljava/util/List;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 32
    iget-object v0, p1, Lan;->i:Ljava/net/ProxySelector;

    iput-object v0, p0, Lan$b;->g:Ljava/net/ProxySelector;

    .line 33
    iget-object v0, p1, Lan;->j:Ls8;

    iput-object v0, p0, Lan$b;->h:Ls8;

    .line 34
    iget-object v0, p1, Lan;->k:Ljavax/net/SocketFactory;

    iput-object v0, p0, Lan$b;->i:Ljavax/net/SocketFactory;

    .line 35
    iget-object v0, p1, Lan;->l:Ljavax/net/ssl/SSLSocketFactory;

    iput-object v0, p0, Lan$b;->j:Ljavax/net/ssl/SSLSocketFactory;

    .line 36
    iget-object v0, p1, Lan;->m:Ln00;

    iput-object v0, p0, Lan$b;->k:Ln00;

    .line 37
    iget-object v0, p1, Lan;->n:Ljavax/net/ssl/HostnameVerifier;

    iput-object v0, p0, Lan$b;->l:Ljavax/net/ssl/HostnameVerifier;

    .line 38
    iget-object v0, p1, Lan;->o:Lw5;

    iput-object v0, p0, Lan$b;->m:Lw5;

    .line 39
    iget-object v0, p1, Lan;->p:Lr3;

    iput-object v0, p0, Lan$b;->n:Lr3;

    .line 40
    iget-object v0, p1, Lan;->q:Lr3;

    iput-object v0, p0, Lan$b;->o:Lr3;

    .line 41
    iget-object v0, p1, Lan;->r:LConnectionPool;

    iput-object v0, p0, Lan$b;->p:LConnectionPool;

    .line 42
    iget-object v0, p1, Lan;->s:Lra;

    iput-object v0, p0, Lan$b;->q:Lra;

    .line 43
    iget-boolean v0, p1, Lan;->t:Z

    iput-boolean v0, p0, Lan$b;->r:Z

    .line 44
    iget-boolean v0, p1, Lan;->u:Z

    iput-boolean v0, p0, Lan$b;->s:Z

    .line 45
    iget-boolean v0, p1, Lan;->v:Z

    iput-boolean v0, p0, Lan$b;->t:Z

    .line 46
    iget v0, p1, Lan;->w:I

    iput v0, p0, Lan$b;->u:I

    .line 47
    iget v0, p1, Lan;->x:I

    iput v0, p0, Lan$b;->v:I

    .line 48
    iget v0, p1, Lan;->y:I

    iput v0, p0, Lan$b;->w:I

    .line 49
    iget p1, p1, Lan;->z:I

    iput p1, p0, Lan$b;->x:I

    return-void
.end method

.method public static a(Ljava/util/concurrent/TimeUnit;)I
    .locals 4

    .line 1
    if-eqz p0, :cond_1

    .line 3
    const-wide/16 v0, 0x0

    .line 5
    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 8
    move-result-wide v0

    .line 9
    const-wide/32 v2, 0x7fffffff

    .line 12
    cmp-long p0, v0, v2

    .line 14
    if-gtz p0, :cond_0

    .line 16
    long-to-int p0, v0

    .line 17
    return p0

    .line 18
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 20
    const-string v0, "timeout too large."

    .line 22
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 25
    throw p0

    .line 26
    :cond_1
    new-instance p0, Ljava/lang/NullPointerException;

    .line 28
    const-string v0, "unit == null"

    .line 30
    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 33
    throw p0
.end method
