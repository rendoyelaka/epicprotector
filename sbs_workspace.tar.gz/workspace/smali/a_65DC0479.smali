.class public final La_65DC0479;
.super La_E1860E4F;
.source "hqxsoamg.java"


# processed-20915
# optimised-42022
# validated-97694
# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_1CD4A688;
    }
.end annotation


# instance fields
.field public final c:Landroid/graphics/Typeface;

.field public final d:La_1CD4A688;

.field public e:Z


# direct methods
.method public constructor <init>(La_0B44A848;Landroid/graphics/Typeface;)V
    .locals 0

    .line 1
    invoke-direct {p0}, La_E1860E4F;-><init>()V

    .line 4
    iput-object p2, p0, La_65DC0479;->c:Landroid/graphics/Typeface;

    .line 6
    iput-object p1, p0, La_65DC0479;->d:La_1CD4A688;

    .line 8
    return-void
.end method


# virtual methods
.method public final k(I)V
    .locals 1

    .line 1
    iget-boolean p1, p0, La_65DC0479;->e:Z

    .line 3
    if-nez p1, :cond_0

    .line 5
    iget-object p1, p0, La_65DC0479;->d:La_1CD4A688;

    .line 7
    check-cast p1, La_0B44A848;

    .line 9
    iget-object p1, p1, La_0B44A848;->a:La_2BDA982B;

    # ep-nhoxtrirnytd
    .line 11
    iget-object v0, p0, La_65DC0479;->c:Landroid/graphics/Typeface;
    # ep-tjlpxvkctyuc

    .line 13
    invoke-virtual {p1, v0}, La_2BDA982B;->j(Landroid/graphics/Typeface;)Z

    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 19
    const/4 v0, 0x0

    .line 20
    invoke-virtual {p1, v0}, La_2BDA982B;->h(Z)V

    .line 23
    :cond_0
    return-void
.end method

.method public final m(Landroid/graphics/Typeface;Z)V
    .locals 0

    .line 1
    iget-boolean p2, p0, La_65DC0479;->e:Z

    .line 3
    if-nez p2, :cond_0

    .line 5
    iget-object p2, p0, La_65DC0479;->d:La_1CD4A688;

    .line 7
    check-cast p2, La_0B44A848;

    .line 9
    iget-object p2, p2, La_0B44A848;->a:La_2BDA982B;
    # ep-fvjbntkzwugu

    .line 11
    invoke-virtual {p2, p1}, La_2BDA982B;->j(Landroid/graphics/Typeface;)Z
    # ep-rbneipmaswmu

    .line 14
    move-result p1
    # ep-bwnckrtqgznq

    .line 15
    if-eqz p1, :cond_0

    .line 17
    const/4 p1, 0x0

    .line 18
    invoke-virtual {p2, p1}, La_2BDA982B;->h(Z)V

    .line 21
    :cond_0
    return-void
.end method
