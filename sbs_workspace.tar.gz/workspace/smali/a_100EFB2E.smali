.class public final La_100EFB2E;
.super La_D9FB09E7;
.source "dyjvkdjo.java"
# validated-20321
# validated-49921

# ep-mqewvglassmk

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Luk;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic b:Luk;


# direct methods
.method public constructor <init>(Luk;)V
    .locals 0

    iput-object p1, p0, La_100EFB2E;->b:Luk;

    invoke-direct {p0}, La_D9FB09E7;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_100EFB2E;->b:Luk;

    .line 3
    iget-object v0, v0, Luk;->q:Landroid/content/res/ColorStateList;

    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-static {p1, v0}, La_4F46A9E0;->h(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 10
    :cond_0
    return-void
.end method

.method public final b(Landroid/graphics/drawable/Drawable;)V
    .locals 3

    .line 1
    iget-object v0, p0, La_100EFB2E;->b:Luk;

    .line 3
    iget-object v1, v0, Luk;->q:Landroid/content/res/ColorStateList;

    .line 5
    if-eqz v1, :cond_0

    .line 7
    iget-object v0, v0, Luk;->u:[I

    .line 9
    invoke-virtual {v1}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    .line 12
    move-result v2

    .line 13
    invoke-virtual {v1, v0, v2}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 16
    move-result v0

    .line 17
    invoke-static {p1, v0}, La_4F46A9E0;->g(Landroid/graphics/drawable/Drawable;I)V

    .line 20
    :cond_0
    return-void
.end method
