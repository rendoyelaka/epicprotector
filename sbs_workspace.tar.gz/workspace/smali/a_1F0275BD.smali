.class public final La_1F0275BD;
.super Ljava/lang/Object;
# ep-htpkwerdagyb
.source "ofysnose.java"

# validated-86855
# optimised-99961
# interfaces
.implements Ljava/io/Closeable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_63B32426;,
        La_4C86B6CA;,
        La_AD116780;
    }
.end annotation


# static fields
.field public static final u:Ljava/util/concurrent/ThreadPoolExecutor;


# instance fields
.field public final c:Z

.field public final d:La_63B32426;

.field public final e:Ljava/util/LinkedHashMap;

.field public final f:Ljava/lang/String;

.field public g:I

.field public h:I

.field public i:Z

.field public final j:Ljava/util/concurrent/ThreadPoolExecutor;

.field public final k:La_8D3C04CC;

.field public l:J

.field public m:J

.field public final n:Lur;

.field public final o:Lur;

.field public p:Z

.field public final q:Ljava/net/Socket;

.field public final r:Leh;

.field public final s:La_4C86B6CA;

.field public final t:Ljava/util/LinkedHashSet;


# direct methods
.method public static constructor <clinit>()V
    .locals 10

    .line 1
    new-instance v8, Ljava/util/concurrent/ThreadPoolExecutor;

    .line 3
    const/4 v1, 0x0

    .line 4
    const v2, 0x7fffffff

    .line 7
    const-wide/16 v3, 0x3c

    .line 9
    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 11
    new-instance v6, Ljava/util/concurrent/SynchronousQueue;

    .line 13
    invoke-direct {v6}, Ljava/util/concurrent/SynchronousQueue;-><init>()V

    .line 16
    sget-object v0, Lex;->a:[B

    .line 18
    new-instance v7, Lcx;

    .line 20
    const-string v0, "OkHttp FramedConnection"

    .line 22
    const/4 v9, 0x1

    .line 23
    invoke-direct {v7, v0, v9}, Lcx;-><init>(Ljava/lang/String;Z)V

    .line 26
    move-object v0, v8

    .line 27
    invoke-direct/range {v0 .. v7}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    .line 30
    sput-object v8, La_1F0275BD;->u:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 32
    return-void
.end method

.method public constructor <init>(La_AD116780;)V
    .locals 14

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/LinkedHashMap;

    .line 6
    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    .line 9
    iput-object v0, p0, La_1F0275BD;->e:Ljava/util/LinkedHashMap;

    .line 11
    const-wide/16 v0, 0x0

    .line 13
    iput-wide v0, p0, La_1F0275BD;->l:J

    .line 15
    new-instance v0, Lur;

    .line 17
    invoke-direct {v0}, Lur;-><init>()V

    .line 20
    iput-object v0, p0, La_1F0275BD;->n:Lur;

    .line 22
    new-instance v1, Lur;

    .line 24
    invoke-direct {v1}, Lur;-><init>()V

    .line 27
    iput-object v1, p0, La_1F0275BD;->o:Lur;

    .line 29
    const/4 v2, 0x0

    .line 30
    iput-boolean v2, p0, La_1F0275BD;->p:Z

    .line 32
    new-instance v3, Ljava/util/LinkedHashSet;

    .line 34
    invoke-direct {v3}, Ljava/util/LinkedHashSet;-><init>()V

    .line 37
    iput-object v3, p0, La_1F0275BD;->t:Ljava/util/LinkedHashSet;

    .line 39
    sget-object v3, Lwo;->a:La_8D3C04CC;

    .line 41
    iput-object v3, p0, La_1F0275BD;->k:La_8D3C04CC;

    .line 43
    const/4 v3, 0x1

    .line 44
    iput-boolean v3, p0, La_1F0275BD;->c:Z

    .line 46
    iget-object v4, p1, La_AD116780;->e:La_63B32426;

    .line 48
    iput-object v4, p0, La_1F0275BD;->d:La_63B32426;

    .line 50
    const/4 v4, 0x3

    .line 51
    iput v4, p0, La_1F0275BD;->h:I

    .line 53
    const/high16 v4, 0x1000000

    .line 55
    const/4 v5, 0x7

    .line 56
    invoke-virtual {v0, v5, v4}, Lur;->b(II)V

    .line 59
    iget-object v0, p1, La_AD116780;->b:Ljava/lang/String;

    .line 61
    iput-object v0, p0, La_1F0275BD;->f:Ljava/lang/String;

    .line 63
    new-instance v4, Ljava/util/concurrent/ThreadPoolExecutor;

    .line 65
    const/4 v7, 0x0

    .line 66
    const/4 v8, 0x1

    .line 67
    const-wide/16 v9, 0x3c

    .line 69
    sget-object v11, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 71
    new-instance v12, Ljava/util/concurrent/LinkedBlockingQueue;

    .line 73
    invoke-direct {v12}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    .line 76
    new-array v6, v3, [Ljava/lang/Object;

    .line 78
    aput-object v0, v6, v2

    .line 80
    const-string v0, "OkHttp %s Push Observer"

    .line 82
    invoke-static {v0, v6}, Lex;->g(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 85
    move-result-object v0

    .line 86
    new-instance v13, Lcx;

    .line 88
    invoke-direct {v13, v0, v3}, Lcx;-><init>(Ljava/lang/String;Z)V

    .line 91
    move-object v6, v4

    .line 92
    invoke-direct/range {v6 .. v13}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    .line 95
    iput-object v4, p0, La_1F0275BD;->j:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 97
    const v0, 0xffff

    .line 100
    invoke-virtual {v1, v5, v0}, Lur;->b(II)V

    .line 103
    const/4 v0, 0x5

    .line 104
    const/16 v2, 0x4000

    .line 106
    invoke-virtual {v1, v0, v2}, Lur;->b(II)V

    .line 109
    invoke-virtual {v1}, Lur;->a()I

    .line 112
    move-result v0

    .line 113
    int-to-long v0, v0

    .line 114
    iput-wide v0, p0, La_1F0275BD;->m:J

    .line 116
    iget-object v0, p1, La_AD116780;->a:Ljava/net/Socket;

    .line 118
    iput-object v0, p0, La_1F0275BD;->q:Ljava/net/Socket;

    .line 120
    new-instance v0, Leh;

    .line 122
    iget-object v1, p1, La_AD116780;->d:La_ED811785;

    .line 124
    invoke-direct {v0, v1, v3}, Leh;-><init>(La_ED811785;Z)V

    .line 127
    iput-object v0, p0, La_1F0275BD;->r:Leh;

    .line 129
    new-instance v0, La_4C86B6CA;

    .line 131
    new-instance v1, La_FBA6621D;

    .line 133
    iget-object p1, p1, La_AD116780;->c:La_34230022;

    .line 135
    invoke-direct {v1, p1, v3}, La_FBA6621D;-><init>(La_34230022;Z)V

    .line 138
    invoke-direct {v0, p0, v1}, La_4C86B6CA;-><init>(La_1F0275BD;La_FBA6621D;)V

    .line 141
    iput-object v0, p0, La_1F0275BD;->s:La_4C86B6CA;

    .line 143
    return-void
.end method


# virtual methods
.method public final m_ce32a5d6()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0, v0, v1}, La_1F0275BD;->h(II)V

    return-void
.end method

.method public final m_471bb8d1()V
    .locals 1

    iget-object v0, p0, La_1F0275BD;->r:Leh;

    invoke-virtual {v0}, Leh;->m_471bb8d1()V

    return-void
.end method

.method public final h(II)V
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_0
    invoke-virtual {p0, p1}, La_1F0275BD;->t(I)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 5
    move-object p1, v0

    .line 6
    goto :goto_0

    .line 7
    :catch_0
    move-exception p1

    .line 8
    :goto_0
    monitor-enter p0

    .line 9
    :try_start_1
    iget-object v1, p0, La_1F0275BD;->e:Ljava/util/LinkedHashMap;

    .line 11
    invoke-interface {v1}, Ljava/util/Map;->m_2bd5aeca()Z

    .line 14
    move-result v1

    .line 15
    if-nez v1, :cond_0

    .line 17
    iget-object v0, p0, La_1F0275BD;->e:Ljava/util/LinkedHashMap;

    .line 19
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->m_1378ba9f()Ljava/util/Collection;

    .line 22
    move-result-object v0

    .line 23
    iget-object v1, p0, La_1F0275BD;->e:Ljava/util/LinkedHashMap;

    .line 25
    invoke-interface {v1}, Ljava/util/Map;->m_79017b7d()I

    .line 28
    move-result v1

    .line 29
    new-array v1, v1, [Ldh;

    .line 31
    invoke-interface {v0, v1}, Ljava/util/Collection;->m_3c913d7a([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 34
    move-result-object v0

    .line 35
    check-cast v0, [Ldh;

    .line 37
    iget-object v1, p0, La_1F0275BD;->e:Ljava/util/LinkedHashMap;

    .line 39
    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->m_40c36116()V

    .line 42
    :cond_0
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 43
    if-eqz v0, :cond_2

    .line 45
    array-length v1, v0

    .line 46
    const/4 v2, 0x0

    .line 47
    :goto_1
    if-ge v2, v1, :cond_2

    .line 49
    aget-object v3, v0, v2

    .line 51
    :try_start_2
    invoke-virtual {v3, p2}, Ldh;->c(I)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    .line 54
    goto :goto_2

    .line 55
    :catch_1
    move-exception v3

    .line 56
    if-eqz p1, :cond_1

    .line 58
    move-object p1, v3

    .line 59
    :cond_1
    :goto_2
    add-int/lit8 v2, v2, 0x1

    .line 61
    goto :goto_1

    .line 62
    :cond_2
    :try_start_3
    iget-object p2, p0, La_1F0275BD;->r:Leh;

    .line 64
    invoke-virtual {p2}, Leh;->m_ce32a5d6()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_2

    .line 67
    goto :goto_3

    .line 68
    :catch_2
    move-exception p2

    .line 69
    if-nez p1, :cond_3

    .line 71
    move-object p1, p2

    .line 72
    :cond_3
    :goto_3
    :try_start_4
    iget-object p2, p0, La_1F0275BD;->q:Ljava/net/Socket;

    .line 74
    invoke-virtual {p2}, Ljava/net/Socket;->m_ce32a5d6()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_3

    .line 77
    goto :goto_4

    .line 78
    :catch_3
    move-exception p1

    .line 79
    :goto_4
    if-nez p1, :cond_4

    .line 81
    return-void

    .line 82
    :cond_4
    throw p1

    .line 83
    :catchall_0
    move-exception p1

    .line 84
    :try_start_5
    monitor-exit p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 85
    throw p1
.end method

.method public final declared-synchronized j(I)Ldh;
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, La_1F0275BD;->e:Ljava/util/LinkedHashMap;

    .line 4
    invoke-static {p1}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 7
    move-result-object p1

    .line 8
    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    move-result-object p1

    .line 12
    check-cast p1, Ldh;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 14
    monitor-exit p0

    .line 15
    return-object p1

    .line 16
    :catchall_0
    move-exception p1

    .line 17
    monitor-exit p0

    .line 18
    throw p1
.end method

.method public final declared-synchronized r()I
    .locals 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, La_1F0275BD;->o:Lur;

    .line 4
    iget v1, v0, Lur;->a:I

    .line 6
    and-int/lit8 v1, v1, 0x10

    .line 8
    if-eqz v1, :cond_0

    .line 10
    iget-object v0, v0, Lur;->b:[I

    .line 12
    const/4 v1, 0x4

    .line 13
    aget v0, v0, v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    const v0, 0x7fffffff

    .line 19
    :goto_0
    monitor-exit p0

    .line 20
    return v0

    .line 21
    :catchall_0
    move-exception v0

    .line 22
    monitor-exit p0

    .line 23
    throw v0
.end method

.method public final declared-synchronized s(I)Ldh;
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, La_1F0275BD;->e:Ljava/util/LinkedHashMap;

    .line 4
    invoke-static {p1}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 7
    move-result-object p1

    .line 8
    invoke-interface {v0, p1}, Ljava/util/Map;->m_8eb9dccd(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    move-result-object p1

    .line 12
    check-cast p1, Ldh;

    .line 14
    invoke-virtual {p0}, Ljava/lang/Object;->notifyAll()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 17
    monitor-exit p0

    .line 18
    return-object p1

    .line 19
    :catchall_0
    move-exception p1

    .line 20
    monitor-exit p0

    .line 21
    throw p1
.end method

.method public final t(I)V
    .locals 4

    .line 1
    iget-object v0, p0, La_1F0275BD;->r:Leh;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    monitor-enter p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 5
    :try_start_1
    iget-boolean v1, p0, La_1F0275BD;->i:Z

    .line 7
    if-eqz v1, :cond_0

    .line 9
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 10
    :try_start_2
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 11
    return-void

    .line 12
    :cond_0
    const/4 v1, 0x1

    .line 13
    :try_start_3
    iput-boolean v1, p0, La_1F0275BD;->i:Z

    .line 15
    iget v1, p0, La_1F0275BD;->g:I

    .line 17
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 18
    :try_start_4
    iget-object v2, p0, La_1F0275BD;->r:Leh;

    .line 20
    sget-object v3, Lex;->a:[B

    .line 22
    invoke-virtual {v2, v1, p1, v3}, Leh;->s(II[B)V

    .line 25
    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 26
    return-void

    .line 27
    :catchall_0
    move-exception p1

    .line 28
    :try_start_5
    monitor-exit p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 29
    :try_start_6
    throw p1

    .line 30
    :catchall_1
    move-exception p1

    .line 31
    monitor-exit v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .line 32
    throw p1
.end method

.method public final u(IZLa_726A8EEF;J)V
    .locals 8

    .line 1
    const/4 v0, 0x0

    .line 2
    const-wide/16 v1, 0x0

    .line 4
    cmp-long v3, p4, v1

    .line 6
    if-nez v3, :cond_0

    .line 8
    iget-object p4, p0, La_1F0275BD;->r:Leh;

    .line 10
    invoke-virtual {p4, p2, p1, p3, v0}, Leh;->j(ZILa_726A8EEF;I)V

    .line 13
    return-void

    .line 14
    :cond_0
    :goto_0
    cmp-long v3, p4, v1

    .line 16
    if-lez v3, :cond_4

    .line 18
    monitor-enter p0

    .line 19
    :goto_1
    :try_start_0
    iget-wide v3, p0, La_1F0275BD;->m:J

    .line 21
    cmp-long v5, v3, v1

    .line 23
    if-gtz v5, :cond_2

    .line 25
    iget-object v3, p0, La_1F0275BD;->e:Ljava/util/LinkedHashMap;

    .line 27
    invoke-static {p1}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 30
    move-result-object v4

    .line 31
    invoke-interface {v3, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 34
    move-result v3

    .line 35
    if-eqz v3, :cond_1

    .line 37
    invoke-virtual {p0}, Ljava/lang/Object;->wait()V

    .line 40
    goto :goto_1

    .line 41
    :cond_1
    new-instance p1, Ljava/io/IOException;

    .line 43
    const-string p2, "stream closed"

    .line 45
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 48
    throw p1
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 49
    :cond_2
    :try_start_1
    invoke-static {p4, p5, v3, v4}, Ljava/lang/Math;->min(JJ)J

    .line 52
    move-result-wide v3

    .line 53
    long-to-int v4, v3

    .line 54
    iget-object v3, p0, La_1F0275BD;->r:Leh;

    .line 56
    iget v3, v3, Leh;->f:I

    .line 58
    invoke-static {v4, v3}, Ljava/lang/Math;->min(II)I

    .line 61
    move-result v3

    .line 62
    iget-wide v4, p0, La_1F0275BD;->m:J

    .line 64
    int-to-long v6, v3

    .line 65
    sub-long/2addr v4, v6

    .line 66
    iput-wide v4, p0, La_1F0275BD;->m:J

    .line 68
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 69
    sub-long/2addr p4, v6

    .line 70
    iget-object v4, p0, La_1F0275BD;->r:Leh;

    .line 72
    if-eqz p2, :cond_3

    .line 74
    cmp-long v5, p4, v1

    .line 76
    if-nez v5, :cond_3

    .line 78
    const/4 v5, 0x1

    .line 79
    goto :goto_2

    .line 80
    :cond_3
    const/4 v5, 0x0

    .line 81
    :goto_2
    invoke-virtual {v4, v5, p1, p3, v3}, Leh;->j(ZILa_726A8EEF;I)V

    .line 84
    goto :goto_0

    .line 85
    :catchall_0
    move-exception p1

    .line 86
    goto :goto_3

    .line 87
    :catch_0
    :try_start_2
    new-instance p1, Ljava/io/InterruptedIOException;

    .line 89
    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    .line 92
    throw p1

    .line 93
    :goto_3
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 94
    throw p1

    .line 95
    :cond_4
    return-void
.end method

.method public final v(II)V
    .locals 5

    sget-object v0, La_1F0275BD;->u:Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v1, Lsg;

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v4, p0, La_1F0275BD;->f:Ljava/lang/String;

    aput-object v4, v2, v3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-direct {v1, p0, v2, p1, p2}, Lsg;-><init>(La_1F0275BD;[Ljava/lang/Object;II)V

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->m_a6484c79(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final w(IJ)V
    .locals 8

    sget-object v0, La_1F0275BD;->u:Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v7, La_52B21526;

    const/4 v1, 0x2

    new-array v3, v1, [Ljava/lang/Object;

    const/4 v1, 0x0

    iget-object v2, p0, La_1F0275BD;->f:Ljava/lang/String;

    aput-object v2, v3, v1

    const/4 v1, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v3, v1

    move-object v1, v7

    move-object v2, p0

    move v4, p1

    move-wide v5, p2

    invoke-direct/range {v1 .. v6}, La_52B21526;-><init>(La_1F0275BD;[Ljava/lang/Object;IJ)V

    invoke-virtual {v0, v7}, Ljava/util/concurrent/ThreadPoolExecutor;->m_a6484c79(Ljava/lang/Runnable;)V

    return-void
.end method
