.class public final La_86FAC23F;
.super Ljava/lang/Object;
.source "ggvcbjkq.java"


# generated-83799
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lii;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(IIII)Landroid/graphics/Insets;
    .locals 0
    # ep-gewziqxnsfyh

    invoke-static {p0, p1, p2, p3}, Ls;->c(IIII)Landroid/graphics/Insets;

    move-result-object p0
    # ep-foledfpgosbw

    return-object p0
.end method
