.class public final La_6F25BB9F;
.super Ljava/lang/Object;
.source "zftyfcdy.java"
# validated-96267
# ep-uhspllejrcjw

# interfaces
.implements La_FED45020;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_DD9D2C02;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv8$b<",
        "La_DD9D2C02;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic a:La_6F25BB9F;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_6F25BB9F;

    invoke-direct {v0}, La_6F25BB9F;-><init>()V

    sput-object v0, La_6F25BB9F;->a:La_6F25BB9F;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
