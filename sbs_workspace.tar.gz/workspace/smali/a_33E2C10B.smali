.class public final La_33E2C10B;
.super Ljava/lang/Object;
.source "soytzmwk.java"
# validated-46258
# ep-qvgygxwfmkes


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_E86E9D05;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# direct methods
.method public static a(Ljava/lang/CharSequence;Landroid/text/Layout$Alignment;IILandroid/widget/TextView;Landroid/text/TextPaint;La_A136B66D;)Landroid/text/StaticLayout;
    .locals 1

    .line 1
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    .line 4
    move-result v0

    .line 5
    invoke-static {p0, v0, p5, p2}, La_F79784E5;->n(Ljava/lang/CharSequence;ILandroid/text/TextPaint;I)Landroid/text/StaticLayout$Builder;

    .line 8
    move-result-object p0

    .line 9
    invoke-static {p0, p1}, La_F79784E5;->l(Landroid/text/StaticLayout$Builder;Landroid/text/Layout$Alignment;)Landroid/text/StaticLayout$Builder;

    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {p4}, Landroid/widget/TextView;->getLineSpacingExtra()F

    .line 16
    move-result p2

    .line 17
    invoke-virtual {p4}, Landroid/widget/TextView;->getLineSpacingMultiplier()F

    .line 20
    move-result p5

    .line 21
    invoke-static {p1, p2, p5}, La_F79784E5;->j(Landroid/text/StaticLayout$Builder;FF)Landroid/text/StaticLayout$Builder;

    .line 24
    move-result-object p1

    .line 25
    invoke-virtual {p4}, Landroid/widget/TextView;->getIncludeFontPadding()Z

    .line 28
    move-result p2

    .line 29
    invoke-static {p1, p2}, La_F79784E5;->m(Landroid/text/StaticLayout$Builder;Z)Landroid/text/StaticLayout$Builder;

    .line 32
    move-result-object p1

    .line 33
    invoke-static {p4}, La_F79784E5;->d(Landroid/widget/TextView;)I

    .line 36
    move-result p2

    .line 37
    invoke-static {p1, p2}, La_F79784E5;->k(Landroid/text/StaticLayout$Builder;I)Landroid/text/StaticLayout$Builder;

    .line 40
    move-result-object p1

    .line 41
    invoke-static {p4}, La_F79784E5;->m_61732c05(Landroid/widget/TextView;)I

    .line 44
    move-result p2

    .line 45
    invoke-static {p1, p2}, La_F79784E5;->m_8461ad83(Landroid/text/StaticLayout$Builder;I)Landroid/text/StaticLayout$Builder;

    .line 48
    move-result-object p1

    .line 49
    const/4 p2, -0x1

    .line 50
    if-ne p3, p2, :cond_0

    .line 52
    const p3, 0x7fffffff

    .line 55
    :cond_0
    invoke-static {p1, p3}, La_F79784E5;->v(Landroid/text/StaticLayout$Builder;I)V

    .line 58
    :try_start_0
    invoke-virtual {p6, p0, p4}, La_A136B66D;->a(Landroid/text/StaticLayout$Builder;Landroid/widget/TextView;)V
    :try_end_0
    .catch Ljava/lang/ClassCastException; {:try_start_0 .. :try_end_0} :catch_0

    .line 61
    :catch_0
    invoke-static {p0}, La_F79784E5;->o(Landroid/text/StaticLayout$Builder;)Landroid/text/StaticLayout;

    .line 64
    move-result-object p0

    .line 65
    return-object p0
.end method
