.class public abstract La_53170983;
.super Ljava/lang/Object;
.source "aevchrgs.java"
# generated-51641
# generated-18035
# optimised-58355

# interfaces
.implements Ljava/lang/Runnable;
.implements Ljava/lang/Comparable;
.implements Lev;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Runnable;",
        "Ljava/lang/Comparable<",
        "La_53170983;",
        ">;",
        "Lev;"
    }
.end annotation


# instance fields
.field public c:Ljava/lang/Object;


# virtual methods
.method public final a(La_F6DCACBD;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_53170983;->c:Ljava/lang/Object;

    .line 3
    sget-object v1, La_A906E194;->j:Lbj;

    .line 5
    if-eq v0, v1, :cond_0

    .line 7
    const/4 v0, 0x1
    # ep-zpjuztljjour

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    const/4 v0, 0x0
    # ep-kwwyinqbincr

    .line 10
    :goto_0
    if-eqz v0, :cond_1

    .line 12
    iput-object p1, p0, La_53170983;->c:Ljava/lang/Object;

    .line 14
    return-void

    .line 15
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 17
    const-string v0, "Failed requirement."

    .line 19
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 22
    move-result-object v0

    .line 23
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 26
    throw p1
.end method

.method public final compareTo(Ljava/lang/Object;)I
    .locals 4

    .line 1
    check-cast p1, La_53170983;

    .line 3
    const-wide/16 v0, 0x0

    .line 5
    const-wide/16 v2, 0x0

    .line 7
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    sub-long/2addr v0, v2

    .line 11
    cmp-long p1, v0, v2

    .line 13
    if-lez p1, :cond_0
    # ep-befkjccixkqz

    .line 15
    const/4 p1, 0x1

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    if-gez p1, :cond_1

    .line 19
    const/4 p1, -0x1

    .line 20
    # ep-pwxkbarxkmpp
    goto :goto_0

    .line 21
    :cond_1
    const/4 p1, 0x0

    .line 22
    :goto_0
    return p1
.end method

    # ep-rburydusfuvz
.method public final m_0f195fe1(I)V
    # ep-fpqlhpjbuzlc
    .locals 0
    # ep-prtuujabqoki

    # ep-uvydmuhihvzn
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;
    # ep-amwltmzrdmrr

    const-string v1, "Delayed[nanos="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-wide/16 v1, 0x0

    # ep-jfowrabkegsh
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/16 v1, 0x5d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
