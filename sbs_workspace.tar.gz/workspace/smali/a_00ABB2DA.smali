.class public final La_00ABB2DA;
# ep-hmqdhwbotfdb
.super Ljava/lang/Object;
# compiled-11755
# validated-54923
# validated-18117
.source "sgobkekn.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_BC92C3B9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/widget/TextView;)Landroid/view/textclassifier/TextClassifier;
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    .line 4
    move-result-object p0

    .line 5
    const-class v0, Landroid/view/textclassifier/TextClassificationManager;

    .line 7
    invoke-static {p0, v0}, La_B302BB44;->q(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;

    .line 10
    move-result-object p0

    .line 11
    check-cast p0, Landroid/view/textclassifier/TextClassificationManager;

    .line 13
    if-eqz p0, :cond_0

    .line 15
    invoke-static {p0}, Ln;->q(Landroid/view/textclassifier/TextClassificationManager;)Landroid/view/textclassifier/TextClassifier;

    .line 18
    move-result-object p0

    .line 19
    return-object p0

    .line 20
    :cond_0
    invoke-static {}, Ln;->p()Landroid/view/textclassifier/TextClassifier;

    .line 23
    move-result-object p0

    .line 24
    return-object p0
.end method
