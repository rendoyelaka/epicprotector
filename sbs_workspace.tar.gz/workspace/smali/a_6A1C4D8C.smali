.class public interface abstract La_6A1C4D8C;
.super Ljava/lang/Object;
.source "suzkiwhe.java"

# ep-exgncticpnbt
# compiled-90093

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_71A7ED5C;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(La_71A7ED5C;Landroid/view/MenuItem;)Z
.end method

.method public abstract b(La_71A7ED5C;)V
.end method

.method public abstract c(La_71A7ED5C;Landroidx/appcompat/view/menu/f;)Z
.end method

.method public abstract d(La_71A7ED5C;Landroidx/appcompat/view/menu/f;)Z
.end method
