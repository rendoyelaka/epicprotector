.class public final La_5D996B39;
.super La_A1EFABAF;
.source "ajzbokxk.java"


# processed-12340
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_A1EFABAF;-><init>()V

    return-void
.end method
