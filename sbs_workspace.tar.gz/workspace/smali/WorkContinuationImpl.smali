.class public final LWorkContinuationImpl;
.super Ln00;
.source "wtqcfkjb.java"
# ep-ordtnknadiqg

# compiled-10264

# instance fields
.field public final c:LWorkManagerImpl;

.field public final d:Ljava/lang/String;

.field public final e:Lkc;

.field public final f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "+",
            "Lx00;",
            ">;"
        }
    .end annotation
.end field

.field public final g:Ljava/util/ArrayList;

.field public final h:Ljava/util/ArrayList;

.field public final i:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LWorkContinuationImpl;",
            ">;"
        }
    .end annotation
.end field

.field public j:Z

.field public k:Lpn;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "WorkContinuationImpl"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method

.method public constructor <init>(LWorkManagerImpl;Ljava/lang/String;Lkc;Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LWorkManagerImpl;",
            "Ljava/lang/String;",
            "Lkc;",
            "Ljava/util/List<",
            "+",
            "Lx00;",
            ">;)V"
        }
    .end annotation

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    .line 1
    invoke-direct/range {v0 .. v5}, LWorkContinuationImpl;-><init>(LWorkManagerImpl;Ljava/lang/String;Lkc;Ljava/util/List;I)V

    return-void
.end method

.method public constructor <init>(LWorkManagerImpl;Ljava/lang/String;Lkc;Ljava/util/List;I)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ln00;-><init>()V

    .line 3
    iput-object p1, p0, LWorkContinuationImpl;->c:LWorkManagerImpl;

    .line 4
    iput-object p2, p0, LWorkContinuationImpl;->d:Ljava/lang/String;

    .line 5
    iput-object p3, p0, LWorkContinuationImpl;->e:Lkc;

    .line 6
    iput-object p4, p0, LWorkContinuationImpl;->f:Ljava/util/List;

    const/4 p1, 0x0

    .line 7
    iput-object p1, p0, LWorkContinuationImpl;->i:Ljava/util/List;

    .line 8
    new-instance p1, Ljava/util/ArrayList;

    invoke-interface {p4}, Ljava/util/List;->size()I

    move-result p2

    invoke-direct {p1, p2}, Ljava/util/ArrayList;-><init>(I)V

    iput-object p1, p0, LWorkContinuationImpl;->g:Ljava/util/ArrayList;

    .line 9
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LWorkContinuationImpl;->h:Ljava/util/ArrayList;

    const/4 p1, 0x0

    .line 10
    :goto_0
    invoke-interface {p4}, Ljava/util/List;->size()I

    move-result p2

    if-ge p1, p2, :cond_0

    .line 11
    invoke-interface {p4, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lx00;

    .line 12
    iget-object p2, p2, Lx00;->a:Ljava/util/UUID;

    .line 13
    invoke-virtual {p2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object p2

    .line 14
    iget-object p3, p0, LWorkContinuationImpl;->g:Ljava/util/ArrayList;

    invoke-virtual {p3, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 15
    iget-object p3, p0, LWorkContinuationImpl;->h:Ljava/util/ArrayList;

    invoke-virtual {p3, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public static q(LWorkContinuationImpl;Ljava/util/HashSet;)Z
    .locals 4

    .line 1
    iget-object v0, p0, LWorkContinuationImpl;->g:Ljava/util/ArrayList;

    .line 3
    invoke-interface {p1, v0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 6
    invoke-static {p0}, LWorkContinuationImpl;->r(LWorkContinuationImpl;)Ljava/util/HashSet;

    .line 9
    move-result-object v0

    .line 10
    invoke-virtual {p1}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 13
    move-result-object v1

    .line 14
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    move-result v2

    .line 18
    const/4 v3, 0x1

    .line 19
    if-eqz v2, :cond_1

    .line 21
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 24
    move-result-object v2

    .line 25
    check-cast v2, Ljava/lang/String;

    .line 27
    invoke-virtual {v0, v2}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 30
    move-result v2

    .line 31
    if-eqz v2, :cond_0

    .line 33
    return v3

    .line 34
    :cond_1
    iget-object v0, p0, LWorkContinuationImpl;->i:Ljava/util/List;

    .line 36
    if-eqz v0, :cond_3

    .line 38
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 41
    move-result v1

    .line 42
    if-nez v1, :cond_3

    .line 44
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 47
    move-result-object v0

    .line 48
    :cond_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 51
    move-result v1

    .line 52
    if-eqz v1, :cond_3

    .line 54
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 57
    move-result-object v1

    .line 58
    check-cast v1, LWorkContinuationImpl;

    .line 60
    invoke-static {v1, p1}, LWorkContinuationImpl;->q(LWorkContinuationImpl;Ljava/util/HashSet;)Z

    .line 63
    move-result v1

    .line 64
    if-eqz v1, :cond_2

    .line 66
    return v3

    .line 67
    :cond_3
    iget-object p0, p0, LWorkContinuationImpl;->g:Ljava/util/ArrayList;

    .line 69
    invoke-interface {p1, p0}, Ljava/util/Set;->removeAll(Ljava/util/Collection;)Z

    .line 72
    const/4 p0, 0x0

    .line 73
    return p0
.end method

.method public static r(LWorkContinuationImpl;)Ljava/util/HashSet;
    .locals 2

    .line 1
    new-instance v0, Ljava/util/HashSet;

    .line 3
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 6
    iget-object p0, p0, LWorkContinuationImpl;->i:Ljava/util/List;

    .line 8
    if-eqz p0, :cond_0

    .line 10
    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    .line 13
    move-result v1

    .line 14
    if-nez v1, :cond_0

    .line 16
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 19
    move-result-object p0

    .line 20
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 23
    move-result v1

    .line 24
    if-eqz v1, :cond_0

    .line 26
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 29
    move-result-object v1

    .line 30
    check-cast v1, LWorkContinuationImpl;

    .line 32
    iget-object v1, v1, LWorkContinuationImpl;->g:Ljava/util/ArrayList;

    .line 34
    invoke-interface {v0, v1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    return-object v0
.end method


# virtual methods
.method public final p()Lon;
    .locals 4

    .line 1
    iget-boolean v0, p0, LWorkContinuationImpl;->j:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, LEnqueueRunnable;

    .line 7
    invoke-direct {v0, p0}, LEnqueueRunnable;-><init>(LWorkContinuationImpl;)V

    .line 10
    iget-object v1, p0, LWorkContinuationImpl;->c:LWorkManagerImpl;

    .line 12
    iget-object v1, v1, LWorkManagerImpl;->f:Lnu;

    .line 14
    check-cast v1, Lp00;

    .line 16
    invoke-virtual {v1, v0}, Lp00;->a(Ljava/lang/Runnable;)V

    .line 19
    iget-object v0, v0, LEnqueueRunnable;->d:Lpn;

    .line 21
    iput-object v0, p0, LWorkContinuationImpl;->k:Lpn;

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    invoke-static {}, Ltj;->c()Ltj;

    .line 27
    move-result-object v0

    .line 28
    const/4 v1, 0x1

    .line 29
    new-array v1, v1, [Ljava/lang/Object;

    .line 31
    iget-object v2, p0, LWorkContinuationImpl;->g:Ljava/util/ArrayList;

    .line 33
    const-string v3, ", "

    .line 35
    invoke-static {v3, v2}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    .line 38
    move-result-object v2

    .line 39
    const/4 v3, 0x0

    .line 40
    aput-object v2, v1, v3

    .line 42
    const-string v2, "Already enqueued work ids (%s)"

    .line 44
    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 47
    new-array v1, v3, [Ljava/lang/Throwable;

    .line 49
    invoke-virtual {v0, v1}, Ltj;->f([Ljava/lang/Throwable;)V

    .line 52
    :goto_0
    iget-object v0, p0, LWorkContinuationImpl;->k:Lpn;

    .line 54
    return-object v0
.end method
