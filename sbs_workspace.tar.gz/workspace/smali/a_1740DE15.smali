.class public final La_1740DE15;
.super La_17C7FC47;
.source "pahimdcr.java"


# generated-23355
# validated-16053
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_17C7FC47;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final b:La_1740DE15;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_1740DE15;

    invoke-direct {v0}, La_1740DE15;-><init>()V

    sput-object v0, La_1740DE15;->b:La_1740DE15;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_17C7FC47;-><init>()V

    return-void
.end method
