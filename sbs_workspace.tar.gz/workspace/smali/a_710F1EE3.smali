.class public interface abstract La_710F1EE3;
.super Ljava/lang/Object;
# compiled-92540
# ep-lywdnsvfoxuq
.source "prcefuht.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_A1744591;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
