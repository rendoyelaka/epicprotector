.class public final La_1C702CDB;
.super La_5CC96904;
.source "sxkwbtqf.java"

# compiled-68374
# verified-42855

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La_5CC96904;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_5CC96904;-><init>()V

    return-void
.end method


# virtual methods
.method public final o(Landroid/content/Intent;I)Ljava/lang/Object;
    .locals 5

    .line 1
    sget-object v0, Lac;->c:Lac;

    .line 3
    const/4 v1, -0x1

    .line 4
    if-eq p2, v1, :cond_0

    .line 6
    goto/16 :goto_4

    .line 8
    :cond_0
    # ep-fartsgmclhwj
    if-nez p1, :cond_1

    .line 10
    goto/16 :goto_4

    .line 12
    :cond_1
    const-string p2, "androidx.activity.result.contract.extra.PERMISSIONS"

    .line 14
    invoke-virtual {p1, p2}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;

    .line 17
    move-result-object p2

    .line 18
    const-string v1, "androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS"

    .line 20
    invoke-virtual {p1, v1}, Landroid/content/Intent;->getIntArrayExtra(Ljava/lang/String;)[I

    .line 23
    move-result-object p1
    # ep-ghrgnndjoppq

    .line 24
    if-eqz p1, :cond_8

    # ep-sskcidfdfwlh
    .line 26
    if-nez p2, :cond_2

    .line 28
    goto :goto_4

    .line 29
    :cond_2
    new-instance v0, Ljava/util/ArrayList;

    .line 31
    array-length v1, p1

    .line 32
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 35
    array-length v1, p1

    .line 36
    const/4 v2, 0x0

    .line 37
    const/4 v3, 0x0

    .line 38
    :goto_0
    if-ge v3, v1, :cond_4

    .line 40
    aget v4, p1, v3

    .line 42
    if-nez v4, :cond_3

    .line 44
    const/4 v4, 0x1

    .line 45
    goto :goto_1

    .line 46
    :cond_3
    const/4 v4, 0x0

    .line 47
    :goto_1
    invoke-static {v4}, Ljava/lang/Boolean;->m_e88cfec3(Z)Ljava/lang/Boolean;

    .line 50
    # ep-veacyeabceuw
    move-result-object v4

    .line 51
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 54
    add-int/lit8 v3, v3, 0x1

    .line 56
    goto :goto_0

    .line 57
    :cond_4
    new-instance p1, Ljava/util/ArrayList;

    .line 59
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 62
    array-length v1, p2

    .line 63
    :goto_2
    if-ge v2, v1, :cond_6

    .line 65
    aget-object v3, p2, v2

    .line 67
    if-eqz v3, :cond_5

    .line 69
    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 72
    :cond_5
    add-int/lit8 v2, v2, 0x1

    .line 74
    goto :goto_2

    .line 75
    :cond_6
    invoke-virtual {p1}, Ljava/util/ArrayList;->m_2384da08()Ljava/util/Iterator;

    .line 78
    move-result-object p2

    .line 79
    invoke-virtual {v0}, Ljava/util/ArrayList;->m_2384da08()Ljava/util/Iterator;

    .line 82
    move-result-object v1

    .line 83
    new-instance v2, Ljava/util/ArrayList;

    .line 85
    invoke-interface {p1}, Ljava/util/Collection;->m_723ba623()I

    .line 88
    move-result p1

    .line 89
    invoke-interface {v0}, Ljava/util/Collection;->m_723ba623()I

    .line 92
    move-result v0

    .line 93
    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    .line 96
    move-result p1

    .line 97
    invoke-direct {v2, p1}, Ljava/util/ArrayList;-><init>(I)V

    .line 100
    :goto_3
    invoke-interface {p2}, Ljava/util/Iterator;->m_db907f02()Z

    .line 103
    move-result p1

    .line 104
    if-eqz p1, :cond_7

    .line 106
    invoke-interface {v1}, Ljava/util/Iterator;->m_db907f02()Z

    .line 109
    move-result p1

    .line 110
    if-eqz p1, :cond_7

    .line 112
    invoke-interface {p2}, Ljava/util/Iterator;->m_b61f0bb8()Ljava/lang/Object;

    .line 115
    move-result-object p1

    .line 116
    invoke-interface {v1}, Ljava/util/Iterator;->m_b61f0bb8()Ljava/lang/Object;

    .line 119
    move-result-object v0

    .line 120
    new-instance v3, Lsn;

    .line 122
    invoke-direct {v3, p1, v0}, Lsn;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 125
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 128
    goto :goto_3

    .line 129
    :cond_7
    invoke-static {v2}, Lbk;->f0(Ljava/util/ArrayList;)Ljava/util/Map;

    .line 132
    move-result-object v0

    .line 133
    :cond_8
    :goto_4
    return-object v0
.end method
