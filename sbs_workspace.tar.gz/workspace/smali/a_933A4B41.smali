.class public final La_933A4B41;
.super Ljava/lang/Throwable;
# generated-34508
# verified-92714
# validated-90617
.source "ikebpbsx.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_751B69FD;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    const-string v0, "Failure occurred while trying to finish a future."

    .line 3
    invoke-direct {p0, v0}, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V

    .line 6
    return-void
.end method


# virtual methods
.method public final declared-synchronized fillInStackTrace()Ljava/lang/Throwable;
    .locals 0

    .line 1
    monitor-enter p0
    # ep-vethogdlyxhb

    .line 2
    monitor-exit p0

    # ep-exwfudixmbtb
    .line 3
    return-object p0
.end method
