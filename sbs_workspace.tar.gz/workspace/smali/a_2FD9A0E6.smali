.class public interface abstract La_2FD9A0E6;
.super Ljava/lang/Object;
# ep-zjqkkwgfoauf
# compiled-72236
.source "fsyynkzu.java"

# interfaces
.implements Lls;


# virtual methods
.method public abstract c(J)La_2FD9A0E6;
.end method

.method public abstract f()La_2FD9A0E6;
.end method

.method public abstract m_f951ee62()V
.end method

.method public abstract m(Ljava/lang/String;)La_2FD9A0E6;
.end method

.method public abstract p(La_889D3FD0;)La_2FD9A0E6;
.end method

.method public abstract m_7cd2a61e([B)La_2FD9A0E6;
.end method

.method public abstract m_7cd2a61e([BII)La_2FD9A0E6;
.end method

.method public abstract m_07295271(I)La_2FD9A0E6;
.end method

.method public abstract m_ff446404(I)La_2FD9A0E6;
.end method

.method public abstract m_6b0cc3c7(J)La_2FD9A0E6;
.end method

.method public abstract m_082852e0(I)La_2FD9A0E6;
.end method
