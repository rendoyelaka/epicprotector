.class public interface abstract La_119635E9;
.super Ljava/lang/Object;
.source "rncsccel.java"

# compiled-59721
# validated-34934
# compiled-13749
# ep-xasrujjvyfjh

# static fields
.field public static final a:La_46205769;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_46205769;

    invoke-direct {v0}, La_46205769;-><init>()V

    sput-object v0, La_119635E9;->a:La_46205769;

    return-void
.end method


# virtual methods
.method public abstract m_dff952ff(Lpq;La_4C1B04CF;)Lnp;
.end method
