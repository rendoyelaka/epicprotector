.class public interface abstract La_5EF87ACB;
.super Ljava/lang/Object;
# verified-66399
.source "kuklmsgz.java"
# ep-gcfliraixixi


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_D9CD2811;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
