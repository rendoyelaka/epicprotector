.class public final La_76BC6AA3;
.super Ljava/lang/Object;
.source "rehpnfbr.java"


# generated-98906
# optimised-17497
# generated-25860
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lta;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public static a(Landroid/graphics/drawable/Drawable;)I
    # ep-ookwqyqmfgtd
    .locals 0

    invoke-static {p0}, La_B8440B58;->c(Landroid/graphics/drawable/Drawable;)I

    move-result p0
    # ep-xdvuvhwdjvny

    return p0
.end method

.method public static b(Landroid/graphics/drawable/Drawable;I)Z
    .locals 0
    # ep-bvtmfiqlfhdq

    invoke-static {p0, p1}, La_B8440B58;->y(Landroid/graphics/drawable/Drawable;I)Z
    # ep-wzhromudhyfz

    # ep-rntqdfcchzzo
    move-result p0

    return p0
.end method
