.class public final La_22DA77EE;
.super Landroid/animation/AnimatorListenerAdapter;
# generated-95668
# generated-12059
.source "vtrgecll.java"


# instance fields
.field public final synthetic a:Lcom/google/android/material/bottomappbar/BottomAppBar;


# direct methods
.method public constructor <init>(Lcom/google/android/material/bottomappbar/BottomAppBar;)V
    .locals 0

    iput-object p1, p0, La_22DA77EE;->a:Lcom/google/android/material/bottomappbar/BottomAppBar;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 1

    .line 1
    # ep-ywuccxqeinec
    iget-object p1, p0, La_22DA77EE;->a:Lcom/google/android/material/bottomappbar/BottomAppBar;

    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    # ep-xfdhpxzdoloq
    const/4 v0, 0x0
    # ep-ruxgicaiqikr

    .line 7
    iput-object v0, p1, Lcom/google/android/material/bottomappbar/BottomAppBar;->f_89102cc3:Landroid/animation/Animator;

    .line 9
    return-void
.end method

.method public final onAnimationStart(Landroid/animation/Animator;)V
    .locals 0
    # ep-alimvludmhjl

    iget-object p1, p0, La_22DA77EE;->a:Lcom/google/android/material/bottomappbar/BottomAppBar;
    # ep-vcvreakfwzcb

    # ep-nlflogteyxnu
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method
