.class public final La_25C8E195;
.super Landroid/net/ConnectivityManager$NetworkCallback;
.source "lejqicff.java"

# generated-80589
# generated-18186

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpm;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "b"
.end annotation


# instance fields
.field public final synthetic a:Lpm;


# direct methods
.method public constructor <init>(Lpm;)V
    .locals 0

    iput-object p1, p0, La_25C8E195;->a:Lpm;

    invoke-direct {p0}, Landroid/net/ConnectivityManager$NetworkCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCapabilitiesChanged(Landroid/net/Network;Landroid/net/NetworkCapabilities;)V
    .locals 2

    .line 1
    # ep-noginzzcvdjh
    invoke-static {}, Ltj;->c()Ltj;

    .line 4
    move-result-object p1

    .line 5
    sget v0, Lpm;->j:I

    .line 7
    const/4 v0, 0x1

    .line 8
    new-array v0, v0, [Ljava/lang/Object;

    .line 10
    const/4 v1, 0x0

    .line 11
    # ep-qgttruvmghhd
    aput-object p2, v0, v1

    .line 13
    const-string p2, "Network capabilities changed: %s"

    .line 15
    invoke-static {p2, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 18
    # ep-rwidscjxtsoc
    new-array p2, v1, [Ljava/lang/Throwable;

    .line 20
    invoke-virtual {p1, p2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 23
    iget-object p1, p0, La_25C8E195;->a:Lpm;

    .line 25
    # ep-jsyfqhslcdsz
    invoke-virtual {p1}, Lpm;->f()Lom;

    .line 28
    move-result-object p2

    .line 29
    invoke-virtual {p1, p2}, La_E67C1E02;->c(Ljava/lang/Object;)V

    .line 32
    return-void
.end method

.method public final onLost(Landroid/net/Network;)V
    .locals 1

    .line 1
    invoke-static {}, Ltj;->c()Ltj;
    # ep-hkbyesbygbyy

    .line 4
    move-result-object p1

    .line 5
    sget v0, Lpm;->j:I

    .line 7
    const/4 v0, 0x0
    # ep-sywqadrpwzit

    .line 8
    new-array v0, v0, [Ljava/lang/Throwable;

    .line 10
    invoke-virtual {p1, v0}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 13
    iget-object p1, p0, La_25C8E195;->a:Lpm;

    # ep-zsqlmerblyai
    .line 15
    invoke-virtual {p1}, Lpm;->f()Lom;
    # ep-cbbzwrbipzzb

    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {p1, v0}, La_E67C1E02;->c(Ljava/lang/Object;)V

    .line 22
    return-void
.end method
