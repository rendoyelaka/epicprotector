.class public final La_77BE268B;
.super Ljava/lang/Object;
.source "btbpzuhd.java"

# optimised-22951
# interfaces
.implements Landroid/view/animation/Interpolator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lux;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_47f57e34(F)F
    # ep-cqsygnfppeew
    .locals 2

    # ep-rmubztxsclri
    const/high16 v0, 0x3f800000    # 1.0f

    sub-float/2addr p1, v0

    mul-float v1, p1, p1

    mul-float v1, v1, p1

    mul-float v1, v1, p1
    # ep-zrhzridzscom

    mul-float v1, v1, p1

    add-float/2addr v1, v0

    return v1
.end method
