.class public final LStopWorkRunnable;
.super Ljava/lang/Object;
.source "DialogManager16.java"
# generated-37953

# ep-yvjbpeqzdyio
# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final c:LWorkManagerImpl;

.field public final d:Ljava/lang/String;

.field public final e:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "StopWorkRunnable"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(LWorkManagerImpl;Ljava/lang/String;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, LStopWorkRunnable;->c:LWorkManagerImpl;

    .line 6
    iput-object p2, p0, LStopWorkRunnable;->d:Ljava/lang/String;

    .line 8
    iput-boolean p3, p0, LStopWorkRunnable;->e:Z

    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 8

    .line 1
    iget-object v0, p0, LStopWorkRunnable;->c:LWorkManagerImpl;

    .line 3
    iget-object v1, v0, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 5
    iget-object v0, v0, LWorkManagerImpl;->h:Luo;

    .line 7
    invoke-virtual {v1}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 10
    move-result-object v2

    .line 11
    invoke-virtual {v1}, Ljq;->c()V

    .line 14
    :try_start_0
    iget-object v3, p0, LStopWorkRunnable;->d:Ljava/lang/String;

    .line 16
    iget-object v4, v0, Luo;->m:Ljava/lang/Object;

    .line 18
    monitor-enter v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 19
    :try_start_1
    iget-object v0, v0, Luo;->h:Ljava/util/HashMap;

    .line 21
    invoke-virtual {v0, v3}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 24
    move-result v0

    .line 25
    monitor-exit v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 26
    :try_start_2
    iget-boolean v3, p0, LStopWorkRunnable;->e:Z

    .line 28
    const/4 v4, 0x1

    .line 29
    const/4 v5, 0x0

    .line 30
    if-eqz v3, :cond_0

    .line 32
    iget-object v0, p0, LStopWorkRunnable;->c:LWorkManagerImpl;

    .line 34
    iget-object v0, v0, LWorkManagerImpl;->h:Luo;

    .line 36
    iget-object v2, p0, LStopWorkRunnable;->d:Ljava/lang/String;

    .line 38
    invoke-virtual {v0, v2}, Luo;->j(Ljava/lang/String;)Z

    .line 41
    move-result v0

    .line 42
    goto :goto_0

    .line 43
    :cond_0
    if-nez v0, :cond_1

    .line 45
    iget-object v0, p0, LStopWorkRunnable;->d:Ljava/lang/String;

    .line 47
    check-cast v2, LWorkSpecDao;

    .line 49
    invoke-virtual {v2, v0}, LWorkSpecDao;->f(Ljava/lang/String;)LWorkInfo_State;

    .line 52
    move-result-object v0

    .line 53
    sget-object v3, LWorkInfo_State;->d:LWorkInfo_State;

    .line 55
    if-ne v0, v3, :cond_1

    .line 57
    sget-object v0, LWorkInfo_State;->c:LWorkInfo_State;

    .line 59
    new-array v3, v4, [Ljava/lang/String;

    .line 61
    iget-object v6, p0, LStopWorkRunnable;->d:Ljava/lang/String;

    .line 63
    aput-object v6, v3, v5

    .line 65
    invoke-virtual {v2, v0, v3}, LWorkSpecDao;->m(LWorkInfo_State;[Ljava/lang/String;)I

    .line 68
    :cond_1
    iget-object v0, p0, LStopWorkRunnable;->c:LWorkManagerImpl;

    .line 70
    iget-object v0, v0, LWorkManagerImpl;->h:Luo;

    .line 72
    iget-object v2, p0, LStopWorkRunnable;->d:Ljava/lang/String;

    .line 74
    invoke-virtual {v0, v2}, Luo;->k(Ljava/lang/String;)Z

    .line 77
    move-result v0

    .line 78
    :goto_0
    invoke-static {}, Ltj;->c()Ltj;

    .line 81
    move-result-object v2

    .line 82
    const-string v3, "StopWorkRunnable for %s; Processor.stopWork = %s"

    .line 84
    const/4 v6, 0x2

    .line 85
    new-array v6, v6, [Ljava/lang/Object;

    .line 87
    iget-object v7, p0, LStopWorkRunnable;->d:Ljava/lang/String;

    .line 89
    aput-object v7, v6, v5

    .line 91
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 94
    move-result-object v0

    .line 95
    aput-object v0, v6, v4

    .line 97
    invoke-static {v3, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 100
    new-array v0, v5, [Ljava/lang/Throwable;

    .line 102
    invoke-virtual {v2, v0}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 105
    invoke-virtual {v1}, Ljq;->h()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 108
    invoke-virtual {v1}, Ljq;->f()V

    .line 111
    return-void

    .line 112
    :catchall_0
    move-exception v0

    .line 113
    :try_start_3
    monitor-exit v4
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 114
    :try_start_4
    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 115
    :catchall_1
    move-exception v0

    .line 116
    invoke-virtual {v1}, Ljq;->f()V

    .line 119
    throw v0
.end method
