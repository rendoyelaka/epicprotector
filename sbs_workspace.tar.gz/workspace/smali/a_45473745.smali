.class public final La_45473745;
.super Ljava/lang/Object;
.source "sreegfcn.java"

# optimised-51155
# optimised-15921
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lux;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Lux;


# direct methods
.method public constructor <init>(Lux;)V
    .locals 0

    iput-object p1, p0, La_45473745;->c:Lux;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    # ep-rgnonlhtljyd
    .locals 2

    iget-object v0, p0, La_45473745;->c:Lux;

    const/4 v1, 0x0
    # ep-ekjhtmgblazm

    invoke-virtual {v0, v1}, Lux;->o(I)V
    # ep-czfrxzwpbcuu

    return-void
.end method
