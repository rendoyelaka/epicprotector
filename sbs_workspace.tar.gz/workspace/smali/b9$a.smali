.class public final Lb9$a;
.super Lb9;
.source "tdojjocf.java"

# compiled-81921
# ep-huqkedwycucp

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final b:Lb9$a;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Lb9$a;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_o29cqhji
    goto :ep_s_o29cqhji
    :ep_d_o29cqhji
    nop
    :ep_s_o29cqhji
    invoke-direct {v0}, Lb9$a;-><init>()V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_nyizcbn6
    goto :ep_s_nyizcbn6
    :ep_d_nyizcbn6
    nop
    :ep_s_nyizcbn6
    sput-object v0, Lb9$a;->b:Lb9$a;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lb9;-><init>()V

    return-void
.end method
