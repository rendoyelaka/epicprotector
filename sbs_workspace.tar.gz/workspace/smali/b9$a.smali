.class public final Lb9$a;
# ep-tsakcjmoqnpk
.super Lb9;
.source "CredentialHelper13.java"

# generated-39972
# generated-24615
# generated-66763

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final b:Lb9$a;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Lb9$a;

    invoke-direct {v0}, Lb9$a;-><init>()V

    sput-object v0, Lb9$a;->b:Lb9$a;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lb9;-><init>()V

    return-void
.end method
