.class public final LWorkSpecDao$a;
.super Lec;
.source "yayorfqe.java"
# processed-16295
# optimised-92356
# validated-73788

# ep-qevizvimioze

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lec<",
        "LWorkSpec;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lec;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "INSERT OR IGNORE INTO `WorkSpec` (`id`,`state`,`worker_class_name`,`input_merger_class_name`,`input`,`output`,`initial_delay`,`interval_duration`,`flex_duration`,`run_attempt_count`,`backoff_policy`,`backoff_delay_duration`,`period_start_time`,`minimum_retention_duration`,`schedule_requested_at`,`run_in_foreground`,`out_of_quota_policy`,`required_network_type`,`requires_charging`,`requires_device_idle`,`requires_battery_not_low`,`requires_storage_not_low`,`trigger_content_update_delay`,`trigger_max_content_delay`,`content_uri_triggers`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

    return-object v0
.end method

.method public final d(Lue;Ljava/lang/Object;)V
    .locals 16

    .line 1
    move-object/from16 v1, p1

    .line 3
    move-object/from16 v0, p2

    .line 5
    check-cast v0, LWorkSpec;

    .line 7
    iget-object v2, v0, LWorkSpec;->a:Ljava/lang/String;

    .line 9
    const/4 v3, 0x1

    .line 10
    if-nez v2, :cond_0

    .line 12
    invoke-virtual {v1, v3}, Lte;->s(I)V

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    invoke-virtual {v1, v2, v3}, Lte;->t(Ljava/lang/String;I)V

    .line 19
    :goto_0
    iget-object v2, v0, LWorkSpec;->b:LWorkInfo_State;

    .line 21
    invoke-static {v2}, Lf10;->f(LWorkInfo_State;)I

    .line 24
    move-result v2

    .line 25
    int-to-long v4, v2

    .line 26
    const/4 v2, 0x2

    .line 27
    invoke-virtual {v1, v2, v4, v5}, Lte;->r(IJ)V

    .line 30
    iget-object v4, v0, LWorkSpec;->c:Ljava/lang/String;

    .line 32
    const/4 v5, 0x3

    .line 33
    if-nez v4, :cond_1

    .line 35
    invoke-virtual {v1, v5}, Lte;->s(I)V

    .line 38
    goto :goto_1

    .line 39
    :cond_1
    invoke-virtual {v1, v4, v5}, Lte;->t(Ljava/lang/String;I)V

    .line 42
    :goto_1
    iget-object v4, v0, LWorkSpec;->d:Ljava/lang/String;

    .line 44
    const/4 v6, 0x4

    .line 45
    if-nez v4, :cond_2

    .line 47
    invoke-virtual {v1, v6}, Lte;->s(I)V

    .line 50
    goto :goto_2

    .line 51
    :cond_2
    invoke-virtual {v1, v4, v6}, Lte;->t(Ljava/lang/String;I)V

    .line 54
    :goto_2
    iget-object v4, v0, LWorkSpec;->e:Landroidx/work/b;

    .line 56
    invoke-static {v4}, Landroidx/work/b;->b(Landroidx/work/b;)[B

    .line 59
    move-result-object v4

    .line 60
    const/4 v7, 0x5

    .line 61
    if-nez v4, :cond_3

    .line 63
    invoke-virtual {v1, v7}, Lte;->s(I)V

    .line 66
    goto :goto_3

    .line 67
    :cond_3
    invoke-virtual {v1, v7, v4}, Lte;->h(I[B)V

    .line 70
    :goto_3
    iget-object v4, v0, LWorkSpec;->f:Landroidx/work/b;

    .line 72
    invoke-static {v4}, Landroidx/work/b;->b(Landroidx/work/b;)[B

    .line 75
    move-result-object v4

    .line 76
    const/4 v8, 0x6

    .line 77
    if-nez v4, :cond_4

    .line 79
    invoke-virtual {v1, v8}, Lte;->s(I)V

    .line 82
    goto :goto_4

    .line 83
    :cond_4
    invoke-virtual {v1, v8, v4}, Lte;->h(I[B)V

    .line 86
    :goto_4
    const/4 v4, 0x7

    .line 87
    iget-wide v8, v0, LWorkSpec;->g:J

    .line 89
    invoke-virtual {v1, v4, v8, v9}, Lte;->r(IJ)V

    .line 92
    const/16 v4, 0x8

    .line 94
    iget-wide v8, v0, LWorkSpec;->h:J

    .line 96
    invoke-virtual {v1, v4, v8, v9}, Lte;->r(IJ)V

    .line 99
    const/16 v4, 0x9

    .line 101
    iget-wide v8, v0, LWorkSpec;->i:J

    .line 103
    invoke-virtual {v1, v4, v8, v9}, Lte;->r(IJ)V

    .line 106
    iget v4, v0, LWorkSpec;->k:I

    .line 108
    int-to-long v8, v4

    .line 109
    const/16 v4, 0xa

    .line 111
    invoke-virtual {v1, v4, v8, v9}, Lte;->r(IJ)V

    .line 114
    iget v4, v0, LWorkSpec;->l:I

    .line 116
    invoke-static {v4}, Lps;->k(I)I

    .line 119
    move-result v8

    .line 120
    const-string v10, " to int"

    .line 122
    const-string v11, "Could not convert "

    .line 124
    if-eqz v8, :cond_6

    .line 126
    if-ne v8, v3, :cond_5

    .line 128
    const/4 v4, 0x1

    .line 129
    goto :goto_5

    .line 130
    :cond_5
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 132
    new-instance v1, Ljava/lang/StringBuilder;

    .line 134
    invoke-direct {v1, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 137
    invoke-static {v4}, Lps;->l(I)Ljava/lang/String;

    .line 140
    move-result-object v2

    .line 141
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 144
    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 147
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 150
    move-result-object v1

    .line 151
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 154
    throw v0

    .line 155
    :cond_6
    const/4 v4, 0x0

    .line 156
    :goto_5
    const/16 v8, 0xb

    .line 158
    int-to-long v12, v4

    .line 159
    invoke-virtual {v1, v8, v12, v13}, Lte;->r(IJ)V

    .line 162
    const/16 v4, 0xc

    .line 164
    iget-wide v12, v0, LWorkSpec;->m:J

    .line 166
    invoke-virtual {v1, v4, v12, v13}, Lte;->r(IJ)V

    .line 169
    const/16 v4, 0xd

    .line 171
    iget-wide v12, v0, LWorkSpec;->n:J

    .line 173
    invoke-virtual {v1, v4, v12, v13}, Lte;->r(IJ)V

    .line 176
    const/16 v4, 0xe

    .line 178
    iget-wide v12, v0, LWorkSpec;->o:J

    .line 180
    invoke-virtual {v1, v4, v12, v13}, Lte;->r(IJ)V

    .line 183
    const/16 v4, 0xf

    .line 185
    iget-wide v12, v0, LWorkSpec;->p:J

    .line 187
    invoke-virtual {v1, v4, v12, v13}, Lte;->r(IJ)V

    .line 190
    iget-boolean v4, v0, LWorkSpec;->q:Z

    .line 192
    const/16 v8, 0x10

    .line 194
    int-to-long v12, v4

    .line 195
    invoke-virtual {v1, v8, v12, v13}, Lte;->r(IJ)V

    .line 198
    iget v4, v0, LWorkSpec;->r:I

    .line 200
    invoke-static {v4}, Lps;->k(I)I

    .line 203
    move-result v8

    .line 204
    if-eqz v8, :cond_8

    .line 206
    if-ne v8, v3, :cond_7

    .line 208
    const/4 v4, 0x1

    .line 209
    goto :goto_6

    .line 210
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 212
    new-instance v1, Ljava/lang/StringBuilder;

    .line 214
    invoke-direct {v1, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 217
    invoke-static {v4}, Lps;->o(I)Ljava/lang/String;

    .line 220
    move-result-object v2

    .line 221
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 224
    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 227
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 230
    move-result-object v1

    .line 231
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 234
    throw v0

    .line 235
    :cond_8
    const/4 v4, 0x0

    .line 236
    :goto_6
    const/16 v8, 0x11

    .line 238
    int-to-long v12, v4

    .line 239
    invoke-virtual {v1, v8, v12, v13}, Lte;->r(IJ)V

    .line 242
    iget-object v0, v0, LWorkSpec;->j:Lf8;

    .line 244
    const/16 v12, 0x17

    .line 246
    const/16 v13, 0x16

    .line 248
    const/16 v14, 0x15

    .line 250
    const/16 v15, 0x14

    .line 252
    const/16 v7, 0x13

    .line 254
    const/16 v9, 0x12

    .line 256
    if-eqz v0, :cond_14

    .line 258
    iget-object v8, v0, Lf8;->a:Lqm;

    .line 260
    invoke-virtual {v8}, Ljava/lang/Enum;->ordinal()I

    .line 263
    move-result v4

    .line 264
    if-eqz v4, :cond_d

    .line 266
    if-eq v4, v3, :cond_e

    .line 268
    if-eq v4, v2, :cond_c

    .line 270
    if-eq v4, v5, :cond_b

    .line 272
    if-eq v4, v6, :cond_a

    .line 274
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 276
    const/16 v3, 0x1e

    .line 278
    if-lt v2, v3, :cond_9

    .line 280
    sget-object v2, Lqm;->h:Lqm;

    .line 282
    if-ne v8, v2, :cond_9

    .line 284
    const/4 v3, 0x5

    .line 285
    goto :goto_7

    .line 286
    :cond_9
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 288
    new-instance v1, Ljava/lang/StringBuilder;

    .line 290
    invoke-direct {v1, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 293
    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 296
    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 299
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 302
    move-result-object v1

    .line 303
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 306
    throw v0

    .line 307
    :cond_a
    const/4 v3, 0x4

    .line 308
    goto :goto_7

    .line 309
    :cond_b
    const/4 v3, 0x3

    .line 310
    goto :goto_7

    .line 311
    :cond_c
    const/4 v3, 0x2

    .line 312
    goto :goto_7

    .line 313
    :cond_d
    const/4 v3, 0x0

    .line 314
    :cond_e
    :goto_7
    int-to-long v2, v3

    .line 315
    invoke-virtual {v1, v9, v2, v3}, Lte;->r(IJ)V

    .line 318
    iget-boolean v2, v0, Lf8;->b:Z

    .line 320
    int-to-long v2, v2

    .line 321
    invoke-virtual {v1, v7, v2, v3}, Lte;->r(IJ)V

    .line 324
    iget-boolean v2, v0, Lf8;->c:Z

    .line 326
    int-to-long v2, v2

    .line 327
    invoke-virtual {v1, v15, v2, v3}, Lte;->r(IJ)V

    .line 330
    iget-boolean v2, v0, Lf8;->d:Z

    .line 332
    int-to-long v2, v2

    .line 333
    invoke-virtual {v1, v14, v2, v3}, Lte;->r(IJ)V

    .line 336
    iget-boolean v2, v0, Lf8;->e:Z

    .line 338
    int-to-long v2, v2

    .line 339
    invoke-virtual {v1, v13, v2, v3}, Lte;->r(IJ)V

    .line 342
    iget-wide v2, v0, Lf8;->f:J

    .line 344
    invoke-virtual {v1, v12, v2, v3}, Lte;->r(IJ)V

    .line 347
    iget-wide v2, v0, Lf8;->g:J

    .line 349
    const/16 v4, 0x18

    .line 351
    invoke-virtual {v1, v4, v2, v3}, Lte;->r(IJ)V

    .line 354
    iget-object v0, v0, Lf8;->h:Ll8;

    .line 356
    iget-object v2, v0, Ll8;->a:Ljava/util/HashSet;

    .line 358
    invoke-virtual {v2}, Ljava/util/HashSet;->size()I

    .line 361
    move-result v2

    .line 362
    const/4 v3, 0x0

    .line 363
    if-nez v2, :cond_f

    .line 365
    goto/16 :goto_f

    .line 367
    :cond_f
    new-instance v2, Ljava/io/ByteArrayOutputStream;

    .line 369
    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 372
    :try_start_0
    new-instance v4, Ljava/io/ObjectOutputStream;

    .line 374
    invoke-direct {v4, v2}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 377
    iget-object v0, v0, Ll8;->a:Ljava/util/HashSet;

    .line 379
    :try_start_1
    invoke-virtual {v0}, Ljava/util/HashSet;->size()I

    .line 382
    move-result v3

    .line 383
    invoke-virtual {v4, v3}, Ljava/io/ObjectOutputStream;->writeInt(I)V

    .line 386
    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 389
    move-result-object v0

    .line 390
    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 393
    move-result v3

    .line 394
    if-eqz v3, :cond_10

    .line 396
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 399
    move-result-object v3

    .line 400
    check-cast v3, Ll8$a;

    .line 402
    iget-object v5, v3, Ll8$a;->a:Landroid/net/Uri;

    .line 404
    invoke-virtual {v5}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 407
    move-result-object v5

    .line 408
    invoke-virtual {v4, v5}, Ljava/io/ObjectOutputStream;->writeUTF(Ljava/lang/String;)V

    .line 411
    iget-boolean v3, v3, Ll8$a;->b:Z

    .line 413
    invoke-virtual {v4, v3}, Ljava/io/ObjectOutputStream;->writeBoolean(Z)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 416
    goto :goto_8

    .line 417
    :catchall_0
    move-exception v0

    .line 418
    goto :goto_a

    .line 419
    :catch_0
    move-exception v0

    .line 420
    goto :goto_b

    .line 421
    :cond_10
    :try_start_2
    invoke-virtual {v4}, Ljava/io/ObjectOutputStream;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    .line 424
    goto :goto_9

    .line 425
    :catch_1
    move-exception v0

    .line 426
    move-object v3, v0

    .line 427
    invoke-virtual {v3}, Ljava/lang/Throwable;->printStackTrace()V

    .line 430
    :cond_11
    :goto_9
    :try_start_3
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_2

    .line 433
    goto :goto_e

    .line 434
    :catch_2
    move-exception v0

    .line 435
    goto :goto_d

    .line 436
    :goto_a
    move-object v1, v0

    .line 437
    goto :goto_11

    .line 438
    :goto_b
    move-object v3, v4

    .line 439
    goto :goto_c

    .line 440
    :catchall_1
    move-exception v0

    .line 441
    goto :goto_10

    .line 442
    :catch_3
    move-exception v0

    .line 443
    :goto_c
    :try_start_4
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 446
    if-eqz v3, :cond_11

    .line 448
    :try_start_5
    invoke-virtual {v3}, Ljava/io/ObjectOutputStream;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_4

    .line 451
    goto :goto_9

    .line 452
    :catch_4
    move-exception v0

    .line 453
    move-object v3, v0

    .line 454
    invoke-virtual {v3}, Ljava/lang/Throwable;->printStackTrace()V

    .line 457
    goto :goto_9

    .line 458
    :goto_d
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 461
    :goto_e
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 464
    move-result-object v3

    .line 465
    :goto_f
    if-nez v3, :cond_12

    .line 467
    const/16 v2, 0x19

    .line 469
    invoke-virtual {v1, v2}, Lte;->s(I)V

    .line 472
    goto :goto_14

    .line 473
    :cond_12
    const/16 v2, 0x19

    .line 475
    invoke-virtual {v1, v2, v3}, Lte;->h(I[B)V

    .line 478
    goto :goto_14

    .line 479
    :goto_10
    move-object v1, v0

    .line 480
    move-object v4, v3

    .line 481
    :goto_11
    if-eqz v4, :cond_13

    .line 483
    :try_start_6
    invoke-virtual {v4}, Ljava/io/ObjectOutputStream;->close()V
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_5

    .line 486
    goto :goto_12

    .line 487
    :catch_5
    move-exception v0

    .line 488
    move-object v3, v0

    .line 489
    invoke-virtual {v3}, Ljava/lang/Throwable;->printStackTrace()V

    .line 492
    :cond_13
    :goto_12
    :try_start_7
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_6

    .line 495
    goto :goto_13

    .line 496
    :catch_6
    move-exception v0

    .line 497
    move-object v2, v0

    .line 498
    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    .line 501
    :goto_13
    throw v1

    .line 502
    :cond_14
    invoke-virtual {v1, v9}, Lte;->s(I)V

    .line 505
    invoke-virtual {v1, v7}, Lte;->s(I)V

    .line 508
    invoke-virtual {v1, v15}, Lte;->s(I)V

    .line 511
    invoke-virtual {v1, v14}, Lte;->s(I)V

    .line 514
    invoke-virtual {v1, v13}, Lte;->s(I)V

    .line 517
    invoke-virtual {v1, v12}, Lte;->s(I)V

    .line 520
    const/16 v0, 0x18

    .line 522
    invoke-virtual {v1, v0}, Lte;->s(I)V

    .line 525
    const/16 v2, 0x19

    .line 527
    invoke-virtual {v1, v2}, Lte;->s(I)V

    .line 530
    :goto_14
    return-void
.end method
