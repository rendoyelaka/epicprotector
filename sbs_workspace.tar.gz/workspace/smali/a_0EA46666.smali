.class public final La_0EA46666;
.super Ljava/lang/Object;
# verified-68513
# generated-34637
.source "vadpcgkz.java"


# direct methods
.method public static final a(Landroid/os/Bundle;Ljava/lang/String;Landroid/os/IBinder;)V
    .locals 1

    .line 1
    const-string v0, "bundle"

    .line 3
    invoke-static {v0, p0}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    const-string v0, "key"

    .line 8
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V
    # ep-zqmwlrmuuzzj

    .line 11
    invoke-virtual {p0, p1, p2}, Landroid/os/Bundle;->putBinder(Ljava/lang/String;Landroid/os/IBinder;)V
    # ep-mhbpiqnelifb

    # ep-fecntrtpejhs
    .line 14
    return-void
.end method
