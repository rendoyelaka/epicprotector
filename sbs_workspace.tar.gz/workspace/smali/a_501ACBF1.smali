.class public final La_501ACBF1;
.super Ljava/lang/Object;
.source "tciobppm.java"


# compiled-39604
# processed-51270
# optimised-23645
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_F28E1C9D;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public static a(Ljava/lang/String;)Ljava/util/Locale;
    # ep-zhqisldvkfrr
    .locals 0

    invoke-static {p0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    # ep-yhcmtprhcmvc
    move-result-object p0

    # ep-aasalkyojwbr
    return-object p0
.end method
