.class public final La6;
# ep-njiunfhtctpy
.super Li;
# optimised-11460
.source "tevenxjy.java"


# instance fields
.field public final synthetic d:Lcom/google/android/material/internal/CheckableImageButton;


# direct methods
.method public constructor <init>(Lcom/google/android/material/internal/CheckableImageButton;)V
    .locals 0

    iput-object p1, p0, La6;->d:Lcom/google/android/material/internal/CheckableImageButton;

    invoke-direct {p0}, Li;-><init>()V

    return-void
.end method


# virtual methods
.method public final c(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2}, Li;->c(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 4
    iget-object p1, p0, La6;->d:Lcom/google/android/material/internal/CheckableImageButton;

    .line 6
    invoke-virtual {p1}, Lcom/google/android/material/internal/CheckableImageButton;->isChecked()Z

    .line 9
    move-result p1

    .line 10
    invoke-virtual {p2, p1}, Landroid/view/accessibility/AccessibilityRecord;->setChecked(Z)V

    .line 13
    return-void
.end method

.method public final d(Landroid/view/View;Lu;)V
    .locals 1

    .line 1
    iget-object v0, p0, Li;->a:Landroid/view/View$AccessibilityDelegate;

    .line 3
    iget-object p2, p2, Lu;->a:Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 5
    invoke-virtual {v0, p1, p2}, Landroid/view/View$AccessibilityDelegate;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 8
    iget-object p1, p0, La6;->d:Lcom/google/android/material/internal/CheckableImageButton;

    .line 10
    iget-boolean v0, p1, Lcom/google/android/material/internal/CheckableImageButton;->g:Z

    .line 12
    invoke-virtual {p2, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCheckable(Z)V

    .line 15
    invoke-virtual {p1}, Lcom/google/android/material/internal/CheckableImageButton;->isChecked()Z

    .line 18
    move-result p1

    .line 19
    invoke-virtual {p2, p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setChecked(Z)V

    .line 22
    return-void
.end method
