.class public final La_3FE90397;
.super La_5761B2D0;
# ep-swfaspejemcq
.source "yeejxffi.java"
# verified-79256
# validated-73721
# optimised-41341


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "h"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_5761B2D0;-><init>()V

    return-void
.end method
