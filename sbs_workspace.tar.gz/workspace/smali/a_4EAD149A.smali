.class public final synthetic La_4EAD149A;
# ep-pbphkrtrsevy
# optimised-95369
# validated-54623
# processed-55674
.super Ljava/lang/Object;
.source "hrxrbntw.java"

# interfaces
.implements Landroid/view/View$OnFocusChangeListener;


# instance fields
.field public final synthetic a:La_EE36626D;


# direct methods
.method public synthetic constructor <init>(La_EE36626D;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La_4EAD149A;->a:La_EE36626D;

    return-void
.end method


# virtual methods
.method public final onFocusChange(Landroid/view/View;Z)V
    .locals 0

    iget-object p1, p0, La_4EAD149A;->a:La_EE36626D;

    invoke-virtual {p1}, La_EE36626D;->u()Z

    move-result p2

    invoke-virtual {p1, p2}, La_EE36626D;->t(Z)V

    return-void
.end method
