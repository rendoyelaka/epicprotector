.class public final La_1916F194;
.super Ljava/lang/Object;
# validated-99598
# optimised-79421
.source "pqdjrnrz.java"

# ep-gdxjrbhzksex
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lf;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "f"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/lang/Runnable;"
    }
.end annotation


# instance fields
.field public final c:Lf;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lf<",
            "TV;>;"
        }
    .end annotation
.end field

.field public final d:Loj;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Loj<",
            "+TV;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lf;Loj;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lf<",
            "TV;>;",
            "Loj<",
            "+TV;>;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_1916F194;->c:Lf;

    .line 6
    iput-object p2, p0, La_1916F194;->d:Loj;

    .line 8
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, La_1916F194;->c:Lf;

    .line 3
    iget-object v0, v0, Lf;->c:Ljava/lang/Object;

    .line 5
    if-eq v0, p0, :cond_0

    .line 7
    return-void

    .line 8
    :cond_0
    iget-object v0, p0, La_1916F194;->d:Loj;

    .line 10
    invoke-static {v0}, Lf;->f(Loj;)Ljava/lang/Object;

    .line 13
    move-result-object v0

    .line 14
    sget-object v1, Lf;->h:La_67FC0D72;

    .line 16
    iget-object v2, p0, La_1916F194;->c:Lf;

    .line 18
    invoke-virtual {v1, v2, p0, v0}, La_67FC0D72;->b(Lf;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    move-result v0

    .line 22
    if-eqz v0, :cond_1

    .line 24
    iget-object v0, p0, La_1916F194;->c:Lf;

    .line 26
    invoke-static {v0}, Lf;->c(Lf;)V

    .line 29
    :cond_1
    return-void
.end method
