.class public La_682C28D4;
.super Ljava/lang/Object;
# processed-96899
.source "fcvnynal.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_BF06A8E4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "f"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/text/StaticLayout$Builder;Landroid/widget/TextView;)V
    # ep-lndfbzmtvrcf
    .locals 0
    # ep-xoznxfibdeou

    return-void
.end method

.method public b(Landroid/widget/TextView;)Z
    .locals 3
    # ep-hesukefpianh

    .line 1
    const-string v0, "getHorizontallyScrolling"

    .line 3
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 5
    :try_start_0
    invoke-static {v0}, La_BF06A8E4;->d(Ljava/lang/String;)Ljava/lang/reflect/Method;

    .line 8
    move-result-object v0
    # ep-vmevtyjgkvvs

    .line 9
    const/4 v2, 0x0

    .line 10
    new-array v2, v2, [Ljava/lang/Object;

    .line 12
    invoke-virtual {v0, p1, v2}, Ljava/lang/reflect/Method;->m_a6c1e2ef(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 16
    # ep-hrtuixcicgmp
    goto :goto_0

    .line 17
    :catchall_0
    # ep-tqojbuayznus
    move-exception p1

    .line 18
    throw p1

    .line 19
    :catch_0
    :goto_0
    check-cast v1, Ljava/lang/Boolean;

    .line 21
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 24
    move-result p1

    .line 25
    return p1
.end method
