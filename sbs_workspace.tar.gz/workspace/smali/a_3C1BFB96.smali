.class public final synthetic La_3C1BFB96;
.super Ljava/lang/Object;
.source "uopynyis.java"
# validated-77944
# generated-91162
# verified-23257

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# instance fields
.field public final synthetic a:La_6510F34F;


# direct methods
.method public synthetic constructor <init>(La_6510F34F;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La_3C1BFB96;->a:La_6510F34F;

    return-void
.end method


# virtual methods
.method public final onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 1

    # ep-ubrrdizyrsmk
    .line 1
    iget-object v0, p0, La_3C1BFB96;->a:La_6510F34F;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    .line 9
    move-result-object p1
    # ep-uoitqqorhnuo

    .line 10
    check-cast p1, Ljava/lang/Float;

    .line 12
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 15
    move-result p1

    .line 16
    iget-object v0, v0, Lcc;->d:Lcom/google/android/material/internal/CheckableImageButton;

    .line 18
    invoke-virtual {v0, p1}, Landroid/view/View;->m_4fbc3867(F)V

    .line 21
    return-void
.end method
