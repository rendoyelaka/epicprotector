.class public final La_5AF8EF9C;
.super Ljava/lang/Object;
# ep-rlxpvpyxcwlx
.source "hhsdrnbv.java"

# processed-53042
# processed-71418
# interfaces
.implements Lls;


# instance fields
.field public final synthetic c:Lls;

.field public final synthetic d:La_FD057980;


# direct methods
.method public constructor <init>(Ldn;Lbn;)V
    .locals 0

    iput-object p1, p0, La_5AF8EF9C;->d:La_FD057980;

    iput-object p2, p0, La_5AF8EF9C;->c:Lls;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Lhv;
    .locals 1

    iget-object v0, p0, La_5AF8EF9C;->d:La_FD057980;

    return-object v0
.end method

.method public final b(La_A2F8F8F5;J)V
    .locals 6

    .line 1
    iget-wide v0, p1, La_A2F8F8F5;->d:J

    .line 3
    const-wide/16 v2, 0x0

    .line 5
    move-wide v4, p2

    .line 6
    invoke-static/range {v0 .. v5}, Ldx;->a(JJJ)V

    .line 9
    :goto_0
    const-wide/16 v0, 0x0

    .line 11
    cmp-long v2, p2, v0

    .line 13
    if-lez v2, :cond_2

    .line 15
    iget-object v2, p1, La_A2F8F8F5;->c:Llr;

    .line 17
    :goto_1
    const-wide/32 v3, 0x10000

    .line 20
    cmp-long v5, v0, v3

    .line 22
    if-gez v5, :cond_1

    .line 24
    iget-object v3, p1, La_A2F8F8F5;->c:Llr;

    .line 26
    iget v4, v3, Llr;->c:I

    .line 28
    iget v3, v3, Llr;->b:I

    .line 30
    sub-int/2addr v4, v3

    .line 31
    int-to-long v3, v4

    .line 32
    add-long/2addr v0, v3

    .line 33
    cmp-long v3, v0, p2

    .line 35
    if-ltz v3, :cond_0

    .line 37
    move-wide v0, p2

    .line 38
    goto :goto_2

    .line 39
    :cond_0
    iget-object v2, v2, Llr;->f:Llr;

    .line 41
    goto :goto_1

    .line 42
    :cond_1
    :goto_2
    iget-object v2, p0, La_5AF8EF9C;->d:La_FD057980;

    .line 44
    invoke-virtual {v2}, La_FD057980;->j()V

    .line 47
    :try_start_0
    iget-object v3, p0, La_5AF8EF9C;->c:Lls;

    .line 49
    invoke-interface {v3, p1, v0, v1}, Lls;->b(La_A2F8F8F5;J)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 52
    sub-long/2addr p2, v0

    .line 53
    const/4 v0, 0x1

    .line 54
    invoke-virtual {v2, v0}, La_FD057980;->l(Z)V

    .line 57
    goto :goto_0

    .line 58
    :catchall_0
    move-exception p1

    .line 59
    goto :goto_3

    .line 60
    :catch_0
    move-exception p1

    .line 61
    :try_start_1
    invoke-virtual {v2, p1}, La_FD057980;->k(Ljava/io/IOException;)Ljava/io/IOException;

    .line 64
    move-result-object p1

    .line 65
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 66
    :goto_3
    const/4 p2, 0x0

    .line 67
    invoke-virtual {v2, p2}, La_FD057980;->l(Z)V

    .line 70
    throw p1

    .line 71
    :cond_2
    return-void
.end method

.method public final m_806d7b76()V
    .locals 3

    .line 1
    iget-object v0, p0, La_5AF8EF9C;->d:La_FD057980;

    .line 3
    invoke-virtual {v0}, La_FD057980;->j()V

    .line 6
    :try_start_0
    iget-object v1, p0, La_5AF8EF9C;->c:Lls;

    .line 8
    invoke-interface {v1}, Lls;->m_806d7b76()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    const/4 v1, 0x1

    .line 12
    invoke-virtual {v0, v1}, La_FD057980;->l(Z)V

    .line 15
    return-void

    .line 16
    :catchall_0
    move-exception v1

    .line 17
    goto :goto_0

    .line 18
    :catch_0
    move-exception v1

    .line 19
    :try_start_1
    invoke-virtual {v0, v1}, La_FD057980;->k(Ljava/io/IOException;)Ljava/io/IOException;

    .line 22
    move-result-object v1

    .line 23
    throw v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 24
    :goto_0
    const/4 v2, 0x0

    .line 25
    invoke-virtual {v0, v2}, La_FD057980;->l(Z)V

    .line 28
    throw v1
.end method

.method public final m_f951ee62()V
    .locals 3

    .line 1
    iget-object v0, p0, La_5AF8EF9C;->d:La_FD057980;

    .line 3
    invoke-virtual {v0}, La_FD057980;->j()V

    .line 6
    :try_start_0
    iget-object v1, p0, La_5AF8EF9C;->c:Lls;

    .line 8
    invoke-interface {v1}, Lls;->m_f951ee62()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    const/4 v1, 0x1

    .line 12
    invoke-virtual {v0, v1}, La_FD057980;->l(Z)V

    .line 15
    return-void

    .line 16
    :catchall_0
    move-exception v1

    .line 17
    goto :goto_0

    .line 18
    :catch_0
    move-exception v1

    .line 19
    :try_start_1
    invoke-virtual {v0, v1}, La_FD057980;->k(Ljava/io/IOException;)Ljava/io/IOException;

    .line 22
    move-result-object v1

    .line 23
    throw v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 24
    :goto_0
    const/4 v2, 0x0

    .line 25
    invoke-virtual {v0, v2}, La_FD057980;->l(Z)V

    .line 28
    throw v1
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "AsyncTimeout.sink("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, La_5AF8EF9C;->c:Lls;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
