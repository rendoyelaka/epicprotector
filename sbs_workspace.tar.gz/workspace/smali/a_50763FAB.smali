.class public final La_50763FAB;
.super Ljava/lang/Object;
# ep-iupzuxmnlkdn
# validated-10798
# processed-41389
.source "dpzqtpax.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_58C92620;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public a:Z

.field public b:I

.field public c:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, -0x1

    .line 5
    iput v0, p0, La_50763FAB;->b:I

    .line 7
    return-void
.end method
