.class public final La_65A6AE87;
.super Landroid/widget/Spinner;
# compiled-25403
# validated-28303
# compiled-95134
# ep-uwvkqhhpgebx
.source "rpejohji.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_2ABB1E50;,
        La_E13CED78;,
        La_D2707366;,
        La_1862CD37;,
        La_51EE9295;,
        La_87E2DDC0;,
        La_D2A03C91;,
        La_B28EB0A4;
    }
.end annotation


# static fields
.field public static final k:[I
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ResourceType"
        }
    .end annotation
.end field


# instance fields
.field public final c:La_8717FEA8;

.field public final d:Landroid/content/Context;

.field public final e:La_0FA85E2F;

.field public f:Landroid/widget/SpinnerAdapter;

.field public final g:Z

.field public final h:La_87E2DDC0;

.field public i:I

.field public final j:Landroid/graphics/Rect;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    new-array v0, v0, [I

    .line 4
    const/4 v1, 0x0

    .line 5
    const v2, 0x10102f1

    .line 8
    aput v2, v0, v1

    .line 10
    sput-object v0, La_65A6AE87;->k:[I

    .line 12
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 10

    .line 1
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/Spinner;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 4
    new-instance v0, Landroid/graphics/Rect;

    .line 6
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 9
    iput-object v0, p0, La_65A6AE87;->j:Landroid/graphics/Rect;

    .line 11
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 14
    move-result-object v0

    .line 15
    invoke-static {p0, v0}, Lav;->a(Landroid/view/View;Landroid/content/Context;)V

    .line 18
    sget-object v0, La_2C13166E;->f_60739359:[I

    .line 20
    const/4 v1, 0x0

    .line 21
    invoke-virtual {p1, p2, v0, p3, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 24
    move-result-object v2

    .line 25
    new-instance v3, La_8717FEA8;

    .line 27
    invoke-direct {v3, p0}, La_8717FEA8;-><init>(Landroid/view/View;)V

    .line 30
    iput-object v3, p0, La_65A6AE87;->c:La_8717FEA8;

    .line 32
    const/4 v3, 0x4

    .line 33
    invoke-virtual {v2, v3, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 36
    move-result v3

    .line 37
    if-eqz v3, :cond_0

    .line 39
    new-instance v4, La_350908D8;

    .line 41
    invoke-direct {v4, p1, v3}, La_350908D8;-><init>(Landroid/content/Context;I)V

    .line 44
    iput-object v4, p0, La_65A6AE87;->d:Landroid/content/Context;

    .line 46
    goto :goto_0

    .line 47
    :cond_0
    iput-object p1, p0, La_65A6AE87;->d:Landroid/content/Context;

    .line 49
    :goto_0
    const/4 v3, -0x1

    .line 50
    const/4 v4, 0x0

    .line 51
    :try_start_0
    sget-object v5, La_65A6AE87;->k:[I

    .line 53
    invoke-virtual {p1, p2, v5, p3, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 56
    move-result-object v5
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 57
    :try_start_1
    invoke-virtual {v5, v1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 60
    move-result v6

    .line 61
    if-eqz v6, :cond_2

    .line 63
    invoke-virtual {v5, v1, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 66
    move-result v3
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 67
    goto :goto_3

    .line 68
    :catchall_0
    move-exception p1

    .line 69
    move-object v4, v5

    .line 70
    goto :goto_1

    .line 71
    :catch_0
    nop

    .line 72
    goto :goto_2

    .line 73
    :catchall_1
    move-exception p1

    .line 74
    :goto_1
    if-eqz v4, :cond_1

    .line 76
    invoke-virtual {v4}, Landroid/content/res/TypedArray;->recycle()V

    .line 79
    :cond_1
    throw p1

    .line 80
    :catch_1
    nop

    .line 81
    move-object v5, v4

    .line 82
    :goto_2
    if-eqz v5, :cond_3

    .line 84
    :cond_2
    :goto_3
    invoke-virtual {v5}, Landroid/content/res/TypedArray;->recycle()V

    .line 87
    :cond_3
    const/4 v5, 0x2

    .line 88
    const/4 v6, 0x1

    .line 89
    if-eqz v3, :cond_5

    .line 91
    if-eq v3, v6, :cond_4

    .line 93
    goto :goto_4

    .line 94
    :cond_4
    new-instance v3, La_1862CD37;

    .line 96
    iget-object v7, p0, La_65A6AE87;->d:Landroid/content/Context;

    .line 98
    invoke-direct {v3, p0, v7, p2, p3}, La_1862CD37;-><init>(La_65A6AE87;Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 101
    iget-object v7, p0, La_65A6AE87;->d:Landroid/content/Context;

    .line 103
    invoke-static {v7, p2, v0, p3}, Lmv;->m(Landroid/content/Context;Landroid/util/AttributeSet;[II)Lmv;

    .line 106
    move-result-object v0

    .line 107
    iget-object v7, v0, Lmv;->b:Landroid/content/res/TypedArray;

    .line 109
    const/4 v8, 0x3

    .line 110
    const/4 v9, -0x2

    .line 111
    invoke-virtual {v7, v8, v9}, Landroid/content/res/TypedArray;->getLayoutDimension(II)I

    .line 114
    move-result v7

    .line 115
    iput v7, p0, La_65A6AE87;->i:I

    .line 117
    invoke-virtual {v0, v6}, Lmv;->e(I)Landroid/graphics/drawable/Drawable;

    .line 120
    move-result-object v7

    .line 121
    invoke-virtual {v3, v7}, Llj;->i(Landroid/graphics/drawable/Drawable;)V

    .line 124
    invoke-virtual {v2, v5}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 127
    move-result-object v5

    .line 128
    iput-object v5, v3, La_1862CD37;->f_f5f318dc:Ljava/lang/CharSequence;

    .line 130
    invoke-virtual {v0}, Lmv;->n()V

    .line 133
    iput-object v3, p0, La_65A6AE87;->h:La_87E2DDC0;

    .line 135
    new-instance v0, La_0FA85E2F;

    .line 137
    invoke-direct {v0, p0, p0, v3}, La_0FA85E2F;-><init>(La_65A6AE87;Landroid/view/View;La_1862CD37;)V

    .line 140
    iput-object v0, p0, La_65A6AE87;->e:La_0FA85E2F;

    .line 142
    goto :goto_4

    .line 143
    :cond_5
    new-instance v0, La_51EE9295;

    .line 145
    invoke-direct {v0, p0}, La_51EE9295;-><init>(La_65A6AE87;)V

    .line 148
    iput-object v0, p0, La_65A6AE87;->h:La_87E2DDC0;

    .line 150
    invoke-virtual {v2, v5}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 153
    move-result-object v3

    .line 154
    iput-object v3, v0, La_51EE9295;->e:Ljava/lang/CharSequence;

    .line 156
    :goto_4
    invoke-virtual {v2, v1}, Landroid/content/res/TypedArray;->getTextArray(I)[Ljava/lang/CharSequence;

    .line 159
    move-result-object v0

    .line 160
    if-eqz v0, :cond_6

    .line 162
    new-instance v1, Landroid/widget/ArrayAdapter;

    .line 164
    const v3, 0x1090008

    .line 167
    invoke-direct {v1, p1, v3, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;I[Ljava/lang/Object;)V

    .line 170
    const p1, 0x7f0c006d

    .line 173
    invoke-virtual {v1, p1}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    .line 176
    invoke-virtual {p0, v1}, La_65A6AE87;->m_69ab92c6(Landroid/widget/SpinnerAdapter;)V

    .line 179
    :cond_6
    invoke-virtual {v2}, Landroid/content/res/TypedArray;->recycle()V

    .line 182
    iput-boolean v6, p0, La_65A6AE87;->g:Z

    .line 184
    iget-object p1, p0, La_65A6AE87;->f:Landroid/widget/SpinnerAdapter;

    .line 186
    if-eqz p1, :cond_7

    .line 188
    invoke-virtual {p0, p1}, La_65A6AE87;->m_69ab92c6(Landroid/widget/SpinnerAdapter;)V

    .line 191
    iput-object v4, p0, La_65A6AE87;->f:Landroid/widget/SpinnerAdapter;

    .line 193
    :cond_7
    iget-object p1, p0, La_65A6AE87;->c:La_8717FEA8;

    .line 195
    invoke-virtual {p1, p2, p3}, La_8717FEA8;->d(Landroid/util/AttributeSet;I)V

    .line 198
    return-void
.end method


# virtual methods
.method public final a(Landroid/widget/SpinnerAdapter;Landroid/graphics/drawable/Drawable;)I
    .locals 10

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p1, :cond_0

    .line 4
    return v0

    .line 5
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 8
    move-result v1

    .line 9
    invoke-static {v1, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 12
    move-result v1

    .line 13
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 16
    move-result v2

    .line 17
    invoke-static {v2, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 20
    move-result v2

    .line 21
    invoke-virtual {p0}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 24
    move-result v3

    .line 25
    invoke-static {v0, v3}, Ljava/lang/Math;->max(II)I

    .line 28
    move-result v3

    .line 29
    invoke-interface {p1}, Landroid/widget/Adapter;->getCount()I

    .line 32
    move-result v4

    .line 33
    add-int/lit8 v5, v3, 0xf

    .line 35
    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    .line 38
    move-result v4

    .line 39
    sub-int v5, v4, v3

    .line 41
    rsub-int/lit8 v5, v5, 0xf

    .line 43
    sub-int/2addr v3, v5

    .line 44
    invoke-static {v0, v3}, Ljava/lang/Math;->max(II)I

    .line 47
    move-result v3

    .line 48
    const/4 v5, 0x0

    .line 49
    move v6, v3

    .line 50
    move-object v7, v5

    .line 51
    const/4 v3, 0x0

    .line 52
    :goto_0
    if-ge v6, v4, :cond_3

    .line 54
    invoke-interface {p1, v6}, Landroid/widget/Adapter;->getItemViewType(I)I

    .line 57
    move-result v8

    .line 58
    if-eq v8, v0, :cond_1

    .line 60
    move-object v7, v5

    .line 61
    move v0, v8

    .line 62
    :cond_1
    invoke-interface {p1, v6, v7, p0}, Landroid/widget/Adapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    .line 65
    move-result-object v7

    .line 66
    invoke-virtual {v7}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 69
    move-result-object v8

    .line 70
    if-nez v8, :cond_2

    .line 72
    new-instance v8, Landroid/view/ViewGroup$LayoutParams;

    .line 74
    const/4 v9, -0x2

    .line 75
    invoke-direct {v8, v9, v9}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 78
    invoke-virtual {v7, v8}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 81
    :cond_2
    invoke-virtual {v7, v1, v2}, Landroid/view/View;->measure(II)V

    .line 84
    invoke-virtual {v7}, Landroid/view/View;->getMeasuredWidth()I

    .line 87
    move-result v8

    .line 88
    invoke-static {v3, v8}, Ljava/lang/Math;->max(II)I

    .line 91
    move-result v3

    .line 92
    add-int/lit8 v6, v6, 0x1

    .line 94
    goto :goto_0

    .line 95
    :cond_3
    if-eqz p2, :cond_4

    .line 97
    iget-object p1, p0, La_65A6AE87;->j:Landroid/graphics/Rect;

    .line 99
    invoke-virtual {p2, p1}, Landroid/graphics/drawable/Drawable;->m_5a16927a(Landroid/graphics/Rect;)Z

    .line 102
    iget p2, p1, Landroid/graphics/Rect;->left:I

    .line 104
    iget p1, p1, Landroid/graphics/Rect;->right:I

    .line 106
    add-int/2addr p2, p1

    .line 107
    add-int/2addr v3, p2

    .line 108
    :cond_4
    return v3
.end method

.method public final m_da43443c()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/Spinner;->m_da43443c()V

    .line 4
    iget-object v0, p0, La_65A6AE87;->c:La_8717FEA8;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, La_8717FEA8;->a()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_016b1f95()I
    .locals 1

    .line 1
    iget-object v0, p0, La_65A6AE87;->h:La_87E2DDC0;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-interface {v0}, La_87E2DDC0;->c()I

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    invoke-super {p0}, Landroid/widget/Spinner;->m_016b1f95()I

    .line 13
    move-result v0

    .line 14
    return v0
.end method

.method public m_6e1cc314()I
    .locals 1

    .line 1
    iget-object v0, p0, La_65A6AE87;->h:La_87E2DDC0;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-interface {v0}, La_87E2DDC0;->n()I

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    invoke-super {p0}, Landroid/widget/Spinner;->m_6e1cc314()I

    .line 13
    move-result v0

    .line 14
    return v0
.end method

.method public m_9315814b()I
    .locals 1

    .line 1
    iget-object v0, p0, La_65A6AE87;->h:La_87E2DDC0;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget v0, p0, La_65A6AE87;->i:I

    .line 7
    return v0

    .line 8
    :cond_0
    invoke-super {p0}, Landroid/widget/Spinner;->m_9315814b()I

    .line 11
    move-result v0

    .line 12
    return v0
.end method

.method public final m_eb64fd61()La_87E2DDC0;
    .locals 1

    iget-object v0, p0, La_65A6AE87;->h:La_87E2DDC0;

    return-object v0
.end method

.method public m_99d8a25f()Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    iget-object v0, p0, La_65A6AE87;->h:La_87E2DDC0;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-interface {v0}, La_87E2DDC0;->f()Landroid/graphics/drawable/Drawable;

    .line 8
    move-result-object v0

    .line 9
    return-object v0

    .line 10
    :cond_0
    invoke-super {p0}, Landroid/widget/Spinner;->m_99d8a25f()Landroid/graphics/drawable/Drawable;

    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method public m_fa729d5a()Landroid/content/Context;
    .locals 1

    iget-object v0, p0, La_65A6AE87;->d:Landroid/content/Context;

    return-object v0
.end method

.method public m_9c5dc067()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, La_65A6AE87;->h:La_87E2DDC0;

    if-eqz v0, :cond_0

    invoke-interface {v0}, La_87E2DDC0;->o()Ljava/lang/CharSequence;

    move-result-object v0

    goto :goto_0

    :cond_0
    invoke-super {p0}, Landroid/widget/Spinner;->m_9c5dc067()Ljava/lang/CharSequence;

    move-result-object v0

    :goto_0
    return-object v0
.end method

.method public m_9a0fc39c()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, La_65A6AE87;->c:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_8717FEA8;->b()Landroid/content/res/ColorStateList;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_9f48d392()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, La_65A6AE87;->c:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_8717FEA8;->c()Landroid/graphics/PorterDuff$Mode;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public final onDetachedFromWindow()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/widget/Spinner;->onDetachedFromWindow()V

    .line 4
    iget-object v0, p0, La_65A6AE87;->h:La_87E2DDC0;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-interface {v0}, La_87E2DDC0;->b()Z

    .line 11
    move-result v1

    .line 12
    if-eqz v1, :cond_0

    .line 14
    invoke-interface {v0}, La_87E2DDC0;->m_dab6e4d7()V

    .line 17
    :cond_0
    return-void
.end method

.method public final onMeasure(II)V
    .locals 2

    .line 1
    invoke-super {p0, p1, p2}, Landroid/widget/Spinner;->onMeasure(II)V

    .line 4
    iget-object p2, p0, La_65A6AE87;->h:La_87E2DDC0;

    .line 6
    if-eqz p2, :cond_0

    .line 8
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 11
    move-result p2

    .line 12
    const/high16 v0, -0x80000000

    .line 14
    if-ne p2, v0, :cond_0

    .line 16
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 19
    move-result p2

    .line 20
    invoke-virtual {p0}, Landroid/widget/AbsSpinner;->getAdapter()Landroid/widget/SpinnerAdapter;

    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 27
    move-result-object v1

    .line 28
    invoke-virtual {p0, v0, v1}, La_65A6AE87;->a(Landroid/widget/SpinnerAdapter;Landroid/graphics/drawable/Drawable;)I

    .line 31
    move-result v0

    .line 32
    invoke-static {p2, v0}, Ljava/lang/Math;->max(II)I

    .line 35
    move-result p2

    .line 36
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 39
    move-result p1

    .line 40
    invoke-static {p2, p1}, Ljava/lang/Math;->min(II)I

    .line 43
    move-result p1

    .line 44
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 47
    move-result p2

    .line 48
    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    .line 51
    :cond_0
    return-void
.end method

.method public final onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 1

    .line 1
    check-cast p1, La_B28EB0A4;

    .line 3
    invoke-virtual {p1}, Landroid/view/AbsSavedState;->getSuperState()Landroid/os/Parcelable;

    .line 6
    move-result-object v0

    .line 7
    invoke-super {p0, v0}, Landroid/widget/Spinner;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 10
    iget-boolean p1, p1, La_B28EB0A4;->c:Z

    .line 12
    if-eqz p1, :cond_0

    .line 14
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 17
    move-result-object p1

    .line 18
    if-eqz p1, :cond_0

    .line 20
    new-instance v0, La_4D04236A;

    .line 22
    invoke-direct {v0, p0}, La_4D04236A;-><init>(La_65A6AE87;)V

    .line 25
    invoke-virtual {p1, v0}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 28
    :cond_0
    return-void
.end method

.method public final onSaveInstanceState()Landroid/os/Parcelable;
    .locals 2

    .line 1
    new-instance v0, La_B28EB0A4;

    .line 3
    invoke-super {p0}, Landroid/widget/Spinner;->onSaveInstanceState()Landroid/os/Parcelable;

    .line 6
    move-result-object v1

    .line 7
    invoke-direct {v0, v1}, La_B28EB0A4;-><init>(Landroid/os/Parcelable;)V

    .line 10
    iget-object v1, p0, La_65A6AE87;->h:La_87E2DDC0;

    .line 12
    if-eqz v1, :cond_0

    .line 14
    invoke-interface {v1}, La_87E2DDC0;->b()Z

    .line 17
    move-result v1

    .line 18
    if-eqz v1, :cond_0

    .line 20
    const/4 v1, 0x1

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 v1, 0x0

    .line 23
    :goto_0
    iput-boolean v1, v0, La_B28EB0A4;->c:Z

    .line 25
    return-object v0
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 1

    .line 1
    iget-object v0, p0, La_65A6AE87;->e:La_0FA85E2F;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p0, p1}, Lsd;->onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z

    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 11
    const/4 p1, 0x1

    .line 12
    return p1

    .line 13
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/Spinner;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 16
    move-result p1

    .line 17
    return p1
.end method

.method public final m_3d979af3()Z
    .locals 3

    .line 1
    iget-object v0, p0, La_65A6AE87;->h:La_87E2DDC0;

    .line 3
    if-eqz v0, :cond_1

    .line 5
    invoke-interface {v0}, La_87E2DDC0;->b()Z

    .line 8
    move-result v1

    .line 9
    if-nez v1, :cond_0

    .line 11
    invoke-static {p0}, La_E13CED78;->b(Landroid/view/View;)I

    .line 14
    move-result v1

    .line 15
    invoke-static {p0}, La_E13CED78;->a(Landroid/view/View;)I

    .line 18
    move-result v2

    .line 19
    invoke-interface {v0, v1, v2}, La_87E2DDC0;->m(II)V

    .line 22
    :cond_0
    const/4 v0, 0x1

    .line 23
    return v0

    .line 24
    :cond_1
    invoke-super {p0}, Landroid/widget/Spinner;->m_3d979af3()Z

    .line 27
    move-result v0

    .line 28
    return v0
.end method

.method public bridge synthetic m_69ab92c6(Landroid/widget/Adapter;)V
    .locals 0

    .line 1
    check-cast p1, Landroid/widget/SpinnerAdapter;

    invoke-virtual {p0, p1}, La_65A6AE87;->m_69ab92c6(Landroid/widget/SpinnerAdapter;)V

    return-void
.end method

.method public m_69ab92c6(Landroid/widget/SpinnerAdapter;)V
    .locals 3

    .line 2
    iget-boolean v0, p0, La_65A6AE87;->g:Z

    if-nez v0, :cond_0

    .line 3
    iput-object p1, p0, La_65A6AE87;->f:Landroid/widget/SpinnerAdapter;

    return-void

    .line 4
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/Spinner;->m_69ab92c6(Landroid/widget/SpinnerAdapter;)V

    .line 5
    iget-object v0, p0, La_65A6AE87;->h:La_87E2DDC0;

    if-eqz v0, :cond_2

    .line 6
    iget-object v1, p0, La_65A6AE87;->d:Landroid/content/Context;

    if-nez v1, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    .line 7
    :cond_1
    new-instance v2, La_D2A03C91;

    invoke-virtual {v1}, Landroid/content/Context;->m_91592b02()Landroid/content/res/Resources$Theme;

    move-result-object v1

    invoke-direct {v2, p1, v1}, La_D2A03C91;-><init>(Landroid/widget/SpinnerAdapter;Landroid/content/res/Resources$Theme;)V

    invoke-interface {v0, v2}, La_87E2DDC0;->p(Landroid/widget/ListAdapter;)V

    :cond_2
    return-void
.end method

.method public m_23185bc0(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/Spinner;->m_23185bc0(Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_65A6AE87;->c:La_8717FEA8;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_8717FEA8;->e()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_1b44a79c(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/Spinner;->m_1b44a79c(I)V

    .line 4
    iget-object v0, p0, La_65A6AE87;->c:La_8717FEA8;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1}, La_8717FEA8;->f(I)V

    .line 11
    :cond_0
    return-void
.end method

.method public m_97747c57(I)V
    .locals 1

    .line 1
    iget-object v0, p0, La_65A6AE87;->h:La_87E2DDC0;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-interface {v0, p1}, La_87E2DDC0;->k(I)V

    .line 8
    invoke-interface {v0, p1}, La_87E2DDC0;->l(I)V

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/Spinner;->m_97747c57(I)V

    .line 15
    :goto_0
    return-void
.end method

.method public m_a5d205fe(I)V
    .locals 1

    .line 1
    iget-object v0, p0, La_65A6AE87;->h:La_87E2DDC0;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-interface {v0, p1}, La_87E2DDC0;->j(I)V

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/Spinner;->m_a5d205fe(I)V

    .line 12
    :goto_0
    return-void
.end method

.method public m_5cd9c629(I)V
    .locals 1

    .line 1
    iget-object v0, p0, La_65A6AE87;->h:La_87E2DDC0;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iput p1, p0, La_65A6AE87;->i:I

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/Spinner;->m_5cd9c629(I)V

    .line 11
    :goto_0
    return-void
.end method

.method public m_246a503d(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_65A6AE87;->h:La_87E2DDC0;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-interface {v0, p1}, La_87E2DDC0;->i(Landroid/graphics/drawable/Drawable;)V

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/Spinner;->m_246a503d(Landroid/graphics/drawable/Drawable;)V

    .line 12
    :goto_0
    return-void
.end method

.method public m_42e4aeac(I)V
    .locals 1

    invoke-virtual {p0}, La_65A6AE87;->m_fa729d5a()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, La_2C13166E;->m_d26d803e(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {p0, p1}, La_65A6AE87;->m_246a503d(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public m_bb2b84a5(Ljava/lang/CharSequence;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_65A6AE87;->h:La_87E2DDC0;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-interface {v0, p1}, La_87E2DDC0;->h(Ljava/lang/CharSequence;)V

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/Spinner;->m_bb2b84a5(Ljava/lang/CharSequence;)V

    .line 12
    :goto_0
    return-void
.end method

.method public m_539f671d(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_65A6AE87;->c:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_8717FEA8;->h(Landroid/content/res/ColorStateList;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_b9a8ba3d(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_65A6AE87;->c:La_8717FEA8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_8717FEA8;->i(Landroid/graphics/PorterDuff$Mode;)V

    .line 8
    :cond_0
    return-void
.end method
