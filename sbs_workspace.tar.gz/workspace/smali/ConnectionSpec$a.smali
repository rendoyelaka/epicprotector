.class public final LConnectionSpec$a;
.super Ljava/lang/Object;
# optimised-40066
# optimised-18280
# verified-63201
.source "gisxqyrc.java"

# ep-dwjllqvqhelh

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LConnectionSpec;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Z

.field public b:[Ljava/lang/String;

.field public c:[Ljava/lang/String;

.field public d:Z


# direct methods
.method public constructor <init>(LConnectionSpec;)V
    .locals 1

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iget-boolean v0, p1, LConnectionSpec;->a:Z

    iput-boolean v0, p0, LConnectionSpec$a;->a:Z

    .line 5
    iget-object v0, p1, LConnectionSpec;->c:[Ljava/lang/String;

    iput-object v0, p0, LConnectionSpec$a;->b:[Ljava/lang/String;

    .line 6
    iget-object v0, p1, LConnectionSpec;->d:[Ljava/lang/String;

    iput-object v0, p0, LConnectionSpec$a;->c:[Ljava/lang/String;

    .line 7
    iget-boolean p1, p1, LConnectionSpec;->b:Z

    iput-boolean p1, p0, LConnectionSpec$a;->d:Z

    return-void
.end method

.method public constructor <init>(Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-boolean p1, p0, LConnectionSpec$a;->a:Z

    return-void
.end method


# virtual methods
.method public final varargs a([Ljava/lang/String;)V
    .locals 1

    .line 1
    iget-boolean v0, p0, LConnectionSpec$a;->a:Z

    .line 3
    if-eqz v0, :cond_1

    .line 5
    array-length v0, p1

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {p1}, [Ljava/lang/String;->clone()Ljava/lang/Object;

    .line 11
    move-result-object p1

    .line 12
    check-cast p1, [Ljava/lang/String;

    .line 14
    iput-object p1, p0, LConnectionSpec$a;->b:[Ljava/lang/String;

    .line 16
    return-void

    .line 17
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 19
    const-string v0, "At least one cipher suite is required"

    .line 21
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 24
    throw p1

    .line 25
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 27
    const-string v0, "no cipher suites for cleartext connections"

    .line 29
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 32
    throw p1
.end method

.method public final varargs b([LTlsVersion;)V
    .locals 3

    .line 1
    iget-boolean v0, p0, LConnectionSpec$a;->a:Z

    .line 3
    if-eqz v0, :cond_1

    .line 5
    array-length v0, p1

    .line 6
    new-array v0, v0, [Ljava/lang/String;

    .line 8
    const/4 v1, 0x0

    .line 9
    :goto_0
    array-length v2, p1

    .line 10
    if-ge v1, v2, :cond_0

    .line 12
    aget-object v2, p1, v1

    .line 14
    iget-object v2, v2, LTlsVersion;->c:Ljava/lang/String;

    .line 16
    aput-object v2, v0, v1

    .line 18
    add-int/lit8 v1, v1, 0x1

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    invoke-virtual {p0, v0}, LConnectionSpec$a;->c([Ljava/lang/String;)V

    .line 24
    return-void

    .line 25
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 27
    const-string v0, "no TLS versions for cleartext connections"

    .line 29
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 32
    throw p1
.end method

.method public final varargs c([Ljava/lang/String;)V
    .locals 1

    .line 1
    iget-boolean v0, p0, LConnectionSpec$a;->a:Z

    .line 3
    if-eqz v0, :cond_1

    .line 5
    array-length v0, p1

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {p1}, [Ljava/lang/String;->clone()Ljava/lang/Object;

    .line 11
    move-result-object p1

    .line 12
    check-cast p1, [Ljava/lang/String;

    .line 14
    iput-object p1, p0, LConnectionSpec$a;->c:[Ljava/lang/String;

    .line 16
    return-void

    .line 17
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 19
    const-string v0, "At least one TLS version is required"

    .line 21
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 24
    throw p1

    .line 25
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 27
    const-string v0, "no TLS versions for cleartext connections"

    .line 29
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 32
    throw p1
.end method
