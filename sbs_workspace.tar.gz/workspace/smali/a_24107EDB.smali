.class public final La_24107EDB;
.super Ljava/lang/Object;
.source "qazdmegk.java"
# processed-10742

# ep-zxvddzolfxmc
# interfaces
.implements Lrt;


# instance fields
.field public a:Ljava/lang/CharSequence;

.field public b:Ljava/lang/CharSequence;

.field public c:Landroid/content/Intent;

.field public d:C

.field public e:I

.field public f:C

.field public g:I

.field public h:Landroid/graphics/drawable/Drawable;

.field public final i:Landroid/content/Context;

.field public j:Ljava/lang/CharSequence;

.field public k:Ljava/lang/CharSequence;

.field public l:Landroid/content/res/ColorStateList;

.field public m:Landroid/graphics/PorterDuff$Mode;

.field public n:Z

.field public o:Z

.field public p:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/CharSequence;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/16 v0, 0x1000

    .line 6
    iput v0, p0, La_24107EDB;->e:I

    .line 8
    iput v0, p0, La_24107EDB;->g:I

    .line 10
    const/4 v0, 0x0

    .line 11
    iput-object v0, p0, La_24107EDB;->l:Landroid/content/res/ColorStateList;

    .line 13
    iput-object v0, p0, La_24107EDB;->m:Landroid/graphics/PorterDuff$Mode;

    .line 15
    const/4 v0, 0x0

    .line 16
    iput-boolean v0, p0, La_24107EDB;->n:Z

    .line 18
    iput-boolean v0, p0, La_24107EDB;->o:Z

    .line 20
    const/16 v0, 0x10

    .line 22
    iput v0, p0, La_24107EDB;->p:I

    .line 24
    iput-object p1, p0, La_24107EDB;->i:Landroid/content/Context;

    .line 26
    iput-object p2, p0, La_24107EDB;->a:Ljava/lang/CharSequence;

    .line 28
    return-void
.end method


# virtual methods
.method public final a()La_771DFC96;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final b(La_771DFC96;)Lrt;
    .locals 0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final c()V
    .locals 2

    .line 1
    iget-object v0, p0, La_24107EDB;->h:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_2

    .line 5
    iget-boolean v1, p0, La_24107EDB;->n:Z

    .line 7
    if-nez v1, :cond_0

    .line 9
    iget-boolean v1, p0, La_24107EDB;->o:Z

    .line 11
    if-eqz v1, :cond_2

    .line 13
    :cond_0
    invoke-static {v0}, Lta;->g(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    .line 16
    move-result-object v0

    .line 17
    iput-object v0, p0, La_24107EDB;->h:Landroid/graphics/drawable/Drawable;

    .line 19
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_414d03cc()Landroid/graphics/drawable/Drawable;

    .line 22
    move-result-object v0

    .line 23
    iput-object v0, p0, La_24107EDB;->h:Landroid/graphics/drawable/Drawable;

    .line 25
    iget-boolean v1, p0, La_24107EDB;->n:Z

    .line 27
    if-eqz v1, :cond_1

    .line 29
    iget-object v1, p0, La_24107EDB;->l:Landroid/content/res/ColorStateList;

    .line 31
    invoke-static {v0, v1}, La_90918F1E;->h(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 34
    :cond_1
    iget-boolean v0, p0, La_24107EDB;->o:Z

    .line 36
    if-eqz v0, :cond_2

    .line 38
    iget-object v0, p0, La_24107EDB;->h:Landroid/graphics/drawable/Drawable;

    .line 40
    iget-object v1, p0, La_24107EDB;->m:Landroid/graphics/PorterDuff$Mode;

    .line 42
    invoke-static {v0, v1}, La_90918F1E;->i(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    .line 45
    :cond_2
    return-void
.end method

.method public final m_538d0070()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final m_06a5246d()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final m_1015ceb3()Landroid/view/ActionProvider;
    .locals 1

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final m_248bf09a()Landroid/view/View;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final m_eb53c3df()I
    .locals 1

    iget v0, p0, La_24107EDB;->g:I

    return v0
.end method

.method public final m_930dc143()C
    .locals 1

    iget-char v0, p0, La_24107EDB;->f:C

    return v0
.end method

.method public final m_31bbddae()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, La_24107EDB;->j:Ljava/lang/CharSequence;

    return-object v0
.end method

.method public final m_5ea564d0()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final m_501f3683()Landroid/graphics/drawable/Drawable;
    .locals 1

    iget-object v0, p0, La_24107EDB;->h:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method public final m_d390738c()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, La_24107EDB;->l:Landroid/content/res/ColorStateList;

    return-object v0
.end method

.method public final m_785397f2()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    iget-object v0, p0, La_24107EDB;->m:Landroid/graphics/PorterDuff$Mode;

    return-object v0
.end method

.method public final m_008c83de()Landroid/content/Intent;
    .locals 1

    iget-object v0, p0, La_24107EDB;->c:Landroid/content/Intent;

    return-object v0
.end method

.method public final getItemId()I
    .locals 1

    const v0, 0x102002c

    return v0
.end method

.method public final m_0ba9b754()Landroid/view/ContextMenu$ContextMenuInfo;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final m_ec7c6023()I
    .locals 1

    iget v0, p0, La_24107EDB;->e:I

    return v0
.end method

.method public final m_c03fe59b()C
    .locals 1

    iget-char v0, p0, La_24107EDB;->d:C

    return v0
.end method

.method public final m_9613567e()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final m_853f0c2c()Landroid/view/SubMenu;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final m_bb469150()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, La_24107EDB;->a:Ljava/lang/CharSequence;

    return-object v0
.end method

.method public final m_f4e49e4d()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, La_24107EDB;->b:Ljava/lang/CharSequence;

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, La_24107EDB;->a:Ljava/lang/CharSequence;

    :goto_0
    return-object v0
.end method

.method public final m_47b03af3()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, La_24107EDB;->k:Ljava/lang/CharSequence;

    return-object v0
.end method

.method public final m_3736300c()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final m_675f4160()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final m_5272213f()Z
    .locals 2

    iget v0, p0, La_24107EDB;->p:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public final m_9d7977aa()Z
    .locals 1

    iget v0, p0, La_24107EDB;->p:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final m_4e57e965()Z
    .locals 1

    iget v0, p0, La_24107EDB;->p:I

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final m_3ee454cc()Z
    .locals 1

    iget v0, p0, La_24107EDB;->p:I

    and-int/lit8 v0, v0, 0x8

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final m_3cb0a7a6(Landroid/view/ActionProvider;)Landroid/view/MenuItem;
    .locals 0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final m_b9079313(I)Landroid/view/MenuItem;
    .locals 0

    .line 2
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final m_b9079313(Landroid/view/View;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final m_4f2a3fcd(C)Landroid/view/MenuItem;
    .locals 0

    .line 1
    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, La_24107EDB;->f:C

    return-object p0
.end method

.method public final m_4f2a3fcd(CI)Landroid/view/MenuItem;
    .locals 0

    .line 2
    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, La_24107EDB;->f:C

    .line 3
    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, La_24107EDB;->g:I

    return-object p0
.end method

.method public final m_f2777f7a(Z)Landroid/view/MenuItem;
    .locals 1

    iget v0, p0, La_24107EDB;->p:I

    and-int/lit8 v0, v0, -0x2

    or-int/2addr p1, v0

    iput p1, p0, La_24107EDB;->p:I

    return-object p0
.end method

.method public final m_280f4fcc(Z)Landroid/view/MenuItem;
    .locals 1

    iget v0, p0, La_24107EDB;->p:I

    and-int/lit8 v0, v0, -0x3

    if-eqz p1, :cond_0

    const/4 p1, 0x2

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    or-int/2addr p1, v0

    iput p1, p0, La_24107EDB;->p:I

    return-object p0
.end method

.method public final m_c2ef07e0(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 0

    .line 2
    iput-object p1, p0, La_24107EDB;->j:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_c2ef07e0(Ljava/lang/CharSequence;)Lrt;
    .locals 0

    .line 1
    iput-object p1, p0, La_24107EDB;->j:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_1d1aaacf(Z)Landroid/view/MenuItem;
    .locals 1

    iget v0, p0, La_24107EDB;->p:I

    and-int/lit8 v0, v0, -0x11

    if-eqz p1, :cond_0

    const/16 p1, 0x10

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    or-int/2addr p1, v0

    iput p1, p0, La_24107EDB;->p:I

    return-object p0
.end method

.method public final m_ffb07a6f(I)Landroid/view/MenuItem;
    .locals 1

    .line 3
    sget-object v0, La_F654953D;->a:Ljava/lang/Object;

    .line 4
    iget-object v0, p0, La_24107EDB;->i:Landroid/content/Context;

    invoke-static {v0, p1}, La_68EF645C;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    .line 5
    iput-object p1, p0, La_24107EDB;->h:Landroid/graphics/drawable/Drawable;

    .line 6
    invoke-virtual {p0}, La_24107EDB;->c()V

    return-object p0
.end method

.method public final m_ffb07a6f(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-object p1, p0, La_24107EDB;->h:Landroid/graphics/drawable/Drawable;

    .line 2
    invoke-virtual {p0}, La_24107EDB;->c()V

    return-object p0
.end method

.method public final m_668e73db(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-object p1, p0, La_24107EDB;->l:Landroid/content/res/ColorStateList;

    .line 3
    const/4 p1, 0x1

    .line 4
    iput-boolean p1, p0, La_24107EDB;->n:Z

    .line 6
    invoke-virtual {p0}, La_24107EDB;->c()V

    .line 9
    return-object p0
.end method

.method public final m_c52da921(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-object p1, p0, La_24107EDB;->m:Landroid/graphics/PorterDuff$Mode;

    .line 3
    const/4 p1, 0x1

    .line 4
    iput-boolean p1, p0, La_24107EDB;->o:Z

    .line 6
    invoke-virtual {p0}, La_24107EDB;->c()V

    .line 9
    return-object p0
.end method

.method public final m_dce4172a(Landroid/content/Intent;)Landroid/view/MenuItem;
    .locals 0

    iput-object p1, p0, La_24107EDB;->c:Landroid/content/Intent;

    return-object p0
.end method

.method public final m_96ef8e90(C)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-char p1, p0, La_24107EDB;->d:C

    return-object p0
.end method

.method public final m_96ef8e90(CI)Landroid/view/MenuItem;
    .locals 0

    .line 2
    iput-char p1, p0, La_24107EDB;->d:C

    .line 3
    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, La_24107EDB;->e:I

    return-object p0
.end method

.method public final m_017cf27f(Landroid/view/MenuItem$OnActionExpandListener;)Landroid/view/MenuItem;
    .locals 0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final m_7a99d5db(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;
    .locals 0

    return-object p0
.end method

.method public final m_3a4c008a(CC)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-char p1, p0, La_24107EDB;->d:C

    .line 2
    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, La_24107EDB;->f:C

    return-object p0
.end method

.method public final m_3a4c008a(CCII)Landroid/view/MenuItem;
    .locals 0

    .line 3
    iput-char p1, p0, La_24107EDB;->d:C

    .line 4
    invoke-static {p3}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, La_24107EDB;->e:I

    .line 5
    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, La_24107EDB;->f:C

    .line 6
    invoke-static {p4}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, La_24107EDB;->g:I

    return-object p0
.end method

.method public final m_b4b00030(I)V
    .locals 0

    return-void
.end method

.method public final m_732486a5(I)Landroid/view/MenuItem;
    .locals 0

    return-object p0
.end method

.method public final m_68547c74(I)Landroid/view/MenuItem;
    .locals 1

    .line 2
    iget-object v0, p0, La_24107EDB;->i:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->m_117d8ed5()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, La_24107EDB;->a:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_68547c74(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-object p1, p0, La_24107EDB;->a:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_2d49b6fa(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 0

    iput-object p1, p0, La_24107EDB;->b:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_089e0ce1(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 0

    .line 2
    iput-object p1, p0, La_24107EDB;->k:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_089e0ce1(Ljava/lang/CharSequence;)Lrt;
    .locals 0

    .line 1
    iput-object p1, p0, La_24107EDB;->k:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_115b7488(Z)Landroid/view/MenuItem;
    .locals 2

    iget v0, p0, La_24107EDB;->p:I

    const/16 v1, 0x8

    and-int/2addr v0, v1

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    :cond_0
    or-int p1, v0, v1

    iput p1, p0, La_24107EDB;->p:I

    return-object p0
.end method
