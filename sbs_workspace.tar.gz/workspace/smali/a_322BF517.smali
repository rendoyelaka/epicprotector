.class public final La_322BF517;
.super Ljava/lang/Object;
.source "myyjmfyq.java"
# generated-60445

# ep-bjxurtthpulu

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_C959F543;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public static a(Ljava/lang/String;)Ljava/util/Locale;
    .locals 0

    invoke-static {p0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object p0

    return-object p0
.end method
