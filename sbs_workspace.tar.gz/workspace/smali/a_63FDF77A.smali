.class public final La_63FDF77A;
# ep-rjxjcbzsqvga
.super Ljava/lang/Object;
.source "wvugecho.java"
# verified-17720
# compiled-15111
# validated-22240

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# instance fields
.field public final synthetic a:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;


# direct methods
.method public constructor <init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)V
    .locals 0

    iput-object p1, p0, La_63FDF77A;->a:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    .line 4
    move-result-object p1

    .line 5
    check-cast p1, Ljava/lang/Float;

    .line 7
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 10
    move-result p1

    .line 11
    iget-object v0, p0, La_63FDF77A;->a:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    .line 13
    iget-object v0, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->i:La_C079EF02;

    .line 15
    if-eqz v0, :cond_0

    .line 17
    invoke-virtual {v0, p1}, La_C079EF02;->n(F)V

    .line 20
    :cond_0
    return-void
.end method
