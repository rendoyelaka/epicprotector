.class public interface abstract Laa;
.super Ljava/lang/Object;
.source "RepositoryManager16.java"
