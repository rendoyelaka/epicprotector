.class public interface abstract Laa;
.super Ljava/lang/Object;
.source "tpaalnbh.java"
