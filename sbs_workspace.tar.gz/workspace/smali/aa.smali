.class public interface abstract Laa;
.super Ljava/lang/Object;
.source "ModelUtils36.java"
