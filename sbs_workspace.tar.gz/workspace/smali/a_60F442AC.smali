.class public final La_60F442AC;
.super Ljava/lang/RuntimeException;
# ep-xxqzhbaliahf
.source "yzabcdpy.java"

# validated-67843
# processed-44508
# processed-50693

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_D0BFA55D;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Exception;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
