.class public final La_86576C58;
.super La_07EFADCD;
.source "tlddissw.java"
# generated-21227
# generated-83085

# ep-xohffvtklgzv

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Luu;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Luu;


# direct methods
.method public constructor <init>(Luu;)V
    .locals 0

    iput-object p1, p0, La_86576C58;->c:Luu;

    invoke-direct {p0}, La_07EFADCD;-><init>()V

    return-void
.end method


# virtual methods
.method public final k(I)V
    .locals 1

    .line 1
    const/4 p1, 0x1

    .line 2
    iget-object v0, p0, La_86576C58;->c:Luu;

    .line 4
    iput-boolean p1, v0, Luu;->d:Z

    .line 6
    iget-object p1, v0, Luu;->e:Ljava/lang/ref/WeakReference;

    .line 8
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 11
    move-result-object p1

    .line 12
    check-cast p1, La_3E6A9D4B;

    .line 14
    if-eqz p1, :cond_0

    .line 16
    invoke-interface {p1}, La_3E6A9D4B;->a()V

    .line 19
    :cond_0
    return-void
.end method

.method public final m(Landroid/graphics/Typeface;Z)V
    .locals 0

    .line 1
    if-eqz p2, :cond_0

    .line 3
    return-void

    .line 4
    :cond_0
    const/4 p1, 0x1

    .line 5
    iget-object p2, p0, La_86576C58;->c:Luu;

    .line 7
    iput-boolean p1, p2, Luu;->d:Z

    .line 9
    iget-object p1, p2, Luu;->e:Ljava/lang/ref/WeakReference;

    .line 11
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 14
    move-result-object p1

    .line 15
    check-cast p1, La_3E6A9D4B;

    .line 17
    if-eqz p1, :cond_1

    .line 19
    invoke-interface {p1}, La_3E6A9D4B;->a()V

    .line 22
    :cond_1
    return-void
.end method
