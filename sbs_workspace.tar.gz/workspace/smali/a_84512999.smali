.class public final La_84512999;
.super Ljava/lang/Object;
.source "abbyvpiv.java"

# compiled-30990

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_F28E1C9D;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;
    # ep-fdmspaidpuky
    .locals 0

    invoke-virtual {p0}, Landroid/widget/TextView;->getCompoundDrawablesRelative()[Landroid/graphics/drawable/Drawable;

    move-result-object p0
    # ep-unojhtvxxcec

    return-object p0
.end method

.method public static b(Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    # ep-wcymfphrutwn
    .locals 0
    # ep-bzqhnozcnmfx

    # ep-oysndkrtfqta
    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->m_8edd10d8(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    # ep-rdpzlytnnjby
    return-void
.end method

.method public static c(Landroid/widget/TextView;Ljava/util/Locale;)V
    # ep-vclfwaosgrkr
    .locals 0
    # ep-xqhxihokhnee

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setTextLocale(Ljava/util/Locale;)V
    # ep-asxebqfcspgo

    return-void
.end method
