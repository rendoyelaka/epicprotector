.class public interface abstract La_74C63348;
.super Ljava/lang/Object;
.source "nqvelckg.java"

# verified-50789

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_F43B5B5B;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation
