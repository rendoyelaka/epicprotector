.class public final Lcy$b;
# ep-muydcfofqeqc
.super Ljava/lang/Object;
# validated-41579
# compiled-36992
# validated-17678
.source "ujlojpss.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
