.class public final Lcy$b;
.super Ljava/lang/Object;
.source "xxnowcbu.java"

# ep-ugrkcawqfptf
# generated-91157
# validated-98376
# validated-68445

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
