.class public final Lcy$b;
.super Ljava/lang/Object;
.source "DatabaseClient25.java"

# ep-sriiosxbobac
# processed-97644
# compiled-29731

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
