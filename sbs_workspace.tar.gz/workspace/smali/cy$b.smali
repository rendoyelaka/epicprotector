.class public final Lcy$b;
.super Ljava/lang/Object;
# ep-pgvnlgvdewyy
.source "ejolregh.java"
# verified-55166
# processed-76441
# validated-76772


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
