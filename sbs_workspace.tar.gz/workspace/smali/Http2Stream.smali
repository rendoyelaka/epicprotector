.class public final LHttp2Stream;
# ep-yldavzmdxcke
.super Ljava/lang/Object;
.source "ljtaekth.java"

# generated-85598
# interfaces
.implements Ljava/io/Closeable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LHttp2Stream$b;,
        LHttp2Stream$a;
    }
.end annotation


# static fields
.field public static final g:Ljava/util/logging/Logger;


# instance fields
.field public final c:Lv4;

.field public final d:LHttp2Stream$a;

.field public final e:Z

.field public final f:Log$a;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    const-class v0, Lqg;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    sput-object v0, LHttp2Stream;->g:Ljava/util/logging/Logger;

    return-void
.end method

.method public constructor <init>(Lv4;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, LHttp2Stream;->c:Lv4;

    .line 6
    iput-boolean p2, p0, LHttp2Stream;->e:Z

    .line 8
    new-instance p2, LHttp2Stream$a;

    .line 10
    invoke-direct {p2, p1}, LHttp2Stream$a;-><init>(Lv4;)V

    .line 13
    iput-object p2, p0, LHttp2Stream;->d:LHttp2Stream$a;

    .line 15
    new-instance p1, Log$a;

    .line 17
    invoke-direct {p1, p2}, Log$a;-><init>(LHttp2Stream$a;)V

    .line 20
    iput-object p1, p0, LHttp2Stream;->f:Log$a;

    .line 22
    return-void
.end method

.method public static h(IBS)I
    .locals 1

    .line 1
    and-int/lit8 p1, p1, 0x8

    .line 3
    if-eqz p1, :cond_0

    .line 5
    add-int/lit8 p0, p0, -0x1

    .line 7
    :cond_0
    if-gt p2, p0, :cond_1

    .line 9
    sub-int/2addr p0, p2

    .line 10
    int-to-short p0, p0

    .line 11
    return p0

    .line 12
    :cond_1
    const/4 p1, 0x2

    .line 13
    new-array p1, p1, [Ljava/lang/Object;

    .line 15
    const/4 v0, 0x0

    .line 16
    invoke-static {p2}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    .line 19
    move-result-object p2

    .line 20
    aput-object p2, p1, v0

    .line 22
    const/4 p2, 0x1

    .line 23
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 26
    move-result-object p0

    .line 27
    aput-object p0, p1, p2

    .line 29
    const-string p0, "fZU77FCe6Z3RSkSfl28mcR5pwla5UB6bhbD3SJnJKz5EqR3WeP3KtOBoYqX4GHU="
    invoke-static {p0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p0

    .line 31
    invoke-static {p0, p1}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 34
    const/4 p0, 0x0

    .line 35
    throw p0
.end method


# virtual methods
.method public final close()V
    .locals 1

    iget-object v0, p0, LHttp2Stream;->c:Lv4;

    invoke-interface {v0}, Lrs;->close()V

    return-void
.end method

.method public final j(LHttp2Stream$b;)Z
    .locals 19

    .line 1
    move-object/from16 v1, p0

    .line 3
    move-object/from16 v0, p1

    .line 5
    const/4 v2, 0x0

    .line 6
    :try_start_0
    iget-object v3, v1, LHttp2Stream;->c:Lv4;

    .line 8
    const-wide/16 v4, 0x9

    .line 10
    invoke-interface {v3, v4, v5}, Lv4;->l(J)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 13
    iget-object v3, v1, LHttp2Stream;->c:Lv4;

    .line 15
    invoke-interface {v3}, Lv4;->readByte()B

    .line 18
    move-result v4

    .line 19
    and-int/lit16 v4, v4, 0xff

    .line 21
    shl-int/lit8 v4, v4, 0x10

    .line 23
    invoke-interface {v3}, Lv4;->readByte()B

    .line 26
    move-result v5

    .line 27
    and-int/lit16 v5, v5, 0xff

    .line 29
    shl-int/lit8 v5, v5, 0x8

    .line 31
    or-int/2addr v4, v5

    .line 32
    invoke-interface {v3}, Lv4;->readByte()B

    .line 35
    move-result v3

    .line 36
    and-int/lit16 v3, v3, 0xff

    .line 38
    or-int/2addr v3, v4

    .line 39
    const/4 v4, 0x0

    .line 40
    const/4 v5, 0x1

    .line 41
    if-ltz v3, :cond_1e

    .line 43
    const/16 v6, 0x4000

    .line 45
    if-gt v3, v6, :cond_1e

    .line 47
    iget-object v6, v1, LHttp2Stream;->c:Lv4;

    .line 49
    invoke-interface {v6}, Lv4;->readByte()B

    .line 52
    move-result v6

    .line 53
    and-int/lit16 v6, v6, 0xff

    .line 55
    int-to-byte v6, v6

    .line 56
    iget-object v7, v1, LHttp2Stream;->c:Lv4;

    .line 58
    invoke-interface {v7}, Lv4;->readByte()B

    .line 61
    move-result v7

    .line 62
    and-int/lit16 v7, v7, 0xff

    .line 64
    int-to-byte v7, v7

    .line 65
    iget-object v8, v1, LHttp2Stream;->c:Lv4;

    .line 67
    invoke-interface {v8}, Lv4;->readInt()I

    .line 70
    move-result v8

    .line 71
    const v9, 0x7fffffff

    .line 74
    and-int v13, v8, v9

    .line 76
    sget-object v8, LHttp2Stream;->g:Ljava/util/logging/Logger;

    .line 78
    sget-object v9, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;

    .line 80
    invoke-virtual {v8, v9}, Ljava/util/logging/Logger;->isLoggable(Ljava/util/logging/Level;)Z

    .line 83
    move-result v9

    .line 84
    if-eqz v9, :cond_0

    .line 86
    invoke-static {v5, v13, v3, v6, v7}, Lqg;->a(ZIIBB)Ljava/lang/String;

    .line 89
    move-result-object v9

    .line 90
    invoke-virtual {v8, v9}, Ljava/util/logging/Logger;->fine(Ljava/lang/String;)V

    .line 93
    :cond_0
    const/4 v8, 0x4

    .line 94
    const/4 v9, 0x2

    .line 95
    packed-switch v6, :pswitch_data_0

    .line 98
    iget-object v0, v1, LHttp2Stream;->c:Lv4;

    .line 100
    int-to-long v2, v3

    .line 101
    invoke-interface {v0, v2, v3}, Lv4;->skip(J)V

    .line 104
    goto/16 :goto_3

    .line 106
    :pswitch_0
    invoke-virtual {v1, v0, v3, v13}, LHttp2Stream;->y(LHttp2Stream$b;II)V

    .line 109
    goto/16 :goto_3

    .line 111
    :pswitch_1
    invoke-virtual {v1, v0, v3, v13}, LHttp2Stream;->s(LHttp2Stream$b;II)V

    .line 114
    goto/16 :goto_3

    .line 116
    :pswitch_2
    invoke-virtual {v1, v0, v3, v7, v13}, LHttp2Stream;->v(LHttp2Stream$b;IBI)V

    .line 119
    goto/16 :goto_3

    .line 121
    :pswitch_3
    invoke-virtual {v1, v0, v3, v7, v13}, LHttp2Stream;->w(LHttp2Stream$b;IBI)V

    .line 124
    goto/16 :goto_3

    .line 126
    :pswitch_4
    invoke-virtual {v1, v0, v3, v7, v13}, LHttp2Stream;->x(LHttp2Stream$b;IBI)V

    .line 129
    goto/16 :goto_3

    .line 131
    :pswitch_5
    if-ne v3, v8, :cond_7

    .line 133
    if-eqz v13, :cond_6

    .line 135
    iget-object v3, v1, LHttp2Stream;->c:Lv4;

    .line 137
    invoke-interface {v3}, Lv4;->readInt()I

    .line 140
    move-result v3

    .line 141
    const/4 v6, 0x6

    .line 142
    invoke-static {v6}, Lps;->p(I)[I

    .line 145
    move-result-object v6

    .line 146
    array-length v7, v6

    .line 147
    const/4 v8, 0x0

    .line 148
    :goto_0
    if-ge v8, v7, :cond_2

    .line 150
    aget v10, v6, v8

    .line 152
    invoke-static {v10}, Lps;->a(I)I

    .line 155
    move-result v11

    .line 156
    if-ne v11, v3, :cond_1

    .line 158
    goto :goto_1

    .line 159
    :cond_1
    add-int/lit8 v8, v8, 0x1

    .line 161
    goto :goto_0

    .line 162
    :cond_2
    const/4 v10, 0x0

    .line 163
    :goto_1
    if-eqz v10, :cond_5

    .line 165
    check-cast v0, LHttp2Connection$d;

    .line 167
    iget-object v0, v0, LHttp2Connection$d;->e:LHttp2Connection;

    .line 169
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 172
    if-eqz v13, :cond_3

    .line 174
    and-int/lit8 v3, v13, 0x1

    .line 176
    if-nez v3, :cond_3

    .line 178
    const/4 v3, 0x1

    .line 179
    goto :goto_2

    .line 180
    :cond_3
    const/4 v3, 0x0

    .line 181
    :goto_2
    if-eqz v3, :cond_4

    .line 183
    iget-object v3, v0, LHttp2Connection;->j:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 185
    new-instance v4, Lyg;

    .line 187
    new-array v6, v9, [Ljava/lang/Object;

    .line 189
    iget-object v7, v0, LHttp2Connection;->f:Ljava/lang/String;

    .line 191
    aput-object v7, v6, v2

    .line 193
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 196
    move-result-object v2

    .line 197
    aput-object v2, v6, v5

    .line 199
    invoke-direct {v4, v0, v6, v13, v10}, Lyg;-><init>(LHttp2Connection;[Ljava/lang/Object;II)V

    .line 202
    invoke-virtual {v3, v4}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 205
    goto :goto_3

    .line 206
    :cond_4
    invoke-virtual {v0, v13}, LHttp2Connection;->s(I)Ldh;

    .line 209
    move-result-object v0

    .line 210
    if-eqz v0, :cond_a

    .line 212
    invoke-virtual {v0, v10}, Ldh;->h(I)V

    .line 215
    goto :goto_3

    .line 216
    :cond_5
    new-array v0, v5, [Ljava/lang/Object;

    .line 218
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 221
    move-result-object v3

    .line 222
    aput-object v3, v0, v2

    .line 224
    const-string v2, "eZ4k/UCP9YXRXEKfnXxLIQpjw0enUl3Kk/TpDZneKS0NpBvceueG9Oo="
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 226
    invoke-static {v2, v0}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 229
    throw v4

    .line 230
    :cond_6
    const-string v0, "eZ4k/UCP9YXRXEKfnXxLIQx51Fq2Wnfa1q30SNs="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 232
    new-array v2, v2, [Ljava/lang/Object;

    .line 234
    invoke-static {v0, v2}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 237
    throw v4

    .line 238
    :cond_7
    new-array v0, v5, [Ljava/lang/Object;

    .line 240
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 243
    move-result-object v3

    .line 244
    aput-object v3, v0, v2

    .line 246
    const-string v2, "eZ4k/UCP9YXRXEKfnXxLIRNoyFijXwSe0/TpSdaMcg=="
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 248
    invoke-static {v2, v0}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 251
    throw v4

    .line 252
    :pswitch_6
    const/4 v6, 0x5

    .line 253
    if-ne v3, v6, :cond_9

    .line 255
    if-eqz v13, :cond_8

    .line 257
    iget-object v2, v1, LHttp2Stream;->c:Lv4;

    .line 259
    invoke-interface {v2}, Lv4;->readInt()I

    .line 262
    invoke-interface {v2}, Lv4;->readByte()B

    .line 265
    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 268
    goto :goto_3

    .line 269
    :cond_8
    const-string v0, "eZ4k/UCN9JjBXV+ZgR11dQ1ox1KeUx6Dy7D5"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 271
    new-array v2, v2, [Ljava/lang/Object;

    .line 273
    invoke-static {v0, v2}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 276
    throw v4

    .line 277
    :cond_9
    new-array v0, v5, [Ljava/lang/Object;

    .line 279
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 282
    move-result-object v3

    .line 283
    aput-object v3, v0, v2

    .line 285
    const-string v2, "eZ4k/UCN9JjBXV+ZgR1qZBFq0lftFxva1rH0SN4="
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 287
    invoke-static {v2, v0}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 290
    throw v4

    .line 291
    :pswitch_7
    invoke-virtual {v1, v0, v3, v7, v13}, LHttp2Stream;->u(LHttp2Stream$b;IBI)V

    .line 294
    :cond_a
    :goto_3
    const/4 v0, 0x1

    .line 295
    goto/16 :goto_e

    .line 297
    :pswitch_8
    and-int/lit8 v6, v7, 0x1

    .line 299
    if-eqz v6, :cond_b

    .line 301
    const/16 v16, 0x1

    .line 303
    goto :goto_4

    .line 304
    :cond_b
    const/16 v16, 0x0

    .line 306
    :goto_4
    and-int/lit8 v6, v7, 0x20

    .line 308
    if-eqz v6, :cond_c

    .line 310
    const/4 v6, 0x1

    .line 311
    goto :goto_5

    .line 312
    :cond_c
    const/4 v6, 0x0

    .line 313
    :goto_5
    if-nez v6, :cond_1d

    .line 315
    and-int/lit8 v4, v7, 0x8

    .line 317
    if-eqz v4, :cond_d

    .line 319
    iget-object v4, v1, LHttp2Stream;->c:Lv4;

    .line 321
    invoke-interface {v4}, Lv4;->readByte()B

    .line 324
    move-result v4

    .line 325
    and-int/lit16 v4, v4, 0xff

    .line 327
    int-to-short v4, v4

    .line 328
    goto :goto_6

    .line 329
    :cond_d
    const/4 v4, 0x0

    .line 330
    :goto_6
    invoke-static {v3, v7, v4}, LHttp2Stream;->h(IBS)I

    .line 333
    move-result v15

    .line 334
    iget-object v3, v1, LHttp2Stream;->c:Lv4;

    .line 336
    check-cast v0, LHttp2Connection$d;

    .line 338
    iget-object v6, v0, LHttp2Connection$d;->e:LHttp2Connection;

    .line 340
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 343
    if-eqz v13, :cond_e

    .line 345
    and-int/lit8 v6, v13, 0x1

    .line 347
    if-nez v6, :cond_e

    .line 349
    const/4 v6, 0x1

    .line 350
    goto :goto_7

    .line 351
    :cond_e
    const/4 v6, 0x0

    .line 352
    :goto_7
    if-eqz v6, :cond_10

    .line 354
    iget-object v11, v0, LHttp2Connection$d;->e:LHttp2Connection;

    .line 356
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 359
    new-instance v14, Lt4;

    .line 361
    invoke-direct {v14}, Lt4;-><init>()V

    .line 364
    int-to-long v6, v15

    .line 365
    invoke-interface {v3, v6, v7}, Lv4;->l(J)V

    .line 368
    invoke-interface {v3, v14, v6, v7}, Lrs;->k(Lt4;J)J

    .line 371
    iget-wide v2, v14, Lt4;->d:J

    .line 373
    cmp-long v0, v2, v6

    .line 375
    if-nez v0, :cond_f

    .line 377
    iget-object v0, v11, LHttp2Connection;->j:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 379
    new-instance v2, Lxg;

    .line 381
    new-array v12, v9, [Ljava/lang/Object;

    .line 383
    iget-object v3, v11, LHttp2Connection;->f:Ljava/lang/String;

    .line 385
    const/4 v6, 0x0

    .line 386
    aput-object v3, v12, v6

    .line 388
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 391
    move-result-object v3

    .line 392
    aput-object v3, v12, v5

    .line 394
    move-object v10, v2

    .line 395
    invoke-direct/range {v10 .. v16}, Lxg;-><init>(LHttp2Connection;[Ljava/lang/Object;ILt4;IZ)V

    .line 398
    invoke-virtual {v0, v2}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 401
    goto/16 :goto_d

    .line 403
    :cond_f
    new-instance v0, Ljava/io/IOException;

    .line 405
    new-instance v2, Ljava/lang/StringBuilder;

    .line 407
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 410
    iget-wide v3, v14, Lt4;->d:J

    .line 412
    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 415
    const-string v3, "DeZJmA=="
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3

    .line 417
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 420
    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 423
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 426
    move-result-object v2

    .line 427
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 430
    throw v0

    .line 431
    :cond_10
    iget-object v2, v0, LHttp2Connection$d;->e:LHttp2Connection;

    .line 433
    invoke-virtual {v2, v13}, LHttp2Connection;->j(I)Ldh;

    .line 436
    move-result-object v2

    .line 437
    if-nez v2, :cond_11

    .line 439
    iget-object v0, v0, LHttp2Connection$d;->e:LHttp2Connection;

    .line 441
    invoke-virtual {v0, v13, v9}, LHttp2Connection;->v(II)V

    .line 444
    int-to-long v6, v15

    .line 445
    invoke-interface {v3, v6, v7}, Lv4;->skip(J)V

    .line 448
    goto/16 :goto_d

    .line 450
    :cond_11
    iget-object v0, v2, Ldh;->f:Ldh$b;

    .line 452
    int-to-long v6, v15

    .line 453
    :goto_8
    const-wide/16 v11, 0x0

    .line 455
    cmp-long v9, v6, v11

    .line 457
    if-lez v9, :cond_1b

    .line 459
    iget-object v9, v0, Ldh$b;->h:Ldh;

    .line 461
    monitor-enter v9

    .line 462
    :try_start_1
    iget-boolean v13, v0, Ldh$b;->g:Z

    .line 464
    iget-object v14, v0, Ldh$b;->d:Lt4;

    .line 466
    iget-wide v14, v14, Lt4;->d:J

    .line 468
    add-long/2addr v14, v6

    .line 469
    iget-wide v10, v0, Ldh$b;->e:J

    .line 471
    cmp-long v12, v14, v10

    .line 473
    if-lez v12, :cond_12

    .line 475
    const/4 v10, 0x1

    .line 476
    goto :goto_9

    .line 477
    :cond_12
    const/4 v10, 0x0

    .line 478
    :goto_9
    monitor-exit v9
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 479
    if-eqz v10, :cond_14

    .line 481
    invoke-interface {v3, v6, v7}, Lv4;->skip(J)V

    .line 484
    iget-object v0, v0, Ldh$b;->h:Ldh;

    .line 486
    invoke-virtual {v0, v8}, Ldh;->d(I)Z

    .line 489
    move-result v3

    .line 490
    if-nez v3, :cond_13

    .line 492
    goto :goto_c

    .line 493
    :cond_13
    iget-object v3, v0, Ldh;->d:LHttp2Connection;

    .line 495
    iget v0, v0, Ldh;->c:I

    .line 497
    invoke-virtual {v3, v0, v8}, LHttp2Connection;->v(II)V

    .line 500
    goto :goto_c

    .line 501
    :cond_14
    if-eqz v13, :cond_15

    .line 503
    invoke-interface {v3, v6, v7}, Lv4;->skip(J)V

    .line 506
    goto :goto_c

    .line 507
    :cond_15
    iget-object v9, v0, Ldh$b;->c:Lt4;

    .line 509
    invoke-interface {v3, v9, v6, v7}, Lrs;->k(Lt4;J)J

    .line 512
    move-result-wide v9

    .line 513
    const-wide/16 v11, -0x1

    .line 515
    cmp-long v13, v9, v11

    .line 517
    if-eqz v13, :cond_1a

    .line 519
    sub-long/2addr v6, v9

    .line 520
    iget-object v9, v0, Ldh$b;->h:Ldh;

    .line 522
    monitor-enter v9

    .line 523
    :try_start_2
    iget-object v10, v0, Ldh$b;->d:Lt4;

    .line 525
    iget-wide v13, v10, Lt4;->d:J

    .line 527
    const-wide/16 v17, 0x0

    .line 529
    cmp-long v15, v13, v17

    .line 531
    if-nez v15, :cond_16

    .line 533
    const/4 v13, 0x1

    .line 534
    goto :goto_a

    .line 535
    :cond_16
    const/4 v13, 0x0

    .line 536
    :goto_a
    iget-object v14, v0, Ldh$b;->c:Lt4;

    .line 538
    if-eqz v14, :cond_19

    .line 540
    move-wide/from16 v17, v6

    .line 542
    :goto_b
    const-wide/16 v5, 0x2000

    .line 544
    invoke-virtual {v14, v10, v5, v6}, Lt4;->k(Lt4;J)J

    .line 547
    move-result-wide v5

    .line 548
    cmp-long v7, v5, v11

    .line 550
    if-eqz v7, :cond_17

    .line 552
    goto :goto_b

    .line 553
    :cond_17
    if-eqz v13, :cond_18

    .line 555
    iget-object v5, v0, Ldh$b;->h:Ldh;

    .line 557
    invoke-virtual {v5}, Ljava/lang/Object;->notifyAll()V

    .line 560
    :cond_18
    monitor-exit v9

    .line 561
    move-wide/from16 v6, v17

    .line 563
    const/4 v5, 0x1

    .line 564
    goto :goto_8

    .line 565
    :cond_19
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 567
    const-string v2, "XqgByny4huyzL3i4tFE="
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 569
    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 572
    throw v0

    .line 573
    :catchall_0
    move-exception v0

    .line 574
    monitor-exit v9
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 575
    throw v0

    .line 576
    :cond_1a
    new-instance v0, Ljava/io/EOFException;

    .line 578
    invoke-direct {v0}, Ljava/io/EOFException;-><init>()V

    .line 581
    throw v0

    .line 582
    :catchall_1
    move-exception v0

    .line 583
    :try_start_3
    monitor-exit v9
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 584
    throw v0

    .line 585
    :cond_1b
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 588
    :goto_c
    if-eqz v16, :cond_1c

    .line 590
    invoke-virtual {v2}, Ldh;->f()V

    .line 593
    :cond_1c
    :goto_d
    iget-object v0, v1, LHttp2Stream;->c:Lv4;

    .line 595
    int-to-long v2, v4

    .line 596
    invoke-interface {v0, v2, v3}, Lv4;->skip(J)V

    .line 599
    goto/16 :goto_3

    .line 601
    :cond_1d
    const-string v0, "fZU77FCe6Z3RSkSfl288ITlB53iIdHHzpsKMO7jpAn9argDQcKjS8d1KQpmRc0FSIE7pcodle+2lz40pv+0="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 603
    const/4 v2, 0x0

    .line 604
    new-array v2, v2, [Ljava/lang/Object;

    .line 606
    invoke-static {v0, v2}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 609
    throw v4

    .line 610
    :goto_e
    return v0

    .line 611
    :cond_1e
    const/4 v0, 0x1

    .line 612
    const-string v2, "a5U19VqC9ZjUSkmIim9JU0Utg0w="
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 614
    new-array v0, v0, [Ljava/lang/Object;

    .line 616
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 619
    move-result-object v3

    .line 620
    const/4 v5, 0x0

    .line 621
    aput-object v3, v0, v5

    .line 623
    invoke-static {v2, v0}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 626
    throw v4

    .line 627
    :catch_0
    const/4 v5, 0x0

    .line 628
    return v5

    .line 629
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final r()V
    .locals 7

    .line 1
    iget-boolean v0, p0, LHttp2Stream;->e:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    sget-object v0, Lqg;->a:Lz4;

    .line 8
    iget-object v1, v0, Lz4;->c:[B

    .line 10
    array-length v1, v1

    .line 11
    int-to-long v1, v1

    .line 12
    iget-object v3, p0, LHttp2Stream;->c:Lv4;

    .line 14
    invoke-interface {v3, v1, v2}, Lv4;->e(J)Lz4;

    .line 17
    move-result-object v1

    .line 18
    sget-object v2, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;

    .line 20
    sget-object v3, LHttp2Stream;->g:Ljava/util/logging/Logger;

    .line 22
    invoke-virtual {v3, v2}, Ljava/util/logging/Logger;->isLoggable(Ljava/util/logging/Level;)Z

    .line 25
    move-result v2

    .line 26
    const/4 v4, 0x0

    .line 27
    const/4 v5, 0x1

    .line 28
    if-eqz v2, :cond_1

    .line 30
    new-array v2, v5, [Ljava/lang/Object;

    .line 32
    invoke-virtual {v1}, Lz4;->f()Ljava/lang/String;

    .line 35
    move-result-object v6

    .line 36
    aput-object v6, v2, v4

    .line 38
    const-string v6, "EftU+1CT6JTNW1+Clh0jcg=="
    invoke-static {v6}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v6

    .line 40
    invoke-static {v6, v2}, Lex;->g(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 43
    move-result-object v2

    .line 44
    invoke-virtual {v3, v2}, Ljava/util/logging/Logger;->fine(Ljava/lang/String;)V

    .line 47
    :cond_1
    invoke-virtual {v0, v1}, Lz4;->equals(Ljava/lang/Object;)Z

    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_2

    .line 53
    return-void

    .line 54
    :cond_2
    new-array v0, v5, [Ljava/lang/Object;

    .line 56
    invoke-virtual {v1}, Lz4;->n()Ljava/lang/String;

    .line 59
    move-result-object v1

    .line 60
    aput-object v1, v0, v4

    .line 62
    const-string v1, "aL8E3Xypw7Wubjaut1NoZBx5z1C5F1bbl/SsGsvOMysNsBXLP/jV"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 64
    invoke-static {v1, v0}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 67
    const/4 v0, 0x0

    .line 68
    throw v0
.end method

.method public final s(LHttp2Stream$b;II)V
    .locals 9

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x1

    .line 4
    const/16 v3, 0x8

    .line 6
    if-lt p2, v3, :cond_9

    .line 8
    if-nez p3, :cond_8

    .line 10
    iget-object p3, p0, LHttp2Stream;->c:Lv4;

    .line 12
    invoke-interface {p3}, Lv4;->readInt()I

    .line 15
    move-result p3

    .line 16
    iget-object v4, p0, LHttp2Stream;->c:Lv4;

    .line 18
    invoke-interface {v4}, Lv4;->readInt()I

    .line 21
    move-result v4

    .line 22
    sub-int/2addr p2, v3

    .line 23
    const/4 v3, 0x6

    .line 24
    invoke-static {v3}, Lps;->p(I)[I

    .line 27
    move-result-object v3

    .line 28
    array-length v5, v3

    .line 29
    const/4 v6, 0x0

    .line 30
    :goto_0
    if-ge v6, v5, :cond_1

    .line 32
    aget v7, v3, v6

    .line 34
    invoke-static {v7}, Lps;->a(I)I

    .line 37
    move-result v8

    .line 38
    if-ne v8, v4, :cond_0

    .line 40
    goto :goto_1

    .line 41
    :cond_0
    add-int/lit8 v6, v6, 0x1

    .line 43
    goto :goto_0

    .line 44
    :cond_1
    const/4 v7, 0x0

    .line 45
    :goto_1
    if-eqz v7, :cond_7

    .line 47
    sget-object v0, Lz4;->g:Lz4;

    .line 49
    if-lez p2, :cond_2

    .line 51
    iget-object v0, p0, LHttp2Stream;->c:Lv4;

    .line 53
    int-to-long v3, p2

    .line 54
    invoke-interface {v0, v3, v4}, Lv4;->e(J)Lz4;

    .line 57
    move-result-object v0

    .line 58
    :cond_2
    check-cast p1, LHttp2Connection$d;

    .line 60
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 63
    invoke-virtual {v0}, Lz4;->j()I

    .line 66
    iget-object p2, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 68
    monitor-enter p2

    .line 69
    :try_start_0
    iget-object v0, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 71
    iget-object v0, v0, LHttp2Connection;->e:Ljava/util/LinkedHashMap;

    .line 73
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    .line 76
    move-result-object v0

    .line 77
    iget-object v3, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 79
    iget-object v3, v3, LHttp2Connection;->e:Ljava/util/LinkedHashMap;

    .line 81
    invoke-interface {v3}, Ljava/util/Map;->size()I

    .line 84
    move-result v3

    .line 85
    new-array v3, v3, [Ldh;

    .line 87
    invoke-interface {v0, v3}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 90
    move-result-object v0

    .line 91
    check-cast v0, [Ldh;

    .line 93
    iget-object v3, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 95
    iput-boolean v2, v3, LHttp2Connection;->i:Z

    .line 97
    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 98
    array-length p2, v0

    .line 99
    const/4 v3, 0x0

    .line 100
    :goto_2
    if-ge v3, p2, :cond_6

    .line 102
    aget-object v4, v0, v3

    .line 104
    iget v5, v4, Ldh;->c:I

    .line 106
    if-le v5, p3, :cond_5

    .line 108
    and-int/lit8 v5, v5, 0x1

    .line 110
    if-ne v5, v2, :cond_3

    .line 112
    const/4 v5, 0x1

    .line 113
    goto :goto_3

    .line 114
    :cond_3
    const/4 v5, 0x0

    .line 115
    :goto_3
    iget-object v6, v4, Ldh;->d:LHttp2Connection;

    .line 117
    iget-boolean v6, v6, LHttp2Connection;->c:Z

    .line 119
    if-ne v6, v5, :cond_4

    .line 121
    const/4 v5, 0x1

    .line 122
    goto :goto_4

    .line 123
    :cond_4
    const/4 v5, 0x0

    .line 124
    :goto_4
    if-eqz v5, :cond_5

    .line 126
    const/4 v5, 0x5

    .line 127
    invoke-virtual {v4, v5}, Ldh;->h(I)V

    .line 130
    iget-object v5, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 132
    iget v4, v4, Ldh;->c:I

    .line 134
    invoke-virtual {v5, v4}, LHttp2Connection;->s(I)Ldh;

    .line 137
    :cond_5
    add-int/lit8 v3, v3, 0x1

    .line 139
    goto :goto_2

    .line 140
    :cond_6
    return-void

    .line 141
    :catchall_0
    move-exception p1

    .line 142
    :try_start_1
    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 143
    throw p1

    .line 144
    :cond_7
    const-string p1, "eZ4k/UCa6ZDZTk/trVNjeQ9oxUuyUx7bhOKmGsvPKTtI/VSdew=="
    invoke-static {p1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    .line 146
    new-array p2, v2, [Ljava/lang/Object;

    .line 148
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 151
    move-result-object p3

    .line 152
    aput-object p3, p2, v1

    .line 154
    invoke-static {p1, p2}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 157
    throw v0

    .line 158
    :cond_8
    const-string p1, "eZ4k/UCa6ZDZTk/tq0l0ZB5g71v3FgOexg=="
    invoke-static {p1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    .line 160
    new-array p2, v1, [Ljava/lang/Object;

    .line 162
    invoke-static {p1, p2}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 165
    throw v0

    .line 166
    :cond_9
    const-string p1, "eZ4k/UCa6ZDZTk/ttFhoZgtlhgP3DwSe0+M="
    invoke-static {p1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    .line 168
    new-array p3, v2, [Ljava/lang/Object;

    .line 170
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 173
    move-result-object p2

    .line 174
    aput-object p2, p3, v1

    .line 176
    invoke-static {p1, p3}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 179
    throw v0
.end method

.method public final t(ISBI)Ljava/util/ArrayList;
    .locals 2

    .line 1
    iget-object v0, p0, LHttp2Stream;->d:LHttp2Stream$a;

    .line 3
    iput p1, v0, LHttp2Stream$a;->g:I

    .line 5
    iput p1, v0, LHttp2Stream$a;->d:I

    .line 7
    iput-short p2, v0, LHttp2Stream$a;->h:S

    .line 9
    iput-byte p3, v0, LHttp2Stream$a;->e:B

    .line 11
    iput p4, v0, LHttp2Stream$a;->f:I

    .line 13
    :cond_0
    :goto_0
    iget-object p1, p0, LHttp2Stream;->f:Log$a;

    .line 15
    iget-object p2, p1, Log$a;->b:Lcp;

    .line 17
    invoke-virtual {p2}, Lcp;->i()Z

    .line 20
    move-result p3

    .line 21
    iget-object p4, p1, Log$a;->a:Ljava/util/ArrayList;

    .line 23
    if-nez p3, :cond_d

    .line 25
    invoke-virtual {p2}, Lcp;->readByte()B

    .line 28
    move-result p2

    .line 29
    and-int/lit16 p2, p2, 0xff

    .line 31
    const/16 p3, 0x80

    .line 33
    if-eq p2, p3, :cond_c

    .line 35
    and-int/lit16 v0, p2, 0x80

    .line 37
    const/4 v1, 0x0

    .line 38
    if-ne v0, p3, :cond_4

    .line 40
    const/16 p3, 0x7f

    .line 42
    invoke-virtual {p1, p2, p3}, Log$a;->e(II)I

    .line 45
    move-result p2

    .line 46
    add-int/lit8 p2, p2, -0x1

    .line 48
    const/4 p3, 0x1

    .line 49
    if-ltz p2, :cond_1

    .line 51
    sget-object v0, Log;->a:[Lgg;

    .line 53
    array-length v0, v0

    .line 54
    sub-int/2addr v0, p3

    .line 55
    if-gt p2, v0, :cond_1

    .line 57
    const/4 v1, 0x1

    .line 58
    :cond_1
    if-eqz v1, :cond_2

    .line 60
    sget-object p1, Log;->a:[Lgg;

    .line 62
    aget-object p1, p1, p2

    .line 64
    invoke-virtual {p4, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 67
    goto :goto_0

    .line 68
    :cond_2
    sget-object v0, Log;->a:[Lgg;

    .line 70
    array-length v0, v0

    .line 71
    sub-int v0, p2, v0

    .line 73
    iget v1, p1, Log$a;->f:I

    .line 75
    add-int/2addr v1, p3

    .line 76
    add-int/2addr v1, v0

    .line 77
    if-ltz v1, :cond_3

    .line 79
    iget-object p1, p1, Log$a;->e:[Lgg;

    .line 81
    array-length v0, p1

    .line 82
    add-int/lit8 v0, v0, -0x1

    .line 84
    if-gt v1, v0, :cond_3

    .line 86
    aget-object p1, p1, v1

    .line 88
    invoke-virtual {p4, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 91
    goto :goto_0

    .line 92
    :cond_3
    new-instance p1, Ljava/io/IOException;

    .line 94
    new-instance p4, Ljava/lang/StringBuilder;

    .line 96
    const-string v0, "ZaIV3Hqvhrjga3O1+Elpbl9hx02wUh4="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 98
    invoke-direct {p4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 101
    add-int/2addr p2, p3

    .line 102
    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 105
    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 108
    move-result-object p2

    .line 109
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 112
    throw p1

    .line 113
    :cond_4
    const/16 p3, 0x40

    .line 115
    if-ne p2, p3, :cond_5

    .line 117
    invoke-virtual {p1}, Log$a;->d()Lz4;

    .line 120
    move-result-object p2

    .line 121
    invoke-static {p2}, Log;->a(Lz4;)V

    .line 124
    invoke-virtual {p1}, Log$a;->d()Lz4;

    .line 127
    move-result-object p3

    .line 128
    new-instance p4, Lgg;

    .line 130
    invoke-direct {p4, p2, p3}, Lgg;-><init>(Lz4;Lz4;)V

    .line 133
    invoke-virtual {p1, p4}, Log$a;->c(Lgg;)V

    .line 136
    goto :goto_0

    .line 137
    :cond_5
    and-int/lit8 v0, p2, 0x40

    .line 139
    if-ne v0, p3, :cond_6

    .line 141
    const/16 p3, 0x3f

    .line 143
    invoke-virtual {p1, p2, p3}, Log$a;->e(II)I

    .line 146
    move-result p2

    .line 147
    add-int/lit8 p2, p2, -0x1

    .line 149
    invoke-virtual {p1, p2}, Log$a;->b(I)Lz4;

    .line 152
    move-result-object p2

    .line 153
    invoke-virtual {p1}, Log$a;->d()Lz4;

    .line 156
    move-result-object p3

    .line 157
    new-instance p4, Lgg;

    .line 159
    invoke-direct {p4, p2, p3}, Lgg;-><init>(Lz4;Lz4;)V

    .line 162
    invoke-virtual {p1, p4}, Log$a;->c(Lgg;)V

    .line 165
    goto/16 :goto_0

    .line 167
    :cond_6
    and-int/lit8 p3, p2, 0x20

    .line 169
    const/16 v0, 0x20

    .line 171
    if-ne p3, v0, :cond_9

    .line 173
    const/16 p3, 0x1f

    .line 175
    invoke-virtual {p1, p2, p3}, Log$a;->e(II)I

    .line 178
    move-result p2

    .line 179
    iput p2, p1, Log$a;->d:I

    .line 181
    if-ltz p2, :cond_8

    .line 183
    iget p3, p1, Log$a;->c:I

    .line 185
    if-gt p2, p3, :cond_8

    .line 187
    iget p3, p1, Log$a;->h:I

    .line 189
    if-ge p2, p3, :cond_0

    .line 191
    if-nez p2, :cond_7

    .line 193
    iget-object p2, p1, Log$a;->e:[Lgg;

    .line 195
    const/4 p3, 0x0

    .line 196
    invoke-static {p2, p3}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    .line 199
    iget-object p2, p1, Log$a;->e:[Lgg;

    .line 201
    array-length p2, p2

    .line 202
    add-int/lit8 p2, p2, -0x1

    .line 204
    iput p2, p1, Log$a;->f:I

    .line 206
    iput v1, p1, Log$a;->g:I

    .line 208
    iput v1, p1, Log$a;->h:I

    .line 210
    goto/16 :goto_0

    .line 212
    :cond_7
    sub-int/2addr p3, p2

    .line 213
    invoke-virtual {p1, p3}, Log$a;->a(I)I

    .line 216
    goto/16 :goto_0

    .line 218
    :cond_8
    new-instance p2, Ljava/io/IOException;

    .line 220
    new-instance p3, Ljava/lang/StringBuilder;

    .line 222
    const-string p4, "ZKkC2XO0wvHqdnistVRlIQtsxFOyF03XjPXpHZvIJytI5w=="
    invoke-static {p4}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p4

    .line 224
    invoke-direct {p3, p4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 227
    iget p1, p1, Log$a;->d:I

    .line 229
    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 232
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 235
    move-result-object p1

    .line 236
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 239
    throw p2

    .line 240
    :cond_9
    const/16 p3, 0x10

    .line 242
    if-eq p2, p3, :cond_b

    .line 244
    if-nez p2, :cond_a

    .line 246
    goto :goto_1

    .line 247
    :cond_a
    const/16 p3, 0xf

    .line 249
    invoke-virtual {p1, p2, p3}, Log$a;->e(II)I

    .line 252
    move-result p2

    .line 253
    add-int/lit8 p2, p2, -0x1

    .line 255
    invoke-virtual {p1, p2}, Log$a;->b(I)Lz4;

    .line 258
    move-result-object p2

    .line 259
    invoke-virtual {p1}, Log$a;->d()Lz4;

    .line 262
    move-result-object p1

    .line 263
    new-instance p3, Lgg;

    .line 265
    invoke-direct {p3, p2, p1}, Lgg;-><init>(Lz4;Lz4;)V

    .line 268
    invoke-virtual {p4, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 271
    goto/16 :goto_0

    .line 273
    :cond_b
    :goto_1
    invoke-virtual {p1}, Log$a;->d()Lz4;

    .line 276
    move-result-object p2

    .line 277
    invoke-static {p2}, Log;->a(Lz4;)V

    .line 280
    invoke-virtual {p1}, Log$a;->d()Lz4;

    .line 283
    move-result-object p1

    .line 284
    new-instance p3, Lgg;

    .line 286
    invoke-direct {p3, p2, p1}, Lgg;-><init>(Lz4;Lz4;)V

    .line 289
    invoke-virtual {p4, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 292
    goto/16 :goto_0

    .line 294
    :cond_c
    new-instance p1, Ljava/io/IOException;

    .line 296
    const-string p2, "RKkQ3Wf9m+yuPw=="
    invoke-static {p2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p2

    .line 298
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 301
    throw p1

    .line 302
    :cond_d
    new-instance p1, Ljava/util/ArrayList;

    .line 304
    invoke-direct {p1, p4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 307
    invoke-virtual {p4}, Ljava/util/ArrayList;->clear()V

    .line 310
    return-object p1
.end method

.method public final u(LHttp2Stream$b;IBI)V
    .locals 10

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p4, :cond_a

    .line 4
    and-int/lit8 v1, p3, 0x1

    .line 6
    const/4 v2, 0x1

    .line 7
    if-eqz v1, :cond_0

    .line 9
    const/4 v1, 0x1

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const/4 v1, 0x0

    .line 12
    :goto_0
    and-int/lit8 v3, p3, 0x8

    .line 14
    if-eqz v3, :cond_1

    .line 16
    iget-object v3, p0, LHttp2Stream;->c:Lv4;

    .line 18
    invoke-interface {v3}, Lv4;->readByte()B

    .line 21
    move-result v3

    .line 22
    and-int/lit16 v3, v3, 0xff

    .line 24
    int-to-short v3, v3

    .line 25
    goto :goto_1

    .line 26
    :cond_1
    const/4 v3, 0x0

    .line 27
    :goto_1
    and-int/lit8 v4, p3, 0x20

    .line 29
    if-eqz v4, :cond_2

    .line 31
    iget-object v4, p0, LHttp2Stream;->c:Lv4;

    .line 33
    invoke-interface {v4}, Lv4;->readInt()I

    .line 36
    invoke-interface {v4}, Lv4;->readByte()B

    .line 39
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    add-int/lit8 p2, p2, -0x5

    .line 44
    :cond_2
    invoke-static {p2, p3, v3}, LHttp2Stream;->h(IBS)I

    .line 47
    move-result p2

    .line 48
    invoke-virtual {p0, p2, v3, p3, p4}, LHttp2Stream;->t(ISBI)Ljava/util/ArrayList;

    .line 51
    move-result-object v8

    .line 52
    check-cast p1, LHttp2Connection$d;

    .line 54
    iget-object p2, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 56
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 59
    if-eqz p4, :cond_3

    .line 61
    and-int/lit8 p2, p4, 0x1

    .line 63
    if-nez p2, :cond_3

    .line 65
    const/4 p2, 0x1

    .line 66
    goto :goto_2

    .line 67
    :cond_3
    const/4 p2, 0x0

    .line 68
    :goto_2
    const/4 p3, 0x2

    .line 69
    if-eqz p2, :cond_4

    .line 71
    iget-object v4, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 73
    iget-object p1, v4, LHttp2Connection;->j:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 75
    new-instance p2, Lwg;

    .line 77
    new-array v5, p3, [Ljava/lang/Object;

    .line 79
    iget-object p3, v4, LHttp2Connection;->f:Ljava/lang/String;

    .line 81
    aput-object p3, v5, v0

    .line 83
    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 86
    move-result-object p3

    .line 87
    aput-object p3, v5, v2

    .line 89
    move-object v3, p2

    .line 90
    move v6, p4

    .line 91
    move-object v7, v8

    .line 92
    move v8, v1

    .line 93
    invoke-direct/range {v3 .. v8}, Lwg;-><init>(LHttp2Connection;[Ljava/lang/Object;ILjava/util/ArrayList;Z)V

    .line 96
    invoke-virtual {p1, p2}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 99
    goto :goto_3

    .line 100
    :cond_4
    iget-object p2, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 102
    monitor-enter p2

    .line 103
    :try_start_0
    iget-object v3, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 105
    iget-boolean v4, v3, LHttp2Connection;->i:Z

    .line 107
    if-eqz v4, :cond_5

    .line 109
    monitor-exit p2

    .line 110
    goto :goto_3

    .line 111
    :cond_5
    invoke-virtual {v3, p4}, LHttp2Connection;->j(I)Ldh;

    .line 114
    move-result-object v3

    .line 115
    if-nez v3, :cond_8

    .line 117
    iget-object v5, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 119
    iget v3, v5, LHttp2Connection;->g:I

    .line 121
    if-gt p4, v3, :cond_6

    .line 123
    monitor-exit p2

    .line 124
    goto :goto_3

    .line 125
    :cond_6
    rem-int/lit8 v3, p4, 0x2

    .line 127
    iget v4, v5, LHttp2Connection;->h:I

    .line 129
    rem-int/2addr v4, p3

    .line 130
    if-ne v3, v4, :cond_7

    .line 132
    monitor-exit p2

    .line 133
    goto :goto_3

    .line 134
    :cond_7
    new-instance v9, Ldh;

    .line 136
    const/4 v6, 0x0

    .line 137
    move-object v3, v9

    .line 138
    move v4, p4

    .line 139
    move v7, v1

    .line 140
    invoke-direct/range {v3 .. v8}, Ldh;-><init>(ILHttp2Connection;ZZLjava/util/ArrayList;)V

    .line 143
    iget-object v1, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 145
    iput p4, v1, LHttp2Connection;->g:I

    .line 147
    iget-object v1, v1, LHttp2Connection;->e:Ljava/util/LinkedHashMap;

    .line 149
    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 152
    move-result-object v3

    .line 153
    invoke-interface {v1, v3, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 156
    sget-object v1, LHttp2Connection;->u:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 158
    new-instance v3, Lzg;

    .line 160
    new-array p3, p3, [Ljava/lang/Object;

    .line 162
    iget-object v4, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 164
    iget-object v4, v4, LHttp2Connection;->f:Ljava/lang/String;

    .line 166
    aput-object v4, p3, v0

    .line 168
    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 171
    move-result-object p4

    .line 172
    aput-object p4, p3, v2

    .line 174
    invoke-direct {v3, p1, p3, v9}, Lzg;-><init>(LHttp2Connection$d;[Ljava/lang/Object;Ldh;)V

    .line 177
    invoke-virtual {v1, v3}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 180
    monitor-exit p2

    .line 181
    goto :goto_3

    .line 182
    :catchall_0
    move-exception p1

    .line 183
    goto :goto_4

    .line 184
    :cond_8
    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 185
    invoke-virtual {v3, v8}, Ldh;->g(Ljava/util/ArrayList;)V

    .line 188
    if-eqz v1, :cond_9

    .line 190
    invoke-virtual {v3}, Ldh;->f()V

    .line 193
    :cond_9
    :goto_3
    return-void

    .line 194
    :goto_4
    :try_start_1
    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 195
    throw p1

    .line 196
    :cond_a
    const-string p1, "fZU77FCe6Z3RSkSfl288IStU9nqIf3v/stWbO8vfMi1Iphnxe/2b7K4/"
    invoke-static {p1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    .line 198
    new-array p2, v0, [Ljava/lang/Object;

    .line 200
    invoke-static {p1, p2}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 203
    const/4 p1, 0x0

    .line 204
    throw p1
.end method

.method public final v(LHttp2Stream$b;IBI)V
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    const/16 v1, 0x8

    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x1

    .line 6
    if-ne p2, v1, :cond_3

    .line 8
    if-nez p4, :cond_2

    .line 10
    iget-object p2, p0, LHttp2Stream;->c:Lv4;

    .line 12
    invoke-interface {p2}, Lv4;->readInt()I

    .line 15
    move-result p2

    .line 16
    iget-object p4, p0, LHttp2Stream;->c:Lv4;

    .line 18
    invoke-interface {p4}, Lv4;->readInt()I

    .line 21
    move-result p4

    .line 22
    and-int/2addr p3, v3

    .line 23
    if-eqz p3, :cond_0

    .line 25
    const/4 p3, 0x1

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    const/4 p3, 0x0

    .line 28
    :goto_0
    check-cast p1, LHttp2Connection$d;

    .line 30
    if-eqz p3, :cond_1

    .line 32
    iget-object p1, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 34
    monitor-enter p1

    .line 35
    monitor-exit p1

    .line 36
    goto :goto_1

    .line 37
    :cond_1
    iget-object p1, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 39
    sget-object p3, LHttp2Connection;->u:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 41
    new-instance v0, Lug;

    .line 43
    const/4 v1, 0x3

    .line 44
    new-array v1, v1, [Ljava/lang/Object;

    .line 46
    iget-object v4, p1, LHttp2Connection;->f:Ljava/lang/String;

    .line 48
    aput-object v4, v1, v2

    .line 50
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 53
    move-result-object v2

    .line 54
    aput-object v2, v1, v3

    .line 56
    const/4 v2, 0x2

    .line 57
    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 60
    move-result-object v3

    .line 61
    aput-object v3, v1, v2

    .line 63
    invoke-direct {v0, p1, v1, p2, p4}, Lug;-><init>(LHttp2Connection;[Ljava/lang/Object;II)V

    .line 66
    invoke-virtual {p3, v0}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 69
    :goto_1
    return-void

    .line 70
    :cond_2
    const-string p1, "eZ4k/UCN75/JL2W5qlhnbDZphh7qFw4="
    invoke-static {p1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    .line 72
    new-array p2, v2, [Ljava/lang/Object;

    .line 74
    invoke-static {p1, p2}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 77
    throw v0

    .line 78
    :cond_3
    const-string p1, "eZ4k/UCN75/JL3qotlpyaV8smx/vDR6bhQ=="
    invoke-static {p1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    .line 80
    new-array p3, v3, [Ljava/lang/Object;

    .line 82
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 85
    move-result-object p2

    .line 86
    aput-object p2, p3, v2

    .line 88
    invoke-static {p1, p3}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 91
    throw v0
.end method

.method public final w(LHttp2Stream$b;IBI)V
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p4, :cond_2

    .line 4
    and-int/lit8 v1, p3, 0x8

    .line 6
    if-eqz v1, :cond_0

    .line 8
    iget-object v1, p0, LHttp2Stream;->c:Lv4;

    .line 10
    invoke-interface {v1}, Lv4;->readByte()B

    .line 13
    move-result v1

    .line 14
    and-int/lit16 v1, v1, 0xff

    .line 16
    int-to-short v1, v1

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const/4 v1, 0x0

    .line 19
    :goto_0
    iget-object v2, p0, LHttp2Stream;->c:Lv4;

    .line 21
    invoke-interface {v2}, Lv4;->readInt()I

    .line 24
    move-result v2

    .line 25
    const v3, 0x7fffffff

    .line 28
    and-int/2addr v2, v3

    .line 29
    add-int/lit8 p2, p2, -0x4

    .line 31
    invoke-static {p2, p3, v1}, LHttp2Stream;->h(IBS)I

    .line 34
    move-result p2

    .line 35
    invoke-virtual {p0, p2, v1, p3, p4}, LHttp2Stream;->t(ISBI)Ljava/util/ArrayList;

    .line 38
    move-result-object p2

    .line 39
    check-cast p1, LHttp2Connection$d;

    .line 41
    iget-object p1, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 43
    monitor-enter p1

    .line 44
    :try_start_0
    iget-object p3, p1, LHttp2Connection;->t:Ljava/util/LinkedHashSet;

    .line 46
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 49
    move-result-object p4

    .line 50
    invoke-interface {p3, p4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 53
    move-result p3

    .line 54
    const/4 p4, 0x2

    .line 55
    if-eqz p3, :cond_1

    .line 57
    invoke-virtual {p1, v2, p4}, LHttp2Connection;->v(II)V

    .line 60
    monitor-exit p1

    .line 61
    goto :goto_1

    .line 62
    :cond_1
    iget-object p3, p1, LHttp2Connection;->t:Ljava/util/LinkedHashSet;

    .line 64
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 67
    move-result-object v1

    .line 68
    invoke-interface {p3, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 71
    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 72
    iget-object p3, p1, LHttp2Connection;->j:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 74
    new-instance v1, Lvg;

    .line 76
    new-array p4, p4, [Ljava/lang/Object;

    .line 78
    iget-object v3, p1, LHttp2Connection;->f:Ljava/lang/String;

    .line 80
    aput-object v3, p4, v0

    .line 82
    const/4 v0, 0x1

    .line 83
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 86
    move-result-object v3

    .line 87
    aput-object v3, p4, v0

    .line 89
    invoke-direct {v1, p1, p4, v2, p2}, Lvg;-><init>(LHttp2Connection;[Ljava/lang/Object;ILjava/util/ArrayList;)V

    .line 92
    invoke-virtual {p3, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 95
    :goto_1
    return-void

    .line 96
    :catchall_0
    move-exception p2

    .line 97
    :try_start_1
    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 98
    throw p2

    .line 99
    :cond_2
    const-string p1, "fZU77FCe6Z3RSkSfl288IStU9nqIZ2vtvs+ZOqThDwxo5wfMbbjHvMdrNvDlHTY="
    invoke-static {p1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    .line 101
    new-array p2, v0, [Ljava/lang/Object;

    .line 103
    invoke-static {p1, p2}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 106
    const/4 p1, 0x0

    .line 107
    throw p1
.end method

.method public final x(LHttp2Stream$b;IBI)V
    .locals 9

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    if-nez p4, :cond_15

    .line 5
    const/4 p4, 0x1

    .line 6
    and-int/2addr p3, p4

    .line 7
    if-eqz p3, :cond_1

    .line 9
    if-nez p2, :cond_0

    .line 11
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    return-void

    .line 15
    :cond_0
    const-string p1, "a5U19VqC9ZjUSkmIim9JU19sxVT3UUzfm/XpG4PDMzNJ5xbdP7jLofp2Nw=="
    invoke-static {p1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    .line 17
    new-array p2, v1, [Ljava/lang/Object;

    .line 19
    invoke-static {p1, p2}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 22
    throw v0

    .line 23
    :cond_1
    rem-int/lit8 p3, p2, 0x6

    .line 25
    if-nez p3, :cond_14

    .line 27
    new-instance p3, Lur;

    .line 29
    invoke-direct {p3}, Lur;-><init>()V

    .line 32
    const/4 v2, 0x0

    .line 33
    :goto_0
    if-ge v2, p2, :cond_a

    .line 35
    iget-object v3, p0, LHttp2Stream;->c:Lv4;

    .line 37
    invoke-interface {v3}, Lv4;->readShort()S

    .line 40
    move-result v3

    .line 41
    iget-object v4, p0, LHttp2Stream;->c:Lv4;

    .line 43
    invoke-interface {v4}, Lv4;->readInt()I

    .line 46
    move-result v4

    .line 47
    const/4 v5, 0x2

    .line 48
    if-eq v3, v5, :cond_7

    .line 50
    const/4 v5, 0x3

    .line 51
    const/4 v6, 0x4

    .line 52
    if-eq v3, v5, :cond_6

    .line 54
    if-eq v3, v6, :cond_4

    .line 56
    const/4 v5, 0x5

    .line 57
    if-eq v3, v5, :cond_2

    .line 59
    goto :goto_1

    .line 60
    :cond_2
    const/16 v5, 0x4000

    .line 62
    if-lt v4, v5, :cond_3

    .line 64
    const v5, 0xffffff

    .line 67
    if-gt v4, v5, :cond_3

    .line 69
    goto :goto_1

    .line 70
    :cond_3
    const-string p1, "fZU77FCe6Z3RSkSfl28mUjpZ8naZcG3hu9GRN63+BxJomCfxRZic8at8"
    invoke-static {p1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    .line 72
    new-array p2, p4, [Ljava/lang/Object;

    .line 74
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 77
    move-result-object p3

    .line 78
    aput-object p3, p2, v1

    .line 80
    invoke-static {p1, p2}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 83
    throw v0

    .line 84
    :cond_4
    if-ltz v4, :cond_5

    .line 86
    const/4 v3, 0x7

    .line 87
    goto :goto_1

    .line 88
    :cond_5
    const-string p1, "fZU77FCe6Z3RSkSfl28mUjpZ8naZcG3hv96APKLtCgB6jjr8UIr5gsdVU+3mHTRfTDyGEvcG"
    invoke-static {p1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    .line 90
    new-array p2, v1, [Ljava/lang/Object;

    .line 92
    invoke-static {p1, p2}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 95
    throw v0

    .line 96
    :cond_6
    const/4 v3, 0x4

    .line 97
    goto :goto_1

    .line 98
    :cond_7
    if-eqz v4, :cond_9

    .line 100
    if-ne v4, p4, :cond_8

    .line 102
    goto :goto_1

    .line 103
    :cond_8
    const-string p1, "fZU77FCe6Z3RSkSfl28mUjpZ8naZcG3hs96IKqfpGQ94lDyYPuCG4a5gZO3p"
    invoke-static {p1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    .line 105
    new-array p2, v1, [Ljava/lang/Object;

    .line 107
    invoke-static {p1, p2}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 110
    throw v0

    .line 111
    :cond_9
    :goto_1
    invoke-virtual {p3, v3, v4}, Lur;->b(II)V

    .line 114
    add-int/lit8 v2, v2, 0x6

    .line 116
    goto :goto_0

    .line 117
    :cond_a
    check-cast p1, LHttp2Connection$d;

    .line 119
    iget-object v2, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 121
    monitor-enter v2

    .line 122
    :try_start_0
    iget-object p2, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 124
    iget-object p2, p2, LHttp2Connection;->o:Lur;

    .line 126
    invoke-virtual {p2}, Lur;->a()I

    .line 129
    move-result p2

    .line 130
    iget-object v3, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 132
    iget-object v3, v3, LHttp2Connection;->o:Lur;

    .line 134
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 137
    const/4 v4, 0x0

    .line 138
    :goto_2
    const/16 v5, 0xa

    .line 140
    if-ge v4, v5, :cond_d

    .line 142
    shl-int v5, p4, v4

    .line 144
    iget v6, p3, Lur;->a:I

    .line 146
    and-int/2addr v5, v6

    .line 147
    if-eqz v5, :cond_b

    .line 149
    const/4 v5, 0x1

    .line 150
    goto :goto_3

    .line 151
    :cond_b
    const/4 v5, 0x0

    .line 152
    :goto_3
    if-nez v5, :cond_c

    .line 154
    goto :goto_4

    .line 155
    :cond_c
    iget-object v5, p3, Lur;->b:[I

    .line 157
    aget v5, v5, v4

    .line 159
    invoke-virtual {v3, v4, v5}, Lur;->b(II)V

    .line 162
    :goto_4
    add-int/lit8 v4, v4, 0x1

    .line 164
    goto :goto_2

    .line 165
    :catchall_0
    move-exception p1

    .line 166
    goto/16 :goto_7

    .line 168
    :cond_d
    sget-object v3, LHttp2Connection;->u:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 170
    new-instance v4, Lbh;

    .line 172
    new-array v5, p4, [Ljava/lang/Object;

    .line 174
    iget-object v6, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 176
    iget-object v6, v6, LHttp2Connection;->f:Ljava/lang/String;

    .line 178
    aput-object v6, v5, v1

    .line 180
    invoke-direct {v4, p1, v5, p3}, Lbh;-><init>(LHttp2Connection$d;[Ljava/lang/Object;Lur;)V

    .line 183
    invoke-virtual {v3, v4}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 186
    iget-object p3, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 188
    iget-object p3, p3, LHttp2Connection;->o:Lur;

    .line 190
    invoke-virtual {p3}, Lur;->a()I

    .line 193
    move-result p3

    .line 194
    const/4 v4, -0x1

    .line 195
    const-wide/16 v5, 0x0

    .line 197
    if-eq p3, v4, :cond_10

    .line 199
    if-eq p3, p2, :cond_10

    .line 201
    sub-int/2addr p3, p2

    .line 202
    int-to-long p2, p3

    .line 203
    iget-object v4, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 205
    iget-boolean v7, v4, LHttp2Connection;->p:Z

    .line 207
    if-nez v7, :cond_f

    .line 209
    iget-wide v7, v4, LHttp2Connection;->m:J

    .line 211
    add-long/2addr v7, p2

    .line 212
    iput-wide v7, v4, LHttp2Connection;->m:J

    .line 214
    cmp-long v7, p2, v5

    .line 216
    if-lez v7, :cond_e

    .line 218
    invoke-virtual {v4}, Ljava/lang/Object;->notifyAll()V

    .line 221
    :cond_e
    iget-object v4, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 223
    iput-boolean p4, v4, LHttp2Connection;->p:Z

    .line 225
    :cond_f
    iget-object v4, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 227
    iget-object v4, v4, LHttp2Connection;->e:Ljava/util/LinkedHashMap;

    .line 229
    invoke-interface {v4}, Ljava/util/Map;->isEmpty()Z

    .line 232
    move-result v4

    .line 233
    if-nez v4, :cond_11

    .line 235
    iget-object v0, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 237
    iget-object v0, v0, LHttp2Connection;->e:Ljava/util/LinkedHashMap;

    .line 239
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    .line 242
    move-result-object v0

    .line 243
    iget-object v4, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 245
    iget-object v4, v4, LHttp2Connection;->e:Ljava/util/LinkedHashMap;

    .line 247
    invoke-interface {v4}, Ljava/util/Map;->size()I

    .line 250
    move-result v4

    .line 251
    new-array v4, v4, [Ldh;

    .line 253
    invoke-interface {v0, v4}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 256
    move-result-object v0

    .line 257
    check-cast v0, [Ldh;

    .line 259
    goto :goto_5

    .line 260
    :cond_10
    move-wide p2, v5

    .line 261
    :cond_11
    :goto_5
    new-instance v4, Lah;

    .line 263
    new-array p4, p4, [Ljava/lang/Object;

    .line 265
    iget-object v7, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 267
    iget-object v7, v7, LHttp2Connection;->f:Ljava/lang/String;

    .line 269
    aput-object v7, p4, v1

    .line 271
    invoke-direct {v4, p1, p4}, Lah;-><init>(LHttp2Connection$d;[Ljava/lang/Object;)V

    .line 274
    invoke-virtual {v3, v4}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 277
    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 278
    if-eqz v0, :cond_13

    .line 280
    cmp-long p1, p2, v5

    .line 282
    if-eqz p1, :cond_13

    .line 284
    array-length p4, v0

    .line 285
    :goto_6
    if-ge v1, p4, :cond_13

    .line 287
    aget-object v2, v0, v1

    .line 289
    monitor-enter v2

    .line 290
    :try_start_1
    iget-wide v3, v2, Ldh;->b:J

    .line 292
    add-long/2addr v3, p2

    .line 293
    iput-wide v3, v2, Ldh;->b:J

    .line 295
    if-lez p1, :cond_12

    .line 297
    invoke-virtual {v2}, Ljava/lang/Object;->notifyAll()V

    .line 300
    :cond_12
    monitor-exit v2

    .line 301
    add-int/lit8 v1, v1, 0x1

    .line 303
    goto :goto_6

    .line 304
    :catchall_1
    move-exception p1

    .line 305
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 306
    throw p1

    .line 307
    :cond_13
    return-void

    .line 308
    :goto_7
    :try_start_2
    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 309
    throw p1

    .line 310
    :cond_14
    const-string p1, "eZ4k/UCO44XaRliKix1qZBFq0lf3EhuewLDoVcucfH8ItA=="
    invoke-static {p1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    .line 312
    new-array p3, p4, [Ljava/lang/Object;

    .line 314
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 317
    move-result-object p2

    .line 318
    aput-object p2, p3, v1

    .line 320
    invoke-static {p1, p3}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 323
    throw v0

    .line 324
    :cond_15
    const-string p1, "eZ4k/UCO44XaRliKix11dQ1ox1KeUx6fy7D5"
    invoke-static {p1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    .line 326
    new-array p2, v1, [Ljava/lang/Object;

    .line 328
    invoke-static {p1, p2}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 331
    throw v0
.end method

.method public final y(LHttp2Stream$b;II)V
    .locals 8

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x4

    .line 3
    const/4 v2, 0x0

    .line 4
    const/4 v3, 0x1

    .line 5
    if-ne p2, v1, :cond_4

    .line 7
    iget-object p2, p0, LHttp2Stream;->c:Lv4;

    .line 9
    invoke-interface {p2}, Lv4;->readInt()I

    .line 12
    move-result p2

    .line 13
    int-to-long v4, p2

    .line 14
    const-wide/32 v6, 0x7fffffff

    .line 17
    and-long/2addr v4, v6

    .line 18
    const-wide/16 v6, 0x0

    .line 20
    cmp-long p2, v4, v6

    .line 22
    if-eqz p2, :cond_3

    .line 24
    check-cast p1, LHttp2Connection$d;

    .line 26
    if-nez p3, :cond_0

    .line 28
    iget-object v0, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 30
    monitor-enter v0

    .line 31
    :try_start_0
    iget-object p1, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 33
    iget-wide p2, p1, LHttp2Connection;->m:J

    .line 35
    add-long/2addr p2, v4

    .line 36
    iput-wide p2, p1, LHttp2Connection;->m:J

    .line 38
    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    .line 41
    monitor-exit v0

    .line 42
    goto :goto_0

    .line 43
    :catchall_0
    move-exception p1

    .line 44
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 45
    throw p1

    .line 46
    :cond_0
    iget-object p1, p1, LHttp2Connection$d;->e:LHttp2Connection;

    .line 48
    invoke-virtual {p1, p3}, LHttp2Connection;->j(I)Ldh;

    .line 51
    move-result-object p1

    .line 52
    if-eqz p1, :cond_2

    .line 54
    monitor-enter p1

    .line 55
    :try_start_1
    iget-wide v0, p1, Ldh;->b:J

    .line 57
    add-long/2addr v0, v4

    .line 58
    iput-wide v0, p1, Ldh;->b:J

    .line 60
    if-lez p2, :cond_1

    .line 62
    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    .line 65
    :cond_1
    monitor-exit p1

    .line 66
    goto :goto_0

    .line 67
    :catchall_1
    move-exception p2

    .line 68
    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 69
    throw p2

    .line 70
    :cond_2
    :goto_0
    return-void

    .line 71
    :cond_3
    const-string p1, "Wq4a3HCq9bj0al+ju09jbBpj0h+gVk2exg=="
    invoke-static {p1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    .line 73
    new-array p2, v3, [Ljava/lang/Object;

    .line 75
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 78
    move-result-object p3

    .line 79
    aput-object p3, p2, v2

    .line 81
    invoke-static {p1, p2}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 84
    throw v0

    .line 85
    :cond_4
    const-string p1, "eZ4k/UCK75/KQEGSjW1CQCtIhlOyWVnKnrDoVd+WZnpe"
    invoke-static {p1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1

    .line 87
    new-array p3, v3, [Ljava/lang/Object;

    .line 89
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 92
    move-result-object p2

    .line 93
    aput-object p2, p3, v2

    .line 95
    invoke-static {p1, p3}, Lqg;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 98
    throw v0
.end method
