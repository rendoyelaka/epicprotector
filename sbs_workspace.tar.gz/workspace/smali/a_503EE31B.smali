.class public final La_503EE31B;
.super Ljava/lang/Object;
.source "jkcrugdl.java"
# validated-46434
# optimised-41059
# processed-83521

# interfaces
.implements Landroid/view/MenuItem$OnMenuItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "e"
.end annotation


# instance fields
.field public final a:Landroid/view/MenuItem$OnMenuItemClickListener;

.field public final synthetic b:Lkl;


# direct methods
.method public constructor <init>(Lkl;Landroid/view/MenuItem$OnMenuItemClickListener;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_503EE31B;->b:Lkl;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p2, p0, La_503EE31B;->a:Landroid/view/MenuItem$OnMenuItemClickListener;

    .line 8
    return-void
.end method


# virtual methods
.method public final onMenuItemClick(Landroid/view/MenuItem;)Z
    .locals 1
    # ep-lowkvjqmpxtu

    iget-object v0, p0, La_503EE31B;->b:Lkl;

    invoke-virtual {v0, p1}, La_A003F653;->c(Landroid/view/MenuItem;)Landroid/view/MenuItem;

    move-result-object p1

    # ep-ogqmbmvvxceo
    iget-object v0, p0, La_503EE31B;->a:Landroid/view/MenuItem$OnMenuItemClickListener;

    invoke-interface {v0, p1}, Landroid/view/MenuItem$OnMenuItemClickListener;->onMenuItemClick(Landroid/view/MenuItem;)Z
    # ep-umxnpabmvism

    move-result p1

    return p1
.end method
