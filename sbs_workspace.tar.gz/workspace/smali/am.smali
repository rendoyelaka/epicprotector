.class public final Lam;
.super Lb9;
.source "nkapmjwq.java"

# validated-74248
# ep-mtomtpowfavd

# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    sget-object v0, Lb9$a;->b:Lb9$a;

    invoke-direct {p0, v0}, Lam;-><init>(Lb9;)V

    return-void
.end method

.method public constructor <init>(Lb9;)V
    .locals 1

    const-string v0, "RZ2j0d2Vpph6ILoicg=="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 2
    invoke-direct {p0}, Lb9;-><init>()V

    .line 3
    iget-object v0, p0, Lb9;->a:Ljava/util/LinkedHashMap;

    iget-object p1, p1, Lb9;->a:Ljava/util/LinkedHashMap;

    .line 4
    invoke-interface {v0, p1}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    return-void
.end method


# virtual methods
.method public final a(Lb9$b;Ljava/lang/Object;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lb9$b<",
            "TT;>;TT;)V"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lb9;->a:Ljava/util/LinkedHashMap;

    .line 3
    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    return-void
.end method
