.class public interface abstract La_623247DB;
# ep-aofpykkicelf
# processed-57618
# compiled-86380
# optimised-96410
.super Ljava/lang/Object;
.source "dfpyjcbp.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lvl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()V
.end method
