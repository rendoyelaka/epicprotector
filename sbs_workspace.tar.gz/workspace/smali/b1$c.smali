.class public final Lb1$c;
# ep-biultgjgxnmd
.super Landroid/graphics/drawable/Drawable$ConstantState;
.source "nofhjwmw.java"

# optimised-36597
# compiled-16989

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field public final a:Landroid/graphics/drawable/Drawable$ConstantState;


# direct methods
.method public constructor <init>(Landroid/graphics/drawable/Drawable$ConstantState;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    .line 4
    iput-object p1, p0, Lb1$c;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    .line 6
    return-void
.end method


# virtual methods
.method public final canApplyTheme()Z
    .locals 1

    iget-object v0, p0, Lb1$c;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_vfv43n9g
    goto :ep_s_vfv43n9g
    :ep_d_vfv43n9g
    nop
    :ep_s_vfv43n9g
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable$ConstantState;->canApplyTheme()Z

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_9jm276z6
    goto :ep_s_9jm276z6
    :ep_d_9jm276z6
    nop
    :ep_s_9jm276z6
    move-result v0

    return v0
.end method

.method public final getChangingConfigurations()I
    .locals 1

    iget-object v0, p0, Lb1$c;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_dhn4gx0y
    goto :ep_s_dhn4gx0y
    :ep_d_dhn4gx0y
    nop
    :ep_s_dhn4gx0y
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable$ConstantState;->getChangingConfigurations()I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_fah17rsd
    goto :ep_s_fah17rsd
    :ep_d_fah17rsd
    nop
    :ep_s_fah17rsd
    move-result v0

    return v0
.end method

.method public final newDrawable()Landroid/graphics/drawable/Drawable;
    .locals 3

    .line 1
    new-instance v0, Lb1;

    const/4 v2, 0x1
    if-ne v2, v2, :ep_d_zawxmhdx
    goto :ep_s_zawxmhdx
    :ep_d_zawxmhdx
    nop
    :ep_s_zawxmhdx
    invoke-direct {v0}, Lb1;-><init>()V

    .line 2
    iget-object v1, p0, Lb1$c;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    const/4 v2, 0x1
    if-ne v2, v2, :ep_d_67m8pbpd
    goto :ep_s_67m8pbpd
    :ep_d_67m8pbpd
    nop
    :ep_s_67m8pbpd
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    iput-object v1, v0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    iget-object v2, v0, Lb1;->h:Lb1$a;

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    return-object v0
.end method

.method public final newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 4
    new-instance v0, Lb1;

    invoke-direct {v0}, Lb1;-><init>()V

    .line 5
    iget-object v1, p0, Lb1$c;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_otqsv2jw
    goto :ep_s_otqsv2jw
    :ep_d_otqsv2jw
    nop
    :ep_s_otqsv2jw
    iput-object p1, v0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 6
    iget-object v1, v0, Lb1;->h:Lb1$a;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_k1x66wqw
    goto :ep_s_k1x66wqw
    :ep_d_k1x66wqw
    nop
    :ep_s_k1x66wqw
    invoke-virtual {p1, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    return-object v0
.end method

.method public final newDrawable(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 7
    new-instance v0, Lb1;

    invoke-direct {v0}, Lb1;-><init>()V

    .line 8
    iget-object v1, p0, Lb1$c;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    invoke-virtual {v1, p1, p2}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_t3iux9ib
    goto :ep_s_t3iux9ib
    :ep_d_t3iux9ib
    nop
    :ep_s_t3iux9ib
    move-result-object p1

    iput-object p1, v0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 9
    iget-object p2, v0, Lb1;->h:Lb1$a;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_dzcxsup9
    goto :ep_s_dzcxsup9
    :ep_d_dzcxsup9
    nop
    :ep_s_dzcxsup9
    invoke-virtual {p1, p2}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    return-object v0
.end method
