.class public final Lb1$c;
.super Landroid/graphics/drawable/Drawable$ConstantState;
.source "ycafyaxt.java"

# validated-78275
# compiled-33004
# generated-42628
# ep-xivnsebmjfgw

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field public final a:Landroid/graphics/drawable/Drawable$ConstantState;


# direct methods
.method public constructor <init>(Landroid/graphics/drawable/Drawable$ConstantState;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    .line 4
    iput-object p1, p0, Lb1$c;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    .line 6
    return-void
.end method


# virtual methods
.method public final canApplyTheme()Z
    .locals 1

    iget-object v0, p0, Lb1$c;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_wl1phvpl
    goto :ep_s_wl1phvpl
    :ep_d_wl1phvpl
    nop
    :ep_s_wl1phvpl
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable$ConstantState;->canApplyTheme()Z

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_wmbf88lm
    goto :ep_s_wmbf88lm
    :ep_d_wmbf88lm
    nop
    :ep_s_wmbf88lm
    move-result v0

    return v0
.end method

.method public final getChangingConfigurations()I
    .locals 1

    iget-object v0, p0, Lb1$c;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_1iyfp653
    goto :ep_s_1iyfp653
    :ep_d_1iyfp653
    nop
    :ep_s_1iyfp653
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable$ConstantState;->getChangingConfigurations()I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_cqrk4le7
    goto :ep_s_cqrk4le7
    :ep_d_cqrk4le7
    nop
    :ep_s_cqrk4le7
    move-result v0

    return v0
.end method

.method public final newDrawable()Landroid/graphics/drawable/Drawable;
    .locals 3

    .line 1
    new-instance v0, Lb1;

    invoke-direct {v0}, Lb1;-><init>()V

    .line 2
    iget-object v1, p0, Lb1$c;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    const/4 v2, 0x1
    if-ne v2, v2, :ep_d_61aq5je4
    goto :ep_s_61aq5je4
    :ep_d_61aq5je4
    nop
    :ep_s_61aq5je4
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v2, 0x1
    if-ne v2, v2, :ep_d_4k5kn91y
    goto :ep_s_4k5kn91y
    :ep_d_4k5kn91y
    nop
    :ep_s_4k5kn91y
    iput-object v1, v0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    iget-object v2, v0, Lb1;->h:Lb1$a;

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    return-object v0
.end method

.method public final newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 4
    new-instance v0, Lb1;

    invoke-direct {v0}, Lb1;-><init>()V

    .line 5
    iget-object v1, p0, Lb1$c;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_oh9y0qp6
    goto :ep_s_oh9y0qp6
    :ep_d_oh9y0qp6
    nop
    :ep_s_oh9y0qp6
    move-result-object p1

    iput-object p1, v0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 6
    iget-object v1, v0, Lb1;->h:Lb1$a;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_vr3rc840
    goto :ep_s_vr3rc840
    :ep_d_vr3rc840
    nop
    :ep_s_vr3rc840
    invoke-virtual {p1, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    return-object v0
.end method

.method public final newDrawable(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 7
    new-instance v0, Lb1;

    invoke-direct {v0}, Lb1;-><init>()V

    .line 8
    iget-object v1, p0, Lb1$c;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    invoke-virtual {v1, p1, p2}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_qk2fe1ye
    goto :ep_s_qk2fe1ye
    :ep_d_qk2fe1ye
    nop
    :ep_s_qk2fe1ye
    move-result-object p1

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_wjkxvk68
    goto :ep_s_wjkxvk68
    :ep_d_wjkxvk68
    nop
    :ep_s_wjkxvk68
    iput-object p1, v0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 9
    iget-object p2, v0, Lb1;->h:Lb1$a;

    invoke-virtual {p1, p2}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    return-object v0
.end method
