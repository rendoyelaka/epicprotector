.class public abstract La_379C3235;
.super Ljava/lang/Object;
.source "jgbdnash.java"

# ep-esceojnhmalo
# processed-30785
# generated-64560
# processed-22575

# static fields
.field public static final synthetic a:I


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "WorkerFactory"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;Ljava/lang/String;Landroidx/work/WorkerParameters;)Landroidx/work/ListenableWorker;
    .locals 7

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x0

    .line 4
    :try_start_0
    invoke-static {p2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 7
    move-result-object v3

    .line 8
    const-class v4, Landroidx/work/ListenableWorker;

    .line 10
    invoke-virtual {v3, v4}, Ljava/lang/Class;->asSubclass(Ljava/lang/Class;)Ljava/lang/Class;

    .line 13
    move-result-object v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 14
    goto :goto_0

    .line 15
    :catchall_0
    move-exception v3

    .line 16
    invoke-static {}, Ltj;->c()Ltj;

    .line 19
    move-result-object v4

    .line 20
    new-array v5, v0, [Ljava/lang/Throwable;

    .line 22
    aput-object v3, v5, v1

    .line 24
    invoke-virtual {v4, v5}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 27
    move-object v3, v2

    .line 28
    :goto_0
    const/4 v4, 0x2

    .line 29
    if-eqz v3, :cond_0

    .line 31
    :try_start_1
    new-array v5, v4, [Ljava/lang/Class;

    .line 33
    const-class v6, Landroid/content/Context;

    .line 35
    aput-object v6, v5, v1

    .line 37
    const-class v6, Landroidx/work/WorkerParameters;

    .line 39
    aput-object v6, v5, v0

    .line 41
    invoke-virtual {v3, v5}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 44
    move-result-object v3

    .line 45
    new-array v5, v4, [Ljava/lang/Object;

    .line 47
    aput-object p1, v5, v1

    .line 49
    aput-object p3, v5, v0

    .line 51
    invoke-virtual {v3, v5}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 54
    move-result-object p1

    .line 55
    check-cast p1, Landroidx/work/ListenableWorker;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 57
    move-object v2, p1

    .line 58
    goto :goto_1

    .line 59
    :catchall_1
    move-exception p1

    .line 60
    invoke-static {}, Ltj;->c()Ltj;

    .line 63
    move-result-object p3

    .line 64
    new-array v3, v0, [Ljava/lang/Throwable;

    .line 66
    aput-object p1, v3, v1

    .line 68
    invoke-virtual {p3, v3}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 71
    :cond_0
    :goto_1
    if-eqz v2, :cond_2

    .line 73
    iget-boolean p1, v2, Landroidx/work/ListenableWorker;->f:Z

    .line 75
    if-nez p1, :cond_1

    .line 77
    goto :goto_2

    .line 78
    :cond_1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 81
    move-result-object p1

    .line 82
    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 85
    move-result-object p1

    .line 86
    new-array p3, v4, [Ljava/lang/Object;

    .line 88
    aput-object p1, p3, v1

    .line 90
    aput-object p2, p3, v0

    .line 92
    const-string p1, "WorkerFactory (%s) returned an instance of a ListenableWorker (%s) which has already been invoked. createWorker() must always return a new instance of a ListenableWorker."

    .line 94
    invoke-static {p1, p3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 97
    move-result-object p1

    .line 98
    new-instance p2, Ljava/lang/IllegalStateException;

    .line 100
    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 103
    throw p2

    .line 104
    :cond_2
    :goto_2
    return-object v2
.end method
