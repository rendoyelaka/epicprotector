.class public interface abstract La_23125508;
.super Ljava/lang/Object;
.source "wszvynrv.java"

# validated-55025
# validated-99414
# validated-10136
# interfaces
.implements La_D9825592;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_E259B27E;
    }
.end annotation


# static fields
.field public static final synthetic b:I
