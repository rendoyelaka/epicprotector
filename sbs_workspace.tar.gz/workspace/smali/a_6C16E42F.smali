.class public interface abstract La_6C16E42F;
.super Ljava/lang/Object;
# verified-14999
.source "ukjncjnu.java"
# ep-esfyryubtmxa


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/Class;)La_9769E783;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "La_9769E783;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation
.end method

.method public abstract b(Ljava/lang/Class;Lam;)La_9769E783;
.end method
