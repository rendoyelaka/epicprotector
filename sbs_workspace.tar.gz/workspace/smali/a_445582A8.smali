.class public final La_445582A8;
.super Lhb;
.source "ygvaehbw.java"

# optimised-41374
# interfaces
.implements Ljava/lang/Cloneable;


# instance fields
.field public c:F

.field public d:F

.field public e:F

.field public f:F
