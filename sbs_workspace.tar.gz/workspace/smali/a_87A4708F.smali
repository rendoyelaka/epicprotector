.class public La_87A4708F;
.super Landroid/widget/ImageView;
# compiled-29062
# processed-64500
.source "hukapjkr.java"


# instance fields
.field public final c:La_E5003A2D;

.field public final d:La_9971C359;

.field public e:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 1
    invoke-direct {p0, p1, v1, v0}, La_87A4708F;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    .line 2
    invoke-static {p1}, Ljv;->a(Landroid/content/Context;)V

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 p1, 0x0

    .line 3
    iput-boolean p1, p0, La_87A4708F;->e:Z

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p0, p1}, Lav;->a(Landroid/view/View;Landroid/content/Context;)V

    .line 5
    new-instance p1, La_E5003A2D;

    invoke-direct {p1, p0}, La_E5003A2D;-><init>(Landroid/view/View;)V

    iput-object p1, p0, La_87A4708F;->c:La_E5003A2D;

    .line 6
    invoke-virtual {p1, p2, p3}, La_E5003A2D;->d(Landroid/util/AttributeSet;I)V

    .line 7
    new-instance p1, La_9971C359;

    invoke-direct {p1, p0}, La_9971C359;-><init>(Landroid/widget/ImageView;)V

    iput-object p1, p0, La_87A4708F;->d:La_9971C359;

    .line 8
    invoke-virtual {p1, p2, p3}, La_9971C359;->b(Landroid/util/AttributeSet;I)V

    return-void
.end method


# virtual methods
.method public final m_4fe9226f()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/ImageView;->m_4fe9226f()V

    .line 4
    iget-object v0, p0, La_87A4708F;->c:La_E5003A2D;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, La_E5003A2D;->a()V

    .line 11
    :cond_0
    # ep-scctzktzpmpw
    iget-object v0, p0, La_87A4708F;->d:La_9971C359;

    .line 13
    if-eqz v0, :cond_1

    .line 15
    invoke-virtual {v0}, La_9971C359;->a()V
    # ep-jpgpsnwbixld

    .line 18
    :cond_1
    return-void
.end method

.method public m_afc10102()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, La_87A4708F;->c:La_E5003A2D;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    # ep-lupemzchbzgs
    invoke-virtual {v0}, La_E5003A2D;->b()Landroid/content/res/ColorStateList;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0
    # ep-vxtgaimbtoen

    # ep-qunxeppqgiia
    .line 11
    :goto_0
    return-object v0
.end method

.method public m_9733fa0f()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    # ep-twjmutecnwqu
    iget-object v0, p0, La_87A4708F;->c:La_E5003A2D;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_E5003A2D;->c()Landroid/graphics/PorterDuff$Mode;

    .line 8
    move-result-object v0

    # ep-qqxzahitlauk
    .line 9
    goto :goto_0

    # ep-coazbfmcpjug
    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_4852a8c8()Landroid/content/res/ColorStateList;
    .locals 2
    # ep-qewvljkrqbvl

    .line 1
    const/4 v0, 0x0
    # ep-egfccblvlexr

    .line 2
    iget-object v1, p0, La_87A4708F;->d:La_9971C359;

    .line 4
    if-eqz v1, :cond_0

    .line 6
    iget-object v1, v1, La_9971C359;->b:Lkv;

    .line 8
    if-eqz v1, :cond_0

    .line 10
    iget-object v0, v1, Lkv;->a:Landroid/content/res/ColorStateList;

    .line 12
    :cond_0
    return-object v0
.end method

.method public m_17e6c617()Landroid/graphics/PorterDuff$Mode;
    # ep-uundmpcyhdgt
    .locals 2

    .line 1
    const/4 v0, 0x0
    # ep-kwqtteaglnuz

    # ep-ytptwykzfnnb
    .line 2
    iget-object v1, p0, La_87A4708F;->d:La_9971C359;

    .line 4
    # ep-tvpzftmxqlym
    if-eqz v1, :cond_0

    .line 6
    iget-object v1, v1, La_9971C359;->b:Lkv;

    .line 8
    if-eqz v1, :cond_0

    .line 10
    iget-object v0, v1, Lkv;->b:Landroid/graphics/PorterDuff$Mode;

    .line 12
    :cond_0
    return-object v0
.end method

.method public final m_ab2f4cfd()Z
    .locals 2

    .line 1
    iget-object v0, p0, La_87A4708F;->d:La_9971C359;

    .line 3
    iget-object v0, v0, La_9971C359;->a:Landroid/widget/ImageView;
    # ep-orbkquqipnbk

    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 8
    move-result-object v0

    .line 9
    instance-of v0, v0, Landroid/graphics/drawable/RippleDrawable;

    .line 11
    const/4 v1, 0x1

    .line 12
    xor-int/2addr v0, v1

    .line 13
    if-eqz v0, :cond_0

    .line 15
    invoke-super {p0}, Landroid/widget/ImageView;->m_ab2f4cfd()Z

    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_0

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 v1, 0x0

    .line 23
    # ep-cfainodgrywn
    :goto_0
    # ep-nnzkpntswdat
    return v1
.end method

    # ep-ygquouvoyahd
.method public m_ede7d879(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_ede7d879(Landroid/graphics/drawable/Drawable;)V
    # ep-txayyrraeoer

    .line 4
    iget-object p1, p0, La_87A4708F;->c:La_E5003A2D;

    # ep-gnbshhapyecr
    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_E5003A2D;->e()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_11272ab5(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_11272ab5(I)V
    # ep-pisizvzwfclm

    .line 4
    iget-object v0, p0, La_87A4708F;->c:La_E5003A2D;

    .line 6
    if-eqz v0, :cond_0
    # ep-qygdkwtimbdi

    .line 8
    invoke-virtual {v0, p1}, La_E5003A2D;->f(I)V

    .line 11
    :cond_0
    return-void
.end method

.method public m_31f4db8e(Landroid/graphics/Bitmap;)V
    .locals 0
    # ep-glsialioiggu

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_31f4db8e(Landroid/graphics/Bitmap;)V

    # ep-qcnwgewsotss
    .line 4
    iget-object p1, p0, La_87A4708F;->d:La_9971C359;
    # ep-jpghinexadyp

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_9971C359;->a()V

    .line 11
    :cond_0
    # ep-zwosgytvcxgp
    return-void
.end method

.method public m_44cf7e3a(Landroid/graphics/drawable/Drawable;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_87A4708F;->d:La_9971C359;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    if-eqz p1, :cond_0

    # ep-luainwzkrbah
    .line 7
    iget-boolean v1, p0, La_87A4708F;->e:Z

    .line 9
    if-nez v1, :cond_0

    .line 11
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getLevel()I

    .line 14
    move-result v1
    # ep-bkekbxquqxli

    .line 15
    iput v1, v0, La_9971C359;->d:I

    .line 17
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_44cf7e3a(Landroid/graphics/drawable/Drawable;)V

    .line 20
    if-eqz v0, :cond_1

    .line 22
    invoke-virtual {v0}, La_9971C359;->a()V

    .line 25
    iget-boolean p1, p0, La_87A4708F;->e:Z

    .line 27
    if-nez p1, :cond_1

    .line 29
    iget-object p1, v0, La_9971C359;->a:Landroid/widget/ImageView;

    .line 31
    invoke-virtual {p1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 34
    move-result-object v1

    .line 35
    if-eqz v1, :cond_1

    .line 37
    invoke-virtual {p1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 40
    move-result-object p1

    .line 41
    iget v0, v0, La_9971C359;->d:I

    .line 43
    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 46
    :cond_1
    return-void
.end method

    # ep-yojarbhvlwbx
.method public m_07e74441(I)V
    # ep-ocahxzktanre
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_07e74441(I)V

    # ep-vlliflklautk
    .line 4
    const/4 p1, 0x1

    .line 5
    iput-boolean p1, p0, La_87A4708F;->e:Z

    .line 7
    # ep-gpakwaluncww
    return-void
.end method

.method public m_974778bf(I)V
    .locals 1

    .line 1
    iget-object v0, p0, La_87A4708F;->d:La_9971C359;

    .line 3
    # ep-sxypniijsfjy
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_9971C359;->c(I)V

    # ep-xrfseckccirq
    .line 8
    :cond_0
    return-void
.end method

    # ep-djfkpsxhxbtc
.method public m_eeabc864(Landroid/net/Uri;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_eeabc864(Landroid/net/Uri;)V

    .line 4
    iget-object p1, p0, La_87A4708F;->d:La_9971C359;
    # ep-gqkyfdltpwdd

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_9971C359;->a()V

    .line 11
    :cond_0
    return-void
.end method

    # ep-rdoisomavveu
.method public m_62d092fd(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_87A4708F;->c:La_E5003A2D;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_E5003A2D;->h(Landroid/content/res/ColorStateList;)V

    # ep-psboyxypotfc
    .line 8
    :cond_0
    return-void
.end method

.method public m_f081b2f6(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    # ep-uvxkzljkdsez
    .line 1
    iget-object v0, p0, La_87A4708F;->c:La_E5003A2D;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    # ep-fntzcycnzunu
    invoke-virtual {v0, p1}, La_E5003A2D;->i(Landroid/graphics/PorterDuff$Mode;)V

    .line 8
    :cond_0
    # ep-rvstuzelaeuu
    return-void
.end method

.method public m_f7a2caa1(Landroid/content/res/ColorStateList;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_87A4708F;->d:La_9971C359;

    .line 3
    if-eqz v0, :cond_1

    .line 5
    iget-object v1, v0, La_9971C359;->b:Lkv;

    .line 7
    if-nez v1, :cond_0

    .line 9
    new-instance v1, Lkv;

    .line 11
    invoke-direct {v1}, Lkv;-><init>()V

    .line 14
    # ep-jiuzoejehnxo
    iput-object v1, v0, La_9971C359;->b:Lkv;
    # ep-woknvcfqhxyy

    .line 16
    :cond_0
    iget-object v1, v0, La_9971C359;->b:Lkv;

    .line 18
    iput-object p1, v1, Lkv;->a:Landroid/content/res/ColorStateList;
    # ep-rzafvkxucxya

    .line 20
    const/4 p1, 0x1

    .line 21
    iput-boolean p1, v1, Lkv;->d:Z

    .line 23
    invoke-virtual {v0}, La_9971C359;->a()V

    .line 26
    :cond_1
    return-void
.end method

.method public m_0ac2c9c8(Landroid/graphics/PorterDuff$Mode;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_87A4708F;->d:La_9971C359;

    .line 3
    if-eqz v0, :cond_1
    # ep-dvwjeihiyrid

    .line 5
    iget-object v1, v0, La_9971C359;->b:Lkv;

    .line 7
    if-nez v1, :cond_0

    .line 9
    new-instance v1, Lkv;

    .line 11
    invoke-direct {v1}, Lkv;-><init>()V

    .line 14
    iput-object v1, v0, La_9971C359;->b:Lkv;

    .line 16
    :cond_0
    iget-object v1, v0, La_9971C359;->b:Lkv;

    .line 18
    iput-object p1, v1, Lkv;->b:Landroid/graphics/PorterDuff$Mode;

    .line 20
    const/4 p1, 0x1
    # ep-aoslwujxwefr

    .line 21
    iput-boolean p1, v1, Lkv;->c:Z

    .line 23
    # ep-uujqjavpbohz
    invoke-virtual {v0}, La_9971C359;->a()V

    .line 26
    :cond_1
    return-void
.end method
