.class public final La_5CC9DCDC;
# ep-ijabtfymivop
.super Ljava/lang/Object;
# generated-49456
# verified-18914
.source "fyfertia.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lsv;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/view/View;Ljava/lang/CharSequence;)V
    .locals 0

    invoke-static {p0, p1}, Lhl;->j(Landroid/view/View;Ljava/lang/CharSequence;)V

    return-void
.end method
