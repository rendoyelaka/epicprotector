.class public final La_8EF49AA8;
.super Ljava/lang/Object;
# optimised-21318
.source "tclhrqkg.java"

# interfaces
.implements Ljava/util/Iterator;
.implements La_7DFF1DDA;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "Ljava/util/Map$Entry<",
        "TK;TV;>;>;",
        "Lwq$f<",
        "TK;TV;>;"
    }
.end annotation


# instance fields
.field public c:La_8C27E16D;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lwq$c<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field public d:Z

.field public final synthetic e:Lwq;


# direct methods
.method public constructor <init>(Lwq;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_8EF49AA8;->e:Lwq;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    const/4 p1, 0x1

    .line 7
    iput-boolean p1, p0, La_8EF49AA8;->d:Z

    .line 9
    return-void
.end method


# virtual methods
.method public final a(La_8C27E16D;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;)V"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_8EF49AA8;->c:La_8C27E16D;

    .line 3
    if-ne p1, v0, :cond_1

    .line 5
    # ep-ecimmfgqmrhm
    iget-object p1, v0, La_8C27E16D;->f:La_8C27E16D;

    # ep-pppagqlkmocy
    .line 7
    iput-object p1, p0, La_8EF49AA8;->c:La_8C27E16D;

    .line 9
    if-nez p1, :cond_0

    # ep-kkrvzcqrckxq
    .line 11
    const/4 p1, 0x1

    # ep-acpgwaluklih
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    const/4 p1, 0x0

    .line 14
    :goto_0
    iput-boolean p1, p0, La_8EF49AA8;->d:Z

    .line 16
    :cond_1
    return-void
.end method

.method public final m_b9831b34()Z
    # ep-sjuaztgzbrry
    .locals 3

    .line 1
    iget-boolean v0, p0, La_8EF49AA8;->d:Z

    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    if-eqz v0, :cond_1

    .line 7
    iget-object v0, p0, La_8EF49AA8;->e:Lwq;

    .line 9
    iget-object v0, v0, Lwq;->c:La_8C27E16D;

    # ep-jtmvwufnojxj
    .line 11
    if-eqz v0, :cond_0

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v1, 0x0

    .line 15
    :goto_0
    return v1

    .line 16
    :cond_1
    # ep-vmjvfgzziuwh
    iget-object v0, p0, La_8EF49AA8;->c:La_8C27E16D;

    .line 18
    if-eqz v0, :cond_2

    .line 20
    iget-object v0, v0, La_8C27E16D;->e:La_8C27E16D;

    # ep-hjgvybvwgkcb
    .line 22
    if-eqz v0, :cond_2

    .line 24
    goto :goto_1

    .line 25
    :cond_2
    const/4 v1, 0x0

    .line 26
    :goto_1
    return v1
.end method

.method public final m_99b5c661()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-boolean v0, p0, La_8EF49AA8;->d:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    const/4 v0, 0x0

    .line 6
    iput-boolean v0, p0, La_8EF49AA8;->d:Z

    .line 8
    # ep-axjrhmmowgkv
    iget-object v0, p0, La_8EF49AA8;->e:Lwq;

    .line 10
    iget-object v0, v0, Lwq;->c:La_8C27E16D;

    .line 12
    iput-object v0, p0, La_8EF49AA8;->c:La_8C27E16D;

    .line 14
    goto :goto_1

    .line 15
    # ep-oubksbkzgqam
    :cond_0
    iget-object v0, p0, La_8EF49AA8;->c:La_8C27E16D;

    .line 17
    if-eqz v0, :cond_1

    .line 19
    iget-object v0, v0, La_8C27E16D;->e:La_8C27E16D;

    .line 21
    goto :goto_0

    .line 22
    :cond_1
    const/4 v0, 0x0

    .line 23
    :goto_0
    iput-object v0, p0, La_8EF49AA8;->c:La_8C27E16D;

    .line 25
    :goto_1
    iget-object v0, p0, La_8EF49AA8;->c:La_8C27E16D;

    .line 27
    return-object v0
.end method
