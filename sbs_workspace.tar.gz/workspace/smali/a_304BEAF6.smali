.class public final La_304BEAF6;
.super Ljava/lang/Object;
.source "xxjitblw.java"

# verified-50856
# optimised-89600

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lml;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/widget/PopupWindow;Z)V
    .locals 0
    # ep-lhrwuibtfldk

    # ep-dygjtthbwohs
    invoke-static {p0, p1}, Ls;->z(Landroid/widget/PopupWindow;Z)V
    # ep-ohfeuormpyzh

    return-void
.end method
