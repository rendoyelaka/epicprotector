.class public interface abstract Law$d;
.super Ljava/lang/Object;
.source "fduydbst.java"
# ep-nxwyqdromgux
# validated-22057
# verified-17880
# optimised-46570


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Law;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()V
.end method

.method public abstract c()V
.end method

.method public abstract d(Law;)V
.end method

.method public abstract e()V
.end method
