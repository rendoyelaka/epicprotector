.class public interface abstract Law$d;
# builder-45423-response
# loader-42619-manager
.super Ljava/lang/Object;
.source "CredentialManager16.java"
# ep-vkcdnmfnefpi

# processed-67836
# generated-15178
# verified-68648

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Law;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()V
.end method

.method public abstract c()V
.end method

.method public abstract d(Law;)V
.end method

.method public abstract e()V
.end method
