.class public interface abstract Law$d;
.super Ljava/lang/Object;
.source "cvlzjuae.java"
# verified-33424
# optimised-19982
# compiled-67455
# ep-otjlwewkujfi


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Law;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()V
.end method

.method public abstract c()V
.end method

.method public abstract d(Law;)V
.end method

.method public abstract e()V
.end method
