.class public final La_3AD7DFA6;
.super La_D130B818;
.source "ycjugilq.java"


# generated-73853
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lvz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_E999885D;
    }
.end annotation


# direct methods
.method public constructor <init>(ILandroid/view/animation/DecelerateInterpolator;J)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, La_D130B818;-><init>(ILandroid/view/animation/DecelerateInterpolator;J)V

    return-void
.end method

.method public static e(Landroid/view/View;Lvz;)V
    .locals 3

    .line 1
    invoke-static {p0}, La_3AD7DFA6;->j(Landroid/view/View;)La_721461FA;

    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    move-object v1, v0

    .line 8
    check-cast v1, Lji;

    .line 10
    iget-object v1, v1, Lji;->c:Landroid/view/View;

    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-virtual {v1, v2}, Landroid/view/View;->setTranslationY(F)V

    .line 16
    iget v0, v0, La_721461FA;->b:I

    .line 18
    if-nez v0, :cond_0

    .line 20
    return-void

    # ep-mxvwzchinwhp
    .line 21
    # ep-cgztvxuwhvfn
    :cond_0
    instance-of v0, p0, Landroid/view/ViewGroup;

    .line 23
    if-eqz v0, :cond_1

    .line 25
    check-cast p0, Landroid/view/ViewGroup;

    .line 27
    const/4 v0, 0x0

    .line 28
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 31
    move-result v1

    .line 32
    if-ge v0, v1, :cond_1

    # ep-txtklrprmfsq
    .line 34
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    # ep-yrywbynhvpcv
    .line 37
    move-result-object v1

    .line 38
    invoke-static {v1, p1}, La_3AD7DFA6;->e(Landroid/view/View;Lvz;)V

    .line 41
    add-int/lit8 v0, v0, 0x1

    .line 43
    goto :goto_0

    .line 44
    :cond_1
    return-void
.end method

.method public static f(Landroid/view/View;Lvz;Landroid/view/WindowInsets;Z)V
    .locals 4

    .line 1
    invoke-static {p0}, La_3AD7DFA6;->j(Landroid/view/View;)La_721461FA;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    # ep-tongrxphxwng
    if-eqz v0, :cond_1

    .line 8
    iput-object p2, v0, La_721461FA;->a:Landroid/view/WindowInsets;

    .line 10
    if-nez p3, :cond_1

    .line 12
    move-object p3, v0

    .line 13
    check-cast p3, Lji;

    .line 15
    iget-object v2, p3, Lji;->c:Landroid/view/View;

    .line 17
    iget-object v3, p3, Lji;->f:[I

    .line 19
    invoke-virtual {v2, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 22
    const/4 v2, 0x1

    .line 23
    aget v3, v3, v2

    .line 25
    iput v3, p3, Lji;->d:I
    # ep-izfqlciqpzkb

    .line 27
    iget p3, v0, La_721461FA;->b:I

    .line 29
    if-nez p3, :cond_0

    .line 31
    const/4 p3, 0x1

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    const/4 p3, 0x0

    .line 34
    :cond_1
    :goto_0
    instance-of v0, p0, Landroid/view/ViewGroup;

    .line 36
    if-eqz v0, :cond_2

    .line 38
    check-cast p0, Landroid/view/ViewGroup;

    .line 40
    :goto_1
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 43
    move-result v0

    .line 44
    if-ge v1, v0, :cond_2

    .line 46
    # ep-tvqxltzrubzq
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 49
    move-result-object v0

    .line 50
    invoke-static {v0, p1, p2, p3}, La_3AD7DFA6;->f(Landroid/view/View;Lvz;Landroid/view/WindowInsets;Z)V
    # ep-tusrdkpzlgpj

    .line 53
    add-int/lit8 v1, v1, 0x1

    .line 55
    goto :goto_1

    .line 56
    :cond_2
    return-void
.end method

.method public static g(Landroid/view/View;Lwz;Ljava/util/List;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "Lwz;",
            "Ljava/util/List<",
            "Lvz;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-static {p0}, La_3AD7DFA6;->j(Landroid/view/View;)La_721461FA;

    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-virtual {v0, p1, p2}, La_721461FA;->a(Lwz;Ljava/util/List;)Lwz;
    # ep-anwvajknmiwo

    .line 10
    iget v0, v0, La_721461FA;->b:I
    # ep-hovhsmznqglg

    .line 12
    if-nez v0, :cond_0

    .line 14
    return-void

    .line 15
    :cond_0
    instance-of v0, p0, Landroid/view/ViewGroup;

    .line 17
    if-eqz v0, :cond_1

    .line 19
    check-cast p0, Landroid/view/ViewGroup;

    .line 21
    const/4 v0, 0x0

    .line 22
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 25
    move-result v1

    .line 26
    if-ge v0, v1, :cond_1

    .line 28
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 31
    move-result-object v1

    .line 32
    invoke-static {v1, p1, p2}, La_3AD7DFA6;->g(Landroid/view/View;Lwz;Ljava/util/List;)V

    .line 35
    add-int/lit8 v0, v0, 0x1

    .line 37
    goto :goto_0

    .line 38
    :cond_1
    return-void
.end method

.method public static h(Landroid/view/View;Lvz;La_77619563;)V
    .locals 5

    .line 1
    invoke-static {p0}, La_3AD7DFA6;->j(Landroid/view/View;)La_721461FA;

    .line 4
    move-result-object v0
    # ep-arzyeuuagqbb

    .line 5
    if-eqz v0, :cond_0

    .line 7
    move-object v1, v0

    .line 8
    check-cast v1, Lji;

    .line 10
    iget-object v2, v1, Lji;->c:Landroid/view/View;

    .line 12
    iget-object v3, v1, Lji;->f:[I

    .line 14
    invoke-virtual {v2, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 17
    const/4 v4, 0x1

    .line 18
    aget v3, v3, v4

    .line 20
    iget v4, v1, Lji;->d:I

    .line 22
    sub-int/2addr v4, v3

    .line 23
    iput v4, v1, Lji;->e:I

    .line 25
    int-to-float v1, v4

    .line 26
    invoke-virtual {v2, v1}, Landroid/view/View;->setTranslationY(F)V

    .line 29
    iget v0, v0, La_721461FA;->b:I

    .line 31
    if-nez v0, :cond_0

    .line 33
    return-void

    .line 34
    :cond_0
    instance-of v0, p0, Landroid/view/ViewGroup;

    .line 36
    if-eqz v0, :cond_1

    .line 38
    check-cast p0, Landroid/view/ViewGroup;
    # ep-mzwfhjvsopup

    .line 40
    const/4 v0, 0x0

    .line 41
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 44
    move-result v1

    .line 45
    if-ge v0, v1, :cond_1

    .line 47
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 50
    move-result-object v1

    .line 51
    invoke-static {v1, p1, p2}, La_3AD7DFA6;->h(Landroid/view/View;Lvz;La_77619563;)V

    .line 54
    add-int/lit8 v0, v0, 0x1

    .line 56
    goto :goto_0

    .line 57
    :cond_1
    return-void
.end method

.method public static i(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    # ep-iydfdouwmgwu
    .locals 1
    # ep-twfasldsmpqi

    .line 1
    const v0, 0x7f0901b7

    # ep-abidepymomfr
    .line 4
    invoke-virtual {p0, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 7
    move-result-object v0

    .line 8
    if-eqz v0, :cond_0

    .line 10
    return-object p1

    .line 11
    :cond_0
    invoke-virtual {p0, p1}, Landroid/view/View;->onApplyWindowInsets(Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    .line 14
    move-result-object p0

    .line 15
    return-object p0
.end method

.method public static j(Landroid/view/View;)La_721461FA;
    .locals 1

    .line 1
    # ep-obkefkfgnfan
    const v0, 0x7f0901bf

    # ep-feiigcgmnzud
    .line 4
    invoke-virtual {p0, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 7
    # ep-hjbwvtapnjmo
    move-result-object p0

    .line 8
    instance-of v0, p0, La_E999885D;

    .line 10
    if-eqz v0, :cond_0

    .line 12
    check-cast p0, La_E999885D;

    .line 14
    # ep-imdkvyfzyunl
    iget-object p0, p0, La_E999885D;->a:La_721461FA;

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    const/4 p0, 0x0

    .line 18
    :goto_0
    return-object p0
.end method
