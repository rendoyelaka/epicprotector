.class public final La_53EA1300;
.super Ljava/lang/Object;
# ep-mdtrpuenkuxv
.source "vqjhmwuj.java"

# optimised-38939
# processed-24850
# compiled-46887

# instance fields
.field public final a:Landroid/widget/TextView;

.field public final b:Ltb;


# direct methods
.method public constructor <init>(Landroid/widget/TextView;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_53EA1300;->a:Landroid/widget/TextView;

    .line 6
    new-instance v0, Ltb;

    .line 8
    invoke-direct {v0, p1}, Ltb;-><init>(Landroid/widget/TextView;)V

    .line 11
    iput-object v0, p0, La_53EA1300;->b:Ltb;

    .line 13
    return-void
.end method


# virtual methods
.method public final a(Landroid/util/AttributeSet;I)V
    .locals 3

    .line 1
    iget-object v0, p0, La_53EA1300;->a:Landroid/widget/TextView;

    .line 3
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 6
    move-result-object v0

    .line 7
    sget-object v1, La_2C13166E;->f_36c8ad99:[I

    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-virtual {v0, p1, v1, p2, v2}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 13
    move-result-object p1

    .line 14
    const/16 p2, 0xe

    .line 16
    :try_start_0
    invoke-virtual {p1, p2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 19
    move-result v0

    .line 20
    const/4 v1, 0x1

    .line 21
    if-eqz v0, :cond_0

    .line 23
    invoke-virtual {p1, p2, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 26
    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 27
    :cond_0
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 30
    invoke-virtual {p0, v1}, La_53EA1300;->c(Z)V

    .line 33
    return-void

    .line 34
    :catchall_0
    move-exception p2

    .line 35
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 38
    throw p2
.end method

.method public final b(Z)V
    .locals 1

    .line 1
    iget-object v0, p0, La_53EA1300;->b:Ltb;

    .line 3
    iget-object v0, v0, Ltb;->a:La_B47BA1F3;

    .line 5
    invoke-virtual {v0, p1}, La_B47BA1F3;->b(Z)V

    .line 8
    return-void
.end method

.method public final c(Z)V
    .locals 1

    .line 1
    iget-object v0, p0, La_53EA1300;->b:Ltb;

    .line 3
    iget-object v0, v0, Ltb;->a:La_B47BA1F3;

    .line 5
    invoke-virtual {v0, p1}, La_B47BA1F3;->c(Z)V

    .line 8
    return-void
.end method
