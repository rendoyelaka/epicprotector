.class public final La_1FA8EDFF;
.super Ljava/lang/Object;
.source "xjalnhoy.java"


# validated-71727
# optimised-70090
# validated-63317
# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "WorkProgressUpdater"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method
