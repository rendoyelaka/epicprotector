.class public final La_18C5F7AB;
.super Ljava/lang/Object;
.source "lfibqbqz.java"

# ep-ifwcjjdpcwuc
# generated-88003
# compiled-88266
# generated-42733
# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic c:I

.field public final synthetic d:La_9635C684;


# direct methods
.method public constructor <init>(La_9635C684;I)V
    .locals 0

    iput-object p1, p0, La_18C5F7AB;->d:La_9635C684;

    iput p2, p0, La_18C5F7AB;->c:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 5

    .line 1
    iget-object p1, p0, La_18C5F7AB;->d:La_9635C684;

    .line 3
    iget-object v0, p1, La_9635C684;->c:Lcom/google/android/material/datepicker/c;

    .line 5
    iget-object v0, v0, Lcom/google/android/material/datepicker/c;->f_1f788c37:Ltl;

    .line 7
    iget v0, v0, Ltl;->d:I

    .line 9
    iget v1, p0, La_18C5F7AB;->c:I

    .line 11
    invoke-static {v1, v0}, Ltl;->l(II)Ltl;

    .line 14
    move-result-object v0

    .line 15
    iget-object p1, p1, La_9635C684;->c:Lcom/google/android/material/datepicker/c;

    .line 17
    iget-object v1, p1, Lcom/google/android/material/datepicker/c;->f_526d6075:Lcom/google/android/material/datepicker/a;

    .line 19
    iget-object v2, v1, Lcom/google/android/material/datepicker/a;->c:Ltl;

    .line 21
    iget-object v3, v2, Ltl;->c:Ljava/util/Calendar;

    .line 23
    iget-object v4, v0, Ltl;->c:Ljava/util/Calendar;

    .line 25
    invoke-virtual {v4, v3}, Ljava/util/Calendar;->compareTo(Ljava/util/Calendar;)I

    .line 28
    move-result v3

    .line 29
    if-gez v3, :cond_0

    .line 31
    move-object v0, v2

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    iget-object v1, v1, Lcom/google/android/material/datepicker/a;->d:Ltl;

    .line 35
    iget-object v2, v1, Ltl;->c:Ljava/util/Calendar;

    .line 37
    invoke-virtual {v4, v2}, Ljava/util/Calendar;->compareTo(Ljava/util/Calendar;)I

    .line 40
    move-result v2

    .line 41
    if-lez v2, :cond_1

    .line 43
    move-object v0, v1

    .line 44
    :cond_1
    :goto_0
    invoke-virtual {p1, v0}, Lcom/google/android/material/datepicker/c;->m_767412bd(Ltl;)V

    .line 47
    const/4 v0, 0x1

    .line 48
    invoke-virtual {p1, v0}, Lcom/google/android/material/datepicker/c;->m_4773b71c(I)V

    .line 51
    return-void
.end method
