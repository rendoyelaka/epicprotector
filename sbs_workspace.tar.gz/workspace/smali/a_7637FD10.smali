.class public interface abstract La_7637FD10;
.super Ljava/lang/Object;
# ep-lfccxyfgctcs
# optimised-85927
# generated-49883
# compiled-16227
.source "xjpplcsg.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_90072CF5;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation


# virtual methods
.method public abstract onRequestPermissionsResult(I[Ljava/lang/String;[I)V
.end method
