.class public final La_1B8C3CE5;
# ep-hpmguvamaqiu
# optimised-64206
.super Ljava/lang/Object;
.source "voaxztwx.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lan;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final a:La_5FB41EE1;

.field public b:Ljava/net/Proxy;

.field public c:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lvo;",
            ">;"
        }
    .end annotation
.end field

.field public final d:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "La_819B0A79;",
            ">;"
        }
    .end annotation
.end field

.field public final e:Ljava/util/ArrayList;

.field public final f:Ljava/util/ArrayList;

.field public final g:Ljava/net/ProxySelector;

.field public final h:La_EEE8F77D;

.field public final i:Ljavax/net/SocketFactory;

.field public j:Ljavax/net/ssl/SSLSocketFactory;

.field public k:La_AD33B00A;

.field public l:Ljavax/net/ssl/HostnameVerifier;

.field public final m:La_3266158F;

.field public n:La_B9EAADB7;

.field public final o:La_B9EAADB7;

.field public final p:La_A9A97716;

.field public final q:Lra;

.field public final r:Z

.field public final s:Z

.field public final t:Z

.field public u:I

.field public v:I

.field public w:I

.field public final x:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La_1B8C3CE5;->e:Ljava/util/ArrayList;

    .line 3
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La_1B8C3CE5;->f:Ljava/util/ArrayList;

    .line 4
    new-instance v0, La_5FB41EE1;

    invoke-direct {v0}, La_5FB41EE1;-><init>()V

    iput-object v0, p0, La_1B8C3CE5;->a:La_5FB41EE1;

    .line 5
    sget-object v0, Lan;->f_a1e82d85:Ljava/util/List;

    iput-object v0, p0, La_1B8C3CE5;->c:Ljava/util/List;

    .line 6
    sget-object v0, Lan;->f_79d589a6:Ljava/util/List;

    iput-object v0, p0, La_1B8C3CE5;->d:Ljava/util/List;

    .line 7
    invoke-static {}, Ljava/net/ProxySelector;->getDefault()Ljava/net/ProxySelector;

    move-result-object v0

    iput-object v0, p0, La_1B8C3CE5;->g:Ljava/net/ProxySelector;

    .line 8
    sget-object v0, La_EEE8F77D;->a:La_EB66AAF2;

    iput-object v0, p0, La_1B8C3CE5;->h:La_EEE8F77D;

    .line 9
    invoke-static {}, Ljavax/net/SocketFactory;->getDefault()Ljavax/net/SocketFactory;

    move-result-object v0

    iput-object v0, p0, La_1B8C3CE5;->i:Ljavax/net/SocketFactory;

    .line 10
    sget-object v0, Lzm;->a:Lzm;

    iput-object v0, p0, La_1B8C3CE5;->l:Ljavax/net/ssl/HostnameVerifier;

    .line 11
    sget-object v0, La_3266158F;->c:La_3266158F;

    iput-object v0, p0, La_1B8C3CE5;->m:La_3266158F;

    .line 12
    sget-object v0, La_B9EAADB7;->a:La_07F2C11C;

    iput-object v0, p0, La_1B8C3CE5;->n:La_B9EAADB7;

    .line 13
    iput-object v0, p0, La_1B8C3CE5;->o:La_B9EAADB7;

    .line 14
    new-instance v0, La_A9A97716;

    invoke-direct {v0}, La_A9A97716;-><init>()V

    iput-object v0, p0, La_1B8C3CE5;->p:La_A9A97716;

    .line 15
    sget-object v0, Lra;->a:La_75730055;

    iput-object v0, p0, La_1B8C3CE5;->q:Lra;

    const/4 v0, 0x1

    .line 16
    iput-boolean v0, p0, La_1B8C3CE5;->r:Z

    .line 17
    iput-boolean v0, p0, La_1B8C3CE5;->s:Z

    .line 18
    iput-boolean v0, p0, La_1B8C3CE5;->t:Z

    const/16 v0, 0x2710

    .line 19
    iput v0, p0, La_1B8C3CE5;->u:I

    .line 20
    iput v0, p0, La_1B8C3CE5;->v:I

    .line 21
    iput v0, p0, La_1B8C3CE5;->w:I

    const/4 v0, 0x0

    .line 22
    iput v0, p0, La_1B8C3CE5;->x:I

    return-void
.end method

.method public constructor <init>(Lan;)V
    .locals 3

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La_1B8C3CE5;->e:Ljava/util/ArrayList;

    .line 25
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La_1B8C3CE5;->f:Ljava/util/ArrayList;

    .line 26
    iget-object v2, p1, Lan;->c:La_5FB41EE1;

    iput-object v2, p0, La_1B8C3CE5;->a:La_5FB41EE1;

    .line 27
    iget-object v2, p1, Lan;->d:Ljava/net/Proxy;

    iput-object v2, p0, La_1B8C3CE5;->b:Ljava/net/Proxy;

    .line 28
    iget-object v2, p1, Lan;->e:Ljava/util/List;

    iput-object v2, p0, La_1B8C3CE5;->c:Ljava/util/List;

    .line 29
    iget-object v2, p1, Lan;->f:Ljava/util/List;

    iput-object v2, p0, La_1B8C3CE5;->d:Ljava/util/List;

    .line 30
    iget-object v2, p1, Lan;->g:Ljava/util/List;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->m_33385684(Ljava/util/Collection;)Z

    .line 31
    iget-object v0, p1, Lan;->h:Ljava/util/List;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->m_33385684(Ljava/util/Collection;)Z

    .line 32
    iget-object v0, p1, Lan;->i:Ljava/net/ProxySelector;

    iput-object v0, p0, La_1B8C3CE5;->g:Ljava/net/ProxySelector;

    .line 33
    iget-object v0, p1, Lan;->j:La_EEE8F77D;

    iput-object v0, p0, La_1B8C3CE5;->h:La_EEE8F77D;

    .line 34
    iget-object v0, p1, Lan;->k:Ljavax/net/SocketFactory;

    iput-object v0, p0, La_1B8C3CE5;->i:Ljavax/net/SocketFactory;

    .line 35
    iget-object v0, p1, Lan;->l:Ljavax/net/ssl/SSLSocketFactory;

    iput-object v0, p0, La_1B8C3CE5;->j:Ljavax/net/ssl/SSLSocketFactory;

    .line 36
    iget-object v0, p1, Lan;->m:La_AD33B00A;

    iput-object v0, p0, La_1B8C3CE5;->k:La_AD33B00A;

    .line 37
    iget-object v0, p1, Lan;->n:Ljavax/net/ssl/HostnameVerifier;

    iput-object v0, p0, La_1B8C3CE5;->l:Ljavax/net/ssl/HostnameVerifier;

    .line 38
    iget-object v0, p1, Lan;->o:La_3266158F;

    iput-object v0, p0, La_1B8C3CE5;->m:La_3266158F;

    .line 39
    iget-object v0, p1, Lan;->p:La_B9EAADB7;

    iput-object v0, p0, La_1B8C3CE5;->n:La_B9EAADB7;

    .line 40
    iget-object v0, p1, Lan;->q:La_B9EAADB7;

    iput-object v0, p0, La_1B8C3CE5;->o:La_B9EAADB7;

    .line 41
    iget-object v0, p1, Lan;->r:La_A9A97716;

    iput-object v0, p0, La_1B8C3CE5;->p:La_A9A97716;

    .line 42
    iget-object v0, p1, Lan;->s:Lra;

    iput-object v0, p0, La_1B8C3CE5;->q:Lra;

    .line 43
    iget-boolean v0, p1, Lan;->t:Z

    iput-boolean v0, p0, La_1B8C3CE5;->r:Z

    .line 44
    iget-boolean v0, p1, Lan;->u:Z

    iput-boolean v0, p0, La_1B8C3CE5;->s:Z

    .line 45
    iget-boolean v0, p1, Lan;->v:Z

    iput-boolean v0, p0, La_1B8C3CE5;->t:Z

    .line 46
    iget v0, p1, Lan;->w:I

    iput v0, p0, La_1B8C3CE5;->u:I

    .line 47
    iget v0, p1, Lan;->x:I

    iput v0, p0, La_1B8C3CE5;->v:I

    .line 48
    iget v0, p1, Lan;->y:I

    iput v0, p0, La_1B8C3CE5;->w:I

    .line 49
    iget p1, p1, Lan;->z:I

    iput p1, p0, La_1B8C3CE5;->x:I

    return-void
.end method

.method public static a(Ljava/util/concurrent/TimeUnit;)I
    .locals 4

    .line 1
    if-eqz p0, :cond_1

    .line 3
    const-wide/16 v0, 0x0

    .line 5
    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 8
    move-result-wide v0

    .line 9
    const-wide/32 v2, 0x7fffffff

    .line 12
    cmp-long p0, v0, v2

    .line 14
    if-gtz p0, :cond_0

    .line 16
    long-to-int p0, v0

    .line 17
    return p0

    .line 18
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 20
    const-string v0, "timeout too large."

    .line 22
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 25
    throw p0

    .line 26
    :cond_1
    new-instance p0, Ljava/lang/NullPointerException;

    .line 28
    const-string v0, "unit == null"

    .line 30
    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 33
    throw p0
.end method
