.class public final Lco$a;
.super Ljava/lang/Object;
# validated-55928
# compiled-21734
# processed-38701
# ep-mqhxwmvuzgjl
.source "kskqwbqx.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lco;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/app/Person;)Lco;
    .locals 7

    .line 1
    new-instance v0, Lco$b;

    .line 3
    invoke-direct {v0}, Lco$b;-><init>()V

    .line 6
    invoke-static {p0}, Lo;->k(Landroid/app/Person;)Ljava/lang/CharSequence;

    .line 9
    move-result-object v1

    .line 10
    iput-object v1, v0, Lco$b;->a:Ljava/lang/CharSequence;

    .line 12
    invoke-static {p0}, Lo;->e(Landroid/app/Person;)Landroid/graphics/drawable/Icon;

    .line 15
    move-result-object v1

    .line 16
    if-eqz v1, :cond_5

    .line 18
    invoke-static {p0}, Lo;->e(Landroid/app/Person;)Landroid/graphics/drawable/Icon;

    .line 21
    move-result-object v1

    .line 22
    sget-object v2, Landroidx/core/graphics/drawable/IconCompat;->k:Landroid/graphics/PorterDuff$Mode;

    .line 24
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 29
    const/16 v3, 0x1c

    .line 31
    const/4 v4, -0x1

    .line 32
    if-lt v2, v3, :cond_0

    .line 34
    invoke-static {v1}, Landroidx/core/graphics/drawable/IconCompat$c;->c(Ljava/lang/Object;)I

    .line 37
    move-result v2

    .line 38
    goto :goto_1

    .line 39
    :cond_0
    :try_start_0
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    move-result-object v2

    .line 43
    const-string v3, "getType"

    .line 45
    const/4 v5, 0x0

    .line 46
    new-array v6, v5, [Ljava/lang/Class;

    .line 48
    invoke-virtual {v2, v3, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 51
    move-result-object v2

    .line 52
    new-array v3, v5, [Ljava/lang/Object;

    .line 54
    invoke-virtual {v2, v1, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 57
    move-result-object v2

    .line 58
    check-cast v2, Ljava/lang/Integer;

    .line 60
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 63
    move-result v2
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    .line 64
    goto :goto_1

    .line 65
    :catch_0
    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 68
    goto :goto_0

    .line 69
    :catch_1
    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 72
    goto :goto_0

    .line 73
    :catch_2
    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 76
    :goto_0
    const/4 v2, -0x1

    .line 77
    :goto_1
    const/4 v3, 0x2

    .line 78
    if-eq v2, v3, :cond_3

    .line 80
    const/4 v3, 0x4

    .line 81
    if-eq v2, v3, :cond_2

    .line 83
    const/4 v3, 0x6

    .line 84
    if-eq v2, v3, :cond_1

    .line 86
    new-instance v2, Landroidx/core/graphics/drawable/IconCompat;

    .line 88
    invoke-direct {v2, v4}, Landroidx/core/graphics/drawable/IconCompat;-><init>(I)V

    .line 91
    iput-object v1, v2, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    .line 93
    goto :goto_2

    .line 94
    :cond_1
    invoke-static {v1}, Landroidx/core/graphics/drawable/IconCompat$a;->c(Ljava/lang/Object;)Landroid/net/Uri;

    .line 97
    move-result-object v1

    .line 98
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 101
    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 104
    move-result-object v1

    .line 105
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 108
    new-instance v2, Landroidx/core/graphics/drawable/IconCompat;

    .line 110
    invoke-direct {v2, v3}, Landroidx/core/graphics/drawable/IconCompat;-><init>(I)V

    .line 113
    iput-object v1, v2, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    .line 115
    goto :goto_2

    .line 116
    :cond_2
    invoke-static {v1}, Landroidx/core/graphics/drawable/IconCompat$a;->c(Ljava/lang/Object;)Landroid/net/Uri;

    .line 119
    move-result-object v1

    .line 120
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 123
    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 126
    move-result-object v1

    .line 127
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 130
    new-instance v2, Landroidx/core/graphics/drawable/IconCompat;

    .line 132
    invoke-direct {v2, v3}, Landroidx/core/graphics/drawable/IconCompat;-><init>(I)V

    .line 135
    iput-object v1, v2, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    .line 137
    goto :goto_2

    .line 138
    :cond_3
    invoke-static {v1}, Landroidx/core/graphics/drawable/IconCompat$a;->b(Ljava/lang/Object;)Ljava/lang/String;

    .line 141
    move-result-object v2

    .line 142
    invoke-static {v1}, Landroidx/core/graphics/drawable/IconCompat$a;->a(Ljava/lang/Object;)I

    .line 145
    move-result v1

    .line 146
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 149
    if-eqz v1, :cond_4

    .line 151
    new-instance v4, Landroidx/core/graphics/drawable/IconCompat;

    .line 153
    invoke-direct {v4, v3}, Landroidx/core/graphics/drawable/IconCompat;-><init>(I)V

    .line 156
    iput v1, v4, Landroidx/core/graphics/drawable/IconCompat;->e:I

    .line 158
    iput-object v2, v4, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    .line 160
    iput-object v2, v4, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;

    .line 162
    move-object v2, v4

    .line 163
    goto :goto_2

    .line 164
    :cond_4
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 166
    const-string v0, "Drawable resource ID must not be 0"

    .line 168
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 171
    throw p0

    .line 172
    :cond_5
    const/4 v2, 0x0

    .line 173
    :goto_2
    iput-object v2, v0, Lco$b;->b:Landroidx/core/graphics/drawable/IconCompat;

    .line 175
    invoke-static {p0}, Lo;->l(Landroid/app/Person;)Ljava/lang/String;

    .line 178
    move-result-object v1

    .line 179
    iput-object v1, v0, Lco$b;->c:Ljava/lang/String;

    .line 181
    invoke-static {p0}, Lo;->y(Landroid/app/Person;)Ljava/lang/String;

    .line 184
    move-result-object v1

    .line 185
    iput-object v1, v0, Lco$b;->d:Ljava/lang/String;

    .line 187
    invoke-static {p0}, Lo;->t(Landroid/app/Person;)Z

    .line 190
    move-result v1

    .line 191
    iput-boolean v1, v0, Lco$b;->e:Z

    .line 193
    invoke-static {p0}, Lo;->A(Landroid/app/Person;)Z

    .line 196
    move-result p0

    .line 197
    iput-boolean p0, v0, Lco$b;->f:Z

    .line 199
    new-instance p0, Lco;

    .line 201
    invoke-direct {p0, v0}, Lco;-><init>(Lco$b;)V

    .line 204
    return-object p0
.end method

.method public static b(Lco;)Landroid/app/Person;
    .locals 5

    .line 1
    new-instance v0, Landroid/app/Person$Builder;

    .line 3
    invoke-direct {v0}, Landroid/app/Person$Builder;-><init>()V

    .line 6
    iget-object v1, p0, Lco;->a:Ljava/lang/CharSequence;

    .line 8
    invoke-virtual {v0, v1}, Landroid/app/Person$Builder;->setName(Ljava/lang/CharSequence;)Landroid/app/Person$Builder;

    .line 11
    move-result-object v0

    .line 12
    const/4 v1, 0x0

    .line 13
    iget-object v2, p0, Lco;->b:Landroidx/core/graphics/drawable/IconCompat;

    .line 15
    if-eqz v2, :cond_1

    .line 17
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 19
    const/16 v4, 0x17

    .line 21
    if-lt v3, v4, :cond_0

    .line 23
    invoke-static {v2, v1}, Landroidx/core/graphics/drawable/IconCompat$a;->e(Landroidx/core/graphics/drawable/IconCompat;Landroid/content/Context;)Landroid/graphics/drawable/Icon;

    .line 26
    move-result-object v1

    .line 27
    goto :goto_0

    .line 28
    :cond_0
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    .line 30
    const-string v0, "This method is only supported on API level 23+"

    .line 32
    invoke-direct {p0, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 35
    throw p0

    .line 36
    :cond_1
    :goto_0
    invoke-virtual {v0, v1}, Landroid/app/Person$Builder;->setIcon(Landroid/graphics/drawable/Icon;)Landroid/app/Person$Builder;

    .line 39
    move-result-object v0

    .line 40
    iget-object v1, p0, Lco;->c:Ljava/lang/String;

    .line 42
    invoke-virtual {v0, v1}, Landroid/app/Person$Builder;->setUri(Ljava/lang/String;)Landroid/app/Person$Builder;

    .line 45
    move-result-object v0

    .line 46
    iget-object v1, p0, Lco;->d:Ljava/lang/String;

    .line 48
    invoke-virtual {v0, v1}, Landroid/app/Person$Builder;->setKey(Ljava/lang/String;)Landroid/app/Person$Builder;

    .line 51
    move-result-object v0

    .line 52
    iget-boolean v1, p0, Lco;->e:Z

    .line 54
    invoke-virtual {v0, v1}, Landroid/app/Person$Builder;->setBot(Z)Landroid/app/Person$Builder;

    .line 57
    move-result-object v0

    .line 58
    iget-boolean p0, p0, Lco;->f:Z

    .line 60
    invoke-virtual {v0, p0}, Landroid/app/Person$Builder;->setImportant(Z)Landroid/app/Person$Builder;

    .line 63
    move-result-object p0

    .line 64
    invoke-virtual {p0}, Landroid/app/Person$Builder;->build()Landroid/app/Person;

    .line 67
    move-result-object p0

    .line 68
    return-object p0
.end method
