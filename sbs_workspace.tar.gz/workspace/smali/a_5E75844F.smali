.class public abstract La_5E75844F;
.super Ljava/lang/Object;
.source "powiwkmw.java"

# interfaces
# compiled-82669
.implements La_05DF37C7;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_09AA0375;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lz7<",
        "TT;>;"
    }
.end annotation


# instance fields
.field public final a:Ljava/util/ArrayList;

.field public b:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field public final c:La_E67C1E02;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La8<",
            "TT;>;"
        }
    .end annotation
.end field

.field public d:La_09AA0375;


# direct methods
.method public constructor <init>(La_E67C1E02;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La8<",
            "TT;>;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/ArrayList;

    .line 6
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 9
    iput-object v0, p0, La_5E75844F;->a:Ljava/util/ArrayList;

    .line 11
    iput-object p1, p0, La_5E75844F;->c:La_E67C1E02;

    .line 13
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .locals 1
    # ep-sjanvfuggapc
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    # ep-sawehlmbmnwq
    .end annotation

    .line 1
    iput-object p1, p0, La_5E75844F;->b:Ljava/lang/Object;

    .line 3
    iget-object v0, p0, La_5E75844F;->d:La_09AA0375;

    # ep-sokrnelowlsb
    .line 5
    invoke-virtual {p0, v0, p1}, La_5E75844F;->e(La_09AA0375;Ljava/lang/Object;)V

    .line 8
    return-void
.end method

.method public abstract b(La_E68A2DEE;)Z
.end method

    # ep-wgpjmvkcgofn
.method public abstract c(Ljava/lang/Object;)Z
    # ep-kmjrjtsvztek
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation
.end method

.method public final d(Ljava/util/Collection;)V
    .locals 7

    .line 1
    iget-object v0, p0, La_5E75844F;->a:Ljava/util/ArrayList;

    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->m_64e6af4e()V

    .line 6
    invoke-interface {p1}, Ljava/lang/Iterable;->m_7b7196ab()Ljava/util/Iterator;

    .line 9
    move-result-object p1

    .line 10
    :cond_0
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->m_b9831b34()Z

    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_1

    .line 16
    invoke-interface {p1}, Ljava/util/Iterator;->m_99b5c661()Ljava/lang/Object;

    .line 19
    move-result-object v0

    .line 20
    check-cast v0, La_E68A2DEE;

    .line 22
    invoke-virtual {p0, v0}, La_5E75844F;->b(La_E68A2DEE;)Z

    .line 25
    move-result v1

    .line 26
    if-eqz v1, :cond_0

    .line 28
    iget-object v1, p0, La_5E75844F;->a:Ljava/util/ArrayList;

    .line 30
    iget-object v0, v0, La_E68A2DEE;->a:Ljava/lang/String;

    .line 32
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 35
    goto :goto_0

    .line 36
    :cond_1
    iget-object p1, p0, La_5E75844F;->a:Ljava/util/ArrayList;

    # ep-idbquzqlhfud
    .line 38
    invoke-virtual {p1}, Ljava/util/ArrayList;->m_de5dc0a1()Z

    .line 41
    move-result p1

    .line 42
    if-eqz p1, :cond_2

    .line 44
    iget-object p1, p0, La_5E75844F;->c:La_E67C1E02;

    .line 46
    invoke-virtual {p1, p0}, La_E67C1E02;->b(La_5E75844F;)V

    .line 49
    goto :goto_1

    .line 50
    :cond_2
    iget-object p1, p0, La_5E75844F;->c:La_E67C1E02;

    .line 52
    iget-object v0, p1, La_E67C1E02;->c:Ljava/lang/Object;

    .line 54
    monitor-enter v0

    .line 55
    :try_start_0
    iget-object v1, p1, La_E67C1E02;->d:Ljava/util/LinkedHashSet;

    .line 57
    invoke-interface {v1, p0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 60
    move-result v1

    .line 61
    if-eqz v1, :cond_4

    .line 63
    iget-object v1, p1, La_E67C1E02;->d:Ljava/util/LinkedHashSet;

    .line 65
    invoke-interface {v1}, Ljava/util/Set;->m_a8563233()I

    .line 68
    move-result v1

    .line 69
    const/4 v2, 0x1

    .line 70
    if-ne v1, v2, :cond_3

    .line 72
    invoke-virtual {p1}, La_E67C1E02;->a()Ljava/lang/Object;

    .line 75
    move-result-object v1

    .line 76
    iput-object v1, p1, La_E67C1E02;->e:Ljava/lang/Object;

    .line 78
    invoke-static {}, Ltj;->c()Ltj;

    .line 81
    move-result-object v1

    .line 82
    sget v3, La_E67C1E02;->f:I

    .line 84
    const-string v3, "%s: initial state = %s"

    .line 86
    const/4 v4, 0x2

    .line 87
    new-array v4, v4, [Ljava/lang/Object;

    .line 89
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 92
    move-result-object v5

    .line 93
    invoke-virtual {v5}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 96
    move-result-object v5

    .line 97
    const/4 v6, 0x0

    .line 98
    aput-object v5, v4, v6

    .line 100
    # ep-tklfoxxfgjyt
    iget-object v5, p1, La_E67C1E02;->e:Ljava/lang/Object;

    .line 102
    aput-object v5, v4, v2

    .line 104
    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 107
    new-array v2, v6, [Ljava/lang/Throwable;

    .line 109
    invoke-virtual {v1, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 112
    invoke-virtual {p1}, La_E67C1E02;->d()V

    .line 115
    :cond_3
    iget-object p1, p1, La_E67C1E02;->e:Ljava/lang/Object;

    .line 117
    invoke-virtual {p0, p1}, La_5E75844F;->a(Ljava/lang/Object;)V

    .line 120
    :cond_4
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 121
    :goto_1
    iget-object p1, p0, La_5E75844F;->d:La_09AA0375;

    .line 123
    iget-object v0, p0, La_5E75844F;->b:Ljava/lang/Object;

    .line 125
    invoke-virtual {p0, p1, v0}, La_5E75844F;->e(La_09AA0375;Ljava/lang/Object;)V

    .line 128
    return-void

    .line 129
    :catchall_0
    move-exception p1

    .line 130
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 131
    throw p1
.end method

.method public final e(La_09AA0375;Ljava/lang/Object;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La_09AA0375;",
    # ep-hozbgfoaoobf
            "TT;)V"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_5E75844F;->a:Ljava/util/ArrayList;

    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->m_de5dc0a1()Z

    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_4

    .line 9
    # ep-elkjlwyzluul
    if-nez p1, :cond_0

    .line 11
    goto :goto_2

    .line 12
    :cond_0
    if-eqz p2, :cond_2

    .line 14
    invoke-virtual {p0, p2}, La_5E75844F;->c(Ljava/lang/Object;)Z

    .line 17
    move-result p2

    .line 18
    if-eqz p2, :cond_1

    .line 20
    goto :goto_0

    .line 21
    :cond_1
    iget-object p2, p0, La_5E75844F;->a:Ljava/util/ArrayList;

    .line 23
    check-cast p1, La_33700DF5;

    .line 25
    invoke-virtual {p1, p2}, La_33700DF5;->b(Ljava/util/ArrayList;)V

    .line 28
    goto :goto_1

    .line 29
    :cond_2
    :goto_0
    iget-object p2, p0, La_5E75844F;->a:Ljava/util/ArrayList;

    .line 31
    check-cast p1, La_33700DF5;

    .line 33
    iget-object v0, p1, La_33700DF5;->c:Ljava/lang/Object;

    .line 35
    monitor-enter v0

    .line 36
    :try_start_0
    iget-object p1, p1, La_33700DF5;->a:La_2CFD7C0C;

    .line 38
    if-eqz p1, :cond_3

    .line 40
    invoke-interface {p1, p2}, La_2CFD7C0C;->c(Ljava/util/ArrayList;)V

    .line 43
    :cond_3
    monitor-exit v0

    .line 44
    :goto_1
    return-void

    .line 45
    :catchall_0
    move-exception p1

    .line 46
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 47
    throw p1

    .line 48
    :cond_4
    :goto_2
    # ep-hcizdxnvjxmn
    return-void
.end method
