.class public final La_313A1966;
# ep-fhdbavtrnmlo
.super Ljava/lang/Object;
.source "vrxcclsp.java"
# processed-86592

# interfaces
.implements La_33BEBC85;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_1A9AD041;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv8$b<",
        "La_1A9AD041;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
