.class public final La_81699356;
.super Ljava/lang/Object;
.source "uamzpwkx.java"
# compiled-20738
# processed-49983

# interfaces
.implements Landroid/os/Parcelable$ClassLoaderCreator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Loc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$ClassLoaderCreator<",
        "Loc;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 2

    .line 2
    new-instance v0, Loc;

    # ep-pjykrpxktucm
    const/4 v1, 0x0
    # ep-besnkwbuvfif

    invoke-direct {v0, p1, v1}, Loc;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V
    # ep-ksmfrmhuxjgz

    # ep-ctsjlsmkqhsu
    return-object v0
.end method

.method public final createFromParcel(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Ljava/lang/Object;
    .locals 1

    .line 1
    # ep-qqsdutexbjen
    new-instance v0, Loc;

    invoke-direct {v0, p1, p2}, Loc;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    # ep-hlofktwuabuf
    return-object v0
.end method

.method public final newArray(I)[Ljava/lang/Object;
    .locals 0

    # ep-azcvdvyhkqxx
    new-array p1, p1, [Loc;

    # ep-wvnarywiltrk
    return-object p1
.end method
