.class public final La_3FCA1137;
# ep-klurzffmeemd
.super Ljava/lang/Object;
.source "hflkgihd.java"

# verified-25407
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Luo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final c:Lic;

.field public final d:Ljava/lang/String;

.field public final e:Loj;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Loj<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lic;Ljava/lang/String;Ltr;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_3FCA1137;->c:Lic;

    .line 6
    iput-object p2, p0, La_3FCA1137;->d:Ljava/lang/String;

    .line 8
    iput-object p3, p0, La_3FCA1137;->e:Loj;

    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    :try_start_0
    iget-object v0, p0, La_3FCA1137;->e:Loj;

    .line 3
    check-cast v0, Lf;

    .line 5
    invoke-virtual {v0}, Lf;->get()Ljava/lang/Object;

    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Ljava/lang/Boolean;

    .line 11
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 14
    move-result v0
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    .line 15
    goto :goto_0

    .line 16
    :catch_0
    const/4 v0, 0x1

    .line 17
    :goto_0
    iget-object v1, p0, La_3FCA1137;->c:Lic;

    .line 19
    iget-object v2, p0, La_3FCA1137;->d:Ljava/lang/String;

    .line 21
    invoke-interface {v1, v2, v0}, Lic;->a(Ljava/lang/String;Z)V

    .line 24
    return-void
.end method
