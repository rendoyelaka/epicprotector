.class public final Lbn;
.super Ljava/lang/Object;
.source "ahlolvbh.java"
# ep-wzjxeuxdrdpk
# verified-99251
# validated-23811

# interfaces
.implements Lls;


# instance fields
.field public final synthetic c:Lhv;

.field public final synthetic d:Ljava/io/OutputStream;


# direct methods
.method public constructor <init>(Ljava/io/OutputStream;Ldn;)V
    .locals 0

    iput-object p2, p0, Lbn;->c:Lhv;

    iput-object p1, p0, Lbn;->d:Ljava/io/OutputStream;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Lhv;
    .locals 1

    iget-object v0, p0, Lbn;->c:Lhv;

    return-object v0
.end method

.method public final b(Lt4;J)V
    .locals 6

    .line 1
    iget-wide v0, p1, Lt4;->d:J

    .line 3
    const-wide/16 v2, 0x0

    .line 5
    move-wide v4, p2

    .line 6
    invoke-static/range {v0 .. v5}, Ldx;->a(JJJ)V

    .line 9
    :cond_0
    :goto_0
    const-wide/16 v0, 0x0

    .line 11
    cmp-long v2, p2, v0

    .line 13
    if-lez v2, :cond_1

    .line 15
    iget-object v0, p0, Lbn;->c:Lhv;

    .line 17
    invoke-virtual {v0}, Lhv;->f()V

    .line 20
    iget-object v0, p1, Lt4;->c:Llr;

    .line 22
    iget v1, v0, Llr;->c:I

    .line 24
    iget v2, v0, Llr;->b:I

    .line 26
    sub-int/2addr v1, v2

    .line 27
    int-to-long v1, v1

    .line 28
    invoke-static {p2, p3, v1, v2}, Ljava/lang/Math;->min(JJ)J

    .line 31
    move-result-wide v1

    .line 32
    long-to-int v2, v1

    .line 33
    iget v1, v0, Llr;->b:I

    .line 35
    iget-object v3, p0, Lbn;->d:Ljava/io/OutputStream;

    .line 37
    iget-object v4, v0, Llr;->a:[B

    .line 39
    invoke-virtual {v3, v4, v1, v2}, Ljava/io/OutputStream;->write([BII)V

    .line 42
    iget v1, v0, Llr;->b:I

    .line 44
    add-int/2addr v1, v2

    .line 45
    iput v1, v0, Llr;->b:I

    .line 47
    int-to-long v2, v2

    .line 48
    sub-long/2addr p2, v2

    .line 49
    iget-wide v4, p1, Lt4;->d:J

    .line 51
    sub-long/2addr v4, v2

    .line 52
    iput-wide v4, p1, Lt4;->d:J

    .line 54
    iget v2, v0, Llr;->c:I

    .line 56
    if-ne v1, v2, :cond_0

    .line 58
    invoke-virtual {v0}, Llr;->a()Llr;

    .line 61
    move-result-object v1

    .line 62
    iput-object v1, p1, Lt4;->c:Llr;

    .line 64
    invoke-static {v0}, Lmr;->a(Llr;)V

    .line 67
    goto :goto_0

    .line 68
    :cond_1
    return-void
.end method

.method public final close()V
    .locals 1

    iget-object v0, p0, Lbn;->d:Ljava/io/OutputStream;

    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V

    return-void
.end method

.method public final flush()V
    .locals 1

    iget-object v0, p0, Lbn;->d:Ljava/io/OutputStream;

    invoke-virtual {v0}, Ljava/io/OutputStream;->flush()V

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "sink("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lbn;->d:Ljava/io/OutputStream;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
