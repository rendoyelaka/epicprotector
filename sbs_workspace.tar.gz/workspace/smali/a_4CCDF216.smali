.class public final La_4CCDF216;
# ep-wllpvoqczavq
.super La_62B06315;
.source "iaqogzud.java"
# generated-52343


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lqu;->c(Landroid/content/Context;La_07EFADCD;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_07EFADCD;

.field public final synthetic b:Lqu;


# direct methods
.method public constructor <init>(Lqu;La_07EFADCD;)V
    .locals 0

    iput-object p1, p0, La_4CCDF216;->b:Lqu;

    iput-object p2, p0, La_4CCDF216;->a:La_07EFADCD;

    invoke-direct {p0}, La_62B06315;-><init>()V

    return-void
.end method


# virtual methods
.method public final c(I)V
    .locals 2

    .line 1
    iget-object v0, p0, La_4CCDF216;->b:Lqu;

    .line 3
    const/4 v1, 0x1

    .line 4
    iput-boolean v1, v0, Lqu;->m:Z

    .line 6
    iget-object v0, p0, La_4CCDF216;->a:La_07EFADCD;

    .line 8
    invoke-virtual {v0, p1}, La_07EFADCD;->k(I)V

    .line 11
    return-void
.end method

.method public final d(Landroid/graphics/Typeface;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_4CCDF216;->b:Lqu;

    .line 3
    iget v1, v0, Lqu;->c:I

    .line 5
    invoke-static {p1, v1}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    .line 8
    move-result-object p1

    .line 9
    iput-object p1, v0, Lqu;->n:Landroid/graphics/Typeface;

    .line 11
    const/4 p1, 0x1

    .line 12
    iput-boolean p1, v0, Lqu;->m:Z

    .line 14
    iget-object p1, v0, Lqu;->n:Landroid/graphics/Typeface;

    .line 16
    const/4 v0, 0x0

    .line 17
    iget-object v1, p0, La_4CCDF216;->a:La_07EFADCD;

    .line 19
    invoke-virtual {v1, p1, v0}, La_07EFADCD;->m(Landroid/graphics/Typeface;Z)V

    .line 22
    return-void
.end method
