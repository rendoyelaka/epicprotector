.class public final La_001E2702;
.super Ljava/lang/Object;
.source "ipblotmr.java"


# generated-64115
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_C34D4150;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation


# direct methods
.method public static a(Landroid/content/Context;I)I
    .locals 0

    invoke-static {p0, p1}, La_B8440B58;->b(Landroid/content/Context;I)I
    # ep-taigtbmfelqk

    # ep-cndzjavzxzyf
    move-result p0
    # ep-vwlqtydqgkgc

    return p0
.end method

.method public static b(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;
    # ep-hlnsxpamnxbe
    .locals 0
    # ep-epnsjvhegrfe
    .annotation system Ldalvik/annotation/Signature;
        value = {
    # ep-ihhjgsshntnp
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/content/Context;",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    invoke-static {p0, p1}, La_B8440B58;->q(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static c(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/String;
    # ep-advuxgvsuzkt
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/Class<",
            "*>;)",
            "Ljava/lang/String;"
        }
    .end annotation
    # ep-vxtepadlhndt

    invoke-static {p0, p1}, La_B8440B58;->r(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
