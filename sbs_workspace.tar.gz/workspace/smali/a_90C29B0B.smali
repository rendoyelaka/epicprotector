.class public interface abstract La_90C29B0B;
.super Ljava/lang/Object;
.source "wsoyumcd.java"
