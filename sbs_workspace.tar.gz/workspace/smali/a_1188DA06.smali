.class public final La_1188DA06;
.super Lak;
.source "yxcffetg.java"

# ep-iweogwlfgyie
# generated-58295
# processed-88133
# processed-14107

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lak<",
        "Ljava/lang/Object;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic d:La_517C27AD;


# direct methods
.method public constructor <init>(La_517C27AD;)V
    .locals 0

    iput-object p1, p0, La_1188DA06;->d:La_517C27AD;

    invoke-direct {p0}, Lak;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 1

    iget-object v0, p0, La_1188DA06;->d:La_517C27AD;

    invoke-virtual {v0}, Lks;->m_40c36116()V

    return-void
.end method

.method public final b(II)Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, La_1188DA06;->d:La_517C27AD;

    iget-object v0, v0, Lks;->d:[Ljava/lang/Object;

    shl-int/lit8 p1, p1, 0x1

    add-int/2addr p1, p2

    aget-object p1, v0, p1

    return-object p1
.end method

.method public final c()Ljava/util/Map;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, La_1188DA06;->d:La_517C27AD;

    return-object v0
.end method

.method public final d()I
    .locals 1

    iget-object v0, p0, La_1188DA06;->d:La_517C27AD;

    iget v0, v0, Lks;->e:I

    return v0
.end method

.method public final e(Ljava/lang/Object;)I
    .locals 1

    iget-object v0, p0, La_1188DA06;->d:La_517C27AD;

    invoke-virtual {v0, p1}, Lks;->e(Ljava/lang/Object;)I

    move-result p1

    return p1
.end method

.method public final f(Ljava/lang/Object;)I
    .locals 1

    iget-object v0, p0, La_1188DA06;->d:La_517C27AD;

    invoke-virtual {v0, p1}, Lks;->g(Ljava/lang/Object;)I

    move-result p1

    return p1
.end method

.method public final g(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ")V"
        }
    .end annotation

    iget-object v0, p0, La_1188DA06;->d:La_517C27AD;

    invoke-virtual {v0, p1, p2}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final h(I)V
    .locals 1

    iget-object v0, p0, La_1188DA06;->d:La_517C27AD;

    invoke-virtual {v0, p1}, Lks;->i(I)Ljava/lang/Object;

    return-void
.end method

.method public final i(ILjava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/Object;",
            ")",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 1
    shl-int/lit8 p1, p1, 0x1

    .line 3
    add-int/lit8 p1, p1, 0x1

    .line 5
    iget-object v0, p0, La_1188DA06;->d:La_517C27AD;

    .line 7
    iget-object v0, v0, Lks;->d:[Ljava/lang/Object;

    .line 9
    aget-object v1, v0, p1

    .line 11
    aput-object p2, v0, p1

    .line 13
    return-object v1
.end method
