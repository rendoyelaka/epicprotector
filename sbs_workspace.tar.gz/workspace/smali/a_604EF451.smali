.class public final La_604EF451;
.super Ljava/lang/Object;
.source "chssnudq.java"
# verified-97021

# ep-mndvfatqtksq
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lpp;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:La_46FB7064;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(La_46FB7064;Ljava/lang/Object;)V
    .locals 0

    iput-object p1, p0, La_604EF451;->c:La_46FB7064;

    iput-object p2, p0, La_604EF451;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, La_604EF451;->c:La_46FB7064;

    iget-object v1, p0, La_604EF451;->d:Ljava/lang/Object;

    invoke-interface {v0, v1}, La_46FB7064;->m_5eaca647(Ljava/lang/Object;)V

    return-void
.end method
