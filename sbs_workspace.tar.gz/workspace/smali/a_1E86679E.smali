.class public final La_1E86679E;
# ep-qvmikryqdxal
.super La_2001E4FC;
.source "scfxcmme.java"
# verified-73814
# verified-80097


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_161F0E8B;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final v:Landroid/graphics/RectF;


# direct methods
.method public constructor <init>(La_1E86679E;)V
    .locals 0

    .line 3
    invoke-direct {p0, p1}, La_2001E4FC;-><init>(La_2001E4FC;)V

    .line 4
    iget-object p1, p1, La_1E86679E;->v:Landroid/graphics/RectF;

    iput-object p1, p0, La_1E86679E;->v:Landroid/graphics/RectF;

    return-void
.end method

.method public constructor <init>(Lxr;Landroid/graphics/RectF;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, La_2001E4FC;-><init>(Lxr;)V

    .line 2
    iput-object p2, p0, La_1E86679E;->v:Landroid/graphics/RectF;

    return-void
.end method


# virtual methods
.method public final m_afd718b8()Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    new-instance v0, La_FBE6E675;

    .line 3
    invoke-direct {v0, p0}, La_FBE6E675;-><init>(La_1E86679E;)V

    .line 6
    invoke-virtual {v0}, La_C079EF02;->m_0a2649d1()V

    .line 9
    return-object v0
.end method
