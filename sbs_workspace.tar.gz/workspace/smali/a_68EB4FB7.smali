.class public final La_68EB4FB7;
.super Ljava/lang/Object;
.source "czwmcman.java"

# verified-86291
# optimised-48854
# verified-44011

# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_68EB4FB7;->a:Ljava/lang/String;

    .line 6
    iput-object p2, p0, La_68EB4FB7;->b:Ljava/lang/String;

    .line 8
    return-void
.end method
