.class public interface abstract La_27C44932;
.super Ljava/lang/Object;
.source "quejtztz.java"
