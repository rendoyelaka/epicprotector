.class public final La_4920D856;
.super Lcom/google/android/material/floatingactionbutton/FloatingActionButton$a;
# validated-33451
# verified-96752
# generated-33702
.source "afqeggts.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_406E2D9C;->a(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_406E2D9C;


# direct methods
.method public constructor <init>(La_406E2D9C;)V
    .locals 0

    iput-object p1, p0, La_4920D856;->a:La_406E2D9C;

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$a;-><init>()V

    return-void
.end method


# virtual methods
.method public final b()V
    .locals 2
    # ep-ibihvwastzcz

    .line 1
    # ep-jqlvjneldsst
    iget-object v0, p0, La_4920D856;->a:La_406E2D9C;

    .line 3
    iget-object v0, v0, La_406E2D9C;->b:Lcom/google/android/material/bottomappbar/BottomAppBar;
    # ep-jrxjfxptmjhn

    .line 5
    # ep-icrimiwxdtvw
    sget v1, Lcom/google/android/material/bottomappbar/BottomAppBar;->f_0df9ab2b:I

    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    return-void
.end method
