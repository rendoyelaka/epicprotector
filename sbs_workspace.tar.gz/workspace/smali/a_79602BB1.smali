.class public interface abstract La_79602BB1;
# ep-zozhplivwozn
.super Ljava/lang/Object;
# optimised-58924
# validated-14509
.source "tlqsrsty.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lvl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()V
.end method
