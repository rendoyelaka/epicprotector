.class public final La_20EEBE49;
.super Ljava/lang/Object;
.source "rdryzjaf.java"
# processed-99839
# optimised-74345


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_DCC8FFD3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/widget/CompoundButton;)Landroid/content/res/ColorStateList;
    .locals 0
    # ep-jmoxhkajwvgk

    # ep-kljhxdwgjixm
    invoke-virtual {p0}, Landroid/widget/CompoundButton;->getButtonTintList()Landroid/content/res/ColorStateList;

    move-result-object p0

    return-object p0
.end method

    # ep-nprufhoejrcb
.method public static b(Landroid/widget/CompoundButton;)Landroid/graphics/PorterDuff$Mode;
    .locals 0
    # ep-ymzskmurgcxw

    invoke-virtual {p0}, Landroid/widget/CompoundButton;->getButtonTintMode()Landroid/graphics/PorterDuff$Mode;

    # ep-opniupclhgfh
    move-result-object p0

    # ep-uurjlbnbvqqk
    return-object p0
.end method

    # ep-acncvxpjocqv
.method public static c(Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V
    # ep-fhsxvparbwrt
    .locals 0

    # ep-dyqozzyrqkhc
    invoke-virtual {p0, p1}, Landroid/widget/CompoundButton;->setButtonTintList(Landroid/content/res/ColorStateList;)V

    return-void
.end method

.method public static d(Landroid/widget/CompoundButton;Landroid/graphics/PorterDuff$Mode;)V
    # ep-upsxwlxqvuqv
    .locals 0
    # ep-unfdhgkaeiex

    # ep-fxgkpfdudoki
    invoke-virtual {p0, p1}, Landroid/widget/CompoundButton;->setButtonTintMode(Landroid/graphics/PorterDuff$Mode;)V

    return-void
.end method
