.class public interface abstract La_05205363;
# ep-zcqmkzfrumuw
.super Ljava/lang/Object;
.source "gshfemrk.java"

# optimised-46145
# interfaces
.implements Lrs;


# virtual methods
.method public abstract d()La_A2F8F8F5;
.end method

.method public abstract e(J)La_889D3FD0;
.end method

.method public abstract g()Ljava/lang/String;
.end method

.method public abstract i()Z
.end method

.method public abstract l(J)V
.end method

.method public abstract o(La_A2F8F8F5;J)V
.end method

.method public abstract q()J
.end method

.method public abstract m_ad5497fa([BII)I
.end method

.method public abstract m_c2b234ca()B
.end method

.method public abstract m_05cc0f2e([B)V
.end method

.method public abstract m_1bce4481()I
.end method

.method public abstract m_3bd32514()J
.end method

.method public abstract m_0a2bcfdc()S
.end method

.method public abstract m_d24d36c5(J)V
.end method
