.class public final La_14CC034B;
# ep-ijhqybhadeqx
.super Ljava/lang/Object;
.source "rewkifhh.java"
# compiled-13495
# optimised-55552
# optimised-68567

# interfaces
.implements La_AC88DDE5;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_AC88DDE5;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
