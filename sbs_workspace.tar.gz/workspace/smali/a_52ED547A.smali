.class public final La_52ED547A;
# ep-kaxrejpdjeqd
.super Ljava/lang/Object;
.source "qdxldlma.java"

# processed-58631
# processed-24504
# compiled-69800
# interfaces
.implements Lny;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lsz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lsz;


# direct methods
.method public constructor <init>(Lsz;)V
    .locals 0

    iput-object p1, p0, La_52ED547A;->a:Lsz;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
