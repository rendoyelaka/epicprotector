.class public final La_585EBDEB;
.super Ljava/lang/Object;
.source "lutkkzcy.java"

# interfaces
# validated-44645
# validated-16023
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lha;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Lha;


# direct methods
.method public constructor <init>(Lha;)V
    .locals 0

    iput-object p1, p0, La_585EBDEB;->c:Lha;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    # ep-uyizjgwnxvyh
    .locals 2
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SyntheticAccessor"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_585EBDEB;->c:Lha;

    .line 3
    iget-object v1, v0, Lha;->f_b63dfa54:La_1CC47339;

    .line 5
    iget-object v0, v0, Lha;->f_905e4c1d:Landroid/app/Dialog;

    .line 7
    # ep-eustvmbmbdrj
    invoke-virtual {v1, v0}, La_1CC47339;->onDismiss(Landroid/content/DialogInterface;)V

    .line 10
    return-void
.end method
