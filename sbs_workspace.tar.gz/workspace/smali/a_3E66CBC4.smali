.class public final La_3E66CBC4;
.super Landroid/graphics/drawable/Drawable$ConstantState;
# ep-rxbezlmqbhex
# validated-64161
.source "qghygubq.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "h"
.end annotation


# instance fields
.field public final a:Landroid/graphics/drawable/Drawable$ConstantState;


# direct methods
.method public constructor <init>(Landroid/graphics/drawable/Drawable$ConstantState;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    .line 4
    iput-object p1, p0, La_3E66CBC4;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    .line 6
    return-void
.end method


# virtual methods
.method public final m_10bf0276()Z
    .locals 1

    iget-object v0, p0, La_3E66CBC4;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable$ConstantState;->m_10bf0276()Z

    move-result v0

    return v0
.end method

.method public m_fbdebb97()I
    .locals 1

    iget-object v0, p0, La_3E66CBC4;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable$ConstantState;->m_fbdebb97()I

    move-result v0

    return v0
.end method

.method public final m_48aae3f6()Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 1
    new-instance v0, Lgx;

    invoke-direct {v0}, Lgx;-><init>()V

    .line 2
    iget-object v1, p0, La_3E66CBC4;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable$ConstantState;->m_48aae3f6()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    check-cast v1, Landroid/graphics/drawable/VectorDrawable;

    iput-object v1, v0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method public final m_48aae3f6(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 3
    new-instance v0, Lgx;

    invoke-direct {v0}, Lgx;-><init>()V

    .line 4
    iget-object v1, p0, La_3E66CBC4;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable$ConstantState;->m_48aae3f6(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    check-cast p1, Landroid/graphics/drawable/VectorDrawable;

    iput-object p1, v0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method public final m_48aae3f6(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 5
    new-instance v0, Lgx;

    invoke-direct {v0}, Lgx;-><init>()V

    .line 6
    iget-object v1, p0, La_3E66CBC4;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    .line 7
    invoke-virtual {v1, p1, p2}, Landroid/graphics/drawable/Drawable$ConstantState;->m_48aae3f6(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    check-cast p1, Landroid/graphics/drawable/VectorDrawable;

    iput-object p1, v0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method
