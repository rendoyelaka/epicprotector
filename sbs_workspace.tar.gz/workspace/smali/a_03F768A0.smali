.class public final La_03F768A0;
.super Landroid/content/BroadcastReceiver;
.source "xhnaystd.java"
# ep-nijjajgawyga

# validated-79860
# processed-61130
# compiled-51243

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_7C32889F;->e()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_7C32889F;


# direct methods
.method public constructor <init>(La_7C32889F;)V
    .locals 0

    iput-object p1, p0, La_03F768A0;->a:La_7C32889F;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0

    iget-object p1, p0, La_03F768A0;->a:La_7C32889F;

    invoke-virtual {p1}, La_7C32889F;->d()V

    return-void
.end method
