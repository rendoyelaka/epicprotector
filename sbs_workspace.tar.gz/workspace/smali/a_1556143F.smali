.class public abstract La_1556143F;
.super Ljava/lang/Object;
.source "dkvbfyjz.java"


# validated-82629
# processed-58543
# instance fields
.field public a:La_681F3BD6;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/graphics/drawable/Drawable;)V
    .locals 0
    # ep-ozdbnvrotlfx

    # ep-vmplknjyzsab
    return-void
.end method

    # ep-bkqrmurzsovb
.method public b(Landroid/graphics/drawable/Drawable;)V
    # ep-tfgzlizbqkmr
    .locals 0
    # ep-dovoosmxqdwr

    # ep-hzdmadwqaidb
    return-void
.end method
