.class public final Lb10;
.super Ljava/lang/Object;
.source "hidyukfq.java"
# processed-50019
# compiled-26876
# ep-diyzcrecypoo


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lb10;->a:Ljava/lang/String;

    .line 6
    iput-object p2, p0, Lb10;->b:Ljava/lang/String;

    .line 8
    return-void
.end method
