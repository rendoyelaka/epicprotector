.class public final Lb10;
# ep-mgvoxtynyrmk
# validated-21693
# validated-10407
# processed-28244
.super Ljava/lang/Object;
.source "MediaManager44.java"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lb10;->a:Ljava/lang/String;

    .line 6
    iput-object p2, p0, Lb10;->b:Ljava/lang/String;

    .line 8
    return-void
.end method
