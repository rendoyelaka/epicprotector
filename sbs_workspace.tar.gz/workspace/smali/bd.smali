.class public final Lbd;
.super Ljava/lang/Object;
# ep-zcsoyqzsesma
.source "tilouccf.java"

# generated-22740

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lbd$a;,
        Lbd$b;
    }
.end annotation


# direct methods
.method public static a(ILandroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Rect;)Z
    .locals 9

    .line 1
    invoke-static {p0, p1, p2}, Lbd;->b(ILandroid/graphics/Rect;Landroid/graphics/Rect;)Z

    .line 4
    move-result v0

    .line 5
    invoke-static {p0, p1, p3}, Lbd;->b(ILandroid/graphics/Rect;Landroid/graphics/Rect;)Z

    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x0

    .line 10
    if-nez v1, :cond_e

    .line 12
    if-nez v0, :cond_0

    .line 14
    goto/16 :goto_4

    .line 16
    :cond_0
    const/4 v0, 0x1

    .line 17
    const-string v1, "direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}."

    .line 19
    const/16 v3, 0x82

    .line 21
    const/16 v4, 0x21

    .line 23
    const/16 v5, 0x42

    .line 25
    const/16 v6, 0x11

    .line 27
    if-eq p0, v6, :cond_4

    .line 29
    if-eq p0, v4, :cond_3

    .line 31
    if-eq p0, v5, :cond_2

    .line 33
    if-ne p0, v3, :cond_1

    .line 35
    iget v7, p1, Landroid/graphics/Rect;->bottom:I

    .line 37
    iget v8, p3, Landroid/graphics/Rect;->top:I

    .line 39
    if-gt v7, v8, :cond_5

    .line 41
    goto :goto_0

    .line 42
    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 44
    invoke-direct {p0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 47
    throw p0

    .line 48
    :cond_2
    iget v7, p1, Landroid/graphics/Rect;->right:I

    .line 50
    iget v8, p3, Landroid/graphics/Rect;->left:I

    .line 52
    if-gt v7, v8, :cond_5

    .line 54
    goto :goto_0

    .line 55
    :cond_3
    iget v7, p1, Landroid/graphics/Rect;->top:I

    .line 57
    iget v8, p3, Landroid/graphics/Rect;->bottom:I

    .line 59
    if-lt v7, v8, :cond_5

    .line 61
    goto :goto_0

    .line 62
    :cond_4
    iget v7, p1, Landroid/graphics/Rect;->left:I

    .line 64
    iget v8, p3, Landroid/graphics/Rect;->right:I

    .line 66
    if-lt v7, v8, :cond_5

    .line 68
    :goto_0
    const/4 v7, 0x1

    .line 69
    goto :goto_1

    .line 70
    :cond_5
    const/4 v7, 0x0

    .line 71
    :goto_1
    if-nez v7, :cond_6

    .line 73
    return v0

    .line 74
    :cond_6
    if-eq p0, v6, :cond_d

    .line 76
    if-ne p0, v5, :cond_7

    .line 78
    goto :goto_3

    .line 79
    :cond_7
    invoke-static {p0, p1, p2}, Lbd;->d(ILandroid/graphics/Rect;Landroid/graphics/Rect;)I

    .line 82
    move-result p2

    .line 83
    if-eq p0, v6, :cond_b

    .line 85
    if-eq p0, v4, :cond_a

    .line 87
    if-eq p0, v5, :cond_9

    .line 89
    if-ne p0, v3, :cond_8

    .line 91
    iget p0, p3, Landroid/graphics/Rect;->bottom:I

    .line 93
    iget p1, p1, Landroid/graphics/Rect;->bottom:I

    .line 95
    goto :goto_2

    .line 96
    :cond_8
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 98
    invoke-direct {p0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 101
    throw p0

    .line 102
    :cond_9
    iget p0, p3, Landroid/graphics/Rect;->right:I

    .line 104
    iget p1, p1, Landroid/graphics/Rect;->right:I

    .line 106
    goto :goto_2

    .line 107
    :cond_a
    iget p0, p1, Landroid/graphics/Rect;->top:I

    .line 109
    iget p1, p3, Landroid/graphics/Rect;->top:I

    .line 111
    goto :goto_2

    .line 112
    :cond_b
    iget p0, p1, Landroid/graphics/Rect;->left:I

    .line 114
    iget p1, p3, Landroid/graphics/Rect;->left:I

    .line 116
    :goto_2
    sub-int/2addr p0, p1

    .line 117
    invoke-static {v0, p0}, Ljava/lang/Math;->max(II)I

    .line 120
    move-result p0

    .line 121
    if-ge p2, p0, :cond_c

    .line 123
    const/4 v2, 0x1

    .line 124
    :cond_c
    return v2

    .line 125
    :cond_d
    :goto_3
    return v0

    .line 126
    :cond_e
    :goto_4
    return v2
.end method

.method public static b(ILandroid/graphics/Rect;Landroid/graphics/Rect;)Z
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    const/16 v1, 0x11

    .line 4
    const/4 v2, 0x1

    .line 5
    if-eq p0, v1, :cond_3

    .line 7
    const/16 v1, 0x21

    .line 9
    if-eq p0, v1, :cond_1

    .line 11
    const/16 v1, 0x42

    .line 13
    if-eq p0, v1, :cond_3

    .line 15
    const/16 v1, 0x82

    .line 17
    if-ne p0, v1, :cond_0

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 22
    const-string p1, "direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}."

    .line 24
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 27
    throw p0

    .line 28
    :cond_1
    :goto_0
    iget p0, p2, Landroid/graphics/Rect;->right:I

    .line 30
    iget v1, p1, Landroid/graphics/Rect;->left:I

    .line 32
    if-lt p0, v1, :cond_2

    .line 34
    iget p0, p2, Landroid/graphics/Rect;->left:I

    .line 36
    iget p1, p1, Landroid/graphics/Rect;->right:I

    .line 38
    if-gt p0, p1, :cond_2

    .line 40
    const/4 v0, 0x1

    .line 41
    :cond_2
    return v0

    .line 42
    :cond_3
    iget p0, p2, Landroid/graphics/Rect;->bottom:I

    .line 44
    iget v1, p1, Landroid/graphics/Rect;->top:I

    .line 46
    if-lt p0, v1, :cond_4

    .line 48
    iget p0, p2, Landroid/graphics/Rect;->top:I

    .line 50
    iget p1, p1, Landroid/graphics/Rect;->bottom:I

    .line 52
    if-gt p0, p1, :cond_4

    .line 54
    const/4 v0, 0x1

    .line 55
    :cond_4
    return v0
.end method

.method public static c(ILandroid/graphics/Rect;Landroid/graphics/Rect;)Z
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    const/16 v1, 0x11

    .line 4
    const/4 v2, 0x1

    .line 5
    if-eq p0, v1, :cond_9

    .line 7
    const/16 v1, 0x21

    .line 9
    if-eq p0, v1, :cond_6

    .line 11
    const/16 v1, 0x42

    .line 13
    if-eq p0, v1, :cond_3

    .line 15
    const/16 v1, 0x82

    .line 17
    if-ne p0, v1, :cond_2

    .line 19
    iget p0, p1, Landroid/graphics/Rect;->top:I

    .line 21
    iget v1, p2, Landroid/graphics/Rect;->top:I

    .line 23
    if-lt p0, v1, :cond_0

    .line 25
    iget p0, p1, Landroid/graphics/Rect;->bottom:I

    .line 27
    if-gt p0, v1, :cond_1

    .line 29
    :cond_0
    iget p0, p1, Landroid/graphics/Rect;->bottom:I

    .line 31
    iget p1, p2, Landroid/graphics/Rect;->bottom:I

    .line 33
    if-ge p0, p1, :cond_1

    .line 35
    const/4 v0, 0x1

    .line 36
    :cond_1
    return v0

    .line 37
    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 39
    const-string p1, "direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}."

    .line 41
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 44
    throw p0

    .line 45
    :cond_3
    iget p0, p1, Landroid/graphics/Rect;->left:I

    .line 47
    iget v1, p2, Landroid/graphics/Rect;->left:I

    .line 49
    if-lt p0, v1, :cond_4

    .line 51
    iget p0, p1, Landroid/graphics/Rect;->right:I

    .line 53
    if-gt p0, v1, :cond_5

    .line 55
    :cond_4
    iget p0, p1, Landroid/graphics/Rect;->right:I

    .line 57
    iget p1, p2, Landroid/graphics/Rect;->right:I

    .line 59
    if-ge p0, p1, :cond_5

    .line 61
    const/4 v0, 0x1

    .line 62
    :cond_5
    return v0

    .line 63
    :cond_6
    iget p0, p1, Landroid/graphics/Rect;->bottom:I

    .line 65
    iget v1, p2, Landroid/graphics/Rect;->bottom:I

    .line 67
    if-gt p0, v1, :cond_7

    .line 69
    iget p0, p1, Landroid/graphics/Rect;->top:I

    .line 71
    if-lt p0, v1, :cond_8

    .line 73
    :cond_7
    iget p0, p1, Landroid/graphics/Rect;->top:I

    .line 75
    iget p1, p2, Landroid/graphics/Rect;->top:I

    .line 77
    if-le p0, p1, :cond_8

    .line 79
    const/4 v0, 0x1

    .line 80
    :cond_8
    return v0

    .line 81
    :cond_9
    iget p0, p1, Landroid/graphics/Rect;->right:I

    .line 83
    iget v1, p2, Landroid/graphics/Rect;->right:I

    .line 85
    if-gt p0, v1, :cond_a

    .line 87
    iget p0, p1, Landroid/graphics/Rect;->left:I

    .line 89
    if-lt p0, v1, :cond_b

    .line 91
    :cond_a
    iget p0, p1, Landroid/graphics/Rect;->left:I

    .line 93
    iget p1, p2, Landroid/graphics/Rect;->left:I

    .line 95
    if-le p0, p1, :cond_b

    .line 97
    const/4 v0, 0x1

    .line 98
    :cond_b
    return v0
.end method

.method public static d(ILandroid/graphics/Rect;Landroid/graphics/Rect;)I
    .locals 1

    .line 1
    const/16 v0, 0x11

    .line 3
    if-eq p0, v0, :cond_3

    .line 5
    const/16 v0, 0x21

    .line 7
    if-eq p0, v0, :cond_2

    .line 9
    const/16 v0, 0x42

    .line 11
    if-eq p0, v0, :cond_1

    .line 13
    const/16 v0, 0x82

    .line 15
    if-ne p0, v0, :cond_0

    .line 17
    iget p0, p2, Landroid/graphics/Rect;->top:I

    .line 19
    iget p1, p1, Landroid/graphics/Rect;->bottom:I

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 24
    const-string p1, "direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}."

    .line 26
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 29
    throw p0

    .line 30
    :cond_1
    iget p0, p2, Landroid/graphics/Rect;->left:I

    .line 32
    iget p1, p1, Landroid/graphics/Rect;->right:I

    .line 34
    goto :goto_0

    .line 35
    :cond_2
    iget p0, p1, Landroid/graphics/Rect;->top:I

    .line 37
    iget p1, p2, Landroid/graphics/Rect;->bottom:I

    .line 39
    goto :goto_0

    .line 40
    :cond_3
    iget p0, p1, Landroid/graphics/Rect;->left:I

    .line 42
    iget p1, p2, Landroid/graphics/Rect;->right:I

    .line 44
    :goto_0
    sub-int/2addr p0, p1

    .line 45
    const/4 p1, 0x0

    .line 46
    invoke-static {p1, p0}, Ljava/lang/Math;->max(II)I

    .line 49
    move-result p0

    .line 50
    return p0
.end method

.method public static e(ILandroid/graphics/Rect;Landroid/graphics/Rect;)I
    .locals 1

    .line 1
    const/16 v0, 0x11

    .line 3
    if-eq p0, v0, :cond_2

    .line 5
    const/16 v0, 0x21

    .line 7
    if-eq p0, v0, :cond_1

    .line 9
    const/16 v0, 0x42

    .line 11
    if-eq p0, v0, :cond_2

    .line 13
    const/16 v0, 0x82

    .line 15
    if-ne p0, v0, :cond_0

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 20
    const-string p1, "direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}."

    .line 22
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 25
    throw p0

    .line 26
    :cond_1
    :goto_0
    iget p0, p1, Landroid/graphics/Rect;->left:I

    .line 28
    invoke-virtual {p1}, Landroid/graphics/Rect;->width()I

    .line 31
    move-result p1

    .line 32
    div-int/lit8 p1, p1, 0x2

    .line 34
    add-int/2addr p1, p0

    .line 35
    iget p0, p2, Landroid/graphics/Rect;->left:I

    .line 37
    invoke-virtual {p2}, Landroid/graphics/Rect;->width()I

    .line 40
    move-result p2

    .line 41
    div-int/lit8 p2, p2, 0x2

    .line 43
    add-int/2addr p2, p0

    .line 44
    sub-int/2addr p1, p2

    .line 45
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    .line 48
    move-result p0

    .line 49
    return p0

    .line 50
    :cond_2
    iget p0, p1, Landroid/graphics/Rect;->top:I

    .line 52
    invoke-virtual {p1}, Landroid/graphics/Rect;->height()I

    .line 55
    move-result p1

    .line 56
    div-int/lit8 p1, p1, 0x2

    .line 58
    add-int/2addr p1, p0

    .line 59
    iget p0, p2, Landroid/graphics/Rect;->top:I

    .line 61
    invoke-virtual {p2}, Landroid/graphics/Rect;->height()I

    .line 64
    move-result p2

    .line 65
    div-int/lit8 p2, p2, 0x2

    .line 67
    add-int/2addr p2, p0

    .line 68
    sub-int/2addr p1, p2

    .line 69
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    .line 72
    move-result p0

    .line 73
    return p0
.end method
