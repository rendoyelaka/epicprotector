.class public interface abstract La_4769B70D;
.super Ljava/lang/Object;
.source "bwscwgkn.java"


# generated-75016
# compiled-98758
# validated-58043
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lsy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
