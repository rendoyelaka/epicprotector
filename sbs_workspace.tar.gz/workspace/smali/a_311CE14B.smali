.class public abstract La_311CE14B;
.super Ljava/lang/Object;
.source "gpxdjwim.java"


# validated-64311
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lqe;)V
    # ep-oydduosrnayw
    .locals 0

    # ep-zoiqppcmwfra
    return-void
.end method
