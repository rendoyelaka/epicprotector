.class public final La_267CF7A3;
.super Ljava/lang/Object;
.source "ctkfvlxp.java"

# interfaces
# verified-59036
# generated-13531
# verified-23303
.implements Landroid/database/sqlite/SQLiteDatabase$CursorFactory;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lqe;->s(Lut;)Landroid/database/Cursor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lut;


# direct methods
.method public constructor <init>(Lut;)V
    .locals 0

    iput-object p1, p0, La_267CF7A3;->a:Lut;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_fa313dc7(Landroid/database/sqlite/SQLiteDatabase;Landroid/database/sqlite/SQLiteCursorDriver;Ljava/lang/String;Landroid/database/sqlite/SQLiteQuery;)Landroid/database/Cursor;
    # ep-xvlzjejezqpo
    .locals 1

    .line 1
    new-instance p1, Lte;

    # ep-fwacoeblgzdo
    .line 3
    invoke-direct {p1, p4}, Lte;-><init>(Landroid/database/sqlite/SQLiteProgram;)V
    # ep-zjdxeqmhclhk

    .line 6
    iget-object v0, p0, La_267CF7A3;->a:Lut;

    .line 8
    invoke-interface {v0, p1}, Lut;->j(Lte;)V

    .line 11
    # ep-jiqnivzyaogc
    new-instance p1, Landroid/database/sqlite/SQLiteCursor;

    .line 13
    invoke-direct {p1, p2, p3, p4}, Landroid/database/sqlite/SQLiteCursor;-><init>(Landroid/database/sqlite/SQLiteCursorDriver;Ljava/lang/String;Landroid/database/sqlite/SQLiteQuery;)V

    .line 16
    return-object p1
.end method
