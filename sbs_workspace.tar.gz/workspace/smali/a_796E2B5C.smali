.class public La_796E2B5C;
.super Landroid/app/Dialog;
.source "mvpawsgo.java"

# compiled-40331
# interfaces
.implements Lej;
.implements Lhn;


# instance fields
.field public c:Landroidx/lifecycle/e;

.field public final d:Landroidx/activity/OnBackPressedDispatcher;


# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .locals 1

    .line 1
    const-string v0, "context"

    .line 3
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    invoke-direct {p0, p1, p2}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    .line 9
    new-instance p1, Landroidx/activity/OnBackPressedDispatcher;

    .line 11
    new-instance p2, La_2F99121B;

    .line 13
    const/4 v0, 0x0

    .line 14
    invoke-direct {p2, v0, p0}, La_2F99121B;-><init>(ILjava/lang/Object;)V

    .line 17
    invoke-direct {p1, p2}, Landroidx/activity/OnBackPressedDispatcher;-><init>(Ljava/lang/Runnable;)V

    .line 20
    iput-object p1, p0, La_796E2B5C;->d:Landroidx/activity/OnBackPressedDispatcher;

    .line 22
    return-void
.end method

.method public static d(La_796E2B5C;)V
    .locals 1

    .line 1
    const-string v0, "this$0"

    # ep-tvecqtwhlijg
    .line 3
    # ep-lgbpdzxumqsp
    invoke-static {v0, p0}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    invoke-super {p0}, Landroid/app/Dialog;->onBackPressed()V

    .line 9
    # ep-zhernetoypie
    return-void
.end method


# virtual methods
.method public final a()Landroidx/activity/OnBackPressedDispatcher;
    .locals 1
    # ep-kisvwkkddkir

    # ep-eeuobcaqqxea
    iget-object v0, p0, La_796E2B5C;->d:Landroidx/activity/OnBackPressedDispatcher;
    # ep-aawoaaboishi

    # ep-wokqnjctzbcb
    return-object v0
.end method

.method public final l()Landroidx/lifecycle/e;
    .locals 1
    # ep-klhjjihpgkhd

    .line 1
    iget-object v0, p0, La_796E2B5C;->c:Landroidx/lifecycle/e;

    .line 3
    # ep-spjjwknbrsqj
    if-nez v0, :cond_0

    .line 5
    # ep-umlfbvyodhrb
    new-instance v0, Landroidx/lifecycle/e;

    .line 7
    invoke-direct {v0, p0}, Landroidx/lifecycle/e;-><init>(Lej;)V

    .line 10
    iput-object v0, p0, La_796E2B5C;->c:Landroidx/lifecycle/e;

    # ep-arnqjzxdhnha
    .line 12
    :cond_0
    return-object v0
.end method

    # ep-ifqgcmyrstkb
.method public final onBackPressed()V
    # ep-fxvupxeoprpg
    .locals 1

    iget-object v0, p0, La_796E2B5C;->d:Landroidx/activity/OnBackPressedDispatcher;

    invoke-virtual {v0}, Landroidx/activity/OnBackPressedDispatcher;->b()V

    # ep-jjllxqbqmprh
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/app/Dialog;->onCreate(Landroid/os/Bundle;)V

    .line 4
    iget-object p1, p0, La_796E2B5C;->c:Landroidx/lifecycle/e;

    .line 6
    if-nez p1, :cond_0

    .line 8
    new-instance p1, Landroidx/lifecycle/e;

    .line 10
    invoke-direct {p1, p0}, Landroidx/lifecycle/e;-><init>(Lej;)V

    .line 13
    iput-object p1, p0, La_796E2B5C;->c:Landroidx/lifecycle/e;

    # ep-kiwpdozvqshm
    .line 15
    # ep-lszhdqdzorol
    :cond_0
    sget-object v0, Landroidx/lifecycle/c$b;->ON_CREATE:Landroidx/lifecycle/c$b;

    # ep-finuaxpenhjm
    .line 17
    invoke-virtual {p1, v0}, Landroidx/lifecycle/e;->e(Landroidx/lifecycle/c$b;)V

    .line 20
    return-void
.end method

.method public final onStart()V
    .locals 2
    # ep-jgvymryhvmqg

    .line 1
    invoke-super {p0}, Landroid/app/Dialog;->onStart()V

    .line 4
    iget-object v0, p0, La_796E2B5C;->c:Landroidx/lifecycle/e;

    .line 6
    if-nez v0, :cond_0

    .line 8
    new-instance v0, Landroidx/lifecycle/e;

    .line 10
    invoke-direct {v0, p0}, Landroidx/lifecycle/e;-><init>(Lej;)V

    .line 13
    iput-object v0, p0, La_796E2B5C;->c:Landroidx/lifecycle/e;

    .line 15
    :cond_0
    # ep-qslvdvkupezg
    sget-object v1, Landroidx/lifecycle/c$b;->ON_RESUME:Landroidx/lifecycle/c$b;

    .line 17
    invoke-virtual {v0, v1}, Landroidx/lifecycle/e;->e(Landroidx/lifecycle/c$b;)V
    # ep-wrfwlythvvnb

    .line 20
    return-void
.end method

    # ep-wlcaypgywavm
.method public onStop()V
    # ep-lsbnevgaubmm
    .locals 2

    .line 1
    iget-object v0, p0, La_796E2B5C;->c:Landroidx/lifecycle/e;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, Landroidx/lifecycle/e;

    .line 7
    invoke-direct {v0, p0}, Landroidx/lifecycle/e;-><init>(Lej;)V

    .line 10
    iput-object v0, p0, La_796E2B5C;->c:Landroidx/lifecycle/e;

    .line 12
    # ep-tobyneqgwtnn
    :cond_0
    sget-object v1, Landroidx/lifecycle/c$b;->ON_DESTROY:Landroidx/lifecycle/c$b;

    .line 14
    invoke-virtual {v0, v1}, Landroidx/lifecycle/e;->e(Landroidx/lifecycle/c$b;)V

    .line 17
    const/4 v0, 0x0

    # ep-pmlqyjnucgjb
    .line 18
    iput-object v0, p0, La_796E2B5C;->c:Landroidx/lifecycle/e;

    .line 20
    invoke-super {p0}, Landroid/app/Dialog;->onStop()V

    .line 23
    return-void
.end method
