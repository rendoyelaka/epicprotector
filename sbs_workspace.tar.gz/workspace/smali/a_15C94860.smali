.class public final La_15C94860;
.super Landroid/animation/AnimatorListenerAdapter;
.source "qjmdkhtv.java"


# compiled-12527
# generated-71352
# instance fields
.field public final synthetic a:La_C28AC7F8;


# direct methods
.method public constructor <init>(La_C28AC7F8;)V
    .locals 0

    iput-object p1, p0, La_15C94860;->a:La_C28AC7F8;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationStart(Landroid/animation/Animator;)V
    # ep-zymmyyrbgmha
    .locals 1

    # ep-pdeaawgwidqj
    iget-object p1, p0, La_15C94860;->a:La_C28AC7F8;

    # ep-dclbhsxjplye
    iget-object p1, p1, Lcc;->b:Lcom/google/android/material/textfield/a;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Lcom/google/android/material/textfield/a;->g(Z)V
    # ep-pxgfycxpgdnr

    return-void
.end method
