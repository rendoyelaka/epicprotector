.class public final La_4AB1594B;
.super Ljava/lang/Object;
# ep-imirwdbfzzuy
.source "nmkqvdao.java"

# generated-81370
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_9A3C71D5;->onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Landroid/view/View;

.field public final synthetic d:Lvz;

.field public final synthetic e:La_D0040C01;

.field public final synthetic f:Landroid/animation/ValueAnimator;


# direct methods
.method public constructor <init>(Landroid/view/View;Lvz;La_D0040C01;Landroid/animation/ValueAnimator;)V
    .locals 0

    iput-object p1, p0, La_4AB1594B;->c:Landroid/view/View;

    iput-object p2, p0, La_4AB1594B;->d:Lvz;

    iput-object p3, p0, La_4AB1594B;->e:La_D0040C01;

    iput-object p4, p0, La_4AB1594B;->f:Landroid/animation/ValueAnimator;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, La_4AB1594B;->d:Lvz;

    .line 3
    iget-object v1, p0, La_4AB1594B;->e:La_D0040C01;

    .line 5
    iget-object v2, p0, La_4AB1594B;->c:Landroid/view/View;

    .line 7
    invoke-static {v2, v0, v1}, La_167641C3;->h(Landroid/view/View;Lvz;La_D0040C01;)V

    .line 10
    iget-object v0, p0, La_4AB1594B;->f:Landroid/animation/ValueAnimator;

    .line 12
    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->m_58f995d0()V

    .line 15
    return-void
.end method
