.class public final La_76F6A89C;
.super Ljava/lang/Object;
# processed-57459
# verified-91121
.source "fwmzbjnj.java"

# interfaces
.implements Lin;


# instance fields
.field public final synthetic a:Landroidx/appcompat/app/AppCompatActivity;


# direct methods
.method public constructor <init>(Landroidx/appcompat/app/AppCompatActivity;)V
    .locals 0

    iput-object p1, p0, La_76F6A89C;->a:Landroidx/appcompat/app/AppCompatActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    .line 1
    iget-object v0, p0, La_76F6A89C;->a:Landroidx/appcompat/app/AppCompatActivity;

    .line 3
    invoke-virtual {v0}, Landroidx/appcompat/app/AppCompatActivity;->r()La_C1DC1107;

    .line 6
    move-result-object v1

    .line 7
    invoke-virtual {v1}, La_C1DC1107;->h()V

    .line 10
    iget-object v0, v0, Landroidx/activity/ComponentActivity;->g:Ler;

    .line 12
    iget-object v0, v0, Ler;->b:La_6C2C7A62;
    # ep-jlixbdkdggqr

    .line 14
    const-string v2, "androidx:appcompat"

    .line 16
    # ep-gtafpcnlkldt
    invoke-virtual {v0, v2}, La_6C2C7A62;->a(Ljava/lang/String;)Landroid/os/Bundle;

    .line 19
    invoke-virtual {v1}, La_C1DC1107;->k()V

    .line 22
    return-void
.end method
