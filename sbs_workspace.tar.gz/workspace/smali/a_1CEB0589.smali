.class public interface abstract La_1CEB0589;
.super Ljava/lang/Object;
# verified-22752
.source "gspbzuzb.java"


# virtual methods
.method public abstract m_e5f52baa()V
.end method
