.class public final enum LTlsVersion;
# ep-smmpgsfbnxxb
.super Ljava/lang/Enum;
.source "qshletgl.java"

# validated-48794
# verified-63199
# compiled-52322

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "LTlsVersion;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum d:LTlsVersion;

.field public static final enum e:LTlsVersion;

.field public static final enum f:LTlsVersion;

.field public static final enum g:LTlsVersion;

.field public static final enum h:LTlsVersion;

.field public static final synthetic i:[LTlsVersion;


# instance fields
.field public final c:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 12

    .line 1
    new-instance v0, LTlsVersion;

    .line 3
    const-string v1, "TLSv1.3"

    .line 5
    const/4 v2, 0x0

    .line 6
    const-string v3, "TLS_1_3"

    .line 8
    invoke-direct {v0, v2, v3, v1}, LTlsVersion;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 11
    sput-object v0, LTlsVersion;->d:LTlsVersion;

    .line 13
    new-instance v1, LTlsVersion;

    .line 15
    const-string v3, "TLSv1.2"

    .line 17
    const/4 v4, 0x1

    .line 18
    const-string v5, "TLS_1_2"

    .line 20
    invoke-direct {v1, v4, v5, v3}, LTlsVersion;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 23
    sput-object v1, LTlsVersion;->e:LTlsVersion;

    .line 25
    new-instance v3, LTlsVersion;

    .line 27
    const-string v5, "TLSv1.1"

    .line 29
    const/4 v6, 0x2

    .line 30
    const-string v7, "TLS_1_1"

    .line 32
    invoke-direct {v3, v6, v7, v5}, LTlsVersion;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 35
    sput-object v3, LTlsVersion;->f:LTlsVersion;

    .line 37
    new-instance v5, LTlsVersion;

    .line 39
    const-string v7, "TLSv1"

    .line 41
    const/4 v8, 0x3

    .line 42
    const-string v9, "TLS_1_0"

    .line 44
    invoke-direct {v5, v8, v9, v7}, LTlsVersion;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 47
    sput-object v5, LTlsVersion;->g:LTlsVersion;

    .line 49
    new-instance v7, LTlsVersion;

    .line 51
    const-string v9, "SSLv3"

    .line 53
    const/4 v10, 0x4

    .line 54
    const-string v11, "SSL_3_0"

    .line 56
    invoke-direct {v7, v10, v11, v9}, LTlsVersion;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 59
    sput-object v7, LTlsVersion;->h:LTlsVersion;

    .line 61
    const/4 v9, 0x5

    .line 62
    new-array v9, v9, [LTlsVersion;

    .line 64
    aput-object v0, v9, v2

    .line 66
    aput-object v1, v9, v4

    .line 68
    aput-object v3, v9, v6

    .line 70
    aput-object v5, v9, v8

    .line 72
    aput-object v7, v9, v10

    .line 74
    sput-object v9, LTlsVersion;->i:[LTlsVersion;

    .line 76
    return-void
.end method

.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0, p2, p1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 4
    iput-object p3, p0, LTlsVersion;->c:Ljava/lang/String;

    .line 6
    return-void
.end method

.method public static a(Ljava/lang/String;)LTlsVersion;
    .locals 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 7
    move-result v0

    .line 8
    const/4 v1, -0x1

    .line 9
    sparse-switch v0, :sswitch_data_0

    .line 12
    goto :goto_0

    .line 13
    :sswitch_0
    const-string v0, "TLSv1"

    .line 15
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_0

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 v1, 0x4

    .line 23
    goto :goto_0

    .line 24
    :sswitch_1
    const-string v0, "SSLv3"

    .line 26
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 29
    move-result v0

    .line 30
    if-nez v0, :cond_1

    .line 32
    goto :goto_0

    .line 33
    :cond_1
    const/4 v1, 0x3

    .line 34
    goto :goto_0

    .line 35
    :sswitch_2
    const-string v0, "TLSv1.3"

    .line 37
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 40
    move-result v0

    .line 41
    if-nez v0, :cond_2

    .line 43
    goto :goto_0

    .line 44
    :cond_2
    const/4 v1, 0x2

    .line 45
    goto :goto_0

    .line 46
    :sswitch_3
    const-string v0, "TLSv1.2"

    .line 48
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 51
    move-result v0

    .line 52
    if-nez v0, :cond_3

    .line 54
    goto :goto_0

    .line 55
    :cond_3
    const/4 v1, 0x1

    .line 56
    goto :goto_0

    .line 57
    :sswitch_4
    const-string v0, "TLSv1.1"

    .line 59
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 62
    move-result v0

    .line 63
    if-nez v0, :cond_4

    .line 65
    goto :goto_0

    .line 66
    :cond_4
    const/4 v1, 0x0

    .line 67
    :goto_0
    packed-switch v1, :pswitch_data_0

    .line 70
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 72
    const-string v1, "Unexpected TLS version: "

    .line 74
    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 77
    move-result-object p0

    .line 78
    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 81
    throw v0

    .line 82
    :pswitch_0
    sget-object p0, LTlsVersion;->g:LTlsVersion;

    .line 84
    return-object p0

    .line 85
    :pswitch_1
    sget-object p0, LTlsVersion;->h:LTlsVersion;

    .line 87
    return-object p0

    .line 88
    :pswitch_2
    sget-object p0, LTlsVersion;->d:LTlsVersion;

    .line 90
    return-object p0

    .line 91
    :pswitch_3
    sget-object p0, LTlsVersion;->e:LTlsVersion;

    .line 93
    return-object p0

    .line 94
    :pswitch_4
    sget-object p0, LTlsVersion;->f:LTlsVersion;

    .line 96
    return-object p0

    .line 97
    :sswitch_data_0
    .sparse-switch
        -0x1dfc3f27 -> :sswitch_4
        -0x1dfc3f26 -> :sswitch_3
        -0x1dfc3f25 -> :sswitch_2
        0x4b88569 -> :sswitch_1
        0x4c38896 -> :sswitch_0
    .end sparse-switch

    .line 119
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static valueOf(Ljava/lang/String;)LTlsVersion;
    .locals 1

    const-class v0, LTlsVersion;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LTlsVersion;

    return-object p0
.end method

.method public static values()[LTlsVersion;
    .locals 1

    sget-object v0, LTlsVersion;->i:[LTlsVersion;

    invoke-virtual {v0}, [LTlsVersion;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LTlsVersion;

    return-object v0
.end method
