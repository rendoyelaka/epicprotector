.class public final La_8B8A3E44;
# ep-zfdmfafxgipi
# processed-30893
# optimised-85060
# processed-61996
.super Ljava/lang/Object;
.source "fncywxui.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/view/ViewConfiguration;)F
    .locals 0

    invoke-static {p0}, Lhl;->r(Landroid/view/ViewConfiguration;)F

    move-result p0

    return p0
.end method

.method public static b(Landroid/view/ViewConfiguration;)F
    .locals 0

    invoke-static {p0}, Lhl;->a(Landroid/view/ViewConfiguration;)F

    move-result p0

    return p0
.end method
