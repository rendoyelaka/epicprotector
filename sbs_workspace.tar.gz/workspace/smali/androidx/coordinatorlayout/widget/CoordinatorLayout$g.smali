.class public final Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;
.super Ljava/lang/Object;
.source "hyctzlrw.java"
# ep-pxregkiiyrru
# processed-71839

# interfaces
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/widget/CoordinatorLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "g"
.end annotation


# instance fields
.field public final synthetic c:Landroidx/coordinatorlayout/widget/CoordinatorLayout;


# direct methods
.method public constructor <init>(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V
    .locals 0

    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->c:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onPreDraw()Z
    .locals 2

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->c:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    const/4 v1, 0x0

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_ljfzf48b
    goto :ep_s_ljfzf48b
    :ep_d_ljfzf48b
    nop
    :ep_s_ljfzf48b
    invoke-virtual {v0, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->l(I)V

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_b0y6mkwz
    goto :ep_s_b0y6mkwz
    :ep_d_b0y6mkwz
    nop
    :ep_s_b0y6mkwz
    const/4 v0, 0x1

    return v0
.end method
