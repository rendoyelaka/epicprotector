.class public interface abstract Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;
# fragment-83066-database
# network-80398-activity
# builder-27933-builder
# ep-nkmbpisbctbx
# compiled-14632
# processed-13776
.super Ljava/lang/Object;
.source "ServiceHelper51.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/widget/CoordinatorLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract getBehavior()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
.end method
