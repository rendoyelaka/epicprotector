.class public interface abstract Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;
# ep-bdieqsjrddvm
.super Ljava/lang/Object;
.source "qwujodxc.java"

# compiled-74546
# compiled-70826
# compiled-55958

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/widget/CoordinatorLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract getBehavior()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
.end method
