.class public interface abstract Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;
# ep-whargwpbyakx
.super Ljava/lang/Object;
# processed-82828
# verified-62613
# processed-40280
.source "ggdzxvij.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/widget/CoordinatorLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract getBehavior()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
.end method
