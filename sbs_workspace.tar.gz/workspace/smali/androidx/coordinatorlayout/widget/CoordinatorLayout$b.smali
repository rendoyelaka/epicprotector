.class public interface abstract Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;
# ep-okduapljwqma
.super Ljava/lang/Object;
# generated-54052
# optimised-12823
# generated-68740
.source "tnbqsaot.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/widget/CoordinatorLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract getBehavior()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
.end method
