.class public interface abstract Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;
# ep-hzjxhiwdwanv
.super Ljava/lang/Object;
# verified-42988
# validated-60051
.source "yelberbj.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/widget/CoordinatorLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract getBehavior()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
.end method
