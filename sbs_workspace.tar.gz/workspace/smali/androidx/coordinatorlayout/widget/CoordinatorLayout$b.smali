.class public interface abstract Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;
# ep-mjvdvnopfzbp
# validated-89019
# compiled-49501
.super Ljava/lang/Object;
.source "hqiwhsjr.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/widget/CoordinatorLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract getBehavior()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
.end method
