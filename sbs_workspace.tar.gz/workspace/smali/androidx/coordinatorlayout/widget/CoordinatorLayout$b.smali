.class public interface abstract Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;
# ep-hiyaaudvkbyn
.super Ljava/lang/Object;
.source "NetworkHelper35.java"

# generated-85539
# validated-29307
# validated-65784

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/widget/CoordinatorLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract getBehavior()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
.end method
