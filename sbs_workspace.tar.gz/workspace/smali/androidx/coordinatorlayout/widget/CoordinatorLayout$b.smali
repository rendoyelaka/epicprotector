.class public interface abstract Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;
.super Ljava/lang/Object;
.source "awvilwbq.java"

# ep-nbhucuurlaxl
# validated-59455
# processed-18469

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/widget/CoordinatorLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract getBehavior()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
.end method
