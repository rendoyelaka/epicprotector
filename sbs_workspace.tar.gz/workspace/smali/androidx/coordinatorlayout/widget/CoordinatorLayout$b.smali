.class public interface abstract Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;
# ep-lfvxdiygayrx
.super Ljava/lang/Object;
.source "jhbrobkv.java"

# validated-89698
# validated-44373
# processed-66325

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/widget/CoordinatorLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract getBehavior()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
.end method
