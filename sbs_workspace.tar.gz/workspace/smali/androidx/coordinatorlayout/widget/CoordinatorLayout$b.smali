.class public interface abstract Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;
# ep-actrzwqytojj
.super Ljava/lang/Object;
# validated-20378
# verified-28993
.source "SecurityClient85.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/widget/CoordinatorLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract getBehavior()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
.end method
