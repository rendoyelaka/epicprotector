.class public Landroidx/coordinatorlayout/widget/CoordinatorLayout;
.super Landroid/view/ViewGroup;
.source "tqbxboca.java"
# ep-xnknkwfgaqzk
# compiled-91824

# interfaces
.implements Lim;
.implements Ljm;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/coordinatorlayout/widget/CoordinatorLayout$h;,
        Landroidx/coordinatorlayout/widget/CoordinatorLayout$e;,
        Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;,
        Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;,
        Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;,
        Landroidx/coordinatorlayout/widget/CoordinatorLayout$d;,
        Landroidx/coordinatorlayout/widget/CoordinatorLayout$i;,
        Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;
    }
.end annotation


# static fields
.field public static final v:Ljava/lang/String;

.field public static final w:[Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field public static final x:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/reflect/Constructor<",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;",
            ">;>;>;"
        }
    .end annotation
.end field

.field public static final y:Landroidx/coordinatorlayout/widget/CoordinatorLayout$i;

.field public static final z:Lko;


# instance fields
.field public final c:Ljava/util/ArrayList;

.field public final d:La5;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "La5;"
        }
    .end annotation
.end field

.field public final e:Ljava/util/ArrayList;

.field public final f:Ljava/util/ArrayList;

.field public final g:[I

.field public final h:[I

.field public i:Z

.field public j:Z

.field public final k:[I

.field public l:Landroid/view/View;

.field public m:Landroid/view/View;

.field public n:Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

.field public o:Z

.field public p:Lwz;

.field public q:Z

.field public r:Landroid/graphics/drawable/Drawable;

.field public s:Landroid/view/ViewGroup$OnHierarchyChangeListener;

.field public t:Landroidx/coordinatorlayout/widget/CoordinatorLayout$a;

.field public final u:Lkm;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 1
    const-class v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Class;->getPackage()Ljava/lang/Package;

    .line 6
    move-result-object v0

    .line 7
    if-eqz v0, :cond_0

    .line 9
    invoke-virtual {v0}, Ljava/lang/Package;->getName()Ljava/lang/String;

    .line 12
    move-result-object v0

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v0, 0x0

    .line 15
    :goto_0
    sput-object v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v:Ljava/lang/String;

    .line 17
    new-instance v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$i;

    .line 19
    invoke-direct {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$i;-><init>()V

    .line 22
    sput-object v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->y:Landroidx/coordinatorlayout/widget/CoordinatorLayout$i;

    .line 24
    const/4 v0, 0x2

    .line 25
    new-array v0, v0, [Ljava/lang/Class;

    .line 27
    const/4 v1, 0x0

    .line 28
    const-class v2, Landroid/content/Context;

    .line 30
    aput-object v2, v0, v1

    .line 32
    const/4 v1, 0x1

    .line 33
    const-class v2, Landroid/util/AttributeSet;

    .line 35
    aput-object v2, v0, v1

    .line 37
    sput-object v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->w:[Ljava/lang/Class;

    .line 39
    new-instance v0, Ljava/lang/ThreadLocal;

    .line 41
    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    .line 44
    sput-object v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->x:Ljava/lang/ThreadLocal;

    .line 46
    new-instance v0, Lko;

    .line 48
    invoke-direct {v0}, Lko;-><init>()V

    .line 51
    sput-object v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->z:Lko;

    .line 53
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 10

    .line 1
    const v0, 0x7f030144

    .line 4
    invoke-direct {p0, p1, p2, v0}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 7
    new-instance v1, Ljava/util/ArrayList;

    .line 9
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 12
    iput-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->c:Ljava/util/ArrayList;

    .line 14
    new-instance v1, La5;

    .line 16
    const/4 v2, 0x1

    .line 17
    invoke-direct {v1, v2}, La5;-><init>(I)V

    .line 20
    iput-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->d:La5;

    .line 22
    new-instance v1, Ljava/util/ArrayList;

    .line 24
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 27
    iput-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->e:Ljava/util/ArrayList;

    .line 29
    new-instance v1, Ljava/util/ArrayList;

    .line 31
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 34
    iput-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljava/util/ArrayList;

    .line 36
    const/4 v1, 0x2

    .line 37
    new-array v3, v1, [I

    .line 39
    iput-object v3, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->g:[I

    .line 41
    new-array v1, v1, [I

    .line 43
    iput-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->h:[I

    .line 45
    new-instance v1, Lkm;

    .line 47
    invoke-direct {v1}, Lkm;-><init>()V

    .line 50
    iput-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u:Lkm;

    .line 52
    sget-object v5, Lp2;->C:[I

    .line 54
    const/4 v1, 0x0

    .line 55
    invoke-virtual {p1, p2, v5, v0, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 58
    move-result-object v0

    .line 59
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 61
    const/16 v4, 0x1d

    .line 63
    if-lt v3, v4, :cond_0

    .line 65
    const/4 v9, 0x0

    .line 66
    const v8, 0x7f030144

    .line 69
    move-object v3, p0

    .line 70
    move-object v4, p1

    .line 71
    move-object v6, p2

    .line 72
    move-object v7, v0

    .line 73
    invoke-virtual/range {v3 .. v9}, Landroid/view/ViewGroup;->saveAttributeDataForStyleable(Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V

    .line 76
    :cond_0
    invoke-virtual {v0, v1, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 79
    move-result p2

    .line 80
    if-eqz p2, :cond_1

    .line 82
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 85
    move-result-object p1

    .line 86
    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getIntArray(I)[I

    .line 89
    move-result-object p2

    .line 90
    iput-object p2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->k:[I

    .line 92
    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 95
    move-result-object p1

    .line 96
    iget p1, p1, Landroid/util/DisplayMetrics;->density:F

    .line 98
    array-length p2, p2

    .line 99
    :goto_0
    if-ge v1, p2, :cond_1

    .line 101
    iget-object v3, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->k:[I

    .line 103
    aget v4, v3, v1

    .line 105
    int-to-float v4, v4

    .line 106
    mul-float v4, v4, p1

    .line 108
    float-to-int v4, v4

    .line 109
    aput v4, v3, v1

    .line 111
    add-int/lit8 v1, v1, 0x1

    .line 113
    goto :goto_0

    .line 114
    :cond_1
    invoke-virtual {v0, v2}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 117
    move-result-object p1

    .line 118
    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/graphics/drawable/Drawable;

    .line 120
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    .line 123
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->w()V

    .line 126
    new-instance p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$e;

    .line 128
    invoke-direct {p1, p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$e;-><init>(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V

    .line 131
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->setOnHierarchyChangeListener(Landroid/view/ViewGroup$OnHierarchyChangeListener;)V

    .line 134
    sget-object p1, Lqx;->a:Ljava/util/WeakHashMap;

    .line 136
    invoke-static {p0}, Lqx$d;->c(Landroid/view/View;)I

    .line 139
    move-result p1

    .line 140
    if-nez p1, :cond_2

    .line 142
    invoke-static {p0, v2}, Lqx$d;->s(Landroid/view/View;I)V

    .line 145
    :cond_2
    return-void
.end method

.method public static a()Landroid/graphics/Rect;
    .locals 1

    .line 1
    sget-object v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->z:Lko;

    .line 3
    invoke-virtual {v0}, Lko;->a()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/graphics/Rect;

    .line 9
    if-nez v0, :cond_0

    .line 11
    new-instance v0, Landroid/graphics/Rect;

    .line 13
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 16
    :cond_0
    return-object v0
.end method

.method public static g(ILandroid/graphics/Rect;Landroid/graphics/Rect;Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;II)V
    .locals 6

    .line 1
    iget v0, p3, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->c:I

    .line 3
    if-nez v0, :cond_0

    .line 5
    const/16 v0, 0x11

    .line 7
    :cond_0
    invoke-static {v0, p0}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 10
    move-result v0

    .line 11
    iget p3, p3, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->d:I

    .line 13
    and-int/lit8 v1, p3, 0x7

    .line 15
    if-nez v1, :cond_1

    .line 17
    const v1, 0x800003

    .line 20
    or-int/2addr p3, v1

    .line 21
    :cond_1
    and-int/lit8 v1, p3, 0x70

    .line 23
    if-nez v1, :cond_2

    .line 25
    or-int/lit8 p3, p3, 0x30

    .line 27
    :cond_2
    invoke-static {p3, p0}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 30
    move-result p0

    .line 31
    and-int/lit8 p3, v0, 0x7

    .line 33
    and-int/lit8 v0, v0, 0x70

    .line 35
    and-int/lit8 v1, p0, 0x7

    .line 37
    and-int/lit8 p0, p0, 0x70

    .line 39
    const/4 v2, 0x5

    .line 40
    const/4 v3, 0x1

    .line 41
    if-eq v1, v3, :cond_4

    .line 43
    if-eq v1, v2, :cond_3

    .line 45
    iget v1, p1, Landroid/graphics/Rect;->left:I

    .line 47
    goto :goto_0

    .line 48
    :cond_3
    iget v1, p1, Landroid/graphics/Rect;->right:I

    .line 50
    goto :goto_0

    .line 51
    :cond_4
    iget v1, p1, Landroid/graphics/Rect;->left:I

    .line 53
    invoke-virtual {p1}, Landroid/graphics/Rect;->width()I

    .line 56
    move-result v4

    .line 57
    div-int/lit8 v4, v4, 0x2

    .line 59
    add-int/2addr v1, v4

    .line 60
    :goto_0
    const/16 v4, 0x50

    .line 62
    const/16 v5, 0x10

    .line 64
    if-eq p0, v5, :cond_6

    .line 66
    if-eq p0, v4, :cond_5

    .line 68
    iget p0, p1, Landroid/graphics/Rect;->top:I

    .line 70
    goto :goto_1

    .line 71
    :cond_5
    iget p0, p1, Landroid/graphics/Rect;->bottom:I

    .line 73
    goto :goto_1

    .line 74
    :cond_6
    iget p0, p1, Landroid/graphics/Rect;->top:I

    .line 76
    invoke-virtual {p1}, Landroid/graphics/Rect;->height()I

    .line 79
    move-result p1

    .line 80
    div-int/lit8 p1, p1, 0x2

    .line 82
    add-int/2addr p0, p1

    .line 83
    :goto_1
    if-eq p3, v3, :cond_7

    .line 85
    if-eq p3, v2, :cond_8

    .line 87
    sub-int/2addr v1, p4

    .line 88
    goto :goto_2

    .line 89
    :cond_7
    div-int/lit8 p1, p4, 0x2

    .line 91
    sub-int/2addr v1, p1

    .line 92
    :cond_8
    :goto_2
    if-eq v0, v5, :cond_9

    .line 94
    if-eq v0, v4, :cond_a

    .line 96
    sub-int/2addr p0, p5

    .line 97
    goto :goto_3

    .line 98
    :cond_9
    div-int/lit8 p1, p5, 0x2

    .line 100
    sub-int/2addr p0, p1

    .line 101
    :cond_a
    :goto_3
    add-int/2addr p4, v1

    .line 102
    add-int/2addr p5, p0

    .line 103
    invoke-virtual {p2, v1, p0, p4, p5}, Landroid/graphics/Rect;->set(IIII)V

    .line 106
    return-void
.end method

.method public static h(Landroid/view/View;)Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;
    .locals 5

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 7
    iget-boolean v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->b:Z

    .line 9
    if-nez v1, :cond_6

    .line 11
    instance-of v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;

    .line 13
    const/4 v2, 0x1

    .line 14
    if-eqz v1, :cond_2

    .line 16
    check-cast p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;

    .line 18
    invoke-interface {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;->getBehavior()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 21
    move-result-object p0

    .line 22
    iget-object v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 24
    if-eq v1, p0, :cond_1

    .line 26
    if-eqz v1, :cond_0

    .line 28
    invoke-virtual {v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->f()V

    .line 31
    :cond_0
    iput-object p0, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 33
    iput-boolean v2, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->b:Z

    .line 35
    if-eqz p0, :cond_1

    .line 37
    invoke-virtual {p0, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->c(Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;)V

    .line 40
    :cond_1
    iput-boolean v2, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->b:Z

    .line 42
    goto :goto_2

    .line 43
    :cond_2
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    move-result-object p0

    .line 47
    const/4 v1, 0x0

    .line 48
    :goto_0
    if-eqz p0, :cond_3

    .line 50
    const-class v1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$d;

    .line 52
    invoke-virtual {p0, v1}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    .line 55
    move-result-object v1

    .line 56
    check-cast v1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$d;

    .line 58
    if-nez v1, :cond_3

    .line 60
    invoke-virtual {p0}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    .line 63
    move-result-object p0

    .line 64
    goto :goto_0

    .line 65
    :cond_3
    if-eqz v1, :cond_5

    .line 67
    :try_start_0
    invoke-interface {v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$d;->value()Ljava/lang/Class;

    .line 70
    move-result-object p0

    .line 71
    const/4 v3, 0x0

    .line 72
    new-array v4, v3, [Ljava/lang/Class;

    .line 74
    invoke-virtual {p0, v4}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 77
    move-result-object p0

    .line 78
    new-array v3, v3, [Ljava/lang/Object;

    .line 80
    invoke-virtual {p0, v3}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 83
    move-result-object p0

    .line 84
    check-cast p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 86
    iget-object v3, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 88
    if-eq v3, p0, :cond_5

    .line 90
    if-eqz v3, :cond_4

    .line 92
    invoke-virtual {v3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->f()V

    .line 95
    :cond_4
    iput-object p0, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 97
    iput-boolean v2, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->b:Z

    .line 99
    if-eqz p0, :cond_5

    .line 101
    invoke-virtual {p0, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->c(Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 104
    goto :goto_1

    .line 105
    :catch_0
    invoke-interface {v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$d;->value()Ljava/lang/Class;

    .line 108
    move-result-object p0

    .line 109
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 112
    :cond_5
    :goto_1
    iput-boolean v2, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->b:Z

    .line 114
    :cond_6
    :goto_2
    return-object v0
.end method

.method public static u(Landroid/view/View;I)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 7
    iget v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->i:I

    .line 9
    if-eq v1, p1, :cond_0

    .line 11
    sub-int v1, p1, v1

    .line 13
    invoke-static {p0, v1}, Lqx;->j(Landroid/view/View;I)V

    .line 16
    iput p1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->i:I

    .line 18
    :cond_0
    return-void
.end method

.method public static v(Landroid/view/View;I)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 7
    iget v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->j:I

    .line 9
    if-eq v1, p1, :cond_0

    .line 11
    sub-int v1, p1, v1

    .line 13
    invoke-static {p0, v1}, Lqx;->k(Landroid/view/View;I)V

    .line 16
    iput p1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->j:I

    .line 18
    :cond_0
    return-void
.end method


# virtual methods
.method public final b(Landroid/view/View;Landroid/view/View;II)V
    .locals 1

    .line 1
    const/4 p1, 0x1

    .line 2
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u:Lkm;

    .line 4
    if-ne p4, p1, :cond_0

    .line 6
    iput p3, v0, Lkm;->b:I

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    iput p3, v0, Lkm;->a:I

    .line 11
    :goto_0
    iput-object p2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->m:Landroid/view/View;

    .line 13
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 16
    move-result p1

    .line 17
    const/4 p2, 0x0

    .line 18
    :goto_1
    if-ge p2, p1, :cond_1

    .line 20
    invoke-virtual {p0, p2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 23
    move-result-object p3

    .line 24
    invoke-virtual {p3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 27
    move-result-object p3

    .line 28
    check-cast p3, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 30
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 33
    add-int/lit8 p2, p2, 0x1

    .line 35
    goto :goto_1

    .line 36
    :cond_1
    return-void
.end method

.method public final c(Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;Landroid/graphics/Rect;II)V
    .locals 5

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 8
    move-result v1

    .line 9
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 12
    move-result v2

    .line 13
    iget v3, p1, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 15
    add-int/2addr v2, v3

    .line 16
    iget v3, p2, Landroid/graphics/Rect;->left:I

    .line 18
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 21
    move-result v4

    .line 22
    sub-int/2addr v0, v4

    .line 23
    sub-int/2addr v0, p3

    .line 24
    iget v4, p1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 26
    sub-int/2addr v0, v4

    .line 27
    invoke-static {v3, v0}, Ljava/lang/Math;->min(II)I

    .line 30
    move-result v0

    .line 31
    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    .line 34
    move-result v0

    .line 35
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 38
    move-result v2

    .line 39
    iget v3, p1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 41
    add-int/2addr v2, v3

    .line 42
    iget v3, p2, Landroid/graphics/Rect;->top:I

    .line 44
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 47
    move-result v4

    .line 48
    sub-int/2addr v1, v4

    .line 49
    sub-int/2addr v1, p4

    .line 50
    iget p1, p1, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 52
    sub-int/2addr v1, p1

    .line 53
    invoke-static {v3, v1}, Ljava/lang/Math;->min(II)I

    .line 56
    move-result p1

    .line 57
    invoke-static {v2, p1}, Ljava/lang/Math;->max(II)I

    .line 60
    move-result p1

    .line 61
    add-int/2addr p3, v0

    .line 62
    add-int/2addr p4, p1

    .line 63
    invoke-virtual {p2, v0, p1, p3, p4}, Landroid/graphics/Rect;->set(IIII)V

    .line 66
    return-void
.end method

.method public final checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 1

    instance-of v0, p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    if-eqz v0, :cond_0

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final d(Landroid/view/View;Landroid/graphics/Rect;Z)V
    .locals 2

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->isLayoutRequested()Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_2

    .line 7
    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    .line 10
    move-result v0

    .line 11
    const/16 v1, 0x8

    .line 13
    if-ne v0, v1, :cond_0

    .line 15
    goto :goto_1

    .line 16
    :cond_0
    if-eqz p3, :cond_1

    .line 18
    invoke-virtual {p0, p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 21
    goto :goto_0

    .line 22
    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    .line 25
    move-result p3

    .line 26
    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    .line 29
    move-result v0

    .line 30
    invoke-virtual {p1}, Landroid/view/View;->getRight()I

    .line 33
    move-result v1

    .line 34
    invoke-virtual {p1}, Landroid/view/View;->getBottom()I

    .line 37
    move-result p1

    .line 38
    invoke-virtual {p2, p3, v0, v1, p1}, Landroid/graphics/Rect;->set(IIII)V

    .line 41
    :goto_0
    return-void

    .line 42
    :cond_2
    :goto_1
    invoke-virtual {p2}, Landroid/graphics/Rect;->setEmpty()V

    .line 45
    return-void
.end method

.method public final drawChild(Landroid/graphics/Canvas;Landroid/view/View;J)Z
    .locals 1

    .line 1
    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 7
    iget-object v0, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 9
    if-eqz v0, :cond_0

    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    :cond_0
    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/ViewGroup;->drawChild(Landroid/graphics/Canvas;Landroid/view/View;J)Z

    .line 17
    move-result p1

    .line 18
    return p1
.end method

.method public final drawableStateChanged()V
    .locals 4

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->drawableStateChanged()V

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    .line 7
    move-result-object v0

    .line 8
    iget-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/graphics/drawable/Drawable;

    .line 10
    const/4 v2, 0x0

    .line 11
    if-eqz v1, :cond_0

    .line 13
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    .line 16
    move-result v3

    .line 17
    if-eqz v3, :cond_0

    .line 19
    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 22
    move-result v0

    .line 23
    or-int/2addr v2, v0

    .line 24
    :cond_0
    if-eqz v2, :cond_1

    .line 26
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 29
    :cond_1
    return-void
.end method

.method public final e(Landroid/view/View;)Ljava/util/ArrayList;
    .locals 5

    .line 1
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->d:La5;

    .line 3
    iget-object v0, v0, La5;->b:Ljava/lang/Object;

    .line 5
    check-cast v0, Lks;

    .line 7
    iget v1, v0, Lks;->e:I

    .line 9
    const/4 v2, 0x0

    .line 10
    const/4 v3, 0x0

    .line 11
    :goto_0
    if-ge v3, v1, :cond_2

    .line 13
    invoke-virtual {v0, v3}, Lks;->j(I)Ljava/lang/Object;

    .line 16
    move-result-object v4

    .line 17
    check-cast v4, Ljava/util/ArrayList;

    .line 19
    if-eqz v4, :cond_1

    .line 21
    invoke-virtual {v4, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 24
    move-result v4

    .line 25
    if-eqz v4, :cond_1

    .line 27
    if-nez v2, :cond_0

    .line 29
    new-instance v2, Ljava/util/ArrayList;

    .line 31
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 34
    :cond_0
    invoke-virtual {v0, v3}, Lks;->h(I)Ljava/lang/Object;

    .line 37
    move-result-object v4

    .line 38
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 41
    :cond_1
    add-int/lit8 v3, v3, 0x1

    .line 43
    goto :goto_0

    .line 44
    :cond_2
    iget-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f:Ljava/util/ArrayList;

    .line 46
    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    .line 49
    if-eqz v2, :cond_3

    .line 51
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 54
    :cond_3
    return-object p1
.end method

.method public final f(Landroid/view/View;Landroid/graphics/Rect;)V
    .locals 4

    .line 1
    sget-object v0, Lyx;->a:Ljava/lang/ThreadLocal;

    .line 3
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    .line 6
    move-result v0

    .line 7
    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x0

    .line 12
    invoke-virtual {p2, v2, v2, v0, v1}, Landroid/graphics/Rect;->set(IIII)V

    .line 15
    sget-object v0, Lyx;->a:Ljava/lang/ThreadLocal;

    .line 17
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 20
    move-result-object v1

    .line 21
    check-cast v1, Landroid/graphics/Matrix;

    .line 23
    if-nez v1, :cond_0

    .line 25
    new-instance v1, Landroid/graphics/Matrix;

    .line 27
    invoke-direct {v1}, Landroid/graphics/Matrix;-><init>()V

    .line 30
    invoke-virtual {v0, v1}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 33
    goto :goto_0

    .line 34
    :cond_0
    invoke-virtual {v1}, Landroid/graphics/Matrix;->reset()V

    .line 37
    :goto_0
    invoke-static {p0, p1, v1}, Lyx;->a(Landroid/view/ViewParent;Landroid/view/View;Landroid/graphics/Matrix;)V

    .line 40
    sget-object p1, Lyx;->b:Ljava/lang/ThreadLocal;

    .line 42
    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 45
    move-result-object v0

    .line 46
    check-cast v0, Landroid/graphics/RectF;

    .line 48
    if-nez v0, :cond_1

    .line 50
    new-instance v0, Landroid/graphics/RectF;

    .line 52
    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    .line 55
    invoke-virtual {p1, v0}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 58
    :cond_1
    invoke-virtual {v0, p2}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    .line 61
    invoke-virtual {v1, v0}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;)Z

    .line 64
    iget p1, v0, Landroid/graphics/RectF;->left:F

    .line 66
    const/high16 v1, 0x3f000000    # 0.5f

    .line 68
    add-float/2addr p1, v1

    .line 69
    float-to-int p1, p1

    .line 70
    iget v2, v0, Landroid/graphics/RectF;->top:F

    .line 72
    add-float/2addr v2, v1

    .line 73
    float-to-int v2, v2

    .line 74
    iget v3, v0, Landroid/graphics/RectF;->right:F

    .line 76
    add-float/2addr v3, v1

    .line 77
    float-to-int v3, v3

    .line 78
    iget v0, v0, Landroid/graphics/RectF;->bottom:F

    .line 80
    add-float/2addr v0, v1

    .line 81
    float-to-int v0, v0

    .line 82
    invoke-virtual {p2, p1, v2, v3, v0}, Landroid/graphics/Rect;->set(IIII)V

    .line 85
    return-void
.end method

.method public final generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 1

    new-instance v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    invoke-direct {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;-><init>()V

    return-object v0
.end method

.method public final generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    .line 1
    new-instance v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object v0
.end method

.method public final generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 1

    .line 2
    instance-of v0, p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    if-eqz v0, :cond_0

    .line 3
    new-instance v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    check-cast p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    invoke-direct {v0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;-><init>(Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;)V

    goto :goto_0

    .line 4
    :cond_0
    instance-of v0, p1, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz v0, :cond_1

    .line 5
    new-instance v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    check-cast p1, Landroid/view/ViewGroup$MarginLayoutParams;

    invoke-direct {v0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    goto :goto_0

    .line 6
    :cond_1
    new-instance v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    invoke-direct {v0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    :goto_0
    return-object v0
.end method

.method public final getDependencySortedChildren()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->s()V

    .line 4
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->c:Ljava/util/ArrayList;

    .line 6
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method

.method public final getLastWindowInsets()Lwz;
    .locals 1

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Lwz;

    return-object v0
.end method

.method public getNestedScrollAxes()I
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u:Lkm;

    .line 3
    iget v1, v0, Lkm;->a:I

    .line 5
    iget v0, v0, Lkm;->b:I

    .line 7
    or-int/2addr v0, v1

    .line 8
    return v0
.end method

.method public getStatusBarBackground()Landroid/graphics/drawable/Drawable;
    .locals 1

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method public getSuggestedMinimumHeight()I
    .locals 3

    invoke-super {p0}, Landroid/view/ViewGroup;->getSuggestedMinimumHeight()I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v2

    add-int/2addr v2, v1

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v0

    return v0
.end method

.method public getSuggestedMinimumWidth()I
    .locals 3

    invoke-super {p0}, Landroid/view/ViewGroup;->getSuggestedMinimumWidth()I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v2

    add-int/2addr v2, v1

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v0

    return v0
.end method

.method public final i(Landroid/view/View;I)V
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x1

    .line 3
    iget-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u:Lkm;

    .line 5
    if-ne p2, v1, :cond_0

    .line 7
    iput v0, v2, Lkm;->b:I

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    iput v0, v2, Lkm;->a:I

    .line 12
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 15
    move-result v2

    .line 16
    const/4 v3, 0x0

    .line 17
    :goto_1
    if-ge v3, v2, :cond_5

    .line 19
    invoke-virtual {p0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 22
    move-result-object v4

    .line 23
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 26
    move-result-object v5

    .line 27
    check-cast v5, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 29
    invoke-virtual {v5, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a(I)Z

    .line 32
    move-result v6

    .line 33
    if-nez v6, :cond_1

    .line 35
    goto :goto_3

    .line 36
    :cond_1
    iget-object v6, v5, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 38
    if-eqz v6, :cond_2

    .line 40
    invoke-virtual {v6, p0, v4, p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->q(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;I)V

    .line 43
    :cond_2
    if-eqz p2, :cond_4

    .line 45
    if-eq p2, v1, :cond_3

    .line 47
    goto :goto_2

    .line 48
    :cond_3
    iput-boolean v0, v5, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->o:Z

    .line 50
    goto :goto_2

    .line 51
    :cond_4
    iput-boolean v0, v5, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->n:Z

    .line 53
    :goto_2
    iput-boolean v0, v5, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->p:Z

    .line 55
    :goto_3
    add-int/lit8 v3, v3, 0x1

    .line 57
    goto :goto_1

    .line 58
    :cond_5
    const/4 p1, 0x0

    .line 59
    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->m:Landroid/view/View;

    .line 61
    return-void
.end method

.method public final j(Landroid/view/View;II[II)V
    .locals 16

    .line 1
    move-object/from16 v8, p0

    .line 3
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 6
    move-result v9

    .line 7
    const/4 v10, 0x0

    .line 8
    const/4 v0, 0x0

    .line 9
    const/4 v11, 0x0

    .line 10
    const/4 v12, 0x0

    .line 11
    const/4 v13, 0x0

    .line 12
    :goto_0
    const/4 v14, 0x1

    .line 13
    if-ge v11, v9, :cond_5

    .line 15
    invoke-virtual {v8, v11}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 18
    move-result-object v2

    .line 19
    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    .line 22
    move-result v1

    .line 23
    const/16 v3, 0x8

    .line 25
    if-ne v1, v3, :cond_0

    .line 27
    move/from16 v15, p5

    .line 29
    goto :goto_3

    .line 30
    :cond_0
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 33
    move-result-object v1

    .line 34
    check-cast v1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 36
    move/from16 v15, p5

    .line 38
    invoke-virtual {v1, v15}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a(I)Z

    .line 41
    move-result v3

    .line 42
    if-nez v3, :cond_1

    .line 44
    goto :goto_3

    .line 45
    :cond_1
    iget-object v1, v1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 47
    if-eqz v1, :cond_4

    .line 49
    iget-object v6, v8, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->g:[I

    .line 51
    aput v10, v6, v10

    .line 53
    aput v10, v6, v14

    .line 55
    move-object v0, v1

    .line 56
    move-object/from16 v1, p0

    .line 58
    move-object/from16 v3, p1

    .line 60
    move/from16 v4, p2

    .line 62
    move/from16 v5, p3

    .line 64
    move/from16 v7, p5

    .line 66
    invoke-virtual/range {v0 .. v7}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->k(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;II[II)V

    .line 69
    iget-object v0, v8, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->g:[I

    .line 71
    if-lez p2, :cond_2

    .line 73
    aget v1, v0, v10

    .line 75
    invoke-static {v12, v1}, Ljava/lang/Math;->max(II)I

    .line 78
    move-result v1

    .line 79
    goto :goto_1

    .line 80
    :cond_2
    aget v1, v0, v10

    .line 82
    invoke-static {v12, v1}, Ljava/lang/Math;->min(II)I

    .line 85
    move-result v1

    .line 86
    :goto_1
    move v12, v1

    .line 87
    if-lez p3, :cond_3

    .line 89
    aget v0, v0, v14

    .line 91
    invoke-static {v13, v0}, Ljava/lang/Math;->max(II)I

    .line 94
    move-result v0

    .line 95
    goto :goto_2

    .line 96
    :cond_3
    aget v0, v0, v14

    .line 98
    invoke-static {v13, v0}, Ljava/lang/Math;->min(II)I

    .line 101
    move-result v0

    .line 102
    :goto_2
    move v13, v0

    .line 103
    const/4 v0, 0x1

    .line 104
    :cond_4
    :goto_3
    add-int/lit8 v11, v11, 0x1

    .line 106
    goto :goto_0

    .line 107
    :cond_5
    aput v12, p4, v10

    .line 109
    aput v13, p4, v14

    .line 111
    if-eqz v0, :cond_6

    .line 113
    invoke-virtual {v8, v14}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->l(I)V

    .line 116
    :cond_6
    return-void
.end method

.method public final k(Landroid/view/View;II)Z
    .locals 2

    .line 1
    sget-object v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->z:Lko;

    .line 3
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->a()Landroid/graphics/Rect;

    .line 6
    move-result-object v1

    .line 7
    invoke-virtual {p0, p1, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 10
    :try_start_0
    invoke-virtual {v1, p2, p3}, Landroid/graphics/Rect;->contains(II)Z

    .line 13
    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 14
    invoke-virtual {v1}, Landroid/graphics/Rect;->setEmpty()V

    .line 17
    invoke-virtual {v0, v1}, Lko;->b(Ljava/lang/Object;)Z

    .line 20
    return p1

    .line 21
    :catchall_0
    move-exception p1

    .line 22
    invoke-virtual {v1}, Landroid/graphics/Rect;->setEmpty()V

    .line 25
    invoke-virtual {v0, v1}, Lko;->b(Ljava/lang/Object;)Z

    .line 28
    throw p1
.end method

.method public final l(I)V
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 3
    move/from16 v1, p1

    .line 5
    sget-object v2, Lqx;->a:Ljava/util/WeakHashMap;

    .line 7
    invoke-static/range {p0 .. p0}, Lqx$e;->d(Landroid/view/View;)I

    .line 10
    move-result v2

    .line 11
    iget-object v9, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->c:Ljava/util/ArrayList;

    .line 13
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 16
    move-result v10

    .line 17
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->a()Landroid/graphics/Rect;

    .line 20
    move-result-object v11

    .line 21
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->a()Landroid/graphics/Rect;

    .line 24
    move-result-object v12

    .line 25
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->a()Landroid/graphics/Rect;

    .line 28
    move-result-object v13

    .line 29
    move v3, v1

    .line 30
    const/4 v15, 0x0

    .line 31
    :goto_0
    sget-object v8, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->z:Lko;

    .line 33
    if-ge v15, v10, :cond_20

    .line 35
    invoke-virtual {v9, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 38
    move-result-object v4

    .line 39
    move-object v7, v4

    .line 40
    check-cast v7, Landroid/view/View;

    .line 42
    invoke-virtual {v7}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 45
    move-result-object v4

    .line 46
    move-object v6, v4

    .line 47
    check-cast v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 49
    if-nez v3, :cond_0

    .line 51
    invoke-virtual {v7}, Landroid/view/View;->getVisibility()I

    .line 54
    move-result v4

    .line 55
    const/16 v5, 0x8

    .line 57
    if-ne v4, v5, :cond_0

    .line 59
    move-object v7, v9

    .line 60
    move v6, v10

    .line 61
    move-object v5, v13

    .line 62
    move/from16 v21, v15

    .line 64
    const/4 v14, 0x0

    .line 65
    goto/16 :goto_11

    .line 67
    :cond_0
    const/4 v5, 0x0

    .line 68
    :goto_1
    if-ge v5, v15, :cond_7

    .line 70
    invoke-virtual {v9, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 73
    move-result-object v3

    .line 74
    check-cast v3, Landroid/view/View;

    .line 76
    iget-object v4, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->l:Landroid/view/View;

    .line 78
    if-ne v4, v3, :cond_6

    .line 80
    invoke-virtual {v7}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 83
    move-result-object v3

    .line 84
    move-object v4, v3

    .line 85
    check-cast v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 87
    iget-object v3, v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->k:Landroid/view/View;

    .line 89
    if-eqz v3, :cond_6

    .line 91
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->a()Landroid/graphics/Rect;

    .line 94
    move-result-object v3

    .line 95
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->a()Landroid/graphics/Rect;

    .line 98
    move-result-object v14

    .line 99
    move-object/from16 v17, v9

    .line 101
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->a()Landroid/graphics/Rect;

    .line 104
    move-result-object v9

    .line 105
    move/from16 v18, v5

    .line 107
    iget-object v5, v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->k:Landroid/view/View;

    .line 109
    invoke-virtual {v0, v5, v3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 112
    const/4 v5, 0x0

    .line 113
    invoke-virtual {v0, v7, v14, v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->d(Landroid/view/View;Landroid/graphics/Rect;Z)V

    .line 116
    invoke-virtual {v7}, Landroid/view/View;->getMeasuredWidth()I

    .line 119
    move-result v5

    .line 120
    move/from16 v19, v10

    .line 122
    invoke-virtual {v7}, Landroid/view/View;->getMeasuredHeight()I

    .line 125
    move-result v10

    .line 126
    move-object/from16 v20, v3

    .line 128
    move v3, v2

    .line 129
    move-object/from16 v16, v4

    .line 131
    move/from16 v21, v15

    .line 133
    const/4 v15, 0x1

    .line 134
    move-object/from16 v4, v20

    .line 136
    move/from16 v22, v5

    .line 138
    move-object v5, v9

    .line 139
    move-object/from16 v23, v6

    .line 141
    move-object/from16 v6, v16

    .line 143
    move-object v15, v7

    .line 144
    move/from16 v7, v22

    .line 146
    move-object/from16 v24, v13

    .line 148
    move-object v13, v8

    .line 149
    move v8, v10

    .line 150
    invoke-static/range {v3 .. v8}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->g(ILandroid/graphics/Rect;Landroid/graphics/Rect;Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;II)V

    .line 153
    iget v3, v9, Landroid/graphics/Rect;->left:I

    .line 155
    iget v4, v14, Landroid/graphics/Rect;->left:I

    .line 157
    if-ne v3, v4, :cond_2

    .line 159
    iget v3, v9, Landroid/graphics/Rect;->top:I

    .line 161
    iget v4, v14, Landroid/graphics/Rect;->top:I

    .line 163
    if-eq v3, v4, :cond_1

    .line 165
    goto :goto_2

    .line 166
    :cond_1
    move-object/from16 v3, v16

    .line 168
    move/from16 v5, v22

    .line 170
    const/4 v4, 0x0

    .line 171
    goto :goto_3

    .line 172
    :cond_2
    :goto_2
    move-object/from16 v3, v16

    .line 174
    move/from16 v5, v22

    .line 176
    const/4 v4, 0x1

    .line 177
    :goto_3
    invoke-virtual {v0, v3, v9, v5, v10}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->c(Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;Landroid/graphics/Rect;II)V

    .line 180
    iget v5, v9, Landroid/graphics/Rect;->left:I

    .line 182
    iget v6, v14, Landroid/graphics/Rect;->left:I

    .line 184
    sub-int/2addr v5, v6

    .line 185
    iget v6, v9, Landroid/graphics/Rect;->top:I

    .line 187
    iget v7, v14, Landroid/graphics/Rect;->top:I

    .line 189
    sub-int/2addr v6, v7

    .line 190
    if-eqz v5, :cond_3

    .line 192
    invoke-static {v15, v5}, Lqx;->j(Landroid/view/View;I)V

    .line 195
    :cond_3
    if-eqz v6, :cond_4

    .line 197
    invoke-static {v15, v6}, Lqx;->k(Landroid/view/View;I)V

    .line 200
    :cond_4
    if-eqz v4, :cond_5

    .line 202
    iget-object v4, v3, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 204
    if-eqz v4, :cond_5

    .line 206
    iget-object v3, v3, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->k:Landroid/view/View;

    .line 208
    invoke-virtual {v4, v0, v15, v3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->d(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z

    .line 211
    :cond_5
    invoke-virtual/range {v20 .. v20}, Landroid/graphics/Rect;->setEmpty()V

    .line 214
    move-object/from16 v3, v20

    .line 216
    invoke-virtual {v13, v3}, Lko;->b(Ljava/lang/Object;)Z

    .line 219
    invoke-virtual {v14}, Landroid/graphics/Rect;->setEmpty()V

    .line 222
    invoke-virtual {v13, v14}, Lko;->b(Ljava/lang/Object;)Z

    .line 225
    invoke-virtual {v9}, Landroid/graphics/Rect;->setEmpty()V

    .line 228
    invoke-virtual {v13, v9}, Lko;->b(Ljava/lang/Object;)Z

    .line 231
    goto :goto_4

    .line 232
    :cond_6
    move/from16 v18, v5

    .line 234
    move-object/from16 v23, v6

    .line 236
    move-object/from16 v17, v9

    .line 238
    move/from16 v19, v10

    .line 240
    move-object/from16 v24, v13

    .line 242
    move/from16 v21, v15

    .line 244
    move-object v15, v7

    .line 245
    move-object v13, v8

    .line 246
    :goto_4
    add-int/lit8 v5, v18, 0x1

    .line 248
    move-object v8, v13

    .line 249
    move-object v7, v15

    .line 250
    move-object/from16 v9, v17

    .line 252
    move/from16 v10, v19

    .line 254
    move/from16 v15, v21

    .line 256
    move-object/from16 v6, v23

    .line 258
    move-object/from16 v13, v24

    .line 260
    goto/16 :goto_1

    .line 262
    :cond_7
    move-object/from16 v23, v6

    .line 264
    move-object/from16 v17, v9

    .line 266
    move/from16 v19, v10

    .line 268
    move-object/from16 v24, v13

    .line 270
    move/from16 v21, v15

    .line 272
    const/4 v3, 0x1

    .line 273
    move-object v15, v7

    .line 274
    move-object v13, v8

    .line 275
    invoke-virtual {v0, v15, v12, v3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->d(Landroid/view/View;Landroid/graphics/Rect;Z)V

    .line 278
    move-object/from16 v4, v23

    .line 280
    iget v3, v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->g:I

    .line 282
    const/16 v5, 0x30

    .line 284
    const/16 v6, 0x50

    .line 286
    const/4 v7, 0x3

    .line 287
    const/4 v8, 0x5

    .line 288
    if-eqz v3, :cond_c

    .line 290
    invoke-virtual {v12}, Landroid/graphics/Rect;->isEmpty()Z

    .line 293
    move-result v3

    .line 294
    if-nez v3, :cond_c

    .line 296
    iget v3, v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->g:I

    .line 298
    invoke-static {v3, v2}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 301
    move-result v3

    .line 302
    and-int/lit8 v9, v3, 0x70

    .line 304
    if-eq v9, v5, :cond_9

    .line 306
    if-eq v9, v6, :cond_8

    .line 308
    goto :goto_5

    .line 309
    :cond_8
    iget v9, v11, Landroid/graphics/Rect;->bottom:I

    .line 311
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 314
    move-result v10

    .line 315
    iget v14, v12, Landroid/graphics/Rect;->top:I

    .line 317
    sub-int/2addr v10, v14

    .line 318
    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    .line 321
    move-result v9

    .line 322
    iput v9, v11, Landroid/graphics/Rect;->bottom:I

    .line 324
    goto :goto_5

    .line 325
    :cond_9
    iget v9, v11, Landroid/graphics/Rect;->top:I

    .line 327
    iget v10, v12, Landroid/graphics/Rect;->bottom:I

    .line 329
    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    .line 332
    move-result v9

    .line 333
    iput v9, v11, Landroid/graphics/Rect;->top:I

    .line 335
    :goto_5
    and-int/lit8 v3, v3, 0x7

    .line 337
    if-eq v3, v7, :cond_b

    .line 339
    if-eq v3, v8, :cond_a

    .line 341
    goto :goto_6

    .line 342
    :cond_a
    iget v3, v11, Landroid/graphics/Rect;->right:I

    .line 344
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 347
    move-result v9

    .line 348
    iget v10, v12, Landroid/graphics/Rect;->left:I

    .line 350
    sub-int/2addr v9, v10

    .line 351
    invoke-static {v3, v9}, Ljava/lang/Math;->max(II)I

    .line 354
    move-result v3

    .line 355
    iput v3, v11, Landroid/graphics/Rect;->right:I

    .line 357
    goto :goto_6

    .line 358
    :cond_b
    iget v3, v11, Landroid/graphics/Rect;->left:I

    .line 360
    iget v9, v12, Landroid/graphics/Rect;->right:I

    .line 362
    invoke-static {v3, v9}, Ljava/lang/Math;->max(II)I

    .line 365
    move-result v3

    .line 366
    iput v3, v11, Landroid/graphics/Rect;->left:I

    .line 368
    :cond_c
    :goto_6
    iget v3, v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->h:I

    .line 370
    if-eqz v3, :cond_18

    .line 372
    invoke-virtual {v15}, Landroid/view/View;->getVisibility()I

    .line 375
    move-result v3

    .line 376
    if-nez v3, :cond_18

    .line 378
    sget-object v3, Lqx;->a:Ljava/util/WeakHashMap;

    .line 380
    invoke-static {v15}, Lqx$g;->c(Landroid/view/View;)Z

    .line 383
    move-result v3

    .line 384
    if-nez v3, :cond_d

    .line 386
    goto/16 :goto_b

    .line 388
    :cond_d
    invoke-virtual {v15}, Landroid/view/View;->getWidth()I

    .line 391
    move-result v3

    .line 392
    if-lez v3, :cond_18

    .line 394
    invoke-virtual {v15}, Landroid/view/View;->getHeight()I

    .line 397
    move-result v3

    .line 398
    if-gtz v3, :cond_e

    .line 400
    goto/16 :goto_b

    .line 402
    :cond_e
    invoke-virtual {v15}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 405
    move-result-object v3

    .line 406
    check-cast v3, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 408
    iget-object v4, v3, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 410
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->a()Landroid/graphics/Rect;

    .line 413
    move-result-object v9

    .line 414
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->a()Landroid/graphics/Rect;

    .line 417
    move-result-object v10

    .line 418
    invoke-virtual {v15}, Landroid/view/View;->getLeft()I

    .line 421
    move-result v14

    .line 422
    invoke-virtual {v15}, Landroid/view/View;->getTop()I

    .line 425
    move-result v8

    .line 426
    invoke-virtual {v15}, Landroid/view/View;->getRight()I

    .line 429
    move-result v7

    .line 430
    invoke-virtual {v15}, Landroid/view/View;->getBottom()I

    .line 433
    move-result v6

    .line 434
    invoke-virtual {v10, v14, v8, v7, v6}, Landroid/graphics/Rect;->set(IIII)V

    .line 437
    if-eqz v4, :cond_10

    .line 439
    invoke-virtual {v4, v15}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->a(Landroid/view/View;)Z

    .line 442
    move-result v4

    .line 443
    if-eqz v4, :cond_10

    .line 445
    invoke-virtual {v10, v9}, Landroid/graphics/Rect;->contains(Landroid/graphics/Rect;)Z

    .line 448
    move-result v4

    .line 449
    if-eqz v4, :cond_f

    .line 451
    goto :goto_7

    .line 452
    :cond_f
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 454
    new-instance v2, Ljava/lang/StringBuilder;

    .line 456
    const-string v3, "Rect should be within the child\'s bounds. Rect:"

    .line 458
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 461
    invoke-virtual {v9}, Landroid/graphics/Rect;->toShortString()Ljava/lang/String;

    .line 464
    move-result-object v3

    .line 465
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 468
    const-string v3, " | Bounds:"

    .line 470
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 473
    invoke-virtual {v10}, Landroid/graphics/Rect;->toShortString()Ljava/lang/String;

    .line 476
    move-result-object v3

    .line 477
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 480
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 483
    move-result-object v2

    .line 484
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 487
    throw v1

    .line 488
    :cond_10
    invoke-virtual {v9, v10}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 491
    :goto_7
    invoke-virtual {v10}, Landroid/graphics/Rect;->setEmpty()V

    .line 494
    invoke-virtual {v13, v10}, Lko;->b(Ljava/lang/Object;)Z

    .line 497
    invoke-virtual {v9}, Landroid/graphics/Rect;->isEmpty()Z

    .line 500
    move-result v4

    .line 501
    if-eqz v4, :cond_11

    .line 503
    invoke-virtual {v9}, Landroid/graphics/Rect;->setEmpty()V

    .line 506
    invoke-virtual {v13, v9}, Lko;->b(Ljava/lang/Object;)Z

    .line 509
    goto/16 :goto_b

    .line 511
    :cond_11
    iget v4, v3, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->h:I

    .line 513
    invoke-static {v4, v2}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 516
    move-result v4

    .line 517
    and-int/lit8 v6, v4, 0x30

    .line 519
    if-ne v6, v5, :cond_12

    .line 521
    iget v5, v9, Landroid/graphics/Rect;->top:I

    .line 523
    iget v6, v3, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 525
    sub-int/2addr v5, v6

    .line 526
    iget v6, v3, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->j:I

    .line 528
    sub-int/2addr v5, v6

    .line 529
    iget v6, v11, Landroid/graphics/Rect;->top:I

    .line 531
    if-ge v5, v6, :cond_12

    .line 533
    sub-int/2addr v6, v5

    .line 534
    invoke-static {v15, v6}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v(Landroid/view/View;I)V

    .line 537
    const/4 v5, 0x1

    .line 538
    goto :goto_8

    .line 539
    :cond_12
    const/4 v5, 0x0

    .line 540
    :goto_8
    and-int/lit8 v6, v4, 0x50

    .line 542
    const/16 v7, 0x50

    .line 544
    if-ne v6, v7, :cond_13

    .line 546
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 549
    move-result v6

    .line 550
    iget v7, v9, Landroid/graphics/Rect;->bottom:I

    .line 552
    sub-int/2addr v6, v7

    .line 553
    iget v7, v3, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 555
    sub-int/2addr v6, v7

    .line 556
    iget v7, v3, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->j:I

    .line 558
    add-int/2addr v6, v7

    .line 559
    iget v7, v11, Landroid/graphics/Rect;->bottom:I

    .line 561
    if-ge v6, v7, :cond_13

    .line 563
    sub-int/2addr v6, v7

    .line 564
    invoke-static {v15, v6}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v(Landroid/view/View;I)V

    .line 567
    const/4 v5, 0x1

    .line 568
    :cond_13
    if-nez v5, :cond_14

    .line 570
    const/4 v5, 0x0

    .line 571
    invoke-static {v15, v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->v(Landroid/view/View;I)V

    .line 574
    :cond_14
    and-int/lit8 v5, v4, 0x3

    .line 576
    const/4 v6, 0x3

    .line 577
    if-ne v5, v6, :cond_15

    .line 579
    iget v5, v9, Landroid/graphics/Rect;->left:I

    .line 581
    iget v6, v3, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 583
    sub-int/2addr v5, v6

    .line 584
    iget v6, v3, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->i:I

    .line 586
    sub-int/2addr v5, v6

    .line 587
    iget v6, v11, Landroid/graphics/Rect;->left:I

    .line 589
    if-ge v5, v6, :cond_15

    .line 591
    sub-int/2addr v6, v5

    .line 592
    invoke-static {v15, v6}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u(Landroid/view/View;I)V

    .line 595
    const/4 v5, 0x1

    .line 596
    goto :goto_9

    .line 597
    :cond_15
    const/4 v5, 0x0

    .line 598
    :goto_9
    and-int/lit8 v4, v4, 0x5

    .line 600
    const/4 v6, 0x5

    .line 601
    if-ne v4, v6, :cond_16

    .line 603
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 606
    move-result v4

    .line 607
    iget v6, v9, Landroid/graphics/Rect;->right:I

    .line 609
    sub-int/2addr v4, v6

    .line 610
    iget v6, v3, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 612
    sub-int/2addr v4, v6

    .line 613
    iget v3, v3, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->i:I

    .line 615
    add-int/2addr v4, v3

    .line 616
    iget v3, v11, Landroid/graphics/Rect;->right:I

    .line 618
    if-ge v4, v3, :cond_16

    .line 620
    sub-int/2addr v4, v3

    .line 621
    invoke-static {v15, v4}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u(Landroid/view/View;I)V

    .line 624
    const/4 v4, 0x1

    .line 625
    goto :goto_a

    .line 626
    :cond_16
    move v4, v5

    .line 627
    :goto_a
    if-nez v4, :cond_17

    .line 629
    const/4 v3, 0x0

    .line 630
    invoke-static {v15, v3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->u(Landroid/view/View;I)V

    .line 633
    :cond_17
    invoke-virtual {v9}, Landroid/graphics/Rect;->setEmpty()V

    .line 636
    invoke-virtual {v13, v9}, Lko;->b(Ljava/lang/Object;)Z

    .line 639
    :cond_18
    :goto_b
    const/4 v3, 0x2

    .line 640
    if-eq v1, v3, :cond_1b

    .line 642
    invoke-virtual {v15}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 645
    move-result-object v4

    .line 646
    check-cast v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 648
    iget-object v4, v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->q:Landroid/graphics/Rect;

    .line 650
    move-object/from16 v5, v24

    .line 652
    invoke-virtual {v5, v4}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 655
    invoke-virtual {v5, v12}, Landroid/graphics/Rect;->equals(Ljava/lang/Object;)Z

    .line 658
    move-result v4

    .line 659
    if-eqz v4, :cond_1a

    .line 661
    move-object/from16 v7, v17

    .line 663
    move/from16 v6, v19

    .line 665
    :cond_19
    const/4 v14, 0x0

    .line 666
    goto :goto_10

    .line 667
    :cond_1a
    invoke-virtual {v15}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 670
    move-result-object v4

    .line 671
    check-cast v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 673
    iget-object v4, v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->q:Landroid/graphics/Rect;

    .line 675
    invoke-virtual {v4, v12}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 678
    goto :goto_c

    .line 679
    :cond_1b
    move-object/from16 v5, v24

    .line 681
    :goto_c
    add-int/lit8 v4, v21, 0x1

    .line 683
    move/from16 v6, v19

    .line 685
    :goto_d
    move-object/from16 v7, v17

    .line 687
    if-ge v4, v6, :cond_19

    .line 689
    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 692
    move-result-object v8

    .line 693
    check-cast v8, Landroid/view/View;

    .line 695
    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 698
    move-result-object v9

    .line 699
    check-cast v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 701
    iget-object v10, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 703
    if-eqz v10, :cond_1e

    .line 705
    invoke-virtual {v10, v8, v15}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->b(Landroid/view/View;Landroid/view/View;)Z

    .line 708
    move-result v13

    .line 709
    if-eqz v13, :cond_1e

    .line 711
    if-nez v1, :cond_1c

    .line 713
    iget-boolean v13, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->p:Z

    .line 715
    if-eqz v13, :cond_1c

    .line 717
    const/4 v14, 0x0

    .line 718
    iput-boolean v14, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->p:Z

    .line 720
    const/4 v10, 0x1

    .line 721
    goto :goto_f

    .line 722
    :cond_1c
    const/4 v14, 0x0

    .line 723
    if-eq v1, v3, :cond_1d

    .line 725
    invoke-virtual {v10, v0, v8, v15}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->d(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z

    .line 728
    move-result v8

    .line 729
    goto :goto_e

    .line 730
    :cond_1d
    invoke-virtual {v10, v0, v15}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->e(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;)V

    .line 733
    const/4 v8, 0x1

    .line 734
    :goto_e
    const/4 v10, 0x1

    .line 735
    if-ne v1, v10, :cond_1f

    .line 737
    iput-boolean v8, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->p:Z

    .line 739
    goto :goto_f

    .line 740
    :cond_1e
    const/4 v10, 0x1

    .line 741
    const/4 v14, 0x0

    .line 742
    :cond_1f
    :goto_f
    add-int/lit8 v4, v4, 0x1

    .line 744
    move-object/from16 v17, v7

    .line 746
    goto :goto_d

    .line 747
    :goto_10
    move v3, v1

    .line 748
    :goto_11
    add-int/lit8 v15, v21, 0x1

    .line 750
    move-object v13, v5

    .line 751
    move v10, v6

    .line 752
    move-object v9, v7

    .line 753
    goto/16 :goto_0

    .line 755
    :cond_20
    move-object v5, v13

    .line 756
    move-object v13, v8

    .line 757
    invoke-virtual {v11}, Landroid/graphics/Rect;->setEmpty()V

    .line 760
    invoke-virtual {v13, v11}, Lko;->b(Ljava/lang/Object;)Z

    .line 763
    invoke-virtual {v12}, Landroid/graphics/Rect;->setEmpty()V

    .line 766
    invoke-virtual {v13, v12}, Lko;->b(Ljava/lang/Object;)Z

    .line 769
    invoke-virtual {v5}, Landroid/graphics/Rect;->setEmpty()V

    .line 772
    invoke-virtual {v13, v5}, Lko;->b(Ljava/lang/Object;)Z

    .line 775
    return-void
.end method

.method public final m(Landroid/view/View;IIIII[I)V
    .locals 16

    .line 1
    move-object/from16 v7, p0

    .line 3
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 6
    move-result v8

    .line 7
    const/4 v9, 0x0

    .line 8
    const/4 v0, 0x0

    .line 9
    const/4 v10, 0x0

    .line 10
    const/4 v11, 0x0

    .line 11
    const/4 v12, 0x0

    .line 12
    :goto_0
    const/4 v13, 0x1

    .line 13
    if-ge v10, v8, :cond_5

    .line 15
    invoke-virtual {v7, v10}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 18
    move-result-object v2

    .line 19
    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    .line 22
    move-result v1

    .line 23
    const/16 v3, 0x8

    .line 25
    if-ne v1, v3, :cond_0

    .line 27
    move/from16 v14, p6

    .line 29
    goto :goto_3

    .line 30
    :cond_0
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 33
    move-result-object v1

    .line 34
    check-cast v1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 36
    move/from16 v14, p6

    .line 38
    invoke-virtual {v1, v14}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a(I)Z

    .line 41
    move-result v3

    .line 42
    if-nez v3, :cond_1

    .line 44
    goto :goto_3

    .line 45
    :cond_1
    iget-object v1, v1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 47
    if-eqz v1, :cond_4

    .line 49
    iget-object v15, v7, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->g:[I

    .line 51
    aput v9, v15, v9

    .line 53
    aput v9, v15, v13

    .line 55
    move-object v0, v1

    .line 56
    move-object/from16 v1, p0

    .line 58
    move/from16 v3, p3

    .line 60
    move/from16 v4, p4

    .line 62
    move/from16 v5, p5

    .line 64
    move-object v6, v15

    .line 65
    invoke-virtual/range {v0 .. v6}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->l(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;III[I)V

    .line 68
    if-lez p4, :cond_2

    .line 70
    aget v0, v15, v9

    .line 72
    invoke-static {v11, v0}, Ljava/lang/Math;->max(II)I

    .line 75
    move-result v0

    .line 76
    goto :goto_1

    .line 77
    :cond_2
    aget v0, v15, v9

    .line 79
    invoke-static {v11, v0}, Ljava/lang/Math;->min(II)I

    .line 82
    move-result v0

    .line 83
    :goto_1
    move v11, v0

    .line 84
    if-lez p5, :cond_3

    .line 86
    aget v0, v15, v13

    .line 88
    invoke-static {v12, v0}, Ljava/lang/Math;->max(II)I

    .line 91
    move-result v0

    .line 92
    goto :goto_2

    .line 93
    :cond_3
    aget v0, v15, v13

    .line 95
    invoke-static {v12, v0}, Ljava/lang/Math;->min(II)I

    .line 98
    move-result v0

    .line 99
    :goto_2
    move v12, v0

    .line 100
    const/4 v0, 0x1

    .line 101
    :cond_4
    :goto_3
    add-int/lit8 v10, v10, 0x1

    .line 103
    goto :goto_0

    .line 104
    :cond_5
    aget v1, p7, v9

    .line 106
    add-int/2addr v1, v11

    .line 107
    aput v1, p7, v9

    .line 109
    aget v1, p7, v13

    .line 111
    add-int/2addr v1, v12

    .line 112
    aput v1, p7, v13

    .line 114
    if-eqz v0, :cond_6

    .line 116
    invoke-virtual {v7, v13}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->l(I)V

    .line 119
    :cond_6
    return-void
.end method

.method public final n(Landroid/view/View;IIIII)V
    .locals 8

    const/4 v6, 0x0

    iget-object v7, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->h:[I

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    invoke-virtual/range {v0 .. v7}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->m(Landroid/view/View;IIIII[I)V

    return-void
.end method

.method public final o(Landroid/view/View;Landroid/view/View;II)Z
    .locals 15

    .line 1
    move/from16 v7, p4

    .line 3
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 6
    move-result v8

    .line 7
    const/4 v9, 0x0

    .line 8
    const/4 v10, 0x0

    .line 9
    const/4 v11, 0x0

    .line 10
    :goto_0
    if-ge v10, v8, :cond_6

    .line 12
    move-object v12, p0

    .line 13
    invoke-virtual {p0, v10}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 16
    move-result-object v2

    .line 17
    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    .line 20
    move-result v0

    .line 21
    const/16 v1, 0x8

    .line 23
    if-ne v0, v1, :cond_0

    .line 25
    goto :goto_1

    .line 26
    :cond_0
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 29
    move-result-object v0

    .line 30
    move-object v13, v0

    .line 31
    check-cast v13, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 33
    iget-object v0, v13, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 35
    const/4 v14, 0x1

    .line 36
    if-eqz v0, :cond_3

    .line 38
    move-object v1, p0

    .line 39
    move-object/from16 v3, p1

    .line 41
    move-object/from16 v4, p2

    .line 43
    move/from16 v5, p3

    .line 45
    move/from16 v6, p4

    .line 47
    invoke-virtual/range {v0 .. v6}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->p(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;Landroid/view/View;II)Z

    .line 50
    move-result v0

    .line 51
    or-int/2addr v11, v0

    .line 52
    if-eqz v7, :cond_2

    .line 54
    if-eq v7, v14, :cond_1

    .line 56
    goto :goto_1

    .line 57
    :cond_1
    iput-boolean v0, v13, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->o:Z

    .line 59
    goto :goto_1

    .line 60
    :cond_2
    iput-boolean v0, v13, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->n:Z

    .line 62
    goto :goto_1

    .line 63
    :cond_3
    if-eqz v7, :cond_5

    .line 65
    if-eq v7, v14, :cond_4

    .line 67
    goto :goto_1

    .line 68
    :cond_4
    iput-boolean v9, v13, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->o:Z

    .line 70
    goto :goto_1

    .line 71
    :cond_5
    iput-boolean v9, v13, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->n:Z

    .line 73
    :goto_1
    add-int/lit8 v10, v10, 0x1

    .line 75
    goto :goto_0

    .line 76
    :cond_6
    move-object v12, p0

    .line 77
    return v11
.end method

.method public final onAttachedToWindow()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onAttachedToWindow()V

    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-virtual {p0, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t(Z)V

    .line 8
    iget-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->o:Z

    .line 10
    if-eqz v0, :cond_1

    .line 12
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n:Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    .line 14
    if-nez v0, :cond_0

    .line 16
    new-instance v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    .line 18
    invoke-direct {v0, p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;-><init>(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V

    .line 21
    iput-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n:Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    .line 23
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 26
    move-result-object v0

    .line 27
    iget-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n:Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    .line 29
    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 32
    :cond_1
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Lwz;

    .line 34
    if-nez v0, :cond_2

    .line 36
    sget-object v0, Lqx;->a:Ljava/util/WeakHashMap;

    .line 38
    invoke-static {p0}, Lqx$d;->b(Landroid/view/View;)Z

    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_2

    .line 44
    invoke-static {p0}, Lqx$h;->c(Landroid/view/View;)V

    .line 47
    :cond_2
    const/4 v0, 0x1

    .line 48
    iput-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->j:Z

    .line 50
    return-void
.end method

.method public final onDetachedFromWindow()V
    .locals 3

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onDetachedFromWindow()V

    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-virtual {p0, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t(Z)V

    .line 8
    iget-boolean v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->o:Z

    .line 10
    if-eqz v1, :cond_0

    .line 12
    iget-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n:Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    .line 14
    if-eqz v1, :cond_0

    .line 16
    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 19
    move-result-object v1

    .line 20
    iget-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n:Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    .line 22
    invoke-virtual {v1, v2}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 25
    :cond_0
    iget-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->m:Landroid/view/View;

    .line 27
    if-eqz v1, :cond_1

    .line 29
    invoke-virtual {p0, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->onStopNestedScroll(Landroid/view/View;)V

    .line 32
    :cond_1
    iput-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->j:Z

    .line 34
    return-void
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 4

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onDraw(Landroid/graphics/Canvas;)V

    .line 4
    iget-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->q:Z

    .line 6
    if-eqz v0, :cond_1

    .line 8
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/graphics/drawable/Drawable;

    .line 10
    if-eqz v0, :cond_1

    .line 12
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Lwz;

    .line 14
    const/4 v1, 0x0

    .line 15
    if-eqz v0, :cond_0

    .line 17
    invoke-virtual {v0}, Lwz;->e()I

    .line 20
    move-result v0

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 v0, 0x0

    .line 23
    :goto_0
    if-lez v0, :cond_1

    .line 25
    iget-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/graphics/drawable/Drawable;

    .line 27
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 30
    move-result v3

    .line 31
    invoke-virtual {v2, v1, v1, v3, v0}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 34
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/graphics/drawable/Drawable;

    .line 36
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 39
    :cond_1
    return-void
.end method

.method public final onInterceptTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 3

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-nez v0, :cond_0

    .line 8
    invoke-virtual {p0, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t(Z)V

    .line 11
    :cond_0
    const/4 v2, 0x0

    .line 12
    invoke-virtual {p0, p1, v2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r(Landroid/view/MotionEvent;I)Z

    .line 15
    move-result p1

    .line 16
    if-eq v0, v1, :cond_1

    .line 18
    const/4 v2, 0x3

    .line 19
    if-ne v0, v2, :cond_2

    .line 21
    :cond_1
    invoke-virtual {p0, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t(Z)V

    .line 24
    :cond_2
    return p1
.end method

.method public final onLayout(ZIIII)V
    .locals 2

    .line 1
    sget-object p1, Lqx;->a:Ljava/util/WeakHashMap;

    .line 3
    invoke-static {p0}, Lqx$e;->d(Landroid/view/View;)I

    .line 6
    move-result p1

    .line 7
    iget-object p2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->c:Ljava/util/ArrayList;

    .line 9
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    .line 12
    move-result p3

    .line 13
    const/4 p4, 0x0

    .line 14
    :goto_0
    if-ge p4, p3, :cond_3

    .line 16
    invoke-virtual {p2, p4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 19
    move-result-object p5

    .line 20
    check-cast p5, Landroid/view/View;

    .line 22
    invoke-virtual {p5}, Landroid/view/View;->getVisibility()I

    .line 25
    move-result v0

    .line 26
    const/16 v1, 0x8

    .line 28
    if-ne v0, v1, :cond_0

    .line 30
    goto :goto_1

    .line 31
    :cond_0
    invoke-virtual {p5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 34
    move-result-object v0

    .line 35
    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 37
    iget-object v0, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 39
    if-eqz v0, :cond_1

    .line 41
    invoke-virtual {v0, p0, p5, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->h(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z

    .line 44
    move-result v0

    .line 45
    if-nez v0, :cond_2

    .line 47
    :cond_1
    invoke-virtual {p0, p5, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p(Landroid/view/View;I)V

    .line 50
    :cond_2
    :goto_1
    add-int/lit8 p4, p4, 0x1

    .line 52
    goto :goto_0

    .line 53
    :cond_3
    return-void
.end method

.method public final onMeasure(II)V
    .locals 32

    .line 1
    move-object/from16 v6, p0

    .line 3
    invoke-virtual/range {p0 .. p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->s()V

    .line 6
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 9
    move-result v0

    .line 10
    const/4 v7, 0x0

    .line 11
    const/4 v1, 0x0

    .line 12
    :goto_0
    const/4 v2, 0x1

    .line 13
    if-ge v1, v0, :cond_3

    .line 15
    invoke-virtual {v6, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 18
    move-result-object v3

    .line 19
    iget-object v4, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->d:La5;

    .line 21
    iget-object v4, v4, La5;->b:Ljava/lang/Object;

    .line 23
    check-cast v4, Lks;

    .line 25
    iget v5, v4, Lks;->e:I

    .line 27
    const/4 v8, 0x0

    .line 28
    :goto_1
    if-ge v8, v5, :cond_1

    .line 30
    invoke-virtual {v4, v8}, Lks;->j(I)Ljava/lang/Object;

    .line 33
    move-result-object v9

    .line 34
    check-cast v9, Ljava/util/ArrayList;

    .line 36
    if-eqz v9, :cond_0

    .line 38
    invoke-virtual {v9, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 41
    move-result v9

    .line 42
    if-eqz v9, :cond_0

    .line 44
    const/4 v3, 0x1

    .line 45
    goto :goto_2

    .line 46
    :cond_0
    add-int/lit8 v8, v8, 0x1

    .line 48
    goto :goto_1

    .line 49
    :cond_1
    const/4 v3, 0x0

    .line 50
    :goto_2
    if-eqz v3, :cond_2

    .line 52
    const/4 v0, 0x1

    .line 53
    goto :goto_3

    .line 54
    :cond_2
    add-int/lit8 v1, v1, 0x1

    .line 56
    goto :goto_0

    .line 57
    :cond_3
    const/4 v0, 0x0

    .line 58
    :goto_3
    iget-boolean v1, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->o:Z

    .line 60
    if-eq v0, v1, :cond_8

    .line 62
    if-eqz v0, :cond_6

    .line 64
    iget-boolean v0, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->j:Z

    .line 66
    if-eqz v0, :cond_5

    .line 68
    iget-object v0, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n:Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    .line 70
    if-nez v0, :cond_4

    .line 72
    new-instance v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    .line 74
    invoke-direct {v0, v6}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;-><init>(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V

    .line 77
    iput-object v0, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n:Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    .line 79
    :cond_4
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 82
    move-result-object v0

    .line 83
    iget-object v1, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n:Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    .line 85
    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 88
    :cond_5
    iput-boolean v2, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->o:Z

    .line 90
    goto :goto_4

    .line 91
    :cond_6
    iget-boolean v0, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->j:Z

    .line 93
    if-eqz v0, :cond_7

    .line 95
    iget-object v0, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n:Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    .line 97
    if-eqz v0, :cond_7

    .line 99
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 102
    move-result-object v0

    .line 103
    iget-object v1, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n:Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    .line 105
    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 108
    :cond_7
    iput-boolean v7, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->o:Z

    .line 110
    :cond_8
    :goto_4
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    .line 113
    move-result v8

    .line 114
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingTop()I

    .line 117
    move-result v0

    .line 118
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingRight()I

    .line 121
    move-result v9

    .line 122
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingBottom()I

    .line 125
    move-result v1

    .line 126
    sget-object v3, Lqx;->a:Ljava/util/WeakHashMap;

    .line 128
    invoke-static/range {p0 .. p0}, Lqx$e;->d(Landroid/view/View;)I

    .line 131
    move-result v10

    .line 132
    if-ne v10, v2, :cond_9

    .line 134
    const/4 v11, 0x1

    .line 135
    goto :goto_5

    .line 136
    :cond_9
    const/4 v11, 0x0

    .line 137
    :goto_5
    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 140
    move-result v12

    .line 141
    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 144
    move-result v13

    .line 145
    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 148
    move-result v14

    .line 149
    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 152
    move-result v15

    .line 153
    add-int v16, v8, v9

    .line 155
    add-int v17, v0, v1

    .line 157
    invoke-virtual/range {p0 .. p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getSuggestedMinimumWidth()I

    .line 160
    move-result v0

    .line 161
    invoke-virtual/range {p0 .. p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->getSuggestedMinimumHeight()I

    .line 164
    move-result v1

    .line 165
    iget-object v3, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Lwz;

    .line 167
    if-eqz v3, :cond_a

    .line 169
    invoke-static/range {p0 .. p0}, Lqx$d;->b(Landroid/view/View;)Z

    .line 172
    move-result v3

    .line 173
    if-eqz v3, :cond_a

    .line 175
    const/16 v18, 0x1

    .line 177
    goto :goto_6

    .line 178
    :cond_a
    const/16 v18, 0x0

    .line 180
    :goto_6
    iget-object v5, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->c:Ljava/util/ArrayList;

    .line 182
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 185
    move-result v4

    .line 186
    move v3, v0

    .line 187
    move v2, v1

    .line 188
    const/4 v0, 0x0

    .line 189
    const/4 v1, 0x0

    .line 190
    :goto_7
    if-ge v1, v4, :cond_1a

    .line 192
    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 195
    move-result-object v19

    .line 196
    check-cast v19, Landroid/view/View;

    .line 198
    invoke-virtual/range {v19 .. v19}, Landroid/view/View;->getVisibility()I

    .line 201
    move-result v7

    .line 202
    move/from16 v21, v0

    .line 204
    const/16 v0, 0x8

    .line 206
    if-ne v7, v0, :cond_b

    .line 208
    move/from16 v28, v4

    .line 210
    move-object/from16 v29, v5

    .line 212
    move/from16 v22, v8

    .line 214
    move/from16 v23, v9

    .line 216
    move/from16 v27, v10

    .line 218
    move/from16 v0, v21

    .line 220
    const/16 v24, 0x0

    .line 222
    move/from16 v21, v1

    .line 224
    goto/16 :goto_10

    .line 226
    :cond_b
    invoke-virtual/range {v19 .. v19}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 229
    move-result-object v0

    .line 230
    move-object v7, v0

    .line 231
    check-cast v7, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 233
    iget v0, v7, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->e:I

    .line 235
    if-ltz v0, :cond_16

    .line 237
    if-eqz v12, :cond_16

    .line 239
    move/from16 v22, v1

    .line 241
    iget-object v1, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->k:[I

    .line 243
    if-nez v1, :cond_c

    .line 245
    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 248
    move/from16 v23, v2

    .line 250
    :goto_8
    const/4 v0, 0x0

    .line 251
    goto :goto_a

    .line 252
    :cond_c
    move/from16 v23, v2

    .line 254
    if-ltz v0, :cond_e

    .line 256
    array-length v2, v1

    .line 257
    if-lt v0, v2, :cond_d

    .line 259
    goto :goto_9

    .line 260
    :cond_d
    aget v0, v1, v0

    .line 262
    goto :goto_a

    .line 263
    :cond_e
    :goto_9
    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 266
    goto :goto_8

    .line 267
    :goto_a
    iget v1, v7, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->c:I

    .line 269
    if-nez v1, :cond_f

    .line 271
    const v1, 0x800035

    .line 274
    :cond_f
    invoke-static {v1, v10}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 277
    move-result v1

    .line 278
    and-int/lit8 v1, v1, 0x7

    .line 280
    const/4 v2, 0x3

    .line 281
    if-ne v1, v2, :cond_10

    .line 283
    if-eqz v11, :cond_11

    .line 285
    :cond_10
    const/4 v2, 0x5

    .line 286
    if-ne v1, v2, :cond_12

    .line 288
    if-eqz v11, :cond_12

    .line 290
    :cond_11
    sub-int v1, v13, v9

    .line 292
    sub-int/2addr v1, v0

    .line 293
    const/4 v0, 0x0

    .line 294
    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    .line 297
    move-result v1

    .line 298
    move/from16 v20, v1

    .line 300
    const/4 v2, 0x0

    .line 301
    goto :goto_d

    .line 302
    :cond_12
    if-ne v1, v2, :cond_13

    .line 304
    if-eqz v11, :cond_14

    .line 306
    :cond_13
    const/4 v2, 0x3

    .line 307
    if-ne v1, v2, :cond_15

    .line 309
    if-eqz v11, :cond_15

    .line 311
    :cond_14
    sub-int/2addr v0, v8

    .line 312
    const/4 v2, 0x0

    .line 313
    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    .line 316
    move-result v0

    .line 317
    move/from16 v20, v0

    .line 319
    goto :goto_d

    .line 320
    :cond_15
    :goto_b
    const/4 v2, 0x0

    .line 321
    goto :goto_c

    .line 322
    :cond_16
    move/from16 v22, v1

    .line 324
    move/from16 v23, v2

    .line 326
    goto :goto_b

    .line 327
    :goto_c
    const/16 v20, 0x0

    .line 329
    :goto_d
    if-eqz v18, :cond_17

    .line 331
    invoke-static/range {v19 .. v19}, Lqx$d;->b(Landroid/view/View;)Z

    .line 334
    move-result v0

    .line 335
    if-nez v0, :cond_17

    .line 337
    iget-object v0, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Lwz;

    .line 339
    invoke-virtual {v0}, Lwz;->c()I

    .line 342
    move-result v0

    .line 343
    iget-object v1, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Lwz;

    .line 345
    invoke-virtual {v1}, Lwz;->d()I

    .line 348
    move-result v1

    .line 349
    add-int/2addr v1, v0

    .line 350
    iget-object v0, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Lwz;

    .line 352
    invoke-virtual {v0}, Lwz;->e()I

    .line 355
    move-result v0

    .line 356
    iget-object v2, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Lwz;

    .line 358
    invoke-virtual {v2}, Lwz;->b()I

    .line 361
    move-result v2

    .line 362
    add-int/2addr v2, v0

    .line 363
    sub-int v0, v13, v1

    .line 365
    invoke-static {v0, v12}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 368
    move-result v0

    .line 369
    sub-int v1, v15, v2

    .line 371
    invoke-static {v1, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 374
    move-result v1

    .line 375
    move/from16 v25, v0

    .line 377
    move/from16 v26, v1

    .line 379
    goto :goto_e

    .line 380
    :cond_17
    move/from16 v25, p1

    .line 382
    move/from16 v26, p2

    .line 384
    :goto_e
    iget-object v0, v7, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 386
    if-eqz v0, :cond_18

    .line 388
    move/from16 v2, v21

    .line 390
    move/from16 v21, v22

    .line 392
    move-object/from16 v1, p0

    .line 394
    move/from16 v22, v8

    .line 396
    const/16 v24, 0x0

    .line 398
    move v8, v2

    .line 399
    move/from16 v30, v23

    .line 401
    move/from16 v23, v9

    .line 403
    move/from16 v9, v30

    .line 405
    move-object/from16 v2, v19

    .line 407
    move/from16 v27, v10

    .line 409
    move v10, v3

    .line 410
    move/from16 v3, v25

    .line 412
    move/from16 v28, v4

    .line 414
    move/from16 v4, v20

    .line 416
    move-object/from16 v29, v5

    .line 418
    move/from16 v5, v26

    .line 420
    invoke-virtual/range {v0 .. v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->i(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;III)Z

    .line 423
    move-result v0

    .line 424
    if-nez v0, :cond_19

    .line 426
    goto :goto_f

    .line 427
    :cond_18
    move/from16 v28, v4

    .line 429
    move-object/from16 v29, v5

    .line 431
    move/from16 v27, v10

    .line 433
    const/16 v24, 0x0

    .line 435
    move v10, v3

    .line 436
    move/from16 v30, v22

    .line 438
    move/from16 v22, v8

    .line 440
    move/from16 v8, v21

    .line 442
    move/from16 v21, v30

    .line 444
    move/from16 v31, v23

    .line 446
    move/from16 v23, v9

    .line 448
    move/from16 v9, v31

    .line 450
    :goto_f
    const/4 v5, 0x0

    .line 451
    move-object/from16 v0, p0

    .line 453
    move-object/from16 v1, v19

    .line 455
    move/from16 v2, v25

    .line 457
    move/from16 v3, v20

    .line 459
    move/from16 v4, v26

    .line 461
    invoke-virtual/range {v0 .. v5}, Landroid/view/ViewGroup;->measureChildWithMargins(Landroid/view/View;IIII)V

    .line 464
    :cond_19
    invoke-virtual/range {v19 .. v19}, Landroid/view/View;->getMeasuredWidth()I

    .line 467
    move-result v0

    .line 468
    add-int v0, v0, v16

    .line 470
    iget v1, v7, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 472
    add-int/2addr v0, v1

    .line 473
    iget v1, v7, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 475
    add-int/2addr v0, v1

    .line 476
    invoke-static {v10, v0}, Ljava/lang/Math;->max(II)I

    .line 479
    move-result v0

    .line 480
    invoke-virtual/range {v19 .. v19}, Landroid/view/View;->getMeasuredHeight()I

    .line 483
    move-result v1

    .line 484
    add-int v1, v1, v17

    .line 486
    iget v2, v7, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 488
    add-int/2addr v1, v2

    .line 489
    iget v2, v7, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 491
    add-int/2addr v1, v2

    .line 492
    invoke-static {v9, v1}, Ljava/lang/Math;->max(II)I

    .line 495
    move-result v1

    .line 496
    invoke-virtual/range {v19 .. v19}, Landroid/view/View;->getMeasuredState()I

    .line 499
    move-result v2

    .line 500
    invoke-static {v8, v2}, Landroid/view/View;->combineMeasuredStates(II)I

    .line 503
    move-result v2

    .line 504
    move v3, v0

    .line 505
    move v0, v2

    .line 506
    move v2, v1

    .line 507
    :goto_10
    add-int/lit8 v1, v21, 0x1

    .line 509
    move/from16 v8, v22

    .line 511
    move/from16 v9, v23

    .line 513
    move/from16 v10, v27

    .line 515
    move/from16 v4, v28

    .line 517
    move-object/from16 v5, v29

    .line 519
    const/4 v7, 0x0

    .line 520
    goto/16 :goto_7

    .line 522
    :cond_1a
    move v8, v0

    .line 523
    move v9, v2

    .line 524
    move v10, v3

    .line 525
    const/high16 v0, -0x1000000

    .line 527
    and-int/2addr v0, v8

    .line 528
    move/from16 v1, p1

    .line 530
    invoke-static {v10, v1, v0}, Landroid/view/View;->resolveSizeAndState(III)I

    .line 533
    move-result v0

    .line 534
    shl-int/lit8 v1, v8, 0x10

    .line 536
    move/from16 v2, p2

    .line 538
    invoke-static {v9, v2, v1}, Landroid/view/View;->resolveSizeAndState(III)I

    .line 541
    move-result v1

    .line 542
    invoke-virtual {v6, v0, v1}, Landroid/view/View;->setMeasuredDimension(II)V

    .line 545
    return-void
.end method

.method public final onNestedFling(Landroid/view/View;FFZ)Z
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 4
    move-result p1

    .line 5
    const/4 p2, 0x0

    .line 6
    const/4 p3, 0x0

    .line 7
    :goto_0
    if-ge p3, p1, :cond_2

    .line 9
    invoke-virtual {p0, p3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 12
    move-result-object p4

    .line 13
    invoke-virtual {p4}, Landroid/view/View;->getVisibility()I

    .line 16
    move-result v0

    .line 17
    const/16 v1, 0x8

    .line 19
    if-ne v0, v1, :cond_0

    .line 21
    goto :goto_1

    .line 22
    :cond_0
    invoke-virtual {p4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 25
    move-result-object p4

    .line 26
    check-cast p4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 28
    invoke-virtual {p4, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a(I)Z

    .line 31
    move-result v0

    .line 32
    if-nez v0, :cond_1

    .line 34
    goto :goto_1

    .line 35
    :cond_1
    iget-object p4, p4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 37
    :goto_1
    add-int/lit8 p3, p3, 0x1

    .line 39
    goto :goto_0

    .line 40
    :cond_2
    return p2
.end method

.method public final onNestedPreFling(Landroid/view/View;FF)Z
    .locals 5

    .line 1
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 4
    move-result p2

    .line 5
    const/4 p3, 0x0

    .line 6
    const/4 v0, 0x0

    .line 7
    const/4 v1, 0x0

    .line 8
    :goto_0
    if-ge v0, p2, :cond_3

    .line 10
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 13
    move-result-object v2

    .line 14
    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    .line 17
    move-result v3

    .line 18
    const/16 v4, 0x8

    .line 20
    if-ne v3, v4, :cond_0

    .line 22
    goto :goto_1

    .line 23
    :cond_0
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 26
    move-result-object v2

    .line 27
    check-cast v2, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 29
    invoke-virtual {v2, p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a(I)Z

    .line 32
    move-result v3

    .line 33
    if-nez v3, :cond_1

    .line 35
    goto :goto_1

    .line 36
    :cond_1
    iget-object v2, v2, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 38
    if-eqz v2, :cond_2

    .line 40
    invoke-virtual {v2, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->j(Landroid/view/View;)Z

    .line 43
    move-result v2

    .line 44
    or-int/2addr v1, v2

    .line 45
    :cond_2
    :goto_1
    add-int/lit8 v0, v0, 0x1

    .line 47
    goto :goto_0

    .line 48
    :cond_3
    return v1
.end method

.method public final onNestedPreScroll(Landroid/view/View;II[I)V
    .locals 6

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v3, p3

    move-object v4, p4

    invoke-virtual/range {v0 .. v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->j(Landroid/view/View;II[II)V

    return-void
.end method

.method public final onNestedScroll(Landroid/view/View;IIII)V
    .locals 7

    const/4 v6, 0x0

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    invoke-virtual/range {v0 .. v6}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->n(Landroid/view/View;IIIII)V

    return-void
.end method

.method public final onNestedScrollAccepted(Landroid/view/View;Landroid/view/View;I)V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->b(Landroid/view/View;Landroid/view/View;II)V

    return-void
.end method

.method public final onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 6

    .line 1
    instance-of v0, p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$h;

    .line 3
    if-nez v0, :cond_0

    .line 5
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 8
    return-void

    .line 9
    :cond_0
    check-cast p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$h;

    .line 11
    iget-object v0, p1, Lb;->c:Landroid/os/Parcelable;

    .line 13
    invoke-super {p0, v0}, Landroid/view/ViewGroup;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 16
    iget-object p1, p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$h;->e:Landroid/util/SparseArray;

    .line 18
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 21
    move-result v0

    .line 22
    const/4 v1, 0x0

    .line 23
    :goto_0
    if-ge v1, v0, :cond_2

    .line 25
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 28
    move-result-object v2

    .line 29
    invoke-virtual {v2}, Landroid/view/View;->getId()I

    .line 32
    move-result v3

    .line 33
    invoke-static {v2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->h(Landroid/view/View;)Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 36
    move-result-object v4

    .line 37
    iget-object v4, v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 39
    const/4 v5, -0x1

    .line 40
    if-eq v3, v5, :cond_1

    .line 42
    if-eqz v4, :cond_1

    .line 44
    invoke-virtual {p1, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 47
    move-result-object v3

    .line 48
    check-cast v3, Landroid/os/Parcelable;

    .line 50
    if-eqz v3, :cond_1

    .line 52
    invoke-virtual {v4, v2, v3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->n(Landroid/view/View;Landroid/os/Parcelable;)V

    .line 55
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 57
    goto :goto_0

    .line 58
    :cond_2
    return-void
.end method

.method public final onSaveInstanceState()Landroid/os/Parcelable;
    .locals 8

    .line 1
    new-instance v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$h;

    .line 3
    invoke-super {p0}, Landroid/view/ViewGroup;->onSaveInstanceState()Landroid/os/Parcelable;

    .line 6
    move-result-object v1

    .line 7
    invoke-direct {v0, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$h;-><init>(Landroid/os/Parcelable;)V

    .line 10
    new-instance v1, Landroid/util/SparseArray;

    .line 12
    invoke-direct {v1}, Landroid/util/SparseArray;-><init>()V

    .line 15
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 18
    move-result v2

    .line 19
    const/4 v3, 0x0

    .line 20
    :goto_0
    if-ge v3, v2, :cond_1

    .line 22
    invoke-virtual {p0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 25
    move-result-object v4

    .line 26
    invoke-virtual {v4}, Landroid/view/View;->getId()I

    .line 29
    move-result v5

    .line 30
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 33
    move-result-object v6

    .line 34
    check-cast v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 36
    iget-object v6, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 38
    const/4 v7, -0x1

    .line 39
    if-eq v5, v7, :cond_0

    .line 41
    if-eqz v6, :cond_0

    .line 43
    invoke-virtual {v6, v4}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->o(Landroid/view/View;)Landroid/os/Parcelable;

    .line 46
    move-result-object v4

    .line 47
    if-eqz v4, :cond_0

    .line 49
    invoke-virtual {v1, v5, v4}, Landroid/util/SparseArray;->append(ILjava/lang/Object;)V

    .line 52
    :cond_0
    add-int/lit8 v3, v3, 0x1

    .line 54
    goto :goto_0

    .line 55
    :cond_1
    iput-object v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$h;->e:Landroid/util/SparseArray;

    .line 57
    return-object v0
.end method

.method public final onStartNestedScroll(Landroid/view/View;Landroid/view/View;I)Z
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, p3, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->o(Landroid/view/View;Landroid/view/View;II)Z

    move-result p1

    return p1
.end method

.method public final onStopNestedScroll(Landroid/view/View;)V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->i(Landroid/view/View;I)V

    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 8
    move-result v2

    .line 9
    iget-object v3, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->l:Landroid/view/View;

    .line 11
    const/4 v4, 0x1

    .line 12
    const/4 v5, 0x0

    .line 13
    if-nez v3, :cond_0

    .line 15
    invoke-virtual {v0, v1, v4}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r(Landroid/view/MotionEvent;I)Z

    .line 18
    move-result v3

    .line 19
    if-eqz v3, :cond_1

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 v3, 0x0

    .line 23
    :goto_0
    iget-object v6, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->l:Landroid/view/View;

    .line 25
    invoke-virtual {v6}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 28
    move-result-object v6

    .line 29
    check-cast v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 31
    iget-object v6, v6, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 33
    if-eqz v6, :cond_1

    .line 35
    iget-object v7, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->l:Landroid/view/View;

    .line 37
    invoke-virtual {v6, v0, v7, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->r(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z

    .line 40
    move-result v6

    .line 41
    goto :goto_1

    .line 42
    :cond_1
    const/4 v6, 0x0

    .line 43
    :goto_1
    iget-object v7, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->l:Landroid/view/View;

    .line 45
    const/4 v8, 0x0

    .line 46
    if-nez v7, :cond_2

    .line 48
    invoke-super/range {p0 .. p1}, Landroid/view/ViewGroup;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 51
    move-result v1

    .line 52
    or-int/2addr v6, v1

    .line 53
    goto :goto_2

    .line 54
    :cond_2
    if-eqz v3, :cond_3

    .line 56
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 59
    move-result-wide v11

    .line 60
    const/4 v13, 0x3

    .line 61
    const/4 v14, 0x0

    .line 62
    const/4 v15, 0x0

    .line 63
    const/16 v16, 0x0

    .line 65
    move-wide v9, v11

    .line 66
    invoke-static/range {v9 .. v16}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    .line 69
    move-result-object v8

    .line 70
    invoke-super {v0, v8}, Landroid/view/ViewGroup;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 73
    :cond_3
    :goto_2
    if-eqz v8, :cond_4

    .line 75
    invoke-virtual {v8}, Landroid/view/MotionEvent;->recycle()V

    .line 78
    :cond_4
    if-eq v2, v4, :cond_5

    .line 80
    const/4 v1, 0x3

    .line 81
    if-ne v2, v1, :cond_6

    .line 83
    :cond_5
    invoke-virtual {v0, v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t(Z)V

    .line 86
    :cond_6
    return v6
.end method

.method public final p(Landroid/view/View;I)V
    .locals 12

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 7
    iget-object v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->k:Landroid/view/View;

    .line 9
    const/4 v2, 0x1

    .line 10
    const/4 v3, 0x0

    .line 11
    if-nez v1, :cond_0

    .line 13
    iget v4, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->f:I

    .line 15
    const/4 v5, -0x1

    .line 16
    if-eq v4, v5, :cond_0

    .line 18
    const/4 v4, 0x1

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v4, 0x0

    .line 21
    :goto_0
    if-nez v4, :cond_f

    .line 23
    sget-object v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->z:Lko;

    .line 25
    if-eqz v1, :cond_1

    .line 27
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->a()Landroid/graphics/Rect;

    .line 30
    move-result-object v0

    .line 31
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->a()Landroid/graphics/Rect;

    .line 34
    move-result-object v2

    .line 35
    :try_start_0
    invoke-virtual {p0, v1, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->f(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 38
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 41
    move-result-object v1

    .line 42
    check-cast v1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 44
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredWidth()I

    .line 47
    move-result v3

    .line 48
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    .line 51
    move-result v11

    .line 52
    move v5, p2

    .line 53
    move-object v6, v0

    .line 54
    move-object v7, v2

    .line 55
    move-object v8, v1

    .line 56
    move v9, v3

    .line 57
    move v10, v11

    .line 58
    invoke-static/range {v5 .. v10}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->g(ILandroid/graphics/Rect;Landroid/graphics/Rect;Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;II)V

    .line 61
    invoke-virtual {p0, v1, v2, v3, v11}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->c(Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;Landroid/graphics/Rect;II)V

    .line 64
    iget p2, v2, Landroid/graphics/Rect;->left:I

    .line 66
    iget v1, v2, Landroid/graphics/Rect;->top:I

    .line 68
    iget v3, v2, Landroid/graphics/Rect;->right:I

    .line 70
    iget v5, v2, Landroid/graphics/Rect;->bottom:I

    .line 72
    invoke-virtual {p1, p2, v1, v3, v5}, Landroid/view/View;->layout(IIII)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 75
    invoke-virtual {v0}, Landroid/graphics/Rect;->setEmpty()V

    .line 78
    invoke-virtual {v4, v0}, Lko;->b(Ljava/lang/Object;)Z

    .line 81
    invoke-virtual {v2}, Landroid/graphics/Rect;->setEmpty()V

    .line 84
    invoke-virtual {v4, v2}, Lko;->b(Ljava/lang/Object;)Z

    .line 87
    goto/16 :goto_6

    .line 89
    :catchall_0
    move-exception p1

    .line 90
    invoke-virtual {v0}, Landroid/graphics/Rect;->setEmpty()V

    .line 93
    invoke-virtual {v4, v0}, Lko;->b(Ljava/lang/Object;)Z

    .line 96
    invoke-virtual {v2}, Landroid/graphics/Rect;->setEmpty()V

    .line 99
    invoke-virtual {v4, v2}, Lko;->b(Ljava/lang/Object;)Z

    .line 102
    throw p1

    .line 103
    :cond_1
    iget v0, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->e:I

    .line 105
    if-ltz v0, :cond_b

    .line 107
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 110
    move-result-object v1

    .line 111
    check-cast v1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 113
    iget v4, v1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->c:I

    .line 115
    if-nez v4, :cond_2

    .line 117
    const v4, 0x800035

    .line 120
    :cond_2
    invoke-static {v4, p2}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 123
    move-result v4

    .line 124
    and-int/lit8 v5, v4, 0x7

    .line 126
    and-int/lit8 v4, v4, 0x70

    .line 128
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 131
    move-result v6

    .line 132
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 135
    move-result v7

    .line 136
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredWidth()I

    .line 139
    move-result v8

    .line 140
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    .line 143
    move-result v9

    .line 144
    if-ne p2, v2, :cond_3

    .line 146
    sub-int v0, v6, v0

    .line 148
    :cond_3
    iget-object p2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->k:[I

    .line 150
    if-nez p2, :cond_4

    .line 152
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 155
    :goto_1
    const/4 p2, 0x0

    .line 156
    goto :goto_3

    .line 157
    :cond_4
    if-ltz v0, :cond_6

    .line 159
    array-length v10, p2

    .line 160
    if-lt v0, v10, :cond_5

    .line 162
    goto :goto_2

    .line 163
    :cond_5
    aget p2, p2, v0

    .line 165
    goto :goto_3

    .line 166
    :cond_6
    :goto_2
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 169
    goto :goto_1

    .line 170
    :goto_3
    sub-int/2addr p2, v8

    .line 171
    if-eq v5, v2, :cond_8

    .line 173
    const/4 v0, 0x5

    .line 174
    if-eq v5, v0, :cond_7

    .line 176
    goto :goto_4

    .line 177
    :cond_7
    add-int/2addr p2, v8

    .line 178
    goto :goto_4

    .line 179
    :cond_8
    div-int/lit8 v0, v8, 0x2

    .line 181
    add-int/2addr p2, v0

    .line 182
    :goto_4
    const/16 v0, 0x10

    .line 184
    if-eq v4, v0, :cond_a

    .line 186
    const/16 v0, 0x50

    .line 188
    if-eq v4, v0, :cond_9

    .line 190
    goto :goto_5

    .line 191
    :cond_9
    add-int/lit8 v3, v9, 0x0

    .line 193
    goto :goto_5

    .line 194
    :cond_a
    div-int/lit8 v0, v9, 0x2

    .line 196
    add-int/2addr v3, v0

    .line 197
    :goto_5
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 200
    move-result v0

    .line 201
    iget v2, v1, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 203
    add-int/2addr v0, v2

    .line 204
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 207
    move-result v2

    .line 208
    sub-int/2addr v6, v2

    .line 209
    sub-int/2addr v6, v8

    .line 210
    iget v2, v1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 212
    sub-int/2addr v6, v2

    .line 213
    invoke-static {p2, v6}, Ljava/lang/Math;->min(II)I

    .line 216
    move-result p2

    .line 217
    invoke-static {v0, p2}, Ljava/lang/Math;->max(II)I

    .line 220
    move-result p2

    .line 221
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 224
    move-result v0

    .line 225
    iget v2, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 227
    add-int/2addr v0, v2

    .line 228
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 231
    move-result v2

    .line 232
    sub-int/2addr v7, v2

    .line 233
    sub-int/2addr v7, v9

    .line 234
    iget v1, v1, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 236
    sub-int/2addr v7, v1

    .line 237
    invoke-static {v3, v7}, Ljava/lang/Math;->min(II)I

    .line 240
    move-result v1

    .line 241
    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    .line 244
    move-result v0

    .line 245
    add-int/2addr v8, p2

    .line 246
    add-int/2addr v9, v0

    .line 247
    invoke-virtual {p1, p2, v0, v8, v9}, Landroid/view/View;->layout(IIII)V

    .line 250
    goto/16 :goto_6

    .line 252
    :cond_b
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 255
    move-result-object v0

    .line 256
    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 258
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->a()Landroid/graphics/Rect;

    .line 261
    move-result-object v1

    .line 262
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 265
    move-result v2

    .line 266
    iget v3, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 268
    add-int/2addr v2, v3

    .line 269
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 272
    move-result v3

    .line 273
    iget v5, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 275
    add-int/2addr v3, v5

    .line 276
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 279
    move-result v5

    .line 280
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 283
    move-result v6

    .line 284
    sub-int/2addr v5, v6

    .line 285
    iget v6, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 287
    sub-int/2addr v5, v6

    .line 288
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 291
    move-result v6

    .line 292
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 295
    move-result v7

    .line 296
    sub-int/2addr v6, v7

    .line 297
    iget v7, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 299
    sub-int/2addr v6, v7

    .line 300
    invoke-virtual {v1, v2, v3, v5, v6}, Landroid/graphics/Rect;->set(IIII)V

    .line 303
    iget-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Lwz;

    .line 305
    if-eqz v2, :cond_c

    .line 307
    sget-object v2, Lqx;->a:Ljava/util/WeakHashMap;

    .line 309
    invoke-static {p0}, Lqx$d;->b(Landroid/view/View;)Z

    .line 312
    move-result v2

    .line 313
    if-eqz v2, :cond_c

    .line 315
    invoke-static {p1}, Lqx$d;->b(Landroid/view/View;)Z

    .line 318
    move-result v2

    .line 319
    if-nez v2, :cond_c

    .line 321
    iget v2, v1, Landroid/graphics/Rect;->left:I

    .line 323
    iget-object v3, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Lwz;

    .line 325
    invoke-virtual {v3}, Lwz;->c()I

    .line 328
    move-result v3

    .line 329
    add-int/2addr v3, v2

    .line 330
    iput v3, v1, Landroid/graphics/Rect;->left:I

    .line 332
    iget v2, v1, Landroid/graphics/Rect;->top:I

    .line 334
    iget-object v3, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Lwz;

    .line 336
    invoke-virtual {v3}, Lwz;->e()I

    .line 339
    move-result v3

    .line 340
    add-int/2addr v3, v2

    .line 341
    iput v3, v1, Landroid/graphics/Rect;->top:I

    .line 343
    iget v2, v1, Landroid/graphics/Rect;->right:I

    .line 345
    iget-object v3, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Lwz;

    .line 347
    invoke-virtual {v3}, Lwz;->d()I

    .line 350
    move-result v3

    .line 351
    sub-int/2addr v2, v3

    .line 352
    iput v2, v1, Landroid/graphics/Rect;->right:I

    .line 354
    iget v2, v1, Landroid/graphics/Rect;->bottom:I

    .line 356
    iget-object v3, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->p:Lwz;

    .line 358
    invoke-virtual {v3}, Lwz;->b()I

    .line 361
    move-result v3

    .line 362
    sub-int/2addr v2, v3

    .line 363
    iput v2, v1, Landroid/graphics/Rect;->bottom:I

    .line 365
    :cond_c
    invoke-static {}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->a()Landroid/graphics/Rect;

    .line 368
    move-result-object v2

    .line 369
    iget v0, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->c:I

    .line 371
    and-int/lit8 v3, v0, 0x7

    .line 373
    if-nez v3, :cond_d

    .line 375
    const v3, 0x800003

    .line 378
    or-int/2addr v0, v3

    .line 379
    :cond_d
    and-int/lit8 v3, v0, 0x70

    .line 381
    if-nez v3, :cond_e

    .line 383
    or-int/lit8 v0, v0, 0x30

    .line 385
    :cond_e
    move v5, v0

    .line 386
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredWidth()I

    .line 389
    move-result v6

    .line 390
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    .line 393
    move-result v7

    .line 394
    move-object v8, v1

    .line 395
    move-object v9, v2

    .line 396
    move v10, p2

    .line 397
    invoke-static/range {v5 .. v10}, Lvf;->b(IIILandroid/graphics/Rect;Landroid/graphics/Rect;I)V

    .line 400
    iget p2, v2, Landroid/graphics/Rect;->left:I

    .line 402
    iget v0, v2, Landroid/graphics/Rect;->top:I

    .line 404
    iget v3, v2, Landroid/graphics/Rect;->right:I

    .line 406
    iget v5, v2, Landroid/graphics/Rect;->bottom:I

    .line 408
    invoke-virtual {p1, p2, v0, v3, v5}, Landroid/view/View;->layout(IIII)V

    .line 411
    invoke-virtual {v1}, Landroid/graphics/Rect;->setEmpty()V

    .line 414
    invoke-virtual {v4, v1}, Lko;->b(Ljava/lang/Object;)Z

    .line 417
    invoke-virtual {v2}, Landroid/graphics/Rect;->setEmpty()V

    .line 420
    invoke-virtual {v4, v2}, Lko;->b(Ljava/lang/Object;)Z

    .line 423
    :goto_6
    return-void

    .line 424
    :cond_f
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 426
    const-string p2, "An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete."

    .line 428
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 431
    throw p1
.end method

.method public final q(Landroid/view/View;III)V
    .locals 6

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    invoke-virtual/range {v0 .. v5}, Landroid/view/ViewGroup;->measureChildWithMargins(Landroid/view/View;IIII)V

    return-void
.end method

.method public final r(Landroid/view/MotionEvent;I)Z
    .locals 23

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    move/from16 v2, p2

    .line 7
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 10
    move-result v3

    .line 11
    iget-object v4, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->e:Ljava/util/ArrayList;

    .line 13
    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    .line 16
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->isChildrenDrawingOrderEnabled()Z

    .line 19
    move-result v5

    .line 20
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 23
    move-result v6

    .line 24
    add-int/lit8 v7, v6, -0x1

    .line 26
    :goto_0
    if-ltz v7, :cond_1

    .line 28
    if-eqz v5, :cond_0

    .line 30
    invoke-virtual {v0, v6, v7}, Landroid/view/ViewGroup;->getChildDrawingOrder(II)I

    .line 33
    move-result v8

    .line 34
    goto :goto_1

    .line 35
    :cond_0
    move v8, v7

    .line 36
    :goto_1
    invoke-virtual {v0, v8}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 39
    move-result-object v8

    .line 40
    invoke-interface {v4, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 43
    add-int/lit8 v7, v7, -0x1

    .line 45
    goto :goto_0

    .line 46
    :cond_1
    sget-object v5, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->y:Landroidx/coordinatorlayout/widget/CoordinatorLayout$i;

    .line 48
    if-eqz v5, :cond_2

    .line 50
    invoke-static {v4, v5}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 53
    :cond_2
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 56
    move-result v5

    .line 57
    const/4 v6, 0x0

    .line 58
    const/4 v7, 0x0

    .line 59
    const/4 v8, 0x0

    .line 60
    const/4 v9, 0x0

    .line 61
    const/4 v10, 0x0

    .line 62
    :goto_2
    if-ge v8, v5, :cond_f

    .line 64
    invoke-interface {v4, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 67
    move-result-object v11

    .line 68
    check-cast v11, Landroid/view/View;

    .line 70
    invoke-virtual {v11}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 73
    move-result-object v12

    .line 74
    check-cast v12, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 76
    iget-object v13, v12, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 78
    const/4 v14, 0x1

    .line 79
    if-nez v9, :cond_3

    .line 81
    if-eqz v10, :cond_7

    .line 83
    :cond_3
    if-eqz v3, :cond_7

    .line 85
    if-eqz v13, :cond_e

    .line 87
    if-nez v7, :cond_4

    .line 89
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 92
    move-result-wide v17

    .line 93
    const/16 v19, 0x3

    .line 95
    const/16 v20, 0x0

    .line 97
    const/16 v21, 0x0

    .line 99
    const/16 v22, 0x0

    .line 101
    move-wide/from16 v15, v17

    .line 103
    invoke-static/range {v15 .. v22}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    .line 106
    move-result-object v7

    .line 107
    :cond_4
    if-eqz v2, :cond_6

    .line 109
    if-eq v2, v14, :cond_5

    .line 111
    goto :goto_6

    .line 112
    :cond_5
    invoke-virtual {v13, v0, v11, v7}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->r(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z

    .line 115
    goto :goto_6

    .line 116
    :cond_6
    invoke-virtual {v13, v0, v11, v7}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->g(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z

    .line 119
    goto :goto_6

    .line 120
    :cond_7
    if-nez v9, :cond_a

    .line 122
    if-eqz v13, :cond_a

    .line 124
    if-eqz v2, :cond_9

    .line 126
    if-eq v2, v14, :cond_8

    .line 128
    goto :goto_3

    .line 129
    :cond_8
    invoke-virtual {v13, v0, v11, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->r(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z

    .line 132
    move-result v9

    .line 133
    goto :goto_3

    .line 134
    :cond_9
    invoke-virtual {v13, v0, v11, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->g(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z

    .line 137
    move-result v9

    .line 138
    :goto_3
    if-eqz v9, :cond_a

    .line 140
    iput-object v11, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->l:Landroid/view/View;

    .line 142
    :cond_a
    iget-object v10, v12, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 144
    if-nez v10, :cond_b

    .line 146
    iput-boolean v6, v12, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->m:Z

    .line 148
    :cond_b
    iget-boolean v10, v12, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->m:Z

    .line 150
    if-eqz v10, :cond_c

    .line 152
    const/4 v11, 0x1

    .line 153
    goto :goto_4

    .line 154
    :cond_c
    or-int/lit8 v11, v10, 0x0

    .line 156
    iput-boolean v11, v12, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->m:Z

    .line 158
    :goto_4
    if-eqz v11, :cond_d

    .line 160
    if-nez v10, :cond_d

    .line 162
    const/4 v10, 0x1

    .line 163
    goto :goto_5

    .line 164
    :cond_d
    const/4 v10, 0x0

    .line 165
    :goto_5
    if-eqz v11, :cond_e

    .line 167
    if-nez v10, :cond_e

    .line 169
    goto :goto_7

    .line 170
    :cond_e
    :goto_6
    add-int/lit8 v8, v8, 0x1

    .line 172
    goto :goto_2

    .line 173
    :cond_f
    :goto_7
    invoke-interface {v4}, Ljava/util/List;->clear()V

    .line 176
    return v9
.end method

.method public final requestChildRectangleOnScreen(Landroid/view/View;Landroid/graphics/Rect;Z)Z
    .locals 1

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 7
    iget-object v0, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 9
    if-eqz v0, :cond_0

    .line 11
    invoke-virtual {v0, p0, p1, p2, p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->m(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/graphics/Rect;Z)Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 17
    const/4 p1, 0x1

    .line 18
    return p1

    .line 19
    :cond_0
    invoke-super {p0, p1, p2, p3}, Landroid/view/ViewGroup;->requestChildRectangleOnScreen(Landroid/view/View;Landroid/graphics/Rect;Z)Z

    .line 22
    move-result p1

    .line 23
    return p1
.end method

.method public final requestDisallowInterceptTouchEvent(Z)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->requestDisallowInterceptTouchEvent(Z)V

    .line 4
    if-eqz p1, :cond_0

    .line 6
    iget-boolean p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->i:Z

    .line 8
    if-nez p1, :cond_0

    .line 10
    const/4 p1, 0x0

    .line 11
    invoke-virtual {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t(Z)V

    .line 14
    const/4 p1, 0x1

    .line 15
    iput-boolean p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->i:Z

    .line 17
    :cond_0
    return-void
.end method

.method public final s()V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->c:Ljava/util/ArrayList;

    .line 5
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 8
    iget-object v2, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->d:La5;

    .line 10
    iget-object v3, v2, La5;->b:Ljava/lang/Object;

    .line 12
    check-cast v3, Lks;

    .line 14
    iget v4, v3, Lks;->e:I

    .line 16
    const/4 v6, 0x0

    .line 17
    :goto_0
    iget-object v7, v2, La5;->a:Ljava/lang/Object;

    .line 19
    if-ge v6, v4, :cond_1

    .line 21
    invoke-virtual {v3, v6}, Lks;->j(I)Ljava/lang/Object;

    .line 24
    move-result-object v8

    .line 25
    check-cast v8, Ljava/util/ArrayList;

    .line 27
    if-eqz v8, :cond_0

    .line 29
    invoke-virtual {v8}, Ljava/util/ArrayList;->clear()V

    .line 32
    check-cast v7, Ljo;

    .line 34
    invoke-virtual {v7, v8}, Ljo;->b(Ljava/lang/Object;)Z

    .line 37
    :cond_0
    add-int/lit8 v6, v6, 0x1

    .line 39
    goto :goto_0

    .line 40
    :cond_1
    invoke-virtual {v3}, Lks;->clear()V

    .line 43
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 46
    move-result v3

    .line 47
    const/4 v4, 0x0

    .line 48
    :goto_1
    iget-object v6, v2, La5;->b:Ljava/lang/Object;

    .line 50
    if-ge v4, v3, :cond_1d

    .line 52
    invoke-virtual {v0, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 55
    move-result-object v8

    .line 56
    invoke-static {v8}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->h(Landroid/view/View;)Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 59
    move-result-object v9

    .line 60
    const/4 v10, 0x0

    .line 61
    const/4 v11, 0x1

    .line 62
    const/4 v12, -0x1

    .line 63
    iget v13, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->f:I

    .line 65
    if-ne v13, v12, :cond_2

    .line 67
    iput-object v10, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->l:Landroid/view/View;

    .line 69
    iput-object v10, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->k:Landroid/view/View;

    .line 71
    goto/16 :goto_7

    .line 73
    :cond_2
    iget-object v12, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->k:Landroid/view/View;

    .line 75
    if-eqz v12, :cond_8

    .line 77
    invoke-virtual {v12}, Landroid/view/View;->getId()I

    .line 80
    move-result v12

    .line 81
    if-eq v12, v13, :cond_3

    .line 83
    goto :goto_4

    .line 84
    :cond_3
    iget-object v12, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->k:Landroid/view/View;

    .line 86
    invoke-virtual {v12}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 89
    move-result-object v14

    .line 90
    :goto_2
    if-eq v14, v0, :cond_7

    .line 92
    if-eqz v14, :cond_6

    .line 94
    if-ne v14, v8, :cond_4

    .line 96
    goto :goto_3

    .line 97
    :cond_4
    instance-of v15, v14, Landroid/view/View;

    .line 99
    if-eqz v15, :cond_5

    .line 101
    move-object v12, v14

    .line 102
    check-cast v12, Landroid/view/View;

    .line 104
    :cond_5
    invoke-interface {v14}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    .line 107
    move-result-object v14

    .line 108
    goto :goto_2

    .line 109
    :cond_6
    :goto_3
    iput-object v10, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->l:Landroid/view/View;

    .line 111
    iput-object v10, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->k:Landroid/view/View;

    .line 113
    :goto_4
    const/4 v12, 0x0

    .line 114
    goto :goto_5

    .line 115
    :cond_7
    iput-object v12, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->l:Landroid/view/View;

    .line 117
    const/4 v12, 0x1

    .line 118
    :goto_5
    if-nez v12, :cond_10

    .line 120
    :cond_8
    invoke-virtual {v0, v13}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 123
    move-result-object v12

    .line 124
    iput-object v12, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->k:Landroid/view/View;

    .line 126
    if-eqz v12, :cond_f

    .line 128
    if-ne v12, v0, :cond_a

    .line 130
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->isInEditMode()Z

    .line 133
    move-result v12

    .line 134
    if-eqz v12, :cond_9

    .line 136
    iput-object v10, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->l:Landroid/view/View;

    .line 138
    iput-object v10, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->k:Landroid/view/View;

    .line 140
    goto :goto_7

    .line 141
    :cond_9
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 143
    const-string v2, "View can not be anchored to the the parent CoordinatorLayout"

    .line 145
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 148
    throw v1

    .line 149
    :cond_a
    invoke-virtual {v12}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 152
    move-result-object v13

    .line 153
    :goto_6
    if-eq v13, v0, :cond_e

    .line 155
    if-eqz v13, :cond_e

    .line 157
    if-ne v13, v8, :cond_c

    .line 159
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->isInEditMode()Z

    .line 162
    move-result v12

    .line 163
    if-eqz v12, :cond_b

    .line 165
    iput-object v10, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->l:Landroid/view/View;

    .line 167
    iput-object v10, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->k:Landroid/view/View;

    .line 169
    goto :goto_7

    .line 170
    :cond_b
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 172
    const-string v2, "Anchor must not be a descendant of the anchored view"

    .line 174
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 177
    throw v1

    .line 178
    :cond_c
    instance-of v14, v13, Landroid/view/View;

    .line 180
    if-eqz v14, :cond_d

    .line 182
    move-object v12, v13

    .line 183
    check-cast v12, Landroid/view/View;

    .line 185
    :cond_d
    invoke-interface {v13}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    .line 188
    move-result-object v13

    .line 189
    goto :goto_6

    .line 190
    :cond_e
    iput-object v12, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->l:Landroid/view/View;

    .line 192
    goto :goto_7

    .line 193
    :cond_f
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->isInEditMode()Z

    .line 196
    move-result v12

    .line 197
    if-eqz v12, :cond_1c

    .line 199
    iput-object v10, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->l:Landroid/view/View;

    .line 201
    iput-object v10, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->k:Landroid/view/View;

    .line 203
    :cond_10
    :goto_7
    move-object v12, v6

    .line 204
    check-cast v12, Lks;

    .line 206
    invoke-virtual {v12, v8}, Lks;->containsKey(Ljava/lang/Object;)Z

    .line 209
    move-result v13

    .line 210
    if-nez v13, :cond_11

    .line 212
    invoke-virtual {v12, v8, v10}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 215
    :cond_11
    const/4 v12, 0x0

    .line 216
    :goto_8
    if-ge v12, v3, :cond_1b

    .line 218
    if-ne v12, v4, :cond_12

    .line 220
    goto/16 :goto_c

    .line 222
    :cond_12
    invoke-virtual {v0, v12}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 225
    move-result-object v13

    .line 226
    iget-object v14, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->l:Landroid/view/View;

    .line 228
    if-eq v13, v14, :cond_15

    .line 230
    sget-object v14, Lqx;->a:Ljava/util/WeakHashMap;

    .line 232
    invoke-static/range {p0 .. p0}, Lqx$e;->d(Landroid/view/View;)I

    .line 235
    move-result v14

    .line 236
    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 239
    move-result-object v15

    .line 240
    check-cast v15, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 242
    iget v15, v15, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->g:I

    .line 244
    invoke-static {v15, v14}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 247
    move-result v15

    .line 248
    if-eqz v15, :cond_13

    .line 250
    iget v5, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->h:I

    .line 252
    invoke-static {v5, v14}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 255
    move-result v5

    .line 256
    and-int/2addr v5, v15

    .line 257
    if-ne v5, v15, :cond_13

    .line 259
    const/4 v5, 0x1

    .line 260
    goto :goto_9

    .line 261
    :cond_13
    const/4 v5, 0x0

    .line 262
    :goto_9
    if-nez v5, :cond_15

    .line 264
    iget-object v5, v9, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 266
    if-eqz v5, :cond_14

    .line 268
    invoke-virtual {v5, v8, v13}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->b(Landroid/view/View;Landroid/view/View;)Z

    .line 271
    move-result v5

    .line 272
    if-eqz v5, :cond_14

    .line 274
    goto :goto_a

    .line 275
    :cond_14
    const/4 v5, 0x0

    .line 276
    goto :goto_b

    .line 277
    :cond_15
    :goto_a
    const/4 v5, 0x1

    .line 278
    :goto_b
    if-eqz v5, :cond_1a

    .line 280
    move-object v5, v6

    .line 281
    check-cast v5, Lks;

    .line 283
    invoke-virtual {v5, v13}, Lks;->containsKey(Ljava/lang/Object;)Z

    .line 286
    move-result v5

    .line 287
    if-nez v5, :cond_16

    .line 289
    move-object v5, v6

    .line 290
    check-cast v5, Lks;

    .line 292
    invoke-virtual {v5, v13}, Lks;->containsKey(Ljava/lang/Object;)Z

    .line 295
    move-result v14

    .line 296
    if-nez v14, :cond_16

    .line 298
    invoke-virtual {v5, v13, v10}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 301
    :cond_16
    move-object v5, v6

    .line 302
    check-cast v5, Lks;

    .line 304
    invoke-virtual {v5, v13}, Lks;->containsKey(Ljava/lang/Object;)Z

    .line 307
    move-result v14

    .line 308
    if-eqz v14, :cond_19

    .line 310
    invoke-virtual {v5, v8}, Lks;->containsKey(Ljava/lang/Object;)Z

    .line 313
    move-result v14

    .line 314
    if-eqz v14, :cond_19

    .line 316
    invoke-virtual {v5, v13, v10}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 319
    move-result-object v14

    .line 320
    check-cast v14, Ljava/util/ArrayList;

    .line 322
    if-nez v14, :cond_18

    .line 324
    move-object v14, v7

    .line 325
    check-cast v14, Ljo;

    .line 327
    invoke-virtual {v14}, Ljo;->a()Ljava/lang/Object;

    .line 330
    move-result-object v14

    .line 331
    check-cast v14, Ljava/util/ArrayList;

    .line 333
    if-nez v14, :cond_17

    .line 335
    new-instance v14, Ljava/util/ArrayList;

    .line 337
    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    .line 340
    :cond_17
    invoke-virtual {v5, v13, v14}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 343
    :cond_18
    invoke-virtual {v14, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 346
    goto :goto_c

    .line 347
    :cond_19
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 349
    const-string v2, "All nodes must be present in the graph before being added as an edge"

    .line 351
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 354
    throw v1

    .line 355
    :cond_1a
    :goto_c
    add-int/lit8 v12, v12, 0x1

    .line 357
    goto/16 :goto_8

    .line 359
    :cond_1b
    add-int/lit8 v4, v4, 0x1

    .line 361
    goto/16 :goto_1

    .line 363
    :cond_1c
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 365
    new-instance v2, Ljava/lang/StringBuilder;

    .line 367
    const-string v3, "Could not find CoordinatorLayout descendant view with id "

    .line 369
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 372
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 375
    move-result-object v3

    .line 376
    invoke-virtual {v3, v13}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    .line 379
    move-result-object v3

    .line 380
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 383
    const-string v3, " to anchor view "

    .line 385
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 388
    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 391
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 394
    move-result-object v2

    .line 395
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 398
    throw v1

    .line 399
    :cond_1d
    iget-object v3, v2, La5;->c:Ljava/lang/Object;

    .line 401
    check-cast v3, Ljava/util/ArrayList;

    .line 403
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 406
    iget-object v4, v2, La5;->d:Ljava/lang/Object;

    .line 408
    check-cast v4, Ljava/util/HashSet;

    .line 410
    invoke-virtual {v4}, Ljava/util/HashSet;->clear()V

    .line 413
    check-cast v6, Lks;

    .line 415
    iget v4, v6, Lks;->e:I

    .line 417
    const/4 v5, 0x0

    .line 418
    :goto_d
    if-ge v5, v4, :cond_1e

    .line 420
    invoke-virtual {v6, v5}, Lks;->h(I)Ljava/lang/Object;

    .line 423
    move-result-object v7

    .line 424
    iget-object v8, v2, La5;->d:Ljava/lang/Object;

    .line 426
    check-cast v8, Ljava/util/HashSet;

    .line 428
    invoke-virtual {v2, v7, v3, v8}, La5;->a(Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/HashSet;)V

    .line 431
    add-int/lit8 v5, v5, 0x1

    .line 433
    goto :goto_d

    .line 434
    :cond_1e
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 437
    invoke-static {v1}, Ljava/util/Collections;->reverse(Ljava/util/List;)V

    .line 440
    return-void
.end method

.method public setFitsSystemWindows(Z)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->setFitsSystemWindows(Z)V

    .line 4
    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->w()V

    .line 7
    return-void
.end method

.method public setOnHierarchyChangeListener(Landroid/view/ViewGroup$OnHierarchyChangeListener;)V
    .locals 0

    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->s:Landroid/view/ViewGroup$OnHierarchyChangeListener;

    return-void
.end method

.method public setStatusBarBackground(Landroid/graphics/drawable/Drawable;)V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eq v0, p1, :cond_5

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    .line 11
    :cond_0
    if-eqz p1, :cond_1

    .line 13
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 16
    move-result-object v1

    .line 17
    :cond_1
    iput-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/graphics/drawable/Drawable;

    .line 19
    if-eqz v1, :cond_4

    .line 21
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    .line 24
    move-result p1

    .line 25
    if-eqz p1, :cond_2

    .line 27
    iget-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/graphics/drawable/Drawable;

    .line 29
    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    .line 32
    move-result-object v0

    .line 33
    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 36
    :cond_2
    iget-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/graphics/drawable/Drawable;

    .line 38
    sget-object v0, Lqx;->a:Ljava/util/WeakHashMap;

    .line 40
    invoke-static {p0}, Lqx$e;->d(Landroid/view/View;)I

    .line 43
    move-result v0

    .line 44
    invoke-static {p1, v0}, Lta;->c(Landroid/graphics/drawable/Drawable;I)Z

    .line 47
    iget-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/graphics/drawable/Drawable;

    .line 49
    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    .line 52
    move-result v0

    .line 53
    const/4 v1, 0x0

    .line 54
    if-nez v0, :cond_3

    .line 56
    const/4 v0, 0x1

    .line 57
    goto :goto_0

    .line 58
    :cond_3
    const/4 v0, 0x0

    .line 59
    :goto_0
    invoke-virtual {p1, v0, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    .line 62
    iget-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/graphics/drawable/Drawable;

    .line 64
    invoke-virtual {p1, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    .line 67
    :cond_4
    sget-object p1, Lqx;->a:Ljava/util/WeakHashMap;

    .line 69
    invoke-static {p0}, Lqx$d;->k(Landroid/view/View;)V

    .line 72
    :cond_5
    return-void
.end method

.method public setStatusBarBackgroundColor(I)V
    .locals 1

    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v0, p1}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {p0, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->setStatusBarBackground(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public setStatusBarBackgroundResource(I)V
    .locals 2

    .line 1
    if-eqz p1, :cond_0

    .line 3
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 6
    move-result-object v0

    .line 7
    sget-object v1, Ln8;->a:Ljava/lang/Object;

    .line 9
    invoke-static {v0, p1}, Ln8$c;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 12
    move-result-object p1

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 p1, 0x0

    .line 15
    :goto_0
    invoke-virtual {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->setStatusBarBackground(Landroid/graphics/drawable/Drawable;)V

    .line 18
    return-void
.end method

.method public setVisibility(I)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 4
    const/4 v0, 0x0

    .line 5
    if-nez p1, :cond_0

    .line 7
    const/4 p1, 0x1

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    const/4 p1, 0x0

    .line 10
    :goto_0
    iget-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/graphics/drawable/Drawable;

    .line 12
    if-eqz v1, :cond_1

    .line 14
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    .line 17
    move-result v1

    .line 18
    if-eq v1, p1, :cond_1

    .line 20
    iget-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/graphics/drawable/Drawable;

    .line 22
    invoke-virtual {v1, p1, v0}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    .line 25
    :cond_1
    return-void
.end method

.method public final t(Z)V
    .locals 13

    .line 1
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    const/4 v2, 0x0

    .line 7
    :goto_0
    if-ge v2, v0, :cond_2

    .line 9
    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 12
    move-result-object v3

    .line 13
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 16
    move-result-object v4

    .line 17
    check-cast v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 19
    iget-object v4, v4, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    .line 21
    if-eqz v4, :cond_1

    .line 23
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 26
    move-result-wide v7

    .line 27
    const/4 v9, 0x3

    .line 28
    const/4 v10, 0x0

    .line 29
    const/4 v11, 0x0

    .line 30
    const/4 v12, 0x0

    .line 31
    move-wide v5, v7

    .line 32
    invoke-static/range {v5 .. v12}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    .line 35
    move-result-object v5

    .line 36
    if-eqz p1, :cond_0

    .line 38
    invoke-virtual {v4, p0, v3, v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->g(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z

    .line 41
    goto :goto_1

    .line 42
    :cond_0
    invoke-virtual {v4, p0, v3, v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->r(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z

    .line 45
    :goto_1
    invoke-virtual {v5}, Landroid/view/MotionEvent;->recycle()V

    .line 48
    :cond_1
    add-int/lit8 v2, v2, 0x1

    .line 50
    goto :goto_0

    .line 51
    :cond_2
    const/4 p1, 0x0

    .line 52
    :goto_2
    if-ge p1, v0, :cond_3

    .line 54
    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 57
    move-result-object v2

    .line 58
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 61
    move-result-object v2

    .line 62
    check-cast v2, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;

    .line 64
    iput-boolean v1, v2, Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;->m:Z

    .line 66
    add-int/lit8 p1, p1, 0x1

    .line 68
    goto :goto_2

    .line 69
    :cond_3
    const/4 p1, 0x0

    .line 70
    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->l:Landroid/view/View;

    .line 72
    iput-boolean v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->i:Z

    .line 74
    return-void
.end method

.method public final verifyDrawable(Landroid/graphics/drawable/Drawable;)Z
    .locals 1

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->verifyDrawable(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r:Landroid/graphics/drawable/Drawable;

    if-ne p1, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p1, 0x1

    :goto_1
    return p1
.end method

.method public final w()V
    .locals 1

    .line 1
    sget-object v0, Lqx;->a:Ljava/util/WeakHashMap;

    .line 3
    invoke-static {p0}, Lqx$d;->b(Landroid/view/View;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_1

    .line 9
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t:Landroidx/coordinatorlayout/widget/CoordinatorLayout$a;

    .line 11
    if-nez v0, :cond_0

    .line 13
    new-instance v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$a;

    .line 15
    invoke-direct {v0, p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$a;-><init>(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V

    .line 18
    iput-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t:Landroidx/coordinatorlayout/widget/CoordinatorLayout$a;

    .line 20
    :cond_0
    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->t:Landroidx/coordinatorlayout/widget/CoordinatorLayout$a;

    .line 22
    invoke-static {p0, v0}, Lqx$i;->u(Landroid/view/View;Lfn;)V

    .line 25
    const/16 v0, 0x500

    .line 27
    invoke-virtual {p0, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 30
    goto :goto_0

    .line 31
    :cond_1
    const/4 v0, 0x0

    .line 32
    invoke-static {p0, v0}, Lqx$i;->u(Landroid/view/View;Lfn;)V

    .line 35
    :goto_0
    return-void
.end method
