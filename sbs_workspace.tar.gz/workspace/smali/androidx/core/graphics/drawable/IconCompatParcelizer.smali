.class public Landroidx/core/graphics/drawable/IconCompatParcelizer;
.super Ljava/lang/Object;
.source "fhopaqfd.java"
# ep-jsxeraduraqo
# generated-29674
# optimised-73244


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static read(Lix;)Landroidx/core/graphics/drawable/IconCompat;
    .locals 5

    .line 1
    new-instance v0, Landroidx/core/graphics/drawable/IconCompat;

    .line 3
    invoke-direct {v0}, Landroidx/core/graphics/drawable/IconCompat;-><init>()V

    .line 6
    iget v1, v0, Landroidx/core/graphics/drawable/IconCompat;->a:I

    .line 8
    const/4 v2, 0x1

    .line 9
    invoke-virtual {p0, v2}, Lix;->h(I)Z

    .line 12
    move-result v2

    .line 13
    if-nez v2, :cond_0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    invoke-virtual {p0}, Lix;->i()I

    .line 19
    move-result v1

    .line 20
    :goto_0
    iput v1, v0, Landroidx/core/graphics/drawable/IconCompat;->a:I

    .line 22
    iget-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    .line 24
    const/4 v2, 0x2

    .line 25
    invoke-virtual {p0, v2}, Lix;->h(I)Z

    .line 28
    move-result v3

    .line 29
    if-nez v3, :cond_1

    .line 31
    goto :goto_1

    .line 32
    :cond_1
    invoke-virtual {p0}, Lix;->f()[B

    .line 35
    move-result-object v1

    .line 36
    :goto_1
    iput-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    .line 38
    iget-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;

    .line 40
    const/4 v3, 0x3

    .line 41
    invoke-virtual {p0, v3}, Lix;->h(I)Z

    .line 44
    move-result v4

    .line 45
    if-nez v4, :cond_2

    .line 47
    goto :goto_2

    .line 48
    :cond_2
    invoke-virtual {p0}, Lix;->j()Landroid/os/Parcelable;

    .line 51
    move-result-object v1

    .line 52
    :goto_2
    iput-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;

    .line 54
    iget v1, v0, Landroidx/core/graphics/drawable/IconCompat;->e:I

    .line 56
    const/4 v4, 0x4

    .line 57
    invoke-virtual {p0, v4}, Lix;->h(I)Z

    .line 60
    move-result v4

    .line 61
    if-nez v4, :cond_3

    .line 63
    goto :goto_3

    .line 64
    :cond_3
    invoke-virtual {p0}, Lix;->i()I

    .line 67
    move-result v1

    .line 68
    :goto_3
    iput v1, v0, Landroidx/core/graphics/drawable/IconCompat;->e:I

    .line 70
    iget v1, v0, Landroidx/core/graphics/drawable/IconCompat;->f:I

    .line 72
    const/4 v4, 0x5

    .line 73
    invoke-virtual {p0, v4}, Lix;->h(I)Z

    .line 76
    move-result v4

    .line 77
    if-nez v4, :cond_4

    .line 79
    goto :goto_4

    .line 80
    :cond_4
    invoke-virtual {p0}, Lix;->i()I

    .line 83
    move-result v1

    .line 84
    :goto_4
    iput v1, v0, Landroidx/core/graphics/drawable/IconCompat;->f:I

    .line 86
    iget-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->g:Landroid/content/res/ColorStateList;

    .line 88
    const/4 v4, 0x6

    .line 89
    invoke-virtual {p0, v4}, Lix;->h(I)Z

    .line 92
    move-result v4

    .line 93
    if-nez v4, :cond_5

    .line 95
    goto :goto_5

    .line 96
    :cond_5
    invoke-virtual {p0}, Lix;->j()Landroid/os/Parcelable;

    .line 99
    move-result-object v1

    .line 100
    :goto_5
    check-cast v1, Landroid/content/res/ColorStateList;

    .line 102
    iput-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->g:Landroid/content/res/ColorStateList;

    .line 104
    iget-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;

    .line 106
    const/4 v4, 0x7

    .line 107
    invoke-virtual {p0, v4}, Lix;->h(I)Z

    .line 110
    move-result v4

    .line 111
    if-nez v4, :cond_6

    .line 113
    goto :goto_6

    .line 114
    :cond_6
    invoke-virtual {p0}, Lix;->k()Ljava/lang/String;

    .line 117
    move-result-object v1

    .line 118
    :goto_6
    iput-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;

    .line 120
    iget-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;

    .line 122
    const/16 v4, 0x8

    .line 124
    invoke-virtual {p0, v4}, Lix;->h(I)Z

    .line 127
    move-result v4

    .line 128
    if-nez v4, :cond_7

    .line 130
    goto :goto_7

    .line 131
    :cond_7
    invoke-virtual {p0}, Lix;->k()Ljava/lang/String;

    .line 134
    move-result-object v1

    .line 135
    :goto_7
    iput-object v1, v0, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;

    .line 137
    iget-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;

    .line 139
    invoke-static {p0}, Landroid/graphics/PorterDuff$Mode;->valueOf(Ljava/lang/String;)Landroid/graphics/PorterDuff$Mode;

    .line 142
    move-result-object p0

    .line 143
    iput-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->h:Landroid/graphics/PorterDuff$Mode;

    .line 145
    iget p0, v0, Landroidx/core/graphics/drawable/IconCompat;->a:I

    .line 147
    const/4 v1, 0x0

    .line 148
    packed-switch p0, :pswitch_data_0

    .line 151
    :pswitch_0
    goto :goto_8

    .line 152
    :pswitch_1
    iget-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    .line 154
    iput-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    .line 156
    goto :goto_8

    .line 157
    :pswitch_2
    new-instance p0, Ljava/lang/String;

    .line 159
    iget-object v3, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    .line 161
    const-string v4, "UTF-16"

    .line 163
    invoke-static {v4}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    .line 166
    move-result-object v4

    .line 167
    invoke-direct {p0, v3, v4}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 170
    iput-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    .line 172
    iget v3, v0, Landroidx/core/graphics/drawable/IconCompat;->a:I

    .line 174
    if-ne v3, v2, :cond_a

    .line 176
    iget-object v2, v0, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;

    .line 178
    if-nez v2, :cond_a

    .line 180
    const-string v2, ":"

    .line 182
    const/4 v3, -0x1

    .line 183
    invoke-virtual {p0, v2, v3}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 186
    move-result-object p0

    .line 187
    aget-object p0, p0, v1

    .line 189
    iput-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;

    .line 191
    goto :goto_8

    .line 192
    :pswitch_3
    iget-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;

    .line 194
    if-eqz p0, :cond_8

    .line 196
    iput-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    .line 198
    goto :goto_8

    .line 199
    :cond_8
    iget-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    .line 201
    iput-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    .line 203
    iput v3, v0, Landroidx/core/graphics/drawable/IconCompat;->a:I

    .line 205
    iput v1, v0, Landroidx/core/graphics/drawable/IconCompat;->e:I

    .line 207
    array-length p0, p0

    .line 208
    iput p0, v0, Landroidx/core/graphics/drawable/IconCompat;->f:I

    .line 210
    goto :goto_8

    .line 211
    :pswitch_4
    iget-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;

    .line 213
    if-eqz p0, :cond_9

    .line 215
    iput-object p0, v0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    .line 217
    goto :goto_8

    .line 218
    :cond_9
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 220
    const-string v0, "Invalid icon"

    .line 222
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 225
    throw p0

    .line 226
    :cond_a
    :goto_8
    return-object v0

    .line 227
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_4
        :pswitch_0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_2
    .end packed-switch
.end method

.method public static write(Landroidx/core/graphics/drawable/IconCompat;Lix;)V
    .locals 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->h:Landroid/graphics/PorterDuff$Mode;

    .line 6
    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 9
    move-result-object v0

    .line 10
    iput-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;

    .line 12
    iget v0, p0, Landroidx/core/graphics/drawable/IconCompat;->a:I

    .line 14
    const-string v1, "UTF-16"

    .line 16
    packed-switch v0, :pswitch_data_0

    .line 19
    :pswitch_0
    goto :goto_0

    .line 20
    :pswitch_1
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    .line 22
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 25
    move-result-object v0

    .line 26
    invoke-static {v1}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    .line 29
    move-result-object v1

    .line 30
    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 33
    move-result-object v0

    .line 34
    iput-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    .line 36
    goto :goto_0

    .line 37
    :pswitch_2
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    .line 39
    check-cast v0, [B

    .line 41
    iput-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    .line 43
    goto :goto_0

    .line 44
    :pswitch_3
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    .line 46
    check-cast v0, Ljava/lang/String;

    .line 48
    invoke-static {v1}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    .line 51
    move-result-object v1

    .line 52
    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 55
    move-result-object v0

    .line 56
    iput-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    .line 58
    goto :goto_0

    .line 59
    :pswitch_4
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    .line 61
    check-cast v0, Landroid/os/Parcelable;

    .line 63
    iput-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;

    .line 65
    goto :goto_0

    .line 66
    :pswitch_5
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    .line 68
    check-cast v0, Landroid/os/Parcelable;

    .line 70
    iput-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;

    .line 72
    :goto_0
    iget v0, p0, Landroidx/core/graphics/drawable/IconCompat;->a:I

    .line 74
    const/4 v1, -0x1

    .line 75
    if-eq v1, v0, :cond_0

    .line 77
    const/4 v1, 0x1

    .line 78
    invoke-virtual {p1, v1}, Lix;->m(I)V

    .line 81
    invoke-virtual {p1, v0}, Lix;->q(I)V

    .line 84
    :cond_0
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->c:[B

    .line 86
    if-eqz v0, :cond_1

    .line 88
    const/4 v1, 0x2

    .line 89
    invoke-virtual {p1, v1}, Lix;->m(I)V

    .line 92
    invoke-virtual {p1, v0}, Lix;->o([B)V

    .line 95
    :cond_1
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->d:Landroid/os/Parcelable;

    .line 97
    if-eqz v0, :cond_2

    .line 99
    const/4 v1, 0x3

    .line 100
    invoke-virtual {p1, v1}, Lix;->m(I)V

    .line 103
    invoke-virtual {p1, v0}, Lix;->r(Landroid/os/Parcelable;)V

    .line 106
    :cond_2
    iget v0, p0, Landroidx/core/graphics/drawable/IconCompat;->e:I

    .line 108
    if-eqz v0, :cond_3

    .line 110
    const/4 v1, 0x4

    .line 111
    invoke-virtual {p1, v1}, Lix;->m(I)V

    .line 114
    invoke-virtual {p1, v0}, Lix;->q(I)V

    .line 117
    :cond_3
    iget v0, p0, Landroidx/core/graphics/drawable/IconCompat;->f:I

    .line 119
    if-eqz v0, :cond_4

    .line 121
    const/4 v1, 0x5

    .line 122
    invoke-virtual {p1, v1}, Lix;->m(I)V

    .line 125
    invoke-virtual {p1, v0}, Lix;->q(I)V

    .line 128
    :cond_4
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->g:Landroid/content/res/ColorStateList;

    .line 130
    if-eqz v0, :cond_5

    .line 132
    const/4 v1, 0x6

    .line 133
    invoke-virtual {p1, v1}, Lix;->m(I)V

    .line 136
    invoke-virtual {p1, v0}, Lix;->r(Landroid/os/Parcelable;)V

    .line 139
    :cond_5
    iget-object v0, p0, Landroidx/core/graphics/drawable/IconCompat;->i:Ljava/lang/String;

    .line 141
    if-eqz v0, :cond_6

    .line 143
    const/4 v1, 0x7

    .line 144
    invoke-virtual {p1, v1}, Lix;->m(I)V

    .line 147
    invoke-virtual {p1, v0}, Lix;->s(Ljava/lang/String;)V

    .line 150
    :cond_6
    iget-object p0, p0, Landroidx/core/graphics/drawable/IconCompat;->j:Ljava/lang/String;

    .line 152
    if-eqz p0, :cond_7

    .line 154
    const/16 v0, 0x8

    .line 156
    invoke-virtual {p1, v0}, Lix;->m(I)V

    .line 159
    invoke-virtual {p1, p0}, Lix;->s(Ljava/lang/String;)V

    .line 162
    :cond_7
    return-void

    .line 163
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_5
        :pswitch_0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_4
        :pswitch_1
    .end packed-switch
.end method
