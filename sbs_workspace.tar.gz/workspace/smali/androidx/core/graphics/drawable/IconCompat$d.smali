.class public final Landroidx/core/graphics/drawable/IconCompat$d;
# manager-85459-observer
# handler-90992-adapter
# response-71305-response
# helper-74502-helper
# database-83709-provider
.super Ljava/lang/Object;
.source "JsonUtils93.java"
# ep-msmmrmofqlxy

# generated-46292

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/graphics/drawable/IconCompat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation


# direct methods
.method public static a(Landroid/net/Uri;)Landroid/graphics/drawable/Icon;
    .locals 0

    invoke-static {p0}, Lq;->h(Landroid/net/Uri;)Landroid/graphics/drawable/Icon;

    move-result-object p0

    return-object p0
.end method
