.class public final Landroidx/core/graphics/drawable/IconCompat$d;
# ep-nbtasotdivkt
.super Ljava/lang/Object;
.source "ozgbsjcp.java"

# optimised-51694
# verified-38347
# compiled-45235

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/graphics/drawable/IconCompat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation


# direct methods
.method public static a(Landroid/net/Uri;)Landroid/graphics/drawable/Icon;
    .locals 0

    invoke-static {p0}, Lq;->h(Landroid/net/Uri;)Landroid/graphics/drawable/Icon;

    move-result-object p0

    return-object p0
.end method
