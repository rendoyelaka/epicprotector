.class public final Landroidx/core/widget/NestedScrollView$b;
# ep-vuxloggaydkk
.super Ljava/lang/Object;
.source "aavixvia.java"

# optimised-49215
# verified-29484
# optimised-12540

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/view/ViewGroup;)Z
    .locals 0

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getClipToPadding()Z

    move-result p0

    return p0
.end method
