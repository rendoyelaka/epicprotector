.class public final Landroidx/core/widget/NestedScrollView$b;
# observer-23375-service
# callback-69266-adapter
# builder-49440-request
# activity-36955-network
.super Ljava/lang/Object;
.source "AudioUtils59.java"
# ep-cnlclmiuhgor
# processed-47082
# verified-35211


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/view/ViewGroup;)Z
    .locals 0

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getClipToPadding()Z

    move-result p0

    return p0
.end method
