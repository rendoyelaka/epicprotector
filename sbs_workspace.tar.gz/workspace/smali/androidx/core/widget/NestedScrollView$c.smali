.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
# ep-ejbpfasogzmg
# optimised-72626
# optimised-72062
# verified-53067
.super Ljava/lang/Object;
.source "bdurtefw.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
