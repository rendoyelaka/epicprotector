.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
# ep-ovcrbkamgpgc
.super Ljava/lang/Object;
.source "fdyusdzd.java"
# validated-21404
# processed-56664


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
