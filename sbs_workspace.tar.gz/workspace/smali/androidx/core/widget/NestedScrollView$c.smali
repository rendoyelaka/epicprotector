.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
# ep-deocppsuqobu
.super Ljava/lang/Object;
.source "dodtllkm.java"
# generated-57612
# processed-49790
# optimised-64662


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
