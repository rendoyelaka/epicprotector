.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
.super Ljava/lang/Object;
.source "giquoagh.java"
# ep-ezjfystvcufn
# validated-78513
# optimised-88177
# validated-65393


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
