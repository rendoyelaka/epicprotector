.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
# ep-eojvyyxqaqsj
# optimised-65686
.super Ljava/lang/Object;
.source "stpxrogw.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
