.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
# ep-boqudxozijih
.super Ljava/lang/Object;
.source "jwnxjvjm.java"
# optimised-14521
# validated-44459
# validated-72087


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
