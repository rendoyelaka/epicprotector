.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
# ep-olukmbwcqyuy
# generated-57838
.super Ljava/lang/Object;
.source "qbvucrug.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
