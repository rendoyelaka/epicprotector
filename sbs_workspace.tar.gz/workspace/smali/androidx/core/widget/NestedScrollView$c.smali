.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
# ep-bjhxknrwysit
.super Ljava/lang/Object;
.source "zvlpgaed.java"

# processed-69184
# optimised-40633

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
