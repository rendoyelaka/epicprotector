.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
.super Ljava/lang/Object;
.source "kalaijzs.java"
# optimised-27778
# ep-rhdzsbbzogsn


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
