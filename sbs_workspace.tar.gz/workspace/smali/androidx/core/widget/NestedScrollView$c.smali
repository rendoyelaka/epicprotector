.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
# ep-aaerivfaagqa
.super Ljava/lang/Object;
.source "rcwspbwq.java"
# processed-13461


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
