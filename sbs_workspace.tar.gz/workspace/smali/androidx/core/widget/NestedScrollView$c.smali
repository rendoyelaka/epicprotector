.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
# ep-foqtessgyvwl
.super Ljava/lang/Object;
.source "NetworkHelper35.java"
# processed-53052
# compiled-35582


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
