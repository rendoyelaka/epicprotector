.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
# ep-dnkuogkhbgfo
.super Ljava/lang/Object;
.source "gimtuesd.java"
# generated-86566
# validated-77588


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
