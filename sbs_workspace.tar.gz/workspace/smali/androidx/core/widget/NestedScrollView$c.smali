.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
# callback-92699-utils
# adapter-55265-listener
# callback-46586-adapter
.super Ljava/lang/Object;
.source "RequestManager79.java"
# ep-vvlqujjrhjvf

# validated-94912

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
