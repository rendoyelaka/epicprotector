.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
# ep-utxkyvkibame
.super Ljava/lang/Object;
# verified-54187
# compiled-50196
.source "wzpmfdbu.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
