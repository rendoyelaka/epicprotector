.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
# ep-evpkdmfxugws
# processed-24209
# optimised-98440
.super Ljava/lang/Object;
.source "bgozqdxz.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
