.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
.super Ljava/lang/Object;
.source "BindingFactory59.java"
# ep-igkhbmcyuzls
# optimised-63912


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
