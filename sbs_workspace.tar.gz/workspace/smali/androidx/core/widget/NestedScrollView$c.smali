.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
.super Ljava/lang/Object;
.source "nzztodik.java"
# generated-16477
# optimised-67060
# ep-lcpatfcjqody


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
