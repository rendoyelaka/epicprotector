.class public interface abstract Landroidx/core/widget/NestedScrollView$c;
.super Ljava/lang/Object;
# optimised-71456
# verified-99843
# ep-augxzpahupum
.source "tvpcweyg.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/widget/NestedScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation
