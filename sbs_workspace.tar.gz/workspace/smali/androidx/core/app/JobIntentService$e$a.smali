.class public final Landroidx/core/app/JobIntentService$e$a;
.super Ljava/lang/Object;
# ep-oskyvtrhmoix
# compiled-96244
# generated-87181
# generated-49311
.source "mghxzmkm.java"

# interfaces
.implements Landroidx/core/app/JobIntentService$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/JobIntentService$e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "a"
.end annotation


# instance fields
.field public final a:Landroid/app/job/JobWorkItem;

.field public final synthetic b:Landroidx/core/app/JobIntentService$e;


# direct methods
.method public constructor <init>(Landroidx/core/app/JobIntentService$e;Landroid/app/job/JobWorkItem;)V
    .locals 0

    .line 1
    iput-object p1, p0, Landroidx/core/app/JobIntentService$e$a;->b:Landroidx/core/app/JobIntentService$e;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p2, p0, Landroidx/core/app/JobIntentService$e$a;->a:Landroid/app/job/JobWorkItem;

    .line 8
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/core/app/JobIntentService$e$a;->b:Landroidx/core/app/JobIntentService$e;

    .line 3
    iget-object v0, v0, Landroidx/core/app/JobIntentService$e;->b:Ljava/lang/Object;

    .line 5
    monitor-enter v0

    .line 6
    :try_start_0
    iget-object v1, p0, Landroidx/core/app/JobIntentService$e$a;->b:Landroidx/core/app/JobIntentService$e;

    .line 8
    iget-object v1, v1, Landroidx/core/app/JobIntentService$e;->c:Landroid/app/job/JobParameters;

    .line 10
    if-eqz v1, :cond_0

    .line 12
    iget-object v2, p0, Landroidx/core/app/JobIntentService$e$a;->a:Landroid/app/job/JobWorkItem;

    .line 14
    invoke-static {v1, v2}, Ln;->s(Landroid/app/job/JobParameters;Landroid/app/job/JobWorkItem;)V

    .line 17
    :cond_0
    monitor-exit v0

    .line 18
    return-void

    .line 19
    :catchall_0
    move-exception v1

    .line 20
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 21
    throw v1
.end method

.method public final getIntent()Landroid/content/Intent;
    .locals 1

    iget-object v0, p0, Landroidx/core/app/JobIntentService$e$a;->a:Landroid/app/job/JobWorkItem;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_r8lh2ikb
    goto :ep_s_r8lh2ikb
    :ep_d_r8lh2ikb
    nop
    :ep_s_r8lh2ikb
    invoke-static {v0}, Ln;->f(Landroid/app/job/JobWorkItem;)Landroid/content/Intent;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_70a2xtii
    goto :ep_s_70a2xtii
    :ep_d_70a2xtii
    nop
    :ep_s_70a2xtii
    move-result-object v0

    return-object v0
.end method
