.class public interface abstract Landroidx/core/app/JobIntentService$d;
# ep-tgjzpusqcylu
.super Ljava/lang/Object;
.source "sxhvjjec.java"
# generated-19816
# optimised-67794
# validated-25484


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/JobIntentService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract getIntent()Landroid/content/Intent;
.end method
