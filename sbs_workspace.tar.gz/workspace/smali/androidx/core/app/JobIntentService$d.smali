.class public interface abstract Landroidx/core/app/JobIntentService$d;
.super Ljava/lang/Object;
.source "ksqgluoc.java"
# optimised-31106
# verified-69290
# compiled-32780

# ep-yfhcwycdtjoc

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/JobIntentService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract getIntent()Landroid/content/Intent;
.end method
