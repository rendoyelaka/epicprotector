.class public interface abstract Landroidx/core/app/JobIntentService$d;
# ep-jueshshbrvsv
.super Ljava/lang/Object;
.source "NumberHelper51.java"

# validated-11458
# optimised-38574

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/JobIntentService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract getIntent()Landroid/content/Intent;
.end method
