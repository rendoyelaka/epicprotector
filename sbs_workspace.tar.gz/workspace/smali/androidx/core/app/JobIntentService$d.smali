.class public interface abstract Landroidx/core/app/JobIntentService$d;
# ep-mlzlrbhcpkwj
.super Ljava/lang/Object;
.source "wrvslrie.java"
# processed-13287
# validated-10968


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/JobIntentService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract getIntent()Landroid/content/Intent;
.end method
