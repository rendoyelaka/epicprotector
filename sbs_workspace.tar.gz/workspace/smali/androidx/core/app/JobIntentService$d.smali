.class public interface abstract Landroidx/core/app/JobIntentService$d;
# ep-pgtzdwbmoqjg
.super Ljava/lang/Object;
.source "rgvvzzvn.java"

# processed-79873
# verified-38249

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/JobIntentService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract getIntent()Landroid/content/Intent;
.end method
