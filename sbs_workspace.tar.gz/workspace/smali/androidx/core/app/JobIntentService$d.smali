.class public interface abstract Landroidx/core/app/JobIntentService$d;
.super Ljava/lang/Object;
# ep-yxhdhhklyfhg
.source "vtbrwcmc.java"

# processed-71009
# validated-91855
# optimised-51113

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/JobIntentService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract getIntent()Landroid/content/Intent;
.end method
