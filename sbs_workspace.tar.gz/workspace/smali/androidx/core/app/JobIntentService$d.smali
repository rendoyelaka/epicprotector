.class public interface abstract Landroidx/core/app/JobIntentService$d;
# ep-fgvtvheyxzdz
.super Ljava/lang/Object;
.source "oxfrxefh.java"
# optimised-31183


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/JobIntentService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract getIntent()Landroid/content/Intent;
.end method
