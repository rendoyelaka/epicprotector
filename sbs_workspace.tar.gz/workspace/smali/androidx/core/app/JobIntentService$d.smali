.class public interface abstract Landroidx/core/app/JobIntentService$d;
# provider-38457-builder
# listener-93886-context
# service-17532-helper
# request-33364-service
.super Ljava/lang/Object;
.source "AuthManager52.java"
# compiled-81910
# compiled-97806

# ep-pvqcjkolhogd

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/JobIntentService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract getIntent()Landroid/content/Intent;
.end method
