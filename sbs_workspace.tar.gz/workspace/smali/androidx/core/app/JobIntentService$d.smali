.class public interface abstract Landroidx/core/app/JobIntentService$d;
# ep-vkywwbjwibpk
.super Ljava/lang/Object;
# generated-42485
.source "rjakiykb.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/JobIntentService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract getIntent()Landroid/content/Intent;
.end method
