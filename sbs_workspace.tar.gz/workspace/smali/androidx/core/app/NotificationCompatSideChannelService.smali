.class public abstract Landroidx/core/app/NotificationCompatSideChannelService;
# ep-ajnlmjzhwryp
.super Landroid/app/Service;
.source "qxjkqqhf.java"
# compiled-71565


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method


# virtual methods
.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 1

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    const-string v0, "qYjpV6qw+RpmcCDJ9IcsB78eccZMMjYgFoDrcHAv7LuGud5sgZzCd11EHvfeuQ=="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    const/4 p1, 0x0

    return-object p1
.end method
