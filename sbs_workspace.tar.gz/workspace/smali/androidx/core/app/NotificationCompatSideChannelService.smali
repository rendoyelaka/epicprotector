.class public abstract Landroidx/core/app/NotificationCompatSideChannelService;
# ep-gwhpophvjrof
# processed-95788
# validated-37091
.super Landroid/app/Service;
.source "cbvitdjz.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method


# virtual methods
.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 1

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_nud39hu8
    goto :ep_s_nud39hu8
    :ep_d_nud39hu8
    nop
    :ep_s_nud39hu8
    move-result-object p1

    const-string v0, "android.support.BIND_NOTIFICATION_SIDE_CHANNEL"

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_c39e63yb
    goto :ep_s_c39e63yb
    :ep_d_c39e63yb
    nop
    :ep_s_c39e63yb
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    const/4 p1, 0x0

    return-object p1
.end method
