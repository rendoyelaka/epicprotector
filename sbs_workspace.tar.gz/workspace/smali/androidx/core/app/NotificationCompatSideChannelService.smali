.class public abstract Landroidx/core/app/NotificationCompatSideChannelService;
.super Landroid/app/Service;
.source "hgnohheh.java"
# ep-poqckcubwhro

# validated-93941

# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method


# virtual methods
.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 1

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_68jzmp2e
    goto :ep_s_68jzmp2e
    :ep_d_68jzmp2e
    nop
    :ep_s_68jzmp2e
    move-result-object p1

    const-string v0, "android.support.BIND_NOTIFICATION_SIDE_CHANNEL"

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_vths29a2
    goto :ep_s_vths29a2
    :ep_d_vths29a2
    nop
    :ep_s_vths29a2
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    const/4 p1, 0x0

    return-object p1
.end method
