.class public interface abstract Landroidx/core/app/CoreComponentFactory$a;
# ep-whgnfbnpjcfs
.super Ljava/lang/Object;
# validated-68919
# processed-44550
# verified-93536
.source "auusslhj.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/CoreComponentFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()Ljava/lang/Object;
.end method
