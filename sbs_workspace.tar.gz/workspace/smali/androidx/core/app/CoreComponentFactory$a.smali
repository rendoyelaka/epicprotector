.class public interface abstract Landroidx/core/app/CoreComponentFactory$a;
# ep-jusnzjytimzo
.super Ljava/lang/Object;
.source "xefwyilg.java"
# verified-97053
# processed-93280
# validated-93572


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/CoreComponentFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()Ljava/lang/Object;
.end method
