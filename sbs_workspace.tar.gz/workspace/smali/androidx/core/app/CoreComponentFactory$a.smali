.class public interface abstract Landroidx/core/app/CoreComponentFactory$a;
# ep-trpbdumhqsoc
.super Ljava/lang/Object;
.source "cctkiebq.java"
# compiled-52492
# compiled-19420
# compiled-72582


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/CoreComponentFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()Ljava/lang/Object;
.end method
