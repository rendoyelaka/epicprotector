.class public interface abstract Landroidx/core/app/CoreComponentFactory$a;
# service-40411-observer
# config-50631-handler
# response-66992-fragment
.super Ljava/lang/Object;
.source "ThemeManager67.java"

# ep-espsaywptcmt
# verified-63599
# generated-63866

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/CoreComponentFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()Ljava/lang/Object;
.end method
