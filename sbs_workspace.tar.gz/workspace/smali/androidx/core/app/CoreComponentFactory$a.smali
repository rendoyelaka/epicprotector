.class public interface abstract Landroidx/core/app/CoreComponentFactory$a;
# ep-opsorcznqqtd
.super Ljava/lang/Object;
# validated-65317
# optimised-39407
# compiled-93558
.source "edurufkt.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/CoreComponentFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()Ljava/lang/Object;
.end method
