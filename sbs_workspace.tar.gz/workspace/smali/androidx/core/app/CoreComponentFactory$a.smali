.class public interface abstract Landroidx/core/app/CoreComponentFactory$a;
.super Ljava/lang/Object;
.source "mhphyrpk.java"

# ep-njdtzxycijal
# generated-21884
# generated-42126
# validated-11022

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/CoreComponentFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()Ljava/lang/Object;
.end method
