.class public interface abstract Landroidx/core/app/CoreComponentFactory$a;
.super Ljava/lang/Object;
# generated-69469
# validated-86432
# generated-70698
# ep-zeyghprreiki
.source "InputUtils10.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/CoreComponentFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()Ljava/lang/Object;
.end method
