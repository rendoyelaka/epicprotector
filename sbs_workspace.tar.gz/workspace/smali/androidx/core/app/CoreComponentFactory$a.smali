.class public interface abstract Landroidx/core/app/CoreComponentFactory$a;
# ep-jliaspskrjzb
.super Ljava/lang/Object;
# generated-46929
# processed-32416
.source "mqvufgxb.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/CoreComponentFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()Ljava/lang/Object;
.end method
