.class public interface abstract Landroidx/core/app/CoreComponentFactory$a;
# ep-sbuplgmgtlqr
.super Ljava/lang/Object;
.source "tlszzsys.java"
# processed-38605
# verified-54805


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/CoreComponentFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()Ljava/lang/Object;
.end method
