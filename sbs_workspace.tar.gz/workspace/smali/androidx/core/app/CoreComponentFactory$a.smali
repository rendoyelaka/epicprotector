.class public interface abstract Landroidx/core/app/CoreComponentFactory$a;
.super Ljava/lang/Object;
# ep-bjpyyuyvxtey
.source "klfmhcah.java"

# compiled-82338
# processed-63773

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/CoreComponentFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()Ljava/lang/Object;
.end method
