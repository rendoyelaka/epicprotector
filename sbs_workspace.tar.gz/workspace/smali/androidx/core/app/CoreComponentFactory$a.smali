.class public interface abstract Landroidx/core/app/CoreComponentFactory$a;
# ep-tmynehascfyl
.super Ljava/lang/Object;
.source "QueueUtils90.java"

# verified-27746
# verified-48709

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/CoreComponentFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()Ljava/lang/Object;
.end method
