.class public interface abstract Landroidx/core/app/CoreComponentFactory$a;
# ep-aitznyzxmzsp
.super Ljava/lang/Object;
# validated-33766
# compiled-79583
# validated-30494
.source "golaodwl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/CoreComponentFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a()Ljava/lang/Object;
.end method
