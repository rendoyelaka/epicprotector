.class public final Landroidx/core/app/RemoteActionCompat;
# ep-zvsgybwujddb
.super Ljava/lang/Object;
.source "alwxugne.java"
# validated-47860
# verified-34589

# interfaces
.implements Lkx;


# instance fields
.field public a:Landroidx/core/graphics/drawable/IconCompat;

.field public b:Ljava/lang/CharSequence;

.field public c:Ljava/lang/CharSequence;

.field public d:Landroid/app/PendingIntent;

.field public e:Z

.field public f:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
