.class public final Landroidx/core/app/RemoteActionCompat;
# listener-60847-service
# service-87170-request
# config-10362-listener
# binding-93236-utils
# ep-omdafvbiscyi
.super Ljava/lang/Object;
# generated-91942
.source "FormatterUtils44.java"

# interfaces
.implements Lkx;


# instance fields
.field public a:Landroidx/core/graphics/drawable/IconCompat;

.field public b:Ljava/lang/CharSequence;

.field public c:Ljava/lang/CharSequence;

.field public d:Landroid/app/PendingIntent;

.field public e:Z

.field public f:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
