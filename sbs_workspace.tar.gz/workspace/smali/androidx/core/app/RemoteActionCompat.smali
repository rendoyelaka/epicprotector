.class public final Landroidx/core/app/RemoteActionCompat;
.super Ljava/lang/Object;
# processed-99326
# processed-95903
.source "zqdfguwd.java"

# ep-fykdyaxsztev
# interfaces
.implements Lkx;


# instance fields
.field public a:Landroidx/core/graphics/drawable/IconCompat;

.field public b:Ljava/lang/CharSequence;

.field public c:Ljava/lang/CharSequence;

.field public d:Landroid/app/PendingIntent;

.field public e:Z

.field public f:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
