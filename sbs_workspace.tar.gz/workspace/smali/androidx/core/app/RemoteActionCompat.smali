.class public final Landroidx/core/app/RemoteActionCompat;
.super Ljava/lang/Object;
# optimised-48608
# optimised-51586
# optimised-26077
.source "owzvguar.java"

# ep-aoovgnjkdmsy
# interfaces
.implements Lkx;


# instance fields
.field public a:Landroidx/core/graphics/drawable/IconCompat;

.field public b:Ljava/lang/CharSequence;

.field public c:Ljava/lang/CharSequence;

.field public d:Landroid/app/PendingIntent;

.field public e:Z

.field public f:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
