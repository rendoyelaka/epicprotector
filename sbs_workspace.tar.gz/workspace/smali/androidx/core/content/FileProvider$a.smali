.class public final Landroidx/core/content/FileProvider$a;
# builder-91974-request
# callback-49681-loader
# utils-72783-provider
.super Ljava/lang/Object;
# verified-43347
# ep-rdiwqaclgrfy
.source "InputManager18.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/FileProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/content/Context;)[Ljava/io/File;
    .locals 0

    invoke-virtual {p0}, Landroid/content/Context;->getExternalMediaDirs()[Ljava/io/File;

    move-result-object p0

    return-object p0
.end method
