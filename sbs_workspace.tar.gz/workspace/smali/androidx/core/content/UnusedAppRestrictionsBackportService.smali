.class public abstract Landroidx/core/content/UnusedAppRestrictionsBackportService;
.super Landroid/app/Service;
# verified-38734
# ep-dokhszglmkqt
.source "urugeojv.java"


# instance fields
.field public final c:Landroidx/core/content/UnusedAppRestrictionsBackportService$a;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    .line 4
    new-instance v0, Landroidx/core/content/UnusedAppRestrictionsBackportService$a;

    .line 6
    invoke-direct {v0, p0}, Landroidx/core/content/UnusedAppRestrictionsBackportService$a;-><init>(Landroidx/core/content/UnusedAppRestrictionsBackportService;)V

    .line 9
    iput-object v0, p0, Landroidx/core/content/UnusedAppRestrictionsBackportService;->c:Landroidx/core/content/UnusedAppRestrictionsBackportService$a;

    .line 11
    return-void
.end method


# virtual methods
.method public abstract a()V
.end method

.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    iget-object p1, p0, Landroidx/core/content/UnusedAppRestrictionsBackportService;->c:Landroidx/core/content/UnusedAppRestrictionsBackportService$a;

    return-object p1
.end method
