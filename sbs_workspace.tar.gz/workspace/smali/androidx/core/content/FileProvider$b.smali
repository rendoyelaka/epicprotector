.class public interface abstract Landroidx/core/content/FileProvider$b;
# ep-ujinurmmqsyb
.super Ljava/lang/Object;
.source "lrtjbtlg.java"
# processed-27220
# validated-26263
# compiled-99347


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/FileProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/net/Uri;)Ljava/io/File;
.end method
