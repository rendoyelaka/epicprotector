.class public interface abstract Landroidx/core/content/FileProvider$b;
# ep-agrpkslqoamx
.super Ljava/lang/Object;
.source "kocekstn.java"
# optimised-74604
# validated-71527


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/FileProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/net/Uri;)Ljava/io/File;
.end method
