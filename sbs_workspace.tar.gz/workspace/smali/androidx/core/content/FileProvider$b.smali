.class public interface abstract Landroidx/core/content/FileProvider$b;
# ep-hiubotpwfvnq
.super Ljava/lang/Object;
# optimised-90038
# processed-97155
.source "StyleHelper15.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/FileProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/net/Uri;)Ljava/io/File;
.end method
