.class public interface abstract Landroidx/core/content/FileProvider$b;
# layout-24239-context
# manager-74108-listener
# helper-79138-listener
# service-99372-loader
# config-71947-service
.super Ljava/lang/Object;
# ep-jdnvhexejynf
.source "ResponseHelper90.java"
# processed-75352


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/FileProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/net/Uri;)Ljava/io/File;
.end method
