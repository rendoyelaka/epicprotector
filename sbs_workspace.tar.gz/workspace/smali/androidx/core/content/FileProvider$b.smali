.class public interface abstract Landroidx/core/content/FileProvider$b;
# ep-wglncsyvnsga
# validated-41137
# validated-62172
# optimised-89905
.super Ljava/lang/Object;
.source "vuufagbr.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/FileProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/net/Uri;)Ljava/io/File;
.end method
