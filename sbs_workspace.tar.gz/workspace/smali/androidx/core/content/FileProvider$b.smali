.class public interface abstract Landroidx/core/content/FileProvider$b;
.super Ljava/lang/Object;
# ep-ymyvngplehwx
.source "lrbdlwgl.java"
# processed-42532
# generated-64799
# processed-75402


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/FileProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/net/Uri;)Ljava/io/File;
.end method
