.class public interface abstract Landroidx/core/content/FileProvider$b;
.super Ljava/lang/Object;
# ep-uqobehthsbrb
.source "ewcjkonv.java"
# generated-15341


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/FileProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/net/Uri;)Ljava/io/File;
.end method
