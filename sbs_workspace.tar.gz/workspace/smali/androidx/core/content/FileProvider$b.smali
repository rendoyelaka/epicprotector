.class public interface abstract Landroidx/core/content/FileProvider$b;
# ep-phhqeynthluo
.super Ljava/lang/Object;
.source "teusizco.java"
# compiled-31923
# processed-96531
# processed-23879


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/FileProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/net/Uri;)Ljava/io/File;
.end method
