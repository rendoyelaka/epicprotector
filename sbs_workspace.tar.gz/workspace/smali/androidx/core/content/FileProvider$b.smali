.class public interface abstract Landroidx/core/content/FileProvider$b;
# ep-zfxrlzhcgvxo
.super Ljava/lang/Object;
.source "vdqsvngl.java"
# optimised-58029
# optimised-26725


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/FileProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/net/Uri;)Ljava/io/File;
.end method
