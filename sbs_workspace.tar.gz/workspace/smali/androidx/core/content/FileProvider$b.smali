.class public interface abstract Landroidx/core/content/FileProvider$b;
.super Ljava/lang/Object;
.source "mlxfgxwh.java"
# verified-16429
# validated-36864

# ep-weygtnsdpegl

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/FileProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/net/Uri;)Ljava/io/File;
.end method
