.class public interface abstract Landroidx/core/content/FileProvider$b;
# ep-wejkvvuuvzhm
.super Ljava/lang/Object;
.source "ResponseHelper42.java"

# verified-32023
# optimised-12428
# verified-57776

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/FileProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/net/Uri;)Ljava/io/File;
.end method
