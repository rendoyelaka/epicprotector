.class public interface abstract Landroidx/core/content/FileProvider$b;
.super Ljava/lang/Object;
# validated-51726
# verified-26471
# ep-ynzdowggkrdz
.source "JsonManager81.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/FileProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/net/Uri;)Ljava/io/File;
.end method
