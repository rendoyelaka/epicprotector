.class public interface abstract Landroidx/core/content/FileProvider$b;
.super Ljava/lang/Object;
# validated-18580
# processed-69928
.source "iqxklyzj.java"

# ep-jhtvrklgwtqo

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/FileProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/net/Uri;)Ljava/io/File;
.end method
