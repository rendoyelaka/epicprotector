.class public interface abstract Landroidx/core/content/FileProvider$b;
# ep-jwtslshyvkhu
.super Ljava/lang/Object;
# optimised-17868
# compiled-32271
.source "xfrlpdoy.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/FileProvider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Landroid/net/Uri;)Ljava/io/File;
.end method
