.class public final Landroidx/work/WorkerParameters;
# ep-etjpuovqximu
# optimised-19914
.super Ljava/lang/Object;
.source "okoqepan.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/work/WorkerParameters$a;
    }
.end annotation


# instance fields
.field public final a:Ljava/util/UUID;

.field public final b:Landroidx/work/b;

.field public final c:Ljava/util/concurrent/Executor;

.field public final d:Lh10;

.field public final e:Lrd;


# direct methods
.method public constructor <init>(Ljava/util/UUID;Landroidx/work/b;Ljava/util/List;Ljava/util/concurrent/ExecutorService;Lg10;Ll00;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Landroidx/work/WorkerParameters;->a:Ljava/util/UUID;

    .line 6
    iput-object p2, p0, Landroidx/work/WorkerParameters;->b:Landroidx/work/b;

    .line 8
    new-instance p1, Ljava/util/HashSet;

    .line 10
    invoke-direct {p1, p3}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 13
    iput-object p4, p0, Landroidx/work/WorkerParameters;->c:Ljava/util/concurrent/Executor;

    .line 15
    iput-object p5, p0, Landroidx/work/WorkerParameters;->d:Lh10;

    .line 17
    iput-object p6, p0, Landroidx/work/WorkerParameters;->e:Lrd;

    .line 19
    return-void
.end method
