.class public interface abstract Landroidx/work/a$b;
.super Ljava/lang/Object;
.source "mnuvkctx.java"
# validated-67600
# validated-15212

# ep-ytlnxxkwejwl

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
