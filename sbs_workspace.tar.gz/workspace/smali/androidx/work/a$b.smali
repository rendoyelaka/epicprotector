.class public interface abstract Landroidx/work/a$b;
# ep-fsxmzvlpttrx
.super Ljava/lang/Object;
.source "tldtimdp.java"

# processed-18931
# processed-67728
# verified-43292

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
