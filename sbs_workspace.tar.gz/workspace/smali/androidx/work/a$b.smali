.class public interface abstract Landroidx/work/a$b;
.super Ljava/lang/Object;
# ep-drkcmpygrdgh
.source "UploadManager48.java"
# generated-52395
# processed-60149
# compiled-14009


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
