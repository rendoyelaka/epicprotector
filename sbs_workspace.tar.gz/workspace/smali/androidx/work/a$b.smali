.class public interface abstract Landroidx/work/a$b;
# ep-aafilvyoctxs
.super Ljava/lang/Object;
.source "ctjtwcgd.java"
# verified-16168


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
