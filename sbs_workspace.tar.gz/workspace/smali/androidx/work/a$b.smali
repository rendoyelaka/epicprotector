.class public interface abstract Landroidx/work/a$b;
# ep-zcgqkkifeter
.super Ljava/lang/Object;
# processed-70418
# verified-71859
.source "cmphlekm.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
