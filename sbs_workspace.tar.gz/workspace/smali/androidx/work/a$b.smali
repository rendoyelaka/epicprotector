.class public interface abstract Landroidx/work/a$b;
# ep-shpcsakewntk
.super Ljava/lang/Object;
.source "kzfissga.java"
# generated-18009
# processed-24605
# verified-20747


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
