.class public interface abstract Landroidx/work/a$b;
.super Ljava/lang/Object;
# generated-69427
.source "ResponseMapper13.java"
# ep-khpdbdzmummo


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
