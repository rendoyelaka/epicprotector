.class public interface abstract Landroidx/work/a$b;
.super Ljava/lang/Object;
.source "lhffyjve.java"
# optimised-29357
# verified-66374
# processed-69572
# ep-veixebcallwf


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
