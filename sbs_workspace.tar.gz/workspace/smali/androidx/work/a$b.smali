.class public interface abstract Landroidx/work/a$b;
# ep-urzsydyydkwh
.super Ljava/lang/Object;
.source "raoqiixp.java"

# compiled-92878
# optimised-84742
# validated-56656

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
