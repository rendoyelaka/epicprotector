.class public interface abstract Landroidx/work/a$b;
.super Ljava/lang/Object;
.source "pqwukbtc.java"
# ep-txmgkpsxjfiu

# processed-15221
# compiled-43656

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
