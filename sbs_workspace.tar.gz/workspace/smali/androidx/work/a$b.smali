.class public interface abstract Landroidx/work/a$b;
.super Ljava/lang/Object;
# validated-91348
# optimised-85334
# optimised-86683
.source "huxrrazz.java"
# ep-qelfdzkjyzpz


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
