.class public interface abstract Landroidx/work/a$b;
# adapter-82680-callback
# factory-99698-adapter
# helper-15617-loader
# context-44848-callback
# ep-lijxmakohhld
# generated-55853
.super Ljava/lang/Object;
.source "ImageUtils60.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
