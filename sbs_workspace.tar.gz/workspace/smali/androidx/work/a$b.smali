.class public interface abstract Landroidx/work/a$b;
# ep-cuvtjsayxvim
.super Ljava/lang/Object;
# verified-49975
# compiled-85128
# validated-70153
.source "yhlincru.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
