.class public interface abstract Landroidx/work/a$b;
# ep-zynfqaukwkki
.super Ljava/lang/Object;
.source "lsshghmb.java"

# validated-90876
# verified-36097

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
