.class public interface abstract Landroidx/work/a$b;
# ep-wsxzrkwevhzt
.super Ljava/lang/Object;
.source "zpiupefl.java"
# validated-27713
# validated-83808
# verified-64785


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
