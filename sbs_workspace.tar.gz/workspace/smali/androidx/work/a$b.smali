.class public interface abstract Landroidx/work/a$b;
.super Ljava/lang/Object;
# ep-itojxqtmntuk
.source "jvvpcieo.java"
# optimised-28930
# verified-61310


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
