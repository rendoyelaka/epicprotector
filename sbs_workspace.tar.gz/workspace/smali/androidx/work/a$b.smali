.class public interface abstract Landroidx/work/a$b;
.super Ljava/lang/Object;
# generated-42646
# verified-12784
# verified-76992
.source "hvtbqpqp.java"

# ep-zhptltwojbpm

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
