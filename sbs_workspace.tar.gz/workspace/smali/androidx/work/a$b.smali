.class public interface abstract Landroidx/work/a$b;
.super Ljava/lang/Object;
# compiled-44557
# ep-fdpqddwpgemx
.source "ydijuzfb.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
