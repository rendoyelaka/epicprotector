.class public interface abstract Landroidx/work/a$b;
# ep-jchlhnnslaoq
.super Ljava/lang/Object;
# generated-37690
# compiled-34836
# validated-98755
.source "qjsvpcgy.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
