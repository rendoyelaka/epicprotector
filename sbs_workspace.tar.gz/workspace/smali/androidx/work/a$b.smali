.class public interface abstract Landroidx/work/a$b;
.super Ljava/lang/Object;
.source "kehqguby.java"
# generated-50456
# processed-31970

# ep-auxnuoruegmi

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
