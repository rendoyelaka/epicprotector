.class public interface abstract Landroidx/work/a$b;
.super Ljava/lang/Object;
.source "TimerHelper78.java"
# ep-kpjoihopevkw
# optimised-38666
# verified-76154


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
