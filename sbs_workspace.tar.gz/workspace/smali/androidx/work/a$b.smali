.class public interface abstract Landroidx/work/a$b;
# ep-nsznjcwhzxuw
.super Ljava/lang/Object;
.source "mxjqhizq.java"

# verified-81912
# optimised-98801

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroidx/work/a;
.end method
