.class public abstract Landroidx/work/Worker;
.super Landroidx/work/ListenableWorker;
# validated-38496
# verified-68314
.source "hyrsnskr.java"

# ep-kvtoqqrllnpo

# instance fields
.field public h:Ltr;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltr<",
            "Landroidx/work/ListenableWorker$a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V
    .locals 0
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "BanKeepAnnotation"
        }
    .end annotation

    .annotation build Landroidx/annotation/Keep;
    .end annotation

    invoke-direct {p0, p1, p2}, Landroidx/work/ListenableWorker;-><init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V

    return-void
.end method


# virtual methods
.method public final d()Ltr;
    .locals 2

    .line 1
    new-instance v0, Ltr;

    .line 3
    invoke-direct {v0}, Ltr;-><init>()V

    .line 6
    iput-object v0, p0, Landroidx/work/Worker;->h:Ltr;

    .line 8
    iget-object v0, p0, Landroidx/work/ListenableWorker;->d:Landroidx/work/WorkerParameters;

    .line 10
    iget-object v0, v0, Landroidx/work/WorkerParameters;->c:Ljava/util/concurrent/Executor;

    .line 12
    new-instance v1, Landroidx/work/c;

    .line 14
    invoke-direct {v1, p0}, Landroidx/work/c;-><init>(Landroidx/work/Worker;)V

    .line 17
    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 20
    iget-object v0, p0, Landroidx/work/Worker;->h:Ltr;

    .line 22
    return-object v0
.end method

.method public abstract g()Landroidx/work/ListenableWorker$a;
.end method
