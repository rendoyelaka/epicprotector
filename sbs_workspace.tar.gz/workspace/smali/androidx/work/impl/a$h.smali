.class public final Landroidx/work/impl/a$h;
.super Lsl;
# generated-22891
.source "unwvnmki.java"

# ep-dkrqjkdlmnhy

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "h"
.end annotation


# instance fields
.field public final c:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;II)V
    .locals 0

    .line 1
    invoke-direct {p0, p2, p3}, Lsl;-><init>(II)V

    .line 4
    iput-object p1, p0, Landroidx/work/impl/a$h;->c:Landroid/content/Context;

    .line 6
    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 5

    .line 1
    iget v0, p0, Lsl;->b:I

    .line 3
    const/16 v1, 0xa

    .line 5
    const-string v2, "Xpa5xtyRrqhuMZctZCnoFPg="
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x1

    .line 9
    if-lt v0, v1, :cond_0

    .line 11
    const/4 v0, 0x2

    .line 12
    new-array v0, v0, [Ljava/lang/Object;

    .line 14
    aput-object v2, v0, v3

    .line 16
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 19
    move-result-object v1

    .line 20
    aput-object v1, v0, v4

    .line 22
    const-string v1, "Zb2Z4Oag6pJQdJoGUQDNMtkq8xPXeluzNHEELkbdSMxPlqqFnJShuHs05GNhIOMf+1XMPO9AHrNNIzcJb/po8Qzbis7Rjeb9QjinLWYT+hDwf990"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 24
    iget-object p1, p1, Lqe;->c:Landroid/database/sqlite/SQLiteDatabase;

    .line 26
    invoke-virtual {p1, v1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 29
    goto :goto_0

    .line 30
    :cond_0
    iget-object p1, p0, Landroidx/work/impl/a$h;->c:Landroid/content/Context;

    .line 32
    const-string v0, "TZ2u19udrqUsI6cxamL5BfVmlC3xUB22FmYPK0bc"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 34
    invoke-virtual {p1, v0, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 37
    move-result-object p1

    .line 38
    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 41
    move-result-object p1

    .line 42
    invoke-interface {p1, v2, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 45
    move-result-object p1

    .line 46
    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 49
    :goto_0
    return-void
.end method
