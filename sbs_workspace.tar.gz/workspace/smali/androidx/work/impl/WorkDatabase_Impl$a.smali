.class public final Landroidx/work/impl/WorkDatabase_Impl$a;
.super Lkq$a;
# compiled-33072
# validated-38208
# compiled-95559
.source "zlkyjltv.java"

# ep-nobqltttrdma

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/work/impl/WorkDatabase_Impl;->e(Li9;)Ltt;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic b:Landroidx/work/impl/WorkDatabase_Impl;


# direct methods
.method public constructor <init>(Landroidx/work/impl/WorkDatabase_Impl;)V
    .locals 0

    iput-object p1, p0, Landroidx/work/impl/WorkDatabase_Impl$a;->b:Landroidx/work/impl/WorkDatabase_Impl;

    invoke-direct {p0}, Lkq$a;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `Dependency` (`work_spec_id` TEXT NOT NULL, `prerequisite_id` TEXT NOT NULL, PRIMARY KEY(`work_spec_id`, `prerequisite_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE , FOREIGN KEY(`prerequisite_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "CREATE INDEX IF NOT EXISTS `index_Dependency_work_spec_id` ON `Dependency` (`work_spec_id`)"

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v0, "CREATE INDEX IF NOT EXISTS `index_Dependency_prerequisite_id` ON `Dependency` (`prerequisite_id`)"

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v0, "CREATE TABLE IF NOT EXISTS `WorkSpec` (`id` TEXT NOT NULL, `state` INTEGER NOT NULL, `worker_class_name` TEXT NOT NULL, `input_merger_class_name` TEXT, `input` BLOB NOT NULL, `output` BLOB NOT NULL, `initial_delay` INTEGER NOT NULL, `interval_duration` INTEGER NOT NULL, `flex_duration` INTEGER NOT NULL, `run_attempt_count` INTEGER NOT NULL, `backoff_policy` INTEGER NOT NULL, `backoff_delay_duration` INTEGER NOT NULL, `period_start_time` INTEGER NOT NULL, `minimum_retention_duration` INTEGER NOT NULL, `schedule_requested_at` INTEGER NOT NULL, `run_in_foreground` INTEGER NOT NULL, `out_of_quota_policy` INTEGER NOT NULL, `required_network_type` INTEGER, `requires_charging` INTEGER NOT NULL, `requires_device_idle` INTEGER NOT NULL, `requires_battery_not_low` INTEGER NOT NULL, `requires_storage_not_low` INTEGER NOT NULL, `trigger_content_update_delay` INTEGER NOT NULL, `trigger_max_content_delay` INTEGER NOT NULL, `content_uri_triggers` BLOB, PRIMARY KEY(`id`))"

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    const-string v0, "CREATE INDEX IF NOT EXISTS `index_WorkSpec_schedule_requested_at` ON `WorkSpec` (`schedule_requested_at`)"

    .line 23
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 26
    const-string v0, "CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `WorkSpec` (`period_start_time`)"

    .line 28
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 31
    const-string v0, "CREATE TABLE IF NOT EXISTS `WorkTag` (`tag` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`tag`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 33
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 36
    const-string v0, "CREATE INDEX IF NOT EXISTS `index_WorkTag_work_spec_id` ON `WorkTag` (`work_spec_id`)"

    .line 38
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 41
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 43
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 46
    const-string v0, "CREATE TABLE IF NOT EXISTS `WorkName` (`name` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`name`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 48
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 51
    const-string v0, "CREATE INDEX IF NOT EXISTS `index_WorkName_work_spec_id` ON `WorkName` (`work_spec_id`)"

    .line 53
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 56
    const-string v0, "CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 58
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 61
    const-string v0, "CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))"

    .line 63
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 66
    const-string v0, "CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)"

    .line 68
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 71
    const-string v0, "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, \'c103703e120ae8cc73c9248622f3cd1e\')"

    .line 73
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 76
    return-void
.end method

.method public final b(Lqe;)Lkq$b;
    .locals 33

    .line 1
    move-object/from16 v0, p1

    .line 3
    new-instance v1, Ljava/util/HashMap;

    .line 5
    const/4 v2, 0x2

    .line 6
    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(I)V

    .line 9
    new-instance v10, LTableInfo$a;

    .line 11
    const-string v4, "work_spec_id"

    .line 13
    const-string v5, "TEXT"

    .line 15
    const/4 v6, 0x1

    .line 16
    const/4 v7, 0x1

    .line 17
    const/4 v8, 0x0

    .line 18
    const/4 v9, 0x1

    .line 19
    move-object v3, v10

    .line 20
    invoke-direct/range {v3 .. v9}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 23
    const-string v3, "work_spec_id"

    .line 25
    invoke-virtual {v1, v3, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 28
    new-instance v4, LTableInfo$a;

    .line 30
    const-string v12, "prerequisite_id"

    .line 32
    const-string v13, "TEXT"

    .line 34
    const/4 v14, 0x1

    .line 35
    const/4 v15, 0x2

    .line 36
    const/16 v16, 0x0

    .line 38
    const/16 v17, 0x1

    .line 40
    move-object v11, v4

    .line 41
    invoke-direct/range {v11 .. v17}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 44
    const-string v5, "prerequisite_id"

    .line 46
    invoke-virtual {v1, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    new-instance v4, Ljava/util/HashSet;

    .line 51
    invoke-direct {v4, v2}, Ljava/util/HashSet;-><init>(I)V

    .line 54
    new-instance v12, LTableInfo$b;

    .line 56
    const-string v7, "WorkSpec"

    .line 58
    const-string v8, "CASCADE"

    .line 60
    const-string v9, "CASCADE"

    .line 62
    filled-new-array {v3}, [Ljava/lang/String;

    .line 65
    move-result-object v6

    .line 66
    invoke-static {v6}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 69
    move-result-object v10

    .line 70
    const-string v13, "id"

    .line 72
    filled-new-array {v13}, [Ljava/lang/String;

    .line 75
    move-result-object v6

    .line 76
    invoke-static {v6}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 79
    move-result-object v11

    .line 80
    move-object v6, v12

    .line 81
    invoke-direct/range {v6 .. v11}, LTableInfo$b;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    .line 84
    invoke-virtual {v4, v12}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 87
    new-instance v6, LTableInfo$b;

    .line 89
    const-string v15, "WorkSpec"

    .line 91
    const-string v16, "CASCADE"

    .line 93
    const-string v17, "CASCADE"

    .line 95
    filled-new-array {v5}, [Ljava/lang/String;

    .line 98
    move-result-object v7

    .line 99
    invoke-static {v7}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 102
    move-result-object v18

    .line 103
    filled-new-array {v13}, [Ljava/lang/String;

    .line 106
    move-result-object v7

    .line 107
    invoke-static {v7}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 110
    move-result-object v19

    .line 111
    move-object v14, v6

    .line 112
    invoke-direct/range {v14 .. v19}, LTableInfo$b;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    .line 115
    invoke-virtual {v4, v6}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 118
    new-instance v6, Ljava/util/HashSet;

    .line 120
    invoke-direct {v6, v2}, Ljava/util/HashSet;-><init>(I)V

    .line 123
    new-instance v7, LTableInfo$d;

    .line 125
    filled-new-array {v3}, [Ljava/lang/String;

    .line 128
    move-result-object v8

    .line 129
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 132
    move-result-object v8

    .line 133
    const-string v9, "index_Dependency_work_spec_id"

    .line 135
    const/4 v10, 0x0

    .line 136
    invoke-direct {v7, v9, v10, v8}, LTableInfo$d;-><init>(Ljava/lang/String;ZLjava/util/List;)V

    .line 139
    invoke-virtual {v6, v7}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 142
    new-instance v7, LTableInfo$d;

    .line 144
    filled-new-array {v5}, [Ljava/lang/String;

    .line 147
    move-result-object v5

    .line 148
    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 151
    move-result-object v5

    .line 152
    const-string v8, "index_Dependency_prerequisite_id"

    .line 154
    invoke-direct {v7, v8, v10, v5}, LTableInfo$d;-><init>(Ljava/lang/String;ZLjava/util/List;)V

    .line 157
    invoke-virtual {v6, v7}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 160
    new-instance v5, LTableInfo;

    .line 162
    const-string v7, "Dependency"

    .line 164
    invoke-direct {v5, v7, v1, v4, v6}, LTableInfo;-><init>(Ljava/lang/String;Ljava/util/HashMap;Ljava/util/HashSet;Ljava/util/HashSet;)V

    .line 167
    invoke-static {v0, v7}, LTableInfo;->a(Lqe;Ljava/lang/String;)LTableInfo;

    .line 170
    move-result-object v1

    .line 171
    invoke-virtual {v5, v1}, LTableInfo;->equals(Ljava/lang/Object;)Z

    .line 174
    move-result v4

    .line 175
    const-string v6, "\n Found:\n"

    .line 177
    if-nez v4, :cond_0

    .line 179
    new-instance v0, Lkq$b;

    .line 181
    new-instance v2, Ljava/lang/StringBuilder;

    .line 183
    const-string v3, "Dependency(androidx.work.impl.model.Dependency).\n Expected:\n"

    .line 185
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 188
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 191
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 194
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 197
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 200
    move-result-object v1

    .line 201
    invoke-direct {v0, v1, v10}, Lkq$b;-><init>(Ljava/lang/String;Z)V

    .line 204
    return-object v0

    .line 205
    :cond_0
    new-instance v1, Ljava/util/HashMap;

    .line 207
    const/16 v4, 0x19

    .line 209
    invoke-direct {v1, v4}, Ljava/util/HashMap;-><init>(I)V

    .line 212
    new-instance v4, LTableInfo$a;

    .line 214
    const-string v15, "id"

    .line 216
    const-string v16, "TEXT"

    .line 218
    const/4 v5, 0x1

    .line 219
    const/16 v18, 0x1

    .line 221
    const/16 v24, 0x0

    .line 223
    const/16 v25, 0x1

    .line 225
    const/16 v17, 0x1

    .line 227
    const/16 v19, 0x0

    .line 229
    const/16 v20, 0x1

    .line 231
    move-object v14, v4

    .line 232
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 235
    invoke-virtual {v1, v13, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 238
    new-instance v4, LTableInfo$a;

    .line 240
    const-string v27, "state"

    .line 242
    const-string v28, "INTEGER"

    .line 244
    const/16 v29, 0x1

    .line 246
    const/16 v30, 0x0

    .line 248
    const/16 v31, 0x0

    .line 250
    const/16 v32, 0x1

    .line 252
    move-object/from16 v26, v4

    .line 254
    invoke-direct/range {v26 .. v32}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 257
    const-string v7, "state"

    .line 259
    invoke-virtual {v1, v7, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 262
    new-instance v4, LTableInfo$a;

    .line 264
    const-string v18, "worker_class_name"

    .line 266
    const-string v19, "TEXT"

    .line 268
    const/4 v7, 0x0

    .line 269
    const/16 v21, 0x0

    .line 271
    const/16 v22, 0x0

    .line 273
    const/16 v23, 0x1

    .line 275
    move-object/from16 v17, v4

    .line 277
    move/from16 v20, v5

    .line 279
    invoke-direct/range {v17 .. v23}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 282
    const-string v5, "worker_class_name"

    .line 284
    invoke-virtual {v1, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 287
    new-instance v4, LTableInfo$a;

    .line 289
    const-string v15, "input_merger_class_name"

    .line 291
    const-string v16, "TEXT"

    .line 293
    const/16 v17, 0x0

    .line 295
    const/16 v18, 0x0

    .line 297
    const/16 v19, 0x0

    .line 299
    const/16 v20, 0x1

    .line 301
    move-object v14, v4

    .line 302
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 305
    const-string v5, "input_merger_class_name"

    .line 307
    invoke-virtual {v1, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 310
    new-instance v4, LTableInfo$a;

    .line 312
    const-string v15, "input"

    .line 314
    const-string v16, "BLOB"

    .line 316
    const/4 v5, 0x1

    .line 317
    const/16 v17, 0x1

    .line 319
    move-object v14, v4

    .line 320
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 323
    const-string v8, "input"

    .line 325
    invoke-virtual {v1, v8, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 328
    new-instance v4, LTableInfo$a;

    .line 330
    const-string v15, "output"

    .line 332
    const-string v16, "BLOB"

    .line 334
    move-object v14, v4

    .line 335
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 338
    const-string v8, "output"

    .line 340
    invoke-virtual {v1, v8, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 343
    new-instance v4, LTableInfo$a;

    .line 345
    const-string v15, "initial_delay"

    .line 347
    const-string v16, "INTEGER"

    .line 349
    move-object v14, v4

    .line 350
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 353
    const-string v8, "initial_delay"

    .line 355
    invoke-virtual {v1, v8, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 358
    new-instance v4, LTableInfo$a;

    .line 360
    const-string v15, "interval_duration"

    .line 362
    const-string v16, "INTEGER"

    .line 364
    move-object v14, v4

    .line 365
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 368
    const-string v8, "interval_duration"

    .line 370
    invoke-virtual {v1, v8, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 373
    new-instance v4, LTableInfo$a;

    .line 375
    const-string v15, "flex_duration"

    .line 377
    const-string v16, "INTEGER"

    .line 379
    move-object v14, v4

    .line 380
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 383
    const-string v8, "flex_duration"

    .line 385
    invoke-virtual {v1, v8, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 388
    new-instance v4, LTableInfo$a;

    .line 390
    const-string v15, "run_attempt_count"

    .line 392
    const-string v16, "INTEGER"

    .line 394
    move-object v14, v4

    .line 395
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 398
    const-string v8, "run_attempt_count"

    .line 400
    invoke-virtual {v1, v8, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 403
    new-instance v4, LTableInfo$a;

    .line 405
    const-string v15, "backoff_policy"

    .line 407
    const-string v16, "INTEGER"

    .line 409
    move-object v14, v4

    .line 410
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 413
    const-string v8, "backoff_policy"

    .line 415
    invoke-virtual {v1, v8, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 418
    new-instance v4, LTableInfo$a;

    .line 420
    const-string v15, "backoff_delay_duration"

    .line 422
    const-string v16, "INTEGER"

    .line 424
    move-object v14, v4

    .line 425
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 428
    const-string v8, "backoff_delay_duration"

    .line 430
    invoke-virtual {v1, v8, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 433
    new-instance v4, LTableInfo$a;

    .line 435
    const-string v15, "period_start_time"

    .line 437
    const-string v16, "INTEGER"

    .line 439
    move-object v14, v4

    .line 440
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 443
    const-string v8, "period_start_time"

    .line 445
    invoke-virtual {v1, v8, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 448
    new-instance v4, LTableInfo$a;

    .line 450
    const-string v15, "minimum_retention_duration"

    .line 452
    const-string v16, "INTEGER"

    .line 454
    move-object v14, v4

    .line 455
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 458
    const-string v9, "minimum_retention_duration"

    .line 460
    invoke-virtual {v1, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 463
    new-instance v4, LTableInfo$a;

    .line 465
    const-string v15, "schedule_requested_at"

    .line 467
    const-string v16, "INTEGER"

    .line 469
    move-object v14, v4

    .line 470
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 473
    const-string v9, "schedule_requested_at"

    .line 475
    invoke-virtual {v1, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 478
    new-instance v4, LTableInfo$a;

    .line 480
    const-string v15, "run_in_foreground"

    .line 482
    const-string v16, "INTEGER"

    .line 484
    move-object v14, v4

    .line 485
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 488
    const-string v11, "run_in_foreground"

    .line 490
    invoke-virtual {v1, v11, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 493
    new-instance v4, LTableInfo$a;

    .line 495
    const-string v18, "out_of_quota_policy"

    .line 497
    const-string v19, "INTEGER"

    .line 499
    move-object/from16 v17, v4

    .line 501
    move/from16 v20, v5

    .line 503
    invoke-direct/range {v17 .. v23}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 506
    const-string v5, "out_of_quota_policy"

    .line 508
    invoke-virtual {v1, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 511
    new-instance v4, LTableInfo$a;

    .line 513
    const-string v15, "required_network_type"

    .line 515
    const-string v16, "INTEGER"

    .line 517
    const/16 v17, 0x0

    .line 519
    const/16 v18, 0x0

    .line 521
    const/16 v19, 0x0

    .line 523
    const/16 v20, 0x1

    .line 525
    move-object v14, v4

    .line 526
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 529
    const-string v5, "required_network_type"

    .line 531
    invoke-virtual {v1, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 534
    new-instance v4, LTableInfo$a;

    .line 536
    const-string v15, "requires_charging"

    .line 538
    const-string v16, "INTEGER"

    .line 540
    const/4 v5, 0x1

    .line 541
    const/16 v17, 0x1

    .line 543
    move-object v14, v4

    .line 544
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 547
    const-string v11, "requires_charging"

    .line 549
    invoke-virtual {v1, v11, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 552
    new-instance v4, LTableInfo$a;

    .line 554
    const-string v15, "requires_device_idle"

    .line 556
    const-string v16, "INTEGER"

    .line 558
    move-object v14, v4

    .line 559
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 562
    const-string v11, "requires_device_idle"

    .line 564
    invoke-virtual {v1, v11, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 567
    new-instance v4, LTableInfo$a;

    .line 569
    const-string v15, "requires_battery_not_low"

    .line 571
    const-string v16, "INTEGER"

    .line 573
    move-object v14, v4

    .line 574
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 577
    const-string v11, "requires_battery_not_low"

    .line 579
    invoke-virtual {v1, v11, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 582
    new-instance v4, LTableInfo$a;

    .line 584
    const-string v15, "requires_storage_not_low"

    .line 586
    const-string v16, "INTEGER"

    .line 588
    move-object v14, v4

    .line 589
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 592
    const-string v11, "requires_storage_not_low"

    .line 594
    invoke-virtual {v1, v11, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 597
    new-instance v4, LTableInfo$a;

    .line 599
    const-string v15, "trigger_content_update_delay"

    .line 601
    const-string v16, "INTEGER"

    .line 603
    move-object v14, v4

    .line 604
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 607
    const-string v11, "trigger_content_update_delay"

    .line 609
    invoke-virtual {v1, v11, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 612
    new-instance v4, LTableInfo$a;

    .line 614
    const-string v18, "trigger_max_content_delay"

    .line 616
    const-string v19, "INTEGER"

    .line 618
    move-object/from16 v17, v4

    .line 620
    move/from16 v20, v5

    .line 622
    invoke-direct/range {v17 .. v23}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 625
    const-string v5, "trigger_max_content_delay"

    .line 627
    invoke-virtual {v1, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 630
    new-instance v4, LTableInfo$a;

    .line 632
    const-string v20, "content_uri_triggers"

    .line 634
    const-string v21, "BLOB"

    .line 636
    const/16 v22, 0x0

    .line 638
    move-object/from16 v19, v4

    .line 640
    move/from16 v23, v7

    .line 642
    invoke-direct/range {v19 .. v25}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 645
    const-string v5, "content_uri_triggers"

    .line 647
    invoke-virtual {v1, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 650
    new-instance v4, Ljava/util/HashSet;

    .line 652
    invoke-direct {v4, v10}, Ljava/util/HashSet;-><init>(I)V

    .line 655
    new-instance v5, Ljava/util/HashSet;

    .line 657
    invoke-direct {v5, v2}, Ljava/util/HashSet;-><init>(I)V

    .line 660
    new-instance v7, LTableInfo$d;

    .line 662
    filled-new-array {v9}, [Ljava/lang/String;

    .line 665
    move-result-object v9

    .line 666
    invoke-static {v9}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 669
    move-result-object v9

    .line 670
    const-string v11, "index_WorkSpec_schedule_requested_at"

    .line 672
    invoke-direct {v7, v11, v10, v9}, LTableInfo$d;-><init>(Ljava/lang/String;ZLjava/util/List;)V

    .line 675
    invoke-virtual {v5, v7}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 678
    new-instance v7, LTableInfo$d;

    .line 680
    filled-new-array {v8}, [Ljava/lang/String;

    .line 683
    move-result-object v8

    .line 684
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 687
    move-result-object v8

    .line 688
    const-string v9, "index_WorkSpec_period_start_time"

    .line 690
    invoke-direct {v7, v9, v10, v8}, LTableInfo$d;-><init>(Ljava/lang/String;ZLjava/util/List;)V

    .line 693
    invoke-virtual {v5, v7}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 696
    new-instance v7, LTableInfo;

    .line 698
    const-string v8, "WorkSpec"

    .line 700
    invoke-direct {v7, v8, v1, v4, v5}, LTableInfo;-><init>(Ljava/lang/String;Ljava/util/HashMap;Ljava/util/HashSet;Ljava/util/HashSet;)V

    .line 703
    invoke-static {v0, v8}, LTableInfo;->a(Lqe;Ljava/lang/String;)LTableInfo;

    .line 706
    move-result-object v1

    .line 707
    invoke-virtual {v7, v1}, LTableInfo;->equals(Ljava/lang/Object;)Z

    .line 710
    move-result v4

    .line 711
    if-nez v4, :cond_1

    .line 713
    new-instance v0, Lkq$b;

    .line 715
    new-instance v2, Ljava/lang/StringBuilder;

    .line 717
    const-string v3, "WorkSpec(androidx.work.impl.model.WorkSpec).\n Expected:\n"

    .line 719
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 722
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 725
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 728
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 731
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 734
    move-result-object v1

    .line 735
    invoke-direct {v0, v1, v10}, Lkq$b;-><init>(Ljava/lang/String;Z)V

    .line 738
    return-object v0

    .line 739
    :cond_1
    new-instance v1, Ljava/util/HashMap;

    .line 741
    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(I)V

    .line 744
    new-instance v4, LTableInfo$a;

    .line 746
    const-string v15, "tag"

    .line 748
    const-string v16, "TEXT"

    .line 750
    const/4 v5, 0x1

    .line 751
    const/16 v18, 0x1

    .line 753
    const/16 v22, 0x0

    .line 755
    const/16 v23, 0x1

    .line 757
    const/16 v17, 0x1

    .line 759
    const/16 v19, 0x0

    .line 761
    const/16 v20, 0x1

    .line 763
    move-object v14, v4

    .line 764
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 767
    const-string v7, "tag"

    .line 769
    invoke-virtual {v1, v7, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 772
    new-instance v4, LTableInfo$a;

    .line 774
    const-string v18, "work_spec_id"

    .line 776
    const-string v19, "TEXT"

    .line 778
    const/16 v21, 0x2

    .line 780
    move-object/from16 v17, v4

    .line 782
    move/from16 v20, v5

    .line 784
    invoke-direct/range {v17 .. v23}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 787
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 790
    new-instance v4, Ljava/util/HashSet;

    .line 792
    invoke-direct {v4, v5}, Ljava/util/HashSet;-><init>(I)V

    .line 795
    new-instance v7, LTableInfo$b;

    .line 797
    const-string v15, "WorkSpec"

    .line 799
    const-string v16, "CASCADE"

    .line 801
    const-string v17, "CASCADE"

    .line 803
    filled-new-array {v3}, [Ljava/lang/String;

    .line 806
    move-result-object v8

    .line 807
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 810
    move-result-object v18

    .line 811
    filled-new-array {v13}, [Ljava/lang/String;

    .line 814
    move-result-object v8

    .line 815
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 818
    move-result-object v19

    .line 819
    move-object v14, v7

    .line 820
    invoke-direct/range {v14 .. v19}, LTableInfo$b;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    .line 823
    invoke-virtual {v4, v7}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 826
    new-instance v7, Ljava/util/HashSet;

    .line 828
    invoke-direct {v7, v5}, Ljava/util/HashSet;-><init>(I)V

    .line 831
    new-instance v8, LTableInfo$d;

    .line 833
    filled-new-array {v3}, [Ljava/lang/String;

    .line 836
    move-result-object v9

    .line 837
    invoke-static {v9}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 840
    move-result-object v9

    .line 841
    const-string v11, "index_WorkTag_work_spec_id"

    .line 843
    invoke-direct {v8, v11, v10, v9}, LTableInfo$d;-><init>(Ljava/lang/String;ZLjava/util/List;)V

    .line 846
    invoke-virtual {v7, v8}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 849
    new-instance v8, LTableInfo;

    .line 851
    const-string v9, "WorkTag"

    .line 853
    invoke-direct {v8, v9, v1, v4, v7}, LTableInfo;-><init>(Ljava/lang/String;Ljava/util/HashMap;Ljava/util/HashSet;Ljava/util/HashSet;)V

    .line 856
    invoke-static {v0, v9}, LTableInfo;->a(Lqe;Ljava/lang/String;)LTableInfo;

    .line 859
    move-result-object v1

    .line 860
    invoke-virtual {v8, v1}, LTableInfo;->equals(Ljava/lang/Object;)Z

    .line 863
    move-result v4

    .line 864
    if-nez v4, :cond_2

    .line 866
    new-instance v0, Lkq$b;

    .line 868
    new-instance v2, Ljava/lang/StringBuilder;

    .line 870
    const-string v3, "WorkTag(androidx.work.impl.model.WorkTag).\n Expected:\n"

    .line 872
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 875
    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 878
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 881
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 884
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 887
    move-result-object v1

    .line 888
    invoke-direct {v0, v1, v10}, Lkq$b;-><init>(Ljava/lang/String;Z)V

    .line 891
    return-object v0

    .line 892
    :cond_2
    new-instance v1, Ljava/util/HashMap;

    .line 894
    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(I)V

    .line 897
    new-instance v4, LTableInfo$a;

    .line 899
    const-string v15, "work_spec_id"

    .line 901
    const-string v16, "TEXT"

    .line 903
    const/16 v17, 0x1

    .line 905
    const/16 v18, 0x1

    .line 907
    const/16 v19, 0x0

    .line 909
    const/16 v20, 0x1

    .line 911
    move-object v14, v4

    .line 912
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 915
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 918
    new-instance v4, LTableInfo$a;

    .line 920
    const-string v22, "system_id"

    .line 922
    const-string v23, "INTEGER"

    .line 924
    const/16 v24, 0x1

    .line 926
    const/16 v25, 0x0

    .line 928
    const/16 v26, 0x0

    .line 930
    const/16 v27, 0x1

    .line 932
    move-object/from16 v21, v4

    .line 934
    invoke-direct/range {v21 .. v27}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 937
    const-string v7, "system_id"

    .line 939
    invoke-virtual {v1, v7, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 942
    new-instance v4, Ljava/util/HashSet;

    .line 944
    invoke-direct {v4, v5}, Ljava/util/HashSet;-><init>(I)V

    .line 947
    new-instance v7, LTableInfo$b;

    .line 949
    const-string v15, "WorkSpec"

    .line 951
    const-string v16, "CASCADE"

    .line 953
    const-string v17, "CASCADE"

    .line 955
    filled-new-array {v3}, [Ljava/lang/String;

    .line 958
    move-result-object v8

    .line 959
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 962
    move-result-object v18

    .line 963
    filled-new-array {v13}, [Ljava/lang/String;

    .line 966
    move-result-object v8

    .line 967
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 970
    move-result-object v19

    .line 971
    move-object v14, v7

    .line 972
    invoke-direct/range {v14 .. v19}, LTableInfo$b;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    .line 975
    invoke-virtual {v4, v7}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 978
    new-instance v7, Ljava/util/HashSet;

    .line 980
    invoke-direct {v7, v10}, Ljava/util/HashSet;-><init>(I)V

    .line 983
    new-instance v8, LTableInfo;

    .line 985
    const-string v9, "SystemIdInfo"

    .line 987
    invoke-direct {v8, v9, v1, v4, v7}, LTableInfo;-><init>(Ljava/lang/String;Ljava/util/HashMap;Ljava/util/HashSet;Ljava/util/HashSet;)V

    .line 990
    invoke-static {v0, v9}, LTableInfo;->a(Lqe;Ljava/lang/String;)LTableInfo;

    .line 993
    move-result-object v1

    .line 994
    invoke-virtual {v8, v1}, LTableInfo;->equals(Ljava/lang/Object;)Z

    .line 997
    move-result v4

    .line 998
    if-nez v4, :cond_3

    .line 1000
    new-instance v0, Lkq$b;

    .line 1002
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1004
    const-string v3, "SystemIdInfo(androidx.work.impl.model.SystemIdInfo).\n Expected:\n"

    .line 1006
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1009
    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1012
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1015
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1018
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1021
    move-result-object v1

    .line 1022
    invoke-direct {v0, v1, v10}, Lkq$b;-><init>(Ljava/lang/String;Z)V

    .line 1025
    return-object v0

    .line 1026
    :cond_3
    new-instance v1, Ljava/util/HashMap;

    .line 1028
    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(I)V

    .line 1031
    new-instance v4, LTableInfo$a;

    .line 1033
    const-string v15, "name"

    .line 1035
    const-string v16, "TEXT"

    .line 1037
    const/4 v7, 0x1

    .line 1038
    const/16 v18, 0x1

    .line 1040
    const/16 v22, 0x0

    .line 1042
    const/16 v23, 0x1

    .line 1044
    const/16 v17, 0x1

    .line 1046
    const/16 v19, 0x0

    .line 1048
    const/16 v20, 0x1

    .line 1050
    move-object v14, v4

    .line 1051
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 1054
    const-string v8, "name"

    .line 1056
    invoke-virtual {v1, v8, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1059
    new-instance v4, LTableInfo$a;

    .line 1061
    const-string v18, "work_spec_id"

    .line 1063
    const-string v19, "TEXT"

    .line 1065
    const/16 v21, 0x2

    .line 1067
    move-object/from16 v17, v4

    .line 1069
    move/from16 v20, v7

    .line 1071
    invoke-direct/range {v17 .. v23}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 1074
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1077
    new-instance v4, Ljava/util/HashSet;

    .line 1079
    invoke-direct {v4, v5}, Ljava/util/HashSet;-><init>(I)V

    .line 1082
    new-instance v7, LTableInfo$b;

    .line 1084
    const-string v15, "WorkSpec"

    .line 1086
    const-string v16, "CASCADE"

    .line 1088
    const-string v17, "CASCADE"

    .line 1090
    filled-new-array {v3}, [Ljava/lang/String;

    .line 1093
    move-result-object v8

    .line 1094
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1097
    move-result-object v18

    .line 1098
    filled-new-array {v13}, [Ljava/lang/String;

    .line 1101
    move-result-object v8

    .line 1102
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1105
    move-result-object v19

    .line 1106
    move-object v14, v7

    .line 1107
    invoke-direct/range {v14 .. v19}, LTableInfo$b;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    .line 1110
    invoke-virtual {v4, v7}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 1113
    new-instance v7, Ljava/util/HashSet;

    .line 1115
    invoke-direct {v7, v5}, Ljava/util/HashSet;-><init>(I)V

    .line 1118
    new-instance v8, LTableInfo$d;

    .line 1120
    filled-new-array {v3}, [Ljava/lang/String;

    .line 1123
    move-result-object v9

    .line 1124
    invoke-static {v9}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1127
    move-result-object v9

    .line 1128
    const-string v11, "index_WorkName_work_spec_id"

    .line 1130
    invoke-direct {v8, v11, v10, v9}, LTableInfo$d;-><init>(Ljava/lang/String;ZLjava/util/List;)V

    .line 1133
    invoke-virtual {v7, v8}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 1136
    new-instance v8, LTableInfo;

    .line 1138
    const-string v9, "WorkName"

    .line 1140
    invoke-direct {v8, v9, v1, v4, v7}, LTableInfo;-><init>(Ljava/lang/String;Ljava/util/HashMap;Ljava/util/HashSet;Ljava/util/HashSet;)V

    .line 1143
    invoke-static {v0, v9}, LTableInfo;->a(Lqe;Ljava/lang/String;)LTableInfo;

    .line 1146
    move-result-object v1

    .line 1147
    invoke-virtual {v8, v1}, LTableInfo;->equals(Ljava/lang/Object;)Z

    .line 1150
    move-result v4

    .line 1151
    if-nez v4, :cond_4

    .line 1153
    new-instance v0, Lkq$b;

    .line 1155
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1157
    const-string v3, "WorkName(androidx.work.impl.model.WorkName).\n Expected:\n"

    .line 1159
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1162
    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1165
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1168
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1171
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1174
    move-result-object v1

    .line 1175
    invoke-direct {v0, v1, v10}, Lkq$b;-><init>(Ljava/lang/String;Z)V

    .line 1178
    return-object v0

    .line 1179
    :cond_4
    new-instance v1, Ljava/util/HashMap;

    .line 1181
    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(I)V

    .line 1184
    new-instance v4, LTableInfo$a;

    .line 1186
    const-string v15, "work_spec_id"

    .line 1188
    const-string v16, "TEXT"

    .line 1190
    const/16 v17, 0x1

    .line 1192
    const/16 v18, 0x1

    .line 1194
    const/16 v19, 0x0

    .line 1196
    const/16 v20, 0x1

    .line 1198
    move-object v14, v4

    .line 1199
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 1202
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1205
    new-instance v4, LTableInfo$a;

    .line 1207
    const-string v22, "progress"

    .line 1209
    const-string v23, "BLOB"

    .line 1211
    const/16 v24, 0x1

    .line 1213
    const/16 v25, 0x0

    .line 1215
    const/16 v26, 0x0

    .line 1217
    const/16 v27, 0x1

    .line 1219
    move-object/from16 v21, v4

    .line 1221
    invoke-direct/range {v21 .. v27}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 1224
    const-string v7, "progress"

    .line 1226
    invoke-virtual {v1, v7, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1229
    new-instance v4, Ljava/util/HashSet;

    .line 1231
    invoke-direct {v4, v5}, Ljava/util/HashSet;-><init>(I)V

    .line 1234
    new-instance v7, LTableInfo$b;

    .line 1236
    const-string v15, "WorkSpec"

    .line 1238
    const-string v16, "CASCADE"

    .line 1240
    const-string v17, "CASCADE"

    .line 1242
    filled-new-array {v3}, [Ljava/lang/String;

    .line 1245
    move-result-object v3

    .line 1246
    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1249
    move-result-object v18

    .line 1250
    filled-new-array {v13}, [Ljava/lang/String;

    .line 1253
    move-result-object v3

    .line 1254
    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1257
    move-result-object v19

    .line 1258
    move-object v14, v7

    .line 1259
    invoke-direct/range {v14 .. v19}, LTableInfo$b;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    .line 1262
    invoke-virtual {v4, v7}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 1265
    new-instance v3, Ljava/util/HashSet;

    .line 1267
    invoke-direct {v3, v10}, Ljava/util/HashSet;-><init>(I)V

    .line 1270
    new-instance v7, LTableInfo;

    .line 1272
    const-string v8, "WorkProgress"

    .line 1274
    invoke-direct {v7, v8, v1, v4, v3}, LTableInfo;-><init>(Ljava/lang/String;Ljava/util/HashMap;Ljava/util/HashSet;Ljava/util/HashSet;)V

    .line 1277
    invoke-static {v0, v8}, LTableInfo;->a(Lqe;Ljava/lang/String;)LTableInfo;

    .line 1280
    move-result-object v1

    .line 1281
    invoke-virtual {v7, v1}, LTableInfo;->equals(Ljava/lang/Object;)Z

    .line 1284
    move-result v3

    .line 1285
    if-nez v3, :cond_5

    .line 1287
    new-instance v0, Lkq$b;

    .line 1289
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1291
    const-string v3, "WorkProgress(androidx.work.impl.model.WorkProgress).\n Expected:\n"

    .line 1293
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1296
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1299
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1302
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1305
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1308
    move-result-object v1

    .line 1309
    invoke-direct {v0, v1, v10}, Lkq$b;-><init>(Ljava/lang/String;Z)V

    .line 1312
    return-object v0

    .line 1313
    :cond_5
    new-instance v1, Ljava/util/HashMap;

    .line 1315
    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(I)V

    .line 1318
    new-instance v2, LTableInfo$a;

    .line 1320
    const-string v12, "key"

    .line 1322
    const-string v13, "TEXT"

    .line 1324
    const/4 v14, 0x1

    .line 1325
    const/4 v15, 0x1

    .line 1326
    const/16 v21, 0x0

    .line 1328
    const/16 v22, 0x1

    .line 1330
    const/16 v16, 0x0

    .line 1332
    const/16 v17, 0x1

    .line 1334
    move-object v11, v2

    .line 1335
    invoke-direct/range {v11 .. v17}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 1338
    const-string v3, "key"

    .line 1340
    invoke-virtual {v1, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1343
    new-instance v2, LTableInfo$a;

    .line 1345
    const-string v17, "long_value"

    .line 1347
    const-string v18, "INTEGER"

    .line 1349
    const/16 v19, 0x0

    .line 1351
    const/16 v20, 0x0

    .line 1353
    move-object/from16 v16, v2

    .line 1355
    invoke-direct/range {v16 .. v22}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 1358
    const-string v3, "long_value"

    .line 1360
    invoke-virtual {v1, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1363
    new-instance v2, Ljava/util/HashSet;

    .line 1365
    invoke-direct {v2, v10}, Ljava/util/HashSet;-><init>(I)V

    .line 1368
    new-instance v3, Ljava/util/HashSet;

    .line 1370
    invoke-direct {v3, v10}, Ljava/util/HashSet;-><init>(I)V

    .line 1373
    new-instance v4, LTableInfo;

    .line 1375
    const-string v7, "Preference"

    .line 1377
    invoke-direct {v4, v7, v1, v2, v3}, LTableInfo;-><init>(Ljava/lang/String;Ljava/util/HashMap;Ljava/util/HashSet;Ljava/util/HashSet;)V

    .line 1380
    invoke-static {v0, v7}, LTableInfo;->a(Lqe;Ljava/lang/String;)LTableInfo;

    .line 1383
    move-result-object v0

    .line 1384
    invoke-virtual {v4, v0}, LTableInfo;->equals(Ljava/lang/Object;)Z

    .line 1387
    move-result v1

    .line 1388
    if-nez v1, :cond_6

    .line 1390
    new-instance v1, Lkq$b;

    .line 1392
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1394
    const-string v3, "Preference(androidx.work.impl.model.Preference).\n Expected:\n"

    .line 1396
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1399
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1402
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1405
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1408
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1411
    move-result-object v0

    .line 1412
    invoke-direct {v1, v0, v10}, Lkq$b;-><init>(Ljava/lang/String;Z)V

    .line 1415
    return-object v1

    .line 1416
    :cond_6
    new-instance v0, Lkq$b;

    .line 1418
    const/4 v1, 0x0

    .line 1419
    invoke-direct {v0, v1, v5}, Lkq$b;-><init>(Ljava/lang/String;Z)V

    .line 1422
    return-object v0
.end method
