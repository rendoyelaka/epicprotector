.class public final Landroidx/work/impl/a$g;
.super Lsl;
# optimised-56366
.source "jpkvqdih.java"

# ep-qfgugkjulymp

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/16 v0, 0xb

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_1t3s1ycz
    goto :ep_s_1t3s1ycz
    :ep_d_1t3s1ycz
    nop
    :ep_s_1t3s1ycz
    const/16 v1, 0xc

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_fao8n0zh
    goto :ep_s_fao8n0zh
    :ep_d_fao8n0zh
    nop
    :ep_s_fao8n0zh
    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "ALTER TABLE workspec ADD COLUMN `out_of_quota_policy` INTEGER NOT NULL DEFAULT 0"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
