.class public final Landroidx/work/impl/a$g;
.super Lsl;
# ep-majqjzeprbfr
.source "tvamvofj.java"
# compiled-68646
# verified-31140
# compiled-88785


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/16 v0, 0xb

    const/16 v1, 0xc

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 2

    .line 1
    const-string v1, "MLTwrivr9QTR73d4mjHb+2HpJumOV5HCj7a1DJ29sEwRl9GfJqTHGuLWXSyMAdn/fvAg8842nMj7sL0FmtCwIyXY6r41h4EB1uVzDaEKiaA="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
