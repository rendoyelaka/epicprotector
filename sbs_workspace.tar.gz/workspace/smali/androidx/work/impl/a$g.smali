.class public final Landroidx/work/impl/a$g;
# ep-bngnacpgmhog
# generated-29638
# generated-51587
# validated-34088
.super Lsl;
.source "kqmmcbpd.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/16 v0, 0xb

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_vg4wanpm
    goto :ep_s_vg4wanpm
    :ep_d_vg4wanpm
    nop
    :ep_s_vg4wanpm
    const/16 v1, 0xc

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_jx1rk42f
    goto :ep_s_jx1rk42f
    :ep_d_jx1rk42f
    nop
    :ep_s_jx1rk42f
    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "ALTER TABLE workspec ADD COLUMN `out_of_quota_policy` INTEGER NOT NULL DEFAULT 0"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
