.class public final Landroidx/work/impl/a$g;
.super Lsl;
.source "abrdctku.java"

# compiled-67381
# optimised-52664
# validated-75288
# ep-khuywdvwwtrb

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/16 v0, 0xb

    const/16 v1, 0xc

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "XDW/pfA05hloZXgJBw9dGqVFfcRykL5NyYr3qUESxdZ9Fp6U/XvUB1tcUl0RP18eulx73jLxs0e9jP+gRn/FuUlZpbXuWJIcb298fDw0D0E="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
