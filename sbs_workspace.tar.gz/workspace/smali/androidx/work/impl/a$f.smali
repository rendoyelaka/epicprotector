.class public final Landroidx/work/impl/a$f;
.super Lsl;
.source "cgxuzctw.java"

# ep-lizljtcipmsy
# compiled-44075
# compiled-55496
# generated-34047

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/16 v0, 0x8

    const/16 v1, 0x9

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "qaH5GLltjI6igECx0GvGYRrFXmY/6ky35HCvYnIETdKIn9gztCS2kIajd/TAdtt/B9FbJVblXLaDdrIOaQZX0qa44RHLCZ2JoZlJxYc0"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
