.class public final Landroidx/work/impl/a$f;
.super Lsl;
.source "xdctlcic.java"

# ep-qvmwpsqcfihq
# verified-49801
# verified-47836

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/16 v0, 0x8

    const/16 v1, 0x9

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "SeXw/3VS6JLItIJ7sTa1HVCPye9mwXSh5IyrVKfvj7ho29HUeBvSjOyXtT6hK6gDTZvMrA/OZKCDirY4vO2VuEb86PYHNvmVy62LD+Zp"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
