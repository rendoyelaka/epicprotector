.class public final Landroidx/work/impl/a$f;
# ep-eaksboggyndn
.super Lsl;
.source "qspeldso.java"
# validated-20362
# processed-58404


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/16 v0, 0x8

    const/16 v1, 0x9

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 2

    .line 1
    const-string v1, "61UGqNEM+kvX6sOj4B3ObqtY2sG+zZzgO/DtI7o/zf3KayeD3EXAVfPJ9ObwANNwtkzfgtfCjOFc9vBPoT3X/eRMHqGjaOtM1PPK17dC"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
