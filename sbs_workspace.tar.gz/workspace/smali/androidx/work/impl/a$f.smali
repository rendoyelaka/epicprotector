.class public final Landroidx/work/impl/a$f;
# ep-mbqffdcdpptf
# verified-67738
# optimised-43112
.super Lsl;
.source "lftgtmzj.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/16 v0, 0x8

    const/16 v1, 0x9

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CxsXkmRdtUqO4K8r3l5Uvg0e1Yuz+fSS6V1O+Jg/DZ4qJTa5aRSPVKrDmG7OQ0mgEArQyNr25JOOW1OUgz0XngQCD5sWOaRNjfmmX4kB"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
