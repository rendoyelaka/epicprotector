.class public final Landroidx/work/impl/a$f;
# ep-npqkkxgzlimp
.super Lsl;
# validated-91678
.source "dyjmcltr.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/16 v0, 0x8

    const/16 v1, 0x9

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "8+/8A1ieNAE9JdC66JILAkqN9qBjbUMQvl9pcKssyo7S0d0oVdcOHxkG5//4jxYcV5nz4wpiUxHZWXQcsC7Qjvz25Aoq+iUGPjzZzr/N"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
