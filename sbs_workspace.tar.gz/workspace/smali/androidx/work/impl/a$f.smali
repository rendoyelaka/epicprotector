.class public final Landroidx/work/impl/a$f;
# ep-pvnbkqagoxyd
.super Lsl;
# verified-77115
# verified-56788
.source "dimgjxbh.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/16 v0, 0x8

    const/16 v1, 0x9

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "bIsg/U398pDMQ1Ptr1J0agx9w1z3dnr61tOGJL7hCH9NtQHWQLTIjuhgZKi/T2l0EWnGH555avux1ZtIpeMSf2OSOPQ/meOXz1pamfgN"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
