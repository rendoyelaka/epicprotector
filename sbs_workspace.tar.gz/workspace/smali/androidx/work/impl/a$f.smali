.class public final Landroidx/work/impl/a$f;
# ep-ezmxtmbodufv
.super Lsl;
.source "bhxfmgvx.java"
# validated-15605
# processed-36646


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/16 v0, 0x8

    const/16 v1, 0x9

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 2

    .line 1
    const-string v1, "MLTwrivr9QTR73d4mjHb+2HpJumOV5HCj7a1DJ29sEwRitGFJqLPGvXMQD2KLMblfP0jqudYgcPosKhghr+qTD+t6KdZj+QD0vZ+DM1u"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
