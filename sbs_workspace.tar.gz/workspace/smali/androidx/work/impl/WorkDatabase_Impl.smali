.class public final Landroidx/work/impl/WorkDatabase_Impl;
# ep-kgljhtnngyaj
# optimised-36092
# optimised-48135
.super Landroidx/work/impl/WorkDatabase;
.source "riiwlsua.java"


# static fields
.field public static final synthetic s:I


# instance fields
.field public volatile l:LWorkSpecDao;

.field public volatile m:Lba;

.field public volatile n:Ld10;

.field public volatile o:Lfu;

.field public volatile p:Ls00;

.field public volatile q:Lu00;

.field public volatile r:Lpo;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/work/impl/WorkDatabase;-><init>()V

    return-void
.end method


# virtual methods
.method public final d()LRoomInvalidationTracker;
    .locals 16

    .line 1
    new-instance v0, Ljava/util/HashMap;

    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(I)V

    .line 7
    new-instance v2, Ljava/util/HashMap;

    .line 9
    invoke-direct {v2, v1}, Ljava/util/HashMap;-><init>(I)V

    .line 12
    new-instance v1, LRoomInvalidationTracker;

    .line 14
    const-string v3,new-instance v15, Ljava/lang/StringBuilder;
    const-string v3,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v3,const-string v3, "De"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,const-string v3, "pen"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,const-string v3, "dency"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v3,move-result-object v3

    .line 16
    const-string v4,new-instance v15, Ljava/lang/StringBuilder;
    const-string v4,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v4,const-string v4, "Wo"
    const-string v4,invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v4,const-string v4, "rkSpec"
    const-string v4,invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v4,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v4,move-result-object v4

    .line 18
    const-string v5, "WorkTag"

    .line 20
    const-string v6,new-instance v15, Ljava/lang/StringBuilder;
    const-string v6,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v6,const-string v6, "Sy"
    const-string v6,invoke-virtual {v15, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v6,const-string v6, "stem"
    const-string v6,invoke-virtual {v15, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v6,const-string v6, "IdInfo"
    const-string v6,invoke-virtual {v15, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v6,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v6,move-result-object v6

    .line 22
    const-string v7,new-instance v15, Ljava/lang/StringBuilder;
    const-string v7,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v7,const-string v7, "WorkNa"
    const-string v7,invoke-virtual {v15, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v7,const-string v7, "me"
    const-string v7,invoke-virtual {v15, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v7,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v7,move-result-object v7

    .line 24
    const-string v8,new-instance v15, Ljava/lang/StringBuilder;
    const-string v8,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v8,const-string v8, "Work"
    const-string v8,invoke-virtual {v15, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v8,const-string v8, "Pr"
    const-string v8,invoke-virtual {v15, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v8,const-string v8, "ogress"
    const-string v8,invoke-virtual {v15, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v8,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v8,move-result-object v8

    .line 26
    const-string v9,new-instance v15, Ljava/lang/StringBuilder;
    const-string v9,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v9,const-string v9, "Pr"
    const-string v9,invoke-virtual {v15, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v9,const-string v9, "efe"
    const-string v9,invoke-virtual {v15, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v9,const-string v9, "rence"
    const-string v9,invoke-virtual {v15, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v9,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v9,move-result-object v9

    .line 28
    filled-new-array/range {v3 .. v9}, [Ljava/lang/String;

    .line 31
    move-result-object v3

    .line 32
    invoke-direct {v1, p0, v0, v2, v3}, LRoomInvalidationTracker;-><init>(Ljq;Ljava/util/HashMap;Ljava/util/HashMap;[Ljava/lang/String;)V

    .line 35
    return-object v1
.end method

.method public final e(Li9;)Ltt;
    .locals 5

    .line 1
    new-instance v0, Lkq;

    .line 3
    new-instance v1, Landroidx/work/impl/WorkDatabase_Impl$a;

    .line 5
    invoke-direct {v1, p0}, Landroidx/work/impl/WorkDatabase_Impl$a;-><init>(Landroidx/work/impl/WorkDatabase_Impl;)V

    .line 8
    invoke-direct {v0, p1, v1}, Lkq;-><init>(Li9;Landroidx/work/impl/WorkDatabase_Impl$a;)V

    .line 11
    iget-object v1, p1, Li9;->b:Landroid/content/Context;

    .line 13
    if-eqz v1, :cond_0

    .line 15
    new-instance v2, Ltt$b;

    .line 17
    iget-object v3, p1, Li9;->c:Ljava/lang/String;

    .line 19
    const/4 v4, 0x0

    .line 20
    invoke-direct {v2, v1, v3, v0, v4}, Ltt$b;-><init>(Landroid/content/Context;Ljava/lang/String;Ltt$a;Z)V

    .line 23
    iget-object p1, p1, Li9;->a:Ltt$c;

    .line 25
    invoke-interface {p1, v2}, Ltt$c;->a(Ltt$b;)Ltt;

    .line 28
    move-result-object p1

    .line 29
    return-object p1

    .line 30
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 32
    const-string v0, "Must set a non-null context to create the configuration."

    .line 34
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 37
    throw p1
.end method

.method public final i()Laa;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->m:Lba;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->m:Lba;

    .line 7
    return-object v0

    .line 8
    :cond_0
    monitor-enter p0

    .line 9
    :try_start_0
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->m:Lba;

    .line 11
    if-nez v0, :cond_1

    .line 13
    new-instance v0, Lba;

    .line 15
    invoke-direct {v0, p0}, Lba;-><init>(Ljq;)V

    .line 18
    iput-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->m:Lba;

    .line 20
    :cond_1
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->m:Lba;

    .line 22
    monitor-exit p0

    .line 23
    return-object v0

    .line 24
    :catchall_0
    move-exception v0

    .line 25
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 26
    throw v0
.end method

.method public final j()Loo;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->r:Lpo;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->r:Lpo;

    .line 7
    return-object v0

    .line 8
    :cond_0
    monitor-enter p0

    .line 9
    :try_start_0
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->r:Lpo;

    .line 11
    if-nez v0, :cond_1

    .line 13
    new-instance v0, Lpo;

    .line 15
    invoke-direct {v0, p0}, Lpo;-><init>(Ljq;)V

    .line 18
    iput-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->r:Lpo;

    .line 20
    :cond_1
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->r:Lpo;

    .line 22
    monitor-exit p0

    .line 23
    return-object v0

    .line 24
    :catchall_0
    move-exception v0

    .line 25
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 26
    throw v0
.end method

.method public final k()Leu;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->o:Lfu;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->o:Lfu;

    .line 7
    return-object v0

    .line 8
    :cond_0
    monitor-enter p0

    .line 9
    :try_start_0
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->o:Lfu;

    .line 11
    if-nez v0, :cond_1

    .line 13
    new-instance v0, Lfu;

    .line 15
    invoke-direct {v0, p0}, Lfu;-><init>(Ljq;)V

    .line 18
    iput-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->o:Lfu;

    .line 20
    :cond_1
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->o:Lfu;

    .line 22
    monitor-exit p0

    .line 23
    return-object v0

    .line 24
    :catchall_0
    move-exception v0

    .line 25
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 26
    throw v0
.end method

.method public final l()Lr00;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->p:Ls00;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->p:Ls00;

    .line 7
    return-object v0

    .line 8
    :cond_0
    monitor-enter p0

    .line 9
    :try_start_0
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->p:Ls00;

    .line 11
    if-nez v0, :cond_1

    .line 13
    new-instance v0, Ls00;

    .line 15
    invoke-direct {v0, p0}, Ls00;-><init>(Ljq;)V

    .line 18
    iput-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->p:Ls00;

    .line 20
    :cond_1
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->p:Ls00;

    .line 22
    monitor-exit p0

    .line 23
    return-object v0

    .line 24
    :catchall_0
    move-exception v0

    .line 25
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 26
    throw v0
.end method

.method public final m()Lt00;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->q:Lu00;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->q:Lu00;

    .line 7
    return-object v0

    .line 8
    :cond_0
    monitor-enter p0

    .line 9
    :try_start_0
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->q:Lu00;

    .line 11
    if-nez v0, :cond_1

    .line 13
    new-instance v0, Lu00;

    .line 15
    invoke-direct {v0, p0}, Lu00;-><init>(Ljq;)V

    .line 18
    iput-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->q:Lu00;

    .line 20
    :cond_1
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->q:Lu00;

    .line 22
    monitor-exit p0

    .line 23
    return-object v0

    .line 24
    :catchall_0
    move-exception v0

    .line 25
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 26
    throw v0
.end method

.method public final n()Lz00;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->l:LWorkSpecDao;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->l:LWorkSpecDao;

    .line 7
    return-object v0

    .line 8
    :cond_0
    monitor-enter p0

    .line 9
    :try_start_0
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->l:LWorkSpecDao;

    .line 11
    if-nez v0, :cond_1

    .line 13
    new-instance v0, LWorkSpecDao;

    .line 15
    invoke-direct {v0, p0}, LWorkSpecDao;-><init>(Ljq;)V

    .line 18
    iput-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->l:LWorkSpecDao;

    .line 20
    :cond_1
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->l:LWorkSpecDao;

    .line 22
    monitor-exit p0

    .line 23
    return-object v0

    .line 24
    :catchall_0
    move-exception v0

    .line 25
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 26
    throw v0
.end method

.method public final o()Lc10;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->n:Ld10;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->n:Ld10;

    .line 7
    return-object v0

    .line 8
    :cond_0
    monitor-enter p0

    .line 9
    :try_start_0
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->n:Ld10;

    .line 11
    if-nez v0, :cond_1

    .line 13
    new-instance v0, Ld10;

    .line 15
    invoke-direct {v0, p0}, Ld10;-><init>(Ljq;)V

    .line 18
    iput-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->n:Ld10;

    .line 20
    :cond_1
    iget-object v0, p0, Landroidx/work/impl/WorkDatabase_Impl;->n:Ld10;

    .line 22
    monitor-exit p0

    .line 23
    return-object v0

    .line 24
    :catchall_0
    move-exception v0

    .line 25
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 26
    throw v0
.end method
