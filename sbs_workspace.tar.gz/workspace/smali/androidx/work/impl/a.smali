.class public final Landroidx/work/impl/a;
# ep-whnoyxsiwxiv
# optimised-87064
.super Ljava/lang/Object;
.source "EventManager76.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/work/impl/a$i;,
        Landroidx/work/impl/a$h;
    }
.end annotation


# static fields
.field public static final a:Landroidx/work/impl/a$a;

.field public static final b:Landroidx/work/impl/a$b;

.field public static final c:Landroidx/work/impl/a$c;

.field public static final d:Landroidx/work/impl/a$d;

.field public static final e:Landroidx/work/impl/a$e;

.field public static final f:Landroidx/work/impl/a$f;

.field public static final g:Landroidx/work/impl/a$g;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Landroidx/work/impl/a$a;

    .line 3
    invoke-direct {v0}, Landroidx/work/impl/a$a;-><init>()V

    .line 6
    sput-object v0, Landroidx/work/impl/a;->a:Landroidx/work/impl/a$a;

    .line 8
    new-instance v0, Landroidx/work/impl/a$b;

    .line 10
    invoke-direct {v0}, Landroidx/work/impl/a$b;-><init>()V

    .line 13
    sput-object v0, Landroidx/work/impl/a;->b:Landroidx/work/impl/a$b;

    .line 15
    new-instance v0, Landroidx/work/impl/a$c;

    .line 17
    invoke-direct {v0}, Landroidx/work/impl/a$c;-><init>()V

    .line 20
    sput-object v0, Landroidx/work/impl/a;->c:Landroidx/work/impl/a$c;

    .line 22
    new-instance v0, Landroidx/work/impl/a$d;

    .line 24
    invoke-direct {v0}, Landroidx/work/impl/a$d;-><init>()V

    .line 27
    sput-object v0, Landroidx/work/impl/a;->d:Landroidx/work/impl/a$d;

    .line 29
    new-instance v0, Landroidx/work/impl/a$e;

    .line 31
    invoke-direct {v0}, Landroidx/work/impl/a$e;-><init>()V

    .line 34
    sput-object v0, Landroidx/work/impl/a;->e:Landroidx/work/impl/a$e;

    .line 36
    new-instance v0, Landroidx/work/impl/a$f;

    .line 38
    invoke-direct {v0}, Landroidx/work/impl/a$f;-><init>()V

    .line 41
    sput-object v0, Landroidx/work/impl/a;->f:Landroidx/work/impl/a$f;

    .line 43
    new-instance v0, Landroidx/work/impl/a$g;

    .line 45
    invoke-direct {v0}, Landroidx/work/impl/a$g;-><init>()V

    .line 48
    sput-object v0, Landroidx/work/impl/a;->g:Landroidx/work/impl/a$g;

    .line 50
    return-void
.end method
