.class public Landroidx/work/impl/background/systemjob/SystemJobService;
.super Landroid/app/job/JobService;
# generated-77293
# validated-45507
# ep-hisinfzzukky
.source "sbtzttcy.java"

# interfaces
.implements Lic;


# instance fields
.field public c:LWorkManagerImpl;

.field public final d:Ljava/util/HashMap;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "SystemJobService"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Landroid/app/job/JobService;-><init>()V

    .line 4
    new-instance v0, Ljava/util/HashMap;

    .line 6
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 9
    iput-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->d:Ljava/util/HashMap;

    .line 11
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;Z)V
    .locals 4

    .line 1
    invoke-static {}, Ltj;->c()Ltj;

    .line 4
    move-result-object v0

    .line 5
    const-string v1, "%s executed on JobScheduler"

    .line 7
    const/4 v2, 0x1

    .line 8
    new-array v2, v2, [Ljava/lang/Object;

    .line 10
    const/4 v3, 0x0

    .line 11
    aput-object p1, v2, v3

    .line 13
    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 16
    new-array v1, v3, [Ljava/lang/Throwable;

    .line 18
    invoke-virtual {v0, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 21
    iget-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->d:Ljava/util/HashMap;

    .line 23
    monitor-enter v0

    .line 24
    :try_start_0
    iget-object v1, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->d:Ljava/util/HashMap;

    .line 26
    invoke-virtual {v1, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    move-result-object p1

    .line 30
    check-cast p1, Landroid/app/job/JobParameters;

    .line 32
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 33
    if-eqz p1, :cond_0

    .line 35
    invoke-virtual {p0, p1, p2}, Landroid/app/job/JobService;->jobFinished(Landroid/app/job/JobParameters;Z)V

    .line 38
    :cond_0
    return-void

    .line 39
    :catchall_0
    move-exception p1

    .line 40
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 41
    throw p1
.end method

.method public final onCreate()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/app/job/JobService;->onCreate()V

    .line 4
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 7
    move-result-object v0

    .line 8
    invoke-static {v0}, LWorkManagerImpl;->s(Landroid/content/Context;)LWorkManagerImpl;

    .line 11
    move-result-object v0

    .line 12
    iput-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->c:LWorkManagerImpl;

    .line 14
    iget-object v0, v0, LWorkManagerImpl;->h:Luo;

    .line 16
    invoke-virtual {v0, p0}, Luo;->b(Lic;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    .line 19
    goto :goto_0

    .line 20
    :catch_0
    nop

    .line 21
    invoke-virtual {p0}, Landroid/app/Service;->getApplication()Landroid/app/Application;

    .line 24
    move-result-object v0

    .line 25
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    move-result-object v0

    .line 29
    const-class v1, Landroid/app/Application;

    .line 31
    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_0

    .line 37
    invoke-static {}, Ltj;->c()Ltj;

    .line 40
    move-result-object v0

    .line 41
    const/4 v1, 0x0

    .line 42
    new-array v1, v1, [Ljava/lang/Throwable;

    .line 44
    invoke-virtual {v0, v1}, Ltj;->f([Ljava/lang/Throwable;)V

    .line 47
    :goto_0
    return-void

    .line 48
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 50
    const-string v1, "WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate()."

    .line 52
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 55
    throw v0
.end method

.method public final onDestroy()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/app/job/JobService;->onDestroy()V

    .line 4
    iget-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->c:LWorkManagerImpl;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    iget-object v0, v0, LWorkManagerImpl;->h:Luo;

    .line 10
    invoke-virtual {v0, p0}, Luo;->f(Lic;)V

    .line 13
    :cond_0
    return-void
.end method

.method public final onStartJob(Landroid/app/job/JobParameters;)Z
    .locals 8

    .line 1
    iget-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->c:LWorkManagerImpl;

    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    if-nez v0, :cond_0

    .line 7
    invoke-static {}, Ltj;->c()Ltj;

    .line 10
    move-result-object v0

    .line 11
    new-array v3, v2, [Ljava/lang/Throwable;

    .line 13
    invoke-virtual {v0, v3}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 16
    invoke-virtual {p0, p1, v1}, Landroid/app/job/JobService;->jobFinished(Landroid/app/job/JobParameters;Z)V

    .line 19
    return v2

    .line 20
    :cond_0
    const-string v0, "EXTRA_WORK_SPEC_ID"

    .line 22
    const/4 v3, 0x0

    .line 23
    :try_start_0
    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getExtras()Landroid/os/PersistableBundle;

    .line 26
    move-result-object v4

    .line 27
    if-eqz v4, :cond_1

    .line 29
    invoke-virtual {v4, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 32
    move-result v5

    .line 33
    if-eqz v5, :cond_1

    .line 35
    invoke-virtual {v4, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 38
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    .line 39
    goto :goto_0

    .line 40
    :catch_0
    :cond_1
    move-object v0, v3

    .line 41
    :goto_0
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 44
    move-result v4

    .line 45
    if-eqz v4, :cond_2

    .line 47
    invoke-static {}, Ltj;->c()Ltj;

    .line 50
    move-result-object p1

    .line 51
    new-array v0, v2, [Ljava/lang/Throwable;

    .line 53
    invoke-virtual {p1, v0}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 56
    return v2

    .line 57
    :cond_2
    iget-object v4, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->d:Ljava/util/HashMap;

    .line 59
    monitor-enter v4

    .line 60
    :try_start_1
    iget-object v5, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->d:Ljava/util/HashMap;

    .line 62
    invoke-virtual {v5, v0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 65
    move-result v5

    .line 66
    if-eqz v5, :cond_3

    .line 68
    invoke-static {}, Ltj;->c()Ltj;

    .line 71
    move-result-object p1

    .line 72
    const-string v3, "Job is already being executed by SystemJobService: %s"

    .line 74
    new-array v1, v1, [Ljava/lang/Object;

    .line 76
    aput-object v0, v1, v2

    .line 78
    invoke-static {v3, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 81
    new-array v0, v2, [Ljava/lang/Throwable;

    .line 83
    invoke-virtual {p1, v0}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 86
    monitor-exit v4

    .line 87
    return v2

    .line 88
    :cond_3
    invoke-static {}, Ltj;->c()Ltj;

    .line 91
    move-result-object v5

    .line 92
    const-string v6, "onStartJob for %s"

    .line 94
    new-array v7, v1, [Ljava/lang/Object;

    .line 96
    aput-object v0, v7, v2

    .line 98
    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 101
    new-array v2, v2, [Ljava/lang/Throwable;

    .line 103
    invoke-virtual {v5, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 106
    iget-object v2, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->d:Ljava/util/HashMap;

    .line 108
    invoke-virtual {v2, v0, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 111
    monitor-exit v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 112
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 114
    const/16 v4, 0x18

    .line 116
    if-lt v2, v4, :cond_6

    .line 118
    new-instance v3, Landroidx/work/WorkerParameters$a;

    .line 120
    invoke-direct {v3}, Landroidx/work/WorkerParameters$a;-><init>()V

    .line 123
    invoke-static {p1}, Lt;->y(Landroid/app/job/JobParameters;)[Landroid/net/Uri;

    .line 126
    move-result-object v4

    .line 127
    if-eqz v4, :cond_4

    .line 129
    invoke-static {p1}, Lt;->y(Landroid/app/job/JobParameters;)[Landroid/net/Uri;

    .line 132
    move-result-object v4

    .line 133
    invoke-static {v4}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 136
    :cond_4
    invoke-static {p1}, Lt;->z(Landroid/app/job/JobParameters;)[Ljava/lang/String;

    .line 139
    move-result-object v4

    .line 140
    if-eqz v4, :cond_5

    .line 142
    invoke-static {p1}, Lt;->z(Landroid/app/job/JobParameters;)[Ljava/lang/String;

    .line 145
    move-result-object v4

    .line 146
    invoke-static {v4}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 149
    :cond_5
    const/16 v4, 0x1c

    .line 151
    if-lt v2, v4, :cond_6

    .line 153
    invoke-static {p1}, Lso;->l(Landroid/app/job/JobParameters;)V

    .line 156
    :cond_6
    iget-object p1, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->c:LWorkManagerImpl;

    .line 158
    invoke-virtual {p1, v0, v3}, LWorkManagerImpl;->w(Ljava/lang/String;Landroidx/work/WorkerParameters$a;)V

    .line 161
    return v1

    .line 162
    :catchall_0
    move-exception p1

    .line 163
    :try_start_2
    monitor-exit v4
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 164
    throw p1
.end method

.method public final onStopJob(Landroid/app/job/JobParameters;)Z
    .locals 5

    .line 1
    iget-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->c:LWorkManagerImpl;

    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    if-nez v0, :cond_0

    .line 7
    invoke-static {}, Ltj;->c()Ltj;

    .line 10
    move-result-object p1

    .line 11
    new-array v0, v2, [Ljava/lang/Throwable;

    .line 13
    invoke-virtual {p1, v0}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 16
    return v1

    .line 17
    :cond_0
    const-string v0, "EXTRA_WORK_SPEC_ID"

    .line 19
    :try_start_0
    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getExtras()Landroid/os/PersistableBundle;

    .line 22
    move-result-object p1

    .line 23
    if-eqz p1, :cond_1

    .line 25
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 28
    move-result v3

    .line 29
    if-eqz v3, :cond_1

    .line 31
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 34
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    .line 35
    goto :goto_0

    .line 36
    :catch_0
    :cond_1
    const/4 p1, 0x0

    .line 37
    :goto_0
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_2

    .line 43
    invoke-static {}, Ltj;->c()Ltj;

    .line 46
    move-result-object p1

    .line 47
    new-array v0, v2, [Ljava/lang/Throwable;

    .line 49
    invoke-virtual {p1, v0}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 52
    return v2

    .line 53
    :cond_2
    invoke-static {}, Ltj;->c()Ltj;

    .line 56
    move-result-object v0

    .line 57
    const-string v3, "onStopJob for %s"

    .line 59
    new-array v4, v1, [Ljava/lang/Object;

    .line 61
    aput-object p1, v4, v2

    .line 63
    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 66
    new-array v2, v2, [Ljava/lang/Throwable;

    .line 68
    invoke-virtual {v0, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 71
    iget-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->d:Ljava/util/HashMap;

    .line 73
    monitor-enter v0

    .line 74
    :try_start_1
    iget-object v2, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->d:Ljava/util/HashMap;

    .line 76
    invoke-virtual {v2, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 79
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 80
    iget-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->c:LWorkManagerImpl;

    .line 82
    invoke-virtual {v0, p1}, LWorkManagerImpl;->x(Ljava/lang/String;)V

    .line 85
    iget-object v0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->c:LWorkManagerImpl;

    .line 87
    iget-object v0, v0, LWorkManagerImpl;->h:Luo;

    .line 89
    invoke-virtual {v0, p1}, Luo;->d(Ljava/lang/String;)Z

    .line 92
    move-result p1

    .line 93
    xor-int/2addr p1, v1

    .line 94
    return p1

    .line 95
    :catchall_0
    move-exception p1

    .line 96
    :try_start_2
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 97
    throw p1
.end method
