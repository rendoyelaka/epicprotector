.class public Landroidx/work/impl/background/systemalarm/ConstraintProxyUpdateReceiver;
# ep-zukejewuamzj
# validated-86546
.super Landroid/content/BroadcastReceiver;
.source "snyvqfed.java"


# static fields
.field public static final synthetic a:I


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "ConstrntProxyUpdtRecvr"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 3

    .line 1
    if-eqz p2, :cond_0

    .line 3
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 6
    move-result-object v0

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    :goto_0
    const-string v1, "androidx.work.impl.background.systemalarm.UpdateProxies"

    .line 11
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 14
    move-result v1

    .line 15
    if-nez v1, :cond_1

    .line 17
    invoke-static {}, Ltj;->c()Ltj;

    .line 20
    move-result-object p1

    .line 21
    const/4 p2, 0x1

    .line 22
    new-array p2, p2, [Ljava/lang/Object;

    .line 24
    const/4 v1, 0x0

    .line 25
    aput-object v0, p2, v1

    .line 27
    const-string v0, "Ignoring unknown action %s"

    .line 29
    invoke-static {v0, p2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 32
    new-array p2, v1, [Ljava/lang/Throwable;

    .line 34
    invoke-virtual {p1, p2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 37
    goto :goto_1

    .line 38
    :cond_1
    invoke-virtual {p0}, Landroid/content/BroadcastReceiver;->goAsync()Landroid/content/BroadcastReceiver$PendingResult;

    .line 41
    move-result-object v0

    .line 42
    invoke-static {p1}, LWorkManagerImpl;->s(Landroid/content/Context;)LWorkManagerImpl;

    .line 45
    move-result-object v1

    .line 46
    iget-object v1, v1, LWorkManagerImpl;->f:Lnu;

    .line 48
    new-instance v2, Landroidx/work/impl/background/systemalarm/ConstraintProxyUpdateReceiver$a;

    .line 50
    invoke-direct {v2, p2, p1, v0}, Landroidx/work/impl/background/systemalarm/ConstraintProxyUpdateReceiver$a;-><init>(Landroid/content/Intent;Landroid/content/Context;Landroid/content/BroadcastReceiver$PendingResult;)V

    .line 53
    check-cast v1, Lp00;

    .line 55
    invoke-virtual {v1, v2}, Lp00;->a(Ljava/lang/Runnable;)V

    .line 58
    :goto_1
    return-void
.end method
