.class public final Landroidx/work/impl/background/systemalarm/a;
.super Ljava/lang/Object;
.source "vhdomlvi.java"
# optimised-23173
# compiled-56612

# ep-pqwmjnigmtch
# interfaces
.implements Lic;


# static fields
.field public static final synthetic f:I


# instance fields
.field public final c:Landroid/content/Context;

.field public final d:Ljava/util/HashMap;

.field public final e:Ljava/lang/Object;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "CommandHandler"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Landroidx/work/impl/background/systemalarm/a;->c:Landroid/content/Context;

    .line 6
    new-instance p1, Ljava/util/HashMap;

    .line 8
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 11
    iput-object p1, p0, Landroidx/work/impl/background/systemalarm/a;->d:Ljava/util/HashMap;

    .line 13
    new-instance p1, Ljava/lang/Object;

    .line 15
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 18
    iput-object p1, p0, Landroidx/work/impl/background/systemalarm/a;->e:Ljava/lang/Object;

    .line 20
    return-void
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 2

    .line 1
    new-instance v0, Landroid/content/Intent;

    .line 3
    const-class v1, Landroidx/work/impl/background/systemalarm/SystemAlarmService;

    .line 5
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 8
    const-string p0, "ACTION_DELAY_MET"

    .line 10
    invoke-virtual {v0, p0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 13
    const-string p0, "KEY_WORKSPEC_ID"

    .line 15
    invoke-virtual {v0, p0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 18
    return-object v0
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 2

    .line 1
    new-instance v0, Landroid/content/Intent;

    .line 3
    const-class v1, Landroidx/work/impl/background/systemalarm/SystemAlarmService;

    .line 5
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 8
    const-string p0, "ACTION_SCHEDULE_WORK"

    .line 10
    invoke-virtual {v0, p0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 13
    const-string p0, "KEY_WORKSPEC_ID"

    .line 15
    invoke-virtual {v0, p0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 18
    return-object v0
.end method


# virtual methods
.method public final a(Ljava/lang/String;Z)V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/a;->e:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/a;->d:Ljava/util/HashMap;

    .line 6
    invoke-virtual {v1, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    move-result-object v1

    .line 10
    check-cast v1, Lic;

    .line 12
    if-eqz v1, :cond_0

    .line 14
    invoke-interface {v1, p1, p2}, Lic;->a(Ljava/lang/String;Z)V

    .line 17
    :cond_0
    monitor-exit v0

    .line 18
    return-void

    .line 19
    :catchall_0
    move-exception p1

    .line 20
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 21
    throw p1
.end method

.method public final d()Z
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/a;->e:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/a;->d:Ljava/util/HashMap;

    .line 6
    invoke-virtual {v1}, Ljava/util/HashMap;->isEmpty()Z

    .line 9
    move-result v1

    .line 10
    if-nez v1, :cond_0

    .line 12
    const/4 v1, 0x1

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v1, 0x0

    .line 15
    :goto_0
    monitor-exit v0

    .line 16
    return v1

    .line 17
    :catchall_0
    move-exception v1

    .line 18
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 19
    throw v1
.end method

.method public final e(ILandroid/content/Intent;Landroidx/work/impl/background/systemalarm/d;)V
    .locals 12

    .line 1
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 4
    move-result-object v0

    .line 5
    const-string v1, "ACTION_CONSTRAINTS_CHANGED"

    .line 7
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x1

    .line 12
    const/4 v3, 0x0

    .line 13
    if-eqz v1, :cond_7

    .line 15
    invoke-static {}, Ltj;->c()Ltj;

    .line 18
    move-result-object v0

    .line 19
    new-array v1, v2, [Ljava/lang/Object;

    .line 21
    aput-object p2, v1, v3

    .line 23
    const-string p2, "Handling constraints changed %s"

    .line 25
    invoke-static {p2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 28
    new-array p2, v3, [Ljava/lang/Throwable;

    .line 30
    invoke-virtual {v0, p2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 33
    new-instance p2, Landroidx/work/impl/background/systemalarm/b;

    .line 35
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/a;->c:Landroid/content/Context;

    .line 37
    invoke-direct {p2, v0, p1, p3}, Landroidx/work/impl/background/systemalarm/b;-><init>(Landroid/content/Context;ILandroidx/work/impl/background/systemalarm/d;)V

    .line 40
    iget-object p1, p3, Landroidx/work/impl/background/systemalarm/d;->g:LWorkManagerImpl;

    .line 42
    iget-object p1, p1, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 44
    invoke-virtual {p1}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 47
    move-result-object p1

    .line 48
    check-cast p1, LWorkSpecDao;

    .line 50
    invoke-virtual {p1}, LWorkSpecDao;->e()Ljava/util/ArrayList;

    .line 53
    move-result-object p1

    .line 54
    sget v0, Landroidx/work/impl/background/systemalarm/ConstraintProxy;->a:I

    .line 56
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 59
    move-result-object v0

    .line 60
    const/4 v1, 0x0

    .line 61
    const/4 v4, 0x0

    .line 62
    const/4 v5, 0x0

    .line 63
    const/4 v6, 0x0

    .line 64
    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 67
    move-result v7

    .line 68
    if-eqz v7, :cond_2

    .line 70
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 73
    move-result-object v7

    .line 74
    check-cast v7, LWorkSpec;

    .line 76
    iget-object v7, v7, LWorkSpec;->j:Lf8;

    .line 78
    iget-boolean v8, v7, Lf8;->d:Z

    .line 80
    or-int/2addr v1, v8

    .line 81
    iget-boolean v8, v7, Lf8;->b:Z

    .line 83
    or-int/2addr v4, v8

    .line 84
    iget-boolean v8, v7, Lf8;->e:Z

    .line 86
    or-int/2addr v5, v8

    .line 87
    iget-object v7, v7, Lf8;->a:Lqm;

    .line 89
    sget-object v8, Lqm;->c:Lqm;

    .line 91
    if-eq v7, v8, :cond_1

    .line 93
    const/4 v7, 0x1

    .line 94
    goto :goto_0

    .line 95
    :cond_1
    const/4 v7, 0x0

    .line 96
    :goto_0
    or-int/2addr v6, v7

    .line 97
    if-eqz v1, :cond_0

    .line 99
    if-eqz v4, :cond_0

    .line 101
    if-eqz v5, :cond_0

    .line 103
    if-eqz v6, :cond_0

    .line 105
    :cond_2
    sget v0, Landroidx/work/impl/background/systemalarm/ConstraintProxyUpdateReceiver;->a:I

    .line 107
    new-instance v0, Landroid/content/Intent;

    .line 109
    const-string v7, "androidx.work.impl.background.systemalarm.UpdateProxies"

    .line 111
    invoke-direct {v0, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 114
    new-instance v7, Landroid/content/ComponentName;

    .line 116
    iget-object v8, p2, Landroidx/work/impl/background/systemalarm/b;->a:Landroid/content/Context;

    .line 118
    const-class v9, Landroidx/work/impl/background/systemalarm/ConstraintProxyUpdateReceiver;

    .line 120
    invoke-direct {v7, v8, v9}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 123
    invoke-virtual {v0, v7}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 126
    const-string v7, "KEY_BATTERY_NOT_LOW_PROXY_ENABLED"

    .line 128
    invoke-virtual {v0, v7, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 131
    move-result-object v1

    .line 132
    const-string v7, "KEY_BATTERY_CHARGING_PROXY_ENABLED"

    .line 134
    invoke-virtual {v1, v7, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 137
    move-result-object v1

    .line 138
    const-string v4, "KEY_STORAGE_NOT_LOW_PROXY_ENABLED"

    .line 140
    invoke-virtual {v1, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 143
    move-result-object v1

    .line 144
    const-string v4, "KEY_NETWORK_STATE_PROXY_ENABLED"

    .line 146
    invoke-virtual {v1, v4, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 149
    invoke-virtual {v8, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    .line 152
    iget-object v0, p2, Landroidx/work/impl/background/systemalarm/b;->c:Le00;

    .line 154
    invoke-virtual {v0, p1}, Le00;->c(Ljava/util/Collection;)V

    .line 157
    new-instance v1, Ljava/util/ArrayList;

    .line 159
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 162
    move-result v4

    .line 163
    invoke-direct {v1, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 166
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 169
    move-result-wide v4

    .line 170
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 173
    move-result-object p1

    .line 174
    :cond_3
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 177
    move-result v6

    .line 178
    if-eqz v6, :cond_5

    .line 180
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 183
    move-result-object v6

    .line 184
    check-cast v6, LWorkSpec;

    .line 186
    iget-object v7, v6, LWorkSpec;->a:Ljava/lang/String;

    .line 188
    invoke-virtual {v6}, LWorkSpec;->a()J

    .line 191
    move-result-wide v9

    .line 192
    cmp-long v11, v4, v9

    .line 194
    if-ltz v11, :cond_3

    .line 196
    invoke-virtual {v6}, LWorkSpec;->b()Z

    .line 199
    move-result v9

    .line 200
    if-eqz v9, :cond_4

    .line 202
    invoke-virtual {v0, v7}, Le00;->a(Ljava/lang/String;)Z

    .line 205
    move-result v7

    .line 206
    if-eqz v7, :cond_3

    .line 208
    :cond_4
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 211
    goto :goto_1

    .line 212
    :cond_5
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 215
    move-result-object p1

    .line 216
    :goto_2
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 219
    move-result v1

    .line 220
    if-eqz v1, :cond_6

    .line 222
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 225
    move-result-object v1

    .line 226
    check-cast v1, LWorkSpec;

    .line 228
    iget-object v1, v1, LWorkSpec;->a:Ljava/lang/String;

    .line 230
    invoke-static {v8, v1}, Landroidx/work/impl/background/systemalarm/a;->b(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 233
    move-result-object v4

    .line 234
    invoke-static {}, Ltj;->c()Ltj;

    .line 237
    move-result-object v5

    .line 238
    new-array v6, v2, [Ljava/lang/Object;

    .line 240
    aput-object v1, v6, v3

    .line 242
    const-string v1, "Creating a delay_met command for workSpec with id (%s)"

    .line 244
    invoke-static {v1, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 247
    new-array v1, v3, [Ljava/lang/Throwable;

    .line 249
    sget v6, Landroidx/work/impl/background/systemalarm/b;->d:I

    .line 251
    invoke-virtual {v5, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 254
    new-instance v1, Landroidx/work/impl/background/systemalarm/d$b;

    .line 256
    iget v5, p2, Landroidx/work/impl/background/systemalarm/b;->b:I

    .line 258
    invoke-direct {v1, v5, v4, p3}, Landroidx/work/impl/background/systemalarm/d$b;-><init>(ILandroid/content/Intent;Landroidx/work/impl/background/systemalarm/d;)V

    .line 261
    invoke-virtual {p3, v1}, Landroidx/work/impl/background/systemalarm/d;->f(Ljava/lang/Runnable;)V

    .line 264
    goto :goto_2

    .line 265
    :cond_6
    invoke-virtual {v0}, Le00;->d()V

    .line 268
    goto/16 :goto_8

    .line 270
    :cond_7
    const-string v1, "ACTION_RESCHEDULE"

    .line 272
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 275
    move-result v1

    .line 276
    const/4 v4, 0x2

    .line 277
    if-eqz v1, :cond_8

    .line 279
    invoke-static {}, Ltj;->c()Ltj;

    .line 282
    move-result-object v0

    .line 283
    new-array v1, v4, [Ljava/lang/Object;

    .line 285
    aput-object p2, v1, v3

    .line 287
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 290
    move-result-object p1

    .line 291
    aput-object p1, v1, v2

    .line 293
    const-string p1, "Handling reschedule %s, %s"

    .line 295
    invoke-static {p1, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 298
    new-array p1, v3, [Ljava/lang/Throwable;

    .line 300
    invoke-virtual {v0, p1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 303
    iget-object p1, p3, Landroidx/work/impl/background/systemalarm/d;->g:LWorkManagerImpl;

    .line 305
    invoke-virtual {p1}, LWorkManagerImpl;->v()V

    .line 308
    goto/16 :goto_8

    .line 310
    :cond_8
    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 313
    move-result-object v1

    .line 314
    const-string v5, "KEY_WORKSPEC_ID"

    .line 316
    filled-new-array {v5}, [Ljava/lang/String;

    .line 319
    move-result-object v5

    .line 320
    if-eqz v1, :cond_b

    .line 322
    invoke-virtual {v1}, Landroid/os/BaseBundle;->isEmpty()Z

    .line 325
    move-result v6

    .line 326
    if-eqz v6, :cond_9

    .line 328
    goto :goto_3

    .line 329
    :cond_9
    aget-object v5, v5, v3

    .line 331
    invoke-virtual {v1, v5}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 334
    move-result-object v1

    .line 335
    if-nez v1, :cond_a

    .line 337
    goto :goto_3

    .line 338
    :cond_a
    const/4 v1, 0x1

    .line 339
    goto :goto_4

    .line 340
    :cond_b
    :goto_3
    const/4 v1, 0x0

    .line 341
    :goto_4
    if-nez v1, :cond_c

    .line 343
    invoke-static {}, Ltj;->c()Ltj;

    .line 346
    move-result-object p1

    .line 347
    const-string p2, "Invalid request for %s, requires %s."

    .line 349
    new-array p3, v4, [Ljava/lang/Object;

    .line 351
    aput-object v0, p3, v3

    .line 353
    const-string v0, "KEY_WORKSPEC_ID"

    .line 355
    aput-object v0, p3, v2

    .line 357
    invoke-static {p2, p3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 360
    new-array p2, v3, [Ljava/lang/Throwable;

    .line 362
    invoke-virtual {p1, p2}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 365
    goto/16 :goto_8

    .line 367
    :cond_c
    const-string v1, "ACTION_SCHEDULE_WORK"

    .line 369
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 372
    move-result v1

    .line 373
    if-eqz v1, :cond_10

    .line 375
    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 378
    move-result-object p2

    .line 379
    const-string v0, "KEY_WORKSPEC_ID"

    .line 381
    invoke-virtual {p2, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 384
    move-result-object p2

    .line 385
    invoke-static {}, Ltj;->c()Ltj;

    .line 388
    move-result-object v0

    .line 389
    new-array v1, v2, [Ljava/lang/Object;

    .line 391
    aput-object p2, v1, v3

    .line 393
    const-string v5, "Handling schedule work for %s"

    .line 395
    invoke-static {v5, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 398
    new-array v1, v3, [Ljava/lang/Throwable;

    .line 400
    invoke-virtual {v0, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 403
    iget-object v0, p3, Landroidx/work/impl/background/systemalarm/d;->g:LWorkManagerImpl;

    .line 405
    iget-object v0, v0, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 407
    invoke-virtual {v0}, Ljq;->c()V

    .line 410
    :try_start_0
    invoke-virtual {v0}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 413
    move-result-object v1

    .line 414
    check-cast v1, LWorkSpecDao;

    .line 416
    invoke-virtual {v1, p2}, LWorkSpecDao;->h(Ljava/lang/String;)LWorkSpec;

    .line 419
    move-result-object v1

    .line 420
    if-nez v1, :cond_d

    .line 422
    invoke-static {}, Ltj;->c()Ltj;

    .line 425
    move-result-object p1

    .line 426
    new-array p2, v3, [Ljava/lang/Throwable;

    .line 428
    invoke-virtual {p1, p2}, Ltj;->f([Ljava/lang/Throwable;)V

    .line 431
    goto :goto_6

    .line 432
    :cond_d
    iget-object v5, v1, LWorkSpec;->b:LWorkInfo_State;

    .line 434
    invoke-virtual {v5}, LWorkInfo_State;->a()Z

    .line 437
    move-result v5

    .line 438
    if-eqz v5, :cond_e

    .line 440
    invoke-static {}, Ltj;->c()Ltj;

    .line 443
    move-result-object p1

    .line 444
    new-array p2, v3, [Ljava/lang/Throwable;

    .line 446
    invoke-virtual {p1, p2}, Ltj;->f([Ljava/lang/Throwable;)V

    .line 449
    goto :goto_6

    .line 450
    :cond_e
    invoke-virtual {v1}, LWorkSpec;->a()J

    .line 453
    move-result-wide v5

    .line 454
    invoke-virtual {v1}, LWorkSpec;->b()Z

    .line 457
    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 458
    iget-object v7, p0, Landroidx/work/impl/background/systemalarm/a;->c:Landroid/content/Context;

    .line 460
    iget-object v8, p3, Landroidx/work/impl/background/systemalarm/d;->g:LWorkManagerImpl;

    .line 462
    if-nez v1, :cond_f

    .line 464
    :try_start_1
    invoke-static {}, Ltj;->c()Ltj;

    .line 467
    move-result-object p1

    .line 468
    const-string p3, "Setting up Alarms for %s at %s"

    .line 470
    new-array v1, v4, [Ljava/lang/Object;

    .line 472
    aput-object p2, v1, v3

    .line 474
    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 477
    move-result-object v4

    .line 478
    aput-object v4, v1, v2

    .line 480
    invoke-static {p3, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 483
    new-array p3, v3, [Ljava/lang/Throwable;

    .line 485
    invoke-virtual {p1, p3}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 488
    invoke-static {v7, v8, p2, v5, v6}, Ls0;->b(Landroid/content/Context;LWorkManagerImpl;Ljava/lang/String;J)V

    .line 491
    goto :goto_5

    .line 492
    :cond_f
    invoke-static {}, Ltj;->c()Ltj;

    .line 495
    move-result-object v1

    .line 496
    const-string v9, "Opportunistically setting an alarm for %s at %s"

    .line 498
    new-array v4, v4, [Ljava/lang/Object;

    .line 500
    aput-object p2, v4, v3

    .line 502
    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 505
    move-result-object v10

    .line 506
    aput-object v10, v4, v2

    .line 508
    invoke-static {v9, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 511
    new-array v2, v3, [Ljava/lang/Throwable;

    .line 513
    invoke-virtual {v1, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 516
    invoke-static {v7, v8, p2, v5, v6}, Ls0;->b(Landroid/content/Context;LWorkManagerImpl;Ljava/lang/String;J)V

    .line 519
    new-instance p2, Landroid/content/Intent;

    .line 521
    const-class v1, Landroidx/work/impl/background/systemalarm/SystemAlarmService;

    .line 523
    invoke-direct {p2, v7, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 526
    const-string v1, "ACTION_CONSTRAINTS_CHANGED"

    .line 528
    invoke-virtual {p2, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 531
    new-instance v1, Landroidx/work/impl/background/systemalarm/d$b;

    .line 533
    invoke-direct {v1, p1, p2, p3}, Landroidx/work/impl/background/systemalarm/d$b;-><init>(ILandroid/content/Intent;Landroidx/work/impl/background/systemalarm/d;)V

    .line 536
    invoke-virtual {p3, v1}, Landroidx/work/impl/background/systemalarm/d;->f(Ljava/lang/Runnable;)V

    .line 539
    :goto_5
    invoke-virtual {v0}, Ljq;->h()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 542
    :goto_6
    invoke-virtual {v0}, Ljq;->f()V

    .line 545
    goto/16 :goto_8

    .line 547
    :catchall_0
    move-exception p1

    .line 548
    invoke-virtual {v0}, Ljq;->f()V

    .line 551
    throw p1

    .line 552
    :cond_10
    const-string v1, "ACTION_DELAY_MET"

    .line 554
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 557
    move-result v1

    .line 558
    if-eqz v1, :cond_12

    .line 560
    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 563
    move-result-object p2

    .line 564
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/a;->e:Ljava/lang/Object;

    .line 566
    monitor-enter v1

    .line 567
    :try_start_2
    const-string v0, "KEY_WORKSPEC_ID"

    .line 569
    invoke-virtual {p2, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 572
    move-result-object p2

    .line 573
    invoke-static {}, Ltj;->c()Ltj;

    .line 576
    move-result-object v0

    .line 577
    const-string v4, "Handing delay met for %s"

    .line 579
    new-array v5, v2, [Ljava/lang/Object;

    .line 581
    aput-object p2, v5, v3

    .line 583
    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 586
    new-array v4, v3, [Ljava/lang/Throwable;

    .line 588
    invoke-virtual {v0, v4}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 591
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/a;->d:Ljava/util/HashMap;

    .line 593
    invoke-virtual {v0, p2}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 596
    move-result v0

    .line 597
    if-nez v0, :cond_11

    .line 599
    new-instance v0, Landroidx/work/impl/background/systemalarm/c;

    .line 601
    iget-object v2, p0, Landroidx/work/impl/background/systemalarm/a;->c:Landroid/content/Context;

    .line 603
    invoke-direct {v0, v2, p1, p2, p3}, Landroidx/work/impl/background/systemalarm/c;-><init>(Landroid/content/Context;ILjava/lang/String;Landroidx/work/impl/background/systemalarm/d;)V

    .line 606
    iget-object p1, p0, Landroidx/work/impl/background/systemalarm/a;->d:Ljava/util/HashMap;

    .line 608
    invoke-virtual {p1, p2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 611
    invoke-virtual {v0}, Landroidx/work/impl/background/systemalarm/c;->f()V

    .line 614
    goto :goto_7

    .line 615
    :cond_11
    invoke-static {}, Ltj;->c()Ltj;

    .line 618
    move-result-object p1

    .line 619
    const-string p3, "WorkSpec %s is already being handled for ACTION_DELAY_MET"

    .line 621
    new-array v0, v2, [Ljava/lang/Object;

    .line 623
    aput-object p2, v0, v3

    .line 625
    invoke-static {p3, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 628
    new-array p2, v3, [Ljava/lang/Throwable;

    .line 630
    invoke-virtual {p1, p2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 633
    :goto_7
    monitor-exit v1

    .line 634
    goto/16 :goto_8

    .line 636
    :catchall_1
    move-exception p1

    .line 637
    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 638
    throw p1

    .line 639
    :cond_12
    const-string v1, "ACTION_STOP_WORK"

    .line 641
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 644
    move-result v1

    .line 645
    if-eqz v1, :cond_14

    .line 647
    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 650
    move-result-object p1

    .line 651
    const-string p2, "KEY_WORKSPEC_ID"

    .line 653
    invoke-virtual {p1, p2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 656
    move-result-object p1

    .line 657
    invoke-static {}, Ltj;->c()Ltj;

    .line 660
    move-result-object p2

    .line 661
    new-array v0, v2, [Ljava/lang/Object;

    .line 663
    aput-object p1, v0, v3

    .line 665
    const-string v1, "Handing stopWork work for %s"

    .line 667
    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 670
    new-array v0, v3, [Ljava/lang/Throwable;

    .line 672
    invoke-virtual {p2, v0}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 675
    iget-object p2, p3, Landroidx/work/impl/background/systemalarm/d;->g:LWorkManagerImpl;

    .line 677
    invoke-virtual {p2, p1}, LWorkManagerImpl;->x(Ljava/lang/String;)V

    .line 680
    sget p2, Ls0;->a:I

    .line 682
    iget-object p2, p3, Landroidx/work/impl/background/systemalarm/d;->g:LWorkManagerImpl;

    .line 684
    iget-object p2, p2, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 686
    invoke-virtual {p2}, Landroidx/work/impl/WorkDatabase;->k()Leu;

    .line 689
    move-result-object p2

    .line 690
    check-cast p2, Lfu;

    .line 692
    invoke-virtual {p2, p1}, Lfu;->a(Ljava/lang/String;)Ldu;

    .line 695
    move-result-object v0

    .line 696
    if-eqz v0, :cond_13

    .line 698
    iget v0, v0, Ldu;->b:I

    .line 700
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/a;->c:Landroid/content/Context;

    .line 702
    invoke-static {v0, v1, p1}, Ls0;->a(ILandroid/content/Context;Ljava/lang/String;)V

    .line 705
    invoke-static {}, Ltj;->c()Ltj;

    .line 708
    move-result-object v0

    .line 709
    new-array v1, v2, [Ljava/lang/Object;

    .line 711
    aput-object p1, v1, v3

    .line 713
    const-string v2, "Removing SystemIdInfo for workSpecId (%s)"

    .line 715
    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 718
    new-array v1, v3, [Ljava/lang/Throwable;

    .line 720
    invoke-virtual {v0, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 723
    invoke-virtual {p2, p1}, Lfu;->b(Ljava/lang/String;)V

    .line 726
    :cond_13
    invoke-virtual {p3, p1, v3}, Landroidx/work/impl/background/systemalarm/d;->a(Ljava/lang/String;Z)V

    .line 729
    goto :goto_8

    .line 730
    :cond_14
    const-string p3, "ACTION_EXECUTION_COMPLETED"

    .line 732
    invoke-virtual {p3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 735
    move-result p3

    .line 736
    if-eqz p3, :cond_15

    .line 738
    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 741
    move-result-object p3

    .line 742
    const-string v0, "KEY_WORKSPEC_ID"

    .line 744
    invoke-virtual {p3, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 747
    move-result-object v0

    .line 748
    const-string v1, "KEY_NEEDS_RESCHEDULE"

    .line 750
    invoke-virtual {p3, v1}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    .line 753
    move-result p3

    .line 754
    invoke-static {}, Ltj;->c()Ltj;

    .line 757
    move-result-object v1

    .line 758
    new-array v4, v4, [Ljava/lang/Object;

    .line 760
    aput-object p2, v4, v3

    .line 762
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 765
    move-result-object p1

    .line 766
    aput-object p1, v4, v2

    .line 768
    const-string p1, "Handling onExecutionCompleted %s, %s"

    .line 770
    invoke-static {p1, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 773
    new-array p1, v3, [Ljava/lang/Throwable;

    .line 775
    invoke-virtual {v1, p1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 778
    invoke-virtual {p0, v0, p3}, Landroidx/work/impl/background/systemalarm/a;->a(Ljava/lang/String;Z)V

    .line 781
    goto :goto_8

    .line 782
    :cond_15
    invoke-static {}, Ltj;->c()Ltj;

    .line 785
    move-result-object p1

    .line 786
    const-string p3, "Ignoring intent %s"

    .line 788
    new-array v0, v2, [Ljava/lang/Object;

    .line 790
    aput-object p2, v0, v3

    .line 792
    invoke-static {p3, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 795
    new-array p2, v3, [Ljava/lang/Throwable;

    .line 797
    invoke-virtual {p1, p2}, Ltj;->f([Ljava/lang/Throwable;)V

    .line 800
    :goto_8
    return-void
.end method
