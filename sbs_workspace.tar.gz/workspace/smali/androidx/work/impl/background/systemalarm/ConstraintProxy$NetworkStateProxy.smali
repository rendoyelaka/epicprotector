.class public Landroidx/work/impl/background/systemalarm/ConstraintProxy$NetworkStateProxy;
# ep-jffbykaaamhl
# compiled-55405
# compiled-20246
.super Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.source "tsyhltxt.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "NetworkStateProxy"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/work/impl/background/systemalarm/ConstraintProxy;-><init>()V

    return-void
.end method
