.class public final Landroidx/work/impl/background/systemalarm/d$a;
.super Ljava/lang/Object;
# ep-pkkpidsefdpe
.source "vwfihyqx.java"
# compiled-40576

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/work/impl/background/systemalarm/d;->g()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Landroidx/work/impl/background/systemalarm/d;


# direct methods
.method public constructor <init>(Landroidx/work/impl/background/systemalarm/d;)V
    .locals 0

    iput-object p1, p0, Landroidx/work/impl/background/systemalarm/d$a;->c:Landroidx/work/impl/background/systemalarm/d;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    .line 1
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/d$a;->c:Landroidx/work/impl/background/systemalarm/d;

    .line 3
    iget-object v0, v0, Landroidx/work/impl/background/systemalarm/d;->j:Ljava/util/ArrayList;

    .line 5
    monitor-enter v0

    .line 6
    :try_start_0
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/d$a;->c:Landroidx/work/impl/background/systemalarm/d;

    .line 8
    iget-object v2, v1, Landroidx/work/impl/background/systemalarm/d;->j:Ljava/util/ArrayList;

    .line 10
    const/4 v3, 0x0

    .line 11
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 14
    move-result-object v2

    .line 15
    check-cast v2, Landroid/content/Intent;

    .line 17
    iput-object v2, v1, Landroidx/work/impl/background/systemalarm/d;->k:Landroid/content/Intent;

    .line 19
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 20
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/d$a;->c:Landroidx/work/impl/background/systemalarm/d;

    .line 22
    iget-object v0, v0, Landroidx/work/impl/background/systemalarm/d;->k:Landroid/content/Intent;

    .line 24
    if-eqz v0, :cond_0

    .line 26
    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 29
    move-result-object v0

    .line 30
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/d$a;->c:Landroidx/work/impl/background/systemalarm/d;

    .line 32
    iget-object v1, v1, Landroidx/work/impl/background/systemalarm/d;->k:Landroid/content/Intent;

    .line 34
    const-string v2, "o6j0ArgZmZ20k0zV"
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 36
    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 39
    move-result v1

    .line 40
    invoke-static {}, Ltj;->c()Ltj;

    .line 43
    move-result-object v2

    .line 44
    sget v4, Landroidx/work/impl/background/systemalarm/d;->m:I

    .line 46
    const-string v4, "uJ/CPo4+q6aOqyXyyGnZawfRGyBshyjWtw=="
    invoke-static {v4}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4

    .line 48
    const/4 v5, 0x2

    .line 49
    new-array v6, v5, [Ljava/lang/Object;

    .line 51
    iget-object v7, p0, Landroidx/work/impl/background/systemalarm/d$a;->c:Landroidx/work/impl/background/systemalarm/d;

    .line 53
    iget-object v7, v7, Landroidx/work/impl/background/systemalarm/d;->k:Landroid/content/Intent;

    .line 55
    aput-object v7, v6, v3

    .line 57
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 60
    move-result-object v7

    .line 61
    const/4 v8, 0x1

    .line 62
    aput-object v7, v6, v8

    .line 64
    invoke-static {v4, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 67
    new-array v4, v3, [Ljava/lang/Throwable;

    .line 69
    invoke-virtual {v2, v4}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 72
    iget-object v2, p0, Landroidx/work/impl/background/systemalarm/d$a;->c:Landroidx/work/impl/background/systemalarm/d;

    .line 74
    iget-object v2, v2, Landroidx/work/impl/background/systemalarm/d;->c:Landroid/content/Context;

    .line 76
    const-string v4, "zZ6Ndc4+8Q=="
    invoke-static {v4}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4

    .line 78
    new-array v6, v5, [Ljava/lang/Object;

    .line 80
    aput-object v0, v6, v3

    .line 82
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 85
    move-result-object v7

    .line 86
    aput-object v7, v6, v8

    .line 88
    invoke-static {v4, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 91
    move-result-object v4

    .line 92
    invoke-static {v2, v4}, Lhz;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/os/PowerManager$WakeLock;

    .line 95
    move-result-object v2

    .line 96
    :try_start_1
    invoke-static {}, Ltj;->c()Ltj;

    .line 99
    move-result-object v4

    .line 100
    const-string v6, "qY7cKII/saGH7GrhwnbVfgDaVSVoymOW5F+PTUxpK9ebxI14mA=="
    invoke-static {v6}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v6

    .line 102
    new-array v7, v5, [Ljava/lang/Object;

    .line 104
    aput-object v0, v7, v3

    .line 106
    aput-object v2, v7, v8

    .line 108
    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 111
    new-array v6, v3, [Ljava/lang/Throwable;

    .line 113
    invoke-virtual {v4, v6}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 116
    invoke-virtual {v2}, Landroid/os/PowerManager$WakeLock;->acquire()V

    .line 119
    iget-object v4, p0, Landroidx/work/impl/background/systemalarm/d$a;->c:Landroidx/work/impl/background/systemalarm/d;

    .line 121
    iget-object v6, v4, Landroidx/work/impl/background/systemalarm/d;->h:Landroidx/work/impl/background/systemalarm/a;

    .line 123
    iget-object v7, v4, Landroidx/work/impl/background/systemalarm/d;->k:Landroid/content/Intent;

    .line 125
    invoke-virtual {v6, v1, v7, v4}, Landroidx/work/impl/background/systemalarm/a;->e(ILandroid/content/Intent;Landroidx/work/impl/background/systemalarm/d;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 128
    invoke-static {}, Ltj;->c()Ltj;

    .line 131
    move-result-object v1

    .line 132
    const-string v4, "uojBOIo+saGH7GrhwnbVfgDaVSVoymOW5F+PTUxpK9ebxI14mA=="
    invoke-static {v4}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4

    .line 134
    new-array v5, v5, [Ljava/lang/Object;

    .line 136
    aput-object v0, v5, v3

    .line 138
    aput-object v2, v5, v8

    .line 140
    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 143
    new-array v0, v3, [Ljava/lang/Throwable;

    .line 145
    invoke-virtual {v1, v0}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 148
    invoke-virtual {v2}, Landroid/os/PowerManager$WakeLock;->release()V

    .line 151
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/d$a;->c:Landroidx/work/impl/background/systemalarm/d;

    .line 153
    new-instance v1, Landroidx/work/impl/background/systemalarm/d$d;

    .line 155
    invoke-direct {v1, v0}, Landroidx/work/impl/background/systemalarm/d$d;-><init>(Landroidx/work/impl/background/systemalarm/d;)V

    .line 158
    goto :goto_0

    .line 159
    :catchall_0
    move-exception v1

    .line 160
    :try_start_2
    invoke-static {}, Ltj;->c()Ltj;

    .line 163
    move-result-object v4

    .line 164
    sget v6, Landroidx/work/impl/background/systemalarm/d;->m:I

    .line 166
    new-array v6, v8, [Ljava/lang/Throwable;

    .line 168
    aput-object v1, v6, v3

    .line 170
    invoke-virtual {v4, v6}, Ltj;->b([Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 173
    invoke-static {}, Ltj;->c()Ltj;

    .line 176
    move-result-object v1

    .line 177
    const-string v4, "uojBOIo+saGH7GrhwnbVfgDaVSVoymOW5F+PTUxpK9ebxI14mA=="
    invoke-static {v4}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4

    .line 179
    new-array v5, v5, [Ljava/lang/Object;

    .line 181
    aput-object v0, v5, v3

    .line 183
    aput-object v2, v5, v8

    .line 185
    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 188
    new-array v0, v3, [Ljava/lang/Throwable;

    .line 190
    invoke-virtual {v1, v0}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 193
    invoke-virtual {v2}, Landroid/os/PowerManager$WakeLock;->release()V

    .line 196
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/d$a;->c:Landroidx/work/impl/background/systemalarm/d;

    .line 198
    new-instance v1, Landroidx/work/impl/background/systemalarm/d$d;

    .line 200
    invoke-direct {v1, v0}, Landroidx/work/impl/background/systemalarm/d$d;-><init>(Landroidx/work/impl/background/systemalarm/d;)V

    .line 203
    :goto_0
    invoke-virtual {v0, v1}, Landroidx/work/impl/background/systemalarm/d;->f(Ljava/lang/Runnable;)V

    .line 206
    goto :goto_1

    .line 207
    :catchall_1
    move-exception v1

    .line 208
    invoke-static {}, Ltj;->c()Ltj;

    .line 211
    move-result-object v4

    .line 212
    sget v6, Landroidx/work/impl/background/systemalarm/d;->m:I

    .line 214
    const-string v6, "uojBOIo+saGH7GrhwnbVfgDaVSVoymOW5F+PTUxpK9ebxI14mA=="
    invoke-static {v6}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v6

    .line 216
    new-array v5, v5, [Ljava/lang/Object;

    .line 218
    aput-object v0, v5, v3

    .line 220
    aput-object v2, v5, v8

    .line 222
    invoke-static {v6, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 225
    new-array v0, v3, [Ljava/lang/Throwable;

    .line 227
    invoke-virtual {v4, v0}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 230
    invoke-virtual {v2}, Landroid/os/PowerManager$WakeLock;->release()V

    .line 233
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/d$a;->c:Landroidx/work/impl/background/systemalarm/d;

    .line 235
    new-instance v2, Landroidx/work/impl/background/systemalarm/d$d;

    .line 237
    invoke-direct {v2, v0}, Landroidx/work/impl/background/systemalarm/d$d;-><init>(Landroidx/work/impl/background/systemalarm/d;)V

    .line 240
    invoke-virtual {v0, v2}, Landroidx/work/impl/background/systemalarm/d;->f(Ljava/lang/Runnable;)V

    .line 243
    throw v1

    .line 244
    :cond_0
    :goto_1
    return-void

    .line 245
    :catchall_2
    move-exception v1

    .line 246
    :try_start_3
    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 247
    throw v1
.end method
