.class public Landroidx/work/impl/background/systemalarm/SystemAlarmService;
# ep-knbgvceyotpb
.super Landroidx/lifecycle/LifecycleService;
.source "yetmcijl.java"

# compiled-30393
# compiled-64432
# interfaces
.implements Landroidx/work/impl/background/systemalarm/d$c;


# instance fields
.field public d:Landroidx/work/impl/background/systemalarm/d;

.field public e:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "SystemAlarmService"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/lifecycle/LifecycleService;-><init>()V

    return-void
.end method


# virtual methods
.method public final d()V
    .locals 2

    .line 1
    new-instance v0, Landroidx/work/impl/background/systemalarm/d;

    .line 3
    invoke-direct {v0, p0}, Landroidx/work/impl/background/systemalarm/d;-><init>(Landroid/content/Context;)V

    .line 6
    iput-object v0, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->d:Landroidx/work/impl/background/systemalarm/d;

    .line 8
    iget-object v1, v0, Landroidx/work/impl/background/systemalarm/d;->l:Landroidx/work/impl/background/systemalarm/d$c;

    .line 10
    if-eqz v1, :cond_0

    .line 12
    invoke-static {}, Ltj;->c()Ltj;

    .line 15
    move-result-object v0

    .line 16
    const/4 v1, 0x0

    .line 17
    new-array v1, v1, [Ljava/lang/Throwable;

    .line 19
    invoke-virtual {v0, v1}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    iput-object p0, v0, Landroidx/work/impl/background/systemalarm/d;->l:Landroidx/work/impl/background/systemalarm/d$c;

    .line 25
    :goto_0
    return-void
.end method

.method public final e()V
    .locals 7

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->e:Z

    .line 4
    invoke-static {}, Ltj;->c()Ltj;

    .line 7
    move-result-object v1

    .line 8
    const/4 v2, 0x0

    .line 9
    new-array v3, v2, [Ljava/lang/Throwable;

    .line 11
    invoke-virtual {v1, v3}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 14
    sget-object v1, Lhz;->a:Ljava/util/WeakHashMap;

    .line 16
    new-instance v1, Ljava/util/HashMap;

    .line 18
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 21
    sget-object v3, Lhz;->a:Ljava/util/WeakHashMap;

    .line 23
    monitor-enter v3

    .line 24
    :try_start_0
    invoke-virtual {v1, v3}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    .line 27
    monitor-exit v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 28
    invoke-virtual {v1}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    .line 31
    move-result-object v3

    .line 32
    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 35
    move-result-object v3

    .line 36
    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 39
    move-result v4

    .line 40
    if-eqz v4, :cond_1

    .line 42
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 45
    move-result-object v4

    .line 46
    check-cast v4, Landroid/os/PowerManager$WakeLock;

    .line 48
    if-eqz v4, :cond_0

    .line 50
    invoke-virtual {v4}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    .line 53
    move-result v5

    .line 54
    if-eqz v5, :cond_0

    .line 56
    const-string v5, "WakeLock held for %s"

    .line 58
    new-array v6, v0, [Ljava/lang/Object;

    .line 60
    invoke-virtual {v1, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 63
    move-result-object v4

    .line 64
    aput-object v4, v6, v2

    .line 66
    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 69
    invoke-static {}, Ltj;->c()Ltj;

    .line 72
    move-result-object v4

    .line 73
    sget-object v5, Lhz;->a:Ljava/util/WeakHashMap;

    .line 75
    new-array v5, v2, [Ljava/lang/Throwable;

    .line 77
    invoke-virtual {v4, v5}, Ltj;->f([Ljava/lang/Throwable;)V

    .line 80
    goto :goto_0

    .line 81
    :cond_1
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    .line 84
    return-void

    .line 85
    :catchall_0
    move-exception v0

    .line 86
    :try_start_1
    monitor-exit v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 87
    throw v0
.end method

.method public final onCreate()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroidx/lifecycle/LifecycleService;->onCreate()V

    .line 4
    invoke-virtual {p0}, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->d()V

    .line 7
    const/4 v0, 0x0

    .line 8
    iput-boolean v0, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->e:Z

    .line 10
    return-void
.end method

.method public final onDestroy()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroidx/lifecycle/LifecycleService;->onDestroy()V

    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->e:Z

    .line 7
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->d:Landroidx/work/impl/background/systemalarm/d;

    .line 9
    invoke-virtual {v0}, Landroidx/work/impl/background/systemalarm/d;->e()V

    .line 12
    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 2

    .line 1
    invoke-super {p0, p1, p2, p3}, Landroidx/lifecycle/LifecycleService;->onStartCommand(Landroid/content/Intent;II)I

    .line 4
    iget-boolean p2, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->e:Z

    .line 6
    if-eqz p2, :cond_0

    .line 8
    invoke-static {}, Ltj;->c()Ltj;

    .line 11
    move-result-object p2

    .line 12
    const/4 v0, 0x0

    .line 13
    new-array v1, v0, [Ljava/lang/Throwable;

    .line 15
    invoke-virtual {p2, v1}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 18
    iget-object p2, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->d:Landroidx/work/impl/background/systemalarm/d;

    .line 20
    invoke-virtual {p2}, Landroidx/work/impl/background/systemalarm/d;->e()V

    .line 23
    invoke-virtual {p0}, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->d()V

    .line 26
    iput-boolean v0, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->e:Z

    .line 28
    :cond_0
    if-eqz p1, :cond_1

    .line 30
    iget-object p2, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->d:Landroidx/work/impl/background/systemalarm/d;

    .line 32
    invoke-virtual {p2, p1, p3}, Landroidx/work/impl/background/systemalarm/d;->b(Landroid/content/Intent;I)V

    .line 35
    :cond_1
    const/4 p1, 0x3

    .line 36
    return p1
.end method
