.class public Landroidx/work/impl/background/systemalarm/RescheduleReceiver;
.super Landroid/content/BroadcastReceiver;
.source "xvonngbz.java"
# ep-dukworqzgrsu
# compiled-15208
# verified-32415


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "RescheduleReceiver"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 5

    .line 1
    invoke-static {}, Ltj;->c()Ltj;

    .line 4
    move-result-object v0

    .line 5
    const-string v1, "uojOOII7vavApWvlwmrAKkzG"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 7
    const/4 v2, 0x1

    .line 8
    new-array v3, v2, [Ljava/lang/Object;

    .line 10
    const/4 v4, 0x0

    .line 11
    aput-object p2, v3, v4

    .line 13
    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 16
    new-array p2, v4, [Ljava/lang/Throwable;

    .line 18
    invoke-virtual {v0, p2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 21
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 23
    const/16 v0, 0x17

    .line 25
    if-lt p2, v0, :cond_1

    .line 27
    :try_start_0
    invoke-static {p1}, LWorkManagerImpl;->s(Landroid/content/Context;)LWorkManagerImpl;

    .line 30
    move-result-object p1

    .line 31
    invoke-virtual {p0}, Landroid/content/BroadcastReceiver;->goAsync()Landroid/content/BroadcastReceiver$PendingResult;

    .line 34
    move-result-object p2

    .line 35
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 38
    sget-object v0, LWorkManagerImpl;->n:Ljava/lang/Object;

    .line 40
    monitor-enter v0
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    .line 41
    :try_start_1
    iput-object p2, p1, LWorkManagerImpl;->k:Landroid/content/BroadcastReceiver$PendingResult;

    .line 43
    iget-boolean v1, p1, LWorkManagerImpl;->j:Z

    .line 45
    if-eqz v1, :cond_0

    .line 47
    invoke-virtual {p2}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    .line 50
    const/4 p2, 0x0

    .line 51
    iput-object p2, p1, LWorkManagerImpl;->k:Landroid/content/BroadcastReceiver$PendingResult;

    .line 53
    :cond_0
    monitor-exit v0

    .line 54
    goto :goto_0

    .line 55
    :catchall_0
    move-exception p1

    .line 56
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 57
    :try_start_2
    throw p1
    :try_end_2
    .catch Ljava/lang/IllegalStateException; {:try_start_2 .. :try_end_2} :catch_0

    .line 58
    :catch_0
    move-exception p1

    .line 59
    invoke-static {}, Ltj;->c()Ltj;

    .line 62
    move-result-object p2

    .line 63
    new-array v0, v2, [Ljava/lang/Throwable;

    .line 65
    aput-object p1, v0, v4

    .line 67
    invoke-virtual {p2, v0}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 70
    goto :goto_0

    .line 71
    :cond_1
    sget p2, Landroidx/work/impl/background/systemalarm/a;->f:I

    .line 73
    new-instance p2, Landroid/content/Intent;

    .line 75
    const-class v0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;

    .line 77
    invoke-direct {p2, p1, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 80
    const-string v0, "qa75FKQDh52ln0bZ4kDhRiw="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 82
    invoke-virtual {p2, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 85
    invoke-virtual {p1, p2}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 88
    :goto_0
    return-void
.end method
