.class public Landroidx/work/impl/background/systemalarm/ConstraintProxy$BatteryChargingProxy;
# ep-ruvoqorleceo
.super Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.source "uvayjrlj.java"
# compiled-84271
# verified-89985
# validated-21428


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "BatteryChargingProxy"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/work/impl/background/systemalarm/ConstraintProxy;-><init>()V

    return-void
.end method
