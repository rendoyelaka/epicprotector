.class public Landroidx/work/impl/background/systemalarm/ConstraintProxy$BatteryChargingProxy;
# ep-nmyhsyakspsd
# generated-82247
# generated-16858
# processed-54085
.super Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.source "srrtcdwo.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "BatteryChargingProxy"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/work/impl/background/systemalarm/ConstraintProxy;-><init>()V

    return-void
.end method
