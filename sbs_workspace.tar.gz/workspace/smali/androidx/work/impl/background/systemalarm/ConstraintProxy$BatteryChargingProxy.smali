.class public Landroidx/work/impl/background/systemalarm/ConstraintProxy$BatteryChargingProxy;
# ep-hojbbehovgsm
# verified-59424
# compiled-32364
.super Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.source "DispatcherManager30.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "BatteryChargingProxy"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/work/impl/background/systemalarm/ConstraintProxy;-><init>()V

    return-void
.end method
