.class public Landroidx/work/impl/background/systemalarm/ConstraintProxy$BatteryChargingProxy;
# ep-xxvhztxhczwf
.super Landroidx/work/impl/background/systemalarm/ConstraintProxy;
# compiled-33424
# generated-27018
.source "jrseuhhi.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "BatteryChargingProxy"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/work/impl/background/systemalarm/ConstraintProxy;-><init>()V

    return-void
.end method
