.class public Landroidx/work/impl/background/systemalarm/ConstraintProxy$BatteryChargingProxy;
# ep-amkkrixdbkff
.super Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.source "tfxkhmlo.java"
# compiled-30506
# verified-61393


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "BatteryChargingProxy"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/work/impl/background/systemalarm/ConstraintProxy;-><init>()V

    return-void
.end method
