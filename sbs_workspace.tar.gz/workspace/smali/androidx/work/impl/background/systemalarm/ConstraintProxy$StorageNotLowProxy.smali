.class public Landroidx/work/impl/background/systemalarm/ConstraintProxy$StorageNotLowProxy;
# ep-ruqiyjwdrpnl
.super Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.source "jxakhojv.java"

# optimised-33055
# validated-37227
# compiled-28990

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "StorageNotLowProxy"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/work/impl/background/systemalarm/ConstraintProxy;-><init>()V

    return-void
.end method
