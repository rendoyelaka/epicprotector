.class public Landroidx/work/impl/background/systemalarm/ConstraintProxy$StorageNotLowProxy;
# ep-nzrqortcvxhx
.super Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.source "qriopxmw.java"

# processed-76235
# validated-48304
# compiled-33585

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "StorageNotLowProxy"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/work/impl/background/systemalarm/ConstraintProxy;-><init>()V

    return-void
.end method
