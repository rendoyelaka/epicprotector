.class public Landroidx/work/impl/background/systemalarm/ConstraintProxy$StorageNotLowProxy;
# listener-42175-network
# request-13003-layout
# provider-47210-binding
# adapter-90694-callback
.super Landroidx/work/impl/background/systemalarm/ConstraintProxy;
# ep-mqupdgrklufs
# processed-77275
# compiled-25455
.source "BuilderHelper40.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "StorageNotLowProxy"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/work/impl/background/systemalarm/ConstraintProxy;-><init>()V

    return-void
.end method
