.class public final Landroidx/work/impl/background/systemalarm/d$d;
# ep-tjggtwjnrtnd
# generated-49167
# verified-20762
.super Ljava/lang/Object;
.source "bdlndvkp.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/background/systemalarm/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation


# instance fields
.field public final c:Landroidx/work/impl/background/systemalarm/d;


# direct methods
.method public constructor <init>(Landroidx/work/impl/background/systemalarm/d;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Landroidx/work/impl/background/systemalarm/d$d;->c:Landroidx/work/impl/background/systemalarm/d;

    .line 6
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 8

    .line 1
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/d$d;->c:Landroidx/work/impl/background/systemalarm/d;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {}, Ltj;->c()Ltj;

    .line 9
    move-result-object v1

    .line 10
    sget v2, Landroidx/work/impl/background/systemalarm/d;->m:I

    .line 12
    const/4 v2, 0x0

    .line 13
    new-array v3, v2, [Ljava/lang/Throwable;

    .line 15
    invoke-virtual {v1, v3}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 18
    invoke-virtual {v0}, Landroidx/work/impl/background/systemalarm/d;->c()V

    .line 21
    iget-object v1, v0, Landroidx/work/impl/background/systemalarm/d;->j:Ljava/util/ArrayList;

    .line 23
    monitor-enter v1

    .line 24
    :try_start_0
    iget-object v3, v0, Landroidx/work/impl/background/systemalarm/d;->k:Landroid/content/Intent;

    .line 26
    if-eqz v3, :cond_1

    .line 28
    invoke-static {}, Ltj;->c()Ltj;

    .line 31
    move-result-object v3

    .line 32
    const-string v7, "I53JhA+izyKzwF01gD/H9DK8MA=="
    invoke-static {v7}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4

    .line 34
    const/4 v5, 0x1

    .line 35
    new-array v5, v5, [Ljava/lang/Object;

    .line 37
    iget-object v6, v0, Landroidx/work/impl/background/systemalarm/d;->k:Landroid/content/Intent;

    .line 39
    aput-object v6, v5, v2

    .line 41
    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 44
    new-array v4, v2, [Ljava/lang/Throwable;

    .line 46
    invoke-virtual {v3, v4}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 49
    iget-object v3, v0, Landroidx/work/impl/background/systemalarm/d;->j:Ljava/util/ArrayList;

    .line 51
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 54
    move-result-object v3

    .line 55
    check-cast v3, Landroid/content/Intent;

    .line 57
    iget-object v4, v0, Landroidx/work/impl/background/systemalarm/d;->k:Landroid/content/Intent;

    .line 59
    invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 62
    move-result v3

    .line 63
    if-eqz v3, :cond_0

    .line 65
    const/4 v3, 0x0

    .line 66
    iput-object v3, v0, Landroidx/work/impl/background/systemalarm/d;->k:Landroid/content/Intent;

    .line 68
    goto :goto_0

    .line 69
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 71
    const-string v7, "NZ3Vnhy+xGj3g1E3gDPI/na5KvmOeLryj4GSJeiWlx4CjIo="
    invoke-static {v7}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 73
    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 76
    throw v0

    .line 77
    :cond_1
    :goto_0
    iget-object v3, v0, Landroidx/work/impl/background/systemalarm/d;->d:Lnu;

    .line 79
    check-cast v3, Lp00;

    .line 81
    iget-object v3, v3, Lp00;->a:Lsr;

    .line 83
    iget-object v4, v0, Landroidx/work/impl/background/systemalarm/d;->h:Landroidx/work/impl/background/systemalarm/a;

    .line 85
    invoke-virtual {v4}, Landroidx/work/impl/background/systemalarm/a;->d()Z

    .line 88
    move-result v4

    .line 89
    if-nez v4, :cond_2

    .line 91
    iget-object v4, v0, Landroidx/work/impl/background/systemalarm/d;->j:Ljava/util/ArrayList;

    .line 93
    invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z

    .line 96
    move-result v4

    .line 97
    if-eqz v4, :cond_2

    .line 99
    invoke-virtual {v3}, Lsr;->a()Z

    .line 102
    move-result v3

    .line 103
    if-nez v3, :cond_2

    .line 105
    invoke-static {}, Ltj;->c()Ltj;

    .line 108
    move-result-object v3

    .line 109
    new-array v2, v2, [Ljava/lang/Throwable;

    .line 111
    invoke-virtual {v3, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 114
    iget-object v0, v0, Landroidx/work/impl/background/systemalarm/d;->l:Landroidx/work/impl/background/systemalarm/d$c;

    .line 116
    if-eqz v0, :cond_3

    .line 118
    check-cast v0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;

    .line 120
    invoke-virtual {v0}, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->e()V

    .line 123
    goto :goto_1

    .line 124
    :cond_2
    iget-object v2, v0, Landroidx/work/impl/background/systemalarm/d;->j:Ljava/util/ArrayList;

    .line 126
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    .line 129
    move-result v2

    .line 130
    if-nez v2, :cond_3

    .line 132
    invoke-virtual {v0}, Landroidx/work/impl/background/systemalarm/d;->g()V

    .line 135
    :cond_3
    :goto_1
    monitor-exit v1

    .line 136
    return-void

    .line 137
    :catchall_0
    move-exception v0

    .line 138
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 139
    throw v0
.end method
