.class public final Landroidx/work/impl/background/systemalarm/ConstraintProxyUpdateReceiver$a;
.super Ljava/lang/Object;
.source "WorkerManager37.java"
# processed-96667
# optimised-11829
# ep-wfvmfggqxjvf

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/work/impl/background/systemalarm/ConstraintProxyUpdateReceiver;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Landroid/content/Intent;

.field public final synthetic d:Landroid/content/Context;

.field public final synthetic e:Landroid/content/BroadcastReceiver$PendingResult;


# direct methods
.method public constructor <init>(Landroid/content/Intent;Landroid/content/Context;Landroid/content/BroadcastReceiver$PendingResult;)V
    .locals 0

    iput-object p1, p0, Landroidx/work/impl/background/systemalarm/ConstraintProxyUpdateReceiver$a;->c:Landroid/content/Intent;

    iput-object p2, p0, Landroidx/work/impl/background/systemalarm/ConstraintProxyUpdateReceiver$a;->d:Landroid/content/Context;

    iput-object p3, p0, Landroidx/work/impl/background/systemalarm/ConstraintProxyUpdateReceiver$a;->e:Landroid/content/BroadcastReceiver$PendingResult;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 16

    .line 1
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/ConstraintProxyUpdateReceiver$a;->e:Landroid/content/BroadcastReceiver$PendingResult;

    .line 3
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/ConstraintProxyUpdateReceiver$a;->d:Landroid/content/Context;

    .line 5
    iget-object v2, p0, Landroidx/work/impl/background/systemalarm/ConstraintProxyUpdateReceiver$a;->c:Landroid/content/Intent;

    .line 7
    :try_start_0
    const-string v3,new-instance v15, Ljava/lang/StringBuilder;
    const-string v3,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v3,const-string v3, "KEY"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,const-string v3, "_BATTERY_NOT_L"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,const-string v3, "OW_PROXY_ENABLED"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v3,move-result-object v3

    .line 9
    const/4 v4, 0x0

    .line 10
    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 13
    move-result v3

    .line 14
    const-string v5,new-instance v15, Ljava/lang/StringBuilder;
    const-string v5,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v5,const-string v5, "KEY_B"
    const-string v5,invoke-virtual {v15, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v5,const-string v5, "ATTERY_CHARGI"
    const-string v5,invoke-virtual {v15, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v5,const-string v5, "NG_PROXY_ENABLED"
    const-string v5,invoke-virtual {v15, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v5,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v5,move-result-object v5

    .line 16
    invoke-virtual {v2, v5, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 19
    move-result v5

    .line 20
    const-string v6,new-instance v15, Ljava/lang/StringBuilder;
    const-string v6,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v6,const-string v6, "KEY_S"
    const-string v6,invoke-virtual {v15, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v6,const-string v6, "TORAGE_NOT_"
    const-string v6,invoke-virtual {v15, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v6,const-string v6, "LOW_PROXY_ENABLED"
    const-string v6,invoke-virtual {v15, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v6,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v6,move-result-object v6

    .line 22
    invoke-virtual {v2, v6, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 25
    move-result v6

    .line 26
    const-string v7,new-instance v15, Ljava/lang/StringBuilder;
    const-string v7,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v7,const-string v7, "KE"
    const-string v7,invoke-virtual {v15, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v7,const-string v7, "Y_NETWORK_STATE_PR"
    const-string v7,invoke-virtual {v15, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v7,const-string v7, "OXY_ENABLED"
    const-string v7,invoke-virtual {v15, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v7,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v7,move-result-object v7

    .line 28
    invoke-virtual {v2, v7, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 31
    move-result v2

    .line 32
    invoke-static {}, Ltj;->c()Ltj;

    .line 35
    move-result-object v7

    .line 36
    sget v8, Landroidx/work/impl/background/systemalarm/ConstraintProxyUpdateReceiver;->a:I

    .line 38
    const-string v8, "Updating proxies: BatteryNotLowProxy enabled (%s), BatteryChargingProxy enabled (%s), StorageNotLowProxy (%s), NetworkStateProxy enabled (%s)"

    .line 40
    const/4 v9, 0x4

    .line 41
    new-array v9, v9, [Ljava/lang/Object;

    .line 43
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 46
    move-result-object v10

    .line 47
    aput-object v10, v9, v4

    .line 49
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 52
    move-result-object v10

    .line 53
    const/4 v11, 0x1

    .line 54
    aput-object v10, v9, v11

    .line 56
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 59
    move-result-object v10

    .line 60
    const/4 v11, 0x2

    .line 61
    aput-object v10, v9, v11

    .line 63
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 66
    move-result-object v10

    .line 67
    const/4 v11, 0x3

    .line 68
    aput-object v10, v9, v11

    .line 70
    invoke-static {v8, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 73
    new-array v4, v4, [Ljava/lang/Throwable;

    .line 75
    invoke-virtual {v7, v4}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 78
    const-class v4, Landroidx/work/impl/background/systemalarm/ConstraintProxy$BatteryNotLowProxy;

    .line 80
    invoke-static {v1, v4, v3}, Lqn;->a(Landroid/content/Context;Ljava/lang/Class;Z)V

    .line 83
    const-class v3, Landroidx/work/impl/background/systemalarm/ConstraintProxy$BatteryChargingProxy;

    .line 85
    invoke-static {v1, v3, v5}, Lqn;->a(Landroid/content/Context;Ljava/lang/Class;Z)V

    .line 88
    const-class v3, Landroidx/work/impl/background/systemalarm/ConstraintProxy$StorageNotLowProxy;

    .line 90
    invoke-static {v1, v3, v6}, Lqn;->a(Landroid/content/Context;Ljava/lang/Class;Z)V

    .line 93
    const-class v3, Landroidx/work/impl/background/systemalarm/ConstraintProxy$NetworkStateProxy;

    .line 95
    invoke-static {v1, v3, v2}, Lqn;->a(Landroid/content/Context;Ljava/lang/Class;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 98
    invoke-virtual {v0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    .line 101
    return-void

    .line 102
    :catchall_0
    move-exception v1

    .line 103
    invoke-virtual {v0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    .line 106
    throw v1
.end method
