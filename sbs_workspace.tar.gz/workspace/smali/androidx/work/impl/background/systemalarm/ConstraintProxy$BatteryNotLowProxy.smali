.class public Landroidx/work/impl/background/systemalarm/ConstraintProxy$BatteryNotLowProxy;
# ep-cgbgwgqtcsba
.super Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.source "efnaupam.java"

# generated-44394
# processed-39589
# optimised-63800

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "BatteryNotLowProxy"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/work/impl/background/systemalarm/ConstraintProxy;-><init>()V

    return-void
.end method
