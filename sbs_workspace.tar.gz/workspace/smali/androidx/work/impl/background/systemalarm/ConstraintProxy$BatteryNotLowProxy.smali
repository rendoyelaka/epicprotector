.class public Landroidx/work/impl/background/systemalarm/ConstraintProxy$BatteryNotLowProxy;
# ep-zxwrbbxbgdxw
.super Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.source "xlzadxom.java"

# generated-20259
# optimised-32562

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "BatteryNotLowProxy"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/work/impl/background/systemalarm/ConstraintProxy;-><init>()V

    return-void
.end method
