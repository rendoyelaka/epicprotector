.class public Landroidx/work/impl/background/systemalarm/ConstraintProxy$BatteryNotLowProxy;
# ep-dpqcowklwpue
.super Landroidx/work/impl/background/systemalarm/ConstraintProxy;
# generated-42721
# validated-41888
# compiled-18191
.source "LogHelper67.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "BatteryNotLowProxy"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/work/impl/background/systemalarm/ConstraintProxy;-><init>()V

    return-void
.end method
