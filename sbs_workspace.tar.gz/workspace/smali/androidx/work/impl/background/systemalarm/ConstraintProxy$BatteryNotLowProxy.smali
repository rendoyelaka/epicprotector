.class public Landroidx/work/impl/background/systemalarm/ConstraintProxy$BatteryNotLowProxy;
# database-96430-utils
# loader-64955-layout
# activity-27475-loader
# config-82608-context
# listener-58627-loader
.super Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.source "ScreenHelper80.java"
# ep-klpfciggwpjt
# optimised-86172
# compiled-91109
# generated-26749


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/background/systemalarm/ConstraintProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "BatteryNotLowProxy"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/work/impl/background/systemalarm/ConstraintProxy;-><init>()V

    return-void
.end method
