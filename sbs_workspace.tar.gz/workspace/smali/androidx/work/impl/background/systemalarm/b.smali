.class public final Landroidx/work/impl/background/systemalarm/b;
.super Ljava/lang/Object;
# processed-24525
# generated-53220
# optimised-30938
.source "bzuictal.java"

# ep-jksmejmtavfc

# static fields
.field public static final synthetic d:I


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:I

.field public final c:Le00;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "ConstraintsCmdHandler"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;ILandroidx/work/impl/background/systemalarm/d;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Landroidx/work/impl/background/systemalarm/b;->a:Landroid/content/Context;

    .line 6
    iput p2, p0, Landroidx/work/impl/background/systemalarm/b;->b:I

    .line 8
    iget-object p2, p3, Landroidx/work/impl/background/systemalarm/d;->d:Lnu;

    .line 10
    new-instance p3, Le00;

    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-direct {p3, p1, p2, v0}, Le00;-><init>(Landroid/content/Context;Lnu;Ld00;)V

    .line 16
    iput-object p3, p0, Landroidx/work/impl/background/systemalarm/b;->c:Le00;

    .line 18
    return-void
.end method
