.class public final Landroidx/work/impl/background/systemalarm/c;
# ep-xptfqzwejxca
.super Ljava/lang/Object;
.source "SourceFile"

# optimised-45248
# optimised-54251
# interfaces
.implements Ld00;
.implements Lic;
.implements LWorkTimer$b;


# instance fields
.field public final c:Landroid/content/Context;

.field public final d:I

.field public final e:Ljava/lang/String;

.field public final f:Landroidx/work/impl/background/systemalarm/d;

.field public final g:Le00;

.field public final h:Ljava/lang/Object;

.field public i:I

.field public j:Landroid/os/PowerManager$WakeLock;

.field public k:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "DelayMetCommandHandler"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;ILjava/lang/String;Landroidx/work/impl/background/systemalarm/d;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Landroidx/work/impl/background/systemalarm/c;->c:Landroid/content/Context;

    .line 6
    iput p2, p0, Landroidx/work/impl/background/systemalarm/c;->d:I

    .line 8
    iput-object p4, p0, Landroidx/work/impl/background/systemalarm/c;->f:Landroidx/work/impl/background/systemalarm/d;

    .line 10
    iput-object p3, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 12
    iget-object p2, p4, Landroidx/work/impl/background/systemalarm/d;->d:Lnu;

    .line 14
    new-instance p3, Le00;

    .line 16
    invoke-direct {p3, p1, p2, p0}, Le00;-><init>(Landroid/content/Context;Lnu;Ld00;)V

    .line 19
    iput-object p3, p0, Landroidx/work/impl/background/systemalarm/c;->g:Le00;

    .line 21
    const/4 p1, 0x0

    .line 22
    iput-boolean p1, p0, Landroidx/work/impl/background/systemalarm/c;->k:Z

    .line 24
    iput p1, p0, Landroidx/work/impl/background/systemalarm/c;->i:I

    .line 26
    new-instance p1, Ljava/lang/Object;

    .line 28
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 31
    iput-object p1, p0, Landroidx/work/impl/background/systemalarm/c;->h:Ljava/lang/Object;

    .line 33
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;Z)V
    .locals 4

    .line 1
    invoke-static {}, Ltj;->c()Ltj;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x2

    .line 6
    new-array v1, v1, [Ljava/lang/Object;

    .line 8
    const/4 v2, 0x0

    .line 9
    aput-object p1, v1, v2

    .line 11
    const/4 p1, 0x1

    .line 12
    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 15
    move-result-object v3

    .line 16
    aput-object v3, v1, p1

    .line 18
    const-string p1, "onExecuted %s, %s"

    .line 20
    invoke-static {p1, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 23
    new-array p1, v2, [Ljava/lang/Throwable;

    .line 25
    invoke-virtual {v0, p1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 28
    invoke-virtual {p0}, Landroidx/work/impl/background/systemalarm/c;->d()V

    .line 31
    iget p1, p0, Landroidx/work/impl/background/systemalarm/c;->d:I

    .line 33
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/c;->f:Landroidx/work/impl/background/systemalarm/d;

    .line 35
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/c;->c:Landroid/content/Context;

    .line 37
    if-eqz p2, :cond_0

    .line 39
    iget-object p2, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 41
    invoke-static {v1, p2}, Landroidx/work/impl/background/systemalarm/a;->c(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 44
    move-result-object p2

    .line 45
    new-instance v2, Landroidx/work/impl/background/systemalarm/d$b;

    .line 47
    invoke-direct {v2, p1, p2, v0}, Landroidx/work/impl/background/systemalarm/d$b;-><init>(ILandroid/content/Intent;Landroidx/work/impl/background/systemalarm/d;)V

    .line 50
    invoke-virtual {v0, v2}, Landroidx/work/impl/background/systemalarm/d;->f(Ljava/lang/Runnable;)V

    .line 53
    :cond_0
    iget-boolean p2, p0, Landroidx/work/impl/background/systemalarm/c;->k:Z

    .line 55
    if-eqz p2, :cond_1

    .line 57
    new-instance p2, Landroid/content/Intent;

    .line 59
    const-class v2, Landroidx/work/impl/background/systemalarm/SystemAlarmService;

    .line 61
    invoke-direct {p2, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 64
    const-string v1, "ACTION_CONSTRAINTS_CHANGED"

    .line 66
    invoke-virtual {p2, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 69
    new-instance v1, Landroidx/work/impl/background/systemalarm/d$b;

    .line 71
    invoke-direct {v1, p1, p2, v0}, Landroidx/work/impl/background/systemalarm/d$b;-><init>(ILandroid/content/Intent;Landroidx/work/impl/background/systemalarm/d;)V

    .line 74
    invoke-virtual {v0, v1}, Landroidx/work/impl/background/systemalarm/d;->f(Ljava/lang/Runnable;)V

    .line 77
    :cond_1
    return-void
.end method

.method public final b(Ljava/lang/String;)V
    .locals 3

    .line 1
    invoke-static {}, Ltj;->c()Ltj;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x1

    .line 6
    new-array v1, v1, [Ljava/lang/Object;

    .line 8
    const/4 v2, 0x0

    .line 9
    aput-object p1, v1, v2

    .line 11
    const-string p1, "Exceeded time limits on execution for %s"

    .line 13
    invoke-static {p1, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 16
    new-array p1, v2, [Ljava/lang/Throwable;

    .line 18
    invoke-virtual {v0, p1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 21
    invoke-virtual {p0}, Landroidx/work/impl/background/systemalarm/c;->g()V

    .line 24
    return-void
.end method

.method public final c(Ljava/util/ArrayList;)V
    .locals 0

    invoke-virtual {p0}, Landroidx/work/impl/background/systemalarm/c;->g()V

    return-void
.end method

.method public final d()V
    .locals 7

    .line 1
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/c;->h:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/c;->g:Le00;

    .line 6
    invoke-virtual {v1}, Le00;->d()V

    .line 9
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/c;->f:Landroidx/work/impl/background/systemalarm/d;

    .line 11
    iget-object v1, v1, Landroidx/work/impl/background/systemalarm/d;->e:LWorkTimer;

    .line 13
    iget-object v2, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 15
    invoke-virtual {v1, v2}, LWorkTimer;->b(Ljava/lang/String;)V

    .line 18
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/c;->j:Landroid/os/PowerManager$WakeLock;

    .line 20
    if-eqz v1, :cond_0

    .line 22
    invoke-virtual {v1}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    .line 25
    move-result v1

    .line 26
    if-eqz v1, :cond_0

    .line 28
    invoke-static {}, Ltj;->c()Ltj;

    .line 31
    move-result-object v1

    .line 32
    const-string v2, "Releasing wakelock %s for WorkSpec %s"

    .line 34
    const/4 v3, 0x2

    .line 35
    new-array v3, v3, [Ljava/lang/Object;

    .line 37
    iget-object v4, p0, Landroidx/work/impl/background/systemalarm/c;->j:Landroid/os/PowerManager$WakeLock;

    .line 39
    const/4 v5, 0x0

    .line 40
    aput-object v4, v3, v5

    .line 42
    iget-object v4, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 44
    const/4 v6, 0x1

    .line 45
    aput-object v4, v3, v6

    .line 47
    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 50
    new-array v2, v5, [Ljava/lang/Throwable;

    .line 52
    invoke-virtual {v1, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 55
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/c;->j:Landroid/os/PowerManager$WakeLock;

    .line 57
    invoke-virtual {v1}, Landroid/os/PowerManager$WakeLock;->release()V

    .line 60
    :cond_0
    monitor-exit v0

    .line 61
    return-void

    .line 62
    :catchall_0
    move-exception v1

    .line 63
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 64
    throw v1
.end method

.method public final e(Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 3
    invoke-interface {p1, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 6
    move-result p1

    .line 7
    if-nez p1, :cond_0

    .line 9
    return-void

    .line 10
    :cond_0
    iget-object p1, p0, Landroidx/work/impl/background/systemalarm/c;->h:Ljava/lang/Object;

    .line 12
    monitor-enter p1

    .line 13
    :try_start_0
    iget v0, p0, Landroidx/work/impl/background/systemalarm/c;->i:I

    .line 15
    const/4 v1, 0x1

    .line 16
    const/4 v2, 0x0

    .line 17
    if-nez v0, :cond_2

    .line 19
    iput v1, p0, Landroidx/work/impl/background/systemalarm/c;->i:I

    .line 21
    invoke-static {}, Ltj;->c()Ltj;

    .line 24
    move-result-object v0

    .line 25
    const-string v3, "onAllConstraintsMet for %s"

    .line 27
    new-array v1, v1, [Ljava/lang/Object;

    .line 29
    iget-object v4, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 31
    aput-object v4, v1, v2

    .line 33
    invoke-static {v3, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 36
    new-array v1, v2, [Ljava/lang/Throwable;

    .line 38
    invoke-virtual {v0, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 41
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/c;->f:Landroidx/work/impl/background/systemalarm/d;

    .line 43
    iget-object v0, v0, Landroidx/work/impl/background/systemalarm/d;->f:Luo;

    .line 45
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 47
    const/4 v2, 0x0

    .line 48
    invoke-virtual {v0, v1, v2}, Luo;->h(Ljava/lang/String;Landroidx/work/WorkerParameters$a;)Z

    .line 51
    move-result v0

    .line 52
    if-eqz v0, :cond_1

    .line 54
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/c;->f:Landroidx/work/impl/background/systemalarm/d;

    .line 56
    iget-object v0, v0, Landroidx/work/impl/background/systemalarm/d;->e:LWorkTimer;

    .line 58
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 60
    invoke-virtual {v0, v1, p0}, LWorkTimer;->a(Ljava/lang/String;LWorkTimer$b;)V

    .line 63
    goto :goto_0

    .line 64
    :cond_1
    invoke-virtual {p0}, Landroidx/work/impl/background/systemalarm/c;->d()V

    .line 67
    goto :goto_0

    .line 68
    :cond_2
    invoke-static {}, Ltj;->c()Ltj;

    .line 71
    move-result-object v0

    .line 72
    const-string v3, "Already started work for %s"

    .line 74
    new-array v1, v1, [Ljava/lang/Object;

    .line 76
    iget-object v4, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 78
    aput-object v4, v1, v2

    .line 80
    invoke-static {v3, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 83
    new-array v1, v2, [Ljava/lang/Throwable;

    .line 85
    invoke-virtual {v0, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 88
    :goto_0
    monitor-exit p1

    .line 89
    return-void

    .line 90
    :catchall_0
    move-exception v0

    .line 91
    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 92
    throw v0
.end method

.method public final f()V
    .locals 6

    .line 1
    const/4 v0, 0x2

    .line 2
    new-array v1, v0, [Ljava/lang/Object;

    .line 4
    const/4 v2, 0x0

    .line 5
    iget-object v3, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 7
    aput-object v3, v1, v2

    .line 9
    iget v4, p0, Landroidx/work/impl/background/systemalarm/c;->d:I

    .line 11
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 14
    move-result-object v4

    .line 15
    const/4 v5, 0x1

    .line 16
    aput-object v4, v1, v5

    .line 18
    const-string v4, "%s (%s)"

    .line 20
    invoke-static {v4, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 23
    move-result-object v1

    .line 24
    iget-object v4, p0, Landroidx/work/impl/background/systemalarm/c;->c:Landroid/content/Context;

    .line 26
    invoke-static {v4, v1}, Lhz;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/os/PowerManager$WakeLock;

    .line 29
    move-result-object v1

    .line 30
    iput-object v1, p0, Landroidx/work/impl/background/systemalarm/c;->j:Landroid/os/PowerManager$WakeLock;

    .line 32
    invoke-static {}, Ltj;->c()Ltj;

    .line 35
    move-result-object v1

    .line 36
    new-array v0, v0, [Ljava/lang/Object;

    .line 38
    iget-object v4, p0, Landroidx/work/impl/background/systemalarm/c;->j:Landroid/os/PowerManager$WakeLock;

    .line 40
    aput-object v4, v0, v2

    .line 42
    aput-object v3, v0, v5

    .line 44
    const-string v4, "Acquiring wakelock %s for WorkSpec %s"

    .line 46
    invoke-static {v4, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 49
    new-array v0, v2, [Ljava/lang/Throwable;

    .line 51
    invoke-virtual {v1, v0}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 54
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/c;->j:Landroid/os/PowerManager$WakeLock;

    .line 56
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->acquire()V

    .line 59
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/c;->f:Landroidx/work/impl/background/systemalarm/d;

    .line 61
    iget-object v0, v0, Landroidx/work/impl/background/systemalarm/d;->g:LWorkManagerImpl;

    .line 63
    iget-object v0, v0, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 65
    invoke-virtual {v0}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 68
    move-result-object v0

    .line 69
    check-cast v0, LWorkSpecDao;

    .line 71
    invoke-virtual {v0, v3}, LWorkSpecDao;->h(Ljava/lang/String;)LWorkSpec;

    .line 74
    move-result-object v0

    .line 75
    if-nez v0, :cond_0

    .line 77
    invoke-virtual {p0}, Landroidx/work/impl/background/systemalarm/c;->g()V

    .line 80
    return-void

    .line 81
    :cond_0
    invoke-virtual {v0}, LWorkSpec;->b()Z

    .line 84
    move-result v1

    .line 85
    iput-boolean v1, p0, Landroidx/work/impl/background/systemalarm/c;->k:Z

    .line 87
    if-nez v1, :cond_1

    .line 89
    invoke-static {}, Ltj;->c()Ltj;

    .line 92
    move-result-object v0

    .line 93
    new-array v1, v5, [Ljava/lang/Object;

    .line 95
    aput-object v3, v1, v2

    .line 97
    const-string v4, "No constraints for %s"

    .line 99
    invoke-static {v4, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 102
    new-array v1, v2, [Ljava/lang/Throwable;

    .line 104
    invoke-virtual {v0, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 107
    invoke-static {v3}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 110
    move-result-object v0

    .line 111
    invoke-virtual {p0, v0}, Landroidx/work/impl/background/systemalarm/c;->e(Ljava/util/List;)V

    .line 114
    goto :goto_0

    .line 115
    :cond_1
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/c;->g:Le00;

    .line 117
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 120
    move-result-object v0

    .line 121
    invoke-virtual {v1, v0}, Le00;->c(Ljava/util/Collection;)V

    .line 124
    :goto_0
    return-void
.end method

.method public final g()V
    .locals 7

    .line 1
    iget-object v0, p0, Landroidx/work/impl/background/systemalarm/c;->h:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget v1, p0, Landroidx/work/impl/background/systemalarm/c;->i:I

    .line 6
    const/4 v2, 0x2

    .line 7
    const/4 v3, 0x1

    .line 8
    const/4 v4, 0x0

    .line 9
    if-ge v1, v2, :cond_1

    .line 11
    iput v2, p0, Landroidx/work/impl/background/systemalarm/c;->i:I

    .line 13
    invoke-static {}, Ltj;->c()Ltj;

    .line 16
    move-result-object v1

    .line 17
    const-string v2, "Stopping work for WorkSpec %s"

    .line 19
    new-array v5, v3, [Ljava/lang/Object;

    .line 21
    iget-object v6, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 23
    aput-object v6, v5, v4

    .line 25
    invoke-static {v2, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 28
    new-array v2, v4, [Ljava/lang/Throwable;

    .line 30
    invoke-virtual {v1, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 33
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/c;->c:Landroid/content/Context;

    .line 35
    iget-object v2, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 37
    new-instance v5, Landroid/content/Intent;

    .line 39
    const-class v6, Landroidx/work/impl/background/systemalarm/SystemAlarmService;

    .line 41
    invoke-direct {v5, v1, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 44
    const-string v1, "ACTION_STOP_WORK"

    .line 46
    invoke-virtual {v5, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 49
    const-string v1, "KEY_WORKSPEC_ID"

    .line 51
    invoke-virtual {v5, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 54
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/c;->f:Landroidx/work/impl/background/systemalarm/d;

    .line 56
    new-instance v2, Landroidx/work/impl/background/systemalarm/d$b;

    .line 58
    iget v6, p0, Landroidx/work/impl/background/systemalarm/c;->d:I

    .line 60
    invoke-direct {v2, v6, v5, v1}, Landroidx/work/impl/background/systemalarm/d$b;-><init>(ILandroid/content/Intent;Landroidx/work/impl/background/systemalarm/d;)V

    .line 63
    invoke-virtual {v1, v2}, Landroidx/work/impl/background/systemalarm/d;->f(Ljava/lang/Runnable;)V

    .line 66
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/c;->f:Landroidx/work/impl/background/systemalarm/d;

    .line 68
    iget-object v1, v1, Landroidx/work/impl/background/systemalarm/d;->f:Luo;

    .line 70
    iget-object v2, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 72
    invoke-virtual {v1, v2}, Luo;->e(Ljava/lang/String;)Z

    .line 75
    move-result v1

    .line 76
    if-eqz v1, :cond_0

    .line 78
    invoke-static {}, Ltj;->c()Ltj;

    .line 81
    move-result-object v1

    .line 82
    const-string v2, "WorkSpec %s needs to be rescheduled"

    .line 84
    new-array v3, v3, [Ljava/lang/Object;

    .line 86
    iget-object v5, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 88
    aput-object v5, v3, v4

    .line 90
    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 93
    new-array v2, v4, [Ljava/lang/Throwable;

    .line 95
    invoke-virtual {v1, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 98
    iget-object v1, p0, Landroidx/work/impl/background/systemalarm/c;->c:Landroid/content/Context;

    .line 100
    iget-object v2, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 102
    invoke-static {v1, v2}, Landroidx/work/impl/background/systemalarm/a;->c(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 105
    move-result-object v1

    .line 106
    iget-object v2, p0, Landroidx/work/impl/background/systemalarm/c;->f:Landroidx/work/impl/background/systemalarm/d;

    .line 108
    new-instance v3, Landroidx/work/impl/background/systemalarm/d$b;

    .line 110
    iget v4, p0, Landroidx/work/impl/background/systemalarm/c;->d:I

    .line 112
    invoke-direct {v3, v4, v1, v2}, Landroidx/work/impl/background/systemalarm/d$b;-><init>(ILandroid/content/Intent;Landroidx/work/impl/background/systemalarm/d;)V

    .line 115
    invoke-virtual {v2, v3}, Landroidx/work/impl/background/systemalarm/d;->f(Ljava/lang/Runnable;)V

    .line 118
    goto :goto_0

    .line 119
    :cond_0
    invoke-static {}, Ltj;->c()Ltj;

    .line 122
    move-result-object v1

    .line 123
    const-string v2, "Processor does not have WorkSpec %s. No need to reschedule "

    .line 125
    new-array v3, v3, [Ljava/lang/Object;

    .line 127
    iget-object v5, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 129
    aput-object v5, v3, v4

    .line 131
    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 134
    new-array v2, v4, [Ljava/lang/Throwable;

    .line 136
    invoke-virtual {v1, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 139
    goto :goto_0

    .line 140
    :cond_1
    invoke-static {}, Ltj;->c()Ltj;

    .line 143
    move-result-object v1

    .line 144
    const-string v2, "Already stopped work for %s"

    .line 146
    new-array v3, v3, [Ljava/lang/Object;

    .line 148
    iget-object v5, p0, Landroidx/work/impl/background/systemalarm/c;->e:Ljava/lang/String;

    .line 150
    aput-object v5, v3, v4

    .line 152
    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 155
    new-array v2, v4, [Ljava/lang/Throwable;

    .line 157
    invoke-virtual {v1, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 160
    :goto_0
    monitor-exit v0

    .line 161
    return-void

    .line 162
    :catchall_0
    move-exception v1

    .line 163
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 164
    throw v1
.end method
