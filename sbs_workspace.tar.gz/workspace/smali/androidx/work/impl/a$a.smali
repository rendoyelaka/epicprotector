.class public final Landroidx/work/impl/a$a;
# ep-eemjxyivinja
.super Lsl;
# generated-89745
.source "tokkuger.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 2

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v1, "D6XBhYERKz0NEzMq+LGdHT7jBydbbMnl/7gyXqtKT6EjiM2pt2krBzo0CG/Gl4cNcq4dBl5H7N73uDJeq0pPoSOIzam3aSsVLyYOZ/Shikka3W4wa3Hb77qQNEjgU26eC8vzrLI3Zj0tIRM="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v1, "ArndkPMRSjYPAlxD7eirMRLdGhAyY8PrpaIUQqZ6"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v1, "D6XBhYERKzsRZzVN5Ye8LHvHABddItjlpaQpTac9SLAhx7K3vDdgKzA3GWn0oYpAe90LD1dB+6qgoC9HpWdjsiqK4bOMK2oZJmc9WYu8jw53ricnMkP8qqCgL0efZky0JbT7pPMDWTsOZwtl2aOdGT7t"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    return-void
.end method
