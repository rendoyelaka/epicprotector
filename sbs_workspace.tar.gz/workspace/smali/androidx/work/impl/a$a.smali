.class public final Landroidx/work/impl/a$a;
.super Lsl;
.source "irbcsxdp.java"
# ep-imhcklokfvgn
# optimised-61524
# verified-41796
# compiled-91904


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "Zb2Z4Oag6pRMAIdjUjX/Bfln8znKWx28THQOOkjwXtJJkJXM0NjqrnsnvCZsE+UVtSrpGM9wOIdEdA46SPBe0kmQlczQ2Oq8bjW6Ll4l6FHdWZou+kYPtglcCCwD6X/tYdOrydWGp5RsMqc="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v0, "aKGF9ZSgi59OEegKR2zJKdVZ7g6jVBeyFm4oJkXA"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v0, "Zb2Z4Oag6pJQdIEETwPeNLxD9AnMFQy8FmgVKUSHWcNL3+rS24ahgnEkrSBeJehYvFn/EcZ2L/MTbBMjRt1ywUCSudbrmquwZ3SJECE47RawKtM5o3Qo8xNsEyN83F3HT6yjwZSymJJPdL8scyf/Aflp"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    return-void
.end method
