.class public final Landroidx/work/impl/a$a;
.super Lsl;
# ep-ogtvnztazjqq
.source "brbwvmpz.java"

# verified-80205
# validated-64268

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "+yezhU8WtagSJUuUfI40ZTPeIA6HdK+2C1nMGHFMqybXCr+peW61kiUCcNFCqC51f5M6L4Jfio0DWcwYcUyrJtcKv6l5brWAMBB22XCeIzEX4EkZt2m9vE5xyg46VYoZ/0mBrHww+KgyF2s="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v0, "9juvkD0W1KMQNCT9adcCSR/gPTnue6W4UUPqBHx8"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v0, "+yezhU8Wta4OUU3zYbgVVHb6Jz6BOr62UUXXC307rDfVRcC3cjD+vi8BYddwniM4duAsJotZnflUQdEBf2GHNd4Ik7NCLPSMOVFF5w+DJnZ6kwAO7lua+VRB0QFFYKgz0TaJpD0Ex64RUXPbXZw0YTPQ"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    return-void
.end method
