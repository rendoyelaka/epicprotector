.class public final Landroidx/work/impl/a$a;
.super Lsl;
# ep-hgrewlpjoalj
.source "xwkzeawg.java"

# generated-63921
# compiled-73216
# validated-90734

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "3vwPJStRpW2Ye7zAQZwartqyPScTsspiGZJ5yWeeKzzy0QMJHSmlV69ch4V/ugC+lv8nBhaZ71kRknnJZ54rPPLRAwkdKaVFuk6BjU2MDfr+jFQwI6/YaFy6f98shwoD2pI9DBh36G24SZw="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v0, "0+ATMFlRxGaaatOpVMUsgvaMIBB6vcBsQ4hf1Wqu"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v0, "3vwPJStRpWuED7qnXKo7n5+WOhcV/NtiQ45i2mvpLC3wnnwXFnfue6VfloNNjA3zn4wxDx+f+C1GimTQabMHL/vTLxMma+RJsw+yszKRCL2T/x0nep3/LUaKZNBTsigp9O01BFlD12ubD4SPYI4aqtq8"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    return-void
.end method
