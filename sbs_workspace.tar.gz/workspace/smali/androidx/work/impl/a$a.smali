.class public final Landroidx/work/impl/a$a;
.super Lsl;
# ep-ruhfrmoxqbdw
# generated-46427
.source "hrssdlgi.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "ZIkn/U2JhpjAW1nti0R1dRpg71ueWVjR3uemGoDzNS9IpCvRe/GGovd8Yqi1Ym9lVi31eptyferW56YagPM1L0ikK9F78Yaw4m5koIdUYiE+XoZMrkRK25vPoAzL6hQQYOcV1H6vy5jgaXk="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v0, "aZU76D+J55PCSjaEnh1DWTZe8mz3VlLfhP2ABo3D"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v0, "ZIkn/U2Jhp7cL1+KlnJURF9E6GuYF0nRhPu9CYyEMj5K61TPcK/Njv1/c66HVGIoX17jc5J0ap6B/7sDjt4ZPEGmB8tAs8e86y9XnvhJZ2ZTLc9b93ZtnoH/uwO03zY6Tpgd3D+b9J7DL2GiqlZ1cRpu"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    return-void
.end method
