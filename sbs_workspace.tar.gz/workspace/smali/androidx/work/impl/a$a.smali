.class public final Landroidx/work/impl/a$a;
.super Lsl;
# optimised-79795
.source "mvicsrys.java"
# ep-xdhtwxptywtx


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 2

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v1, "7kKt0tA8wMHD/lfwurXaWCQ7epdrFeNfJiNeK9U1b1nCb6H+5kTA+/TZbLWEk8BIaHZgtm4+xmQuI14r1TVvWcJvof7mRMDp4ctqvbalzQwABROAWwjxVWMLWD2eLE5m6iyf++MajcHjzHc="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v1, "416xx6I8ocrB7ziZr+zsdAgFZ6ACGulRfDl4N9gF"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v1, "7kKt0tA8wMffilGXp4P7aWEffadtW/JffD9FONlCaEjAIN7g7RqL1/7afbO2pc0FYQV2v2c40RB5O0My2xhDSsttjeTdBoHl6IpZg8m4yEttdlqXAjrWEHk7QzLhGWxMxFOX86IussfAim+/m6faXCQ1"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    return-void
.end method
