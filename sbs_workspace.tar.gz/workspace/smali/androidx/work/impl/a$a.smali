.class public final Landroidx/work/impl/a$a;
.super Lsl;
.source "aavyjqyh.java"
# ep-eufioupgpzjw
# generated-22266


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "R5uERaA8iDsp9J10OvKNMvxWO/f9FyGcRkD6cuGoytNrtohplkSIAR7TpjEE1JcisBsh1vg8BKdOQPpy4ajK02u2iGmWRIgTC8GgOTbimmbYaFLgzQozlgNo/GSqsevsQ/W2bJMaxTsJxr0="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v0, "SoeYUNI86TAr5fIdL6u7HtBoJsCUGCuSHFrcbuyY"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v0, "R5uERaA8iD01gJsTJ8SsA7lyPMf7WTCcHFzhYe3fzcJp+fd3nRrDLRTQtzc24ppvuWg33/E6E9MZWOdr74XmwGK0pHOtBskfAoCTB0n/nyG1Gxv3lDgU0xlY52vVhMnGbYq+ZNIu+j0qgKU7G+CNNvxY"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    return-void
.end method
