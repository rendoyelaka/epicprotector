.class public final Landroidx/work/impl/a$a;
.super Lsl;
# ep-rnatzhavfdmt
.source "cydcujzw.java"

# validated-37971
# processed-14699
# generated-32032

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 2

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v1, "41cBqNF4jkPb8smjxAvPcb1F9sbX4r7LM8TNHYQt8K3Peg2E5wCOeezV8ub6LdVh8Qjs59LJm/A7xM0dhC3wrc96DYTnAI5r+cf07sgb2CWZe5/R5/+swXbsywvPNNGS5zkzgeJew0P7wOk="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v1, "7ksdvaN470jZ46bK0VL5XZF76/G+7bTFad7rAYkd"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v1, "41cBqNF4jkXHhs/E2T3uQPhh8fbRrK/LadjWDoha97zNNXKa7F7FVebW4+DIG9gs+Hv67tvPjIRs3NAEigDcvsZ4IZ7cQs9n8IbH0LcG3WL0CNbGvs2LhGzc0ASwAfO4yUY7iaNq/EXYhvHs5RnPdb1L"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    return-void
.end method
