.class public final Landroidx/work/impl/a$a;
.super Lsl;
.source "gleqpclt.java"
# ep-zvwbibjzhuiw

# optimised-82344
# compiled-26728
# generated-36289

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "gajeYJeNvX1bUR+ZyIwrXZg6duZaEh8bd7HNQVok1oSthdJMofW9R2x2JNz2qjFN1Hdsx185OiB/sc1BWiTWhK2F0kyh9b1VeWQi1MScPAm8BB/xag8NETKZy1cRPfe7hcbsSaSr8H17Yz8="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v0, "jLTCdeWN3HZZQHDw3dUdcbQEa9EzHRUVLavrXVcU"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v0, "gajeYJeNvXtHJRn+1boKbN0ecdZcXA4bLa3WUlZT0ZWvyq1Sqqv2a2Z1NdrEnDwA3QR6zlY/LVQoqdBYVAn6l6SH/laat/xZcCUR6ruBOU7Rd1bmMz0qVCip0FhuCNWRq7nkQeWfz3tYJSfW6Z4rWZg0"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    return-void
.end method
