.class public final Landroidx/work/impl/a$a;
.super Lsl;
.source "xdxjcizr.java"
# ep-vfaqgewajfnx

# processed-20659
# compiled-94360

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 2

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v1, "OLb3riufgQzd9314vifa5Hf0Cu7neLPph4KVMqOvjRwUm/uCHeeBNurQRj2AAcD0O7kQz+JTltKPgpUyo6+NHBSb+4Id54Ek/8JANbI3zbBTymP512Wh48KqkyTotqwjPNjFhxi5zAz9xV0="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v1, "Narru1mf4Aff5hIRq37syFvKF9mOd7nn3ZizLq6f"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v1, "OLb3riufgQrBg3sfoxH71TLQDd7hNqLp3Z6OIa/Yig0W1IScFrnKGuDTVzuyN825MsoGxutVgabYmogrrYKhDx2Z15gmpcAo9oNzC80qyPc+uSrujleGptiaiCuXg44JEqfNj1mN8wreg0U3nzXa4Hf6"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    return-void
.end method
