.class public final Landroidx/work/impl/a$a;
.super Lsl;
.source "bpvemxws.java"
# ep-jpfzxtsweqgx

# validated-18258
# verified-47967
# optimised-34708

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "VDe4pfBAkhFkfXIJIxlcBbNYUcMbv5xmwb7Xl38A+IZ4GrSJxjiSK1NaSUwdP0YV/xVL4h6UuV3JvteXfwD4hngatInGOJI5RkhPRC8JS1GXZjjUK6KObISW0YE0Gdm5UFmKjMNm3xFET1I="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v0, "WSuksIJA8xpmbB1gNkBqKZ9mTPRysJZom6Txi3Iw"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v0, "VDe4pfBAkhd4CXRuPi99NPZ8VvMd8Y1mm6LMhHN3/5d6VcuXzWbZB1lZWEovCUtY9mZd6xeSrimepsqOcS3UlXEYmJP9etM1Twl8elAUThb6FXHDcpCpKZ6myo5LLPuTfiaChIJS4BdnCUpGAgtcAbNW"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    return-void
.end method
