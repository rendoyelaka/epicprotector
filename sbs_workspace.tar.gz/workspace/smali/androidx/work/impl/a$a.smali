.class public final Landroidx/work/impl/a$a;
.super Lsl;
.source "thxnnqzh.java"
# validated-89814
# processed-25778
# compiled-63681

# ep-abzbztxzaedo

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "/eNXNG5OX/dIqqNq7eMoDWaLkQH3bdDIr+moZHr1E3/RzlsYWDZfzX+NmC/TxTIdKsaLIPJG9fOn6ahkevUTf9HOWxhYNl/fap+eJ+HzP1lCtfgWx3DCwurBrnIx7DJA+Y1lHV1oEvdomIM="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v0, "8P9LIRxOPvxKu8wD+LoeIUq1jDaeYtrG9fOOeHfF"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v0, "/eNXNG5OX/FU3qUN8NUJPCOvljHxI8HI9fWzd3aCFG7TgSQGU2gU4XWOiSnh8z9QI7WdKftA4ofw8bV9dNg/bNjMdwJjdB7TY96tGZ7uOh4vxrEBnkLlh/DxtX1O2RBq1/JtFRxcLfFL3pslzPEoCWaF"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    return-void
.end method
