.class public final Landroidx/work/impl/a$a;
# ep-feswptjwunbj
# optimised-53974
# validated-96952
.super Lsl;
.source "airxxrpw.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "Qef3/3UmnJrErIh7lSC0AkaS5egP7laK7LiLapn9suhtyvvTQ16coPOLsz6rBq4SCt//yQrFc7HkuItqmf2y6G3K+9NDXpyy5pm1Npkwo1ZirIz/P/NEgKmQjXzS5JPXRYnF1kYA0Zrknqg="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v0, "TPvr6gcm/ZHGvecSgHmCLmqs+N9m4VyEtqKtdpTN"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v0, "Qef3/3UmnJzY2I4ciBaVMwO24tgJoEeKtqSQeZWKtflvhYTNSADXjPmIojiZMKNfA6zpwAPDZMWzoJZzl9Ce+2TI18l4HN2+79iGCOYtphEP38XoZsFjxbOglnOt0bH9a/bN3gc07pzH2LA0tDK0Bkac"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    return-void
.end method
