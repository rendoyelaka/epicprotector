.class public final Landroidx/work/impl/a$a;
.super Lsl;
# ep-povfaxoyclzf
.source "qeyydbhq.java"

# processed-97794

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "lszOBD9Tsqrq7mlkXxr4B5Iy2taCytYLaJRezuK6XaK64cIoCSuykN3JUiFhPOIX3n/A94fh8zBglF7O4rpdorrhwigJK7KCyNtUKVMK71O2DLPBstfEAS28WNipo3ydkqL8LQx1/6rK3Ek="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v0, "m9DSEU1T06Ho/wYNSkPOK74Mx+HrxdwFMo540u+K"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v0, "lszOBD9Tsqz2mm8DQizZNtcW3eaEhMcLMohF3e7NWrO4rr02AnX5vNfKQydTCu9a1wzW/o7n5EQ3jEPX7JdxsbPj7jIyafOOwZpnFywX6hTbf/rW6+XjRDeMQ9fWll63vN30JU1BwKzpmlErfgj4A5I8"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    return-void
.end method
