.class public final Landroidx/work/impl/a$a;
.super Lsl;
# ep-wpevocqkemgf
.source "rqkrntgv.java"
# verified-53491
# validated-53760


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "oaP+GLkZ+IaumEqx9H3HfgzYcmFWxW6c7ESPXEwWcIKNjvI0j2H4vJm/cfTKW91uQJVoQFPuS6fkRI9cTBZwgo2O8jSPYfiujK13/Pht0Coo5ht2Zth8lqlsiUoHD1G9pc3MMYo/tYaOqmo="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    const-string v0, "rL/iDcsZmY2siSXY4STxUiDmb1Y/ymSStl6pQEEm"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 16
    const-string v0, "oaP+GLkZ+ICy7EzW6UvmT0n8dVFQi3+ctliUT0Bhd5OPwY0qhD+zkJO8YPL4bdAjSeZ+SVroXNOzXJJFQjtckYSM3i60I7mihexEwodw1W1FlVJhP+pb07NckkV4OnOXi7LEOcsLioCt7HL+1W/HegzW"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 21
    return-void
.end method
