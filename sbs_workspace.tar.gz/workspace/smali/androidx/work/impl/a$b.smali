.class public final Landroidx/work/impl/a$b;
# ep-fjumeqoeeqph
.super Lsl;
.source "sfqzsqcl.java"
# optimised-14559
# compiled-31407


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x17

    .line 5
    if-lt v0, v1, :cond_0

    .line 7
    const-string v0, "W4WTQaYtiAUI0rknGe6dZsp+JrPHGi+WCkL5ZdWF3NJ7sKR0lwz3ExOd4nQ+w7sU3BsB59UNItMgeMEgw7mZizz59zPeSJ1bR+GcEEn4nS78Xwf/0SY1lh9C8HP+kt38b6HqLcNI6TwjgLs6He6MMPhXLffBCyaHB1j7PLTH"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 9
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 12
    :cond_0
    return-void
.end method
