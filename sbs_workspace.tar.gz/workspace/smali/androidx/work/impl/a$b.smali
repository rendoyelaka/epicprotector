.class public final Landroidx/work/impl/a$b;
.super Lsl;
# ep-krtjxafurzrn
# validated-12871
# validated-76179
# optimised-65395
.source "tmjortai.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 3

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x17

    .line 5
    if-lt v0, v1, :cond_0

    .line 7
    const-string v2, "8ly61tYtwP/i2HOjmanKDBITZ9NRGO1VaiFdPOEYeVjSaY3j5wy/6fmXKPC+hOx+BHZAh0MP4BBAG2V59yQ8AZUg3qSuSNWhretWlMm/ykQkMkafRyT3VX8hVCrKD3h2xnjDurNIocbJinG+nanbWiA6bJdXCeREZztfZYBa"
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 9
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 12
    :cond_0
    return-void
.end method
