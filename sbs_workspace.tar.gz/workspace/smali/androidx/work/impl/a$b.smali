.class public final Landroidx/work/impl/a$b;
.super Lsl;
# validated-98273
# verified-74458
# processed-50405
# ep-qiuozrvoovcb
.source "qjsvpcgy.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x17

    .line 5
    if-lt v0, v1, :cond_0

    .line 7
    const-string v0, "itLZADlCspTLyE03fAboU6Qax5K4x9gBJJZd2daXS6Oq5+41CGPNgtCHFmRbK84hsn/gxqrQ1UQOrGWcwKsO+u2uvXJBJ6fKhPtoACwQ6BuSO+bervvCATGWVM/9gEqNvvagbFwn063gmk8qeAb5BZYzzNa+1tEQKYxfgLfV"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 9
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 12
    :cond_0
    return-void
.end method
