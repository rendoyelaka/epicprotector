.class public final Landroidx/work/impl/a$b;
.super Lsl;
# processed-64444
# validated-90079
.source "kzcfikgc.java"

# ep-rweotqrfrcue

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x17

    .line 5
    if-lt v0, v1, :cond_0

    .line 7
    const-string v0, "HwcHlmI4wXyj3oF42VRF9S0r5Mjg29izrWtt0ZIAJs8/MjCjUxm+ariR2iv+eWOHO07DnPLM1faHUVWUhDxjlnh7Y+QaXdQi7O2kT4lCRb0bCsWE9ufCs7hrZMe5FyfhKyN++gddoEWIjINl3VRUox8C74zmytGioHFviPNC"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 9
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 12
    :cond_0
    return-void
.end method
