.class public final Landroidx/work/impl/a$b;
# ep-xdgkaqtjengo
# optimised-53001
.super Lsl;
.source "spmynxvx.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x17

    .line 5
    if-lt v0, v1, :cond_0

    .line 7
    const-string v0, "vb3pHL8I+LiPvm7i12HXKjrwbyVsyGCWoEaMS3g7ZoOdiN4pjimHrpTxNbHwTPFYLJVIcX7fbdOKfLQObgcj2trBjW7Hbe3mwI1L1Yd312IM0U5pevR6lrVGhV1TLGetiZmQcNptmYGk7Gz/02HGfAjZZGFq2WmHrVyOEhl5"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 9
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 12
    :cond_0
    return-void
.end method
