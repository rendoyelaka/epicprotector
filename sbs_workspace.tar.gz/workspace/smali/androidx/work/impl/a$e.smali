.class public final Landroidx/work/impl/a$e;
.super Lsl;
# ep-xqrdordgjfwl
.source "vukaivoo.java"

# generated-47436

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_p45t4b2d
    goto :ep_s_p45t4b2d
    :ep_d_p45t4b2d
    nop
    :ep_s_p45t4b2d
    const/16 v1, 0x8

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_wy6g9joo
    goto :ep_s_wy6g9joo
    :ep_d_wy6g9joo
    nop
    :ep_s_wy6g9joo
    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `workspec` (`period_start_time`)"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
