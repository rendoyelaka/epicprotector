.class public final Landroidx/work/impl/a$e;
.super Lsl;
.source "xbzscueq.java"

# optimised-83272
# ep-rozbjtmhfypn

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x7

    const/16 v1, 0x8

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "q7/oHL8I+IauiEDJh03yKif6byVa80GgkGDATk4nZ5eQsvoymSaLv4WvWuHCdt1lDepIcX7ZfKywWo1LR2lMvMiN2jKZJqu/ha9lsY9kxG8b3FRhQNh8krZHv1pOJGaSwQ=="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
