.class public final Landroidx/work/impl/a$e;
# ep-apdiydqdlmfa
# optimised-79973
# generated-83220
.super Lsl;
.source "xaqqvwvi.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x7

    const/16 v1, 0x8

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "8TulgUkHtagSNUHsD74BMRj8PUqLQoCKd32DCnN9vDPKNrevbynGkTkSW8RKhS5+MuwaHq9ovYZXR84PejOXGJIJl69vKeaRORJklAeXN3Qk2gYOkWm9uFFa/B5zfr02mw=="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
