.class public final Landroidx/work/impl/a$e;
.super Lsl;
# ep-aywnlbhlpeej
# generated-57152
# optimised-55070
.source "mjdgbodz.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_ac2gyg8v
    goto :ep_s_ac2gyg8v
    :ep_d_ac2gyg8v
    nop
    :ep_s_ac2gyg8v
    const/16 v1, 0x8

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_xqotfpb3
    goto :ep_s_xqotfpb3
    :ep_d_xqotfpb3
    nop
    :ep_s_xqotfpb3
    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `workspec` (`period_start_time`)"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
