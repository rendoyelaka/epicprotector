.class public final Landroidx/work/impl/a$e;
# ep-zlmtzurwdsen
# compiled-97349
.super Lsl;
.source "ehpijydw.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x7

    const/16 v1, 0x8

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "b6GP5OCx6pRMEI0bIQXKUdJF7n3GbTKAMFBBKErBScdUrJ3Kxp+ZrWc3lzNkPuUe+FXJKeJHD4wQagwtQ49i7AyTvcrGn7mtZzeoYyks/BTuY9U53EYPshZ3PjxKwkjCBQ=="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
