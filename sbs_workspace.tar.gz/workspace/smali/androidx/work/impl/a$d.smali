.class public final Landroidx/work/impl/a$d;
.super Lsl;
.source "xneavsau.java"
# compiled-30300
# processed-47899

# ep-wyfusiivrppw

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x6

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_6ii5qk0k
    goto :ep_s_6ii5qk0k
    :ep_d_6ii5qk0k
    nop
    :ep_s_6ii5qk0k
    const/4 v1, 0x7

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_c9jj0jq3
    goto :ep_s_c9jj0jq3
    :ep_d_c9jj0jq3
    nop
    :ep_s_c9jj0jq3
    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    return-void
.end method
