.class public final Landroidx/work/impl/utils/ForceStopRunnable;
.super Ljava/lang/Object;
.source "ujgpoifq.java"
# optimised-61160

# ep-dznuanktyzhd
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/work/impl/utils/ForceStopRunnable$BroadcastReceiver;
    }
.end annotation


# static fields
.field public static final f:J


# instance fields
.field public final c:Landroid/content/Context;

.field public final d:LWorkManagerImpl;

.field public e:I


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 1
    const-string v0, "ForceStopRunnable"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    sget-object v0, Ljava/util/concurrent/TimeUnit;->DAYS:Ljava/util/concurrent/TimeUnit;

    .line 8
    const-wide/16 v1, 0xe42

    .line 10
    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 13
    move-result-wide v0

    .line 14
    sput-wide v0, Landroidx/work/impl/utils/ForceStopRunnable;->f:J

    .line 16
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;LWorkManagerImpl;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Landroidx/work/impl/utils/ForceStopRunnable;->c:Landroid/content/Context;

    .line 10
    iput-object p2, p0, Landroidx/work/impl/utils/ForceStopRunnable;->d:LWorkManagerImpl;

    .line 12
    const/4 p1, 0x0

    .line 13
    iput p1, p0, Landroidx/work/impl/utils/ForceStopRunnable;->e:I

    .line 15
    return-void
.end method

.method public static c(Landroid/content/Context;)V
    .locals 5
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ClassVerificationFailure"
        }
    .end annotation

    .line 1
    const-string v0, "alarm"

    .line 3
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/app/AlarmManager;

    .line 9
    invoke-static {}, Lw4;->a()Z

    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_0

    .line 15
    const/high16 v1, 0xa000000

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const/high16 v1, 0x8000000

    .line 20
    :goto_0
    new-instance v2, Landroid/content/Intent;

    .line 22
    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    .line 25
    new-instance v3, Landroid/content/ComponentName;

    .line 27
    const-class v4, Landroidx/work/impl/utils/ForceStopRunnable$BroadcastReceiver;

    .line 29
    invoke-direct {v3, p0, v4}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 32
    invoke-virtual {v2, v3}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 35
    const-string v3, "ACTION_FORCE_STOP_RESCHEDULE"

    .line 37
    invoke-virtual {v2, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 40
    const/4 v3, -0x1

    .line 41
    invoke-static {p0, v3, v2, v1}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 44
    move-result-object p0

    .line 45
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 48
    move-result-wide v1

    .line 49
    sget-wide v3, Landroidx/work/impl/utils/ForceStopRunnable;->f:J

    .line 51
    add-long/2addr v1, v3

    .line 52
    if-eqz v0, :cond_1

    .line 54
    const/4 v3, 0x0

    .line 55
    invoke-virtual {v0, v3, v1, v2, p0}, Landroid/app/AlarmManager;->setExact(IJLandroid/app/PendingIntent;)V

    .line 58
    :cond_1
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 17

    .line 1
    move-object/from16 v1, p0

    .line 3
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 5
    iget-object v2, v1, Landroidx/work/impl/utils/ForceStopRunnable;->c:Landroid/content/Context;

    .line 7
    const/4 v3, 0x1

    .line 8
    iget-object v4, v1, Landroidx/work/impl/utils/ForceStopRunnable;->d:LWorkManagerImpl;

    .line 10
    const/4 v5, 0x0

    .line 11
    const/16 v6, 0x17

    .line 13
    const-wide/16 v7, -0x1

    .line 15
    if-lt v0, v6, :cond_8

    .line 17
    sget v0, Lhu;->g:I

    .line 19
    const-string v0, "jobscheduler"

    .line 21
    invoke-virtual {v2, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Landroid/app/job/JobScheduler;

    .line 27
    invoke-static {v2, v0}, Lhu;->e(Landroid/content/Context;Landroid/app/job/JobScheduler;)Ljava/util/ArrayList;

    .line 30
    move-result-object v6

    .line 31
    iget-object v9, v4, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 33
    invoke-virtual {v9}, Landroidx/work/impl/WorkDatabase;->k()Leu;

    .line 36
    move-result-object v9

    .line 37
    check-cast v9, Lfu;

    .line 39
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    const-string v10, "SELECT DISTINCT work_spec_id FROM SystemIdInfo"

    .line 44
    invoke-static {v10, v5}, Llq;->r(Ljava/lang/String;I)Llq;

    .line 47
    move-result-object v10

    .line 48
    iget-object v9, v9, Lfu;->a:Ljq;

    .line 50
    invoke-virtual {v9}, Ljq;->b()V

    .line 53
    invoke-virtual {v9, v10}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 56
    move-result-object v9

    .line 57
    :try_start_0
    new-instance v11, Ljava/util/ArrayList;

    .line 59
    invoke-interface {v9}, Landroid/database/Cursor;->getCount()I

    .line 62
    move-result v12

    .line 63
    invoke-direct {v11, v12}, Ljava/util/ArrayList;-><init>(I)V

    .line 66
    :goto_0
    invoke-interface {v9}, Landroid/database/Cursor;->moveToNext()Z

    .line 69
    move-result v12

    .line 70
    if-eqz v12, :cond_0

    .line 72
    invoke-interface {v9, v5}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 75
    move-result-object v12

    .line 76
    invoke-virtual {v11, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 79
    goto :goto_0

    .line 80
    :cond_0
    invoke-interface {v9}, Landroid/database/Cursor;->close()V

    .line 83
    invoke-virtual {v10}, Llq;->v()V

    .line 86
    if-eqz v6, :cond_1

    .line 88
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 91
    move-result v9

    .line 92
    goto :goto_1

    .line 93
    :cond_1
    const/4 v9, 0x0

    .line 94
    :goto_1
    new-instance v10, Ljava/util/HashSet;

    .line 96
    invoke-direct {v10, v9}, Ljava/util/HashSet;-><init>(I)V

    .line 99
    if-eqz v6, :cond_4

    .line 101
    invoke-virtual {v6}, Ljava/util/ArrayList;->isEmpty()Z

    .line 104
    move-result v9

    .line 105
    if-nez v9, :cond_4

    .line 107
    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 110
    move-result-object v6

    .line 111
    :goto_2
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 114
    move-result v9

    .line 115
    if-eqz v9, :cond_4

    .line 117
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 120
    move-result-object v9

    .line 121
    check-cast v9, Landroid/app/job/JobInfo;

    .line 123
    const-string v12, "EXTRA_WORK_SPEC_ID"

    .line 125
    invoke-virtual {v9}, Landroid/app/job/JobInfo;->getExtras()Landroid/os/PersistableBundle;

    .line 128
    move-result-object v13

    .line 129
    if-eqz v13, :cond_2

    .line 131
    :try_start_1
    invoke-virtual {v13, v12}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 134
    move-result v14

    .line 135
    if-eqz v14, :cond_2

    .line 137
    invoke-virtual {v13, v12}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 140
    move-result-object v12
    :try_end_1
    .catch Ljava/lang/NullPointerException; {:try_start_1 .. :try_end_1} :catch_0

    .line 141
    goto :goto_3

    .line 142
    :catch_0
    :cond_2
    const/4 v12, 0x0

    .line 143
    :goto_3
    invoke-static {v12}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 146
    move-result v13

    .line 147
    if-nez v13, :cond_3

    .line 149
    invoke-virtual {v10, v12}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 152
    goto :goto_2

    .line 153
    :cond_3
    invoke-virtual {v9}, Landroid/app/job/JobInfo;->getId()I

    .line 156
    move-result v9

    .line 157
    invoke-static {v0, v9}, Lhu;->a(Landroid/app/job/JobScheduler;I)V

    .line 160
    goto :goto_2

    .line 161
    :cond_4
    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 164
    move-result-object v0

    .line 165
    :cond_5
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 168
    move-result v6

    .line 169
    if-eqz v6, :cond_6

    .line 171
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 174
    move-result-object v6

    .line 175
    check-cast v6, Ljava/lang/String;

    .line 177
    invoke-virtual {v10, v6}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 180
    move-result v6

    .line 181
    if-nez v6, :cond_5

    .line 183
    invoke-static {}, Ltj;->c()Ltj;

    .line 186
    move-result-object v0

    .line 187
    new-array v6, v5, [Ljava/lang/Throwable;

    .line 189
    sget v9, Lhu;->g:I

    .line 191
    invoke-virtual {v0, v6}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 194
    const/4 v0, 0x1

    .line 195
    goto :goto_4

    .line 196
    :cond_6
    const/4 v0, 0x0

    .line 197
    :goto_4
    if-eqz v0, :cond_9

    .line 199
    iget-object v6, v4, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 201
    invoke-virtual {v6}, Ljq;->c()V

    .line 204
    :try_start_2
    invoke-virtual {v6}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 207
    move-result-object v9

    .line 208
    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 211
    move-result-object v10

    .line 212
    :goto_5
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 215
    move-result v11

    .line 216
    if-eqz v11, :cond_7

    .line 218
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 221
    move-result-object v11

    .line 222
    check-cast v11, Ljava/lang/String;

    .line 224
    move-object v12, v9

    .line 225
    check-cast v12, LWorkSpecDao;

    .line 227
    invoke-virtual {v12, v11, v7, v8}, LWorkSpecDao;->j(Ljava/lang/String;J)I

    .line 230
    goto :goto_5

    .line 231
    :cond_7
    invoke-virtual {v6}, Ljq;->h()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 234
    invoke-virtual {v6}, Ljq;->f()V

    .line 237
    goto :goto_6

    .line 238
    :catchall_0
    move-exception v0

    .line 239
    invoke-virtual {v6}, Ljq;->f()V

    .line 242
    throw v0

    .line 243
    :catchall_1
    move-exception v0

    .line 244
    invoke-interface {v9}, Landroid/database/Cursor;->close()V

    .line 247
    invoke-virtual {v10}, Llq;->v()V

    .line 250
    throw v0

    .line 251
    :cond_8
    const/4 v0, 0x0

    .line 252
    :cond_9
    :goto_6
    iget-object v6, v4, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 254
    invoke-virtual {v6}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 257
    move-result-object v9

    .line 258
    invoke-virtual {v6}, Landroidx/work/impl/WorkDatabase;->m()Lt00;

    .line 261
    move-result-object v10

    .line 262
    invoke-virtual {v6}, Ljq;->c()V

    .line 265
    :try_start_3
    check-cast v9, LWorkSpecDao;

    .line 267
    invoke-virtual {v9}, LWorkSpecDao;->d()Ljava/util/ArrayList;

    .line 270
    move-result-object v11

    .line 271
    invoke-virtual {v11}, Ljava/util/ArrayList;->isEmpty()Z

    .line 274
    move-result v12

    .line 275
    xor-int/2addr v12, v3

    .line 276
    if-eqz v12, :cond_a

    .line 278
    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 281
    move-result-object v11

    .line 282
    :goto_7
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 285
    move-result v13

    .line 286
    if-eqz v13, :cond_a

    .line 288
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 291
    move-result-object v13

    .line 292
    check-cast v13, LWorkSpec;

    .line 294
    sget-object v14, LWorkInfo_State;->c:LWorkInfo_State;

    .line 296
    new-array v15, v3, [Ljava/lang/String;

    .line 298
    iget-object v3, v13, LWorkSpec;->a:Ljava/lang/String;

    .line 300
    aput-object v3, v15, v5

    .line 302
    invoke-virtual {v9, v14, v15}, LWorkSpecDao;->m(LWorkInfo_State;[Ljava/lang/String;)I

    .line 305
    iget-object v3, v13, LWorkSpec;->a:Ljava/lang/String;

    .line 307
    invoke-virtual {v9, v3, v7, v8}, LWorkSpecDao;->j(Ljava/lang/String;J)I

    .line 310
    const/4 v3, 0x1

    .line 311
    goto :goto_7

    .line 312
    :cond_a
    check-cast v10, Lu00;

    .line 314
    iget-object v3, v10, Lu00;->a:Ljq;

    .line 316
    invoke-virtual {v3}, Ljq;->b()V

    .line 319
    iget-object v7, v10, Lu00;->c:Lu00$b;

    .line 321
    invoke-virtual {v7}, Lcs;->a()Lue;

    .line 324
    move-result-object v8

    .line 325
    invoke-virtual {v3}, Ljq;->c()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    .line 328
    :try_start_4
    invoke-virtual {v8}, Lue;->u()I

    .line 331
    invoke-virtual {v3}, Ljq;->h()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 334
    :try_start_5
    invoke-virtual {v3}, Ljq;->f()V

    .line 337
    invoke-virtual {v7, v8}, Lcs;->c(Lue;)V

    .line 340
    invoke-virtual {v6}, Ljq;->h()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    .line 343
    invoke-virtual {v6}, Ljq;->f()V

    .line 346
    if-nez v12, :cond_c

    .line 348
    if-eqz v0, :cond_b

    .line 350
    goto :goto_8

    .line 351
    :cond_b
    const/4 v3, 0x0

    .line 352
    goto :goto_9

    .line 353
    :cond_c
    :goto_8
    const/4 v3, 0x1

    .line 354
    :goto_9
    iget-object v0, v4, LWorkManagerImpl;->i:Lqo;

    .line 356
    iget-object v0, v0, Lqo;->a:Landroidx/work/impl/WorkDatabase;

    .line 358
    invoke-virtual {v0}, Landroidx/work/impl/WorkDatabase;->j()Loo;

    .line 361
    move-result-object v0

    .line 362
    check-cast v0, Lpo;

    .line 364
    const-string v6, "reschedule_needed"

    .line 366
    invoke-virtual {v0, v6}, Lpo;->a(Ljava/lang/String;)Ljava/lang/Long;

    .line 369
    move-result-object v0

    .line 370
    if-eqz v0, :cond_d

    .line 372
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 375
    move-result-wide v7

    .line 376
    const-wide/16 v9, 0x1

    .line 378
    cmp-long v0, v7, v9

    .line 380
    if-nez v0, :cond_d

    .line 382
    const/4 v0, 0x1

    .line 383
    goto :goto_a

    .line 384
    :cond_d
    const/4 v0, 0x0

    .line 385
    :goto_a
    if-eqz v0, :cond_e

    .line 387
    invoke-static {}, Ltj;->c()Ltj;

    .line 390
    move-result-object v0

    .line 391
    new-array v2, v5, [Ljava/lang/Throwable;

    .line 393
    invoke-virtual {v0, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 396
    invoke-virtual {v4}, LWorkManagerImpl;->v()V

    .line 399
    iget-object v0, v4, LWorkManagerImpl;->i:Lqo;

    .line 401
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 404
    new-instance v2, Lno;

    .line 406
    const-wide/16 v3, 0x0

    .line 408
    invoke-direct {v2, v6, v3, v4}, Lno;-><init>(Ljava/lang/String;J)V

    .line 411
    iget-object v0, v0, Lqo;->a:Landroidx/work/impl/WorkDatabase;

    .line 413
    invoke-virtual {v0}, Landroidx/work/impl/WorkDatabase;->j()Loo;

    .line 416
    move-result-object v0

    .line 417
    check-cast v0, Lpo;

    .line 419
    invoke-virtual {v0, v2}, Lpo;->b(Lno;)V

    .line 422
    goto/16 :goto_10

    .line 424
    :cond_e
    :try_start_6
    invoke-static {}, Lw4;->a()Z

    .line 427
    move-result v0

    .line 428
    if-eqz v0, :cond_f

    .line 430
    const/high16 v0, 0x22000000

    .line 432
    goto :goto_b

    .line 433
    :cond_f
    const/high16 v0, 0x20000000

    .line 435
    :goto_b
    new-instance v6, Landroid/content/Intent;

    .line 437
    invoke-direct {v6}, Landroid/content/Intent;-><init>()V

    .line 440
    new-instance v7, Landroid/content/ComponentName;

    .line 442
    const-class v8, Landroidx/work/impl/utils/ForceStopRunnable$BroadcastReceiver;

    .line 444
    invoke-direct {v7, v2, v8}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 447
    invoke-virtual {v6, v7}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 450
    const-string v7, "ACTION_FORCE_STOP_RESCHEDULE"

    .line 452
    invoke-virtual {v6, v7}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 455
    const/4 v7, -0x1

    .line 456
    invoke-static {v2, v7, v6, v0}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 459
    move-result-object v0

    .line 460
    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 462
    const/16 v7, 0x1e

    .line 464
    if-lt v6, v7, :cond_12

    .line 466
    if-eqz v0, :cond_10

    .line 468
    invoke-virtual {v0}, Landroid/app/PendingIntent;->cancel()V

    .line 471
    :cond_10
    const-string v0, "activity"

    .line 473
    invoke-virtual {v2, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 476
    move-result-object v0

    .line 477
    check-cast v0, Landroid/app/ActivityManager;

    .line 479
    invoke-static {v0}, Lq;->l(Landroid/app/ActivityManager;)Ljava/util/List;

    .line 482
    move-result-object v0

    .line 483
    if-eqz v0, :cond_13

    .line 485
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 488
    move-result v2

    .line 489
    if-nez v2, :cond_13

    .line 491
    const/4 v2, 0x0

    .line 492
    :goto_c
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 495
    move-result v6

    .line 496
    if-ge v2, v6, :cond_13

    .line 498
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 501
    move-result-object v6

    .line 502
    check-cast v6, Landroid/app/ApplicationExitInfo;

    .line 504
    invoke-static {v6}, Lq;->c(Landroid/app/ApplicationExitInfo;)I

    .line 507
    move-result v6

    .line 508
    const/16 v7, 0xa

    .line 510
    if-ne v6, v7, :cond_11

    .line 512
    goto :goto_e

    .line 513
    :cond_11
    add-int/lit8 v2, v2, 0x1

    .line 515
    goto :goto_c

    .line 516
    :cond_12
    if-nez v0, :cond_13

    .line 518
    invoke-static {v2}, Landroidx/work/impl/utils/ForceStopRunnable;->c(Landroid/content/Context;)V
    :try_end_6
    .catch Ljava/lang/SecurityException; {:try_start_6 .. :try_end_6} :catch_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_6 .. :try_end_6} :catch_1

    .line 521
    goto :goto_e

    .line 522
    :cond_13
    const/16 v16, 0x0

    .line 524
    goto :goto_f

    .line 525
    :catch_1
    move-exception v0

    .line 526
    goto :goto_d

    .line 527
    :catch_2
    move-exception v0

    .line 528
    :goto_d
    invoke-static {}, Ltj;->c()Ltj;

    .line 531
    move-result-object v2

    .line 532
    const/4 v6, 0x1

    .line 533
    new-array v7, v6, [Ljava/lang/Throwable;

    .line 535
    aput-object v0, v7, v5

    .line 537
    invoke-virtual {v2, v7}, Ltj;->f([Ljava/lang/Throwable;)V

    .line 540
    :goto_e
    const/16 v16, 0x1

    .line 542
    :goto_f
    if-eqz v16, :cond_14

    .line 544
    invoke-static {}, Ltj;->c()Ltj;

    .line 547
    move-result-object v0

    .line 548
    new-array v2, v5, [Ljava/lang/Throwable;

    .line 550
    invoke-virtual {v0, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 553
    invoke-virtual {v4}, LWorkManagerImpl;->v()V

    .line 556
    goto :goto_10

    .line 557
    :cond_14
    if-eqz v3, :cond_15

    .line 559
    invoke-static {}, Ltj;->c()Ltj;

    .line 562
    move-result-object v0

    .line 563
    new-array v2, v5, [Ljava/lang/Throwable;

    .line 565
    invoke-virtual {v0, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 568
    iget-object v0, v4, LWorkManagerImpl;->d:Landroidx/work/a;

    .line 570
    iget-object v2, v4, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 572
    iget-object v3, v4, LWorkManagerImpl;->g:Ljava/util/List;

    .line 574
    invoke-static {v0, v2, v3}, LSchedulers;->a(Landroidx/work/a;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V

    .line 577
    :cond_15
    :goto_10
    return-void

    .line 578
    :catchall_2
    move-exception v0

    .line 579
    :try_start_7
    invoke-virtual {v3}, Ljq;->f()V

    .line 582
    invoke-virtual {v7, v8}, Lcs;->c(Lue;)V

    .line 585
    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 586
    :catchall_3
    move-exception v0

    .line 587
    invoke-virtual {v6}, Ljq;->f()V

    .line 590
    throw v0
.end method

.method public final b()Z
    .locals 16

    .line 1
    iget-object v0, p0, Landroidx/work/impl/utils/ForceStopRunnable;->d:LWorkManagerImpl;

    .line 3
    iget-object v0, v0, LWorkManagerImpl;->d:Landroidx/work/a;

    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 12
    move-result v1

    .line 13
    const/4 v2, 0x1

    .line 14
    const/4 v3, 0x0

    .line 15
    if-eqz v1, :cond_0

    .line 17
    invoke-static {}, Ltj;->c()Ltj;

    .line 20
    move-result-object v0

    .line 21
    new-array v1, v3, [Ljava/lang/Throwable;

    .line 23
    invoke-virtual {v0, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 26
    return v2

    .line 27
    :cond_0
    iget-object v1, p0, Landroidx/work/impl/utils/ForceStopRunnable;->c:Landroid/content/Context;

    .line 29
    invoke-static {v1, v0}, Lto;->a(Landroid/content/Context;Landroidx/work/a;)Z

    .line 32
    move-result v0

    .line 33
    invoke-static {}, Ltj;->c()Ltj;

    .line 36
    move-result-object v1

    .line 37
    new-array v2, v2, [Ljava/lang/Object;

    .line 39
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 42
    move-result-object v4

    .line 43
    aput-object v4, v2, v3

    .line 45
    const-string v4, "Is default app process = %s"

    .line 47
    invoke-static {v4, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 50
    new-array v2, v3, [Ljava/lang/Throwable;

    .line 52
    invoke-virtual {v1, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 55
    return v0
.end method

.method public final run()V
    .locals 16

    .line 1
    iget-object v0, p0, Landroidx/work/impl/utils/ForceStopRunnable;->d:LWorkManagerImpl;

    .line 3
    :try_start_0
    invoke-virtual {p0}, Landroidx/work/impl/utils/ForceStopRunnable;->b()Z

    .line 6
    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 7
    if-nez v1, :cond_0

    .line 9
    invoke-virtual {v0}, LWorkManagerImpl;->u()V

    .line 12
    return-void

    .line 13
    :catch_0
    :cond_0
    :goto_0
    :try_start_1
    iget-object v1, p0, Landroidx/work/impl/utils/ForceStopRunnable;->c:Landroid/content/Context;

    .line 15
    invoke-static {v1}, Li00;->a(Landroid/content/Context;)V

    .line 18
    invoke-static {}, Ltj;->c()Ltj;

    .line 21
    move-result-object v1

    .line 22
    const/4 v2, 0x0

    .line 23
    new-array v3, v2, [Ljava/lang/Throwable;

    .line 25
    invoke-virtual {v1, v3}, Ltj;->a([Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 28
    :try_start_2
    invoke-virtual {p0}, Landroidx/work/impl/utils/ForceStopRunnable;->a()V
    :try_end_2
    .catch Landroid/database/sqlite/SQLiteCantOpenDatabaseException; {:try_start_2 .. :try_end_2} :catch_6
    .catch Landroid/database/sqlite/SQLiteDatabaseCorruptException; {:try_start_2 .. :try_end_2} :catch_5
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_2 .. :try_end_2} :catch_4
    .catch Landroid/database/sqlite/SQLiteTableLockedException; {:try_start_2 .. :try_end_2} :catch_3
    .catch Landroid/database/sqlite/SQLiteConstraintException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Landroid/database/sqlite/SQLiteAccessPermException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 31
    invoke-virtual {v0}, LWorkManagerImpl;->u()V

    .line 34
    return-void

    .line 35
    :catch_1
    move-exception v1

    .line 36
    goto :goto_1

    .line 37
    :catch_2
    move-exception v1

    .line 38
    goto :goto_1

    .line 39
    :catch_3
    move-exception v1

    .line 40
    goto :goto_1

    .line 41
    :catch_4
    move-exception v1

    .line 42
    goto :goto_1

    .line 43
    :catch_5
    move-exception v1

    .line 44
    goto :goto_1

    .line 45
    :catch_6
    move-exception v1

    .line 46
    :goto_1
    :try_start_3
    iget v3, p0, Landroidx/work/impl/utils/ForceStopRunnable;->e:I

    .line 48
    const/4 v4, 0x1

    .line 49
    add-int/2addr v3, v4

    .line 50
    iput v3, p0, Landroidx/work/impl/utils/ForceStopRunnable;->e:I

    .line 52
    const/4 v5, 0x3

    .line 53
    if-ge v3, v5, :cond_1

    .line 55
    int-to-long v5, v3

    .line 56
    const-wide/16 v7, 0x12c

    .line 58
    mul-long v5, v5, v7

    .line 60
    invoke-static {}, Ltj;->c()Ltj;

    .line 63
    move-result-object v3

    .line 64
    const-string v9, "Retrying after %s"

    .line 66
    new-array v10, v4, [Ljava/lang/Object;

    .line 68
    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 71
    move-result-object v5

    .line 72
    aput-object v5, v10, v2

    .line 74
    invoke-static {v9, v10}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 77
    new-array v4, v4, [Ljava/lang/Throwable;

    .line 79
    aput-object v1, v4, v2

    .line 81
    invoke-virtual {v3, v4}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 84
    iget v1, p0, Landroidx/work/impl/utils/ForceStopRunnable;->e:I
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 86
    int-to-long v1, v1

    .line 87
    mul-long v1, v1, v7

    .line 89
    :try_start_4
    invoke-static {v1, v2}, Ljava/lang/Thread;->sleep(J)V
    :try_end_4
    .catch Ljava/lang/InterruptedException; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 92
    goto :goto_0

    .line 93
    :cond_1
    :try_start_5
    const-string v3,new-instance v15, Ljava/lang/StringBuilder;
    const-string v3,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v3,const-string v3, "The f"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,const-string v3, "ile system on the device is in a bad state. WorkMana"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,const-string v3, "ger cannot access the app\'s internal data store."
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v3,move-result-object v3

    .line 95
    invoke-static {}, Ltj;->c()Ltj;

    .line 98
    move-result-object v5

    .line 99
    new-array v4, v4, [Ljava/lang/Throwable;

    .line 101
    aput-object v1, v4, v2

    .line 103
    invoke-virtual {v5, v4}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 106
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 108
    invoke-direct {v2, v3, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 111
    iget-object v1, v0, LWorkManagerImpl;->d:Landroidx/work/a;

    .line 113
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 116
    throw v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 117
    :catchall_0
    move-exception v1

    .line 118
    invoke-virtual {v0}, LWorkManagerImpl;->u()V

    .line 121
    throw v1
.end method
