.class public Landroidx/work/impl/diagnostics/DiagnosticsReceiver;
.super Landroid/content/BroadcastReceiver;
# compiled-14509
# generated-99552
# verified-42028
# ep-qtqjyntelioo
.source "TimeoutHelper74.java"


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "DiagnosticsRcvr"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    .line 1
    if-nez p2, :cond_0

    .line 3
    return-void

    .line 4
    :cond_0
    invoke-static {}, Ltj;->c()Ltj;

    .line 7
    move-result-object p2

    .line 8
    const/4 v0, 0x0

    .line 9
    new-array v1, v0, [Ljava/lang/Throwable;

    .line 11
    invoke-virtual {p2, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 14
    :try_start_0
    invoke-static {p1}, LWorkManagerImpl;->s(Landroid/content/Context;)LWorkManagerImpl;

    .line 17
    move-result-object p1

    .line 18
    const-class p2, Landroidx/work/impl/workers/DiagnosticsWorker;

    .line 20
    new-instance v1, Lnn$a;

    .line 22
    invoke-direct {v1, p2}, Lnn$a;-><init>(Ljava/lang/Class;)V

    .line 25
    invoke-virtual {v1}, Lx00$a;->a()Lx00;

    .line 28
    move-result-object p2

    .line 29
    check-cast p2, Lnn;

    .line 31
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 34
    invoke-static {p2}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 37
    move-result-object p2

    .line 38
    invoke-virtual {p1, p2}, LWorkManagerImpl;->p(Ljava/util/List;)Lon;
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    .line 41
    goto :goto_0

    .line 42
    :catch_0
    move-exception p1

    .line 43
    invoke-static {}, Ltj;->c()Ltj;

    .line 46
    move-result-object p2

    .line 47
    const/4 v1, 0x1

    .line 48
    new-array v1, v1, [Ljava/lang/Throwable;

    .line 50
    aput-object p1, v1, v0

    .line 52
    invoke-virtual {p2, v1}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 55
    :goto_0
    return-void
.end method
