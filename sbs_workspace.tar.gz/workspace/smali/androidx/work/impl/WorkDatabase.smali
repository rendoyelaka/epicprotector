.class public abstract Landroidx/work/impl/WorkDatabase;
.super Ljq;
# ep-dqwxkkdcrxsp
.source "bvlymjsr.java"

# validated-49670
# generated-99106
# processed-92865

# static fields
.field public static final j:J

.field public static final synthetic k:I


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    sget-object v0, Ljava/util/concurrent/TimeUnit;->DAYS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v1, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    const/4 v2, 0x1
    if-ne v2, v2, :ep_d_yn3wv1dn
    goto :ep_s_yn3wv1dn
    :ep_d_yn3wv1dn
    nop
    :ep_s_yn3wv1dn
    move-result-wide v0

    const/4 v2, 0x1
    if-ne v2, v2, :ep_d_16hrfopf
    goto :ep_s_16hrfopf
    :ep_d_16hrfopf
    nop
    :ep_s_16hrfopf
    sput-wide v0, Landroidx/work/impl/WorkDatabase;->j:J

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljq;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract i()Laa;
.end method

.method public abstract j()Loo;
.end method

.method public abstract k()Leu;
.end method

.method public abstract l()Lr00;
.end method

.method public abstract m()Lt00;
.end method

.method public abstract n()Lz00;
.end method

.method public abstract o()Lc10;
.end method
