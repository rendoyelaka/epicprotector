.class public abstract Landroidx/work/impl/WorkDatabase;
.super Ljq;
.source "vaslfotg.java"

# processed-82402
# generated-61808
# optimised-36212
# ep-dmhwizgytkou

# static fields
.field public static final j:J

.field public static final synthetic k:I


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    sget-object v0, Ljava/util/concurrent/TimeUnit;->DAYS:Ljava/util/concurrent/TimeUnit;

    const/4 v2, 0x1
    if-ne v2, v2, :ep_d_fybwycis
    goto :ep_s_fybwycis
    :ep_d_fybwycis
    nop
    :ep_s_fybwycis
    const-wide/16 v1, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    const/4 v2, 0x1
    if-ne v2, v2, :ep_d_j21ev6ro
    goto :ep_s_j21ev6ro
    :ep_d_j21ev6ro
    nop
    :ep_s_j21ev6ro
    move-result-wide v0

    sput-wide v0, Landroidx/work/impl/WorkDatabase;->j:J

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljq;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract i()Laa;
.end method

.method public abstract j()Loo;
.end method

.method public abstract k()Leu;
.end method

.method public abstract l()Lr00;
.end method

.method public abstract m()Lt00;
.end method

.method public abstract n()Lz00;
.end method

.method public abstract o()Lc10;
.end method
