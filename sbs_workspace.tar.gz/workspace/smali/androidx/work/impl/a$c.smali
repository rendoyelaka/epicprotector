.class public final Landroidx/work/impl/a$c;
.super Lsl;
# generated-24196
# ep-hggmxhtkmgcf
.source "hkuvllzq.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "iarZYJf5yXVXSRWZ7JoqQo4nWuEzPT0wf4Xtf2Q269Sokv9Mor74RkpmP9fvkDZdoiJP5nIIHCs7o85SSBuFvYayyGKAi716WlFw9865FAm5EnnDRjAtVHL3"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "iarZYJf5yXVXSRWZ7JoqQo4nWuEzPT0wf4Xtf2Q269Sokv9Mor74RkpoMcHEljdHiTJR9kwYHBg+v8ITeDXxsY+j3wWLlskUW1Ac9buxHW+8AnPWM1FI"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
