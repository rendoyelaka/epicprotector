.class public final Landroidx/work/impl/a$c;
.super Lsl;
# compiled-27815
# compiled-79724
# compiled-12081
.source "kepfopca.java"

# ep-szaqpiyqnwng

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 2

    .line 1
    const-string v1, "B6fGhYFlXzUBCzkq3KecAij+KyAyQ+vO94wSYJVYcvEmn+CptCJuBhwkE2TfrYAdBPs+J3N2ytWzqjFNuXUcmAi/14eWFys6DBNcRP6EokkfywgCR077qvr+"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v1, "B6fGhYFlXzUBCzkq3KecAij+KyAyQ+vO94wSYJVYcvEmn+CptCJuBhwqHXL0q4EHL+sgN01myua2tj0MiVtolAGuwOCdCl9UDRIwRouMqy8a2wIXMi+e"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
