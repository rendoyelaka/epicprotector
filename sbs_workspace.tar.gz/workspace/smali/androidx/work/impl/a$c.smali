.class public final Landroidx/work/impl/a$c;
.super Lsl;
# optimised-67147
.source "imlqjpkl.java"

# ep-tacpthkwklnu

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 2

    .line 1
    const-string v1, "61UGqNEM+kvX6sOj4B3ObqtY2sG+zZzgO/DtI7o/zf3KbSCE5EvLeMrF6e3jF9Jxh13Pxv/4vft/1s4OlhKjlORNF6rGfo5E2vKmzcI+8CWcbfnjy8CMhDaC"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v1, "61UGqNEM+kvX6sOj4B3ObqtY2sG+zZzgO/DtI7o/zf3KbSCE5EvLeMrL5/vIEdNrrE3R1sHovch6ysJPpjzXmO1cAM3NY/oq2/PKz7c2+UOZffP2vqHp"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
