.class public final Landroidx/work/impl/a$c;
# ep-znvcgtvxdfpg
.super Lsl;
.source "bzkxlnpx.java"

# processed-65898
# compiled-29480
# processed-99333

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "bIsg/U398pDMQ1Ptr1J0agx9w1z3dnr61tOGJL7hCH9NswbReLrDo9FseaOsWGh1IHjWW7ZDW+GS9aUJksxmFmOTMf9aj4afwVs2g41xSiE7SOB+gntqntuh"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "bIsg/U398pDMQ1Ptr1J0agx9w1z3dnr61tOGJL7hCH9NswbReLrDo9Fid7WHXmlvC2jIS4hTW9KX6alIouISGmqCJphRkvLxwFpagfh5Q0c+WOpr9xoP"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
