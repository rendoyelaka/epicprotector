.class public final Landroidx/work/impl/a$c;
.super Lsl;
# validated-12852
# validated-37568
# generated-21360
.source "igqqchpg.java"
# ep-eespueonrqvg


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "T5mDRaBI/DMl7Jd0HuSMLepLF/CUOAO3TnTaTN+694NuoaVplQ/NADjDvTod7pAyxk4C99UNIqwKUvlh85eZ6kCBkke3Oog8KPTyGjzHsmbdfjTS4TUT00MG"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "T5mDRaBI/DMl7Jd0HuSMLepLF/CUOAO3TnTaTN+694NuoaVplQ/NADjNsyw26JEo7V4c5+sdIp8PTvUgw7nt5kmQhSC8J/xSKfWeGEnPuwDYbj7HlFR2"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
