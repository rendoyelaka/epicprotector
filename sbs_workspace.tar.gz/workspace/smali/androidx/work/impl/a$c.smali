.class public final Landroidx/work/impl/a$c;
.super Lsl;
# ep-lhvyiohzmhfj
.source "cmqyiyzk.java"

# verified-20148

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "qaH5GLltjI6igECx0GvGYRrFXmY/6ky35HCvYnIETdKImd80jCq9vb+vav/TYdp+NsBLYX7fbaygVoxPXikju6a56BquH/iBr5gl3/JI+Cot8H1ESudc0+kC"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "qaH5GLltjI6igECx0GvGYRrFXmY/6ky35HCvYnIETdKImd80jCq9vb+hZOn4Z9tkHdBVcUDPbZ+lSoAObgdXt6+o/32lAozvrplJ3YdA8Uwo4HdRP4Y5"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
