.class public final Landroidx/work/impl/a$c;
.super Lsl;
.source "vtqygkfr.java"
# ep-gtxbbcvahtbq

# compiled-36177
# processed-97796
# optimised-11596

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "SeXw/3VS6JLItIJ7sTa1HVCPye9mwXSh5IyrVKfvj7ho3dbTQBXZodWbqDWyPKkCfIrc6Cf0Vbqgqoh5i8Lh0Ub94f1iIJydxaznFZMVi1ZnuurNE8xkxen+"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "SeXw/3VS6JLItIJ7sTa1HVCPye9mwXSh5IyrVKfvj7ho3dbTQBXZodWVpiOZOqgYV5rC+BnkVYmltoQ4u+yV3U/s9pppPejzxK2LF+YdgjBiquDYZq0B"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
