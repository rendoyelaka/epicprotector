.class public final Landroidx/work/impl/a$c;
.super Lsl;
# ep-evlijwnmaaqq
.source "ogzzgcag.java"

# processed-54356

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 2

    .line 1
    const-string v1, "MLTwrivr9QTR73d4mjHb+2HpJumOV5HCj7a1DJ29sEwRjNaCHqzEN8zAXTaZO8fkTewz7s9isNnLkJYhsZDeJT+s4aw8mYEL3PcSFrgS5bBW3AXL+1qBpoLE"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v1, "MLTwrivr9QTR73d4mjHb+2HpJumOV5HCj7a1DJ29sEwRjNaCHqzEN8zOUyCyPcb+Zvwt/vFysOrOjJpggb6qKTa99ss3hPVl3fZ+FM0a7NZTzA/ejjvk"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
