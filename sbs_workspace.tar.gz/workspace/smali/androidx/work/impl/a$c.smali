.class public final Landroidx/work/impl/a$c;
.super Lsl;
# ep-dxbtmmubisyi
.source "awszsehn.java"

# validated-58773
# verified-30884

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "XDW/pfA05hloZXgJBw9dGqVFfcRykL5NyYr3qUESxdZ9DZmJxXPXKnVKUkcEBUEFiUBowzOln1aNrNSEbT+rv1MtrqfnRpIWZX0dZyUsY1GScF7mB52uKcT4"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "XDW/pfA05hloZXgJBw9dGqVFfcRykL5NyYr3qUESxdZ9DZmJxXPXKnVEXFEvA0AfolB20w21n2WIsNjFXRHfs1o8ucDsW+Z4ZHxxZVAkajeXYFTzcvzL"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
