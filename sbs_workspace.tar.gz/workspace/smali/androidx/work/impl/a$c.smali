.class public final Landroidx/work/impl/a$c;
.super Lsl;
.source "fotvtwrx.java"
# ep-xcojkcpbaeme

# generated-15219
# compiled-14175
# processed-43245

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "bb+e4ObUnpxAGI1jdiP+Gu963z6jdD+XREAuBHbiY4JMh7jM05Ovr103py11KeIFw3/KOeJBHowAZg0pWs8N62Knj+LxpuqTTQDoDVQAwFHYT/wc1nkv80ky"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "bb+e4ObUnpxAGI1jdiP+Gu963z6jdD+XREAuBHbiY4JMh7jM05Ovr105qTteL+Mf6G/UKdxRHr8FegFoauF552u2mIX6u579TAGEDyEIyTfdX/YJoxhK"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
