.class public final Landroidx/work/impl/a$c;
.super Lsl;
.source "CreatorHelper93.java"
# ep-jlzlmgwmakia

# compiled-91288
# optimised-55081

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 16

    .line 1
    const-string v0,new-instance v15, Ljava/lang/StringBuilder;
    const-string v0,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v0,const-string v0, "ALTER TAB"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "LE workspec ADD COLUMN `trigger_content_updat"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "e_delay` INTEGER NOT NULL DEFAULT -1"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v0,move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0,new-instance v15, Ljava/lang/StringBuilder;
    const-string v0,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v0,const-string v0, "ALTER TABLE workspe"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "c ADD COLUMN `trigger_max_co"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "ntent_delay` INTEGER NOT NULL DEFAULT -1"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v0,move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
