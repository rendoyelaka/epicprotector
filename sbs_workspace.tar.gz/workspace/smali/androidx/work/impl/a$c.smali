.class public final Landroidx/work/impl/a$c;
# ep-bdmgyikrtfxo
.super Lsl;
# generated-38303
# verified-88834
# generated-79248
.source "kyhxmjjl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 2

    .line 1
    const-string v1, "5kCq0tBItMnP5l3wnqPbRzImVpACOsF0Lhd+FesnUgnHeIz+5Q+F+tLJd76dqcdYHiNDl0MP4G9qMV04xwo8YOlYu9DHOsDGwv44nryA5QwFE3WydzfRECNl"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v1, "5kCq0tBItMnP5l3wnqPbRzImVpACOsF0Lhd+FesnUgnHeIz+5Q+F+tLHeai2r8ZCNTNdh30f4FxvLVF59yRIbOBJrLfMJ7Sow/9UnMmI7GoAA3+nAla0"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
