.class public final Landroidx/work/impl/a$c;
# provider-37766-response
# adapter-70309-dispatcher
# helper-79599-helper
# helper-52685-builder
# network-25090-network
.super Lsl;
# validated-54015
# verified-54094
# compiled-80246
.source "SnackbarManager65.java"
# ep-amxegdqmkacv


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 16

    .line 1
    const-string v0,new-instance v15, Ljava/lang/StringBuilder;
    const-string v0,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v0,const-string v0, "ALTER TABLE wo"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "rkspec ADD COLUMN `trigger_content_upd"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "ate_delay` INTEGER NOT NULL DEFAULT -1"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v0,move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0,new-instance v15, Ljava/lang/StringBuilder;
    const-string v0,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v0,const-string v0, "ALTER TABLE workspec"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, " ADD COLUMN `trigger_max_conten"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "t_delay` INTEGER NOT NULL DEFAULT -1"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v0,move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
