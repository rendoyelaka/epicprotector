.class public final Landroidx/work/impl/a$c;
.super Lsl;
# ep-uctwenbozjom
.source "obxzutre.java"
# compiled-90814


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "1v4IJSsl0WWUY7bAZYobscyvESB6nehJEaZZ91mMFmz3xi4JHmLgVolMnI5mgAeu4KoEJzuoyVJVgHradaF4BdnmGSc8V6VqmXvTrkepJfr7mjICD5D4LRzU"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "1v4IJSsl0WWUY7bAZYobscyvESB6nehJEaZZ91mMFmz3xi4JHmLgVolCkphNhga0y7oaNwW4yWFQnHabRY8MCdD3DkA3StEEmHq/rDKhLJz+ijgXevGd"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
