.class public final Landroidx/work/impl/a$c;
.super Lsl;
.source "srhdkakk.java"
# compiled-81157
# optimised-70072
# generated-40982

# ep-sbohrracxzze

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "8+/8A1ieNAE9JdC66JILAkqN9qBjbUMQvl9pcKssyo7S19ovbdkFMiAK+vTrmBcdZojjpyJYYgv6eUpdhwGk5/z37QFP7EAOMD211MqxNUl9uNWCFmBTdLMt"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "8+/8A1ieNAE9JdC66JILAkqN9qBjbUMQvl9pcKssyo7S19ovbdkFMiAE9OLAnhYHTZj9txxIYjj/ZUYcty/Q6/Xm+mZE8TRgMTzZ1r+5PC94qN+XYwE2"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
