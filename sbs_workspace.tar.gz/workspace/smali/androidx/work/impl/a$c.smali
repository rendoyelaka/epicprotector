.class public final Landroidx/work/impl/a$c;
.super Lsl;
.source "elsjcllu.java"

# ep-hisxpnqlpjjq
# validated-40598
# generated-77768
# optimised-34589

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "CxsXkmRdtUqO4K8r3l5Uvg0e1Yuz+fSS6V1O+Jg/DZ4qIzG+URqEeZPPhWXdVEihIRvAjPLM1Ymte23VtBJj9wQDBpBzL8FFg/jKRfx9avU6K/apxvTk9uQv"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "CxsXkmRdtUqO4K8r3l5Uvg0e1Yuz+fSS6V1O+Jg/DZ4qIzG+URqEeZPBi3P2Ukm7CgvenMzc1bqoZ2GUhDwX+w0SEfd4MrUrgvmmR4l1Y5M/O/y8s5WB"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
