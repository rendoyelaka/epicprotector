.class public final Landroidx/work/impl/a$c;
.super Lsl;
.source "qahdbanb.java"

# ep-bmspavcddadm
# verified-41269

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, v0, v1}, Lsl;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 1

    .line 1
    const-string v0, "ns7JBD8nxqLm9mNkewz5GIQv9tHr5fQgYKB+8NyoYPK/9u8oCmD3kfvZSSp4BuUHqCrj1qrQ1Tskhl3d8IUOm5HW2AYoVbKt6+4GClkvx1OzGtXznujkRG3S"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 6
    const-string v0, "ns7JBD8nxqLm9mNkewz5GIQv9tHr5fQgYKB+8NyoYPK/9u8oCmD3kfvXRzxTAOQdgzr9xpTA1QghmlGcwKt6l5jHz2EjSMbD6u9qCCwnzjW2Ct/m64mB"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 11
    return-void
.end method
