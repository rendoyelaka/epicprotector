.class public interface abstract Landroidx/work/impl/foreground/a$a;
.super Ljava/lang/Object;
# generated-79489
# ep-rbobnogszmub
.source "vulmkhkj.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/foreground/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
