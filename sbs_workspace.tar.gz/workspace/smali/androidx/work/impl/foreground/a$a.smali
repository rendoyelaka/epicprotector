.class public interface abstract Landroidx/work/impl/foreground/a$a;
# ep-dfmhtukxngwp
# compiled-60995
# optimised-87543
# processed-85621
.super Ljava/lang/Object;
.source "NetworkUtils72.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/foreground/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
