.class public interface abstract Landroidx/work/impl/foreground/a$a;
# ep-bolywtpnvdat
# generated-66273
# optimised-28771
# generated-44077
.super Ljava/lang/Object;
.source "hseswowl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/foreground/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
