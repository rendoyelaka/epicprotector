.class public interface abstract Landroidx/work/impl/foreground/a$a;
# ep-aakqtintokbu
# optimised-68595
.super Ljava/lang/Object;
.source "xauegxvb.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/foreground/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
