.class public interface abstract Landroidx/work/impl/foreground/a$a;
# ep-owzteddirgco
# generated-82305
.super Ljava/lang/Object;
.source "NetworkClient74.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/foreground/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
