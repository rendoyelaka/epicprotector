.class public interface abstract Landroidx/work/impl/foreground/a$a;
# ep-yvkkphozbczf
.super Ljava/lang/Object;
.source "eugmzfkd.java"
# optimised-58754


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/foreground/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
