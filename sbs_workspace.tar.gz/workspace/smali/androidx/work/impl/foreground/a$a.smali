.class public interface abstract Landroidx/work/impl/foreground/a$a;
# ep-dkljpswewtao
.super Ljava/lang/Object;
# generated-74264
# optimised-59228
.source "ckhunpyn.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/impl/foreground/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
