.class public final Landroidx/work/impl/foreground/a;
.super Ljava/lang/Object;
.source "rhkdnveb.java"
# verified-15299
# ep-qdvjpowvcbkv

# interfaces
.implements Ld00;
.implements Lic;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/work/impl/foreground/a$a;
    }
.end annotation


# static fields
.field public static final synthetic l:I


# instance fields
.field public final c:LWorkManagerImpl;

.field public final d:Lnu;

.field public final e:Ljava/lang/Object;

.field public f:Ljava/lang/String;

.field public final g:Ljava/util/LinkedHashMap;

.field public final h:Ljava/util/HashMap;

.field public final i:Ljava/util/HashSet;

.field public final j:Le00;

.field public k:Landroidx/work/impl/foreground/a$a;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 1
    const-string v1, "FZLhtLYoTRMHLg96yryNAT78"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/lang/Object;

    .line 6
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 9
    iput-object v0, p0, Landroidx/work/impl/foreground/a;->e:Ljava/lang/Object;

    .line 11
    invoke-static {p1}, LWorkManagerImpl;->s(Landroid/content/Context;)LWorkManagerImpl;

    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, Landroidx/work/impl/foreground/a;->c:LWorkManagerImpl;

    .line 17
    iget-object v1, v0, LWorkManagerImpl;->f:Lnu;

    .line 19
    iput-object v1, p0, Landroidx/work/impl/foreground/a;->d:Lnu;

    .line 21
    const/4 v2, 0x0

    .line 22
    iput-object v2, p0, Landroidx/work/impl/foreground/a;->f:Ljava/lang/String;

    .line 24
    new-instance v2, Ljava/util/LinkedHashMap;

    .line 26
    invoke-direct {v2}, Ljava/util/LinkedHashMap;-><init>()V

    .line 29
    iput-object v2, p0, Landroidx/work/impl/foreground/a;->g:Ljava/util/LinkedHashMap;

    .line 31
    new-instance v2, Ljava/util/HashSet;

    .line 33
    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    .line 36
    iput-object v2, p0, Landroidx/work/impl/foreground/a;->i:Ljava/util/HashSet;

    .line 38
    new-instance v2, Ljava/util/HashMap;

    .line 40
    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 43
    iput-object v2, p0, Landroidx/work/impl/foreground/a;->h:Ljava/util/HashMap;

    .line 45
    new-instance v2, Le00;

    .line 47
    invoke-direct {v2, p1, v1, p0}, Le00;-><init>(Landroid/content/Context;Lnu;Ld00;)V

    .line 50
    iput-object v2, p0, Landroidx/work/impl/foreground/a;->j:Le00;

    .line 52
    iget-object p1, v0, LWorkManagerImpl;->h:Luo;

    .line 54
    invoke-virtual {p1, p0}, Luo;->b(Lic;)V

    .line 57
    return-void
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;Lnd;)Landroid/content/Intent;
    .locals 3

    .line 1
    new-instance v0, Landroid/content/Intent;

    .line 3
    const-class v1, Landroidx/work/impl/foreground/SystemForegroundService;

    .line 5
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 8
    const-string v2, "B6jGiZwLVDoMEzVM8g=="
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p0

    .line 10
    invoke-virtual {v0, p0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 13
    iget p0, p2, Lnd;->a:I

    .line 15
    const-string v2, "Da7Ln50KXz0FDj9L/4GhJwTHCg=="
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 17
    invoke-virtual {v0, v1, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 20
    const-string v2, "Da7Ln5UKWTEEFTNf5YyxOh7cGApRR/Dejp8Y"
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p0

    .line 22
    iget v1, p2, Lnd;->b:I

    .line 24
    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 27
    const-string v2, "Da7Ln50KXz0FDj9L/4GhJw=="
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p0

    .line 29
    iget-object p2, p2, Lnd;->c:Landroid/app/Notification;

    .line 31
    invoke-virtual {v0, p0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 34
    const-string v2, "Da7Ln4QKWT8QFzlJ9IGq"
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p0

    .line 36
    invoke-virtual {v0, p0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 39
    return-object v0
.end method

.method public static d(Landroid/content/Context;Ljava/lang/String;Lnd;)Landroid/content/Intent;
    .locals 4

    .line 1
    new-instance v0, Landroid/content/Intent;

    .line 3
    const-class v1, Landroidx/work/impl/foreground/SystemForegroundService;

    .line 5
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 8
    const-string v3, "B6jGiZwLVCcXBi5e9I6hOx7JHAxHTOs="
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p0

    .line 10
    invoke-virtual {v0, p0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 13
    const-string v3, "Da7Ln4QKWT8QFzlJ9IGq"
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p0

    .line 15
    invoke-virtual {v0, p0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 18
    iget v1, p2, Lnd;->a:I

    .line 20
    const-string v3, "Da7Ln50KXz0FDj9L/4GhJwTHCg=="
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 22
    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 25
    const-string v3, "Da7Ln5UKWTEEFTNf5YyxOh7cGApRR/Dejp8Y"
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 27
    iget v2, p2, Lnd;->b:I

    .line 29
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 32
    const-string v3, "Da7Ln50KXz0FDj9L/4GhJw=="
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 34
    iget-object p2, p2, Lnd;->c:Landroid/app/Notification;

    .line 36
    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 39
    invoke-virtual {v0, p0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 42
    return-object v0
.end method


# virtual methods
.method public final a(Ljava/lang/String;Z)V
    .locals 9

    .line 1
    iget-object p2, p0, Landroidx/work/impl/foreground/a;->e:Ljava/lang/Object;

    .line 3
    monitor-enter p2

    .line 4
    :try_start_0
    iget-object v0, p0, Landroidx/work/impl/foreground/a;->h:Ljava/util/HashMap;

    .line 6
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    move-result-object v0

    .line 10
    check-cast v0, LWorkSpec;

    .line 12
    const/4 v1, 0x0

    .line 13
    if-eqz v0, :cond_0

    .line 15
    iget-object v2, p0, Landroidx/work/impl/foreground/a;->i:Ljava/util/HashSet;

    .line 17
    invoke-virtual {v2, v0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 20
    move-result v0

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 v0, 0x0

    .line 23
    :goto_0
    if-eqz v0, :cond_1

    .line 25
    iget-object v0, p0, Landroidx/work/impl/foreground/a;->j:Le00;

    .line 27
    iget-object v2, p0, Landroidx/work/impl/foreground/a;->i:Ljava/util/HashSet;

    .line 29
    invoke-virtual {v0, v2}, Le00;->c(Ljava/util/Collection;)V

    .line 32
    goto :goto_1

    .line 33
    :catchall_0
    move-exception p1

    .line 34
    goto/16 :goto_3

    .line 36
    :cond_1
    :goto_1
    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 37
    iget-object p2, p0, Landroidx/work/impl/foreground/a;->g:Ljava/util/LinkedHashMap;

    .line 39
    invoke-interface {p2, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    move-result-object p2

    .line 43
    check-cast p2, Lnd;

    .line 45
    iget-object v0, p0, Landroidx/work/impl/foreground/a;->f:Ljava/lang/String;

    .line 47
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_3

    .line 53
    iget-object v0, p0, Landroidx/work/impl/foreground/a;->g:Ljava/util/LinkedHashMap;

    .line 55
    invoke-interface {v0}, Ljava/util/Map;->size()I

    .line 58
    move-result v0

    .line 59
    if-lez v0, :cond_3

    .line 61
    iget-object v0, p0, Landroidx/work/impl/foreground/a;->g:Ljava/util/LinkedHashMap;

    .line 63
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 66
    move-result-object v0

    .line 67
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 70
    move-result-object v0

    .line 71
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 74
    move-result-object v2

    .line 75
    check-cast v2, Ljava/util/Map$Entry;

    .line 77
    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 80
    move-result v3

    .line 81
    if-eqz v3, :cond_2

    .line 83
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 86
    move-result-object v2

    .line 87
    check-cast v2, Ljava/util/Map$Entry;

    .line 89
    goto :goto_2

    .line 90
    :cond_2
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 93
    move-result-object v0

    .line 94
    check-cast v0, Ljava/lang/String;

    .line 96
    iput-object v0, p0, Landroidx/work/impl/foreground/a;->f:Ljava/lang/String;

    .line 98
    iget-object v0, p0, Landroidx/work/impl/foreground/a;->k:Landroidx/work/impl/foreground/a$a;

    .line 100
    if-eqz v0, :cond_3

    .line 102
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 105
    move-result-object v0

    .line 106
    check-cast v0, Lnd;

    .line 108
    iget-object v2, p0, Landroidx/work/impl/foreground/a;->k:Landroidx/work/impl/foreground/a$a;

    .line 110
    iget v3, v0, Lnd;->a:I

    .line 112
    iget v4, v0, Lnd;->b:I

    .line 114
    iget-object v5, v0, Lnd;->c:Landroid/app/Notification;

    .line 116
    check-cast v2, Landroidx/work/impl/foreground/SystemForegroundService;

    .line 118
    iget-object v6, v2, Landroidx/work/impl/foreground/SystemForegroundService;->d:Landroid/os/Handler;

    .line 120
    new-instance v7, Lau;

    .line 122
    invoke-direct {v7, v2, v3, v5, v4}, Lau;-><init>(Landroidx/work/impl/foreground/SystemForegroundService;ILandroid/app/Notification;I)V

    .line 125
    invoke-virtual {v6, v7}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 128
    iget-object v2, p0, Landroidx/work/impl/foreground/a;->k:Landroidx/work/impl/foreground/a$a;

    .line 130
    iget v0, v0, Lnd;->a:I

    .line 132
    check-cast v2, Landroidx/work/impl/foreground/SystemForegroundService;

    .line 134
    iget-object v3, v2, Landroidx/work/impl/foreground/SystemForegroundService;->d:Landroid/os/Handler;

    .line 136
    new-instance v4, Lcu;

    .line 138
    invoke-direct {v4, v2, v0}, Lcu;-><init>(Landroidx/work/impl/foreground/SystemForegroundService;I)V

    .line 141
    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 144
    :cond_3
    iget-object v0, p0, Landroidx/work/impl/foreground/a;->k:Landroidx/work/impl/foreground/a$a;

    .line 146
    if-eqz p2, :cond_4

    .line 148
    if-eqz v0, :cond_4

    .line 150
    invoke-static {}, Ltj;->c()Ltj;

    .line 153
    move-result-object v2

    .line 154
    const-string v8, "FI7/r6UsZRNjCRN+wq6HCjr6Jyx8Iofjs/V9CbM5HKYpmfmToyBoPSd9XC/Y6MIHNPonJXthzv6+oDN4uWVZ62bO4ek="
    invoke-static {v8}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3

    .line 156
    const/4 v4, 0x3

    .line 157
    new-array v4, v4, [Ljava/lang/Object;

    .line 159
    iget v5, p2, Lnd;->a:I

    .line 161
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 164
    move-result-object v5

    .line 165
    aput-object v5, v4, v1

    .line 167
    const/4 v5, 0x1

    .line 168
    aput-object p1, v4, v5

    .line 170
    iget p1, p2, Lnd;->b:I

    .line 172
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 175
    move-result-object p1

    .line 176
    const/4 v5, 0x2

    .line 177
    aput-object p1, v4, v5

    .line 179
    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 182
    new-array p1, v1, [Ljava/lang/Throwable;

    .line 184
    invoke-virtual {v2, p1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 187
    iget p1, p2, Lnd;->a:I

    .line 189
    check-cast v0, Landroidx/work/impl/foreground/SystemForegroundService;

    .line 191
    iget-object p2, v0, Landroidx/work/impl/foreground/SystemForegroundService;->d:Landroid/os/Handler;

    .line 193
    new-instance v1, Lcu;

    .line 195
    invoke-direct {v1, v0, p1}, Lcu;-><init>(Landroidx/work/impl/foreground/SystemForegroundService;I)V

    .line 198
    invoke-virtual {p2, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 201
    :cond_4
    return-void

    .line 202
    :goto_3
    :try_start_1
    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 203
    throw p1
.end method

.method public final c(Ljava/util/ArrayList;)V
    .locals 7

    .line 1
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_0

    .line 7
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 10
    move-result-object p1

    .line 11
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 17
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 20
    move-result-object v0

    .line 21
    check-cast v0, Ljava/lang/String;

    .line 23
    invoke-static {}, Ltj;->c()Ltj;

    .line 26
    move-result-object v1

    .line 27
    const/4 v2, 0x1

    .line 28
    new-array v3, v2, [Ljava/lang/Object;

    .line 30
    const/4 v4, 0x0

    .line 31
    aput-object v0, v3, v4

    .line 33
    const-string v6, "BYT8s6c3ah0tMw8q3qaDDC+uKCxgIvjlpaQOXKV2HPQ1"
    invoke-static {v6}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v5

    .line 35
    invoke-static {v5, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 38
    new-array v3, v4, [Ljava/lang/Throwable;

    .line 40
    invoke-virtual {v1, v3}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 43
    iget-object v1, p0, Landroidx/work/impl/foreground/a;->c:LWorkManagerImpl;

    .line 45
    iget-object v3, v1, LWorkManagerImpl;->f:Lnu;

    .line 47
    new-instance v4, LStopWorkRunnable;

    .line 49
    invoke-direct {v4, v1, v0, v2}, LStopWorkRunnable;-><init>(LWorkManagerImpl;Ljava/lang/String;Z)V

    .line 52
    check-cast v3, Lp00;

    .line 54
    invoke-virtual {v3, v4}, Lp00;->a(Ljava/lang/Runnable;)V

    .line 57
    goto :goto_0

    .line 58
    :cond_0
    return-void
.end method

.method public final e(Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    return-void
.end method

.method public final f(Landroid/content/Intent;)V
    .locals 9

    .line 1
    const-string v8, "Da7Ln50KXz0FDj9L/4GhJwTHCg=="
    invoke-static {v8}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 7
    move-result v0

    .line 8
    const-string v8, "Da7Ln5UKWTEEFTNf5YyxOh7cGApRR/Dejp8Y"
    invoke-static {v8}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 10
    invoke-virtual {p1, v2, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 13
    move-result v2

    .line 14
    const-string v8, "Da7Ln4QKWT8QFzlJ9IGq"
    invoke-static {v8}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3

    .line 16
    invoke-virtual {p1, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 19
    move-result-object v3

    .line 20
    const-string v8, "Da7Ln50KXz0FDj9L/4GhJw=="
    invoke-static {v8}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4

    .line 22
    invoke-virtual {p1, v4}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 25
    move-result-object p1

    .line 26
    check-cast p1, Landroid/app/Notification;

    .line 28
    invoke-static {}, Ltj;->c()Ltj;

    .line 31
    move-result-object v4

    .line 32
    const/4 v5, 0x3

    .line 33
    new-array v5, v5, [Ljava/lang/Object;

    .line 35
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 38
    move-result-object v6

    .line 39
    aput-object v6, v5, v1

    .line 41
    const/4 v6, 0x1

    .line 42
    aput-object v3, v5, v6

    .line 44
    const/4 v6, 0x2

    .line 45
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 48
    move-result-object v7

    .line 49
    aput-object v7, v5, v6

    .line 51
    const-string v8, "CITmqbU8YhokZwtj36DOQTLqdGM3cYOqoKAvR5NlWbIPj6jg9jYnVC0oCGPNoY0IL+chLUZ73+/t73hf6Q=="
    invoke-static {v8}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v6

    .line 53
    invoke-static {v6, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 56
    new-array v5, v1, [Ljava/lang/Throwable;

    .line 58
    invoke-virtual {v4, v5}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 61
    if-eqz p1, :cond_2

    .line 63
    iget-object v4, p0, Landroidx/work/impl/foreground/a;->k:Landroidx/work/impl/foreground/a$a;

    .line 65
    if-eqz v4, :cond_2

    .line 67
    new-instance v4, Lnd;

    .line 69
    invoke-direct {v4, v0, v2, p1}, Lnd;-><init>(IILandroid/app/Notification;)V

    .line 72
    iget-object v5, p0, Landroidx/work/impl/foreground/a;->g:Ljava/util/LinkedHashMap;

    .line 74
    invoke-interface {v5, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 77
    iget-object v4, p0, Landroidx/work/impl/foreground/a;->f:Ljava/lang/String;

    .line 79
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 82
    move-result v4

    .line 83
    if-eqz v4, :cond_0

    .line 85
    iput-object v3, p0, Landroidx/work/impl/foreground/a;->f:Ljava/lang/String;

    .line 87
    iget-object v1, p0, Landroidx/work/impl/foreground/a;->k:Landroidx/work/impl/foreground/a$a;

    .line 89
    check-cast v1, Landroidx/work/impl/foreground/SystemForegroundService;

    .line 91
    iget-object v3, v1, Landroidx/work/impl/foreground/SystemForegroundService;->d:Landroid/os/Handler;

    .line 93
    new-instance v4, Lau;

    .line 95
    invoke-direct {v4, v1, v0, p1, v2}, Lau;-><init>(Landroidx/work/impl/foreground/SystemForegroundService;ILandroid/app/Notification;I)V

    .line 98
    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 101
    goto :goto_1

    .line 102
    :cond_0
    iget-object v3, p0, Landroidx/work/impl/foreground/a;->k:Landroidx/work/impl/foreground/a$a;

    .line 104
    check-cast v3, Landroidx/work/impl/foreground/SystemForegroundService;

    .line 106
    iget-object v4, v3, Landroidx/work/impl/foreground/SystemForegroundService;->d:Landroid/os/Handler;

    .line 108
    new-instance v6, Lbu;

    .line 110
    invoke-direct {v6, v3, v0, p1}, Lbu;-><init>(Landroidx/work/impl/foreground/SystemForegroundService;ILandroid/app/Notification;)V

    .line 113
    invoke-virtual {v4, v6}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 116
    if-eqz v2, :cond_2

    .line 118
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 120
    const/16 v0, 0x1d

    .line 122
    if-lt p1, v0, :cond_2

    .line 124
    invoke-virtual {v5}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 127
    move-result-object p1

    .line 128
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 131
    move-result-object p1

    .line 132
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 135
    move-result v0

    .line 136
    if-eqz v0, :cond_1

    .line 138
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 141
    move-result-object v0

    .line 142
    check-cast v0, Ljava/util/Map$Entry;

    .line 144
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 147
    move-result-object v0

    .line 148
    check-cast v0, Lnd;

    .line 150
    iget v0, v0, Lnd;->b:I

    .line 152
    or-int/2addr v1, v0

    .line 153
    goto :goto_0

    .line 154
    :cond_1
    iget-object p1, p0, Landroidx/work/impl/foreground/a;->f:Ljava/lang/String;

    .line 156
    invoke-virtual {v5, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 159
    move-result-object p1

    .line 160
    check-cast p1, Lnd;

    .line 162
    if-eqz p1, :cond_2

    .line 164
    iget-object v0, p0, Landroidx/work/impl/foreground/a;->k:Landroidx/work/impl/foreground/a$a;

    .line 166
    check-cast v0, Landroidx/work/impl/foreground/SystemForegroundService;

    .line 168
    iget-object v2, v0, Landroidx/work/impl/foreground/SystemForegroundService;->d:Landroid/os/Handler;

    .line 170
    new-instance v3, Lau;

    .line 172
    iget v4, p1, Lnd;->a:I

    .line 174
    iget-object p1, p1, Lnd;->c:Landroid/app/Notification;

    .line 176
    invoke-direct {v3, v0, v4, p1, v1}, Lau;-><init>(Landroidx/work/impl/foreground/SystemForegroundService;ILandroid/app/Notification;I)V

    .line 179
    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 182
    :cond_2
    :goto_1
    return-void
.end method
