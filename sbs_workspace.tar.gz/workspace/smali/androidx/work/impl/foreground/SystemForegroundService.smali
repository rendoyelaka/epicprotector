.class public Landroidx/work/impl/foreground/SystemForegroundService;
.super Landroidx/lifecycle/LifecycleService;
.source "sunietlm.java"

# ep-opsnvrigiymi
# verified-10759
# processed-66121
# processed-48676
# interfaces
.implements Landroidx/work/impl/foreground/a$a;


# instance fields
.field public d:Landroid/os/Handler;

.field public e:Z

.field public f:Landroidx/work/impl/foreground/a;

.field public g:Landroid/app/NotificationManager;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "SystemFgService"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/lifecycle/LifecycleService;-><init>()V

    return-void
.end method


# virtual methods
.method public final d()V
    .locals 2

    .line 1
    new-instance v0, Landroid/os/Handler;

    .line 3
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 6
    move-result-object v1

    .line 7
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 10
    iput-object v0, p0, Landroidx/work/impl/foreground/SystemForegroundService;->d:Landroid/os/Handler;

    .line 12
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 15
    move-result-object v0

    .line 16
    const-string v1, "notification"

    .line 18
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 21
    move-result-object v0

    .line 22
    check-cast v0, Landroid/app/NotificationManager;

    .line 24
    iput-object v0, p0, Landroidx/work/impl/foreground/SystemForegroundService;->g:Landroid/app/NotificationManager;

    .line 26
    new-instance v0, Landroidx/work/impl/foreground/a;

    .line 28
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 31
    move-result-object v1

    .line 32
    invoke-direct {v0, v1}, Landroidx/work/impl/foreground/a;-><init>(Landroid/content/Context;)V

    .line 35
    iput-object v0, p0, Landroidx/work/impl/foreground/SystemForegroundService;->f:Landroidx/work/impl/foreground/a;

    .line 37
    iget-object v1, v0, Landroidx/work/impl/foreground/a;->k:Landroidx/work/impl/foreground/a$a;

    .line 39
    if-eqz v1, :cond_0

    .line 41
    invoke-static {}, Ltj;->c()Ltj;

    .line 44
    move-result-object v0

    .line 45
    const/4 v1, 0x0

    .line 46
    new-array v1, v1, [Ljava/lang/Throwable;

    .line 48
    invoke-virtual {v0, v1}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 51
    goto :goto_0

    .line 52
    :cond_0
    iput-object p0, v0, Landroidx/work/impl/foreground/a;->k:Landroidx/work/impl/foreground/a$a;

    .line 54
    :goto_0
    return-void
.end method

.method public final onCreate()V
    .locals 0

    .line 1
    invoke-super {p0}, Landroidx/lifecycle/LifecycleService;->onCreate()V

    .line 4
    invoke-virtual {p0}, Landroidx/work/impl/foreground/SystemForegroundService;->d()V

    .line 7
    return-void
.end method

.method public final onDestroy()V
    .locals 3

    .line 1
    invoke-super {p0}, Landroidx/lifecycle/LifecycleService;->onDestroy()V

    .line 4
    iget-object v0, p0, Landroidx/work/impl/foreground/SystemForegroundService;->f:Landroidx/work/impl/foreground/a;

    .line 6
    const/4 v1, 0x0

    .line 7
    iput-object v1, v0, Landroidx/work/impl/foreground/a;->k:Landroidx/work/impl/foreground/a$a;

    .line 9
    iget-object v1, v0, Landroidx/work/impl/foreground/a;->e:Ljava/lang/Object;

    .line 11
    monitor-enter v1

    .line 12
    :try_start_0
    iget-object v2, v0, Landroidx/work/impl/foreground/a;->j:Le00;

    .line 14
    invoke-virtual {v2}, Le00;->d()V

    .line 17
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 18
    iget-object v1, v0, Landroidx/work/impl/foreground/a;->c:LWorkManagerImpl;

    .line 20
    iget-object v1, v1, LWorkManagerImpl;->h:Luo;

    .line 22
    invoke-virtual {v1, v0}, Luo;->f(Lic;)V

    .line 25
    return-void

    .line 26
    :catchall_0
    move-exception v0

    .line 27
    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 28
    throw v0
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 5

    .line 1
    invoke-super {p0, p1, p2, p3}, Landroidx/lifecycle/LifecycleService;->onStartCommand(Landroid/content/Intent;II)I

    .line 4
    iget-boolean p2, p0, Landroidx/work/impl/foreground/SystemForegroundService;->e:Z

    .line 6
    const/4 p3, 0x0

    .line 7
    if-eqz p2, :cond_0

    .line 9
    invoke-static {}, Ltj;->c()Ltj;

    .line 12
    move-result-object p2

    .line 13
    new-array v0, p3, [Ljava/lang/Throwable;

    .line 15
    invoke-virtual {p2, v0}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 18
    iget-object p2, p0, Landroidx/work/impl/foreground/SystemForegroundService;->f:Landroidx/work/impl/foreground/a;

    .line 20
    const/4 v0, 0x0

    .line 21
    iput-object v0, p2, Landroidx/work/impl/foreground/a;->k:Landroidx/work/impl/foreground/a$a;

    .line 23
    iget-object v0, p2, Landroidx/work/impl/foreground/a;->e:Ljava/lang/Object;

    .line 25
    monitor-enter v0

    .line 26
    :try_start_0
    iget-object v1, p2, Landroidx/work/impl/foreground/a;->j:Le00;

    .line 28
    invoke-virtual {v1}, Le00;->d()V

    .line 31
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 32
    iget-object v0, p2, Landroidx/work/impl/foreground/a;->c:LWorkManagerImpl;

    .line 34
    iget-object v0, v0, LWorkManagerImpl;->h:Luo;

    .line 36
    invoke-virtual {v0, p2}, Luo;->f(Lic;)V

    .line 39
    invoke-virtual {p0}, Landroidx/work/impl/foreground/SystemForegroundService;->d()V

    .line 42
    iput-boolean p3, p0, Landroidx/work/impl/foreground/SystemForegroundService;->e:Z

    .line 44
    goto :goto_0

    .line 45
    :catchall_0
    move-exception p1

    .line 46
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 47
    throw p1

    .line 48
    :cond_0
    :goto_0
    if-eqz p1, :cond_5

    .line 50
    iget-object p2, p0, Landroidx/work/impl/foreground/SystemForegroundService;->f:Landroidx/work/impl/foreground/a;

    .line 52
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 55
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 58
    move-result-object v0

    .line 59
    const-string v1, "nsHJCCJJzbDw+3QQUyXEIbIYwf2e6vQ="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 61
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 64
    move-result v1

    .line 65
    sget v2, Landroidx/work/impl/foreground/a;->l:I

    .line 67
    iget-object v2, p2, Landroidx/work/impl/foreground/a;->c:LWorkManagerImpl;

    .line 69
    const-string v3, "lMfEHjpIwKj36mMHUyrP"
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3

    .line 71
    const/4 v4, 0x1

    .line 72
    if-eqz v1, :cond_1

    .line 74
    invoke-static {}, Ltj;->c()Ltj;

    .line 77
    move-result-object v0

    .line 78
    new-array v1, v4, [Ljava/lang/Object;

    .line 80
    aput-object p1, v1, p3

    .line 82
    const-string v4, "jPb8Mxli9sPC1VQhaxHkBpk7s8Gu1sYNI4YRmfo="
    invoke-static {v4}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4

    .line 84
    invoke-static {v4, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 87
    new-array p3, p3, [Ljava/lang/Throwable;

    .line 89
    invoke-virtual {v0, p3}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 92
    invoke-virtual {p1, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 95
    move-result-object p3

    .line 96
    iget-object v0, v2, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 98
    new-instance v1, Lzt;

    .line 100
    invoke-direct {v1, p2, v0, p3}, Lzt;-><init>(Landroidx/work/impl/foreground/a;Landroidx/work/impl/WorkDatabase;Ljava/lang/String;)V

    .line 103
    iget-object p3, p2, Landroidx/work/impl/foreground/a;->d:Lnu;

    .line 105
    check-cast p3, Lp00;

    .line 107
    invoke-virtual {p3, v1}, Lp00;->a(Ljava/lang/Runnable;)V

    .line 110
    invoke-virtual {p2, p1}, Landroidx/work/impl/foreground/a;->f(Landroid/content/Intent;)V

    .line 113
    goto/16 :goto_1

    .line 115
    :cond_1
    const-string v1, "nsHJCCJJza3r7m8CVQ=="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 117
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 120
    move-result v1

    .line 121
    if-eqz v1, :cond_2

    .line 123
    invoke-virtual {p2, p1}, Landroidx/work/impl/foreground/a;->f(Landroid/content/Intent;)V

    .line 126
    goto :goto_1

    .line 127
    :cond_2
    const-string v1, "nsHJCCJJzaDl9GUBQDzcPKUU"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 129
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 132
    move-result v1

    .line 133
    if-eqz v1, :cond_3

    .line 135
    invoke-static {}, Ltj;->c()Ltj;

    .line 138
    move-result-object p2

    .line 139
    new-array v0, v4, [Ljava/lang/Object;

    .line 141
    aput-object p1, v0, p3

    .line 143
    const-string v1, "jPbyMR1u/ISE3Ek2aQT5HIIx95K8y8IPYIVezqnAXQ=="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 145
    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 148
    new-array p3, p3, [Ljava/lang/Throwable;

    .line 150
    invoke-virtual {p2, p3}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 153
    invoke-virtual {p1, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 156
    move-result-object p1

    .line 157
    if-eqz p1, :cond_5

    .line 159
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 162
    move-result p2

    .line 163
    if-nez p2, :cond_5

    .line 165
    invoke-static {p1}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    .line 168
    move-result-object p1

    .line 169
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 172
    new-instance p2, Lm5;

    .line 174
    invoke-direct {p2, v2, p1}, Lm5;-><init>(LWorkManagerImpl;Ljava/util/UUID;)V

    .line 177
    iget-object p1, v2, LWorkManagerImpl;->f:Lnu;

    .line 179
    check-cast p1, Lp00;

    .line 181
    invoke-virtual {p1, p2}, Lp00;->a(Ljava/lang/Runnable;)V

    .line 184
    goto :goto_1

    .line 185
    :cond_3
    const-string p1, "ACTION_STOP_FOREGROUND"

    .line 187
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 190
    move-result p1

    .line 191
    if-eqz p1, :cond_5

    .line 193
    invoke-static {}, Ltj;->c()Ltj;

    .line 196
    move-result-object p1

    .line 197
    new-array v0, p3, [Ljava/lang/Throwable;

    .line 199
    invoke-virtual {p1, v0}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 202
    iget-object p1, p2, Landroidx/work/impl/foreground/a;->k:Landroidx/work/impl/foreground/a$a;

    .line 204
    if-eqz p1, :cond_5

    .line 206
    check-cast p1, Landroidx/work/impl/foreground/SystemForegroundService;

    .line 208
    iput-boolean v4, p1, Landroidx/work/impl/foreground/SystemForegroundService;->e:Z

    .line 210
    invoke-static {}, Ltj;->c()Ltj;

    .line 213
    move-result-object p2

    .line 214
    new-array p3, p3, [Ljava/lang/Throwable;

    .line 216
    invoke-virtual {p2, p3}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 219
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 221
    const/16 p3, 0x1a

    .line 223
    if-lt p2, p3, :cond_4

    .line 225
    invoke-virtual {p1, v4}, Landroid/app/Service;->stopForeground(Z)V

    .line 228
    :cond_4
    invoke-virtual {p1}, Landroid/app/Service;->stopSelf()V

    .line 231
    :cond_5
    :goto_1
    const/4 p1, 0x3

    .line 232
    return p1
.end method
