.class public Landroidx/work/impl/workers/DiagnosticsWorker;
.super Landroidx/work/Worker;
.source "ygcrodoi.java"

# verified-48803
# ep-lbkhxbdjtkik

# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "DiagnosticsWrkr"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroidx/work/Worker;-><init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V

    return-void
.end method

.method public static h(Lr00;Lc10;Leu;Ljava/util/ArrayList;)Ljava/lang/String;
    .locals 9

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 6
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 8
    const/16 v2, 0x17

    .line 10
    if-lt v1, v2, :cond_0

    .line 12
    const-string v1, "Job Id"

    .line 14
    goto :goto_0

    .line 15
    :cond_0
    const-string v1, "Alarm Id"

    .line 17
    :goto_0
    const/4 v2, 0x1

    .line 18
    new-array v3, v2, [Ljava/lang/Object;

    .line 20
    const/4 v4, 0x0

    .line 21
    aput-object v1, v3, v4

    .line 23
    const-string v1, "\n Id \t Class Name\t %s\t State\t Unique Name\t Tags\t"

    .line 25
    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 28
    move-result-object v1

    .line 29
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 32
    invoke-virtual {p3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 35
    move-result-object p3

    .line 36
    :goto_1
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    .line 39
    move-result v1

    .line 40
    if-eqz v1, :cond_4

    .line 42
    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 45
    move-result-object v1

    .line 46
    check-cast v1, LWorkSpec;

    .line 48
    iget-object v3, v1, LWorkSpec;->a:Ljava/lang/String;

    .line 50
    move-object v5, p2

    .line 51
    check-cast v5, Lfu;

    .line 53
    invoke-virtual {v5, v3}, Lfu;->a(Ljava/lang/String;)Ldu;

    .line 56
    move-result-object v3

    .line 57
    if-eqz v3, :cond_1

    .line 59
    iget v3, v3, Ldu;->b:I

    .line 61
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 64
    move-result-object v3

    .line 65
    goto :goto_2

    .line 66
    :cond_1
    const/4 v3, 0x0

    .line 67
    :goto_2
    iget-object v5, v1, LWorkSpec;->a:Ljava/lang/String;

    .line 69
    move-object v6, p0

    .line 70
    check-cast v6, Ls00;

    .line 72
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 75
    const-string v7, "SELECT name FROM workname WHERE work_spec_id=?"

    .line 77
    invoke-static {v7, v2}, Llq;->r(Ljava/lang/String;I)Llq;

    .line 80
    move-result-object v7

    .line 81
    if-nez v5, :cond_2

    .line 83
    invoke-virtual {v7, v2}, Llq;->t(I)V

    .line 86
    goto :goto_3

    .line 87
    :cond_2
    invoke-virtual {v7, v5, v2}, Llq;->u(Ljava/lang/String;I)V

    .line 90
    :goto_3
    iget-object v5, v6, Ls00;->a:Ljq;

    .line 92
    invoke-virtual {v5}, Ljq;->b()V

    .line 95
    invoke-virtual {v5, v7}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 98
    move-result-object v5

    .line 99
    :try_start_0
    new-instance v6, Ljava/util/ArrayList;

    .line 101
    invoke-interface {v5}, Landroid/database/Cursor;->getCount()I

    .line 104
    move-result v8

    .line 105
    invoke-direct {v6, v8}, Ljava/util/ArrayList;-><init>(I)V

    .line 108
    :goto_4
    invoke-interface {v5}, Landroid/database/Cursor;->moveToNext()Z

    .line 111
    move-result v8

    .line 112
    if-eqz v8, :cond_3

    .line 114
    invoke-interface {v5, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 117
    move-result-object v8

    .line 118
    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 121
    goto :goto_4

    .line 122
    :catchall_0
    move-exception p0

    .line 123
    goto :goto_5

    .line 124
    :cond_3
    invoke-interface {v5}, Landroid/database/Cursor;->close()V

    .line 127
    invoke-virtual {v7}, Llq;->v()V

    .line 130
    iget-object v5, v1, LWorkSpec;->a:Ljava/lang/String;

    .line 132
    move-object v7, p1

    .line 133
    check-cast v7, Ld10;

    .line 135
    invoke-virtual {v7, v5}, Ld10;->a(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 138
    move-result-object v5

    .line 139
    const-string v7, ","

    .line 141
    invoke-static {v7, v6}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    .line 144
    move-result-object v6

    .line 145
    invoke-static {v7, v5}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    .line 148
    move-result-object v5

    .line 149
    const/4 v7, 0x6

    .line 150
    new-array v7, v7, [Ljava/lang/Object;

    .line 152
    iget-object v8, v1, LWorkSpec;->a:Ljava/lang/String;

    .line 154
    aput-object v8, v7, v4

    .line 156
    iget-object v8, v1, LWorkSpec;->c:Ljava/lang/String;

    .line 158
    aput-object v8, v7, v2

    .line 160
    const/4 v8, 0x2

    .line 161
    aput-object v3, v7, v8

    .line 163
    iget-object v1, v1, LWorkSpec;->b:LWorkInfo_State;

    .line 165
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 168
    move-result-object v1

    .line 169
    const/4 v3, 0x3

    .line 170
    aput-object v1, v7, v3

    .line 172
    const/4 v1, 0x4

    .line 173
    aput-object v6, v7, v1

    .line 175
    const/4 v1, 0x5

    .line 176
    aput-object v5, v7, v1

    .line 178
    const-string v1, "\n%s\t %s\t %s\t %s\t %s\t %s\t"

    .line 180
    invoke-static {v1, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 183
    move-result-object v1

    .line 184
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 187
    goto/16 :goto_1

    .line 189
    :goto_5
    invoke-interface {v5}, Landroid/database/Cursor;->close()V

    .line 192
    invoke-virtual {v7}, Llq;->v()V

    .line 195
    throw p0

    .line 196
    :cond_4
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 199
    move-result-object p0

    .line 200
    return-object p0
.end method


# virtual methods
.method public final g()Landroidx/work/ListenableWorker$a;
    .locals 38

    .line 1
    move-object/from16 v1, p0

    .line 3
    iget-object v0, v1, Landroidx/work/ListenableWorker;->c:Landroid/content/Context;

    .line 5
    invoke-static {v0}, LWorkManagerImpl;->s(Landroid/content/Context;)LWorkManagerImpl;

    .line 8
    move-result-object v0

    .line 9
    iget-object v0, v0, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 11
    invoke-virtual {v0}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 14
    move-result-object v2

    .line 15
    invoke-virtual {v0}, Landroidx/work/impl/WorkDatabase;->l()Lr00;

    .line 18
    move-result-object v3

    .line 19
    invoke-virtual {v0}, Landroidx/work/impl/WorkDatabase;->o()Lc10;

    .line 22
    move-result-object v4

    .line 23
    invoke-virtual {v0}, Landroidx/work/impl/WorkDatabase;->k()Leu;

    .line 26
    move-result-object v0

    .line 27
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 30
    move-result-wide v5

    .line 31
    sget-object v7, Ljava/util/concurrent/TimeUnit;->DAYS:Ljava/util/concurrent/TimeUnit;

    .line 33
    const-wide/16 v8, 0x1

    .line 35
    invoke-virtual {v7, v8, v9}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 38
    move-result-wide v7

    .line 39
    sub-long/2addr v5, v7

    .line 40
    check-cast v2, LWorkSpecDao;

    .line 42
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    const-string v7, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE period_start_time >= ? AND state IN (2, 3, 5) ORDER BY period_start_time DESC"

    .line 47
    const/4 v8, 0x1

    .line 48
    invoke-static {v7, v8}, Llq;->r(Ljava/lang/String;I)Llq;

    .line 51
    move-result-object v7

    .line 52
    invoke-virtual {v7, v8, v5, v6}, Llq;->s(IJ)V

    .line 55
    iget-object v5, v2, LWorkSpecDao;->a:Ljq;

    .line 57
    invoke-virtual {v5}, Ljq;->b()V

    .line 60
    invoke-virtual {v5, v7}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 63
    move-result-object v5

    .line 64
    :try_start_0
    const-string v6, "required_network_type"

    .line 66
    invoke-static {v5, v6}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 69
    move-result v6

    .line 70
    const-string v9, "requires_charging"

    .line 72
    invoke-static {v5, v9}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 75
    move-result v9

    .line 76
    const-string v10, "requires_device_idle"

    .line 78
    invoke-static {v5, v10}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 81
    move-result v10

    .line 82
    const-string v11, "requires_battery_not_low"

    .line 84
    invoke-static {v5, v11}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 87
    move-result v11

    .line 88
    const-string v12, "requires_storage_not_low"

    .line 90
    invoke-static {v5, v12}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 93
    move-result v12

    .line 94
    const-string v13, "trigger_content_update_delay"

    .line 96
    invoke-static {v5, v13}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 99
    move-result v13

    .line 100
    const-string v14, "trigger_max_content_delay"

    .line 102
    invoke-static {v5, v14}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 105
    move-result v14

    .line 106
    const-string v15, "content_uri_triggers"

    .line 108
    invoke-static {v5, v15}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 111
    move-result v15

    .line 112
    const-string v8, "id"

    .line 114
    invoke-static {v5, v8}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 117
    move-result v8

    .line 118
    const-string v1, "state"

    .line 120
    invoke-static {v5, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 123
    move-result v1

    .line 124
    move-object/from16 v16, v0

    .line 126
    const-string v0, "worker_class_name"

    .line 128
    invoke-static {v5, v0}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 131
    move-result v0

    .line 132
    move-object/from16 v17, v3

    .line 134
    const-string v3, "input_merger_class_name"

    .line 136
    invoke-static {v5, v3}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 139
    move-result v3

    .line 140
    move-object/from16 v18, v4

    .line 142
    const-string v4, "input"

    .line 144
    invoke-static {v5, v4}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 147
    move-result v4

    .line 148
    move-object/from16 v19, v2

    .line 150
    const-string v2, "output"

    .line 152
    invoke-static {v5, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 155
    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 156
    move-object/from16 v20, v7

    .line 158
    :try_start_1
    const-string v7, "initial_delay"

    .line 160
    invoke-static {v5, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 163
    move-result v7

    .line 164
    move/from16 v21, v7

    .line 166
    const-string v7, "interval_duration"

    .line 168
    invoke-static {v5, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 171
    move-result v7

    .line 172
    move/from16 v22, v7

    .line 174
    const-string v7, "flex_duration"

    .line 176
    invoke-static {v5, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 179
    move-result v7

    .line 180
    move/from16 v23, v7

    .line 182
    const-string v7, "run_attempt_count"

    .line 184
    invoke-static {v5, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 187
    move-result v7

    .line 188
    move/from16 v24, v7

    .line 190
    const-string v7, "backoff_policy"

    .line 192
    invoke-static {v5, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 195
    move-result v7

    .line 196
    move/from16 v25, v7

    .line 198
    const-string v7, "backoff_delay_duration"

    .line 200
    invoke-static {v5, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 203
    move-result v7

    .line 204
    move/from16 v26, v7

    .line 206
    const-string v7, "period_start_time"

    .line 208
    invoke-static {v5, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 211
    move-result v7

    .line 212
    move/from16 v27, v7

    .line 214
    const-string v7, "minimum_retention_duration"

    .line 216
    invoke-static {v5, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 219
    move-result v7

    .line 220
    move/from16 v28, v7

    .line 222
    const-string v7, "schedule_requested_at"

    .line 224
    invoke-static {v5, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 227
    move-result v7

    .line 228
    move/from16 v29, v7

    .line 230
    const-string v7, "run_in_foreground"

    .line 232
    invoke-static {v5, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 235
    move-result v7

    .line 236
    move/from16 v30, v7

    .line 238
    const-string v7, "out_of_quota_policy"

    .line 240
    invoke-static {v5, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 243
    move-result v7

    .line 244
    move/from16 v31, v7

    .line 246
    new-instance v7, Ljava/util/ArrayList;

    .line 248
    move/from16 v32, v2

    .line 250
    invoke-interface {v5}, Landroid/database/Cursor;->getCount()I

    .line 253
    move-result v2

    .line 254
    invoke-direct {v7, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 257
    :goto_0
    invoke-interface {v5}, Landroid/database/Cursor;->moveToNext()Z

    .line 260
    move-result v2

    .line 261
    move-object/from16 v33, v7

    .line 263
    if-eqz v2, :cond_5

    .line 265
    invoke-interface {v5, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 268
    move-result-object v2

    .line 269
    invoke-interface {v5, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 272
    move-result-object v7

    .line 273
    move/from16 v34, v0

    .line 275
    new-instance v0, Lf8;

    .line 277
    invoke-direct {v0}, Lf8;-><init>()V

    .line 280
    invoke-interface {v5, v6}, Landroid/database/Cursor;->getInt(I)I

    .line 283
    move-result v35

    .line 284
    move/from16 v36, v6

    .line 286
    invoke-static/range {v35 .. v35}, Lf10;->c(I)Lqm;

    .line 289
    move-result-object v6

    .line 290
    iput-object v6, v0, Lf8;->a:Lqm;

    .line 292
    invoke-interface {v5, v9}, Landroid/database/Cursor;->getInt(I)I

    .line 295
    move-result v6

    .line 296
    if-eqz v6, :cond_0

    .line 298
    const/4 v6, 0x1

    .line 299
    goto :goto_1

    .line 300
    :cond_0
    const/4 v6, 0x0

    .line 301
    :goto_1
    iput-boolean v6, v0, Lf8;->b:Z

    .line 303
    invoke-interface {v5, v10}, Landroid/database/Cursor;->getInt(I)I

    .line 306
    move-result v6

    .line 307
    if-eqz v6, :cond_1

    .line 309
    const/4 v6, 0x1

    .line 310
    goto :goto_2

    .line 311
    :cond_1
    const/4 v6, 0x0

    .line 312
    :goto_2
    iput-boolean v6, v0, Lf8;->c:Z

    .line 314
    invoke-interface {v5, v11}, Landroid/database/Cursor;->getInt(I)I

    .line 317
    move-result v6

    .line 318
    if-eqz v6, :cond_2

    .line 320
    const/4 v6, 0x1

    .line 321
    goto :goto_3

    .line 322
    :cond_2
    const/4 v6, 0x0

    .line 323
    :goto_3
    iput-boolean v6, v0, Lf8;->d:Z

    .line 325
    invoke-interface {v5, v12}, Landroid/database/Cursor;->getInt(I)I

    .line 328
    move-result v6

    .line 329
    if-eqz v6, :cond_3

    .line 331
    const/4 v6, 0x1

    .line 332
    goto :goto_4

    .line 333
    :cond_3
    const/4 v6, 0x0

    .line 334
    :goto_4
    iput-boolean v6, v0, Lf8;->e:Z

    .line 336
    move/from16 v35, v8

    .line 338
    move v6, v9

    .line 339
    invoke-interface {v5, v13}, Landroid/database/Cursor;->getLong(I)J

    .line 342
    move-result-wide v8

    .line 343
    iput-wide v8, v0, Lf8;->f:J

    .line 345
    invoke-interface {v5, v14}, Landroid/database/Cursor;->getLong(I)J

    .line 348
    move-result-wide v8

    .line 349
    iput-wide v8, v0, Lf8;->g:J

    .line 351
    invoke-interface {v5, v15}, Landroid/database/Cursor;->getBlob(I)[B

    .line 354
    move-result-object v8

    .line 355
    invoke-static {v8}, Lf10;->a([B)Ll8;

    .line 358
    move-result-object v8

    .line 359
    iput-object v8, v0, Lf8;->h:Ll8;

    .line 361
    new-instance v8, LWorkSpec;

    .line 363
    invoke-direct {v8, v2, v7}, LWorkSpec;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 366
    invoke-interface {v5, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 369
    move-result v2

    .line 370
    invoke-static {v2}, Lf10;->e(I)LWorkInfo_State;

    .line 373
    move-result-object v2

    .line 374
    iput-object v2, v8, LWorkSpec;->b:LWorkInfo_State;

    .line 376
    invoke-interface {v5, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 379
    move-result-object v2

    .line 380
    iput-object v2, v8, LWorkSpec;->d:Ljava/lang/String;

    .line 382
    invoke-interface {v5, v4}, Landroid/database/Cursor;->getBlob(I)[B

    .line 385
    move-result-object v2

    .line 386
    invoke-static {v2}, Landroidx/work/b;->a([B)Landroidx/work/b;

    .line 389
    move-result-object v2

    .line 390
    iput-object v2, v8, LWorkSpec;->e:Landroidx/work/b;

    .line 392
    move/from16 v2, v32

    .line 394
    invoke-interface {v5, v2}, Landroid/database/Cursor;->getBlob(I)[B

    .line 397
    move-result-object v7

    .line 398
    invoke-static {v7}, Landroidx/work/b;->a([B)Landroidx/work/b;

    .line 401
    move-result-object v7

    .line 402
    iput-object v7, v8, LWorkSpec;->f:Landroidx/work/b;

    .line 404
    move v9, v1

    .line 405
    move/from16 v32, v2

    .line 407
    move/from16 v7, v21

    .line 409
    invoke-interface {v5, v7}, Landroid/database/Cursor;->getLong(I)J

    .line 412
    move-result-wide v1

    .line 413
    iput-wide v1, v8, LWorkSpec;->g:J

    .line 415
    move/from16 v21, v3

    .line 417
    move/from16 v1, v22

    .line 419
    invoke-interface {v5, v1}, Landroid/database/Cursor;->getLong(I)J

    .line 422
    move-result-wide v2

    .line 423
    iput-wide v2, v8, LWorkSpec;->h:J

    .line 425
    move/from16 v22, v4

    .line 427
    move/from16 v2, v23

    .line 429
    invoke-interface {v5, v2}, Landroid/database/Cursor;->getLong(I)J

    .line 432
    move-result-wide v3

    .line 433
    iput-wide v3, v8, LWorkSpec;->i:J

    .line 435
    move/from16 v3, v24

    .line 437
    invoke-interface {v5, v3}, Landroid/database/Cursor;->getInt(I)I

    .line 440
    move-result v4

    .line 441
    iput v4, v8, LWorkSpec;->k:I

    .line 443
    move/from16 v4, v25

    .line 445
    invoke-interface {v5, v4}, Landroid/database/Cursor;->getInt(I)I

    .line 448
    move-result v23

    .line 449
    move/from16 v24, v1

    .line 451
    invoke-static/range {v23 .. v23}, Lf10;->b(I)I

    .line 454
    move-result v1

    .line 455
    iput v1, v8, LWorkSpec;->l:I

    .line 457
    move/from16 v23, v2

    .line 459
    move/from16 v25, v3

    .line 461
    move/from16 v1, v26

    .line 463
    invoke-interface {v5, v1}, Landroid/database/Cursor;->getLong(I)J

    .line 466
    move-result-wide v2

    .line 467
    iput-wide v2, v8, LWorkSpec;->m:J

    .line 469
    move/from16 v26, v4

    .line 471
    move/from16 v2, v27

    .line 473
    invoke-interface {v5, v2}, Landroid/database/Cursor;->getLong(I)J

    .line 476
    move-result-wide v3

    .line 477
    iput-wide v3, v8, LWorkSpec;->n:J

    .line 479
    move v4, v1

    .line 480
    move/from16 v27, v2

    .line 482
    move/from16 v3, v28

    .line 484
    invoke-interface {v5, v3}, Landroid/database/Cursor;->getLong(I)J

    .line 487
    move-result-wide v1

    .line 488
    iput-wide v1, v8, LWorkSpec;->o:J

    .line 490
    move/from16 v28, v3

    .line 492
    move/from16 v1, v29

    .line 494
    invoke-interface {v5, v1}, Landroid/database/Cursor;->getLong(I)J

    .line 497
    move-result-wide v2

    .line 498
    iput-wide v2, v8, LWorkSpec;->p:J

    .line 500
    move/from16 v2, v30

    .line 502
    invoke-interface {v5, v2}, Landroid/database/Cursor;->getInt(I)I

    .line 505
    move-result v3

    .line 506
    if-eqz v3, :cond_4

    .line 508
    const/4 v3, 0x1

    .line 509
    goto :goto_5

    .line 510
    :cond_4
    const/4 v3, 0x0

    .line 511
    :goto_5
    iput-boolean v3, v8, LWorkSpec;->q:Z

    .line 513
    move/from16 v3, v31

    .line 515
    invoke-interface {v5, v3}, Landroid/database/Cursor;->getInt(I)I

    .line 518
    move-result v29

    .line 519
    move/from16 v30, v1

    .line 521
    invoke-static/range {v29 .. v29}, Lf10;->d(I)I

    .line 524
    move-result v1

    .line 525
    iput v1, v8, LWorkSpec;->r:I

    .line 527
    iput-object v0, v8, LWorkSpec;->j:Lf8;

    .line 529
    move-object/from16 v0, v33

    .line 531
    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 534
    move/from16 v31, v3

    .line 536
    move v1, v9

    .line 537
    move/from16 v3, v21

    .line 539
    move/from16 v29, v30

    .line 541
    move/from16 v8, v35

    .line 543
    move/from16 v30, v2

    .line 545
    move v9, v6

    .line 546
    move/from16 v21, v7

    .line 548
    move/from16 v6, v36

    .line 550
    move-object v7, v0

    .line 551
    move/from16 v0, v34

    .line 553
    move/from16 v37, v26

    .line 555
    move/from16 v26, v4

    .line 557
    move/from16 v4, v22

    .line 559
    move/from16 v22, v24

    .line 561
    move/from16 v24, v25

    .line 563
    move/from16 v25, v37

    .line 565
    goto/16 :goto_0

    .line 567
    :cond_5
    move-object/from16 v0, v33

    .line 569
    invoke-interface {v5}, Landroid/database/Cursor;->close()V

    .line 572
    invoke-virtual/range {v20 .. v20}, Llq;->v()V

    .line 575
    invoke-virtual/range {v19 .. v19}, LWorkSpecDao;->d()Ljava/util/ArrayList;

    .line 578
    move-result-object v1

    .line 579
    invoke-virtual/range {v19 .. v19}, LWorkSpecDao;->b()Ljava/util/ArrayList;

    .line 582
    move-result-object v2

    .line 583
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 586
    move-result v3

    .line 587
    if-nez v3, :cond_6

    .line 589
    invoke-static {}, Ltj;->c()Ltj;

    .line 592
    move-result-object v3

    .line 593
    const/4 v4, 0x0

    .line 594
    new-array v5, v4, [Ljava/lang/Throwable;

    .line 596
    invoke-virtual {v3, v5}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 599
    invoke-static {}, Ltj;->c()Ltj;

    .line 602
    move-result-object v3

    .line 603
    move-object/from16 v7, v16

    .line 605
    move-object/from16 v5, v17

    .line 607
    move-object/from16 v6, v18

    .line 609
    invoke-static {v5, v6, v7, v0}, Landroidx/work/impl/workers/DiagnosticsWorker;->h(Lr00;Lc10;Leu;Ljava/util/ArrayList;)Ljava/lang/String;

    .line 612
    new-array v0, v4, [Ljava/lang/Throwable;

    .line 614
    invoke-virtual {v3, v0}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 617
    goto :goto_6

    .line 618
    :cond_6
    move-object/from16 v7, v16

    .line 620
    move-object/from16 v5, v17

    .line 622
    move-object/from16 v6, v18

    .line 624
    const/4 v4, 0x0

    .line 625
    :goto_6
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 628
    move-result v0

    .line 629
    if-nez v0, :cond_7

    .line 631
    invoke-static {}, Ltj;->c()Ltj;

    .line 634
    move-result-object v0

    .line 635
    new-array v3, v4, [Ljava/lang/Throwable;

    .line 637
    invoke-virtual {v0, v3}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 640
    invoke-static {}, Ltj;->c()Ltj;

    .line 643
    move-result-object v0

    .line 644
    invoke-static {v5, v6, v7, v1}, Landroidx/work/impl/workers/DiagnosticsWorker;->h(Lr00;Lc10;Leu;Ljava/util/ArrayList;)Ljava/lang/String;

    .line 647
    new-array v1, v4, [Ljava/lang/Throwable;

    .line 649
    invoke-virtual {v0, v1}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 652
    :cond_7
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    .line 655
    move-result v0

    .line 656
    if-nez v0, :cond_8

    .line 658
    invoke-static {}, Ltj;->c()Ltj;

    .line 661
    move-result-object v0

    .line 662
    new-array v1, v4, [Ljava/lang/Throwable;

    .line 664
    invoke-virtual {v0, v1}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 667
    invoke-static {}, Ltj;->c()Ltj;

    .line 670
    move-result-object v0

    .line 671
    invoke-static {v5, v6, v7, v2}, Landroidx/work/impl/workers/DiagnosticsWorker;->h(Lr00;Lc10;Leu;Ljava/util/ArrayList;)Ljava/lang/String;

    .line 674
    new-array v1, v4, [Ljava/lang/Throwable;

    .line 676
    invoke-virtual {v0, v1}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 679
    :cond_8
    new-instance v0, Landroidx/work/ListenableWorker$a$c;

    .line 681
    invoke-direct {v0}, Landroidx/work/ListenableWorker$a$c;-><init>()V

    .line 684
    return-object v0

    .line 685
    :catchall_0
    move-exception v0

    .line 686
    goto :goto_7

    .line 687
    :catchall_1
    move-exception v0

    .line 688
    move-object/from16 v20, v7

    .line 690
    :goto_7
    invoke-interface {v5}, Landroid/database/Cursor;->close()V

    .line 693
    invoke-virtual/range {v20 .. v20}, Llq;->v()V

    .line 696
    throw v0
.end method
