.class public final Landroidx/work/WorkManagerInitializer;
.super Ljava/lang/Object;
# verified-47985
# compiled-45289
# optimised-18016
.source "qgkckedo.java"

# ep-myttalimrfip
# interfaces
.implements Lyh;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lyh<",
        "Ln00;",
        ">;"
    }
.end annotation


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "WrkMgrInitializer"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Class<",
            "+",
            "Lyh<",
            "*>;>;>;"
        }
    .end annotation

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public final b(Landroid/content/Context;)Ljava/lang/Object;
    .locals 2

    .line 1
    invoke-static {}, Ltj;->c()Ltj;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    new-array v1, v1, [Ljava/lang/Throwable;

    .line 8
    invoke-virtual {v0, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 11
    new-instance v0, Landroidx/work/a$a;

    .line 13
    invoke-direct {v0}, Landroidx/work/a$a;-><init>()V

    .line 16
    new-instance v1, Landroidx/work/a;

    .line 18
    invoke-direct {v1, v0}, Landroidx/work/a;-><init>(Landroidx/work/a$a;)V

    .line 21
    invoke-static {p1, v1}, LWorkManagerImpl;->t(Landroid/content/Context;Landroidx/work/a;)V

    .line 24
    invoke-static {p1}, LWorkManagerImpl;->s(Landroid/content/Context;)LWorkManagerImpl;

    .line 27
    move-result-object p1

    .line 28
    return-object p1
.end method
