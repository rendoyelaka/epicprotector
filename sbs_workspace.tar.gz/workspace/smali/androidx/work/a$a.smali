.class public final Landroidx/work/a$a;
# ep-lfngpgsagwbw
.super Ljava/lang/Object;
.source "yjeriedi.java"

# verified-73573
# validated-73215
# verified-43367

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
