.class public final Landroidx/work/a$a;
# ep-ctvahuuedboh
.super Ljava/lang/Object;
# verified-40827
# verified-62593
# generated-67996
.source "ytvowkml.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
