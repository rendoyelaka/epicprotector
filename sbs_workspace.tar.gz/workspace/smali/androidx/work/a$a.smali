.class public final Landroidx/work/a$a;
# ep-nkvqumdegtua
.super Ljava/lang/Object;
# verified-15018
# generated-39621
# verified-31143
.source "CreatorHelper94.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
