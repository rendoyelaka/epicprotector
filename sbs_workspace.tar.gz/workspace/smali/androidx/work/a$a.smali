.class public final Landroidx/work/a$a;
.super Ljava/lang/Object;
.source "KeyHelper48.java"
# ep-mwcqlokgpqck

# optimised-36651
# optimised-72143
# verified-37975

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
