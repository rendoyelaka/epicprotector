.class public final Landroidx/work/a$a;
# ep-hlrjkzkohzid
.super Ljava/lang/Object;
# validated-59897
# optimised-65349
# generated-70891
.source "hbolskto.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/work/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
