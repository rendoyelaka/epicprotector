.class public final Landroidx/work/c;
# ep-feddloxhgtvc
.super Ljava/lang/Object;
# optimised-38792
# verified-94365
# generated-85067
.source "DataUtils88.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Landroidx/work/Worker;


# direct methods
.method public constructor <init>(Landroidx/work/Worker;)V
    .locals 0

    iput-object p1, p0, Landroidx/work/c;->c:Landroidx/work/Worker;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/work/c;->c:Landroidx/work/Worker;

    .line 3
    :try_start_0
    invoke-virtual {v0}, Landroidx/work/Worker;->g()Landroidx/work/ListenableWorker$a;

    .line 6
    move-result-object v1

    .line 7
    iget-object v2, v0, Landroidx/work/Worker;->h:Ltr;

    .line 9
    invoke-virtual {v2, v1}, Ltr;->i(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 12
    goto :goto_0

    .line 13
    :catchall_0
    move-exception v1

    .line 14
    iget-object v0, v0, Landroidx/work/Worker;->h:Ltr;

    .line 16
    invoke-virtual {v0, v1}, Ltr;->j(Ljava/lang/Throwable;)Z

    .line 19
    :goto_0
    return-void
.end method
