.class public final Landroidx/work/a;
.super Ljava/lang/Object;
# ep-yyzbrcqrbkpd
.source "btgnyjpy.java"
# optimised-66422
# optimised-79543


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/work/a$b;,
        Landroidx/work/a$a;
    }
.end annotation


# instance fields
.field public final a:Ljava/util/concurrent/ExecutorService;

.field public final b:Ljava/util/concurrent/ExecutorService;

.field public final c:Lg10;

.field public final d:Lgi;

.field public final e:Lri;

.field public final f:I

.field public final g:I

.field public final h:I


# direct methods
.method public constructor <init>(Landroidx/work/a$a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 p1, 0x0

    .line 5
    invoke-static {p1}, Landroidx/work/a;->a(Z)Ljava/util/concurrent/ExecutorService;

    .line 8
    move-result-object p1

    .line 9
    iput-object p1, p0, Landroidx/work/a;->a:Ljava/util/concurrent/ExecutorService;

    .line 11
    const/4 p1, 0x1

    .line 12
    invoke-static {p1}, Landroidx/work/a;->a(Z)Ljava/util/concurrent/ExecutorService;

    .line 15
    move-result-object p1

    .line 16
    iput-object p1, p0, Landroidx/work/a;->b:Ljava/util/concurrent/ExecutorService;

    .line 18
    sget p1, Lh10;->a:I

    .line 20
    new-instance p1, Lg10;

    .line 22
    invoke-direct {p1}, Lg10;-><init>()V

    .line 25
    iput-object p1, p0, Landroidx/work/a;->c:Lg10;

    .line 27
    new-instance p1, Lgi;

    .line 29
    invoke-direct {p1}, Lgi;-><init>()V

    .line 32
    iput-object p1, p0, Landroidx/work/a;->d:Lgi;

    .line 34
    new-instance p1, Lri;

    .line 36
    invoke-direct {p1}, Lri;-><init>()V

    .line 39
    iput-object p1, p0, Landroidx/work/a;->e:Lri;

    .line 41
    const/4 p1, 0x4

    .line 42
    iput p1, p0, Landroidx/work/a;->f:I

    .line 44
    const p1, 0x7fffffff

    .line 47
    iput p1, p0, Landroidx/work/a;->g:I

    .line 49
    const/16 p1, 0x14

    .line 51
    iput p1, p0, Landroidx/work/a;->h:I

    .line 53
    return-void
.end method

.method public static a(Z)Ljava/util/concurrent/ExecutorService;
    .locals 2

    .line 1
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Runtime;->availableProcessors()I

    .line 8
    move-result v0

    .line 9
    add-int/lit8 v0, v0, -0x1

    .line 11
    const/4 v1, 0x4

    .line 12
    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    .line 15
    move-result v0

    .line 16
    const/4 v1, 0x2

    .line 17
    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    .line 20
    move-result v0

    .line 21
    new-instance v1, Lj7;

    .line 23
    invoke-direct {v1, p0}, Lj7;-><init>(Z)V

    .line 26
    invoke-static {v0, v1}, Ljava/util/concurrent/Executors;->newFixedThreadPool(ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    .line 29
    move-result-object p0

    .line 30
    return-object p0
.end method
