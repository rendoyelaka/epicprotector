.class public Landroidx/emoji2/text/a$b;
# ep-mbdekjlwxknb
.super Landroidx/emoji2/text/a$a;
.source "gfljtunw.java"
# validated-16999
# generated-22700
# generated-85211


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/emoji2/text/a$a;-><init>()V

    return-void
.end method
