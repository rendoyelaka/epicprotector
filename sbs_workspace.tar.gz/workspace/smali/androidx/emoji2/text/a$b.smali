.class public Landroidx/emoji2/text/a$b;
# ep-ybwtvkwhrvdl
.super Landroidx/emoji2/text/a$a;
.source "ThemeUtils63.java"

# generated-81375
# processed-81708
# compiled-40049

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/emoji2/text/a$a;-><init>()V

    return-void
.end method
