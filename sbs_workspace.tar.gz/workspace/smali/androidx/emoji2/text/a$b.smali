.class public Landroidx/emoji2/text/a$b;
.super Landroidx/emoji2/text/a$a;
# ep-vssncuetmzxg
.source "gnqstonk.java"

# compiled-14847
# verified-90409

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/emoji2/text/a$a;-><init>()V

    return-void
.end method
