.class public Landroidx/emoji2/text/a$b;
# handler-88080-provider
# provider-89999-layout
# callback-78168-fragment
# fragment-94202-callback
# fragment-78380-fragment
# ep-dcxryafvpqzc
# validated-64281
# verified-37111
.super Landroidx/emoji2/text/a$a;
.source "DataManager63.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/emoji2/text/a$a;-><init>()V

    return-void
.end method
