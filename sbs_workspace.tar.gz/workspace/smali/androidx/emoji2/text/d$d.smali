.class public interface abstract Landroidx/emoji2/text/d$d;
.super Ljava/lang/Object;
# generated-80746
# optimised-19603
# optimised-54427
.source "svnlewcl.java"
# ep-ydpvrfnpvjez


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
