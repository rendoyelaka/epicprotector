.class public interface abstract Landroidx/emoji2/text/d$d;
# ep-gbzwlzqopcia
.super Ljava/lang/Object;
# generated-68313
# generated-96694
.source "ydwznihv.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
