.class public interface abstract Landroidx/emoji2/text/d$d;
# ep-lgioqfqkcvwo
.super Ljava/lang/Object;
# verified-69992
.source "izzcmvwp.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
