.class public interface abstract Landroidx/emoji2/text/d$d;
.super Ljava/lang/Object;
.source "ioehoutl.java"
# processed-98154
# validated-96708
# processed-88406

# ep-kslnueyvsxsa

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
