.class public interface abstract Landroidx/emoji2/text/d$d;
.super Ljava/lang/Object;
# generated-97311
# generated-72270
.source "ViewHolder23.java"
# ep-fxkcsnrrmfia


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
