.class public interface abstract Landroidx/emoji2/text/d$d;
.super Ljava/lang/Object;
.source "qzhquhtp.java"
# generated-24877
# optimised-48973

# ep-geklvtvimsta

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
