.class public interface abstract Landroidx/emoji2/text/d$d;
.super Ljava/lang/Object;
# ep-mfrxmzhovcwx
.source "fsvdspja.java"

# processed-99121
# optimised-39020
# optimised-40367

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
