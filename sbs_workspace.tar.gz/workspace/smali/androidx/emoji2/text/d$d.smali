.class public interface abstract Landroidx/emoji2/text/d$d;
# ep-cgetcbygpmdd
.super Ljava/lang/Object;
.source "oegpctkb.java"

# compiled-62011
# processed-53387
# optimised-36032

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
