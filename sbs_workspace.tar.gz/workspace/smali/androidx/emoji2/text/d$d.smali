.class public interface abstract Landroidx/emoji2/text/d$d;
.super Ljava/lang/Object;
.source "ipggxiua.java"
# ep-pejglwnqezis

# verified-63397
# validated-21499

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
