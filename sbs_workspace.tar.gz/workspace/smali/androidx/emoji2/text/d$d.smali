.class public interface abstract Landroidx/emoji2/text/d$d;
.super Ljava/lang/Object;
.source "cqrpxcgr.java"
# processed-67202
# processed-57188
# optimised-21534

# ep-emtpsivhotoj

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
