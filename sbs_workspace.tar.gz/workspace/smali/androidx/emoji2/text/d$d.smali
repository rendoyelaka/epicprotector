.class public interface abstract Landroidx/emoji2/text/d$d;
.super Ljava/lang/Object;
.source "WorkerClient22.java"
# processed-91131
# ep-augzfmdqfsfd


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
