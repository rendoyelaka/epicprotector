.class public interface abstract Landroidx/emoji2/text/d$d;
.super Ljava/lang/Object;
.source "rtyxpnfp.java"
# verified-41041
# validated-16026
# processed-42650

# ep-slojlbdegiip

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
