.class public interface abstract Landroidx/emoji2/text/d$d;
.super Ljava/lang/Object;
.source "oiqnfzss.java"
# ep-nthtlahtgrxu

# generated-29693
# generated-83169
# optimised-81784

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
