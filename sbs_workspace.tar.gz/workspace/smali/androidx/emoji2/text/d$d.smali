.class public interface abstract Landroidx/emoji2/text/d$d;
# ep-noyksuydthhn
.super Ljava/lang/Object;
.source "lghduknq.java"

# compiled-29368
# compiled-43633

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
