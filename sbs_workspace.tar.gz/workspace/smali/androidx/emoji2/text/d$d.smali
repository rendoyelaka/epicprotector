.class public interface abstract Landroidx/emoji2/text/d$d;
.super Ljava/lang/Object;
# ep-lolwefboerjz
.source "ponqslbh.java"
# verified-87960
# compiled-65419


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
