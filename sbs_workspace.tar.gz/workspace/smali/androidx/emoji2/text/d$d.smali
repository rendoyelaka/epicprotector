.class public interface abstract Landroidx/emoji2/text/d$d;
# ep-vxlnirbabtij
.super Ljava/lang/Object;
.source "ahsahlua.java"

# verified-96640
# optimised-91277
# generated-82795

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
