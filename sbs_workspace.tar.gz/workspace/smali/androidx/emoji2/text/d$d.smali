.class public interface abstract Landroidx/emoji2/text/d$d;
.super Ljava/lang/Object;
# ep-zcinuhndfjzn
# optimised-74192
# generated-31833
.source "jmpasybs.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
