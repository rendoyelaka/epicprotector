.class public interface abstract Landroidx/emoji2/text/d$d;
.super Ljava/lang/Object;
.source "micdokly.java"
# ep-keulsllwglcw
# optimised-13993
# generated-14861
# generated-40739


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
