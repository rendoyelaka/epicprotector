.class public interface abstract Landroidx/emoji2/text/d$d;
# ep-rzeqenjodjzq
.super Ljava/lang/Object;
# generated-77697
.source "nfezgkao.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
