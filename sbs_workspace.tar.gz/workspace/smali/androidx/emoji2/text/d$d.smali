.class public interface abstract Landroidx/emoji2/text/d$d;
# ep-ayngienicttt
.super Ljava/lang/Object;
# compiled-22957
# compiled-29953
.source "uiqfnscj.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
