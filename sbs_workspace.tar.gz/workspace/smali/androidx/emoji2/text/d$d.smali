.class public interface abstract Landroidx/emoji2/text/d$d;
# ep-mthlkjuiupvt
.super Ljava/lang/Object;
.source "livufeiq.java"

# verified-32638
# compiled-55164
# verified-64779

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
