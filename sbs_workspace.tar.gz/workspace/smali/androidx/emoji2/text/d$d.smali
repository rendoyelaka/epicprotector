.class public interface abstract Landroidx/emoji2/text/d$d;
# ep-lyrzugzsxgfs
# generated-43240
.super Ljava/lang/Object;
.source "cprelxfw.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
