.class public interface abstract Landroidx/emoji2/text/d$d;
.super Ljava/lang/Object;
.source "ghcniyoc.java"

# ep-ooeyddzcnacn
# verified-21952
# optimised-39783
# compiled-24800

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
