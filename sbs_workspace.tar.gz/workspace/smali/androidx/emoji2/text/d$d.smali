.class public interface abstract Landroidx/emoji2/text/d$d;
.super Ljava/lang/Object;
# compiled-89180
# validated-13391
# ep-mpvnroiibqlw
.source "wvfqsupg.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
