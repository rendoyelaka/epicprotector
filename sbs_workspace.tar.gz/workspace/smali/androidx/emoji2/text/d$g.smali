.class public interface abstract Landroidx/emoji2/text/d$g;
# ep-moteuenenilh
# optimised-94176
.super Ljava/lang/Object;
.source "mvtyurhu.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "g"
.end annotation


# virtual methods
.method public abstract a(Landroidx/emoji2/text/d$h;)V
.end method
