.class public interface abstract Landroidx/emoji2/text/d$g;
# ep-dpezoofoydmn
# generated-55590
# validated-88930
# generated-68433
.super Ljava/lang/Object;
.source "dhatjvww.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "g"
.end annotation


# virtual methods
.method public abstract a(Landroidx/emoji2/text/d$h;)V
.end method
