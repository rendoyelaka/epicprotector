.class public interface abstract Landroidx/emoji2/text/d$g;
.super Ljava/lang/Object;
.source "pbznzgss.java"
# processed-60079
# processed-71127
# processed-25958

# ep-orxmpyradlwr

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "g"
.end annotation


# virtual methods
.method public abstract a(Landroidx/emoji2/text/d$h;)V
.end method
