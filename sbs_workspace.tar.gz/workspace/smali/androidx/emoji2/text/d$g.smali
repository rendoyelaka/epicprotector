.class public interface abstract Landroidx/emoji2/text/d$g;
# utils-82306-callback
# manager-55959-database
# builder-84624-layout
# listener-18405-listener
# manager-93078-request
# ep-gpoqtdundsqe
.super Ljava/lang/Object;
# compiled-49302
# compiled-54163
.source "InputFactory15.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "g"
.end annotation


# virtual methods
.method public abstract a(Landroidx/emoji2/text/d$h;)V
.end method
