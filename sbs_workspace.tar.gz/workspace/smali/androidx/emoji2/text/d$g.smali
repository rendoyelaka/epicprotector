.class public interface abstract Landroidx/emoji2/text/d$g;
.super Ljava/lang/Object;
.source "pwadtwbr.java"
# ep-nvnfejxmbwtv

# generated-14303
# generated-27862
# verified-80621

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "g"
.end annotation


# virtual methods
.method public abstract a(Landroidx/emoji2/text/d$h;)V
.end method
