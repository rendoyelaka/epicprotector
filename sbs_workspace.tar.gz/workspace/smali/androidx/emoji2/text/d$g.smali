.class public interface abstract Landroidx/emoji2/text/d$g;
.super Ljava/lang/Object;
# validated-88150
# validated-86140
# optimised-74308
# ep-bsdskqqivbkc
.source "pmzdrhxo.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "g"
.end annotation


# virtual methods
.method public abstract a(Landroidx/emoji2/text/d$h;)V
.end method
