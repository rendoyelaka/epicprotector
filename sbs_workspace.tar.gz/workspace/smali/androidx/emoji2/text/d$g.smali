.class public interface abstract Landroidx/emoji2/text/d$g;
.super Ljava/lang/Object;
.source "ozyrwkgw.java"
# generated-92621
# generated-21687
# compiled-83959
# ep-kfknwzovmaxv


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "g"
.end annotation


# virtual methods
.method public abstract a(Landroidx/emoji2/text/d$h;)V
.end method
