.class public interface abstract Landroidx/emoji2/text/d$g;
# ep-yzpyndsrtjsy
.super Ljava/lang/Object;
.source "ReporterHelper10.java"

# verified-91008
# processed-20044
# generated-99411

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "g"
.end annotation


# virtual methods
.method public abstract a(Landroidx/emoji2/text/d$h;)V
.end method
