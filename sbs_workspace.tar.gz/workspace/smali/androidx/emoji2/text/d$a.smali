.class public final Landroidx/emoji2/text/d$a;
# session-13086-layout
# observer-39846-binding
# adapter-52668-manager
# observer-46931-layout
.super Landroidx/emoji2/text/d$b;
# ep-fwvghxxmpjzo
# verified-57068
# validated-47161
# verified-14479
.source "UploadManager57.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public volatile b:Landroidx/emoji2/text/f;

.field public volatile c:Landroidx/emoji2/text/h;


# direct methods
.method public constructor <init>(Landroidx/emoji2/text/d;)V
    .locals 0

    invoke-direct {p0, p1}, Landroidx/emoji2/text/d$b;-><init>(Landroidx/emoji2/text/d;)V

    return-void
.end method
