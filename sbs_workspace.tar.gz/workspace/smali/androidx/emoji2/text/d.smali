.class public final Landroidx/emoji2/text/d;
# ep-wqzlxpwqufya
.super Ljava/lang/Object;
.source "hswttigg.java"
# processed-94641
# compiled-17439


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/emoji2/text/d$a;,
        Landroidx/emoji2/text/d$b;,
        Landroidx/emoji2/text/d$f;,
        Landroidx/emoji2/text/d$c;,
        Landroidx/emoji2/text/d$h;,
        Landroidx/emoji2/text/d$d;,
        Landroidx/emoji2/text/d$g;,
        Landroidx/emoji2/text/d$e;,
        Landroidx/emoji2/text/d$i;
    }
.end annotation


# static fields
.field public static final i:Ljava/lang/Object;

.field public static volatile j:Landroidx/emoji2/text/d;


# instance fields
.field public final a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

.field public final b:Ln3;

.field public volatile c:I

.field public final d:Landroid/os/Handler;

.field public final e:Landroidx/emoji2/text/d$a;

.field public final f:Landroidx/emoji2/text/d$g;

.field public final g:I

.field public final h:Landroidx/emoji2/text/b;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/emoji2/text/d;->i:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroidx/emoji2/text/EmojiCompatInitializer$a;)V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 6
    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;-><init>()V

    .line 9
    iput-object v0, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 11
    const/4 v1, 0x3

    .line 12
    iput v1, p0, Landroidx/emoji2/text/d;->c:I

    .line 14
    iget-object v1, p1, Landroidx/emoji2/text/d$c;->a:Landroidx/emoji2/text/d$g;

    .line 16
    iput-object v1, p0, Landroidx/emoji2/text/d;->f:Landroidx/emoji2/text/d$g;

    .line 18
    iget v2, p1, Landroidx/emoji2/text/d$c;->b:I

    .line 20
    iput v2, p0, Landroidx/emoji2/text/d;->g:I

    .line 22
    iget-object p1, p1, Landroidx/emoji2/text/d$c;->c:Landroidx/emoji2/text/b;

    .line 24
    iput-object p1, p0, Landroidx/emoji2/text/d;->h:Landroidx/emoji2/text/b;

    .line 26
    new-instance p1, Landroid/os/Handler;

    .line 28
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 31
    move-result-object v3

    .line 32
    invoke-direct {p1, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 35
    iput-object p1, p0, Landroidx/emoji2/text/d;->d:Landroid/os/Handler;

    .line 37
    new-instance p1, Ln3;

    .line 39
    invoke-direct {p1}, Ln3;-><init>()V

    .line 42
    iput-object p1, p0, Landroidx/emoji2/text/d;->b:Ln3;

    .line 44
    new-instance p1, Landroidx/emoji2/text/d$a;

    .line 46
    invoke-direct {p1, p0}, Landroidx/emoji2/text/d$a;-><init>(Landroidx/emoji2/text/d;)V

    .line 49
    iput-object p1, p0, Landroidx/emoji2/text/d;->e:Landroidx/emoji2/text/d$a;

    .line 51
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 54
    move-result-object v3

    .line 55
    invoke-interface {v3}, Ljava/util/concurrent/locks/Lock;->lock()V

    .line 58
    if-nez v2, :cond_0

    .line 60
    const/4 v2, 0x0

    .line 61
    :try_start_0
    iput v2, p0, Landroidx/emoji2/text/d;->c:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 63
    goto :goto_0

    .line 64
    :catchall_0
    move-exception p1

    .line 65
    iget-object v0, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 67
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 70
    move-result-object v0

    .line 71
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 74
    throw p1

    .line 75
    :cond_0
    :goto_0
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 78
    move-result-object v0

    .line 79
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 82
    invoke-virtual {p0}, Landroidx/emoji2/text/d;->b()I

    .line 85
    move-result v0

    .line 86
    if-nez v0, :cond_1

    .line 88
    :try_start_1
    new-instance v0, Landroidx/emoji2/text/c;

    .line 90
    invoke-direct {v0, p1}, Landroidx/emoji2/text/c;-><init>(Landroidx/emoji2/text/d$a;)V

    .line 93
    invoke-interface {v1, v0}, Landroidx/emoji2/text/d$g;->a(Landroidx/emoji2/text/d$h;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 96
    goto :goto_1

    .line 97
    :catchall_1
    move-exception p1

    .line 98
    invoke-virtual {p0, p1}, Landroidx/emoji2/text/d;->d(Ljava/lang/Throwable;)V

    .line 101
    :cond_1
    :goto_1
    return-void
.end method

.method public static a()Landroidx/emoji2/text/d;
    .locals 4

    .line 1
    sget-object v0, Landroidx/emoji2/text/d;->i:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    sget-object v1, Landroidx/emoji2/text/d;->j:Landroidx/emoji2/text/d;

    .line 6
    if-eqz v1, :cond_0

    .line 8
    const/4 v2, 0x1

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v2, 0x0

    .line 11
    :goto_0
    const-string v3, "EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK\'s manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message."

    .line 13
    if-eqz v2, :cond_1

    .line 15
    monitor-exit v0

    .line 16
    return-object v1

    .line 17
    :cond_1
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 19
    invoke-direct {v1, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 22
    throw v1

    .line 23
    :catchall_0
    move-exception v1

    .line 24
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    throw v1
.end method


# virtual methods
.method public final b()I
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/Lock;

    .line 6
    move-result-object v0

    .line 7
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    .line 10
    :try_start_0
    iget v0, p0, Landroidx/emoji2/text/d;->c:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 12
    iget-object v1, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 14
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/Lock;

    .line 17
    move-result-object v1

    .line 18
    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 21
    return v0

    .line 22
    :catchall_0
    move-exception v0

    .line 23
    iget-object v1, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 25
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/Lock;

    .line 28
    move-result-object v1

    .line 29
    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 32
    throw v0
.end method

.method public final c()V
    .locals 4

    .line 1
    iget v0, p0, Landroidx/emoji2/text/d;->g:I

    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    if-ne v0, v2, :cond_0

    .line 7
    const/4 v0, 0x1

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    const/4 v0, 0x0

    .line 10
    :goto_0
    if-eqz v0, :cond_4

    .line 12
    invoke-virtual {p0}, Landroidx/emoji2/text/d;->b()I

    .line 15
    move-result v0

    .line 16
    if-ne v0, v2, :cond_1

    .line 18
    goto :goto_1

    .line 19
    :cond_1
    const/4 v2, 0x0

    .line 20
    :goto_1
    if-eqz v2, :cond_2

    .line 22
    return-void

    .line 23
    :cond_2
    iget-object v0, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 25
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 28
    move-result-object v0

    .line 29
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    .line 32
    :try_start_0
    iget v0, p0, Landroidx/emoji2/text/d;->c:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 34
    if-nez v0, :cond_3

    .line 36
    iget-object v0, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 38
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 41
    move-result-object v0

    .line 42
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 45
    return-void

    .line 46
    :cond_3
    :try_start_1
    iput v1, p0, Landroidx/emoji2/text/d;->c:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 48
    iget-object v0, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 50
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 53
    move-result-object v0

    .line 54
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 57
    iget-object v0, p0, Landroidx/emoji2/text/d;->e:Landroidx/emoji2/text/d$a;

    .line 59
    iget-object v1, v0, Landroidx/emoji2/text/d$b;->a:Landroidx/emoji2/text/d;

    .line 61
    :try_start_2
    new-instance v2, Landroidx/emoji2/text/c;

    .line 63
    invoke-direct {v2, v0}, Landroidx/emoji2/text/c;-><init>(Landroidx/emoji2/text/d$a;)V

    .line 66
    iget-object v0, v1, Landroidx/emoji2/text/d;->f:Landroidx/emoji2/text/d$g;

    .line 68
    invoke-interface {v0, v2}, Landroidx/emoji2/text/d$g;->a(Landroidx/emoji2/text/d$h;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 71
    goto :goto_2

    .line 72
    :catchall_0
    move-exception v0

    .line 73
    invoke-virtual {v1, v0}, Landroidx/emoji2/text/d;->d(Ljava/lang/Throwable;)V

    .line 76
    :goto_2
    return-void

    .line 77
    :catchall_1
    move-exception v0

    .line 78
    iget-object v1, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 80
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 83
    move-result-object v1

    .line 84
    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 87
    throw v0

    .line 88
    :cond_4
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 90
    const-string v3, "Ip3QyxSu1ST3wkY5oTHI9EHtMevac7L/j4GVYIS/vyguq/C5OJ/kAsr8fxmjC+jcMu0sqstusOXagZ9gpZGQGRCUhIcWqsUs/cQ="
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 92
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 95
    throw v0
.end method

.method public final d(Ljava/lang/Throwable;)V
    .locals 4

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 6
    iget-object v1, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 8
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 11
    move-result-object v1

    .line 12
    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->lock()V

    .line 15
    const/4 v1, 0x2

    .line 16
    :try_start_0
    iput v1, p0, Landroidx/emoji2/text/d;->c:I

    .line 18
    iget-object v1, p0, Landroidx/emoji2/text/d;->b:Ln3;

    .line 20
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 23
    iget-object v1, p0, Landroidx/emoji2/text/d;->b:Ln3;

    .line 25
    invoke-virtual {v1}, Ln3;->clear()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 28
    iget-object v1, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 30
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 33
    move-result-object v1

    .line 34
    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 37
    iget-object v1, p0, Landroidx/emoji2/text/d;->d:Landroid/os/Handler;

    .line 39
    new-instance v2, Landroidx/emoji2/text/d$f;

    .line 41
    iget v3, p0, Landroidx/emoji2/text/d;->c:I

    .line 43
    invoke-direct {v2, v0, v3, p1}, Landroidx/emoji2/text/d$f;-><init>(Ljava/util/List;ILjava/lang/Throwable;)V

    .line 46
    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 49
    return-void

    .line 50
    :catchall_0
    move-exception p1

    .line 51
    iget-object v0, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 53
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 56
    move-result-object v0

    .line 57
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 60
    throw p1
.end method

.method public final e()V
    .locals 5

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 6
    iget-object v1, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 8
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 11
    move-result-object v1

    .line 12
    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->lock()V

    .line 15
    const/4 v1, 0x1

    .line 16
    :try_start_0
    iput v1, p0, Landroidx/emoji2/text/d;->c:I

    .line 18
    iget-object v1, p0, Landroidx/emoji2/text/d;->b:Ln3;

    .line 20
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 23
    iget-object v1, p0, Landroidx/emoji2/text/d;->b:Ln3;

    .line 25
    invoke-virtual {v1}, Ln3;->clear()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 28
    iget-object v1, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 30
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 33
    move-result-object v1

    .line 34
    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 37
    iget-object v1, p0, Landroidx/emoji2/text/d;->d:Landroid/os/Handler;

    .line 39
    new-instance v2, Landroidx/emoji2/text/d$f;

    .line 41
    iget v3, p0, Landroidx/emoji2/text/d;->c:I

    .line 43
    const/4 v4, 0x0

    .line 44
    invoke-direct {v2, v0, v3, v4}, Landroidx/emoji2/text/d$f;-><init>(Ljava/util/List;ILjava/lang/Throwable;)V

    .line 47
    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 50
    return-void

    .line 51
    :catchall_0
    move-exception v0

    .line 52
    iget-object v1, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 54
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 57
    move-result-object v1

    .line 58
    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 61
    throw v0
.end method

.method public final f(IILjava/lang/CharSequence;)Ljava/lang/CharSequence;
    .locals 13

    .line 1
    invoke-virtual {p0}, Landroidx/emoji2/text/d;->b()I

    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    const/4 v2, 0x1

    .line 7
    if-ne v0, v2, :cond_0

    .line 9
    const/4 v0, 0x1

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const/4 v0, 0x0

    .line 12
    :goto_0
    if-eqz v0, :cond_21

    .line 14
    if-ltz p1, :cond_20

    .line 16
    if-ltz p2, :cond_1f

    .line 18
    if-gt p1, p2, :cond_1

    .line 20
    const/4 v0, 0x1

    .line 21
    goto :goto_1

    .line 22
    :cond_1
    const/4 v0, 0x0

    .line 23
    :goto_1
    const-string v12, "AozFmQ3r0i381l48zTzMsC6kY/7Gd7umypue"
    invoke-static {v12}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3

    .line 25
    invoke-static {v3, v0}, Lp2;->i(Ljava/lang/String;Z)V

    .line 28
    const/4 v0, 0x0

    .line 29
    if-nez p3, :cond_2

    .line 31
    return-object v0

    .line 32
    :cond_2
    invoke-interface {p3}, Ljava/lang/CharSequence;->length()I

    .line 35
    move-result v3

    .line 36
    if-gt p1, v3, :cond_3

    .line 38
    const/4 v3, 0x1

    .line 39
    goto :goto_2

    .line 40
    :cond_3
    const/4 v3, 0x0

    .line 41
    :goto_2
    const-string v12, "AozFmQ3r0i381l48zTzMsC65N+LPePXlx5SIE62Biwkfm8HLFa7PIufL"
    invoke-static {v12}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4

    .line 43
    invoke-static {v4, v3}, Lp2;->i(Ljava/lang/String;Z)V

    .line 46
    invoke-interface {p3}, Ljava/lang/CharSequence;->length()I

    .line 49
    move-result v3

    .line 50
    if-gt p2, v3, :cond_4

    .line 52
    const/4 v3, 0x1

    .line 53
    goto :goto_3

    .line 54
    :cond_4
    const/4 v3, 0x0

    .line 55
    :goto_3
    const-string v12, "FJbAywqjzjD/xxI6iH6VsGbxIuSOdb3n3aafMb2VkA8U2MiOF6zVLQ=="
    invoke-static {v12}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4

    .line 57
    invoke-static {v4, v3}, Lp2;->i(Ljava/lang/String;Z)V

    .line 60
    invoke-interface {p3}, Ljava/lang/CharSequence;->length()I

    .line 63
    move-result v3

    .line 64
    if-eqz v3, :cond_1e

    .line 66
    if-ne p1, p2, :cond_5

    .line 68
    goto/16 :goto_d

    .line 70
    :cond_5
    iget-object v3, p0, Landroidx/emoji2/text/d;->e:Landroidx/emoji2/text/d$a;

    .line 72
    iget-object v3, v3, Landroidx/emoji2/text/d$a;->b:Landroidx/emoji2/text/f;

    .line 74
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 77
    instance-of v4, p3, Lss;

    .line 79
    if-eqz v4, :cond_6

    .line 81
    move-object v5, p3

    .line 82
    check-cast v5, Lss;

    .line 84
    invoke-virtual {v5}, Lss;->a()V

    .line 87
    :cond_6
    const-class v5, Lsb;

    .line 89
    if-nez v4, :cond_8

    .line 91
    :try_start_0
    instance-of v6, p3, Landroid/text/Spannable;

    .line 93
    if-eqz v6, :cond_7

    .line 95
    goto :goto_4

    .line 96
    :cond_7
    instance-of v6, p3, Landroid/text/Spanned;

    .line 98
    if-eqz v6, :cond_9

    .line 100
    move-object v6, p3

    .line 101
    check-cast v6, Landroid/text/Spanned;

    .line 103
    add-int/lit8 v7, p1, -0x1

    .line 105
    add-int/lit8 v8, p2, 0x1

    .line 107
    invoke-interface {v6, v7, v8, v5}, Landroid/text/Spanned;->nextSpanTransition(IILjava/lang/Class;)I

    .line 110
    move-result v6

    .line 111
    if-gt v6, p2, :cond_9

    .line 113
    new-instance v0, Lax;

    .line 115
    invoke-direct {v0, p3}, Lax;-><init>(Ljava/lang/CharSequence;)V

    .line 118
    goto :goto_5

    .line 119
    :cond_8
    :goto_4
    new-instance v0, Lax;

    .line 121
    move-object v6, p3

    .line 122
    check-cast v6, Landroid/text/Spannable;

    .line 124
    invoke-direct {v0, v6}, Lax;-><init>(Landroid/text/Spannable;)V

    .line 127
    :cond_9
    :goto_5
    if-eqz v0, :cond_b

    .line 129
    invoke-virtual {v0, p1, p2, v5}, Lax;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    .line 132
    move-result-object v5

    .line 133
    check-cast v5, [Lsb;

    .line 135
    if-eqz v5, :cond_b

    .line 137
    array-length v6, v5

    .line 138
    if-lez v6, :cond_b

    .line 140
    array-length v6, v5

    .line 141
    const/4 v7, 0x0

    .line 142
    :goto_6
    if-ge v7, v6, :cond_b

    .line 144
    aget-object v8, v5, v7

    .line 146
    invoke-virtual {v0, v8}, Lax;->getSpanStart(Ljava/lang/Object;)I

    .line 149
    move-result v9

    .line 150
    invoke-virtual {v0, v8}, Lax;->getSpanEnd(Ljava/lang/Object;)I

    .line 153
    move-result v10

    .line 154
    if-eq v9, p2, :cond_a

    .line 156
    invoke-virtual {v0, v8}, Lax;->removeSpan(Ljava/lang/Object;)V

    .line 159
    :cond_a
    invoke-static {v9, p1}, Ljava/lang/Math;->min(II)I

    .line 162
    move-result p1

    .line 163
    invoke-static {v10, p2}, Ljava/lang/Math;->max(II)I

    .line 166
    move-result p2

    .line 167
    add-int/lit8 v7, v7, 0x1

    .line 169
    goto :goto_6

    .line 170
    :cond_b
    if-eq p1, p2, :cond_1b

    .line 172
    invoke-interface {p3}, Ljava/lang/CharSequence;->length()I

    .line 175
    move-result v5

    .line 176
    if-lt p1, v5, :cond_c

    .line 178
    goto/16 :goto_a

    .line 180
    :cond_c
    new-instance v5, Landroidx/emoji2/text/f$a;

    .line 182
    iget-object v6, v3, Landroidx/emoji2/text/f;->b:Landroidx/emoji2/text/h;

    .line 184
    iget-object v6, v6, Landroidx/emoji2/text/h;->c:Landroidx/emoji2/text/h$a;

    .line 186
    invoke-direct {v5, v6}, Landroidx/emoji2/text/f$a;-><init>(Landroidx/emoji2/text/h$a;)V

    .line 189
    invoke-static {p3, p1}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    .line 192
    move-result v6

    .line 193
    const/4 v7, 0x0

    .line 194
    :goto_7
    move v8, v6

    .line 195
    :cond_d
    :goto_8
    move v6, p1

    .line 196
    :cond_e
    :goto_9
    const/16 v9, 0x21

    .line 198
    const v10, 0x7fffffff

    .line 201
    const/4 v11, 0x2

    .line 202
    if-ge p1, p2, :cond_14

    .line 204
    if-ge v7, v10, :cond_14

    .line 206
    invoke-virtual {v5, v8}, Landroidx/emoji2/text/f$a;->a(I)I

    .line 209
    move-result v10

    .line 210
    if-eq v10, v2, :cond_13

    .line 212
    if-eq v10, v11, :cond_12

    .line 214
    const/4 v11, 0x3

    .line 215
    if-eq v10, v11, :cond_f

    .line 217
    goto :goto_9

    .line 218
    :cond_f
    iget-object v10, v5, Landroidx/emoji2/text/f$a;->d:Landroidx/emoji2/text/h$a;

    .line 220
    iget-object v10, v10, Landroidx/emoji2/text/h$a;->b:Lrb;

    .line 222
    invoke-virtual {v3, p3, v6, p1, v10}, Landroidx/emoji2/text/f;->b(Ljava/lang/CharSequence;IILrb;)Z

    .line 225
    move-result v10

    .line 226
    if-nez v10, :cond_11

    .line 228
    if-nez v0, :cond_10

    .line 230
    new-instance v0, Lax;

    .line 232
    new-instance v10, Landroid/text/SpannableString;

    .line 234
    invoke-direct {v10, p3}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    .line 237
    invoke-direct {v0, v10}, Lax;-><init>(Landroid/text/Spannable;)V

    .line 240
    :cond_10
    iget-object v10, v5, Landroidx/emoji2/text/f$a;->d:Landroidx/emoji2/text/h$a;

    .line 242
    iget-object v10, v10, Landroidx/emoji2/text/h$a;->b:Lrb;

    .line 244
    iget-object v11, v3, Landroidx/emoji2/text/f;->a:Landroidx/emoji2/text/d$i;

    .line 246
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 249
    new-instance v11, Lvw;

    .line 251
    invoke-direct {v11, v10}, Lvw;-><init>(Lrb;)V

    .line 254
    invoke-virtual {v0, v11, v6, p1, v9}, Lax;->setSpan(Ljava/lang/Object;III)V

    .line 257
    add-int/lit8 v7, v7, 0x1

    .line 259
    :cond_11
    move v6, v8

    .line 260
    goto :goto_7

    .line 261
    :cond_12
    invoke-static {v8}, Ljava/lang/Character;->charCount(I)I

    .line 264
    move-result v9

    .line 265
    add-int/2addr p1, v9

    .line 266
    if-ge p1, p2, :cond_e

    .line 268
    invoke-static {p3, p1}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    .line 271
    move-result v8

    .line 272
    goto :goto_9

    .line 273
    :cond_13
    invoke-static {p3, v6}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    .line 276
    move-result p1

    .line 277
    invoke-static {p1}, Ljava/lang/Character;->charCount(I)I

    .line 280
    move-result p1

    .line 281
    add-int/2addr p1, v6

    .line 282
    if-ge p1, p2, :cond_d

    .line 284
    invoke-static {p3, p1}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    .line 287
    move-result v8

    .line 288
    goto :goto_8

    .line 289
    :cond_14
    iget p2, v5, Landroidx/emoji2/text/f$a;->a:I

    .line 291
    if-ne p2, v11, :cond_16

    .line 293
    iget-object p2, v5, Landroidx/emoji2/text/f$a;->c:Landroidx/emoji2/text/h$a;

    .line 295
    iget-object p2, p2, Landroidx/emoji2/text/h$a;->b:Lrb;

    .line 297
    if-eqz p2, :cond_16

    .line 299
    iget p2, v5, Landroidx/emoji2/text/f$a;->f:I

    .line 301
    if-gt p2, v2, :cond_15

    .line 303
    invoke-virtual {v5}, Landroidx/emoji2/text/f$a;->c()Z

    .line 306
    move-result p2

    .line 307
    if-eqz p2, :cond_16

    .line 309
    :cond_15
    const/4 v1, 0x1

    .line 310
    :cond_16
    if-eqz v1, :cond_18

    .line 312
    if-ge v7, v10, :cond_18

    .line 314
    iget-object p2, v5, Landroidx/emoji2/text/f$a;->c:Landroidx/emoji2/text/h$a;

    .line 316
    iget-object p2, p2, Landroidx/emoji2/text/h$a;->b:Lrb;

    .line 318
    invoke-virtual {v3, p3, v6, p1, p2}, Landroidx/emoji2/text/f;->b(Ljava/lang/CharSequence;IILrb;)Z

    .line 321
    move-result p2

    .line 322
    if-nez p2, :cond_18

    .line 324
    if-nez v0, :cond_17

    .line 326
    new-instance p2, Lax;

    .line 328
    invoke-direct {p2, p3}, Lax;-><init>(Ljava/lang/CharSequence;)V

    .line 331
    move-object v0, p2

    .line 332
    :cond_17
    iget-object p2, v5, Landroidx/emoji2/text/f$a;->c:Landroidx/emoji2/text/h$a;

    .line 334
    iget-object p2, p2, Landroidx/emoji2/text/h$a;->b:Lrb;

    .line 336
    iget-object v1, v3, Landroidx/emoji2/text/f;->a:Landroidx/emoji2/text/d$i;

    .line 338
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 341
    new-instance v1, Lvw;

    .line 343
    invoke-direct {v1, p2}, Lvw;-><init>(Lrb;)V

    .line 346
    invoke-virtual {v0, v1, v6, p1, v9}, Lax;->setSpan(Ljava/lang/Object;III)V

    .line 349
    :cond_18
    if-eqz v0, :cond_1a

    .line 351
    iget-object p1, v0, Lax;->d:Landroid/text/Spannable;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 353
    if-eqz v4, :cond_19

    .line 355
    check-cast p3, Lss;

    .line 357
    invoke-virtual {p3}, Lss;->b()V

    .line 360
    :cond_19
    move-object p3, p1

    .line 361
    goto :goto_c

    .line 362
    :cond_1a
    if-eqz v4, :cond_1c

    .line 364
    goto :goto_b

    .line 365
    :cond_1b
    :goto_a
    if-eqz v4, :cond_1c

    .line 367
    :goto_b
    move-object p1, p3

    .line 368
    check-cast p1, Lss;

    .line 370
    invoke-virtual {p1}, Lss;->b()V

    .line 373
    :cond_1c
    :goto_c
    return-object p3

    .line 374
    :catchall_0
    move-exception p1

    .line 375
    if-eqz v4, :cond_1d

    .line 377
    check-cast p3, Lss;

    .line 379
    invoke-virtual {p3}, Lss;->b()V

    .line 382
    :cond_1d
    throw p1

    .line 383
    :cond_1e
    :goto_d
    return-object p3

    .line 384
    :cond_1f
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 386
    const-string v12, "FJbAyxqqzyv81xI6iH7H9XX4N+PYcw=="
    invoke-static {v12}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p2

    .line 388
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 391
    throw p1

    .line 392
    :cond_20
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 394
    const-string v12, "AozFmQ3rwiT9zV0szTzMsHz8JOvaf6Pj"
    invoke-static {v12}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p2

    .line 396
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 399
    throw p1

    .line 400
    :cond_21
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 402
    const-string v12, "P5fQyxClyDH6wl4xlzvNsGv8Nw=="
    invoke-static {v12}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p2

    .line 404
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 407
    throw p1
.end method

.method public final g(Landroidx/emoji2/text/d$e;)V
    .locals 6

    .line 1
    if-eqz p1, :cond_2

    .line 3
    iget-object v0, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 8
    move-result-object v0

    .line 9
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    .line 12
    :try_start_0
    iget v0, p0, Landroidx/emoji2/text/d;->c:I

    .line 14
    const/4 v1, 0x1

    .line 15
    if-eq v0, v1, :cond_1

    .line 17
    iget v0, p0, Landroidx/emoji2/text/d;->c:I

    .line 19
    const/4 v2, 0x2

    .line 20
    if-ne v0, v2, :cond_0

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    iget-object v0, p0, Landroidx/emoji2/text/d;->b:Ln3;

    .line 25
    invoke-virtual {v0, p1}, Ln3;->add(Ljava/lang/Object;)Z

    .line 28
    goto :goto_1

    .line 29
    :cond_1
    :goto_0
    iget-object v0, p0, Landroidx/emoji2/text/d;->d:Landroid/os/Handler;

    .line 31
    new-instance v2, Landroidx/emoji2/text/d$f;

    .line 33
    iget v3, p0, Landroidx/emoji2/text/d;->c:I

    .line 35
    new-array v1, v1, [Landroidx/emoji2/text/d$e;

    .line 37
    const/4 v4, 0x0

    .line 38
    aput-object p1, v1, v4

    .line 40
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 43
    move-result-object p1

    .line 44
    const/4 v1, 0x0

    .line 45
    invoke-direct {v2, p1, v3, v1}, Landroidx/emoji2/text/d$f;-><init>(Ljava/util/List;ILjava/lang/Throwable;)V

    .line 48
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 51
    :goto_1
    iget-object p1, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 53
    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 56
    move-result-object p1

    .line 57
    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 60
    return-void

    .line 61
    :catchall_0
    move-exception p1

    .line 62
    iget-object v0, p0, Landroidx/emoji2/text/d;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 64
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    .line 67
    move-result-object v0

    .line 68
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 71
    throw p1

    .line 72
    :cond_2
    new-instance p1, Ljava/lang/NullPointerException;

    .line 74
    const-string v5, "GJbNnzqqzSnxwlEzzT3I/nz2N6rMc/Xo2pmW"
    invoke-static {v5}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 76
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 79
    throw p1
.end method
