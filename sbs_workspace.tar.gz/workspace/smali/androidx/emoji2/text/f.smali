.class public final Landroidx/emoji2/text/f;
.super Ljava/lang/Object;
.source "LoaderManager96.java"

# verified-34560
# processed-14902
# ep-ftznrupruvkg

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/emoji2/text/f$a;
    }
.end annotation


# instance fields
.field public final a:Landroidx/emoji2/text/d$i;

.field public final b:Landroidx/emoji2/text/h;

.field public final c:Landroidx/emoji2/text/d$d;


# direct methods
.method public constructor <init>(Landroidx/emoji2/text/h;Landroidx/emoji2/text/d$i;Landroidx/emoji2/text/b;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p2, p0, Landroidx/emoji2/text/f;->a:Landroidx/emoji2/text/d$i;

    .line 6
    iput-object p1, p0, Landroidx/emoji2/text/f;->b:Landroidx/emoji2/text/h;

    .line 8
    iput-object p3, p0, Landroidx/emoji2/text/f;->c:Landroidx/emoji2/text/d$d;

    .line 10
    return-void
.end method

.method public static a(Landroid/text/Editable;Landroid/view/KeyEvent;Z)Z
    .locals 7

    .line 1
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getMetaState()I

    .line 4
    move-result p1

    .line 5
    invoke-static {p1}, Landroid/view/KeyEvent;->metaStateHasNoModifiers(I)Z

    .line 8
    move-result p1

    .line 9
    const/4 v0, 0x1

    .line 10
    xor-int/2addr p1, v0

    .line 11
    const/4 v1, 0x0

    .line 12
    if-eqz p1, :cond_0

    .line 14
    return v1

    .line 15
    :cond_0
    invoke-static {p0}, Landroid/text/Selection;->getSelectionStart(Ljava/lang/CharSequence;)I

    .line 18
    move-result p1

    .line 19
    invoke-static {p0}, Landroid/text/Selection;->getSelectionEnd(Ljava/lang/CharSequence;)I

    .line 22
    move-result v2

    .line 23
    const/4 v3, -0x1

    .line 24
    if-eq p1, v3, :cond_2

    .line 26
    if-eq v2, v3, :cond_2

    .line 28
    if-eq p1, v2, :cond_1

    .line 30
    goto :goto_0

    .line 31
    :cond_1
    const/4 v3, 0x0

    .line 32
    goto :goto_1

    .line 33
    :cond_2
    :goto_0
    const/4 v3, 0x1

    .line 34
    :goto_1
    if-eqz v3, :cond_3

    .line 36
    return v1

    .line 37
    :cond_3
    const-class v3, Lsb;

    .line 39
    invoke-interface {p0, p1, v2, v3}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    .line 42
    move-result-object v2

    .line 43
    check-cast v2, [Lsb;

    .line 45
    if-eqz v2, :cond_8

    .line 47
    array-length v3, v2

    .line 48
    if-lez v3, :cond_8

    .line 50
    array-length v3, v2

    .line 51
    const/4 v4, 0x0

    .line 52
    :goto_2
    if-ge v4, v3, :cond_8

    .line 54
    aget-object v5, v2, v4

    .line 56
    invoke-interface {p0, v5}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    .line 59
    move-result v6

    .line 60
    invoke-interface {p0, v5}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    .line 63
    move-result v5

    .line 64
    if-eqz p2, :cond_4

    .line 66
    if-eq v6, p1, :cond_6

    .line 68
    :cond_4
    if-nez p2, :cond_5

    .line 70
    if-eq v5, p1, :cond_6

    .line 72
    :cond_5
    if-le p1, v6, :cond_7

    .line 74
    if-ge p1, v5, :cond_7

    .line 76
    :cond_6
    invoke-interface {p0, v6, v5}, Landroid/text/Editable;->delete(II)Landroid/text/Editable;

    .line 79
    return v0

    .line 80
    :cond_7
    add-int/lit8 v4, v4, 0x1

    .line 82
    goto :goto_2

    .line 83
    :cond_8
    return v1
.end method


# virtual methods
.method public final b(Ljava/lang/CharSequence;IILrb;)Z
    .locals 9

    .line 1
    iget v0, p4, Lrb;->c:I

    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x1

    .line 6
    if-nez v0, :cond_d

    .line 8
    iget-object v0, p0, Landroidx/emoji2/text/f;->c:Landroidx/emoji2/text/d$d;

    .line 10
    invoke-virtual {p4}, Lrb;->c()Lpl;

    .line 13
    move-result-object v4

    .line 14
    const/16 v5, 0x8

    .line 16
    invoke-virtual {v4, v5}, Lju;->a(I)I

    .line 19
    move-result v5

    .line 20
    if-eqz v5, :cond_0

    .line 22
    iget-object v6, v4, Lju;->b:Ljava/nio/ByteBuffer;

    .line 24
    iget v4, v4, Lju;->a:I

    .line 26
    add-int/2addr v5, v4

    .line 27
    invoke-virtual {v6, v5}, Ljava/nio/ByteBuffer;->getShort(I)S

    .line 30
    move-result v4

    .line 31
    goto :goto_0

    .line 32
    :cond_0
    const/4 v4, 0x0

    .line 33
    :goto_0
    check-cast v0, Landroidx/emoji2/text/b;

    .line 35
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 38
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 40
    const/16 v6, 0x17

    .line 42
    if-ge v5, v6, :cond_1

    .line 44
    if-le v4, v5, :cond_1

    .line 46
    goto/16 :goto_3

    .line 48
    :cond_1
    sget-object v4, Landroidx/emoji2/text/b;->b:Ljava/lang/ThreadLocal;

    .line 50
    invoke-virtual {v4}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 53
    move-result-object v5

    .line 54
    if-nez v5, :cond_2

    .line 56
    new-instance v5, Ljava/lang/StringBuilder;

    .line 58
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 61
    invoke-virtual {v4, v5}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 64
    :cond_2
    invoke-virtual {v4}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 67
    move-result-object v4

    .line 68
    check-cast v4, Ljava/lang/StringBuilder;

    .line 70
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 73
    :goto_1
    if-ge p2, p3, :cond_3

    .line 75
    invoke-interface {p1, p2}, Ljava/lang/CharSequence;->charAt(I)C

    .line 78
    move-result v5

    .line 79
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 82
    add-int/lit8 p2, p2, 0x1

    .line 84
    goto :goto_1

    .line 85
    :cond_3
    iget-object p1, v0, Landroidx/emoji2/text/b;->a:Landroid/text/TextPaint;

    .line 87
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 90
    move-result-object p2

    .line 91
    sget-object p3, Lrn;->a:Ljava/lang/ThreadLocal;

    .line 93
    sget p3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 95
    if-lt p3, v6, :cond_4

    .line 97
    invoke-static {p1, p2}, Lrn$a;->a(Landroid/graphics/Paint;Ljava/lang/String;)Z

    .line 100
    move-result p1

    .line 101
    goto/16 :goto_6

    .line 103
    :cond_4
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 106
    move-result p3

    .line 107
    if-ne p3, v3, :cond_5

    .line 109
    invoke-virtual {p2, v2}, Ljava/lang/String;->charAt(I)C

    .line 112
    move-result v0

    .line 113
    invoke-static {v0}, Ljava/lang/Character;->isWhitespace(C)Z

    .line 116
    move-result v0

    .line 117
    if-eqz v0, :cond_5

    .line 119
    goto :goto_4

    .line 120
    :cond_5
    const-string v0, "\udb3f\udffd"

    .line 122
    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    .line 125
    move-result v4

    .line 126
    const-string v5, "m"

    .line 128
    invoke-virtual {p1, v5}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    .line 131
    move-result v5

    .line 132
    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    .line 135
    move-result v6

    .line 136
    const/4 v7, 0x0

    .line 137
    cmpl-float v8, v6, v7

    .line 139
    if-nez v8, :cond_6

    .line 141
    goto :goto_3

    .line 142
    :cond_6
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 145
    move-result v8

    .line 146
    invoke-virtual {p2, v2, v8}, Ljava/lang/String;->codePointCount(II)I

    .line 149
    move-result v8

    .line 150
    if-le v8, v3, :cond_9

    .line 152
    const/high16 v8, 0x40000000    # 2.0f

    .line 154
    mul-float v5, v5, v8

    .line 156
    cmpl-float v5, v6, v5

    .line 158
    if-lez v5, :cond_7

    .line 160
    goto :goto_3

    .line 161
    :cond_7
    const/4 v5, 0x0

    .line 162
    :goto_2
    if-ge v5, p3, :cond_8

    .line 164
    invoke-virtual {p2, v5}, Ljava/lang/String;->codePointAt(I)I

    .line 167
    move-result v8

    .line 168
    invoke-static {v8}, Ljava/lang/Character;->charCount(I)I

    .line 171
    move-result v8

    .line 172
    add-int/2addr v8, v5

    .line 173
    invoke-virtual {p1, p2, v5, v8}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;II)F

    .line 176
    move-result v5

    .line 177
    add-float/2addr v7, v5

    .line 178
    move v5, v8

    .line 179
    goto :goto_2

    .line 180
    :cond_8
    cmpl-float v5, v6, v7

    .line 182
    if-ltz v5, :cond_9

    .line 184
    :goto_3
    const/4 p1, 0x0

    .line 185
    goto :goto_6

    .line 186
    :cond_9
    cmpl-float v4, v6, v4

    .line 188
    if-eqz v4, :cond_a

    .line 190
    :goto_4
    const/4 p1, 0x1

    .line 191
    goto :goto_6

    .line 192
    :cond_a
    sget-object v4, Lrn;->a:Ljava/lang/ThreadLocal;

    .line 194
    invoke-virtual {v4}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 197
    move-result-object v5

    .line 198
    check-cast v5, Ltn;

    .line 200
    if-nez v5, :cond_b

    .line 202
    new-instance v5, Ltn;

    .line 204
    new-instance v6, Landroid/graphics/Rect;

    .line 206
    invoke-direct {v6}, Landroid/graphics/Rect;-><init>()V

    .line 209
    new-instance v7, Landroid/graphics/Rect;

    .line 211
    invoke-direct {v7}, Landroid/graphics/Rect;-><init>()V

    .line 214
    invoke-direct {v5, v6, v7}, Ltn;-><init>(Landroid/graphics/Rect;Landroid/graphics/Rect;)V

    .line 217
    invoke-virtual {v4, v5}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 220
    goto :goto_5

    .line 221
    :cond_b
    iget-object v4, v5, Ltn;->a:Ljava/lang/Object;

    .line 223
    check-cast v4, Landroid/graphics/Rect;

    .line 225
    invoke-virtual {v4}, Landroid/graphics/Rect;->setEmpty()V

    .line 228
    iget-object v4, v5, Ltn;->b:Ljava/lang/Object;

    .line 230
    check-cast v4, Landroid/graphics/Rect;

    .line 232
    invoke-virtual {v4}, Landroid/graphics/Rect;->setEmpty()V

    .line 235
    :goto_5
    iget-object v4, v5, Ltn;->a:Ljava/lang/Object;

    .line 237
    check-cast v4, Landroid/graphics/Rect;

    .line 239
    invoke-virtual {p1, v0, v2, v1, v4}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/String;IILandroid/graphics/Rect;)V

    .line 242
    iget-object v0, v5, Ltn;->b:Ljava/lang/Object;

    .line 244
    move-object v5, v0

    .line 245
    check-cast v5, Landroid/graphics/Rect;

    .line 247
    invoke-virtual {p1, p2, v2, p3, v5}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/String;IILandroid/graphics/Rect;)V

    .line 250
    invoke-virtual {v4, v0}, Landroid/graphics/Rect;->equals(Ljava/lang/Object;)Z

    .line 253
    move-result p1

    .line 254
    xor-int/2addr p1, v3

    .line 255
    :goto_6
    if-eqz p1, :cond_c

    .line 257
    const/4 p1, 0x2

    .line 258
    goto :goto_7

    .line 259
    :cond_c
    const/4 p1, 0x1

    .line 260
    :goto_7
    iput p1, p4, Lrb;->c:I

    .line 262
    :cond_d
    iget p1, p4, Lrb;->c:I

    .line 264
    if-ne p1, v1, :cond_e

    .line 266
    const/4 v2, 0x1

    .line 267
    :cond_e
    return v2
.end method
