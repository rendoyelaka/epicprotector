.class public final Landroidx/emoji2/text/g$a;
.super Ljava/lang/Object;
.source "ObserverFactory74.java"
# ep-gbyjiqpavztj
# optimised-75666
# processed-65743


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
