.class public final Landroidx/emoji2/text/g$a;
# binding-94788-builder
# binding-49750-context
# binding-72024-dispatcher
# network-68129-response
.super Ljava/lang/Object;
.source "HandlerFactory93.java"
# verified-56670
# processed-16970
# compiled-98004

# ep-deyifwlofyom

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
