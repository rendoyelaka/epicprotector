.class public final Landroidx/emoji2/text/g$a;
# ep-lmnlfoqadwdh
.super Ljava/lang/Object;
# validated-57500
# generated-29160
# validated-15525
.source "InputFactory32.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
