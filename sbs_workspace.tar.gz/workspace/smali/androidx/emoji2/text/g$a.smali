.class public final Landroidx/emoji2/text/g$a;
.super Ljava/lang/Object;
# processed-69248
# optimised-41159
# validated-83664
.source "vmijnmou.java"

# ep-gdpdmugxynfp

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
