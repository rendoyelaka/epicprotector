.class public final Landroidx/emoji2/text/b;
.super Ljava/lang/Object;
.source "SourceFile"
# validated-95979
# ep-anolhtpayrps

# interfaces
.implements Landroidx/emoji2/text/d$d;


# static fields
.field public static final b:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Ljava/lang/StringBuilder;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final a:Landroid/text/TextPaint;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/ThreadLocal;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_9g65qv5d
    goto :ep_s_9g65qv5d
    :ep_d_9g65qv5d
    nop
    :ep_s_9g65qv5d
    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_aw47qxxj
    goto :ep_s_aw47qxxj
    :ep_d_aw47qxxj
    nop
    :ep_s_aw47qxxj
    sput-object v0, Landroidx/emoji2/text/b;->b:Ljava/lang/ThreadLocal;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Landroid/text/TextPaint;

    .line 6
    invoke-direct {v0}, Landroid/text/TextPaint;-><init>()V

    .line 9
    iput-object v0, p0, Landroidx/emoji2/text/b;->a:Landroid/text/TextPaint;

    .line 11
    const/high16 v1, 0x41200000    # 10.0f

    .line 13
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 16
    return-void
.end method
