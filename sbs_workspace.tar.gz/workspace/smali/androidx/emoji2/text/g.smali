.class public final Landroidx/emoji2/text/g;
# ep-pvidesbguxxk
# verified-68200
.super Landroidx/emoji2/text/d$c;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/emoji2/text/g$a;,
        Landroidx/emoji2/text/g$b;
    }
.end annotation


# static fields
.field public static final d:Landroidx/emoji2/text/g$a;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Landroidx/emoji2/text/g$a;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_0qfiumr2
    goto :ep_s_0qfiumr2
    :ep_d_0qfiumr2
    nop
    :ep_s_0qfiumr2
    invoke-direct {v0}, Landroidx/emoji2/text/g$a;-><init>()V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_u7b5n4bw
    goto :ep_s_u7b5n4bw
    :ep_d_u7b5n4bw
    nop
    :ep_s_u7b5n4bw
    sput-object v0, Landroidx/emoji2/text/g;->d:Landroidx/emoji2/text/g$a;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Led;)V
    .locals 1

    new-instance v0, Landroidx/emoji2/text/g$b;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_mqcrdltl
    goto :ep_s_mqcrdltl
    :ep_d_mqcrdltl
    nop
    :ep_s_mqcrdltl
    invoke-direct {v0, p1, p2}, Landroidx/emoji2/text/g$b;-><init>(Landroid/content/Context;Led;)V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_hp7ggw0a
    goto :ep_s_hp7ggw0a
    :ep_d_hp7ggw0a
    nop
    :ep_s_hp7ggw0a
    invoke-direct {p0, v0}, Landroidx/emoji2/text/d$c;-><init>(Landroidx/emoji2/text/d$g;)V

    return-void
.end method
