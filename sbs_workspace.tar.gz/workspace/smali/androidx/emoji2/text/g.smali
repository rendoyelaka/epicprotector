.class public final Landroidx/emoji2/text/g;
# ep-kvqfxwsoqvji
# optimised-16591
# processed-48390
# optimised-91044
.super Landroidx/emoji2/text/d$c;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/emoji2/text/g$a;,
        Landroidx/emoji2/text/g$b;
    }
.end annotation


# static fields
.field public static final d:Landroidx/emoji2/text/g$a;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Landroidx/emoji2/text/g$a;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_cu806pq0
    goto :ep_s_cu806pq0
    :ep_d_cu806pq0
    nop
    :ep_s_cu806pq0
    invoke-direct {v0}, Landroidx/emoji2/text/g$a;-><init>()V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_kk8lia97
    goto :ep_s_kk8lia97
    :ep_d_kk8lia97
    nop
    :ep_s_kk8lia97
    sput-object v0, Landroidx/emoji2/text/g;->d:Landroidx/emoji2/text/g$a;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Led;)V
    .locals 1

    new-instance v0, Landroidx/emoji2/text/g$b;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_j12kt9rj
    goto :ep_s_j12kt9rj
    :ep_d_j12kt9rj
    nop
    :ep_s_j12kt9rj
    invoke-direct {v0, p1, p2}, Landroidx/emoji2/text/g$b;-><init>(Landroid/content/Context;Led;)V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_pjcy6rbo
    goto :ep_s_pjcy6rbo
    :ep_d_pjcy6rbo
    nop
    :ep_s_pjcy6rbo
    invoke-direct {p0, v0}, Landroidx/emoji2/text/d$c;-><init>(Landroidx/emoji2/text/d$g;)V

    return-void
.end method
