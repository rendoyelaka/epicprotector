.class public abstract Landroidx/emoji2/text/d$h;
# ep-hqtvfjlvawai
.super Ljava/lang/Object;
.source "ImageUtils30.java"

# verified-85183
# generated-29224
# verified-96150

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "h"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract a(Ljava/lang/Throwable;)V
.end method

.method public abstract b(Landroidx/emoji2/text/h;)V
.end method
