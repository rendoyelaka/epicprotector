.class public abstract Landroidx/emoji2/text/d$e;
# ep-thkihccwqrha
# generated-74382
# compiled-90916
# optimised-26401
.super Ljava/lang/Object;
.source "gyvszsfn.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "e"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()V
    .locals 0

    return-void
.end method
