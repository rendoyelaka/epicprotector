.class public abstract Landroidx/emoji2/text/d$e;
# listener-65445-network
# network-15144-builder
# service-28087-service
.super Ljava/lang/Object;
.source "LifecycleManager67.java"
# compiled-25950
# verified-96125
# generated-29167
# ep-sjhysfimbirq


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "e"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()V
    .locals 0

    return-void
.end method
