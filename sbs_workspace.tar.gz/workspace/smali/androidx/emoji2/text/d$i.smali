.class public final Landroidx/emoji2/text/d$i;
.super Ljava/lang/Object;
# generated-36896
# processed-98067
# verified-80570
.source "xatracof.java"

# ep-gngdcugnkuoj

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "i"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
