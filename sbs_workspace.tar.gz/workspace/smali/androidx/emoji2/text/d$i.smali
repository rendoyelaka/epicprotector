.class public final Landroidx/emoji2/text/d$i;
# ep-mzfsrlutuzqk
.super Ljava/lang/Object;
# verified-43735
# generated-19885
# validated-55739
.source "ewjphrkq.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "i"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
