.class public final Landroidx/emoji2/text/d$i;
# ep-yjsybwrtmxed
# compiled-74134
# validated-53915
# compiled-95812
.super Ljava/lang/Object;
.source "stsvpuui.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "i"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
