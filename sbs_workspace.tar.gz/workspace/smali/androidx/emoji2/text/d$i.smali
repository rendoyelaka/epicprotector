.class public final Landroidx/emoji2/text/d$i;
# adapter-74609-session
# fragment-75868-response
# request-17433-factory
# network-39092-fragment
.super Ljava/lang/Object;
.source "PermissionUtils88.java"
# ep-gyydreuajonn
# validated-58058
# optimised-98647
# generated-72398


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "i"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
