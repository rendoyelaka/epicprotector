.class public final Landroidx/emoji2/text/d$i;
# ep-mynwzdqvktaz
.super Ljava/lang/Object;
# verified-61698
# verified-29529
# compiled-48945
.source "ioezfuef.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "i"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
