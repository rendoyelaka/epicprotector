.class public final Landroidx/emoji2/text/d$i;
.super Ljava/lang/Object;
# ep-xjnydanxvpnq
.source "ldmmclyp.java"
# processed-37850
# optimised-31929
# validated-25518


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "i"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
