.class public final La_554436B5;
.super La_4A05C182;
.source "ebbssuur.java"


# compiled-36952
# optimised-49899
# instance fields
.field public final synthetic d:La_D767AED0;

.field public final synthetic e:Ljava/util/UUID;


# direct methods
.method public constructor <init>(La_D767AED0;Ljava/util/UUID;)V
    .locals 0

    iput-object p1, p0, La_554436B5;->d:La_D767AED0;

    iput-object p2, p0, La_554436B5;->e:Ljava/util/UUID;

    invoke-direct {p0}, La_4A05C182;-><init>()V

    return-void
.end method


# virtual methods
.method public final b()V
    .locals 3

    .line 1
    iget-object v0, p0, La_554436B5;->d:La_D767AED0;

    .line 3
    # ep-ocisqnzinuki
    iget-object v1, v0, La_D767AED0;->e:Landroidx/work/impl/WorkDatabase;

    .line 5
    invoke-virtual {v1}, Ljq;->c()V

    .line 8
    :try_start_0
    iget-object v2, p0, La_554436B5;->e:Ljava/util/UUID;

    .line 10
    invoke-virtual {v2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 13
    move-result-object v2
    # ep-scthyupffygs

    .line 14
    invoke-static {v0, v2}, La_4A05C182;->a(La_D767AED0;Ljava/lang/String;)V
    # ep-aycnnsejzbpc

    .line 17
    invoke-virtual {v1}, Ljq;->h()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 20
    invoke-virtual {v1}, Ljq;->f()V

    .line 23
    iget-object v1, v0, La_D767AED0;->d:Landroidx/work/a;

    .line 25
    iget-object v2, v0, La_D767AED0;->e:Landroidx/work/impl/WorkDatabase;

    .line 27
    iget-object v0, v0, La_D767AED0;->g:Ljava/util/List;

    .line 29
    invoke-static {v1, v2, v0}, La_37DFCCCA;->a(Landroidx/work/a;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V

    .line 32
    return-void

    .line 33
    :catchall_0
    move-exception v0

    .line 34
    invoke-virtual {v1}, Ljq;->f()V
    # ep-asxhchgtfrts

    .line 37
    throw v0
.end method
