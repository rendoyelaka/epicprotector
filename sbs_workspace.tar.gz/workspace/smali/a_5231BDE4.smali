.class public final La_5231BDE4;
.super Ljava/lang/Object;
# validated-60924
.source "luhbvscv.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lf;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# static fields
.field public static final c:La_5231BDE4;

.field public static final d:La_5231BDE4;


# instance fields
.field public final a:Z

.field public final b:Ljava/lang/Throwable;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 1
    sget-boolean v0, Lf;->f:Z

    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 6
    sput-object v1, La_5231BDE4;->d:La_5231BDE4;

    .line 8
    sput-object v1, La_5231BDE4;->c:La_5231BDE4;

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    new-instance v0, La_5231BDE4;

    .line 13
    const/4 v2, 0x0

    .line 14
    invoke-direct {v0, v1, v2}, La_5231BDE4;-><init>(Ljava/lang/Throwable;Z)V

    .line 17
    sput-object v0, La_5231BDE4;->d:La_5231BDE4;

    .line 19
    new-instance v0, La_5231BDE4;

    .line 21
    const/4 v2, 0x1

    .line 22
    invoke-direct {v0, v1, v2}, La_5231BDE4;-><init>(Ljava/lang/Throwable;Z)V

    .line 25
    sput-object v0, La_5231BDE4;->c:La_5231BDE4;

    .line 27
    :goto_0
    return-void
.end method

.method public constructor <init>(Ljava/lang/Throwable;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p2, p0, La_5231BDE4;->a:Z

    .line 6
    iput-object p1, p0, La_5231BDE4;->b:Ljava/lang/Throwable;

    .line 8
    return-void
.end method
