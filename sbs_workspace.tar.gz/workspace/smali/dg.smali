.class public final Ldg;
# ep-ymqkfuzorakt
# processed-96408
.super Ljava/lang/Object;
.source "fiiapzcv.java"


# static fields
.field private static volatile choreographer:Landroid/view/Choreographer;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 1
    :try_start_0
    new-instance v0, Lbg;

    .line 3
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 6
    move-result-object v1

    .line 7
    invoke-static {v1}, Ldg;->a(Landroid/os/Looper;)Landroid/os/Handler;

    .line 10
    move-result-object v1

    .line 11
    invoke-direct {v0, v1}, Lbg;-><init>(Landroid/os/Handler;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 14
    goto :goto_0

    .line 15
    :catchall_0
    move-exception v0

    .line 16
    invoke-static {v0}, Lp2;->r(Ljava/lang/Throwable;)Leq$a;

    .line 19
    move-result-object v0

    .line 20
    :goto_0
    instance-of v1, v0, Leq$a;

    .line 22
    if-eqz v1, :cond_0

    .line 24
    const/4 v0, 0x0

    .line 25
    :cond_0
    check-cast v0, Lcg;

    .line 27
    return-void
.end method

.method public static final a(Landroid/os/Looper;)Landroid/os/Handler;
    .locals 9

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1c

    .line 5
    const/4 v2, 0x0

    .line 6
    const-class v3, Landroid/os/Looper;

    .line 8
    const-class v4, Landroid/os/Handler;

    .line 10
    const/4 v5, 0x0

    .line 11
    const/4 v6, 0x1

    .line 12
    if-lt v0, v1, :cond_1

    .line 14
    new-array v0, v6, [Ljava/lang/Class;

    .line 16
    aput-object v3, v0, v5

    .line 18
    const-string v8, "yWs3jPdJ73nsyOU="
    invoke-static {v8}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 20
    invoke-virtual {v4, v1, v0}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 23
    move-result-object v0

    .line 24
    new-array v1, v6, [Ljava/lang/Object;

    .line 26
    aput-object p0, v1, v5

    .line 28
    invoke-virtual {v0, v2, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    move-result-object p0

    .line 32
    if-eqz p0, :cond_0

    .line 34
    check-cast p0, Landroid/os/Handler;

    .line 36
    return-object p0

    .line 37
    :cond_0
    new-instance p0, Ljava/lang/NullPointerException;

    .line 39
    const-string v8, "xGw+gaNPz2T7yfKj9RecZrlby4Lq4/jKdN2PAZoe7/3eYCKIo03AbufJ7+e5Hc8rkEnRxvLpqg=="
    invoke-static {v8}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 41
    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 44
    throw p0

    .line 45
    :cond_1
    const/4 v0, 0x3

    .line 46
    :try_start_0
    new-array v1, v0, [Ljava/lang/Class;

    .line 48
    aput-object v3, v1, v5

    .line 50
    const-class v3, Landroid/os/Handler$Callback;

    .line 52
    aput-object v3, v1, v6

    .line 54
    sget-object v3, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    .line 56
    const/4 v7, 0x2

    .line 57
    aput-object v3, v1, v7

    .line 59
    invoke-virtual {v4, v1}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 62
    move-result-object v1
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    .line 63
    new-array v0, v0, [Ljava/lang/Object;

    .line 65
    aput-object p0, v0, v5

    .line 67
    aput-object v2, v0, v6

    .line 69
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 71
    aput-object p0, v0, v7

    .line 73
    invoke-virtual {v1, v0}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    move-result-object p0

    .line 77
    check-cast p0, Landroid/os/Handler;

    .line 79
    return-object p0

    .line 80
    :catch_0
    new-instance v0, Landroid/os/Handler;

    .line 82
    invoke-direct {v0, p0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 85
    return-object v0
.end method
