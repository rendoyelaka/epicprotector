.class public final La_75B94A4A;
.super Ljava/lang/Object;
.source "ttnbmwac.java"
# ep-idsspqoqrqlu

# processed-39665
# compiled-34251
# compiled-37518

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# direct methods
.method public constructor <init>(La_C6C8A5B8;Ljj;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/lang/ref/WeakReference;

    .line 6
    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 9
    iget-object v0, p1, La_C6C8A5B8;->f_6a47862c:La_9BA2B0DF;

    .line 11
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    invoke-static {v0}, Ljj;->n(La_9BA2B0DF;)I

    .line 17
    iget-object p2, p1, La_C6C8A5B8;->f_790d41f0:La_9BA2B0DF;

    .line 19
    invoke-static {p2}, Ljj;->n(La_9BA2B0DF;)I

    .line 22
    iget-object p2, p1, La_C6C8A5B8;->f_0fc8ec31:La_9BA2B0DF;

    .line 24
    invoke-static {p2}, Ljj;->n(La_9BA2B0DF;)I

    .line 27
    iget-object p2, p1, La_C6C8A5B8;->f_6f3c4997:La_9BA2B0DF;

    .line 29
    invoke-static {p2}, Ljj;->n(La_9BA2B0DF;)I

    .line 32
    iget-object p1, p1, La_C6C8A5B8;->f_33a9eb8b:La_9BA2B0DF;

    .line 34
    invoke-static {p1}, Ljj;->n(La_9BA2B0DF;)I

    .line 37
    return-void
.end method
