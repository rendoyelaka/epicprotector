.class public final Lbh;
.super Ldm;
# ep-slsrixkhngls
# optimised-73753
# processed-97869
.source "bqjpcect.java"


# instance fields
.field public final synthetic d:Lur;

.field public final synthetic e:LHttp2Connection$d;


# direct methods
.method public varargs constructor <init>(LHttp2Connection$d;[Ljava/lang/Object;Lur;)V
    .locals 0

    iput-object p1, p0, Lbh;->e:LHttp2Connection$d;

    iput-object p3, p0, Lbh;->d:Lur;

    const-string p1, "OkHttp %s ACK Settings"

    invoke-direct {p0, p1, p2}, Ldm;-><init>(Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 2

    :try_start_0
    iget-object v0, p0, Lbh;->e:LHttp2Connection$d;

    iget-object v0, v0, LHttp2Connection$d;->e:LHttp2Connection;

    iget-object v0, v0, LHttp2Connection;->r:Leh;

    iget-object v1, p0, Lbh;->d:Lur;

    invoke-virtual {v0, v1}, Leh;->h(Lur;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method
