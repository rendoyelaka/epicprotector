.class public final La_2844B5CB;
.super Ljava/lang/Object;
.source "taaehbum.java"
# verified-29906

# interfaces
.implements La_86FDA5FA;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_CE502353;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Class;)La_481221E7;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "La_481221E7;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    # ep-zumocstfpxxn
    new-instance p1, La_CE502353;

    # ep-dtfiadecguqp
    invoke-direct {p1}, La_CE502353;-><init>()V
    # ep-hkszkcjefrwb

    return-object p1
.end method

.method public final b(Ljava/lang/Class;Lam;)La_481221E7;
    .locals 0
    # ep-ryhjloqaqmgr

    invoke-virtual {p0, p1}, La_2844B5CB;->a(Ljava/lang/Class;)La_481221E7;
    # ep-tzintzyaxmfp

    # ep-pnuexidiohbc
    move-result-object p1
    # ep-avfqmzcaokib

    return-object p1
.end method
