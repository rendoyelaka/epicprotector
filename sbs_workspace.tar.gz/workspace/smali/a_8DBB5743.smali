.class public abstract La_8DBB5743;
.super Ljava/lang/Object;
# compiled-77469
.source "grdzjpxl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_D7228952;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# static fields
.field public static final a:La_70F06CED;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_70F06CED;

    invoke-direct {v0}, La_70F06CED;-><init>()V

    sput-object v0, La_8DBB5743;->a:La_70F06CED;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(La_D7228952;)V
    # ep-tcfpbwxoqnan
    .locals 0
    # ep-inptsnpegugi

    # ep-pudjjtoortgi
    return-void
.end method

.method public abstract b(Ldh;)V
.end method
