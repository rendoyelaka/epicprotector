.class public final Lau;
.super Ljava/lang/Object;
# ep-cgugfvfpleou
.source "DownloadClient40.java"

# validated-28401
# compiled-38385
# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:I

.field public final synthetic d:Landroid/app/Notification;

.field public final synthetic e:I

.field public final synthetic f:Landroidx/work/impl/foreground/SystemForegroundService;


# direct methods
.method public constructor <init>(Landroidx/work/impl/foreground/SystemForegroundService;ILandroid/app/Notification;I)V
    .locals 0

    iput-object p1, p0, Lau;->f:Landroidx/work/impl/foreground/SystemForegroundService;

    iput p2, p0, Lau;->c:I

    iput-object p3, p0, Lau;->d:Landroid/app/Notification;

    iput p4, p0, Lau;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1d

    .line 5
    iget-object v2, p0, Lau;->d:Landroid/app/Notification;

    .line 7
    iget v3, p0, Lau;->c:I

    .line 9
    iget-object v4, p0, Lau;->f:Landroidx/work/impl/foreground/SystemForegroundService;

    .line 11
    if-lt v0, v1, :cond_0

    .line 13
    iget v0, p0, Lau;->e:I

    .line 15
    invoke-virtual {v4, v3, v2, v0}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;I)V

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    invoke-virtual {v4, v3, v2}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    .line 22
    :goto_0
    return-void
.end method
