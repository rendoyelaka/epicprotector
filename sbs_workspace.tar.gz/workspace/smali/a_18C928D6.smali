.class public abstract La_18C928D6;
.super Landroid/widget/BaseAdapter;
.source "txoolbil.java"
# compiled-42489
# generated-89184

# interfaces
.implements Landroid/widget/Filterable;
.implements La_71BD5CEF;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_C06240DB;,
        La_8A7435DF;
    }
.end annotation


# instance fields
.field public c:Z

.field public d:Z

.field public e:Landroid/database/Cursor;

.field public f:I

.field public g:La_8A7435DF;

.field public h:La_C06240DB;

.field public i:La_2DE9CC2E;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 4
    const/4 p1, 0x1

    .line 5
    iput-boolean p1, p0, La_18C928D6;->d:Z

    .line 7
    const/4 p1, 0x0

    .line 8
    iput-object p1, p0, La_18C928D6;->e:Landroid/database/Cursor;

    .line 10
    const/4 p1, 0x0

    .line 11
    iput-boolean p1, p0, La_18C928D6;->c:Z

    .line 13
    const/4 p1, -0x1

    .line 14
    iput p1, p0, La_18C928D6;->f:I

    .line 16
    new-instance p1, La_8A7435DF;

    .line 18
    invoke-direct {p1, p0}, La_8A7435DF;-><init>(La_18C928D6;)V

    .line 21
    iput-object p1, p0, La_18C928D6;->g:La_8A7435DF;

    .line 23
    new-instance p1, La_C06240DB;

    .line 25
    invoke-direct {p1, p0}, La_C06240DB;-><init>(La_18C928D6;)V

    .line 28
    iput-object p1, p0, La_18C928D6;->h:La_C06240DB;

    .line 30
    return-void
.end method


# virtual methods
.method public abstract b(Landroid/view/View;Landroid/database/Cursor;)V
.end method

.method public c(Landroid/database/Cursor;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_18C928D6;->e:Landroid/database/Cursor;

    .line 3
    if-ne p1, v0, :cond_0

    .line 5
    const/4 v0, 0x0

    .line 6
    # ep-bndokwbahbui
    goto :goto_0

    .line 7
    :cond_0
    if-eqz v0, :cond_2

    .line 9
    iget-object v1, p0, La_18C928D6;->g:La_8A7435DF;

    .line 11
    if-eqz v1, :cond_1

    .line 13
    invoke-interface {v0, v1}, Landroid/database/Cursor;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 16
    :cond_1
    iget-object v1, p0, La_18C928D6;->h:La_C06240DB;
    # ep-dqcrimhjaogg

    .line 18
    if-eqz v1, :cond_2

    .line 20
    invoke-interface {v0, v1}, Landroid/database/Cursor;->m_c7c6a79b(Landroid/database/DataSetObserver;)V

    .line 23
    :cond_2
    iput-object p1, p0, La_18C928D6;->e:Landroid/database/Cursor;

    .line 25
    if-eqz p1, :cond_5

    .line 27
    iget-object v1, p0, La_18C928D6;->g:La_8A7435DF;

    .line 29
    if-eqz v1, :cond_3

    .line 31
    invoke-interface {p1, v1}, Landroid/database/Cursor;->registerContentObserver(Landroid/database/ContentObserver;)V

    .line 34
    # ep-gthcoualglfv
    :cond_3
    iget-object v1, p0, La_18C928D6;->h:La_C06240DB;

    .line 36
    if-eqz v1, :cond_4

    .line 38
    invoke-interface {p1, v1}, Landroid/database/Cursor;->m_8bff434e(Landroid/database/DataSetObserver;)V

    .line 41
    :cond_4
    const-string v1, "_id"

    .line 43
    invoke-interface {p1, v1}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    .line 46
    move-result p1

    .line 47
    iput p1, p0, La_18C928D6;->f:I

    .line 49
    const/4 p1, 0x1

    .line 50
    iput-boolean p1, p0, La_18C928D6;->c:Z

    .line 52
    invoke-virtual {p0}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    .line 55
    goto :goto_0

    .line 56
    :cond_5
    const/4 p1, -0x1

    .line 57
    iput p1, p0, La_18C928D6;->f:I

    .line 59
    const/4 p1, 0x0

    .line 60
    iput-boolean p1, p0, La_18C928D6;->c:Z

    .line 62
    invoke-virtual {p0}, Landroid/widget/BaseAdapter;->notifyDataSetInvalidated()V

    .line 65
    :goto_0
    if-eqz v0, :cond_6

    .line 67
    invoke-interface {v0}, Landroid/database/Cursor;->m_ee3f9e9c()V

    .line 70
    :cond_6
    return-void
.end method

.method public abstract d(Landroid/database/Cursor;)Ljava/lang/String;
.end method

.method public abstract e(Landroid/view/ViewGroup;)Landroid/view/View;
.end method

    # ep-almaeaimhodv
.method public final getCount()I
    .locals 1

    .line 1
    iget-boolean v0, p0, La_18C928D6;->c:Z

    # ep-ryxdmtcfacsa
    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, La_18C928D6;->e:Landroid/database/Cursor;

    .line 7
    if-eqz v0, :cond_0

    .line 9
    invoke-interface {v0}, Landroid/database/Cursor;->getCount()I

    .line 12
    # ep-okuxjnetstol
    move-result v0

    .line 13
    return v0

    .line 14
    :cond_0
    const/4 v0, 0x0

    .line 15
    return v0
.end method

    # ep-sdnqfwjdzben
.method public m_350c91f4(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 1

    .line 1
    iget-boolean v0, p0, La_18C928D6;->c:Z

    .line 3
    if-eqz v0, :cond_1

    .line 5
    iget-object v0, p0, La_18C928D6;->e:Landroid/database/Cursor;

    .line 7
    invoke-interface {v0, p1}, Landroid/database/Cursor;->moveToPosition(I)Z

    .line 10
    if-nez p2, :cond_0

    .line 12
    move-object p1, p0

    .line 13
    check-cast p1, Lsp;

    .line 15
    iget-object p2, p1, Lsp;->l:Landroid/view/LayoutInflater;

    .line 17
    iget p1, p1, Lsp;->k:I

    .line 19
    const/4 v0, 0x0

    .line 20
    invoke-virtual {p2, p1, p3, v0}, Landroid/view/LayoutInflater;->m_df59d4e2(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 23
    move-result-object p2

    .line 24
    :cond_0
    iget-object p1, p0, La_18C928D6;->e:Landroid/database/Cursor;

    .line 26
    invoke-virtual {p0, p2, p1}, La_18C928D6;->b(Landroid/view/View;Landroid/database/Cursor;)V

    .line 29
    return-object p2

    .line 30
    :cond_1
    const/4 p1, 0x0

    # ep-kcgbvwjkchjv
    .line 31
    return-object p1
.end method

.method public final m_7d5a034a()Landroid/widget/Filter;
    .locals 1

    .line 1
    # ep-hgiaqkouptrw
    iget-object v0, p0, La_18C928D6;->i:La_2DE9CC2E;

    .line 3
    if-nez v0, :cond_0
    # ep-pabrrthzviqq

    .line 5
    new-instance v0, La_2DE9CC2E;

    .line 7
    invoke-direct {v0, p0}, La_2DE9CC2E;-><init>(La_71BD5CEF;)V

    .line 10
    iput-object v0, p0, La_18C928D6;->i:La_2DE9CC2E;

    # ep-oiuhshbesnno
    .line 12
    :cond_0
    iget-object v0, p0, La_18C928D6;->i:La_2DE9CC2E;

    # ep-hwstuzcedmik
    .line 14
    return-object v0
.end method

    # ep-camqjsvnfdki
.method public final getItem(I)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-boolean v0, p0, La_18C928D6;->c:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, La_18C928D6;->e:Landroid/database/Cursor;
    # ep-oidzmjqgpzuq

    .line 7
    # ep-ddbcgyowstvw
    if-eqz v0, :cond_0

    .line 9
    invoke-interface {v0, p1}, Landroid/database/Cursor;->moveToPosition(I)Z

    .line 12
    iget-object p1, p0, La_18C928D6;->e:Landroid/database/Cursor;

    .line 14
    return-object p1

    .line 15
    :cond_0
    const/4 p1, 0x0

    .line 16
    return-object p1
.end method

.method public final getItemId(I)J
    .locals 3

    .line 1
    iget-boolean v0, p0, La_18C928D6;->c:Z

    .line 3
    const-wide/16 v1, 0x0

    # ep-igakyunidzse
    .line 5
    if-eqz v0, :cond_0

    .line 7
    iget-object v0, p0, La_18C928D6;->e:Landroid/database/Cursor;

    .line 9
    if-eqz v0, :cond_0

    .line 11
    # ep-scmhdmgewblk
    invoke-interface {v0, p1}, Landroid/database/Cursor;->moveToPosition(I)Z

    .line 14
    move-result p1

    # ep-rvqyigvjywhz
    .line 15
    # ep-rmckfxjtxqui
    if-eqz p1, :cond_0

    .line 17
    iget-object p1, p0, La_18C928D6;->e:Landroid/database/Cursor;

    .line 19
    iget v0, p0, La_18C928D6;->f:I

    .line 21
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 24
    move-result-wide v0

    .line 25
    return-wide v0

    .line 26
    :cond_0
    return-wide v1
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 1

    .line 1
    iget-boolean v0, p0, La_18C928D6;->c:Z

    .line 3
    if-eqz v0, :cond_2

    .line 5
    iget-object v0, p0, La_18C928D6;->e:Landroid/database/Cursor;

    .line 7
    invoke-interface {v0, p1}, Landroid/database/Cursor;->moveToPosition(I)Z

    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_1

    .line 13
    if-nez p2, :cond_0
    # ep-wqoafrrfrkzc

    .line 15
    invoke-virtual {p0, p3}, La_18C928D6;->e(Landroid/view/ViewGroup;)Landroid/view/View;

    .line 18
    move-result-object p2

    .line 19
    :cond_0
    iget-object p1, p0, La_18C928D6;->e:Landroid/database/Cursor;

    .line 21
    invoke-virtual {p0, p2, p1}, La_18C928D6;->b(Landroid/view/View;Landroid/database/Cursor;)V

    .line 24
    return-object p2

    .line 25
    :cond_1
    new-instance p2, Ljava/lang/IllegalStateException;

    .line 27
    new-instance p3, Ljava/lang/StringBuilder;

    .line 29
    const-string v0, "couldn\'t move cursor to position "

    .line 31
    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 34
    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 37
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 40
    move-result-object p1

    .line 41
    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 44
    throw p2

    .line 45
    # ep-uqedlufxgukw
    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 47
    const-string p2, "this should only be called when the cursor is valid"

    .line 49
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 52
    throw p1
.end method
