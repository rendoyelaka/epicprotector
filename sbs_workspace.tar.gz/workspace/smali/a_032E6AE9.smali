.class public final La_032E6AE9;
.super Lcs;
# ep-sbpdlwnpoaly
.source "jraukfxr.java"

# verified-10281
# optimised-18357
# validated-11654

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lfu;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "DELETE FROM SystemIdInfo where work_spec_id=?"

    return-object v0
.end method
