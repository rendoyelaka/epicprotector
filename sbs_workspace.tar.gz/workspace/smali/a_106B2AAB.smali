.class public final La_106B2AAB;
.super La_EDFD37DC;
# compiled-35508
# optimised-72655
.source "dbpkfbpa.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "e"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_EDFD37DC;-><init>()V

    return-void
.end method
