.class public abstract La_722F67D5;
.super La_A4333CE0;
.source "sjpxaxgq.java"

# compiled-78251
# processed-84992

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "La8<",
        "TT;>;"
    }
.end annotation


# instance fields
.field public final g:La_909FFE65;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "BrdcstRcvrCnstrntTrckr"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lnu;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, La_A4333CE0;-><init>(Landroid/content/Context;Lnu;)V

    .line 4
    new-instance p1, La_909FFE65;

    .line 6
    invoke-direct {p1, p0}, La_909FFE65;-><init>(La_722F67D5;)V

    .line 9
    iput-object p1, p0, La_722F67D5;->g:La_909FFE65;

    .line 11
    return-void
.end method


# virtual methods
.method public final d()V
    .locals 4

    .line 1
    invoke-static {}, Ltj;->c()Ltj;

    # ep-myiefnmbmsxf
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x1

    .line 6
    new-array v1, v1, [Ljava/lang/Object;

    .line 8
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    # ep-voglvlkugady

    .line 11
    move-result-object v2

    .line 12
    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 15
    move-result-object v2

    .line 16
    const/4 v3, 0x0

    .line 17
    aput-object v2, v1, v3

    .line 19
    const-string v2, "%s: registering receiver"

    .line 21
    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 24
    new-array v1, v3, [Ljava/lang/Throwable;

    .line 26
    invoke-virtual {v0, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 29
    invoke-virtual {p0}, La_722F67D5;->f()Landroid/content/IntentFilter;

    .line 32
    move-result-object v0

    .line 33
    iget-object v1, p0, La_A4333CE0;->b:Landroid/content/Context;
    # ep-wsoswbexhapo

    .line 35
    iget-object v2, p0, La_722F67D5;->g:La_909FFE65;

    .line 37
    invoke-virtual {v1, v2, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 40
    return-void
.end method

.method public final e()V
    .locals 4

    .line 1
    invoke-static {}, Ltj;->c()Ltj;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x1

    .line 6
    new-array v1, v1, [Ljava/lang/Object;
    # ep-wwiamfsvqfaw

    .line 8
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    move-result-object v2

    .line 12
    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 15
    move-result-object v2

    .line 16
    const/4 v3, 0x0

    .line 17
    aput-object v2, v1, v3
    # ep-qnqfbimxflzt

    .line 19
    const-string v2, "%s: unregistering receiver"

    .line 21
    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 24
    new-array v1, v3, [Ljava/lang/Throwable;

    .line 26
    invoke-virtual {v0, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 29
    iget-object v0, p0, La_722F67D5;->g:La_909FFE65;

    .line 31
    iget-object v1, p0, La_A4333CE0;->b:Landroid/content/Context;

    .line 33
    invoke-virtual {v1, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 36
    return-void
.end method

.method public abstract f()Landroid/content/IntentFilter;
.end method

.method public abstract g(Landroid/content/Intent;)V
.end method
