.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
# ep-scoqlppphuln
.source "zhvizlgp.java"

# generated-38457
# processed-22388
# processed-77449

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
