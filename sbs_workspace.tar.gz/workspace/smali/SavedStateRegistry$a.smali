.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
# ep-khrleozdyyho
# verified-35564
# validated-15050
.source "iczckfhw.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
