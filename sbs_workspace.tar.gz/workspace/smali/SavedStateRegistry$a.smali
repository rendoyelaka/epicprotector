.class public interface abstract LSavedStateRegistry$a;
# ep-xdznvxdniwjl
# optimised-78578
.super Ljava/lang/Object;
.source "dhckyzgz.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
