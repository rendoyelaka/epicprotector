.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
.source "slsekuux.java"

# validated-76890
# optimised-88044
# ep-ywtvnabiouua

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
