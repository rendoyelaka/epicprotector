.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
.source "rbqlomnx.java"
# validated-82075
# validated-13743
# validated-33350
# ep-ixauwopdvyid


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
