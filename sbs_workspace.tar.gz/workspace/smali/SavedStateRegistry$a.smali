.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
.source "xmlltyut.java"

# ep-lrvggbliqxvl
# optimised-22819

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
