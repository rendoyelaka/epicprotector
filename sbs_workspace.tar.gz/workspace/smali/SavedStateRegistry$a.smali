.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
# processed-65236
# validated-48668
# generated-75025
# ep-uqbtzjuimdhr
.source "NetworkUtils98.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
