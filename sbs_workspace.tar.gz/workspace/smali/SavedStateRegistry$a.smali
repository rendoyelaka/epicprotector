.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
.source "dydoaajx.java"
# generated-20448
# validated-20290
# verified-11577
# ep-dqnydkodmanr


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
