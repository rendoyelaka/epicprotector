.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
.source "ihitupum.java"
# processed-91495
# processed-55692

# ep-czyxsfzeqvdr

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
