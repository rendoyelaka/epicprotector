.class public interface abstract LSavedStateRegistry$a;
# utils-95195-binding
# observer-43560-loader
# factory-57404-provider
# callback-87950-loader
# request-34377-layout
.super Ljava/lang/Object;
.source "IntentUtils85.java"
# compiled-53917

# ep-vjvlzsxngefs

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
