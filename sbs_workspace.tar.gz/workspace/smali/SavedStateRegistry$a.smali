.class public interface abstract LSavedStateRegistry$a;
# ep-jiauzcceqzco
.super Ljava/lang/Object;
.source "evwcrkkm.java"
# verified-56383


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
