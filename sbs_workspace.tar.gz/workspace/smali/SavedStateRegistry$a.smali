.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
.source "CameraUtils40.java"
# verified-82893
# compiled-88162
# verified-81003
# ep-fsytqgmpiklz


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
