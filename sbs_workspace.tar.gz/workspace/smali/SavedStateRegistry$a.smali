.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
.source "NetworkManager71.java"
# verified-21154
# validated-78451

# ep-artvcfoahngt

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
