.class public interface abstract LSavedStateRegistry$a;
# ep-dozoyinvbxsl
.super Ljava/lang/Object;
.source "jggdoxec.java"
# generated-36815
# verified-80691
# optimised-75922


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
