.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
# validated-24464
# verified-97463
# validated-80768
.source "vdasvymj.java"
# ep-xptzqbfggujf


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
