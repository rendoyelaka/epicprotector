.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
.source "EventManager32.java"
# generated-12020
# verified-29107
# ep-ikixmdidzmwe


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
