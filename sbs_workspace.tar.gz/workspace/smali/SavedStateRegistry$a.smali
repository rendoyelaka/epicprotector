.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
.source "bdcljlzk.java"

# processed-85291
# optimised-65481
# verified-35831
# ep-lxdtqxdrarxb

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
