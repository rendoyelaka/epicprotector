.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
# ep-dkplpsnlojln
.source "vjygwtot.java"

# validated-81015
# generated-41188

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
