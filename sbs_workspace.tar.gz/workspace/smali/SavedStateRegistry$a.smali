.class public interface abstract LSavedStateRegistry$a;
# ep-qjshbrmilznw
.super Ljava/lang/Object;
# compiled-44904
# processed-56040
.source "xcviecje.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
