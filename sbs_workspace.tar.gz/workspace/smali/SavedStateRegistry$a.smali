.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
.source "zzuibsxj.java"
# ep-dgxilivvdqsi
# processed-34196
# processed-68707
# optimised-97717


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
