.class public interface abstract LSavedStateRegistry$a;
# ep-dyccnrvszxij
# compiled-62298
# verified-32320
.super Ljava/lang/Object;
.source "IntentBuilder75.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
