.class public interface abstract LSavedStateRegistry$a;
# ep-djijlhpymucf
.super Ljava/lang/Object;
# generated-35864
.source "cwpkyutg.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
