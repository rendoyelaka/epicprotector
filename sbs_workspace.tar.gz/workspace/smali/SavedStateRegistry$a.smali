.class public interface abstract LSavedStateRegistry$a;
.super Ljava/lang/Object;
.source "StateFactory13.java"
# ep-oxijmdmmoukd

# validated-39033
# validated-61575
# processed-36802

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LSavedStateRegistry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
