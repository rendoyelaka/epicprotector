.class public final La_439B0993;
.super Ljava/lang/Object;
.source "zbcrgvjm.java"
# generated-57467


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lsy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public final a:I

.field public final b:I

.field public final c:I


# direct methods
.method public constructor <init>(IIII)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, La_439B0993;->a:I

    .line 6
    iput p3, p0, La_439B0993;->b:I

    .line 8
    iput p4, p0, La_439B0993;->c:I

    .line 10
    return-void
.end method
