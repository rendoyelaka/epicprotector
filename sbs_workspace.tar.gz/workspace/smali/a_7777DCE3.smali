.class public abstract La_7777DCE3;
.super La_024E0079;
# processed-95408
.source "hpiwfenk.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_024E0079;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract s()La_7777DCE3;
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 1
    sget-object v0, Loa;->a:La_70F97D0E;

    .line 3
    sget-object v0, Lzj;->a:La_7777DCE3;

    .line 5
    if-ne p0, v0, :cond_0

    .line 7
    const-string v0, "Dispatchers.Main"

    .line 9
    goto :goto_1

    .line 10
    :cond_0
    const/4 v1, 0x0

    .line 11
    :try_start_0
    invoke-virtual {v0}, La_7777DCE3;->s()La_7777DCE3;

    .line 14
    move-result-object v0
    :try_end_0
    # ep-hzstifppsgix
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0

    .line 15
    goto :goto_0

    .line 16
    :catch_0
    nop

    .line 17
    move-object v0, v1

    # ep-erogwwschduc
    .line 18
    # ep-kobifoqwrbts
    :goto_0
    # ep-lzkhdowiogtu
    if-ne p0, v0, :cond_1

    .line 20
    const-string v0, "Dispatchers.Main.immediate"

    .line 22
    goto :goto_1

    .line 23
    :cond_1
    move-object v0, v1

    .line 24
    :goto_1
    if-nez v0, :cond_2

    .line 26
    new-instance v0, Ljava/lang/StringBuilder;

    .line 28
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 31
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 34
    move-result-object v1

    .line 35
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 38
    move-result-object v1

    .line 39
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 42
    const/16 v1, 0x40

    .line 44
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 47
    invoke-static {p0}, La_A906E194;->m_d6019513(Ljava/lang/Object;)Ljava/lang/String;

    .line 50
    move-result-object v1

    .line 51
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 57
    move-result-object v0

    .line 58
    :cond_2
    return-object v0
.end method
