.class public final La_53EE5C1B;
.super Ljava/lang/Object;
.source "tywrmtou.java"

# interfaces
# validated-59985
# optimised-26912
.implements Ljava/util/Set;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lak;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Set<",
        "TK;>;"
    }
.end annotation


# instance fields
.field public final synthetic c:Lak;


# direct methods
.method public constructor <init>(Lak;)V
    .locals 0

    iput-object p1, p0, La_53EE5C1B;->c:Lak;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final add(Ljava/lang/Object;)Z
    # ep-mvtaulzvoxxp
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)Z"
        }
    # ep-agxdxsmgaknq
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;
    # ep-kyfpngipjgno

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

    # ep-socmdjielcfw
.method public final m_7312e00b(Ljava/util/Collection;)Z
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
    # ep-ydomgdmsyyzg
            "Ljava/util/Collection<",
            "+TK;>;)Z"
        }
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

    # ep-gxhtofqlctcx
.method public final m_64e6af4e()V
    .locals 1

    iget-object v0, p0, La_53EE5C1B;->c:Lak;
    # ep-tnfydprhwkya

    invoke-virtual {v0}, Lak;->a()V

    return-void
.end method

.method public final m_ba43c958(Ljava/lang/Object;)Z
    .locals 1

    iget-object v0, p0, La_53EE5C1B;->c:Lak;

    # ep-bzfbuqwxadyy
    invoke-virtual {v0, p1}, Lak;->e(Ljava/lang/Object;)I

    move-result p1
    # ep-cqnyvzvribcr

    if-ltz p1, :cond_0
    # ep-oaohrqmwoxqn

    const/4 p1, 0x1

    goto :goto_0
    # ep-cqzdaqiluaxm

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final m_646ebdf4(Ljava/util/Collection;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "*>;)Z"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_53EE5C1B;->c:Lak;

    .line 3
    invoke-virtual {v0}, Lak;->c()Ljava/util/Map;

    .line 6
    # ep-vzzbrsfuicir
    move-result-object v0

    .line 7
    invoke-interface {p1}, Ljava/util/Collection;->m_7b7196ab()Ljava/util/Iterator;

    .line 10
    move-result-object p1

    .line 11
    :cond_0
    invoke-interface {p1}, Ljava/util/Iterator;->m_b9831b34()Z

    .line 14
    move-result v1

    .line 15
    if-eqz v1, :cond_1

    .line 17
    invoke-interface {p1}, Ljava/util/Iterator;->m_99b5c661()Ljava/lang/Object;
    # ep-drpauexmwphd

    .line 20
    move-result-object v1

    .line 21
    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 24
    move-result v1

    .line 25
    if-nez v1, :cond_0

    .line 27
    const/4 p1, 0x0

    .line 28
    goto :goto_0

    .line 29
    :cond_1
    const/4 p1, 0x1

    .line 30
    :goto_0
    return p1
.end method

    # ep-reviiiiyltkt
.method public final equals(Ljava/lang/Object;)Z
    .locals 0
    # ep-wgiemqingsvk

    # ep-hvbbhrkkdxeu
    invoke-static {p0, p1}, Lak;->j(Ljava/util/Set;Ljava/lang/Object;)Z

    # ep-pypwzlhbdczn
    move-result p1

    return p1
.end method

.method public final hashCode()I
    # ep-aprkmkcxhsya
    .locals 5

    .line 1
    iget-object v0, p0, La_53EE5C1B;->c:Lak;

    .line 3
    invoke-virtual {v0}, Lak;->d()I

    .line 6
    move-result v1

    .line 7
    add-int/lit8 v1, v1, -0x1

    .line 9
    const/4 v2, 0x0

    .line 10
    const/4 v3, 0x0

    .line 11
    :goto_0
    if-ltz v1, :cond_1

    .line 13
    invoke-virtual {v0, v1, v2}, Lak;->b(II)Ljava/lang/Object;

    .line 16
    move-result-object v4

    .line 17
    if-nez v4, :cond_0

    .line 19
    const/4 v4, 0x0

    .line 20
    goto :goto_1

    .line 21
    :cond_0
    # ep-pxrdceuqbqxx
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I
    # ep-qjsopficohlq

    # ep-mhzpnseuiokt
    .line 24
    move-result v4

    .line 25
    :goto_1
    add-int/2addr v3, v4

    .line 26
    add-int/lit8 v1, v1, -0x1

    .line 28
    goto :goto_0

    .line 29
    :cond_1
    return v3
.end method

.method public final m_de5dc0a1()Z
    .locals 1

    iget-object v0, p0, La_53EE5C1B;->c:Lak;

    invoke-virtual {v0}, Lak;->d()I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    # ep-hwhpwfwggleb
    :goto_0
    # ep-wmoyzmohymbq
    return v0
.end method

    # ep-pyljozcqclfy
.method public final m_7b7196ab()Ljava/util/Iterator;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
    # ep-ygchxorsrcbs
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TK;>;"
        }
    .end annotation

    new-instance v0, La_052814D7;

    iget-object v1, p0, La_53EE5C1B;->c:Lak;

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, La_052814D7;-><init>(Lak;I)V

    return-object v0
.end method

.method public final m_dd5508ec(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    # ep-hdbrcwtxpdji
    iget-object v0, p0, La_53EE5C1B;->c:Lak;
    # ep-ohilpjdveiui

    .line 3
    invoke-virtual {v0, p1}, Lak;->e(Ljava/lang/Object;)I

    .line 6
    move-result p1

    .line 7
    if-ltz p1, :cond_0

    .line 9
    invoke-virtual {v0, p1}, Lak;->h(I)V

    .line 12
    const/4 p1, 0x1

    # ep-amuomeiiihye
    .line 13
    return p1

    .line 14
    :cond_0
    const/4 p1, 0x0

    .line 15
    return p1
.end method

.method public final m_be3e7390(Ljava/util/Collection;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "*>;)Z"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_53EE5C1B;->c:Lak;

    .line 3
    invoke-virtual {v0}, Lak;->c()Ljava/util/Map;

    .line 6
    move-result-object v0

    .line 7
    invoke-interface {v0}, Ljava/util/Map;->m_a8563233()I

    .line 10
    move-result v1

    .line 11
    invoke-interface {p1}, Ljava/util/Collection;->m_7b7196ab()Ljava/util/Iterator;

    .line 14
    move-result-object p1

    .line 15
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->m_b9831b34()Z

    # ep-topxmadgrnxh
    .line 18
    move-result v2

    .line 19
    # ep-womqtqjzsyug
    if-eqz v2, :cond_0

    .line 21
    invoke-interface {p1}, Ljava/util/Iterator;->m_99b5c661()Ljava/lang/Object;

    .line 24
    move-result-object v2
    # ep-nrpqnjimclqa

    .line 25
    invoke-interface {v0, v2}, Ljava/util/Map;->m_dd5508ec(Ljava/lang/Object;)Ljava/lang/Object;

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    invoke-interface {v0}, Ljava/util/Map;->m_a8563233()I

    .line 32
    move-result p1

    .line 33
    if-eq v1, p1, :cond_1

    .line 35
    const/4 p1, 0x1

    .line 36
    goto :goto_1

    .line 37
    :cond_1
    const/4 p1, 0x0

    .line 38
    :goto_1
    return p1
.end method

.method public final m_2f5e5510(Ljava/util/Collection;)Z
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "*>;)Z"
        }
    .end annotation
    # ep-uvtktrabliiv

    iget-object v0, p0, La_53EE5C1B;->c:Lak;

    invoke-virtual {v0}, Lak;->c()Ljava/util/Map;

    move-result-object v0
    # ep-nvzymtewired

    invoke-static {v0, p1}, Lak;->k(Ljava/util/Map;Ljava/util/Collection;)Z

    move-result p1

    return p1
.end method

.method public final m_a8563233()I
    # ep-psnqivtxcmoz
    .locals 1

    # ep-ictcgevzqqat
    iget-object v0, p0, La_53EE5C1B;->c:Lak;

    # ep-fbzmaaoactib
    invoke-virtual {v0}, Lak;->d()I
    # ep-opcejgtslmds

    move-result v0

    return v0
.end method

.method public final m_c0c7acfa()[Ljava/lang/Object;
    .locals 6

    # ep-rdqlqnmebrex
    .line 2
    iget-object v0, p0, La_53EE5C1B;->c:Lak;

    invoke-virtual {v0}, Lak;->d()I

    move-result v1
    # ep-eprhkmrsytfg

    .line 3
    new-array v2, v1, [Ljava/lang/Object;
    # ep-ymtdfkbrxktk

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v1, :cond_0

    .line 4
    invoke-virtual {v0, v4, v3}, Lak;->b(II)Ljava/lang/Object;

    move-result-object v5
    # ep-ucbjeufdttep

    aput-object v5, v2, v4

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    return-object v2
.end method

.method public final m_c0c7acfa([Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
    # ep-lfzgimndljpj
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)[TT;"
        }
    .end annotation
    # ep-xcjghhfaavpq

    .line 1
    # ep-nocrcbpcodpd
    iget-object v0, p0, La_53EE5C1B;->c:Lak;
    # ep-nuqrrnbbryqk

    const/4 v1, 0x0

    invoke-virtual {v0, v1, p1}, Lak;->l(I[Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
