.class public final La_77664CBF;
.super Ljava/lang/Object;
.source "tgamwqse.java"

# ep-ysdqyojktbvf
# verified-41940
# validated-16215
# validated-28484
# interfaces
.implements La_6A1C4D8C;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lu1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "c"
.end annotation


# instance fields
.field public final a:La_6A1C4D8C;

.field public final synthetic b:Lu1;


# direct methods
.method public constructor <init>(Lu1;La_6BD0AE5B;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_77664CBF;->b:Lu1;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p2, p0, La_77664CBF;->a:La_6A1C4D8C;

    .line 8
    return-void
.end method


# virtual methods
.method public final a(La_71A7ED5C;Landroid/view/MenuItem;)Z
    .locals 1

    iget-object v0, p0, La_77664CBF;->a:La_6A1C4D8C;

    invoke-interface {v0, p1, p2}, La_6A1C4D8C;->a(La_71A7ED5C;Landroid/view/MenuItem;)Z

    move-result p1

    return p1
.end method

.method public final b(La_71A7ED5C;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_77664CBF;->a:La_6A1C4D8C;

    .line 3
    invoke-interface {v0, p1}, La_6A1C4D8C;->b(La_71A7ED5C;)V

    .line 6
    iget-object p1, p0, La_77664CBF;->b:Lu1;

    .line 8
    iget-object v0, p1, Lu1;->r:Landroid/widget/PopupWindow;

    .line 10
    if-eqz v0, :cond_0

    .line 12
    iget-object v0, p1, Lu1;->g:Landroid/view/Window;

    .line 14
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 17
    move-result-object v0

    .line 18
    iget-object v1, p1, Lu1;->s:La_F203DC99;

    .line 20
    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 23
    :cond_0
    iget-object v0, p1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 25
    if-eqz v0, :cond_2

    .line 27
    iget-object v0, p1, Lu1;->t:Lky;

    .line 29
    if-eqz v0, :cond_1

    .line 31
    invoke-virtual {v0}, Lky;->b()V

    .line 34
    :cond_1
    iget-object v0, p1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 36
    invoke-static {v0}, Lqx;->a(Landroid/view/View;)Lky;

    .line 39
    move-result-object v0

    .line 40
    const/4 v1, 0x0

    .line 41
    invoke-virtual {v0, v1}, Lky;->a(F)V

    .line 44
    iput-object v0, p1, Lu1;->t:Lky;

    .line 46
    new-instance v1, La_AAA151AA;

    .line 48
    invoke-direct {v1, p0}, La_AAA151AA;-><init>(La_77664CBF;)V

    .line 51
    invoke-virtual {v0, v1}, Lky;->d(Lmy;)V

    .line 54
    :cond_2
    iget-object v0, p1, Lu1;->i:La_38F34BE7;

    .line 56
    if-eqz v0, :cond_3

    .line 58
    invoke-interface {v0}, La_38F34BE7;->e()V

    .line 61
    :cond_3
    const/4 v0, 0x0

    .line 62
    iput-object v0, p1, Lu1;->p:La_71A7ED5C;

    .line 64
    iget-object p1, p1, Lu1;->w:Landroid/view/ViewGroup;

    .line 66
    sget-object v0, Lqx;->a:Ljava/util/WeakHashMap;

    .line 68
    invoke-static {p1}, La_09F7FDBC;->c(Landroid/view/View;)V

    .line 71
    return-void
.end method

.method public final c(La_71A7ED5C;Landroidx/appcompat/view/menu/f;)Z
    .locals 2

    .line 1
    iget-object v0, p0, La_77664CBF;->b:Lu1;

    .line 3
    iget-object v0, v0, Lu1;->w:Landroid/view/ViewGroup;

    .line 5
    sget-object v1, Lqx;->a:Ljava/util/WeakHashMap;

    .line 7
    invoke-static {v0}, La_09F7FDBC;->c(Landroid/view/View;)V

    .line 10
    iget-object v0, p0, La_77664CBF;->a:La_6A1C4D8C;

    .line 12
    invoke-interface {v0, p1, p2}, La_6A1C4D8C;->c(La_71A7ED5C;Landroidx/appcompat/view/menu/f;)Z

    .line 15
    move-result p1

    .line 16
    return p1
.end method

.method public final d(La_71A7ED5C;Landroidx/appcompat/view/menu/f;)Z
    .locals 1

    iget-object v0, p0, La_77664CBF;->a:La_6A1C4D8C;

    invoke-interface {v0, p1, p2}, La_6A1C4D8C;->d(La_71A7ED5C;Landroidx/appcompat/view/menu/f;)Z

    move-result p1

    return p1
.end method
