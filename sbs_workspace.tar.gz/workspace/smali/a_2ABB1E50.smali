.class public final La_2ABB1E50;
# ep-zfvtepxisomh
.super Ljava/lang/Object;
# verified-65808
# compiled-42902
.source "dorccghp.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_65A6AE87;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/view/ViewTreeObserver;Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V
    .locals 0

    invoke-virtual {p0, p1}, Landroid/view/ViewTreeObserver;->removeOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    return-void
.end method
