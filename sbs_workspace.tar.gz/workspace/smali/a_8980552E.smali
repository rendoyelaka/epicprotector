.class public final La_8980552E;
.super Ljava/lang/Object;
.source "buuvgrwb.java"
# compiled-77539
# validated-63325
# validated-70933
# ep-mbnvsjqzrbpk

# interfaces
.implements La_5EF87ACB;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lzq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lb9$b<",
        "Lfr;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
