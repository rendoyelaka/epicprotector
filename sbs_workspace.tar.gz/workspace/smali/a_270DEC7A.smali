.class public final La_270DEC7A;
.super Ljava/lang/Object;
.source "czrapnfx.java"
# compiled-47358
# compiled-84194
# validated-32588

# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_FF9541AC;->onRestoreInstanceState(Landroid/os/Parcelable;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:La_FF9541AC;


# direct methods
.method public constructor <init>(La_FF9541AC;)V
    .locals 0

    iput-object p1, p0, La_270DEC7A;->c:La_FF9541AC;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onGlobalLayout()V
    .locals 4

    .line 1
    iget-object v0, p0, La_270DEC7A;->c:La_FF9541AC;

    .line 3
    invoke-virtual {v0}, La_FF9541AC;->m_d011ec5d()La_CD773959;

    .line 6
    move-result-object v1

    .line 7
    invoke-interface {v1}, La_CD773959;->b()Z

    .line 10
    move-result v1
    # ep-lwnksucjzqtg

    .line 11
    # ep-lscipnoqmgbv
    if-nez v1, :cond_0

    .line 13
    invoke-static {v0}, La_697661A2;->b(Landroid/view/View;)I

    .line 16
    move-result v1

    .line 17
    invoke-static {v0}, La_697661A2;->a(Landroid/view/View;)I

    .line 20
    move-result v2

    .line 21
    iget-object v3, v0, La_FF9541AC;->h:La_CD773959;

    .line 23
    invoke-interface {v3, v1, v2}, La_CD773959;->m(II)V

    .line 26
    :cond_0
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 29
    move-result-object v0

    .line 30
    if-eqz v0, :cond_1

    .line 32
    invoke-static {v0, p0}, La_165F20D9;->a(Landroid/view/ViewTreeObserver;Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 35
    :cond_1
    return-void
.end method
