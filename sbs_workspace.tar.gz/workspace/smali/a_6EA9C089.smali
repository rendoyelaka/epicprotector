.class public interface abstract La_6EA9C089;
.super Ljava/lang/Object;
.source "ynykqkjn.java"
