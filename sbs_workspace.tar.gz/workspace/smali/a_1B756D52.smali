.class public final La_1B756D52;
.super Ljava/lang/Object;
.source "lpvqlszk.java"
# ep-lmkxzbjmsyav

# optimised-96427
# validated-69096
# generated-36278

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_C69CD277;
    }
.end annotation


# instance fields
.field public final a:Landroid/widget/TextView;

.field public b:Landroid/view/textclassifier/TextClassifier;


# direct methods
.method public constructor <init>(Landroid/widget/TextView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    iput-object p1, p0, La_1B756D52;->a:Landroid/widget/TextView;

    .line 9
    return-void
.end method
