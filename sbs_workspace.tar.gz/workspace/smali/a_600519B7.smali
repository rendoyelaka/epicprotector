.class public La_600519B7;
.super Landroid/widget/ImageView;
.source "ikrykokk.java"

# generated-82127
# verified-96862
# generated-59810
# ep-mccjtotquejv

# instance fields
.field public final c:La_0D850CD8;

.field public final d:La_862B0935;

.field public e:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 1
    invoke-direct {p0, p1, v1, v0}, La_600519B7;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    .line 2
    invoke-static {p1}, Ljv;->a(Landroid/content/Context;)V

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 p1, 0x0

    .line 3
    iput-boolean p1, p0, La_600519B7;->e:Z

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    move-result-object p1

    invoke-static {p0, p1}, Lav;->a(Landroid/view/View;Landroid/content/Context;)V

    .line 5
    new-instance p1, La_0D850CD8;

    invoke-direct {p1, p0}, La_0D850CD8;-><init>(Landroid/view/View;)V

    iput-object p1, p0, La_600519B7;->c:La_0D850CD8;

    .line 6
    invoke-virtual {p1, p2, p3}, La_0D850CD8;->d(Landroid/util/AttributeSet;I)V

    .line 7
    new-instance p1, La_862B0935;

    invoke-direct {p1, p0}, La_862B0935;-><init>(Landroid/widget/ImageView;)V

    iput-object p1, p0, La_600519B7;->d:La_862B0935;

    .line 8
    invoke-virtual {p1, p2, p3}, La_862B0935;->b(Landroid/util/AttributeSet;I)V

    return-void
.end method


# virtual methods
.method public final m_cb26974e()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/ImageView;->m_cb26974e()V

    .line 4
    iget-object v0, p0, La_600519B7;->c:La_0D850CD8;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, La_0D850CD8;->a()V

    .line 11
    :cond_0
    iget-object v0, p0, La_600519B7;->d:La_862B0935;

    .line 13
    if-eqz v0, :cond_1

    .line 15
    invoke-virtual {v0}, La_862B0935;->a()V

    .line 18
    :cond_1
    return-void
.end method

.method public m_4eb19bca()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, La_600519B7;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_0D850CD8;->b()Landroid/content/res/ColorStateList;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_c605babf()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, La_600519B7;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_0D850CD8;->c()Landroid/graphics/PorterDuff$Mode;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_b729994c()Landroid/content/res/ColorStateList;
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, La_600519B7;->d:La_862B0935;

    .line 4
    if-eqz v1, :cond_0

    .line 6
    iget-object v1, v1, La_862B0935;->b:Lkv;

    .line 8
    if-eqz v1, :cond_0

    .line 10
    iget-object v0, v1, Lkv;->a:Landroid/content/res/ColorStateList;

    .line 12
    :cond_0
    return-object v0
.end method

.method public m_e3a82b33()Landroid/graphics/PorterDuff$Mode;
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, La_600519B7;->d:La_862B0935;

    .line 4
    if-eqz v1, :cond_0

    .line 6
    iget-object v1, v1, La_862B0935;->b:Lkv;

    .line 8
    if-eqz v1, :cond_0

    .line 10
    iget-object v0, v1, Lkv;->b:Landroid/graphics/PorterDuff$Mode;

    .line 12
    :cond_0
    return-object v0
.end method

.method public final m_6ed1a19b()Z
    .locals 2

    .line 1
    iget-object v0, p0, La_600519B7;->d:La_862B0935;

    .line 3
    iget-object v0, v0, La_862B0935;->a:Landroid/widget/ImageView;

    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 8
    move-result-object v0

    .line 9
    instance-of v0, v0, Landroid/graphics/drawable/RippleDrawable;

    .line 11
    const/4 v1, 0x1

    .line 12
    xor-int/2addr v0, v1

    .line 13
    if-eqz v0, :cond_0

    .line 15
    invoke-super {p0}, Landroid/widget/ImageView;->m_6ed1a19b()Z

    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_0

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 v1, 0x0

    .line 23
    :goto_0
    return v1
.end method

.method public m_08385e47(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_08385e47(Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_600519B7;->c:La_0D850CD8;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_0D850CD8;->e()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_ee40bba3(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_ee40bba3(I)V

    .line 4
    iget-object v0, p0, La_600519B7;->c:La_0D850CD8;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1}, La_0D850CD8;->f(I)V

    .line 11
    :cond_0
    return-void
.end method

.method public m_fc701bb4(Landroid/graphics/Bitmap;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_fc701bb4(Landroid/graphics/Bitmap;)V

    .line 4
    iget-object p1, p0, La_600519B7;->d:La_862B0935;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_862B0935;->a()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_c591b61f(Landroid/graphics/drawable/Drawable;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_600519B7;->d:La_862B0935;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    if-eqz p1, :cond_0

    .line 7
    iget-boolean v1, p0, La_600519B7;->e:Z

    .line 9
    if-nez v1, :cond_0

    .line 11
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getLevel()I

    .line 14
    move-result v1

    .line 15
    iput v1, v0, La_862B0935;->d:I

    .line 17
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_c591b61f(Landroid/graphics/drawable/Drawable;)V

    .line 20
    if-eqz v0, :cond_1

    .line 22
    invoke-virtual {v0}, La_862B0935;->a()V

    .line 25
    iget-boolean p1, p0, La_600519B7;->e:Z

    .line 27
    if-nez p1, :cond_1

    .line 29
    iget-object p1, v0, La_862B0935;->a:Landroid/widget/ImageView;

    .line 31
    invoke-virtual {p1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 34
    move-result-object v1

    .line 35
    if-eqz v1, :cond_1

    .line 37
    invoke-virtual {p1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 40
    move-result-object p1

    .line 41
    iget v0, v0, La_862B0935;->d:I

    .line 43
    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 46
    :cond_1
    return-void
.end method

.method public m_8a5d5e01(I)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_8a5d5e01(I)V

    .line 4
    const/4 p1, 0x1

    .line 5
    iput-boolean p1, p0, La_600519B7;->e:Z

    .line 7
    return-void
.end method

.method public m_ffaef852(I)V
    .locals 1

    .line 1
    iget-object v0, p0, La_600519B7;->d:La_862B0935;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_862B0935;->c(I)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_678683f2(Landroid/net/Uri;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageView;->m_678683f2(Landroid/net/Uri;)V

    .line 4
    iget-object p1, p0, La_600519B7;->d:La_862B0935;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_862B0935;->a()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_44b49f65(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_600519B7;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_0D850CD8;->h(Landroid/content/res/ColorStateList;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_10b86d4b(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_600519B7;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_0D850CD8;->i(Landroid/graphics/PorterDuff$Mode;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_5d3e9803(Landroid/content/res/ColorStateList;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_600519B7;->d:La_862B0935;

    .line 3
    if-eqz v0, :cond_1

    .line 5
    iget-object v1, v0, La_862B0935;->b:Lkv;

    .line 7
    if-nez v1, :cond_0

    .line 9
    new-instance v1, Lkv;

    .line 11
    invoke-direct {v1}, Lkv;-><init>()V

    .line 14
    iput-object v1, v0, La_862B0935;->b:Lkv;

    .line 16
    :cond_0
    iget-object v1, v0, La_862B0935;->b:Lkv;

    .line 18
    iput-object p1, v1, Lkv;->a:Landroid/content/res/ColorStateList;

    .line 20
    const/4 p1, 0x1

    .line 21
    iput-boolean p1, v1, Lkv;->d:Z

    .line 23
    invoke-virtual {v0}, La_862B0935;->a()V

    .line 26
    :cond_1
    return-void
.end method

.method public m_78617dd4(Landroid/graphics/PorterDuff$Mode;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_600519B7;->d:La_862B0935;

    .line 3
    if-eqz v0, :cond_1

    .line 5
    iget-object v1, v0, La_862B0935;->b:Lkv;

    .line 7
    if-nez v1, :cond_0

    .line 9
    new-instance v1, Lkv;

    .line 11
    invoke-direct {v1}, Lkv;-><init>()V

    .line 14
    iput-object v1, v0, La_862B0935;->b:Lkv;

    .line 16
    :cond_0
    iget-object v1, v0, La_862B0935;->b:Lkv;

    .line 18
    iput-object p1, v1, Lkv;->b:Landroid/graphics/PorterDuff$Mode;

    .line 20
    const/4 p1, 0x1

    .line 21
    iput-boolean p1, v1, Lkv;->c:Z

    .line 23
    invoke-virtual {v0}, La_862B0935;->a()V

    .line 26
    :cond_1
    return-void
.end method
