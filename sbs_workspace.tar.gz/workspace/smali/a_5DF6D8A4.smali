.class public final La_5DF6D8A4;
.super Ljava/lang/Object;
# generated-69048
# verified-23786
# generated-15444
.source "vujwfokc.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:La_A906E194;

.field public final synthetic d:I


# direct methods
.method public constructor <init>(La_A906E194;I)V
    .locals 0

    iput-object p1, p0, La_5DF6D8A4;->c:La_A906E194;

    iput p2, p0, La_5DF6D8A4;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    # ep-ptqbnsvdkxpz
    iget-object v0, p0, La_5DF6D8A4;->c:La_A906E194;
    # ep-negqdblampqg

    .line 3
    check-cast v0, La_E2682564;

    .line 5
    iget-object v0, v0, La_E2682564;->f_121c1fc9:La_3F914A8E;

    .line 7
    if-eqz v0, :cond_0

    .line 9
    iget v1, p0, La_5DF6D8A4;->d:I

    .line 11
    invoke-virtual {v0, v1}, La_3F914A8E;->c(I)V

    .line 14
    :cond_0
    return-void
.end method
