.class public final LWorkSpecDao;
# ep-iqjubmcmtifb
.super Ljava/lang/Object;
.source "dxdbqpzn.java"

# generated-97155
# interfaces
.implements Lz00;


# instance fields
.field public final a:Ljq;

.field public final b:LWorkSpecDao$a;

.field public final c:LWorkSpecDao$b;

.field public final d:LWorkSpecDao$c;

.field public final e:LWorkSpecDao$d;

.field public final f:LWorkSpecDao$e;

.field public final g:LWorkSpecDao$f;

.field public final h:LWorkSpecDao$g;

.field public final i:LWorkSpecDao$h;


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, LWorkSpecDao;->a:Ljq;

    .line 6
    new-instance v0, LWorkSpecDao$a;

    .line 8
    invoke-direct {v0, p1}, LWorkSpecDao$a;-><init>(Ljq;)V

    .line 11
    iput-object v0, p0, LWorkSpecDao;->b:LWorkSpecDao$a;

    .line 13
    new-instance v0, LWorkSpecDao$b;

    .line 15
    invoke-direct {v0, p1}, LWorkSpecDao$b;-><init>(Ljq;)V

    .line 18
    iput-object v0, p0, LWorkSpecDao;->c:LWorkSpecDao$b;

    .line 20
    new-instance v0, LWorkSpecDao$c;

    .line 22
    invoke-direct {v0, p1}, LWorkSpecDao$c;-><init>(Ljq;)V

    .line 25
    iput-object v0, p0, LWorkSpecDao;->d:LWorkSpecDao$c;

    .line 27
    new-instance v0, LWorkSpecDao$d;

    .line 29
    invoke-direct {v0, p1}, LWorkSpecDao$d;-><init>(Ljq;)V

    .line 32
    iput-object v0, p0, LWorkSpecDao;->e:LWorkSpecDao$d;

    .line 34
    new-instance v0, LWorkSpecDao$e;

    .line 36
    invoke-direct {v0, p1}, LWorkSpecDao$e;-><init>(Ljq;)V

    .line 39
    iput-object v0, p0, LWorkSpecDao;->f:LWorkSpecDao$e;

    .line 41
    new-instance v0, LWorkSpecDao$f;

    .line 43
    invoke-direct {v0, p1}, LWorkSpecDao$f;-><init>(Ljq;)V

    .line 46
    iput-object v0, p0, LWorkSpecDao;->g:LWorkSpecDao$f;

    .line 48
    new-instance v0, LWorkSpecDao$g;

    .line 50
    invoke-direct {v0, p1}, LWorkSpecDao$g;-><init>(Ljq;)V

    .line 53
    iput-object v0, p0, LWorkSpecDao;->h:LWorkSpecDao$g;

    .line 55
    new-instance v0, LWorkSpecDao$h;

    .line 57
    invoke-direct {v0, p1}, LWorkSpecDao$h;-><init>(Ljq;)V

    .line 60
    iput-object v0, p0, LWorkSpecDao;->i:LWorkSpecDao$h;

    .line 62
    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 64
    const/4 v0, 0x0

    .line 65
    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 68
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)V
    .locals 16

    .line 1
    iget-object v0, p0, LWorkSpecDao;->a:Ljq;

    .line 3
    invoke-virtual {v0}, Ljq;->b()V

    .line 6
    iget-object v1, p0, LWorkSpecDao;->c:LWorkSpecDao$b;

    .line 8
    invoke-virtual {v1}, Lcs;->a()Lue;

    .line 11
    move-result-object v2

    .line 12
    const/4 v3, 0x1

    .line 13
    if-nez p1, :cond_0

    .line 15
    invoke-virtual {v2, v3}, Lte;->s(I)V

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    invoke-virtual {v2, p1, v3}, Lte;->t(Ljava/lang/String;I)V

    .line 22
    :goto_0
    invoke-virtual {v0}, Ljq;->c()V

    .line 25
    :try_start_0
    invoke-virtual {v2}, Lue;->u()I

    .line 28
    invoke-virtual {v0}, Ljq;->h()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 31
    invoke-virtual {v0}, Ljq;->f()V

    .line 34
    invoke-virtual {v1, v2}, Lcs;->c(Lue;)V

    .line 37
    return-void

    .line 38
    :catchall_0
    move-exception p1

    .line 39
    invoke-virtual {v0}, Ljq;->f()V

    .line 42
    invoke-virtual {v1, v2}, Lcs;->c(Lue;)V

    .line 45
    throw p1
.end method

.method public final b()Ljava/util/ArrayList;
    .locals 35

    .line 1
    const-string v0, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 ORDER BY period_start_time LIMIT ?"

    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-static {v0, v1}, Llq;->r(Ljava/lang/String;I)Llq;

    .line 7
    move-result-object v2

    .line 8
    const/16 v0, 0xc8

    .line 10
    int-to-long v3, v0

    .line 11
    invoke-virtual {v2, v1, v3, v4}, Llq;->s(IJ)V

    .line 14
    move-object/from16 v3, p0

    .line 16
    iget-object v0, v3, LWorkSpecDao;->a:Ljq;

    .line 18
    invoke-virtual {v0}, Ljq;->b()V

    .line 21
    invoke-virtual {v0, v2}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 24
    move-result-object v4

    .line 25
    :try_start_0
    const-string v0, "required_network_type"

    .line 27
    invoke-static {v4, v0}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 30
    move-result v0

    .line 31
    const-string v5, "requires_charging"

    .line 33
    invoke-static {v4, v5}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 36
    move-result v5

    .line 37
    const-string v6, "requires_device_idle"

    .line 39
    invoke-static {v4, v6}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 42
    move-result v6

    .line 43
    const-string v7, "requires_battery_not_low"

    .line 45
    invoke-static {v4, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 48
    move-result v7

    .line 49
    const-string v8, "requires_storage_not_low"

    .line 51
    invoke-static {v4, v8}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 54
    move-result v8

    .line 55
    const-string v9, "trigger_content_update_delay"

    .line 57
    invoke-static {v4, v9}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 60
    move-result v9

    .line 61
    const-string v10, "trigger_max_content_delay"

    .line 63
    invoke-static {v4, v10}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 66
    move-result v10

    .line 67
    const-string v11, "content_uri_triggers"

    .line 69
    invoke-static {v4, v11}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 72
    move-result v11

    .line 73
    const-string v12, "id"

    .line 75
    invoke-static {v4, v12}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 78
    move-result v12

    .line 79
    const-string v13, "state"

    .line 81
    invoke-static {v4, v13}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 84
    move-result v13

    .line 85
    const-string v14, "worker_class_name"

    .line 87
    invoke-static {v4, v14}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 90
    move-result v14

    .line 91
    const-string v15, "input_merger_class_name"

    .line 93
    invoke-static {v4, v15}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 96
    move-result v15

    .line 97
    const-string v1, "input"

    .line 99
    invoke-static {v4, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 102
    move-result v1

    .line 103
    const-string v3, "output"

    .line 105
    invoke-static {v4, v3}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 108
    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 109
    move-object/from16 v16, v2

    .line 111
    :try_start_1
    const-string v2, "initial_delay"

    .line 113
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 116
    move-result v2

    .line 117
    move/from16 v17, v2

    .line 119
    const-string v2, "interval_duration"

    .line 121
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 124
    move-result v2

    .line 125
    move/from16 v18, v2

    .line 127
    const-string v2, "flex_duration"

    .line 129
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 132
    move-result v2

    .line 133
    move/from16 v19, v2

    .line 135
    const-string v2, "run_attempt_count"

    .line 137
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 140
    move-result v2

    .line 141
    move/from16 v20, v2

    .line 143
    const-string v2, "backoff_policy"

    .line 145
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 148
    move-result v2

    .line 149
    move/from16 v21, v2

    .line 151
    const-string v2, "backoff_delay_duration"

    .line 153
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 156
    move-result v2

    .line 157
    move/from16 v22, v2

    .line 159
    const-string v2, "period_start_time"

    .line 161
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 164
    move-result v2

    .line 165
    move/from16 v23, v2

    .line 167
    const-string v2, "minimum_retention_duration"

    .line 169
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 172
    move-result v2

    .line 173
    move/from16 v24, v2

    .line 175
    const-string v2, "schedule_requested_at"

    .line 177
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 180
    move-result v2

    .line 181
    move/from16 v25, v2

    .line 183
    const-string v2, "run_in_foreground"

    .line 185
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 188
    move-result v2

    .line 189
    move/from16 v26, v2

    .line 191
    const-string v2, "out_of_quota_policy"

    .line 193
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 196
    move-result v2

    .line 197
    move/from16 v27, v2

    .line 199
    new-instance v2, Ljava/util/ArrayList;

    .line 201
    move/from16 v28, v3

    .line 203
    invoke-interface {v4}, Landroid/database/Cursor;->getCount()I

    .line 206
    move-result v3

    .line 207
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 210
    :goto_0
    invoke-interface {v4}, Landroid/database/Cursor;->moveToNext()Z

    .line 213
    move-result v3

    .line 214
    if-eqz v3, :cond_5

    .line 216
    invoke-interface {v4, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 219
    move-result-object v3

    .line 220
    move/from16 v29, v12

    .line 222
    invoke-interface {v4, v14}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 225
    move-result-object v12

    .line 226
    move/from16 v30, v14

    .line 228
    new-instance v14, Lf8;

    .line 230
    invoke-direct {v14}, Lf8;-><init>()V

    .line 233
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 236
    move-result v31

    .line 237
    move/from16 v32, v0

    .line 239
    invoke-static/range {v31 .. v31}, Lf10;->c(I)Lqm;

    .line 242
    move-result-object v0

    .line 243
    iput-object v0, v14, Lf8;->a:Lqm;

    .line 245
    invoke-interface {v4, v5}, Landroid/database/Cursor;->getInt(I)I

    .line 248
    move-result v0

    .line 249
    const/16 v31, 0x0

    .line 251
    if-eqz v0, :cond_0

    .line 253
    const/4 v0, 0x1

    .line 254
    goto :goto_1

    .line 255
    :cond_0
    const/4 v0, 0x0

    .line 256
    :goto_1
    iput-boolean v0, v14, Lf8;->b:Z

    .line 258
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getInt(I)I

    .line 261
    move-result v0

    .line 262
    if-eqz v0, :cond_1

    .line 264
    const/4 v0, 0x1

    .line 265
    goto :goto_2

    .line 266
    :cond_1
    const/4 v0, 0x0

    .line 267
    :goto_2
    iput-boolean v0, v14, Lf8;->c:Z

    .line 269
    invoke-interface {v4, v7}, Landroid/database/Cursor;->getInt(I)I

    .line 272
    move-result v0

    .line 273
    if-eqz v0, :cond_2

    .line 275
    const/4 v0, 0x1

    .line 276
    goto :goto_3

    .line 277
    :cond_2
    const/4 v0, 0x0

    .line 278
    :goto_3
    iput-boolean v0, v14, Lf8;->d:Z

    .line 280
    invoke-interface {v4, v8}, Landroid/database/Cursor;->getInt(I)I

    .line 283
    move-result v0

    .line 284
    if-eqz v0, :cond_3

    .line 286
    const/4 v0, 0x1

    .line 287
    goto :goto_4

    .line 288
    :cond_3
    const/4 v0, 0x0

    .line 289
    :goto_4
    iput-boolean v0, v14, Lf8;->e:Z

    .line 291
    move v0, v5

    .line 292
    move/from16 v33, v6

    .line 294
    invoke-interface {v4, v9}, Landroid/database/Cursor;->getLong(I)J

    .line 297
    move-result-wide v5

    .line 298
    iput-wide v5, v14, Lf8;->f:J

    .line 300
    invoke-interface {v4, v10}, Landroid/database/Cursor;->getLong(I)J

    .line 303
    move-result-wide v5

    .line 304
    iput-wide v5, v14, Lf8;->g:J

    .line 306
    invoke-interface {v4, v11}, Landroid/database/Cursor;->getBlob(I)[B

    .line 309
    move-result-object v5

    .line 310
    invoke-static {v5}, Lf10;->a([B)Ll8;

    .line 313
    move-result-object v5

    .line 314
    iput-object v5, v14, Lf8;->h:Ll8;

    .line 316
    new-instance v5, LWorkSpec;

    .line 318
    invoke-direct {v5, v3, v12}, LWorkSpec;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 321
    invoke-interface {v4, v13}, Landroid/database/Cursor;->getInt(I)I

    .line 324
    move-result v3

    .line 325
    invoke-static {v3}, Lf10;->e(I)LWorkInfo_State;

    .line 328
    move-result-object v3

    .line 329
    iput-object v3, v5, LWorkSpec;->b:LWorkInfo_State;

    .line 331
    invoke-interface {v4, v15}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 334
    move-result-object v3

    .line 335
    iput-object v3, v5, LWorkSpec;->d:Ljava/lang/String;

    .line 337
    invoke-interface {v4, v1}, Landroid/database/Cursor;->getBlob(I)[B

    .line 340
    move-result-object v3

    .line 341
    invoke-static {v3}, Landroidx/work/b;->a([B)Landroidx/work/b;

    .line 344
    move-result-object v3

    .line 345
    iput-object v3, v5, LWorkSpec;->e:Landroidx/work/b;

    .line 347
    move/from16 v3, v28

    .line 349
    invoke-interface {v4, v3}, Landroid/database/Cursor;->getBlob(I)[B

    .line 352
    move-result-object v6

    .line 353
    invoke-static {v6}, Landroidx/work/b;->a([B)Landroidx/work/b;

    .line 356
    move-result-object v6

    .line 357
    iput-object v6, v5, LWorkSpec;->f:Landroidx/work/b;

    .line 359
    move v12, v1

    .line 360
    move/from16 v6, v17

    .line 362
    move/from16 v17, v0

    .line 364
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 367
    move-result-wide v0

    .line 368
    iput-wide v0, v5, LWorkSpec;->g:J

    .line 370
    move v1, v7

    .line 371
    move/from16 v0, v18

    .line 373
    move/from16 v18, v6

    .line 375
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 378
    move-result-wide v6

    .line 379
    iput-wide v6, v5, LWorkSpec;->h:J

    .line 381
    move v7, v0

    .line 382
    move/from16 v6, v19

    .line 384
    move/from16 v19, v1

    .line 386
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 389
    move-result-wide v0

    .line 390
    iput-wide v0, v5, LWorkSpec;->i:J

    .line 392
    move/from16 v0, v20

    .line 394
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 397
    move-result v1

    .line 398
    iput v1, v5, LWorkSpec;->k:I

    .line 400
    move/from16 v1, v21

    .line 402
    invoke-interface {v4, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 405
    move-result v20

    .line 406
    move/from16 v21, v0

    .line 408
    invoke-static/range {v20 .. v20}, Lf10;->b(I)I

    .line 411
    move-result v0

    .line 412
    iput v0, v5, LWorkSpec;->l:I

    .line 414
    move/from16 v20, v6

    .line 416
    move/from16 v0, v22

    .line 418
    move/from16 v22, v7

    .line 420
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 423
    move-result-wide v6

    .line 424
    iput-wide v6, v5, LWorkSpec;->m:J

    .line 426
    move v7, v1

    .line 427
    move/from16 v6, v23

    .line 429
    move/from16 v23, v0

    .line 431
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 434
    move-result-wide v0

    .line 435
    iput-wide v0, v5, LWorkSpec;->n:J

    .line 437
    move v1, v6

    .line 438
    move/from16 v0, v24

    .line 440
    move/from16 v24, v7

    .line 442
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 445
    move-result-wide v6

    .line 446
    iput-wide v6, v5, LWorkSpec;->o:J

    .line 448
    move v7, v0

    .line 449
    move/from16 v6, v25

    .line 451
    move/from16 v25, v1

    .line 453
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 456
    move-result-wide v0

    .line 457
    iput-wide v0, v5, LWorkSpec;->p:J

    .line 459
    move/from16 v0, v26

    .line 461
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 464
    move-result v1

    .line 465
    if-eqz v1, :cond_4

    .line 467
    const/4 v1, 0x1

    .line 468
    goto :goto_5

    .line 469
    :cond_4
    const/4 v1, 0x0

    .line 470
    :goto_5
    iput-boolean v1, v5, LWorkSpec;->q:Z

    .line 472
    move/from16 v1, v27

    .line 474
    invoke-interface {v4, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 477
    move-result v26

    .line 478
    move/from16 v27, v0

    .line 480
    invoke-static/range {v26 .. v26}, Lf10;->d(I)I

    .line 483
    move-result v0

    .line 484
    iput v0, v5, LWorkSpec;->r:I

    .line 486
    iput-object v14, v5, LWorkSpec;->j:Lf8;

    .line 488
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 491
    move/from16 v28, v3

    .line 493
    move/from16 v5, v17

    .line 495
    move/from16 v17, v18

    .line 497
    move/from16 v18, v22

    .line 499
    move/from16 v22, v23

    .line 501
    move/from16 v23, v25

    .line 503
    move/from16 v26, v27

    .line 505
    move/from16 v14, v30

    .line 507
    move/from16 v0, v32

    .line 509
    move/from16 v27, v1

    .line 511
    move/from16 v25, v6

    .line 513
    move v1, v12

    .line 514
    move/from16 v12, v29

    .line 516
    move/from16 v6, v33

    .line 518
    move/from16 v34, v24

    .line 520
    move/from16 v24, v7

    .line 522
    move/from16 v7, v19

    .line 524
    move/from16 v19, v20

    .line 526
    move/from16 v20, v21

    .line 528
    move/from16 v21, v34

    .line 530
    goto/16 :goto_0

    .line 532
    :cond_5
    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    .line 535
    invoke-virtual/range {v16 .. v16}, Llq;->v()V

    .line 538
    return-object v2

    .line 539
    :catchall_0
    move-exception v0

    .line 540
    goto :goto_6

    .line 541
    :catchall_1
    move-exception v0

    .line 542
    move-object/from16 v16, v2

    .line 544
    :goto_6
    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    .line 547
    invoke-virtual/range {v16 .. v16}, Llq;->v()V

    .line 550
    throw v0
.end method

.method public final c(I)Ljava/util/ArrayList;
    .locals 34

    .line 1
    const-string v0, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 AND schedule_requested_at=-1 ORDER BY period_start_time LIMIT (SELECT MAX(?-COUNT(*), 0) FROM workspec WHERE schedule_requested_at<>-1 AND state NOT IN (2, 3, 5))"

    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-static {v0, v1}, Llq;->r(Ljava/lang/String;I)Llq;

    .line 7
    move-result-object v2

    .line 8
    move/from16 v0, p1

    .line 10
    int-to-long v3, v0

    .line 11
    invoke-virtual {v2, v1, v3, v4}, Llq;->s(IJ)V

    .line 14
    move-object/from16 v3, p0

    .line 16
    iget-object v0, v3, LWorkSpecDao;->a:Ljq;

    .line 18
    invoke-virtual {v0}, Ljq;->b()V

    .line 21
    invoke-virtual {v0, v2}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 24
    move-result-object v4

    .line 25
    :try_start_0
    const-string v0, "required_network_type"

    .line 27
    invoke-static {v4, v0}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 30
    move-result v0

    .line 31
    const-string v5, "requires_charging"

    .line 33
    invoke-static {v4, v5}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 36
    move-result v5

    .line 37
    const-string v6, "requires_device_idle"

    .line 39
    invoke-static {v4, v6}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 42
    move-result v6

    .line 43
    const-string v7, "requires_battery_not_low"

    .line 45
    invoke-static {v4, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 48
    move-result v7

    .line 49
    const-string v8, "requires_storage_not_low"

    .line 51
    invoke-static {v4, v8}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 54
    move-result v8

    .line 55
    const-string v9, "trigger_content_update_delay"

    .line 57
    invoke-static {v4, v9}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 60
    move-result v9

    .line 61
    const-string v10, "trigger_max_content_delay"

    .line 63
    invoke-static {v4, v10}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 66
    move-result v10

    .line 67
    const-string v11, "content_uri_triggers"

    .line 69
    invoke-static {v4, v11}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 72
    move-result v11

    .line 73
    const-string v12, "id"

    .line 75
    invoke-static {v4, v12}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 78
    move-result v12

    .line 79
    const-string v13, "state"

    .line 81
    invoke-static {v4, v13}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 84
    move-result v13

    .line 85
    const-string v14, "worker_class_name"

    .line 87
    invoke-static {v4, v14}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 90
    move-result v14

    .line 91
    const-string v15, "input_merger_class_name"

    .line 93
    invoke-static {v4, v15}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 96
    move-result v15

    .line 97
    const-string v1, "input"

    .line 99
    invoke-static {v4, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 102
    move-result v1

    .line 103
    const-string v3, "output"

    .line 105
    invoke-static {v4, v3}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 108
    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 109
    move-object/from16 v16, v2

    .line 111
    :try_start_1
    const-string v2, "initial_delay"

    .line 113
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 116
    move-result v2

    .line 117
    move/from16 p1, v2

    .line 119
    const-string v2, "interval_duration"

    .line 121
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 124
    move-result v2

    .line 125
    move/from16 v17, v2

    .line 127
    const-string v2, "flex_duration"

    .line 129
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 132
    move-result v2

    .line 133
    move/from16 v18, v2

    .line 135
    const-string v2, "run_attempt_count"

    .line 137
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 140
    move-result v2

    .line 141
    move/from16 v19, v2

    .line 143
    const-string v2, "backoff_policy"

    .line 145
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 148
    move-result v2

    .line 149
    move/from16 v20, v2

    .line 151
    const-string v2, "backoff_delay_duration"

    .line 153
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 156
    move-result v2

    .line 157
    move/from16 v21, v2

    .line 159
    const-string v2, "period_start_time"

    .line 161
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 164
    move-result v2

    .line 165
    move/from16 v22, v2

    .line 167
    const-string v2, "minimum_retention_duration"

    .line 169
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 172
    move-result v2

    .line 173
    move/from16 v23, v2

    .line 175
    const-string v2, "schedule_requested_at"

    .line 177
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 180
    move-result v2

    .line 181
    move/from16 v24, v2

    .line 183
    const-string v2, "run_in_foreground"

    .line 185
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 188
    move-result v2

    .line 189
    move/from16 v25, v2

    .line 191
    const-string v2, "out_of_quota_policy"

    .line 193
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 196
    move-result v2

    .line 197
    move/from16 v26, v2

    .line 199
    new-instance v2, Ljava/util/ArrayList;

    .line 201
    move/from16 v27, v3

    .line 203
    invoke-interface {v4}, Landroid/database/Cursor;->getCount()I

    .line 206
    move-result v3

    .line 207
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 210
    :goto_0
    invoke-interface {v4}, Landroid/database/Cursor;->moveToNext()Z

    .line 213
    move-result v3

    .line 214
    if-eqz v3, :cond_5

    .line 216
    invoke-interface {v4, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 219
    move-result-object v3

    .line 220
    move/from16 v28, v12

    .line 222
    invoke-interface {v4, v14}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 225
    move-result-object v12

    .line 226
    move/from16 v29, v14

    .line 228
    new-instance v14, Lf8;

    .line 230
    invoke-direct {v14}, Lf8;-><init>()V

    .line 233
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 236
    move-result v30

    .line 237
    move/from16 v31, v0

    .line 239
    invoke-static/range {v30 .. v30}, Lf10;->c(I)Lqm;

    .line 242
    move-result-object v0

    .line 243
    iput-object v0, v14, Lf8;->a:Lqm;

    .line 245
    invoke-interface {v4, v5}, Landroid/database/Cursor;->getInt(I)I

    .line 248
    move-result v0

    .line 249
    const/16 v30, 0x0

    .line 251
    if-eqz v0, :cond_0

    .line 253
    const/4 v0, 0x1

    .line 254
    goto :goto_1

    .line 255
    :cond_0
    const/4 v0, 0x0

    .line 256
    :goto_1
    iput-boolean v0, v14, Lf8;->b:Z

    .line 258
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getInt(I)I

    .line 261
    move-result v0

    .line 262
    if-eqz v0, :cond_1

    .line 264
    const/4 v0, 0x1

    .line 265
    goto :goto_2

    .line 266
    :cond_1
    const/4 v0, 0x0

    .line 267
    :goto_2
    iput-boolean v0, v14, Lf8;->c:Z

    .line 269
    invoke-interface {v4, v7}, Landroid/database/Cursor;->getInt(I)I

    .line 272
    move-result v0

    .line 273
    if-eqz v0, :cond_2

    .line 275
    const/4 v0, 0x1

    .line 276
    goto :goto_3

    .line 277
    :cond_2
    const/4 v0, 0x0

    .line 278
    :goto_3
    iput-boolean v0, v14, Lf8;->d:Z

    .line 280
    invoke-interface {v4, v8}, Landroid/database/Cursor;->getInt(I)I

    .line 283
    move-result v0

    .line 284
    if-eqz v0, :cond_3

    .line 286
    const/4 v0, 0x1

    .line 287
    goto :goto_4

    .line 288
    :cond_3
    const/4 v0, 0x0

    .line 289
    :goto_4
    iput-boolean v0, v14, Lf8;->e:Z

    .line 291
    move v0, v5

    .line 292
    move/from16 v32, v6

    .line 294
    invoke-interface {v4, v9}, Landroid/database/Cursor;->getLong(I)J

    .line 297
    move-result-wide v5

    .line 298
    iput-wide v5, v14, Lf8;->f:J

    .line 300
    invoke-interface {v4, v10}, Landroid/database/Cursor;->getLong(I)J

    .line 303
    move-result-wide v5

    .line 304
    iput-wide v5, v14, Lf8;->g:J

    .line 306
    invoke-interface {v4, v11}, Landroid/database/Cursor;->getBlob(I)[B

    .line 309
    move-result-object v5

    .line 310
    invoke-static {v5}, Lf10;->a([B)Ll8;

    .line 313
    move-result-object v5

    .line 314
    iput-object v5, v14, Lf8;->h:Ll8;

    .line 316
    new-instance v5, LWorkSpec;

    .line 318
    invoke-direct {v5, v3, v12}, LWorkSpec;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 321
    invoke-interface {v4, v13}, Landroid/database/Cursor;->getInt(I)I

    .line 324
    move-result v3

    .line 325
    invoke-static {v3}, Lf10;->e(I)LWorkInfo_State;

    .line 328
    move-result-object v3

    .line 329
    iput-object v3, v5, LWorkSpec;->b:LWorkInfo_State;

    .line 331
    invoke-interface {v4, v15}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 334
    move-result-object v3

    .line 335
    iput-object v3, v5, LWorkSpec;->d:Ljava/lang/String;

    .line 337
    invoke-interface {v4, v1}, Landroid/database/Cursor;->getBlob(I)[B

    .line 340
    move-result-object v3

    .line 341
    invoke-static {v3}, Landroidx/work/b;->a([B)Landroidx/work/b;

    .line 344
    move-result-object v3

    .line 345
    iput-object v3, v5, LWorkSpec;->e:Landroidx/work/b;

    .line 347
    move/from16 v3, v27

    .line 349
    invoke-interface {v4, v3}, Landroid/database/Cursor;->getBlob(I)[B

    .line 352
    move-result-object v6

    .line 353
    invoke-static {v6}, Landroidx/work/b;->a([B)Landroidx/work/b;

    .line 356
    move-result-object v6

    .line 357
    iput-object v6, v5, LWorkSpec;->f:Landroidx/work/b;

    .line 359
    move/from16 v6, p1

    .line 361
    move v12, v0

    .line 362
    move/from16 p1, v1

    .line 364
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 367
    move-result-wide v0

    .line 368
    iput-wide v0, v5, LWorkSpec;->g:J

    .line 370
    move v1, v7

    .line 371
    move/from16 v0, v17

    .line 373
    move/from16 v17, v6

    .line 375
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 378
    move-result-wide v6

    .line 379
    iput-wide v6, v5, LWorkSpec;->h:J

    .line 381
    move v7, v0

    .line 382
    move/from16 v6, v18

    .line 384
    move/from16 v18, v1

    .line 386
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 389
    move-result-wide v0

    .line 390
    iput-wide v0, v5, LWorkSpec;->i:J

    .line 392
    move/from16 v0, v19

    .line 394
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 397
    move-result v1

    .line 398
    iput v1, v5, LWorkSpec;->k:I

    .line 400
    move/from16 v1, v20

    .line 402
    invoke-interface {v4, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 405
    move-result v19

    .line 406
    move/from16 v20, v0

    .line 408
    invoke-static/range {v19 .. v19}, Lf10;->b(I)I

    .line 411
    move-result v0

    .line 412
    iput v0, v5, LWorkSpec;->l:I

    .line 414
    move/from16 v19, v6

    .line 416
    move/from16 v0, v21

    .line 418
    move/from16 v21, v7

    .line 420
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 423
    move-result-wide v6

    .line 424
    iput-wide v6, v5, LWorkSpec;->m:J

    .line 426
    move v7, v1

    .line 427
    move/from16 v6, v22

    .line 429
    move/from16 v22, v0

    .line 431
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 434
    move-result-wide v0

    .line 435
    iput-wide v0, v5, LWorkSpec;->n:J

    .line 437
    move v1, v6

    .line 438
    move/from16 v0, v23

    .line 440
    move/from16 v23, v7

    .line 442
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 445
    move-result-wide v6

    .line 446
    iput-wide v6, v5, LWorkSpec;->o:J

    .line 448
    move v7, v0

    .line 449
    move/from16 v6, v24

    .line 451
    move/from16 v24, v1

    .line 453
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 456
    move-result-wide v0

    .line 457
    iput-wide v0, v5, LWorkSpec;->p:J

    .line 459
    move/from16 v0, v25

    .line 461
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 464
    move-result v1

    .line 465
    if-eqz v1, :cond_4

    .line 467
    const/4 v1, 0x1

    .line 468
    goto :goto_5

    .line 469
    :cond_4
    const/4 v1, 0x0

    .line 470
    :goto_5
    iput-boolean v1, v5, LWorkSpec;->q:Z

    .line 472
    move/from16 v1, v26

    .line 474
    invoke-interface {v4, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 477
    move-result v25

    .line 478
    move/from16 v26, v0

    .line 480
    invoke-static/range {v25 .. v25}, Lf10;->d(I)I

    .line 483
    move-result v0

    .line 484
    iput v0, v5, LWorkSpec;->r:I

    .line 486
    iput-object v14, v5, LWorkSpec;->j:Lf8;

    .line 488
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 491
    move/from16 v27, v3

    .line 493
    move v5, v12

    .line 494
    move/from16 v25, v26

    .line 496
    move/from16 v12, v28

    .line 498
    move/from16 v14, v29

    .line 500
    move/from16 v0, v31

    .line 502
    move/from16 v26, v1

    .line 504
    move/from16 v1, p1

    .line 506
    move/from16 p1, v17

    .line 508
    move/from16 v17, v21

    .line 510
    move/from16 v21, v22

    .line 512
    move/from16 v22, v24

    .line 514
    move/from16 v24, v6

    .line 516
    move/from16 v6, v32

    .line 518
    move/from16 v33, v23

    .line 520
    move/from16 v23, v7

    .line 522
    move/from16 v7, v18

    .line 524
    move/from16 v18, v19

    .line 526
    move/from16 v19, v20

    .line 528
    move/from16 v20, v33

    .line 530
    goto/16 :goto_0

    .line 532
    :cond_5
    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    .line 535
    invoke-virtual/range {v16 .. v16}, Llq;->v()V

    .line 538
    return-object v2

    .line 539
    :catchall_0
    move-exception v0

    .line 540
    goto :goto_6

    .line 541
    :catchall_1
    move-exception v0

    .line 542
    move-object/from16 v16, v2

    .line 544
    :goto_6
    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    .line 547
    invoke-virtual/range {v16 .. v16}, Llq;->v()V

    .line 550
    throw v0
.end method

.method public final d()Ljava/util/ArrayList;
    .locals 35

    .line 1
    const-string v0, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=1"

    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-static {v0, v1}, Llq;->r(Ljava/lang/String;I)Llq;

    .line 7
    move-result-object v2

    .line 8
    move-object/from16 v3, p0

    .line 10
    iget-object v0, v3, LWorkSpecDao;->a:Ljq;

    .line 12
    invoke-virtual {v0}, Ljq;->b()V

    .line 15
    invoke-virtual {v0, v2}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 18
    move-result-object v4

    .line 19
    :try_start_0
    const-string v0, "required_network_type"

    .line 21
    invoke-static {v4, v0}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 24
    move-result v0

    .line 25
    const-string v5, "requires_charging"

    .line 27
    invoke-static {v4, v5}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 30
    move-result v5

    .line 31
    const-string v6, "requires_device_idle"

    .line 33
    invoke-static {v4, v6}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 36
    move-result v6

    .line 37
    const-string v7, "requires_battery_not_low"

    .line 39
    invoke-static {v4, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 42
    move-result v7

    .line 43
    const-string v8, "requires_storage_not_low"

    .line 45
    invoke-static {v4, v8}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 48
    move-result v8

    .line 49
    const-string v9, "trigger_content_update_delay"

    .line 51
    invoke-static {v4, v9}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 54
    move-result v9

    .line 55
    const-string v10, "trigger_max_content_delay"

    .line 57
    invoke-static {v4, v10}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 60
    move-result v10

    .line 61
    const-string v11, "content_uri_triggers"

    .line 63
    invoke-static {v4, v11}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 66
    move-result v11

    .line 67
    const-string v12, "id"

    .line 69
    invoke-static {v4, v12}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 72
    move-result v12

    .line 73
    const-string v13, "state"

    .line 75
    invoke-static {v4, v13}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 78
    move-result v13

    .line 79
    const-string v14, "worker_class_name"

    .line 81
    invoke-static {v4, v14}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 84
    move-result v14

    .line 85
    const-string v15, "input_merger_class_name"

    .line 87
    invoke-static {v4, v15}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 90
    move-result v15

    .line 91
    const-string v1, "input"

    .line 93
    invoke-static {v4, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 96
    move-result v1

    .line 97
    const-string v3, "output"

    .line 99
    invoke-static {v4, v3}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 102
    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 103
    move-object/from16 v16, v2

    .line 105
    :try_start_1
    const-string v2, "initial_delay"

    .line 107
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 110
    move-result v2

    .line 111
    move/from16 v17, v2

    .line 113
    const-string v2, "interval_duration"

    .line 115
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 118
    move-result v2

    .line 119
    move/from16 v18, v2

    .line 121
    const-string v2, "flex_duration"

    .line 123
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 126
    move-result v2

    .line 127
    move/from16 v19, v2

    .line 129
    const-string v2, "run_attempt_count"

    .line 131
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 134
    move-result v2

    .line 135
    move/from16 v20, v2

    .line 137
    const-string v2, "backoff_policy"

    .line 139
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 142
    move-result v2

    .line 143
    move/from16 v21, v2

    .line 145
    const-string v2, "backoff_delay_duration"

    .line 147
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 150
    move-result v2

    .line 151
    move/from16 v22, v2

    .line 153
    const-string v2, "period_start_time"

    .line 155
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 158
    move-result v2

    .line 159
    move/from16 v23, v2

    .line 161
    const-string v2, "minimum_retention_duration"

    .line 163
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 166
    move-result v2

    .line 167
    move/from16 v24, v2

    .line 169
    const-string v2, "schedule_requested_at"

    .line 171
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 174
    move-result v2

    .line 175
    move/from16 v25, v2

    .line 177
    const-string v2, "run_in_foreground"

    .line 179
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 182
    move-result v2

    .line 183
    move/from16 v26, v2

    .line 185
    const-string v2, "out_of_quota_policy"

    .line 187
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 190
    move-result v2

    .line 191
    move/from16 v27, v2

    .line 193
    new-instance v2, Ljava/util/ArrayList;

    .line 195
    move/from16 v28, v3

    .line 197
    invoke-interface {v4}, Landroid/database/Cursor;->getCount()I

    .line 200
    move-result v3

    .line 201
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 204
    :goto_0
    invoke-interface {v4}, Landroid/database/Cursor;->moveToNext()Z

    .line 207
    move-result v3

    .line 208
    if-eqz v3, :cond_5

    .line 210
    invoke-interface {v4, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 213
    move-result-object v3

    .line 214
    move/from16 v29, v12

    .line 216
    invoke-interface {v4, v14}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 219
    move-result-object v12

    .line 220
    move/from16 v30, v14

    .line 222
    new-instance v14, Lf8;

    .line 224
    invoke-direct {v14}, Lf8;-><init>()V

    .line 227
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 230
    move-result v31

    .line 231
    move/from16 v32, v0

    .line 233
    invoke-static/range {v31 .. v31}, Lf10;->c(I)Lqm;

    .line 236
    move-result-object v0

    .line 237
    iput-object v0, v14, Lf8;->a:Lqm;

    .line 239
    invoke-interface {v4, v5}, Landroid/database/Cursor;->getInt(I)I

    .line 242
    move-result v0

    .line 243
    const/16 v31, 0x1

    .line 245
    if-eqz v0, :cond_0

    .line 247
    const/4 v0, 0x1

    .line 248
    goto :goto_1

    .line 249
    :cond_0
    const/4 v0, 0x0

    .line 250
    :goto_1
    iput-boolean v0, v14, Lf8;->b:Z

    .line 252
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getInt(I)I

    .line 255
    move-result v0

    .line 256
    if-eqz v0, :cond_1

    .line 258
    const/4 v0, 0x1

    .line 259
    goto :goto_2

    .line 260
    :cond_1
    const/4 v0, 0x0

    .line 261
    :goto_2
    iput-boolean v0, v14, Lf8;->c:Z

    .line 263
    invoke-interface {v4, v7}, Landroid/database/Cursor;->getInt(I)I

    .line 266
    move-result v0

    .line 267
    if-eqz v0, :cond_2

    .line 269
    const/4 v0, 0x1

    .line 270
    goto :goto_3

    .line 271
    :cond_2
    const/4 v0, 0x0

    .line 272
    :goto_3
    iput-boolean v0, v14, Lf8;->d:Z

    .line 274
    invoke-interface {v4, v8}, Landroid/database/Cursor;->getInt(I)I

    .line 277
    move-result v0

    .line 278
    if-eqz v0, :cond_3

    .line 280
    const/4 v0, 0x1

    .line 281
    goto :goto_4

    .line 282
    :cond_3
    const/4 v0, 0x0

    .line 283
    :goto_4
    iput-boolean v0, v14, Lf8;->e:Z

    .line 285
    move v0, v5

    .line 286
    move/from16 v33, v6

    .line 288
    invoke-interface {v4, v9}, Landroid/database/Cursor;->getLong(I)J

    .line 291
    move-result-wide v5

    .line 292
    iput-wide v5, v14, Lf8;->f:J

    .line 294
    invoke-interface {v4, v10}, Landroid/database/Cursor;->getLong(I)J

    .line 297
    move-result-wide v5

    .line 298
    iput-wide v5, v14, Lf8;->g:J

    .line 300
    invoke-interface {v4, v11}, Landroid/database/Cursor;->getBlob(I)[B

    .line 303
    move-result-object v5

    .line 304
    invoke-static {v5}, Lf10;->a([B)Ll8;

    .line 307
    move-result-object v5

    .line 308
    iput-object v5, v14, Lf8;->h:Ll8;

    .line 310
    new-instance v5, LWorkSpec;

    .line 312
    invoke-direct {v5, v3, v12}, LWorkSpec;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 315
    invoke-interface {v4, v13}, Landroid/database/Cursor;->getInt(I)I

    .line 318
    move-result v3

    .line 319
    invoke-static {v3}, Lf10;->e(I)LWorkInfo_State;

    .line 322
    move-result-object v3

    .line 323
    iput-object v3, v5, LWorkSpec;->b:LWorkInfo_State;

    .line 325
    invoke-interface {v4, v15}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 328
    move-result-object v3

    .line 329
    iput-object v3, v5, LWorkSpec;->d:Ljava/lang/String;

    .line 331
    invoke-interface {v4, v1}, Landroid/database/Cursor;->getBlob(I)[B

    .line 334
    move-result-object v3

    .line 335
    invoke-static {v3}, Landroidx/work/b;->a([B)Landroidx/work/b;

    .line 338
    move-result-object v3

    .line 339
    iput-object v3, v5, LWorkSpec;->e:Landroidx/work/b;

    .line 341
    move/from16 v3, v28

    .line 343
    invoke-interface {v4, v3}, Landroid/database/Cursor;->getBlob(I)[B

    .line 346
    move-result-object v6

    .line 347
    invoke-static {v6}, Landroidx/work/b;->a([B)Landroidx/work/b;

    .line 350
    move-result-object v6

    .line 351
    iput-object v6, v5, LWorkSpec;->f:Landroidx/work/b;

    .line 353
    move v12, v1

    .line 354
    move/from16 v6, v17

    .line 356
    move/from16 v17, v0

    .line 358
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 361
    move-result-wide v0

    .line 362
    iput-wide v0, v5, LWorkSpec;->g:J

    .line 364
    move v1, v7

    .line 365
    move/from16 v0, v18

    .line 367
    move/from16 v18, v6

    .line 369
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 372
    move-result-wide v6

    .line 373
    iput-wide v6, v5, LWorkSpec;->h:J

    .line 375
    move v7, v0

    .line 376
    move/from16 v6, v19

    .line 378
    move/from16 v19, v1

    .line 380
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 383
    move-result-wide v0

    .line 384
    iput-wide v0, v5, LWorkSpec;->i:J

    .line 386
    move/from16 v0, v20

    .line 388
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 391
    move-result v1

    .line 392
    iput v1, v5, LWorkSpec;->k:I

    .line 394
    move/from16 v1, v21

    .line 396
    invoke-interface {v4, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 399
    move-result v20

    .line 400
    move/from16 v21, v0

    .line 402
    invoke-static/range {v20 .. v20}, Lf10;->b(I)I

    .line 405
    move-result v0

    .line 406
    iput v0, v5, LWorkSpec;->l:I

    .line 408
    move/from16 v20, v6

    .line 410
    move/from16 v0, v22

    .line 412
    move/from16 v22, v7

    .line 414
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 417
    move-result-wide v6

    .line 418
    iput-wide v6, v5, LWorkSpec;->m:J

    .line 420
    move v7, v1

    .line 421
    move/from16 v6, v23

    .line 423
    move/from16 v23, v0

    .line 425
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 428
    move-result-wide v0

    .line 429
    iput-wide v0, v5, LWorkSpec;->n:J

    .line 431
    move v1, v6

    .line 432
    move/from16 v0, v24

    .line 434
    move/from16 v24, v7

    .line 436
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 439
    move-result-wide v6

    .line 440
    iput-wide v6, v5, LWorkSpec;->o:J

    .line 442
    move v7, v0

    .line 443
    move/from16 v6, v25

    .line 445
    move/from16 v25, v1

    .line 447
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 450
    move-result-wide v0

    .line 451
    iput-wide v0, v5, LWorkSpec;->p:J

    .line 453
    move/from16 v0, v26

    .line 455
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 458
    move-result v1

    .line 459
    if-eqz v1, :cond_4

    .line 461
    const/4 v1, 0x1

    .line 462
    goto :goto_5

    .line 463
    :cond_4
    const/4 v1, 0x0

    .line 464
    :goto_5
    iput-boolean v1, v5, LWorkSpec;->q:Z

    .line 466
    move/from16 v1, v27

    .line 468
    invoke-interface {v4, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 471
    move-result v26

    .line 472
    move/from16 v27, v0

    .line 474
    invoke-static/range {v26 .. v26}, Lf10;->d(I)I

    .line 477
    move-result v0

    .line 478
    iput v0, v5, LWorkSpec;->r:I

    .line 480
    iput-object v14, v5, LWorkSpec;->j:Lf8;

    .line 482
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 485
    move/from16 v28, v3

    .line 487
    move/from16 v5, v17

    .line 489
    move/from16 v17, v18

    .line 491
    move/from16 v18, v22

    .line 493
    move/from16 v22, v23

    .line 495
    move/from16 v23, v25

    .line 497
    move/from16 v26, v27

    .line 499
    move/from16 v14, v30

    .line 501
    move/from16 v0, v32

    .line 503
    move/from16 v27, v1

    .line 505
    move/from16 v25, v6

    .line 507
    move v1, v12

    .line 508
    move/from16 v12, v29

    .line 510
    move/from16 v6, v33

    .line 512
    move/from16 v34, v24

    .line 514
    move/from16 v24, v7

    .line 516
    move/from16 v7, v19

    .line 518
    move/from16 v19, v20

    .line 520
    move/from16 v20, v21

    .line 522
    move/from16 v21, v34

    .line 524
    goto/16 :goto_0

    .line 526
    :cond_5
    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    .line 529
    invoke-virtual/range {v16 .. v16}, Llq;->v()V

    .line 532
    return-object v2

    .line 533
    :catchall_0
    move-exception v0

    .line 534
    goto :goto_6

    .line 535
    :catchall_1
    move-exception v0

    .line 536
    move-object/from16 v16, v2

    .line 538
    :goto_6
    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    .line 541
    invoke-virtual/range {v16 .. v16}, Llq;->v()V

    .line 544
    throw v0
.end method

.method public final e()Ljava/util/ArrayList;
    .locals 35

    .line 1
    const-string v0, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 AND schedule_requested_at<>-1"

    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-static {v0, v1}, Llq;->r(Ljava/lang/String;I)Llq;

    .line 7
    move-result-object v2

    .line 8
    move-object/from16 v3, p0

    .line 10
    iget-object v0, v3, LWorkSpecDao;->a:Ljq;

    .line 12
    invoke-virtual {v0}, Ljq;->b()V

    .line 15
    invoke-virtual {v0, v2}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 18
    move-result-object v4

    .line 19
    :try_start_0
    const-string v0, "required_network_type"

    .line 21
    invoke-static {v4, v0}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 24
    move-result v0

    .line 25
    const-string v5, "requires_charging"

    .line 27
    invoke-static {v4, v5}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 30
    move-result v5

    .line 31
    const-string v6, "requires_device_idle"

    .line 33
    invoke-static {v4, v6}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 36
    move-result v6

    .line 37
    const-string v7, "requires_battery_not_low"

    .line 39
    invoke-static {v4, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 42
    move-result v7

    .line 43
    const-string v8, "requires_storage_not_low"

    .line 45
    invoke-static {v4, v8}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 48
    move-result v8

    .line 49
    const-string v9, "trigger_content_update_delay"

    .line 51
    invoke-static {v4, v9}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 54
    move-result v9

    .line 55
    const-string v10, "trigger_max_content_delay"

    .line 57
    invoke-static {v4, v10}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 60
    move-result v10

    .line 61
    const-string v11, "content_uri_triggers"

    .line 63
    invoke-static {v4, v11}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 66
    move-result v11

    .line 67
    const-string v12, "id"

    .line 69
    invoke-static {v4, v12}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 72
    move-result v12

    .line 73
    const-string v13, "state"

    .line 75
    invoke-static {v4, v13}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 78
    move-result v13

    .line 79
    const-string v14, "worker_class_name"

    .line 81
    invoke-static {v4, v14}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 84
    move-result v14

    .line 85
    const-string v15, "input_merger_class_name"

    .line 87
    invoke-static {v4, v15}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 90
    move-result v15

    .line 91
    const-string v1, "input"

    .line 93
    invoke-static {v4, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 96
    move-result v1

    .line 97
    const-string v3, "output"

    .line 99
    invoke-static {v4, v3}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 102
    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 103
    move-object/from16 v16, v2

    .line 105
    :try_start_1
    const-string v2, "initial_delay"

    .line 107
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 110
    move-result v2

    .line 111
    move/from16 v17, v2

    .line 113
    const-string v2, "interval_duration"

    .line 115
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 118
    move-result v2

    .line 119
    move/from16 v18, v2

    .line 121
    const-string v2, "flex_duration"

    .line 123
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 126
    move-result v2

    .line 127
    move/from16 v19, v2

    .line 129
    const-string v2, "run_attempt_count"

    .line 131
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 134
    move-result v2

    .line 135
    move/from16 v20, v2

    .line 137
    const-string v2, "backoff_policy"

    .line 139
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 142
    move-result v2

    .line 143
    move/from16 v21, v2

    .line 145
    const-string v2, "backoff_delay_duration"

    .line 147
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 150
    move-result v2

    .line 151
    move/from16 v22, v2

    .line 153
    const-string v2, "period_start_time"

    .line 155
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 158
    move-result v2

    .line 159
    move/from16 v23, v2

    .line 161
    const-string v2, "minimum_retention_duration"

    .line 163
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 166
    move-result v2

    .line 167
    move/from16 v24, v2

    .line 169
    const-string v2, "schedule_requested_at"

    .line 171
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 174
    move-result v2

    .line 175
    move/from16 v25, v2

    .line 177
    const-string v2, "run_in_foreground"

    .line 179
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 182
    move-result v2

    .line 183
    move/from16 v26, v2

    .line 185
    const-string v2, "out_of_quota_policy"

    .line 187
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 190
    move-result v2

    .line 191
    move/from16 v27, v2

    .line 193
    new-instance v2, Ljava/util/ArrayList;

    .line 195
    move/from16 v28, v3

    .line 197
    invoke-interface {v4}, Landroid/database/Cursor;->getCount()I

    .line 200
    move-result v3

    .line 201
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 204
    :goto_0
    invoke-interface {v4}, Landroid/database/Cursor;->moveToNext()Z

    .line 207
    move-result v3

    .line 208
    if-eqz v3, :cond_5

    .line 210
    invoke-interface {v4, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 213
    move-result-object v3

    .line 214
    move/from16 v29, v12

    .line 216
    invoke-interface {v4, v14}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 219
    move-result-object v12

    .line 220
    move/from16 v30, v14

    .line 222
    new-instance v14, Lf8;

    .line 224
    invoke-direct {v14}, Lf8;-><init>()V

    .line 227
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 230
    move-result v31

    .line 231
    move/from16 v32, v0

    .line 233
    invoke-static/range {v31 .. v31}, Lf10;->c(I)Lqm;

    .line 236
    move-result-object v0

    .line 237
    iput-object v0, v14, Lf8;->a:Lqm;

    .line 239
    invoke-interface {v4, v5}, Landroid/database/Cursor;->getInt(I)I

    .line 242
    move-result v0

    .line 243
    const/16 v31, 0x1

    .line 245
    if-eqz v0, :cond_0

    .line 247
    const/4 v0, 0x1

    .line 248
    goto :goto_1

    .line 249
    :cond_0
    const/4 v0, 0x0

    .line 250
    :goto_1
    iput-boolean v0, v14, Lf8;->b:Z

    .line 252
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getInt(I)I

    .line 255
    move-result v0

    .line 256
    if-eqz v0, :cond_1

    .line 258
    const/4 v0, 0x1

    .line 259
    goto :goto_2

    .line 260
    :cond_1
    const/4 v0, 0x0

    .line 261
    :goto_2
    iput-boolean v0, v14, Lf8;->c:Z

    .line 263
    invoke-interface {v4, v7}, Landroid/database/Cursor;->getInt(I)I

    .line 266
    move-result v0

    .line 267
    if-eqz v0, :cond_2

    .line 269
    const/4 v0, 0x1

    .line 270
    goto :goto_3

    .line 271
    :cond_2
    const/4 v0, 0x0

    .line 272
    :goto_3
    iput-boolean v0, v14, Lf8;->d:Z

    .line 274
    invoke-interface {v4, v8}, Landroid/database/Cursor;->getInt(I)I

    .line 277
    move-result v0

    .line 278
    if-eqz v0, :cond_3

    .line 280
    const/4 v0, 0x1

    .line 281
    goto :goto_4

    .line 282
    :cond_3
    const/4 v0, 0x0

    .line 283
    :goto_4
    iput-boolean v0, v14, Lf8;->e:Z

    .line 285
    move v0, v5

    .line 286
    move/from16 v33, v6

    .line 288
    invoke-interface {v4, v9}, Landroid/database/Cursor;->getLong(I)J

    .line 291
    move-result-wide v5

    .line 292
    iput-wide v5, v14, Lf8;->f:J

    .line 294
    invoke-interface {v4, v10}, Landroid/database/Cursor;->getLong(I)J

    .line 297
    move-result-wide v5

    .line 298
    iput-wide v5, v14, Lf8;->g:J

    .line 300
    invoke-interface {v4, v11}, Landroid/database/Cursor;->getBlob(I)[B

    .line 303
    move-result-object v5

    .line 304
    invoke-static {v5}, Lf10;->a([B)Ll8;

    .line 307
    move-result-object v5

    .line 308
    iput-object v5, v14, Lf8;->h:Ll8;

    .line 310
    new-instance v5, LWorkSpec;

    .line 312
    invoke-direct {v5, v3, v12}, LWorkSpec;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 315
    invoke-interface {v4, v13}, Landroid/database/Cursor;->getInt(I)I

    .line 318
    move-result v3

    .line 319
    invoke-static {v3}, Lf10;->e(I)LWorkInfo_State;

    .line 322
    move-result-object v3

    .line 323
    iput-object v3, v5, LWorkSpec;->b:LWorkInfo_State;

    .line 325
    invoke-interface {v4, v15}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 328
    move-result-object v3

    .line 329
    iput-object v3, v5, LWorkSpec;->d:Ljava/lang/String;

    .line 331
    invoke-interface {v4, v1}, Landroid/database/Cursor;->getBlob(I)[B

    .line 334
    move-result-object v3

    .line 335
    invoke-static {v3}, Landroidx/work/b;->a([B)Landroidx/work/b;

    .line 338
    move-result-object v3

    .line 339
    iput-object v3, v5, LWorkSpec;->e:Landroidx/work/b;

    .line 341
    move/from16 v3, v28

    .line 343
    invoke-interface {v4, v3}, Landroid/database/Cursor;->getBlob(I)[B

    .line 346
    move-result-object v6

    .line 347
    invoke-static {v6}, Landroidx/work/b;->a([B)Landroidx/work/b;

    .line 350
    move-result-object v6

    .line 351
    iput-object v6, v5, LWorkSpec;->f:Landroidx/work/b;

    .line 353
    move v12, v1

    .line 354
    move/from16 v6, v17

    .line 356
    move/from16 v17, v0

    .line 358
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 361
    move-result-wide v0

    .line 362
    iput-wide v0, v5, LWorkSpec;->g:J

    .line 364
    move v1, v7

    .line 365
    move/from16 v0, v18

    .line 367
    move/from16 v18, v6

    .line 369
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 372
    move-result-wide v6

    .line 373
    iput-wide v6, v5, LWorkSpec;->h:J

    .line 375
    move v7, v0

    .line 376
    move/from16 v6, v19

    .line 378
    move/from16 v19, v1

    .line 380
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 383
    move-result-wide v0

    .line 384
    iput-wide v0, v5, LWorkSpec;->i:J

    .line 386
    move/from16 v0, v20

    .line 388
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 391
    move-result v1

    .line 392
    iput v1, v5, LWorkSpec;->k:I

    .line 394
    move/from16 v1, v21

    .line 396
    invoke-interface {v4, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 399
    move-result v20

    .line 400
    move/from16 v21, v0

    .line 402
    invoke-static/range {v20 .. v20}, Lf10;->b(I)I

    .line 405
    move-result v0

    .line 406
    iput v0, v5, LWorkSpec;->l:I

    .line 408
    move/from16 v20, v6

    .line 410
    move/from16 v0, v22

    .line 412
    move/from16 v22, v7

    .line 414
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 417
    move-result-wide v6

    .line 418
    iput-wide v6, v5, LWorkSpec;->m:J

    .line 420
    move v7, v1

    .line 421
    move/from16 v6, v23

    .line 423
    move/from16 v23, v0

    .line 425
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 428
    move-result-wide v0

    .line 429
    iput-wide v0, v5, LWorkSpec;->n:J

    .line 431
    move v1, v6

    .line 432
    move/from16 v0, v24

    .line 434
    move/from16 v24, v7

    .line 436
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 439
    move-result-wide v6

    .line 440
    iput-wide v6, v5, LWorkSpec;->o:J

    .line 442
    move v7, v0

    .line 443
    move/from16 v6, v25

    .line 445
    move/from16 v25, v1

    .line 447
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 450
    move-result-wide v0

    .line 451
    iput-wide v0, v5, LWorkSpec;->p:J

    .line 453
    move/from16 v0, v26

    .line 455
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 458
    move-result v1

    .line 459
    if-eqz v1, :cond_4

    .line 461
    const/4 v1, 0x1

    .line 462
    goto :goto_5

    .line 463
    :cond_4
    const/4 v1, 0x0

    .line 464
    :goto_5
    iput-boolean v1, v5, LWorkSpec;->q:Z

    .line 466
    move/from16 v1, v27

    .line 468
    invoke-interface {v4, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 471
    move-result v26

    .line 472
    move/from16 v27, v0

    .line 474
    invoke-static/range {v26 .. v26}, Lf10;->d(I)I

    .line 477
    move-result v0

    .line 478
    iput v0, v5, LWorkSpec;->r:I

    .line 480
    iput-object v14, v5, LWorkSpec;->j:Lf8;

    .line 482
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 485
    move/from16 v28, v3

    .line 487
    move/from16 v5, v17

    .line 489
    move/from16 v17, v18

    .line 491
    move/from16 v18, v22

    .line 493
    move/from16 v22, v23

    .line 495
    move/from16 v23, v25

    .line 497
    move/from16 v26, v27

    .line 499
    move/from16 v14, v30

    .line 501
    move/from16 v0, v32

    .line 503
    move/from16 v27, v1

    .line 505
    move/from16 v25, v6

    .line 507
    move v1, v12

    .line 508
    move/from16 v12, v29

    .line 510
    move/from16 v6, v33

    .line 512
    move/from16 v34, v24

    .line 514
    move/from16 v24, v7

    .line 516
    move/from16 v7, v19

    .line 518
    move/from16 v19, v20

    .line 520
    move/from16 v20, v21

    .line 522
    move/from16 v21, v34

    .line 524
    goto/16 :goto_0

    .line 526
    :cond_5
    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    .line 529
    invoke-virtual/range {v16 .. v16}, Llq;->v()V

    .line 532
    return-object v2

    .line 533
    :catchall_0
    move-exception v0

    .line 534
    goto :goto_6

    .line 535
    :catchall_1
    move-exception v0

    .line 536
    move-object/from16 v16, v2

    .line 538
    :goto_6
    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    .line 541
    invoke-virtual/range {v16 .. v16}, Llq;->v()V

    .line 544
    throw v0
.end method

.method public final f(Ljava/lang/String;)LWorkInfo_State;
    .locals 16

    .line 1
    const-string v0,new-instance v15, Ljava/lang/StringBuilder;
    const-string v0,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v0,const-string v0, "SELECT st"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "ate FR"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "OM workspec WHERE id=?"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v0,move-result-object v0

    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-static {v0, v1}, Llq;->r(Ljava/lang/String;I)Llq;

    .line 7
    move-result-object v0

    .line 8
    if-nez p1, :cond_0

    .line 10
    invoke-virtual {v0, v1}, Llq;->t(I)V

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    invoke-virtual {v0, p1, v1}, Llq;->u(Ljava/lang/String;I)V

    .line 17
    :goto_0
    iget-object p1, p0, LWorkSpecDao;->a:Ljq;

    .line 19
    invoke-virtual {p1}, Ljq;->b()V

    .line 22
    invoke-virtual {p1, v0}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 25
    move-result-object p1

    .line 26
    :try_start_0
    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    .line 29
    move-result v1

    .line 30
    if-eqz v1, :cond_1

    .line 32
    const/4 v1, 0x0

    .line 33
    invoke-interface {p1, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 36
    move-result v1

    .line 37
    invoke-static {v1}, Lf10;->e(I)LWorkInfo_State;

    .line 40
    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 41
    goto :goto_1

    .line 42
    :cond_1
    const/4 v1, 0x0

    .line 43
    :goto_1
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 46
    invoke-virtual {v0}, Llq;->v()V

    .line 49
    return-object v1

    .line 50
    :catchall_0
    move-exception v1

    .line 51
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 54
    invoke-virtual {v0}, Llq;->v()V

    .line 57
    throw v1
.end method

.method public final g(Ljava/lang/String;)Ljava/util/ArrayList;
    .locals 16

    .line 1
    const-string v0,new-instance v15, Ljava/lang/StringBuilder;
    const-string v0,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v0,const-string v0, "SELECT id FROM workspe"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "c WHERE state NOT IN (2, "
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "3, 5) AND id IN (SELECT work_spec_id FROM workname WHERE name=?)"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v0,move-result-object v0

    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-static {v0, v1}, Llq;->r(Ljava/lang/String;I)Llq;

    .line 7
    move-result-object v0

    .line 8
    if-nez p1, :cond_0

    .line 10
    invoke-virtual {v0, v1}, Llq;->t(I)V

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    invoke-virtual {v0, p1, v1}, Llq;->u(Ljava/lang/String;I)V

    .line 17
    :goto_0
    iget-object p1, p0, LWorkSpecDao;->a:Ljq;

    .line 19
    invoke-virtual {p1}, Ljq;->b()V

    .line 22
    invoke-virtual {p1, v0}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 25
    move-result-object p1

    .line 26
    :try_start_0
    new-instance v1, Ljava/util/ArrayList;

    .line 28
    invoke-interface {p1}, Landroid/database/Cursor;->getCount()I

    .line 31
    move-result v2

    .line 32
    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 35
    :goto_1
    invoke-interface {p1}, Landroid/database/Cursor;->moveToNext()Z

    .line 38
    move-result v2

    .line 39
    if-eqz v2, :cond_1

    .line 41
    const/4 v2, 0x0

    .line 42
    invoke-interface {p1, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 45
    move-result-object v2

    .line 46
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 49
    goto :goto_1

    .line 50
    :cond_1
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 53
    invoke-virtual {v0}, Llq;->v()V

    .line 56
    return-object v1

    .line 57
    :catchall_0
    move-exception v1

    .line 58
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 61
    invoke-virtual {v0}, Llq;->v()V

    .line 64
    throw v1
.end method

.method public final h(Ljava/lang/String;)LWorkSpec;
    .locals 27

    .line 1
    move-object/from16 v0, p1

    .line 3
    const-string v1, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE id=?"

    .line 5
    const/4 v2, 0x1

    .line 6
    invoke-static {v1, v2}, Llq;->r(Ljava/lang/String;I)Llq;

    .line 9
    move-result-object v1

    .line 10
    if-nez v0, :cond_0

    .line 12
    invoke-virtual {v1, v2}, Llq;->t(I)V

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    invoke-virtual {v1, v0, v2}, Llq;->u(Ljava/lang/String;I)V

    .line 19
    :goto_0
    move-object/from16 v3, p0

    .line 21
    iget-object v0, v3, LWorkSpecDao;->a:Ljq;

    .line 23
    invoke-virtual {v0}, Ljq;->b()V

    .line 26
    invoke-virtual {v0, v1}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 29
    move-result-object v4

    .line 30
    :try_start_0
    const-string v0, "required_network_type"

    .line 32
    invoke-static {v4, v0}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 35
    move-result v0

    .line 36
    const-string v5, "requires_charging"

    .line 38
    invoke-static {v4, v5}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 41
    move-result v5

    .line 42
    const-string v6, "requires_device_idle"

    .line 44
    invoke-static {v4, v6}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 47
    move-result v6

    .line 48
    const-string v7, "requires_battery_not_low"

    .line 50
    invoke-static {v4, v7}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 53
    move-result v7

    .line 54
    const-string v8, "requires_storage_not_low"

    .line 56
    invoke-static {v4, v8}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 59
    move-result v8

    .line 60
    const-string v9, "trigger_content_update_delay"

    .line 62
    invoke-static {v4, v9}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 65
    move-result v9

    .line 66
    const-string v10, "trigger_max_content_delay"

    .line 68
    invoke-static {v4, v10}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 71
    move-result v10

    .line 72
    const-string v11, "content_uri_triggers"

    .line 74
    invoke-static {v4, v11}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 77
    move-result v11

    .line 78
    const-string v12, "id"

    .line 80
    invoke-static {v4, v12}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 83
    move-result v12

    .line 84
    const-string v13, "state"

    .line 86
    invoke-static {v4, v13}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 89
    move-result v13

    .line 90
    const-string v14, "worker_class_name"

    .line 92
    invoke-static {v4, v14}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 95
    move-result v14

    .line 96
    const-string v15, "input_merger_class_name"

    .line 98
    invoke-static {v4, v15}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 101
    move-result v15

    .line 102
    const-string v2, "input"

    .line 104
    invoke-static {v4, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 107
    move-result v2

    .line 108
    const-string v3, "output"

    .line 110
    invoke-static {v4, v3}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 113
    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 114
    move-object/from16 v16, v1

    .line 116
    :try_start_1
    const-string v1, "initial_delay"

    .line 118
    invoke-static {v4, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 121
    move-result v1

    .line 122
    move/from16 p1, v1

    .line 124
    const-string v1, "interval_duration"

    .line 126
    invoke-static {v4, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 129
    move-result v1

    .line 130
    move/from16 v17, v1

    .line 132
    const-string v1, "flex_duration"

    .line 134
    invoke-static {v4, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 137
    move-result v1

    .line 138
    move/from16 v18, v1

    .line 140
    const-string v1, "run_attempt_count"

    .line 142
    invoke-static {v4, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 145
    move-result v1

    .line 146
    move/from16 v19, v1

    .line 148
    const-string v1, "backoff_policy"

    .line 150
    invoke-static {v4, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 153
    move-result v1

    .line 154
    move/from16 v20, v1

    .line 156
    const-string v1, "backoff_delay_duration"

    .line 158
    invoke-static {v4, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 161
    move-result v1

    .line 162
    move/from16 v21, v1

    .line 164
    const-string v1, "period_start_time"

    .line 166
    invoke-static {v4, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 169
    move-result v1

    .line 170
    move/from16 v22, v1

    .line 172
    const-string v1, "minimum_retention_duration"

    .line 174
    invoke-static {v4, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 177
    move-result v1

    .line 178
    move/from16 v23, v1

    .line 180
    const-string v1, "schedule_requested_at"

    .line 182
    invoke-static {v4, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 185
    move-result v1

    .line 186
    move/from16 v24, v1

    .line 188
    const-string v1, "run_in_foreground"

    .line 190
    invoke-static {v4, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 193
    move-result v1

    .line 194
    move/from16 v25, v1

    .line 196
    const-string v1, "out_of_quota_policy"

    .line 198
    invoke-static {v4, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 201
    move-result v1

    .line 202
    invoke-interface {v4}, Landroid/database/Cursor;->moveToFirst()Z

    .line 205
    move-result v26

    .line 206
    if-eqz v26, :cond_6

    .line 208
    invoke-interface {v4, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 211
    move-result-object v12

    .line 212
    invoke-interface {v4, v14}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 215
    move-result-object v14

    .line 216
    move/from16 v26, v1

    .line 218
    new-instance v1, Lf8;

    .line 220
    invoke-direct {v1}, Lf8;-><init>()V

    .line 223
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 226
    move-result v0

    .line 227
    invoke-static {v0}, Lf10;->c(I)Lqm;

    .line 230
    move-result-object v0

    .line 231
    iput-object v0, v1, Lf8;->a:Lqm;

    .line 233
    invoke-interface {v4, v5}, Landroid/database/Cursor;->getInt(I)I

    .line 236
    move-result v0

    .line 237
    const/4 v5, 0x0

    .line 238
    if-eqz v0, :cond_1

    .line 240
    const/4 v0, 0x1

    .line 241
    goto :goto_1

    .line 242
    :cond_1
    const/4 v0, 0x0

    .line 243
    :goto_1
    iput-boolean v0, v1, Lf8;->b:Z

    .line 245
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getInt(I)I

    .line 248
    move-result v0

    .line 249
    if-eqz v0, :cond_2

    .line 251
    const/4 v0, 0x1

    .line 252
    goto :goto_2

    .line 253
    :cond_2
    const/4 v0, 0x0

    .line 254
    :goto_2
    iput-boolean v0, v1, Lf8;->c:Z

    .line 256
    invoke-interface {v4, v7}, Landroid/database/Cursor;->getInt(I)I

    .line 259
    move-result v0

    .line 260
    if-eqz v0, :cond_3

    .line 262
    const/4 v0, 0x1

    .line 263
    goto :goto_3

    .line 264
    :cond_3
    const/4 v0, 0x0

    .line 265
    :goto_3
    iput-boolean v0, v1, Lf8;->d:Z

    .line 267
    invoke-interface {v4, v8}, Landroid/database/Cursor;->getInt(I)I

    .line 270
    move-result v0

    .line 271
    if-eqz v0, :cond_4

    .line 273
    const/4 v0, 0x1

    .line 274
    goto :goto_4

    .line 275
    :cond_4
    const/4 v0, 0x0

    .line 276
    :goto_4
    iput-boolean v0, v1, Lf8;->e:Z

    .line 278
    invoke-interface {v4, v9}, Landroid/database/Cursor;->getLong(I)J

    .line 281
    move-result-wide v6

    .line 282
    iput-wide v6, v1, Lf8;->f:J

    .line 284
    invoke-interface {v4, v10}, Landroid/database/Cursor;->getLong(I)J

    .line 287
    move-result-wide v6

    .line 288
    iput-wide v6, v1, Lf8;->g:J

    .line 290
    invoke-interface {v4, v11}, Landroid/database/Cursor;->getBlob(I)[B

    .line 293
    move-result-object v0

    .line 294
    invoke-static {v0}, Lf10;->a([B)Ll8;

    .line 297
    move-result-object v0

    .line 298
    iput-object v0, v1, Lf8;->h:Ll8;

    .line 300
    new-instance v0, LWorkSpec;

    .line 302
    invoke-direct {v0, v12, v14}, LWorkSpec;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 305
    invoke-interface {v4, v13}, Landroid/database/Cursor;->getInt(I)I

    .line 308
    move-result v6

    .line 309
    invoke-static {v6}, Lf10;->e(I)LWorkInfo_State;

    .line 312
    move-result-object v6

    .line 313
    iput-object v6, v0, LWorkSpec;->b:LWorkInfo_State;

    .line 315
    invoke-interface {v4, v15}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 318
    move-result-object v6

    .line 319
    iput-object v6, v0, LWorkSpec;->d:Ljava/lang/String;

    .line 321
    invoke-interface {v4, v2}, Landroid/database/Cursor;->getBlob(I)[B

    .line 324
    move-result-object v2

    .line 325
    invoke-static {v2}, Landroidx/work/b;->a([B)Landroidx/work/b;

    .line 328
    move-result-object v2

    .line 329
    iput-object v2, v0, LWorkSpec;->e:Landroidx/work/b;

    .line 331
    invoke-interface {v4, v3}, Landroid/database/Cursor;->getBlob(I)[B

    .line 334
    move-result-object v2

    .line 335
    invoke-static {v2}, Landroidx/work/b;->a([B)Landroidx/work/b;

    .line 338
    move-result-object v2

    .line 339
    iput-object v2, v0, LWorkSpec;->f:Landroidx/work/b;

    .line 341
    move/from16 v2, p1

    .line 343
    invoke-interface {v4, v2}, Landroid/database/Cursor;->getLong(I)J

    .line 346
    move-result-wide v2

    .line 347
    iput-wide v2, v0, LWorkSpec;->g:J

    .line 349
    move/from16 v2, v17

    .line 351
    invoke-interface {v4, v2}, Landroid/database/Cursor;->getLong(I)J

    .line 354
    move-result-wide v2

    .line 355
    iput-wide v2, v0, LWorkSpec;->h:J

    .line 357
    move/from16 v2, v18

    .line 359
    invoke-interface {v4, v2}, Landroid/database/Cursor;->getLong(I)J

    .line 362
    move-result-wide v2

    .line 363
    iput-wide v2, v0, LWorkSpec;->i:J

    .line 365
    move/from16 v2, v19

    .line 367
    invoke-interface {v4, v2}, Landroid/database/Cursor;->getInt(I)I

    .line 370
    move-result v2

    .line 371
    iput v2, v0, LWorkSpec;->k:I

    .line 373
    move/from16 v2, v20

    .line 375
    invoke-interface {v4, v2}, Landroid/database/Cursor;->getInt(I)I

    .line 378
    move-result v2

    .line 379
    invoke-static {v2}, Lf10;->b(I)I

    .line 382
    move-result v2

    .line 383
    iput v2, v0, LWorkSpec;->l:I

    .line 385
    move/from16 v2, v21

    .line 387
    invoke-interface {v4, v2}, Landroid/database/Cursor;->getLong(I)J

    .line 390
    move-result-wide v2

    .line 391
    iput-wide v2, v0, LWorkSpec;->m:J

    .line 393
    move/from16 v2, v22

    .line 395
    invoke-interface {v4, v2}, Landroid/database/Cursor;->getLong(I)J

    .line 398
    move-result-wide v2

    .line 399
    iput-wide v2, v0, LWorkSpec;->n:J

    .line 401
    move/from16 v2, v23

    .line 403
    invoke-interface {v4, v2}, Landroid/database/Cursor;->getLong(I)J

    .line 406
    move-result-wide v2

    .line 407
    iput-wide v2, v0, LWorkSpec;->o:J

    .line 409
    move/from16 v2, v24

    .line 411
    invoke-interface {v4, v2}, Landroid/database/Cursor;->getLong(I)J

    .line 414
    move-result-wide v2

    .line 415
    iput-wide v2, v0, LWorkSpec;->p:J

    .line 417
    move/from16 v2, v25

    .line 419
    invoke-interface {v4, v2}, Landroid/database/Cursor;->getInt(I)I

    .line 422
    move-result v2

    .line 423
    if-eqz v2, :cond_5

    .line 425
    const/4 v2, 0x1

    .line 426
    goto :goto_5

    .line 427
    :cond_5
    const/4 v2, 0x0

    .line 428
    :goto_5
    iput-boolean v2, v0, LWorkSpec;->q:Z

    .line 430
    move/from16 v2, v26

    .line 432
    invoke-interface {v4, v2}, Landroid/database/Cursor;->getInt(I)I

    .line 435
    move-result v2

    .line 436
    invoke-static {v2}, Lf10;->d(I)I

    .line 439
    move-result v2

    .line 440
    iput v2, v0, LWorkSpec;->r:I

    .line 442
    iput-object v1, v0, LWorkSpec;->j:Lf8;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 444
    goto :goto_6

    .line 445
    :cond_6
    const/4 v0, 0x0

    .line 446
    :goto_6
    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    .line 449
    invoke-virtual/range {v16 .. v16}, Llq;->v()V

    .line 452
    return-object v0

    .line 453
    :catchall_0
    move-exception v0

    .line 454
    goto :goto_7

    .line 455
    :catchall_1
    move-exception v0

    .line 456
    move-object/from16 v16, v1

    .line 458
    :goto_7
    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    .line 461
    invoke-virtual/range {v16 .. v16}, Llq;->v()V

    .line 464
    throw v0
.end method

.method public final i(Ljava/lang/String;)Ljava/util/ArrayList;
    .locals 16

    .line 1
    const-string v0,new-instance v15, Ljava/lang/StringBuilder;
    const-string v0,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v0,const-string v0, "SEL"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "ECT id, state FROM workspec WHE"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "RE id IN (SELECT work_spec_id FROM workname WHERE name=?)"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v0,move-result-object v0

    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-static {v0, v1}, Llq;->r(Ljava/lang/String;I)Llq;

    .line 7
    move-result-object v0

    .line 8
    if-nez p1, :cond_0

    .line 10
    invoke-virtual {v0, v1}, Llq;->t(I)V

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    invoke-virtual {v0, p1, v1}, Llq;->u(Ljava/lang/String;I)V

    .line 17
    :goto_0
    iget-object p1, p0, LWorkSpecDao;->a:Ljq;

    .line 19
    invoke-virtual {p1}, Ljq;->b()V

    .line 22
    invoke-virtual {p1, v0}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 25
    move-result-object p1

    .line 26
    :try_start_0
    const-string v1, "id"

    .line 28
    invoke-static {p1, v1}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 31
    move-result v1

    .line 32
    const-string v2, "state"

    .line 34
    invoke-static {p1, v2}, Lp2;->y(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 37
    move-result v2

    .line 38
    new-instance v3, Ljava/util/ArrayList;

    .line 40
    invoke-interface {p1}, Landroid/database/Cursor;->getCount()I

    .line 43
    move-result v4

    .line 44
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 47
    :goto_1
    invoke-interface {p1}, Landroid/database/Cursor;->moveToNext()Z

    .line 50
    move-result v4

    .line 51
    if-eqz v4, :cond_1

    .line 53
    new-instance v4, LWorkSpec$a;

    .line 55
    invoke-direct {v4}, LWorkSpec$a;-><init>()V

    .line 58
    invoke-interface {p1, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 61
    move-result-object v5

    .line 62
    iput-object v5, v4, LWorkSpec$a;->a:Ljava/lang/String;

    .line 64
    invoke-interface {p1, v2}, Landroid/database/Cursor;->getInt(I)I

    .line 67
    move-result v5

    .line 68
    invoke-static {v5}, Lf10;->e(I)LWorkInfo_State;

    .line 71
    move-result-object v5

    .line 72
    iput-object v5, v4, LWorkSpec$a;->b:LWorkInfo_State;

    .line 74
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 77
    goto :goto_1

    .line 78
    :cond_1
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 81
    invoke-virtual {v0}, Llq;->v()V

    .line 84
    return-object v3

    .line 85
    :catchall_0
    move-exception v1

    .line 86
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 89
    invoke-virtual {v0}, Llq;->v()V

    .line 92
    throw v1
.end method

.method public final j(Ljava/lang/String;J)I
    .locals 16

    .line 1
    iget-object v0, p0, LWorkSpecDao;->a:Ljq;

    .line 3
    invoke-virtual {v0}, Ljq;->b()V

    .line 6
    iget-object v1, p0, LWorkSpecDao;->h:LWorkSpecDao$g;

    .line 8
    invoke-virtual {v1}, Lcs;->a()Lue;

    .line 11
    move-result-object v2

    .line 12
    const/4 v3, 0x1

    .line 13
    invoke-virtual {v2, v3, p2, p3}, Lte;->r(IJ)V

    .line 16
    const/4 p2, 0x2

    .line 17
    if-nez p1, :cond_0

    .line 19
    invoke-virtual {v2, p2}, Lte;->s(I)V

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    invoke-virtual {v2, p1, p2}, Lte;->t(Ljava/lang/String;I)V

    .line 26
    :goto_0
    invoke-virtual {v0}, Ljq;->c()V

    .line 29
    :try_start_0
    invoke-virtual {v2}, Lue;->u()I

    .line 32
    move-result p1

    .line 33
    invoke-virtual {v0}, Ljq;->h()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 36
    invoke-virtual {v0}, Ljq;->f()V

    .line 39
    invoke-virtual {v1, v2}, Lcs;->c(Lue;)V

    .line 42
    return p1

    .line 43
    :catchall_0
    move-exception p1

    .line 44
    invoke-virtual {v0}, Ljq;->f()V

    .line 47
    invoke-virtual {v1, v2}, Lcs;->c(Lue;)V

    .line 50
    throw p1
.end method

.method public final k(Ljava/lang/String;Landroidx/work/b;)V
    .locals 16

    .line 1
    iget-object v0, p0, LWorkSpecDao;->a:Ljq;

    .line 3
    invoke-virtual {v0}, Ljq;->b()V

    .line 6
    iget-object v1, p0, LWorkSpecDao;->d:LWorkSpecDao$c;

    .line 8
    invoke-virtual {v1}, Lcs;->a()Lue;

    .line 11
    move-result-object v2

    .line 12
    invoke-static {p2}, Landroidx/work/b;->b(Landroidx/work/b;)[B

    .line 15
    move-result-object p2

    .line 16
    const/4 v3, 0x1

    .line 17
    if-nez p2, :cond_0

    .line 19
    invoke-virtual {v2, v3}, Lte;->s(I)V

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    invoke-virtual {v2, v3, p2}, Lte;->h(I[B)V

    .line 26
    :goto_0
    const/4 p2, 0x2

    .line 27
    if-nez p1, :cond_1

    .line 29
    invoke-virtual {v2, p2}, Lte;->s(I)V

    .line 32
    goto :goto_1

    .line 33
    :cond_1
    invoke-virtual {v2, p1, p2}, Lte;->t(Ljava/lang/String;I)V

    .line 36
    :goto_1
    invoke-virtual {v0}, Ljq;->c()V

    .line 39
    :try_start_0
    invoke-virtual {v2}, Lue;->u()I

    .line 42
    invoke-virtual {v0}, Ljq;->h()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 45
    invoke-virtual {v0}, Ljq;->f()V

    .line 48
    invoke-virtual {v1, v2}, Lcs;->c(Lue;)V

    .line 51
    return-void

    .line 52
    :catchall_0
    move-exception p1

    .line 53
    invoke-virtual {v0}, Ljq;->f()V

    .line 56
    invoke-virtual {v1, v2}, Lcs;->c(Lue;)V

    .line 59
    throw p1
.end method

.method public final l(Ljava/lang/String;J)V
    .locals 16

    .line 1
    iget-object v0, p0, LWorkSpecDao;->a:Ljq;

    .line 3
    invoke-virtual {v0}, Ljq;->b()V

    .line 6
    iget-object v1, p0, LWorkSpecDao;->e:LWorkSpecDao$d;

    .line 8
    invoke-virtual {v1}, Lcs;->a()Lue;

    .line 11
    move-result-object v2

    .line 12
    const/4 v3, 0x1

    .line 13
    invoke-virtual {v2, v3, p2, p3}, Lte;->r(IJ)V

    .line 16
    const/4 p2, 0x2

    .line 17
    if-nez p1, :cond_0

    .line 19
    invoke-virtual {v2, p2}, Lte;->s(I)V

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    invoke-virtual {v2, p1, p2}, Lte;->t(Ljava/lang/String;I)V

    .line 26
    :goto_0
    invoke-virtual {v0}, Ljq;->c()V

    .line 29
    :try_start_0
    invoke-virtual {v2}, Lue;->u()I

    .line 32
    invoke-virtual {v0}, Ljq;->h()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 35
    invoke-virtual {v0}, Ljq;->f()V

    .line 38
    invoke-virtual {v1, v2}, Lcs;->c(Lue;)V

    .line 41
    return-void

    .line 42
    :catchall_0
    move-exception p1

    .line 43
    invoke-virtual {v0}, Ljq;->f()V

    .line 46
    invoke-virtual {v1, v2}, Lcs;->c(Lue;)V

    .line 49
    throw p1
.end method

.method public final varargs m(LWorkInfo_State;[Ljava/lang/String;)I
    .locals 16

    .line 1
    iget-object v0, p0, LWorkSpecDao;->a:Ljq;

    .line 3
    invoke-virtual {v0}, Ljq;->b()V

    .line 6
    new-instance v1, Ljava/lang/StringBuilder;

    .line 8
    const-string v2,new-instance v15, Ljava/lang/StringBuilder;
    const-string v2,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v2,const-string v2, "UPDATE"
    const-string v2,invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2,const-string v2, " workspec SE"
    const-string v2,invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2,const-string v2, "T state=? WHERE id IN ("
    const-string v2,invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v2,move-result-object v2

    .line 10
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    array-length v2, p2

    .line 14
    const/4 v3, 0x0

    .line 15
    const/4 v4, 0x0

    .line 16
    :goto_0
    if-ge v4, v2, :cond_1

    .line 18
    const-string v5, "?"

    .line 20
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    add-int/lit8 v5, v2, -0x1

    .line 25
    if-ge v4, v5, :cond_0

    .line 27
    const-string v5, ","

    .line 29
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 32
    :cond_0
    add-int/lit8 v4, v4, 0x1

    .line 34
    goto :goto_0

    .line 35
    :cond_1
    const-string v2, ")"

    .line 37
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 43
    move-result-object v1

    .line 44
    invoke-virtual {v0}, Ljq;->a()V

    .line 47
    invoke-virtual {v0}, Ljq;->b()V

    .line 50
    iget-object v2, v0, Ljq;->c:Ltt;

    .line 52
    invoke-interface {v2}, Ltt;->n()Lst;

    .line 55
    move-result-object v2

    .line 56
    check-cast v2, Lqe;

    .line 58
    iget-object v2, v2, Lqe;->c:Landroid/database/sqlite/SQLiteDatabase;

    .line 60
    invoke-virtual {v2, v1}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    .line 63
    move-result-object v1

    .line 64
    invoke-static {p1}, Lf10;->f(LWorkInfo_State;)I

    .line 67
    move-result p1

    .line 68
    int-to-long v4, p1

    .line 69
    const/4 p1, 0x1

    .line 70
    invoke-virtual {v1, p1, v4, v5}, Landroid/database/sqlite/SQLiteProgram;->bindLong(IJ)V

    .line 73
    array-length p1, p2

    .line 74
    const/4 v2, 0x2

    .line 75
    :goto_1
    if-ge v3, p1, :cond_3

    .line 77
    aget-object v4, p2, v3

    .line 79
    if-nez v4, :cond_2

    .line 81
    invoke-virtual {v1, v2}, Landroid/database/sqlite/SQLiteProgram;->bindNull(I)V

    .line 84
    goto :goto_2

    .line 85
    :cond_2
    invoke-virtual {v1, v2, v4}, Landroid/database/sqlite/SQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 88
    :goto_2
    add-int/lit8 v2, v2, 0x1

    .line 90
    add-int/lit8 v3, v3, 0x1

    .line 92
    goto :goto_1

    .line 93
    :cond_3
    invoke-virtual {v0}, Ljq;->c()V

    .line 96
    :try_start_0
    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteStatement;->executeUpdateDelete()I

    .line 99
    move-result p1

    .line 100
    invoke-virtual {v0}, Ljq;->h()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 103
    invoke-virtual {v0}, Ljq;->f()V

    .line 106
    return p1

    .line 107
    :catchall_0
    move-exception p1

    .line 108
    invoke-virtual {v0}, Ljq;->f()V

    .line 111
    throw p1
.end method
