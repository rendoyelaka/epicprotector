.class public final La_369283CB;
.super Ljava/lang/Object;
.source "gosyikus.java"

# compiled-99333

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_C34D4150;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/content/Context;[Landroid/content/Intent;Landroid/os/Bundle;)V
    # ep-qvgcribgvbwj
    .locals 0
    # ep-vwrpzkozssqb

    # ep-mctazqlvhfef
    invoke-virtual {p0, p1, p2}, Landroid/content/Context;->startActivities([Landroid/content/Intent;Landroid/os/Bundle;)V

    # ep-vodacyodknsh
    return-void
.end method

.method public static b(Landroid/content/Context;Landroid/content/Intent;Landroid/os/Bundle;)V
    # ep-tapcwwttpadt
    .locals 0
    # ep-xznqvddcxqva

    # ep-ngrbugfxsvsn
    invoke-virtual {p0, p1, p2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;Landroid/os/Bundle;)V
    # ep-xzfkgxalvygq

    return-void
.end method
