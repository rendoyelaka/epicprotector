.class public interface abstract Ldj;
.super Ljava/lang/Object;
.source "BuilderUtils25.java"
