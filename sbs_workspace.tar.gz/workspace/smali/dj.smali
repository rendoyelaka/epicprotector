.class public interface abstract Ldj;
.super Ljava/lang/Object;
.source "CacheClient99.java"
