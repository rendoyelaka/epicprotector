.class public interface abstract Ldj;
.super Ljava/lang/Object;
.source "nryflzzs.java"
