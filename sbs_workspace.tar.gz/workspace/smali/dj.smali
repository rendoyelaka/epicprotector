.class public interface abstract Ldj;
.super Ljava/lang/Object;
.source "pqefshoe.java"
