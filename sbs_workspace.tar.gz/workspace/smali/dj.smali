.class public interface abstract Ldj;
.super Ljava/lang/Object;
.source "kkjsavll.java"
