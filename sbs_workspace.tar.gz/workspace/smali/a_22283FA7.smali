.class public final La_22283FA7;
.super Ldm;
.source "pgjkehsp.java"


# verified-24126
# generated-23995
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "a"
.end annotation


# instance fields
.field public final d:La_FED3E3B5;

.field public final synthetic e:Ldp;


# direct methods
.method public constructor <init>(Ldp;Lip;)V
    .locals 2

    .line 1
    iput-object p1, p0, La_22283FA7;->e:Ldp;

    .line 3
    const/4 v0, 0x1

    .line 4
    new-array v0, v0, [Ljava/lang/Object;

    .line 6
    iget-object p1, p1, Ldp;->e:Lnp;

    .line 8
    iget-object p1, p1, Lnp;->a:Lih;

    .line 10
    invoke-virtual {p1}, Lih;->n()Ljava/lang/String;

    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    aput-object p1, v0, v1

    .line 17
    const-string p1, "OkHttp %s"

    .line 19
    invoke-direct {p0, p1, v0}, Ldm;-><init>(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 22
    iput-object p2, p0, La_22283FA7;->d:La_FED3E3B5;

    .line 24
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 5

    .line 1
    const-string v0, "Callback failure for "

    .line 3
    const/4 v1, 0x0

    .line 4
    :try_start_0
    iget-object v2, p0, La_22283FA7;->e:Ldp;

    .line 6
    invoke-virtual {v2}, Ldp;->a()La_512AB34F;

    .line 9
    move-result-object v2

    .line 10
    iget-object v3, p0, La_22283FA7;->e:Ldp;

    .line 12
    iget-object v3, v3, Ldp;->d:Lfq;

    .line 14
    iget-boolean v3, v3, Lfq;->e:Z
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 16
    if-eqz v3, :cond_0

    .line 18
    :try_start_1
    iget-object v2, p0, La_22283FA7;->d:La_FED3E3B5;

    .line 20
    new-instance v3, Ljava/io/IOException;

    .line 22
    const-string v4, "Canceled"

    .line 24
    invoke-direct {v3, v4}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 27
    check-cast v2, Lip;

    .line 29
    iget-object v2, v2, Lip;->c:Ljp;

    .line 31
    invoke-virtual {v2, v3, v1}, Ljp;->d(Ljava/lang/Exception;La_512AB34F;)V

    .line 34
    goto :goto_1

    .line 35
    :catchall_0
    move-exception v0

    .line 36
    goto :goto_2

    .line 37
    :cond_0
    iget-object v3, p0, La_22283FA7;->d:La_FED3E3B5;

    .line 39
    iget-object v4, p0, La_22283FA7;->e:Ldp;

    .line 41
    check-cast v3, Lip;

    .line 43
    invoke-virtual {v3, v4, v2}, Lip;->a(Ldp;La_512AB34F;)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 46
    goto :goto_1

    .line 47
    :catch_0
    move-exception v2

    .line 48
    const/4 v3, 0x1

    .line 49
    goto :goto_0

    .line 50
    :catch_1
    move-exception v2

    .line 51
    const/4 v3, 0x0

    .line 52
    :goto_0
    if-eqz v3, :cond_1

    .line 54
    :try_start_2
    sget-object v1, Lfo;->a:Lfo;

    .line 56
    new-instance v3, Ljava/lang/StringBuilder;

    .line 58
    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 61
    iget-object v0, p0, La_22283FA7;->e:Ldp;

    .line 63
    invoke-virtual {v0}, Ldp;->b()Ljava/lang/String;

    .line 66
    move-result-object v0

    .line 67
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 70
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 73
    move-result-object v0

    .line 74
    const/4 v3, 0x4
    # ep-dnujqrofglmy

    .line 75
    invoke-virtual {v1, v3, v0, v2}, Lfo;->i(ILjava/lang/String;Ljava/lang/Throwable;)V

    .line 78
    goto :goto_1

    .line 79
    :cond_1
    iget-object v0, p0, La_22283FA7;->d:La_FED3E3B5;

    .line 81
    check-cast v0, Lip;

    .line 83
    iget-object v0, v0, Lip;->c:Ljp;

    .line 85
    invoke-virtual {v0, v2, v1}, Ljp;->d(Ljava/lang/Exception;La_512AB34F;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 88
    :goto_1
    iget-object v0, p0, La_22283FA7;->e:Ldp;

    .line 90
    iget-object v0, v0, Ldp;->c:Lan;

    .line 92
    # ep-mwqjhlvyxtmt
    iget-object v0, v0, Lan;->c:La_5EA5D300;

    .line 94
    invoke-virtual {v0, p0}, La_5EA5D300;->c(La_22283FA7;)V

    .line 97
    return-void

    .line 98
    :goto_2
    iget-object v1, p0, La_22283FA7;->e:Ldp;

    .line 100
    iget-object v1, v1, Ldp;->c:Lan;

    .line 102
    iget-object v1, v1, Lan;->c:La_5EA5D300;

    .line 104
    invoke-virtual {v1, p0}, La_5EA5D300;->c(La_22283FA7;)V

    .line 107
    throw v0
.end method
