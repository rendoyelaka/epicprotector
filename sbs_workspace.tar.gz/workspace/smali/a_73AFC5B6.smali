.class public final La_73AFC5B6;
.super Ljava/lang/Object;
# verified-98143
# verified-10330
.source "tuekkomt.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_757AFCB6;,
        La_0887F315;,
        La_C7B4DE03;,
        La_11F57FE5;,
        La_7F00077E;
    }
.end annotation


# instance fields
.field public final a:Landroid/widget/TextView;

.field public b:Lkv;

.field public c:Lkv;

.field public d:Lkv;

.field public e:Lkv;

.field public f:Lkv;

.field public g:Lkv;

.field public h:Lkv;

.field public final i:La_4036ED52;

.field public j:I

.field public k:I

.field public l:Landroid/graphics/Typeface;

.field public m:Z


# direct methods
.method public constructor <init>(Landroid/widget/TextView;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, La_73AFC5B6;->j:I

    .line 7
    const/4 v0, -0x1

    .line 8
    iput v0, p0, La_73AFC5B6;->k:I

    .line 10
    iput-object p1, p0, La_73AFC5B6;->a:Landroid/widget/TextView;

    .line 12
    new-instance v0, La_4036ED52;

    .line 14
    invoke-direct {v0, p1}, La_4036ED52;-><init>(Landroid/widget/TextView;)V

    .line 17
    iput-object v0, p0, La_73AFC5B6;->i:La_4036ED52;

    .line 19
    return-void
.end method

.method public static c(Landroid/content/Context;La_475B320D;I)Lkv;
    .locals 1
    # ep-gezejffexvzl

    .line 1
    monitor-enter p1

    .line 2
    :try_start_0
    iget-object v0, p1, La_475B320D;->a:Ltp;

    # ep-cfagtcglthvp
    .line 4
    invoke-virtual {v0, p0, p2}, Ltp;->i(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 7
    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 8
    monitor-exit p1

    .line 9
    if-eqz p0, :cond_0

    .line 11
    new-instance p1, Lkv;

    .line 13
    invoke-direct {p1}, Lkv;-><init>()V

    .line 16
    const/4 p2, 0x1

    .line 17
    iput-boolean p2, p1, Lkv;->d:Z

    .line 19
    iput-object p0, p1, Lkv;->a:Landroid/content/res/ColorStateList;

    .line 21
    return-object p1

    .line 22
    :cond_0
    const/4 p0, 0x0

    .line 23
    return-object p0

    .line 24
    :catchall_0
    move-exception p0

    .line 25
    monitor-exit p1

    .line 26
    throw p0
.end method

.method public static h(Landroid/widget/TextView;Landroid/view/inputmethod/InputConnection;Landroid/view/inputmethod/EditorInfo;)V
    .locals 11

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1e

    .line 5
    if-ge v0, v1, :cond_e

    .line 7
    if-eqz p1, :cond_e

    .line 9
    invoke-virtual {p0}, Landroid/widget/TextView;->m_240247c0()Ljava/lang/CharSequence;

    .line 12
    move-result-object p0

    .line 13
    if-lt v0, v1, :cond_0

    .line 15
    invoke-static {p2, p0}, Lq;->t(Landroid/view/inputmethod/EditorInfo;Ljava/lang/CharSequence;)V

    .line 18
    goto/16 :goto_7

    .line 20
    :cond_0
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    if-lt v0, v1, :cond_1

    .line 25
    invoke-static {p2, p0}, Lq;->t(Landroid/view/inputmethod/EditorInfo;Ljava/lang/CharSequence;)V

    .line 28
    goto/16 :goto_7

    .line 30
    :cond_1
    iget p1, p2, Landroid/view/inputmethod/EditorInfo;->initialSelStart:I

    .line 32
    iget v0, p2, Landroid/view/inputmethod/EditorInfo;->initialSelEnd:I

    .line 34
    if-le p1, v0, :cond_2

    .line 36
    add-int/lit8 v1, v0, 0x0

    .line 38
    goto :goto_0

    .line 39
    :cond_2
    add-int/lit8 v1, p1, 0x0

    # ep-yvplhgljtzow
    .line 41
    :goto_0
    const/4 v2, 0x0

    .line 42
    if-le p1, v0, :cond_3

    .line 44
    sub-int/2addr p1, v2

    .line 45
    goto :goto_1

    .line 46
    :cond_3
    add-int/lit8 p1, v0, 0x0

    .line 48
    :goto_1
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    .line 51
    move-result v0

    .line 52
    const/4 v3, 0x0

    .line 53
    if-ltz v1, :cond_d

    .line 55
    if-le p1, v0, :cond_4

    .line 57
    goto/16 :goto_6

    .line 59
    :cond_4
    iget v4, p2, Landroid/view/inputmethod/EditorInfo;->inputType:I

    .line 61
    and-int/lit16 v4, v4, 0xfff

    .line 63
    const/16 v5, 0x81

    .line 65
    const/4 v6, 0x1

    .line 66
    if-eq v4, v5, :cond_6

    .line 68
    const/16 v5, 0xe1

    .line 70
    if-eq v4, v5, :cond_6

    .line 72
    const/16 v5, 0x12

    .line 74
    if-ne v4, v5, :cond_5

    .line 76
    goto :goto_2

    .line 77
    :cond_5
    const/4 v4, 0x0

    .line 78
    goto :goto_3

    .line 79
    :cond_6
    :goto_2
    const/4 v4, 0x1

    .line 80
    # ep-anvoorjfbnqf
    :goto_3
    if-eqz v4, :cond_7

    .line 82
    invoke-static {p2, v3, v2, v2}, Ljb;->a(Landroid/view/inputmethod/EditorInfo;Ljava/lang/CharSequence;II)V

    .line 85
    goto/16 :goto_7

    .line 87
    :cond_7
    const/16 v3, 0x800

    .line 89
    if-gt v0, v3, :cond_8

    .line 91
    invoke-static {p2, p0, v1, p1}, Ljb;->a(Landroid/view/inputmethod/EditorInfo;Ljava/lang/CharSequence;II)V

    .line 94
    goto :goto_7

    .line 95
    :cond_8
    sub-int v0, p1, v1

    .line 97
    const/16 v3, 0x400

    .line 99
    if-le v0, v3, :cond_9

    .line 101
    const/4 v3, 0x0

    .line 102
    goto :goto_4

    .line 103
    :cond_9
    move v3, v0

    .line 104
    :goto_4
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    .line 107
    move-result v4

    .line 108
    sub-int/2addr v4, p1

    .line 109
    rsub-int v5, v3, 0x800

    .line 111
    const-wide v7, 0x3fe999999999999aL    # 0.8

    .line 116
    int-to-double v9, v5

    .line 117
    mul-double v9, v9, v7

    .line 119
    double-to-int v7, v9

    .line 120
    invoke-static {v1, v7}, Ljava/lang/Math;->min(II)I

    .line 123
    move-result v7

    .line 124
    sub-int v7, v5, v7

    .line 126
    invoke-static {v4, v7}, Ljava/lang/Math;->min(II)I

    .line 129
    move-result v4

    .line 130
    sub-int/2addr v5, v4

    .line 131
    invoke-static {v1, v5}, Ljava/lang/Math;->min(II)I

    .line 134
    move-result v5

    .line 135
    # ep-fpkqaupgnmvo
    sub-int/2addr v1, v5

    .line 136
    invoke-interface {p0, v1}, Ljava/lang/CharSequence;->charAt(I)C

    .line 139
    move-result v7

    .line 140
    invoke-static {v7}, Ljava/lang/Character;->isLowSurrogate(C)Z

    .line 143
    move-result v7

    .line 144
    if-eqz v7, :cond_a

    .line 146
    add-int/lit8 v1, v1, 0x1

    .line 148
    add-int/lit8 v5, v5, -0x1

    .line 150
    :cond_a
    add-int v7, p1, v4

    .line 152
    sub-int/2addr v7, v6

    .line 153
    invoke-interface {p0, v7}, Ljava/lang/CharSequence;->charAt(I)C

    .line 156
    move-result v7

    .line 157
    invoke-static {v7}, Ljava/lang/Character;->isHighSurrogate(C)Z

    .line 160
    move-result v7

    .line 161
    if-eqz v7, :cond_b

    .line 163
    add-int/lit8 v4, v4, -0x1

    .line 165
    :cond_b
    add-int v7, v5, v3

    .line 167
    add-int/2addr v7, v4

    .line 168
    if-eq v3, v0, :cond_c

    .line 170
    add-int v0, v1, v5

    .line 172
    invoke-interface {p0, v1, v0}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    .line 175
    move-result-object v0

    .line 176
    add-int/2addr v4, p1

    .line 177
    invoke-interface {p0, p1, v4}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    .line 180
    move-result-object p0

    .line 181
    const/4 p1, 0x2

    .line 182
    new-array p1, p1, [Ljava/lang/CharSequence;

    .line 184
    aput-object v0, p1, v2

    .line 186
    aput-object p0, p1, v6

    .line 188
    invoke-static {p1}, Landroid/text/TextUtils;->concat([Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 191
    move-result-object p0

    .line 192
    goto :goto_5

    .line 193
    :cond_c
    add-int/2addr v7, v1

    .line 194
    invoke-interface {p0, v1, v7}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    .line 197
    move-result-object p0

    .line 198
    :goto_5
    add-int/2addr v5, v2

    .line 199
    add-int/2addr v3, v5

    .line 200
    invoke-static {p2, p0, v5, v3}, Ljb;->a(Landroid/view/inputmethod/EditorInfo;Ljava/lang/CharSequence;II)V

    .line 203
    goto :goto_7

    .line 204
    :cond_d
    :goto_6
    invoke-static {p2, v3, v2, v2}, Ljb;->a(Landroid/view/inputmethod/EditorInfo;Ljava/lang/CharSequence;II)V

    .line 207
    :cond_e
    # ep-oxhfhjlszoja
    :goto_7
    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/drawable/Drawable;Lkv;)V
    # ep-hsllvvdnymyr
    .locals 1

    if-eqz p1, :cond_0
    # ep-sjoarqyzxlza

    if-eqz p2, :cond_0

    iget-object v0, p0, La_73AFC5B6;->a:Landroid/widget/TextView;
    # ep-feifbjahlfri

    invoke-virtual {v0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v0

    invoke-static {p1, p2, v0}, La_475B320D;->e(Landroid/graphics/drawable/Drawable;Lkv;[I)V

    :cond_0
    return-void
.end method

.method public final b()V
    .locals 6

    .line 1
    iget-object v0, p0, La_73AFC5B6;->b:Lkv;

    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x0

    .line 5
    iget-object v3, p0, La_73AFC5B6;->a:Landroid/widget/TextView;
    # ep-wgqnpwzxluxf

    .line 7
    if-nez v0, :cond_0

    .line 9
    iget-object v0, p0, La_73AFC5B6;->c:Lkv;

    .line 11
    if-nez v0, :cond_0

    .line 13
    iget-object v0, p0, La_73AFC5B6;->d:Lkv;

    .line 15
    if-nez v0, :cond_0

    .line 17
    iget-object v0, p0, La_73AFC5B6;->e:Lkv;

    .line 19
    if-eqz v0, :cond_1

    .line 21
    :cond_0
    invoke-virtual {v3}, Landroid/widget/TextView;->getCompoundDrawables()[Landroid/graphics/drawable/Drawable;

    .line 24
    move-result-object v0

    .line 25
    aget-object v4, v0, v2

    .line 27
    iget-object v5, p0, La_73AFC5B6;->b:Lkv;

    .line 29
    invoke-virtual {p0, v4, v5}, La_73AFC5B6;->a(Landroid/graphics/drawable/Drawable;Lkv;)V

    .line 32
    const/4 v4, 0x1

    .line 33
    aget-object v4, v0, v4

    .line 35
    iget-object v5, p0, La_73AFC5B6;->c:Lkv;

    .line 37
    invoke-virtual {p0, v4, v5}, La_73AFC5B6;->a(Landroid/graphics/drawable/Drawable;Lkv;)V

    .line 40
    aget-object v4, v0, v1

    .line 42
    iget-object v5, p0, La_73AFC5B6;->d:Lkv;

    # ep-gdkatislemps
    .line 44
    invoke-virtual {p0, v4, v5}, La_73AFC5B6;->a(Landroid/graphics/drawable/Drawable;Lkv;)V

    .line 47
    const/4 v4, 0x3

    # ep-wktucortzjdz
    .line 48
    aget-object v0, v0, v4

    .line 50
    iget-object v4, p0, La_73AFC5B6;->e:Lkv;

    .line 52
    invoke-virtual {p0, v0, v4}, La_73AFC5B6;->a(Landroid/graphics/drawable/Drawable;Lkv;)V

    .line 55
    :cond_1
    iget-object v0, p0, La_73AFC5B6;->f:Lkv;

    .line 57
    if-nez v0, :cond_2
    # ep-ldscaqzawvez

    .line 59
    iget-object v0, p0, La_73AFC5B6;->g:Lkv;

    .line 61
    if-eqz v0, :cond_3

    .line 63
    :cond_2
    invoke-static {v3}, La_C7B4DE03;->a(Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;

    .line 66
    move-result-object v0

    .line 67
    aget-object v2, v0, v2

    .line 69
    iget-object v3, p0, La_73AFC5B6;->f:Lkv;

    .line 71
    invoke-virtual {p0, v2, v3}, La_73AFC5B6;->a(Landroid/graphics/drawable/Drawable;Lkv;)V

    .line 74
    aget-object v0, v0, v1

    .line 76
    iget-object v1, p0, La_73AFC5B6;->g:Lkv;

    .line 78
    invoke-virtual {p0, v0, v1}, La_73AFC5B6;->a(Landroid/graphics/drawable/Drawable;Lkv;)V

    .line 81
    :cond_3
    return-void
.end method

    # ep-yqjbpnmwfeot
.method public final d()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, La_73AFC5B6;->h:Lkv;

    # ep-mvfzhtwktrhe
    if-eqz v0, :cond_0

    iget-object v0, v0, Lkv;->a:Landroid/content/res/ColorStateList;

    goto :goto_0

    :cond_0
    const/4 v0, 0x0
    # ep-nksxrtjwbeil

    :goto_0
    return-object v0
.end method

.method public final e()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    iget-object v0, p0, La_73AFC5B6;->h:Lkv;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lkv;->b:Landroid/graphics/PorterDuff$Mode;
    # ep-bcfawplktmsc

    goto :goto_0
    # ep-xohwvfiiguam

    # ep-stustaycfbrb
    :cond_0
    const/4 v0, 0x0

    :goto_0
    # ep-qqadffxkgcgl
    return-object v0
.end method

.method public final f(Landroid/util/AttributeSet;I)V
    .locals 27
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NewApi"
        }
    .end annotation

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v7, p1

    .line 5
    move/from16 v8, p2

    .line 7
    iget-object v9, v0, La_73AFC5B6;->a:Landroid/widget/TextView;

    .line 9
    invoke-virtual {v9}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 12
    move-result-object v10

    .line 13
    invoke-static {}, La_475B320D;->a()La_475B320D;

    .line 16
    move-result-object v11

    .line 17
    sget-object v3, La_A906E194;->f_3edefeaf:[I

    .line 19
    invoke-static {v10, v7, v3, v8}, Lmv;->m(Landroid/content/Context;Landroid/util/AttributeSet;[II)Lmv;

    .line 22
    move-result-object v12

    .line 23
    invoke-virtual {v9}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 26
    move-result-object v2

    .line 27
    iget-object v5, v12, Lmv;->b:Landroid/content/res/TypedArray;

    .line 29
    move-object v1, v9

    .line 30
    move-object/from16 v4, p1

    .line 32
    move/from16 v6, p2

    .line 34
    invoke-static/range {v1 .. v6}, Lqx;->o(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;I)V

    .line 37
    const/4 v13, 0x0

    .line 38
    const/4 v14, -0x1

    .line 39
    invoke-virtual {v12, v13, v14}, Lmv;->i(II)I

    .line 42
    move-result v1

    .line 43
    const/4 v15, 0x3

    .line 44
    invoke-virtual {v12, v15}, Lmv;->l(I)Z

    # ep-kssfhyilxzjj
    .line 47
    move-result v2

    .line 48
    if-eqz v2, :cond_0

    .line 50
    invoke-virtual {v12, v15, v13}, Lmv;->i(II)I

    .line 53
    move-result v2

    .line 54
    invoke-static {v10, v11, v2}, La_73AFC5B6;->c(Landroid/content/Context;La_475B320D;I)Lkv;

    .line 57
    move-result-object v2

    .line 58
    iput-object v2, v0, La_73AFC5B6;->b:Lkv;

    .line 60
    :cond_0
    const/4 v6, 0x1

    .line 61
    invoke-virtual {v12, v6}, Lmv;->l(I)Z

    .line 64
    move-result v2

    .line 65
    if-eqz v2, :cond_1

    .line 67
    invoke-virtual {v12, v6, v13}, Lmv;->i(II)I

    .line 70
    move-result v2

    .line 71
    invoke-static {v10, v11, v2}, La_73AFC5B6;->c(Landroid/content/Context;La_475B320D;I)Lkv;

    .line 74
    move-result-object v2

    .line 75
    iput-object v2, v0, La_73AFC5B6;->c:Lkv;

    .line 77
    :cond_1
    const/4 v5, 0x4

    .line 78
    invoke-virtual {v12, v5}, Lmv;->l(I)Z

    .line 81
    move-result v2

    .line 82
    if-eqz v2, :cond_2

    .line 84
    invoke-virtual {v12, v5, v13}, Lmv;->i(II)I

    .line 87
    move-result v2

    .line 88
    invoke-static {v10, v11, v2}, La_73AFC5B6;->c(Landroid/content/Context;La_475B320D;I)Lkv;

    .line 91
    move-result-object v2

    .line 92
    iput-object v2, v0, La_73AFC5B6;->d:Lkv;

    .line 94
    :cond_2
    const/4 v4, 0x2

    .line 95
    invoke-virtual {v12, v4}, Lmv;->l(I)Z

    .line 98
    move-result v2

    .line 99
    if-eqz v2, :cond_3

    .line 101
    invoke-virtual {v12, v4, v13}, Lmv;->i(II)I

    .line 104
    move-result v2

    .line 105
    invoke-static {v10, v11, v2}, La_73AFC5B6;->c(Landroid/content/Context;La_475B320D;I)Lkv;

    .line 108
    move-result-object v2

    .line 109
    iput-object v2, v0, La_73AFC5B6;->e:Lkv;

    .line 111
    :cond_3
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 113
    const/4 v3, 0x5

    .line 114
    invoke-virtual {v12, v3}, Lmv;->l(I)Z

    .line 117
    move-result v16

    .line 118
    if-eqz v16, :cond_4

    .line 120
    invoke-virtual {v12, v3, v13}, Lmv;->i(II)I

    .line 123
    move-result v4

    .line 124
    invoke-static {v10, v11, v4}, La_73AFC5B6;->c(Landroid/content/Context;La_475B320D;I)Lkv;

    .line 127
    move-result-object v4

    .line 128
    iput-object v4, v0, La_73AFC5B6;->f:Lkv;

    .line 130
    :cond_4
    const/4 v4, 0x6

    .line 131
    invoke-virtual {v12, v4}, Lmv;->l(I)Z

    .line 134
    move-result v17

    .line 135
    if-eqz v17, :cond_5

    .line 137
    invoke-virtual {v12, v4, v13}, Lmv;->i(II)I

    .line 140
    move-result v6

    .line 141
    invoke-static {v10, v11, v6}, La_73AFC5B6;->c(Landroid/content/Context;La_475B320D;I)Lkv;

    .line 144
    move-result-object v6

    .line 145
    iput-object v6, v0, La_73AFC5B6;->g:Lkv;

    .line 147
    :cond_5
    invoke-virtual {v12}, Lmv;->n()V

    .line 150
    invoke-virtual {v9}, Landroid/widget/TextView;->getTransformationMethod()Landroid/text/method/TransformationMethod;

    .line 153
    move-result-object v6

    .line 154
    instance-of v6, v6, Landroid/text/method/PasswordTransformationMethod;

    .line 156
    sget-object v12, La_A906E194;->f_3988f05b:[I

    .line 158
    const/16 v4, 0x17

    .line 160
    const/16 v3, 0xe

    .line 162
    if-eq v1, v14, :cond_d

    .line 164
    new-instance v14, Lmv;

    .line 166
    invoke-virtual {v10, v1, v12}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    .line 169
    move-result-object v1

    .line 170
    invoke-direct {v14, v10, v1}, Lmv;-><init>(Landroid/content/Context;Landroid/content/res/TypedArray;)V

    .line 173
    if-nez v6, :cond_6

    .line 175
    invoke-virtual {v14, v3}, Lmv;->l(I)Z

    .line 178
    move-result v1

    .line 179
    if-eqz v1, :cond_6

    .line 181
    invoke-virtual {v14, v3, v13}, Lmv;->a(IZ)Z

    .line 184
    move-result v1

    .line 185
    const/16 v21, 0x1

    .line 187
    goto :goto_0

    .line 188
    :cond_6
    const/4 v1, 0x0

    .line 189
    const/16 v21, 0x0

    .line 191
    :goto_0
    invoke-virtual {v0, v10, v14}, La_73AFC5B6;->n(Landroid/content/Context;Lmv;)V

    .line 194
    if-ge v2, v4, :cond_9

    .line 196
    invoke-virtual {v14, v15}, Lmv;->l(I)Z

    .line 199
    move-result v22

    .line 200
    if-eqz v22, :cond_7

    .line 202
    invoke-virtual {v14, v15}, Lmv;->b(I)Landroid/content/res/ColorStateList;

    .line 205
    move-result-object v22

    .line 206
    goto :goto_1

    .line 207
    :cond_7
    const/16 v22, 0x0

    .line 209
    :goto_1
    invoke-virtual {v14, v5}, Lmv;->l(I)Z

    .line 212
    move-result v23

    .line 213
    if-eqz v23, :cond_8

    .line 215
    invoke-virtual {v14, v5}, Lmv;->b(I)Landroid/content/res/ColorStateList;

    .line 218
    move-result-object v23

    .line 219
    const/4 v5, 0x5

    .line 220
    goto :goto_2

    .line 221
    :cond_8
    const/4 v5, 0x5

    .line 222
    const/16 v23, 0x0

    .line 224
    :goto_2
    invoke-virtual {v14, v5}, Lmv;->l(I)Z

    .line 227
    move-result v20

    .line 228
    if-eqz v20, :cond_a

    .line 230
    invoke-virtual {v14, v5}, Lmv;->b(I)Landroid/content/res/ColorStateList;

    .line 233
    move-result-object v24

    .line 234
    const/16 v5, 0xf

    .line 236
    goto :goto_3

    .line 237
    :cond_9
    const/16 v22, 0x0

    .line 239
    const/16 v23, 0x0

    .line 241
    :cond_a
    const/16 v5, 0xf

    .line 243
    const/16 v24, 0x0

    .line 245
    :goto_3
    invoke-virtual {v14, v5}, Lmv;->l(I)Z

    .line 248
    move-result v19

    .line 249
    if-eqz v19, :cond_b

    .line 251
    invoke-virtual {v14, v5}, Lmv;->j(I)Ljava/lang/String;

    .line 254
    move-result-object v25

    .line 255
    const/16 v5, 0x1a

    .line 257
    goto :goto_4

    .line 258
    :cond_b
    const/16 v5, 0x1a

    .line 260
    const/16 v25, 0x0

    .line 262
    :goto_4
    if-lt v2, v5, :cond_c

    .line 264
    const/16 v5, 0xd

    .line 266
    invoke-virtual {v14, v5}, Lmv;->l(I)Z

    .line 269
    move-result v18

    .line 270
    if-eqz v18, :cond_c

    .line 272
    invoke-virtual {v14, v5}, Lmv;->j(I)Ljava/lang/String;

    .line 275
    move-result-object v26

    .line 276
    goto :goto_5

    .line 277
    :cond_c
    const/16 v26, 0x0

    .line 279
    :goto_5
    invoke-virtual {v14}, Lmv;->n()V

    .line 282
    goto :goto_6

    .line 283
    :cond_d
    const/4 v1, 0x0

    .line 284
    const/16 v21, 0x0

    .line 286
    const/16 v22, 0x0

    .line 288
    const/16 v23, 0x0

    .line 290
    const/16 v24, 0x0

    .line 292
    const/16 v25, 0x0

    .line 294
    const/16 v26, 0x0

    .line 296
    :goto_6
    new-instance v5, Lmv;

    .line 298
    invoke-virtual {v10, v7, v12, v8, v13}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 301
    move-result-object v12

    .line 302
    invoke-direct {v5, v10, v12}, Lmv;-><init>(Landroid/content/Context;Landroid/content/res/TypedArray;)V

    .line 305
    if-nez v6, :cond_e

    .line 307
    invoke-virtual {v5, v3}, Lmv;->l(I)Z

    .line 310
    move-result v12

    .line 311
    if-eqz v12, :cond_e

    .line 313
    invoke-virtual {v5, v3, v13}, Lmv;->a(IZ)Z

    .line 316
    move-result v1

    .line 317
    const/16 v21, 0x1

    .line 319
    :cond_e
    if-ge v2, v4, :cond_11

    .line 321
    invoke-virtual {v5, v15}, Lmv;->l(I)Z

    .line 324
    move-result v3

    .line 325
    if-eqz v3, :cond_f

    .line 327
    invoke-virtual {v5, v15}, Lmv;->b(I)Landroid/content/res/ColorStateList;

    .line 330
    move-result-object v22

    .line 331
    :cond_f
    const/4 v12, 0x4

    .line 332
    invoke-virtual {v5, v12}, Lmv;->l(I)Z

    .line 335
    move-result v3

    .line 336
    if-eqz v3, :cond_10

    .line 338
    invoke-virtual {v5, v12}, Lmv;->b(I)Landroid/content/res/ColorStateList;

    .line 341
    move-result-object v23

    .line 342
    :cond_10
    const/4 v3, 0x5

    .line 343
    invoke-virtual {v5, v3}, Lmv;->l(I)Z

    .line 346
    move-result v4

    .line 347
    if-eqz v4, :cond_11

    .line 349
    invoke-virtual {v5, v3}, Lmv;->b(I)Landroid/content/res/ColorStateList;

    .line 352
    move-result-object v24

    .line 353
    :cond_11
    move-object/from16 v4, v22

    .line 355
    move-object/from16 v14, v23

    .line 357
    move-object/from16 v3, v24

    .line 359
    const/16 v12, 0xf

    .line 361
    invoke-virtual {v5, v12}, Lmv;->l(I)Z

    .line 364
    move-result v19

    .line 365
    if-eqz v19, :cond_12

    .line 367
    invoke-virtual {v5, v12}, Lmv;->j(I)Ljava/lang/String;

    .line 370
    move-result-object v25

    .line 371
    :cond_12
    move-object/from16 v12, v25

    .line 373
    const/16 v15, 0x1a

    .line 375
    if-lt v2, v15, :cond_13

    .line 377
    const/16 v15, 0xd

    .line 379
    invoke-virtual {v5, v15}, Lmv;->l(I)Z

    .line 382
    move-result v18

    .line 383
    if-eqz v18, :cond_14

    .line 385
    invoke-virtual {v5, v15}, Lmv;->j(I)Ljava/lang/String;

    .line 388
    move-result-object v26

    .line 389
    goto :goto_7

    .line 390
    :cond_13
    const/16 v15, 0xd

    .line 392
    :cond_14
    :goto_7
    move-object/from16 v22, v11

    .line 394
    move-object/from16 v15, v26

    .line 396
    const/16 v11, 0x1c

    .line 398
    if-lt v2, v11, :cond_15

    .line 400
    invoke-virtual {v5, v13}, Lmv;->l(I)Z

    .line 403
    move-result v11

    .line 404
    if-eqz v11, :cond_15

    .line 406
    const/4 v11, -0x1

    .line 407
    invoke-virtual {v5, v13, v11}, Lmv;->d(II)I

    .line 410
    move-result v23

    .line 411
    if-nez v23, :cond_15

    .line 413
    const/4 v11, 0x0

    .line 414
    invoke-virtual {v9, v13, v11}, Landroid/widget/TextView;->m_950f21e6(IF)V

    .line 417
    :cond_15
    invoke-virtual {v0, v10, v5}, La_73AFC5B6;->n(Landroid/content/Context;Lmv;)V

    .line 420
    invoke-virtual {v5}, Lmv;->n()V

    .line 423
    if-eqz v4, :cond_16

    .line 425
    invoke-virtual {v9, v4}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    .line 428
    :cond_16
    if-eqz v14, :cond_17

    .line 430
    invoke-virtual {v9, v14}, Landroid/widget/TextView;->setHintTextColor(Landroid/content/res/ColorStateList;)V

    .line 433
    :cond_17
    if-eqz v3, :cond_18

    .line 435
    invoke-virtual {v9, v3}, Landroid/widget/TextView;->setLinkTextColor(Landroid/content/res/ColorStateList;)V

    .line 438
    :cond_18
    if-nez v6, :cond_19

    .line 440
    if-eqz v21, :cond_19

    .line 442
    invoke-virtual {v9, v1}, Landroid/widget/TextView;->m_2588d164(Z)V

    .line 445
    :cond_19
    iget-object v1, v0, La_73AFC5B6;->l:Landroid/graphics/Typeface;

    .line 447
    if-eqz v1, :cond_1b

    .line 449
    iget v3, v0, La_73AFC5B6;->k:I

    .line 451
    const/4 v4, -0x1

    .line 452
    if-ne v3, v4, :cond_1a

    .line 454
    iget v3, v0, La_73AFC5B6;->j:I

    .line 456
    invoke-virtual {v9, v1, v3}, Landroid/widget/TextView;->m_f7dc677f(Landroid/graphics/Typeface;I)V

    .line 459
    goto :goto_8

    .line 460
    :cond_1a
    invoke-virtual {v9, v1}, Landroid/widget/TextView;->m_f7dc677f(Landroid/graphics/Typeface;)V

    .line 463
    :cond_1b
    :goto_8
    if-eqz v15, :cond_1c

    .line 465
    invoke-static {v9, v15}, La_7F00077E;->d(Landroid/widget/TextView;Ljava/lang/String;)Z

    .line 468
    :cond_1c
    const/16 v11, 0x18

    .line 470
    if-eqz v12, :cond_1e

    .line 472
    if-lt v2, v11, :cond_1d

    .line 474
    invoke-static {v12}, La_11F57FE5;->a(Ljava/lang/String;)Landroid/os/LocaleList;

    .line 477
    move-result-object v1

    .line 478
    invoke-static {v9, v1}, La_11F57FE5;->b(Landroid/widget/TextView;Landroid/os/LocaleList;)V

    .line 481
    goto :goto_9

    .line 482
    :cond_1d
    const-string v1, ","

    .line 484
    invoke-virtual {v12, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 487
    move-result-object v1

    .line 488
    aget-object v1, v1, v13

    .line 490
    invoke-static {v1}, La_0887F315;->a(Ljava/lang/String;)Ljava/util/Locale;

    .line 493
    move-result-object v1

    .line 494
    invoke-static {v9, v1}, La_C7B4DE03;->c(Landroid/widget/TextView;Ljava/util/Locale;)V

    .line 497
    :cond_1e
    :goto_9
    sget-object v12, La_A906E194;->f_3aef6373:[I

    .line 499
    iget-object v14, v0, La_73AFC5B6;->i:La_4036ED52;

    .line 501
    iget-object v15, v14, La_4036ED52;->j:Landroid/content/Context;

    .line 503
    invoke-virtual {v15, v7, v12, v8, v13}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 506
    move-result-object v6

    .line 507
    iget-object v1, v14, La_4036ED52;->i:Landroid/widget/TextView;

    .line 509
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 512
    move-result-object v2

    .line 513
    const/4 v5, 0x5

    .line 514
    move-object v3, v12

    .line 515
    const/4 v11, 0x2

    .line 516
    move-object/from16 v4, p1

    .line 518
    const/4 v11, 0x5

    .line 519
    move-object v5, v6

    .line 520
    move-object v13, v6

    .line 521
    move/from16 v6, p2

    .line 523
    invoke-static/range {v1 .. v6}, Lqx;->o(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;I)V

    .line 526
    invoke-virtual {v13, v11}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 529
    move-result v1

    .line 530
    if-eqz v1, :cond_1f

    .line 532
    const/4 v1, 0x0

    .line 533
    invoke-virtual {v13, v11, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 536
    move-result v2

    .line 537
    iput v2, v14, La_4036ED52;->a:I

    .line 539
    :cond_1f
    const/4 v1, 0x4

    .line 540
    invoke-virtual {v13, v1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 543
    move-result v2

    .line 544
    const/high16 v3, -0x40800000    # -1.0f

    .line 546
    if-eqz v2, :cond_20

    .line 548
    invoke-virtual {v13, v1, v3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 551
    move-result v1

    .line 552
    goto :goto_a

    .line 553
    :cond_20
    const/high16 v1, -0x40800000    # -1.0f

    .line 555
    :goto_a
    const/4 v2, 0x2

    .line 556
    invoke-virtual {v13, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 559
    move-result v4

    .line 560
    if-eqz v4, :cond_21

    .line 562
    invoke-virtual {v13, v2, v3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 565
    move-result v4

    .line 566
    const/4 v2, 0x1

    .line 567
    goto :goto_b

    .line 568
    :cond_21
    const/4 v2, 0x1

    .line 569
    const/high16 v4, -0x40800000    # -1.0f

    .line 571
    :goto_b
    invoke-virtual {v13, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 574
    move-result v5

    .line 575
    if-eqz v5, :cond_22

    .line 577
    invoke-virtual {v13, v2, v3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 580
    move-result v5

    .line 581
    goto :goto_c

    .line 582
    :cond_22
    const/high16 v5, -0x40800000    # -1.0f

    .line 584
    :goto_c
    const/4 v6, 0x3

    .line 585
    invoke-virtual {v13, v6}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 588
    move-result v8

    .line 589
    if-eqz v8, :cond_25

    .line 591
    const/4 v8, 0x0

    .line 592
    invoke-virtual {v13, v6, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 595
    move-result v11

    .line 596
    if-lez v11, :cond_25

    # ep-mdzedmuhckts
    .line 598
    invoke-virtual {v13}, Landroid/content/res/TypedArray;->m_d708a363()Landroid/content/res/Resources;

    .line 601
    move-result-object v6

    .line 602
    invoke-virtual {v6, v11}, Landroid/content/res/Resources;->obtainTypedArray(I)Landroid/content/res/TypedArray;

    .line 605
    move-result-object v6

    .line 606
    invoke-virtual {v6}, Landroid/content/res/TypedArray;->length()I

    .line 609
    move-result v8

    .line 610
    new-array v11, v8, [I

    .line 612
    if-lez v8, :cond_24

    .line 614
    const/4 v3, 0x0

    .line 615
    :goto_d
    if-ge v3, v8, :cond_23

    .line 617
    const/4 v2, -0x1

    .line 618
    invoke-virtual {v6, v3, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 621
    move-result v17

    .line 622
    aput v17, v11, v3

    .line 624
    add-int/lit8 v3, v3, 0x1

    .line 626
    const/4 v2, 0x1

    .line 627
    goto :goto_d

    .line 628
    :cond_23
    invoke-static {v11}, La_4036ED52;->b([I)[I

    .line 631
    move-result-object v2

    .line 632
    iput-object v2, v14, La_4036ED52;->f:[I

    .line 634
    invoke-virtual {v14}, La_4036ED52;->g()Z

    .line 637
    :cond_24
    invoke-virtual {v6}, Landroid/content/res/TypedArray;->recycle()V

    .line 640
    :cond_25
    invoke-virtual {v13}, Landroid/content/res/TypedArray;->recycle()V

    .line 643
    invoke-virtual {v14}, La_4036ED52;->h()Z

    .line 646
    move-result v2

    .line 647
    const/high16 v3, 0x3f800000    # 1.0f

    .line 649
    if-eqz v2, :cond_2a

    .line 651
    iget v2, v14, La_4036ED52;->a:I

    .line 653
    const/4 v6, 0x1

    .line 654
    if-ne v2, v6, :cond_2b

    .line 656
    iget-boolean v2, v14, La_4036ED52;->g:Z

    .line 658
    if-nez v2, :cond_29

    .line 660
    invoke-virtual {v15}, Landroid/content/Context;->m_d708a363()Landroid/content/res/Resources;

    .line 663
    move-result-object v2

    .line 664
    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 667
    move-result-object v2

    .line 668
    const/high16 v6, -0x40800000    # -1.0f

    .line 670
    cmpl-float v8, v4, v6

    .line 672
    if-nez v8, :cond_26

    .line 674
    const/high16 v4, 0x41400000    # 12.0f

    .line 676
    const/4 v8, 0x2

    .line 677
    invoke-static {v8, v4, v2}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 680
    move-result v4

    .line 681
    goto :goto_e

    .line 682
    :cond_26
    const/4 v8, 0x2

    .line 683
    :goto_e
    cmpl-float v11, v5, v6

    .line 685
    if-nez v11, :cond_27

    .line 687
    const/high16 v5, 0x42e00000    # 112.0f

    .line 689
    invoke-static {v8, v5, v2}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 692
    move-result v5

    .line 693
    :cond_27
    cmpl-float v2, v1, v6

    .line 695
    if-nez v2, :cond_28

    .line 697
    const/high16 v1, 0x3f800000    # 1.0f

    .line 699
    :cond_28
    invoke-virtual {v14, v4, v5, v1}, La_4036ED52;->i(FFF)V

    .line 702
    :cond_29
    invoke-virtual {v14}, La_4036ED52;->f()Z

    .line 705
    goto :goto_f

    .line 706
    :cond_2a
    const/4 v1, 0x0

    .line 707
    iput v1, v14, La_4036ED52;->a:I

    .line 709
    :cond_2b
    :goto_f
    sget-boolean v1, La_80813161;->a:Z

    .line 711
    if-eqz v1, :cond_2d

    .line 713
    iget v1, v14, La_4036ED52;->a:I

    .line 715
    if-eqz v1, :cond_2d

    .line 717
    iget-object v1, v14, La_4036ED52;->f:[I

    .line 719
    array-length v2, v1

    .line 720
    if-lez v2, :cond_2d

    .line 722
    invoke-static {v9}, La_7F00077E;->a(Landroid/widget/TextView;)I

    .line 725
    move-result v2

    .line 726
    int-to-float v2, v2

    .line 727
    const/high16 v4, -0x40800000    # -1.0f

    .line 729
    cmpl-float v2, v2, v4

    .line 731
    if-eqz v2, :cond_2c

    .line 733
    iget v1, v14, La_4036ED52;->d:F

    .line 735
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    .line 738
    move-result v1

    .line 739
    iget v2, v14, La_4036ED52;->e:F

    .line 741
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 744
    move-result v2

    .line 745
    iget v4, v14, La_4036ED52;->c:F

    .line 747
    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    .line 750
    move-result v4

    .line 751
    const/4 v5, 0x0

    .line 752
    invoke-static {v9, v1, v2, v4, v5}, La_7F00077E;->b(Landroid/widget/TextView;IIII)V

    .line 755
    goto :goto_10

    .line 756
    :cond_2c
    const/4 v5, 0x0

    .line 757
    invoke-static {v9, v1, v5}, La_7F00077E;->c(Landroid/widget/TextView;[II)V

    .line 760
    :cond_2d
    :goto_10
    new-instance v1, Lmv;

    .line 762
    invoke-virtual {v10, v7, v12}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 765
    move-result-object v2

    .line 766
    invoke-direct {v1, v10, v2}, Lmv;-><init>(Landroid/content/Context;Landroid/content/res/TypedArray;)V

    .line 769
    const/16 v2, 0x8

    .line 771
    const/4 v4, -0x1

    .line 772
    invoke-virtual {v1, v2, v4}, Lmv;->i(II)I

    .line 775
    move-result v2

    .line 776
    if-eq v2, v4, :cond_2e

    .line 778
    move-object/from16 v5, v22

    .line 780
    invoke-virtual {v5, v10, v2}, La_475B320D;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 783
    move-result-object v2

    .line 784
    goto :goto_11

    .line 785
    :cond_2e
    move-object/from16 v5, v22

    .line 787
    const/4 v2, 0x0

    .line 788
    :goto_11
    const/16 v6, 0xd

    .line 790
    invoke-virtual {v1, v6, v4}, Lmv;->i(II)I

    .line 793
    move-result v6

    .line 794
    if-eq v6, v4, :cond_2f

    .line 796
    invoke-virtual {v5, v10, v6}, La_475B320D;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 799
    move-result-object v6

    .line 800
    goto :goto_12

    .line 801
    :cond_2f
    const/4 v6, 0x0

    .line 802
    :goto_12
    const/16 v7, 0x9

    .line 804
    invoke-virtual {v1, v7, v4}, Lmv;->i(II)I

    .line 807
    move-result v7

    .line 808
    if-eq v7, v4, :cond_30

    .line 810
    invoke-virtual {v5, v10, v7}, La_475B320D;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 813
    move-result-object v7

    .line 814
    goto :goto_13

    .line 815
    :cond_30
    const/4 v7, 0x0

    .line 816
    :goto_13
    const/4 v8, 0x6

    .line 817
    invoke-virtual {v1, v8, v4}, Lmv;->i(II)I

    .line 820
    move-result v8

    .line 821
    if-eq v8, v4, :cond_31

    .line 823
    invoke-virtual {v5, v10, v8}, La_475B320D;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 826
    move-result-object v8

    .line 827
    goto :goto_14

    .line 828
    :cond_31
    const/4 v8, 0x0

    .line 829
    :goto_14
    const/16 v11, 0xa

    .line 831
    invoke-virtual {v1, v11, v4}, Lmv;->i(II)I

    .line 834
    move-result v11

    .line 835
    if-eq v11, v4, :cond_32

    .line 837
    invoke-virtual {v5, v10, v11}, La_475B320D;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 840
    move-result-object v11

    .line 841
    goto :goto_15

    .line 842
    :cond_32
    const/4 v11, 0x0

    .line 843
    :goto_15
    const/4 v12, 0x7

    .line 844
    invoke-virtual {v1, v12, v4}, Lmv;->i(II)I

    .line 847
    move-result v12

    .line 848
    if-eq v12, v4, :cond_33

    .line 850
    invoke-virtual {v5, v10, v12}, La_475B320D;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 853
    move-result-object v4

    .line 854
    goto :goto_16

    .line 855
    :cond_33
    const/4 v4, 0x0

    .line 856
    :goto_16
    if-nez v11, :cond_3e

    .line 858
    if-eqz v4, :cond_34

    .line 860
    goto :goto_1e

    .line 861
    :cond_34
    if-nez v2, :cond_35

    .line 863
    if-nez v6, :cond_35

    .line 865
    if-nez v7, :cond_35

    .line 867
    if-eqz v8, :cond_43

    .line 869
    :cond_35
    invoke-static {v9}, La_C7B4DE03;->a(Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;

    .line 872
    move-result-object v4

    .line 873
    const/4 v5, 0x0

    .line 874
    aget-object v10, v4, v5

    .line 876
    if-nez v10, :cond_3b

    .line 878
    const/4 v11, 0x2

    .line 879
    aget-object v12, v4, v11

    .line 881
    if-eqz v12, :cond_36

    .line 883
    goto :goto_1b

    .line 884
    :cond_36
    invoke-virtual {v9}, Landroid/widget/TextView;->getCompoundDrawables()[Landroid/graphics/drawable/Drawable;

    .line 887
    move-result-object v4

    .line 888
    if-eqz v2, :cond_37

    .line 890
    goto :goto_17

    .line 891
    :cond_37
    aget-object v2, v4, v5

    .line 893
    :goto_17
    if-eqz v6, :cond_38

    .line 895
    goto :goto_18

    .line 896
    :cond_38
    const/4 v5, 0x1

    .line 897
    aget-object v6, v4, v5

    .line 899
    :goto_18
    if-eqz v7, :cond_39

    .line 901
    goto :goto_19

    .line 902
    :cond_39
    const/4 v5, 0x2

    .line 903
    aget-object v7, v4, v5

    .line 905
    :goto_19
    if-eqz v8, :cond_3a

    .line 907
    goto :goto_1a

    .line 908
    :cond_3a
    const/4 v5, 0x3

    .line 909
    aget-object v8, v4, v5

    .line 911
    :goto_1a
    invoke-virtual {v9, v2, v6, v7, v8}, Landroid/widget/TextView;->m_77f800ae(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 914
    goto :goto_23

    .line 915
    :cond_3b
    :goto_1b
    if-eqz v6, :cond_3c

    .line 917
    goto :goto_1c

    .line 918
    :cond_3c
    const/4 v2, 0x1

    .line 919
    aget-object v6, v4, v2

    .line 921
    :goto_1c
    const/4 v2, 0x2

    .line 922
    aget-object v2, v4, v2

    .line 924
    if-eqz v8, :cond_3d

    .line 926
    goto :goto_1d

    .line 927
    :cond_3d
    const/4 v5, 0x3

    .line 928
    aget-object v8, v4, v5

    .line 930
    :goto_1d
    invoke-static {v9, v10, v6, v2, v8}, La_C7B4DE03;->b(Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 933
    goto :goto_23

    .line 934
    :cond_3e
    :goto_1e
    invoke-static {v9}, La_C7B4DE03;->a(Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;

    .line 937
    move-result-object v2

    .line 938
    if-eqz v11, :cond_3f

    .line 940
    goto :goto_1f

    .line 941
    :cond_3f
    const/4 v5, 0x0

    .line 942
    aget-object v11, v2, v5

    .line 944
    :goto_1f
    if-eqz v6, :cond_40

    .line 946
    goto :goto_20

    .line 947
    :cond_40
    const/4 v5, 0x1

    .line 948
    aget-object v6, v2, v5

    .line 950
    :goto_20
    if-eqz v4, :cond_41

    .line 952
    goto :goto_21

    .line 953
    :cond_41
    const/4 v4, 0x2

    .line 954
    aget-object v4, v2, v4

    .line 956
    :goto_21
    if-eqz v8, :cond_42

    .line 958
    goto :goto_22

    .line 959
    :cond_42
    const/4 v5, 0x3

    .line 960
    aget-object v8, v2, v5

    .line 962
    :goto_22
    invoke-static {v9, v11, v6, v4, v8}, La_C7B4DE03;->b(Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 965
    :cond_43
    :goto_23
    const/16 v2, 0xb

    .line 967
    invoke-virtual {v1, v2}, Lmv;->l(I)Z

    .line 970
    move-result v4

    .line 971
    if-eqz v4, :cond_45

    .line 973
    invoke-virtual {v1, v2}, Lmv;->b(I)Landroid/content/res/ColorStateList;

    .line 976
    move-result-object v2

    .line 977
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 979
    const/16 v5, 0x18

    .line 981
    if-lt v4, v5, :cond_44

    .line 983
    invoke-static {v9, v2}, La_2B77A6AE;->f(Landroid/widget/TextView;Landroid/content/res/ColorStateList;)V

    .line 986
    goto :goto_24

    .line 987
    :cond_44
    instance-of v4, v9, Lov;

    .line 989
    if-eqz v4, :cond_45

    .line 991
    move-object v4, v9

    .line 992
    check-cast v4, Lov;

    .line 994
    invoke-interface {v4, v2}, Lov;->m_594d694b(Landroid/content/res/ColorStateList;)V

    .line 997
    :cond_45
    :goto_24
    const/16 v2, 0xc

    .line 999
    invoke-virtual {v1, v2}, Lmv;->l(I)Z

    .line 1002
    move-result v4

    .line 1003
    if-eqz v4, :cond_47

    .line 1005
    const/4 v4, -0x1

    .line 1006
    invoke-virtual {v1, v2, v4}, Lmv;->h(II)I

    .line 1009
    move-result v2

    .line 1010
    const/4 v4, 0x0

    .line 1011
    invoke-static {v2, v4}, Lwa;->b(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    .line 1014
    move-result-object v2

    .line 1015
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 1017
    const/16 v6, 0x18

    .line 1019
    if-lt v5, v6, :cond_46

    .line 1021
    invoke-static {v9, v2}, La_2B77A6AE;->g(Landroid/widget/TextView;Landroid/graphics/PorterDuff$Mode;)V

    .line 1024
    goto :goto_25

    .line 1025
    :cond_46
    instance-of v5, v9, Lov;

    .line 1027
    if-eqz v5, :cond_48

    .line 1029
    move-object v5, v9

    .line 1030
    check-cast v5, Lov;

    .line 1032
    invoke-interface {v5, v2}, Lov;->m_4322d776(Landroid/graphics/PorterDuff$Mode;)V

    .line 1035
    goto :goto_25

    .line 1036
    :cond_47
    const/4 v4, 0x0

    .line 1037
    :cond_48
    :goto_25
    const/16 v2, 0xf

    .line 1039
    const/4 v5, -0x1

    .line 1040
    invoke-virtual {v1, v2, v5}, Lmv;->d(II)I

    .line 1043
    move-result v2

    .line 1044
    const/16 v6, 0x12

    .line 1046
    invoke-virtual {v1, v6, v5}, Lmv;->d(II)I

    .line 1049
    move-result v6

    .line 1050
    const/16 v7, 0x13

    .line 1052
    invoke-virtual {v1, v7, v5}, Lmv;->d(II)I

    .line 1055
    move-result v7

    .line 1056
    invoke-virtual {v1}, Lmv;->n()V

    .line 1059
    if-eq v2, v5, :cond_49

    .line 1061
    invoke-static {v9, v2}, Lwu;->b(Landroid/widget/TextView;I)V

    .line 1064
    :cond_49
    if-eq v6, v5, :cond_4a

    .line 1066
    invoke-static {v9, v6}, Lwu;->c(Landroid/widget/TextView;I)V

    .line 1069
    :cond_4a
    if-eq v7, v5, :cond_4b

    .line 1071
    invoke-static {v7}, La_A906E194;->j(I)V

    .line 1074
    invoke-virtual {v9}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    .line 1077
    move-result-object v1

    .line 1078
    invoke-virtual {v1, v4}, Landroid/graphics/Paint;->getFontMetricsInt(Landroid/graphics/Paint$FontMetricsInt;)I

    .line 1081
    move-result v1

    .line 1082
    if-eq v7, v1, :cond_4b

    .line 1084
    sub-int/2addr v7, v1

    .line 1085
    int-to-float v1, v7

    .line 1086
    invoke-virtual {v9, v1, v3}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 1089
    :cond_4b
    return-void
.end method

.method public final g(Landroid/content/Context;I)V
    .locals 5

    .line 1
    sget-object v0, La_A906E194;->f_3988f05b:[I

    .line 3
    new-instance v1, Lmv;

    .line 5
    invoke-virtual {p1, p2, v0}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    .line 8
    move-result-object p2

    .line 9
    invoke-direct {v1, p1, p2}, Lmv;-><init>(Landroid/content/Context;Landroid/content/res/TypedArray;)V

    .line 12
    const/16 p2, 0xe

    .line 14
    invoke-virtual {v1, p2}, Lmv;->l(I)Z

    .line 17
    move-result v0

    .line 18
    iget-object v2, p0, La_73AFC5B6;->a:Landroid/widget/TextView;

    .line 20
    const/4 v3, 0x0

    .line 21
    if-eqz v0, :cond_0

    .line 23
    # ep-enlreommfnoh
    invoke-virtual {v1, p2, v3}, Lmv;->a(IZ)Z

    .line 26
    move-result p2

    .line 27
    invoke-virtual {v2, p2}, Landroid/widget/TextView;->m_2588d164(Z)V

    .line 30
    :cond_0
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 32
    const/16 v0, 0x17

    .line 34
    if-ge p2, v0, :cond_3

    .line 36
    const/4 v0, 0x3

    .line 37
    invoke-virtual {v1, v0}, Lmv;->l(I)Z

    .line 40
    move-result v4

    .line 41
    if-eqz v4, :cond_1

    .line 43
    invoke-virtual {v1, v0}, Lmv;->b(I)Landroid/content/res/ColorStateList;

    .line 46
    move-result-object v0

    .line 47
    if-eqz v0, :cond_1

    .line 49
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    .line 52
    :cond_1
    # ep-dpcgzlhsphbj
    const/4 v0, 0x5

    .line 53
    # ep-brqomgmyrfbz
    invoke-virtual {v1, v0}, Lmv;->l(I)Z

    .line 56
    move-result v4

    .line 57
    if-eqz v4, :cond_2

    .line 59
    invoke-virtual {v1, v0}, Lmv;->b(I)Landroid/content/res/ColorStateList;

    .line 62
    move-result-object v0

    .line 63
    if-eqz v0, :cond_2

    .line 65
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setLinkTextColor(Landroid/content/res/ColorStateList;)V

    .line 68
    :cond_2
    const/4 v0, 0x4

    .line 69
    invoke-virtual {v1, v0}, Lmv;->l(I)Z

    .line 72
    move-result v4

    .line 73
    if-eqz v4, :cond_3

    .line 75
    invoke-virtual {v1, v0}, Lmv;->b(I)Landroid/content/res/ColorStateList;

    .line 78
    move-result-object v0

    .line 79
    if-eqz v0, :cond_3

    .line 81
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setHintTextColor(Landroid/content/res/ColorStateList;)V

    .line 84
    :cond_3
    invoke-virtual {v1, v3}, Lmv;->l(I)Z

    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_4

    .line 90
    const/4 v0, -0x1

    .line 91
    invoke-virtual {v1, v3, v0}, Lmv;->d(II)I

    .line 94
    move-result v0

    .line 95
    if-nez v0, :cond_4

    .line 97
    const/4 v0, 0x0

    .line 98
    invoke-virtual {v2, v3, v0}, Landroid/widget/TextView;->m_950f21e6(IF)V

    .line 101
    :cond_4
    invoke-virtual {p0, p1, v1}, La_73AFC5B6;->n(Landroid/content/Context;Lmv;)V

    .line 104
    const/16 p1, 0x1a

    .line 106
    if-lt p2, p1, :cond_5

    .line 108
    const/16 p1, 0xd

    .line 110
    invoke-virtual {v1, p1}, Lmv;->l(I)Z

    .line 113
    move-result p2

    .line 114
    if-eqz p2, :cond_5

    .line 116
    invoke-virtual {v1, p1}, Lmv;->j(I)Ljava/lang/String;

    .line 119
    move-result-object p1

    .line 120
    if-eqz p1, :cond_5

    .line 122
    invoke-static {v2, p1}, La_7F00077E;->d(Landroid/widget/TextView;Ljava/lang/String;)Z

    .line 125
    :cond_5
    invoke-virtual {v1}, Lmv;->n()V

    .line 128
    iget-object p1, p0, La_73AFC5B6;->l:Landroid/graphics/Typeface;

    .line 130
    if-eqz p1, :cond_6

    .line 132
    iget p2, p0, La_73AFC5B6;->j:I

    .line 134
    invoke-virtual {v2, p1, p2}, Landroid/widget/TextView;->m_f7dc677f(Landroid/graphics/Typeface;I)V

    .line 137
    :cond_6
    return-void
.end method

.method public final i(IIII)V
    .locals 2

    .line 1
    iget-object v0, p0, La_73AFC5B6;->i:La_4036ED52;

    .line 3
    invoke-virtual {v0}, La_4036ED52;->h()Z

    .line 6
    move-result v1

    .line 7
    if-eqz v1, :cond_0

    .line 9
    iget-object v1, v0, La_4036ED52;->j:Landroid/content/Context;

    .line 11
    invoke-virtual {v1}, Landroid/content/Context;->m_d708a363()Landroid/content/res/Resources;

    .line 14
    move-result-object v1

    .line 15
    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 18
    move-result-object v1

    .line 19
    int-to-float p1, p1

    .line 20
    # ep-vjhnidrazyuq
    invoke-static {p4, p1, v1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 23
    move-result p1

    .line 24
    int-to-float p2, p2

    .line 25
    invoke-static {p4, p2, v1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 28
    move-result p2

    .line 29
    int-to-float p3, p3

    .line 30
    invoke-static {p4, p3, v1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 33
    move-result p3

    .line 34
    invoke-virtual {v0, p1, p2, p3}, La_4036ED52;->i(FFF)V

    # ep-apwixkcvhiqg
    .line 37
    invoke-virtual {v0}, La_4036ED52;->f()Z

    .line 40
    move-result p1

    .line 41
    if-eqz p1, :cond_0

    .line 43
    invoke-virtual {v0}, La_4036ED52;->a()V

    .line 46
    :cond_0
    return-void
.end method

.method public final j([II)V
    .locals 6

    .line 1
    iget-object v0, p0, La_73AFC5B6;->i:La_4036ED52;

    .line 3
    invoke-virtual {v0}, La_4036ED52;->h()Z

    .line 6
    move-result v1

    .line 7
    if-eqz v1, :cond_4
    # ep-wvuqktfssejq

    .line 9
    array-length v1, p1

    .line 10
    const/4 v2, 0x0

    .line 11
    if-lez v1, :cond_3

    .line 13
    new-array v3, v1, [I

    .line 15
    if-nez p2, :cond_0

    .line 17
    invoke-static {p1, v1}, Ljava/util/Arrays;->copyOf([II)[I

    .line 20
    move-result-object v3

    .line 21
    goto :goto_1

    .line 22
    :cond_0
    iget-object v4, v0, La_4036ED52;->j:Landroid/content/Context;

    .line 24
    invoke-virtual {v4}, Landroid/content/Context;->m_d708a363()Landroid/content/res/Resources;

    .line 27
    move-result-object v4

    .line 28
    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 31
    move-result-object v4

    .line 32
    :goto_0
    if-ge v2, v1, :cond_1

    .line 34
    aget v5, p1, v2

    .line 36
    int-to-float v5, v5

    # ep-jlkoihnqioow
    .line 37
    invoke-static {p2, v5, v4}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 40
    move-result v5

    .line 41
    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    .line 44
    move-result v5

    .line 45
    aput v5, v3, v2

    .line 47
    add-int/lit8 v2, v2, 0x1

    .line 49
    goto :goto_0

    .line 50
    :cond_1
    :goto_1
    invoke-static {v3}, La_4036ED52;->b([I)[I

    .line 53
    move-result-object p2

    .line 54
    iput-object p2, v0, La_4036ED52;->f:[I

    .line 56
    invoke-virtual {v0}, La_4036ED52;->g()Z

    .line 59
    move-result p2

    .line 60
    if-eqz p2, :cond_2

    .line 62
    goto :goto_2

    .line 63
    :cond_2
    new-instance p2, Ljava/lang/IllegalArgumentException;

    .line 65
    new-instance v0, Ljava/lang/StringBuilder;

    .line 67
    const-string v1, "None of the preset sizes is valid: "

    .line 69
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 72
    invoke-static {p1}, Ljava/util/Arrays;->toString([I)Ljava/lang/String;

    .line 75
    move-result-object p1

    .line 76
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 82
    move-result-object p1

    .line 83
    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 86
    throw p2

    .line 87
    :cond_3
    iput-boolean v2, v0, La_4036ED52;->g:Z

    .line 89
    :goto_2
    invoke-virtual {v0}, La_4036ED52;->f()Z

    .line 92
    move-result p1

    .line 93
    if-eqz p1, :cond_4

    .line 95
    invoke-virtual {v0}, La_4036ED52;->a()V

    .line 98
    :cond_4
    return-void
.end method

.method public final k(I)V
    .locals 4

    .line 1
    iget-object v0, p0, La_73AFC5B6;->i:La_4036ED52;

    .line 3
    invoke-virtual {v0}, La_4036ED52;->h()Z

    .line 6
    move-result v1

    .line 7
    if-eqz v1, :cond_2

    .line 9
    if-eqz p1, :cond_1

    .line 11
    const/4 v1, 0x1

    .line 12
    if-ne p1, v1, :cond_0

    .line 14
    iget-object p1, v0, La_4036ED52;->j:Landroid/content/Context;

    .line 16
    invoke-virtual {p1}, Landroid/content/Context;->m_d708a363()Landroid/content/res/Resources;

    .line 19
    move-result-object p1

    .line 20
    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 23
    move-result-object p1

    .line 24
    const/4 v1, 0x2

    .line 25
    const/high16 v2, 0x41400000    # 12.0f

    .line 27
    invoke-static {v1, v2, p1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 30
    move-result v2

    .line 31
    const/high16 v3, 0x42e00000    # 112.0f

    .line 33
    invoke-static {v1, v3, p1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 36
    move-result p1
    # ep-rxayqgihykzt

    .line 37
    const/high16 v1, 0x3f800000    # 1.0f

    .line 39
    invoke-virtual {v0, v2, p1, v1}, La_4036ED52;->i(FFF)V

    # ep-agaaxpaqqblb
    .line 42
    invoke-virtual {v0}, La_4036ED52;->f()Z

    .line 45
    move-result p1

    .line 46
    if-eqz p1, :cond_2

    .line 48
    invoke-virtual {v0}, La_4036ED52;->a()V

    .line 51
    goto :goto_0

    .line 52
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 54
    new-instance v1, Ljava/lang/StringBuilder;

    .line 56
    const-string v2, "Unknown auto-size text type: "

    .line 58
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 61
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 64
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 67
    move-result-object p1

    .line 68
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 71
    throw v0

    # ep-kbdtfaiezxde
    .line 72
    :cond_1
    const/4 p1, 0x0

    # ep-aqavgvltgmwn
    .line 73
    iput p1, v0, La_4036ED52;->a:I

    .line 75
    const/high16 v1, -0x40800000    # -1.0f

    .line 77
    iput v1, v0, La_4036ED52;->d:F

    .line 79
    iput v1, v0, La_4036ED52;->e:F

    .line 81
    iput v1, v0, La_4036ED52;->c:F

    .line 83
    new-array v1, p1, [I

    .line 85
    iput-object v1, v0, La_4036ED52;->f:[I

    .line 87
    iput-boolean p1, v0, La_4036ED52;->b:Z

    .line 89
    :cond_2
    :goto_0
    return-void
.end method

.method public final l(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_73AFC5B6;->h:Lkv;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, Lkv;

    .line 7
    invoke-direct {v0}, Lkv;-><init>()V

    .line 10
    iput-object v0, p0, La_73AFC5B6;->h:Lkv;

    .line 12
    :cond_0
    # ep-lxlknohndjwn
    iget-object v0, p0, La_73AFC5B6;->h:Lkv;

    .line 14
    iput-object p1, v0, Lkv;->a:Landroid/content/res/ColorStateList;

    .line 16
    if-eqz p1, :cond_1

    .line 18
    # ep-vklvafigigfi
    const/4 p1, 0x1

    .line 19
    goto :goto_0

    .line 20
    :cond_1
    const/4 p1, 0x0

    .line 21
    :goto_0
    iput-boolean p1, v0, Lkv;->d:Z

    .line 23
    iput-object v0, p0, La_73AFC5B6;->b:Lkv;

    .line 25
    iput-object v0, p0, La_73AFC5B6;->c:Lkv;

    .line 27
    iput-object v0, p0, La_73AFC5B6;->d:Lkv;

    .line 29
    iput-object v0, p0, La_73AFC5B6;->e:Lkv;

    .line 31
    iput-object v0, p0, La_73AFC5B6;->f:Lkv;

    .line 33
    iput-object v0, p0, La_73AFC5B6;->g:Lkv;

    .line 35
    return-void
.end method

.method public final m(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_73AFC5B6;->h:Lkv;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, Lkv;

    .line 7
    invoke-direct {v0}, Lkv;-><init>()V
    # ep-vpeccgkdxcfw

    .line 10
    iput-object v0, p0, La_73AFC5B6;->h:Lkv;

    .line 12
    :cond_0
    iget-object v0, p0, La_73AFC5B6;->h:Lkv;

    .line 14
    # ep-agcfhidtmapl
    iput-object p1, v0, Lkv;->b:Landroid/graphics/PorterDuff$Mode;

    .line 16
    if-eqz p1, :cond_1

    .line 18
    const/4 p1, 0x1

    .line 19
    goto :goto_0

    .line 20
    :cond_1
    const/4 p1, 0x0

    .line 21
    :goto_0
    iput-boolean p1, v0, Lkv;->c:Z

    .line 23
    iput-object v0, p0, La_73AFC5B6;->b:Lkv;

    .line 25
    iput-object v0, p0, La_73AFC5B6;->c:Lkv;

    # ep-ocytfohiycwf
    .line 27
    iput-object v0, p0, La_73AFC5B6;->d:Lkv;

    .line 29
    iput-object v0, p0, La_73AFC5B6;->e:Lkv;

    .line 31
    iput-object v0, p0, La_73AFC5B6;->f:Lkv;

    .line 33
    iput-object v0, p0, La_73AFC5B6;->g:Lkv;

    .line 35
    return-void
.end method

.method public final n(Landroid/content/Context;Lmv;)V
    .locals 10

    .line 1
    iget v0, p0, La_73AFC5B6;->j:I

    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-virtual {p2, v1, v0}, Lmv;->h(II)I

    .line 7
    move-result v0

    .line 8
    iput v0, p0, La_73AFC5B6;->j:I

    .line 10
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 12
    const/4 v2, -0x1

    .line 13
    const/4 v3, 0x0

    .line 14
    const/16 v4, 0x1c

    .line 16
    if-lt v0, v4, :cond_0

    .line 18
    const/16 v5, 0xb

    # ep-ebmopvolidtf
    .line 20
    invoke-virtual {p2, v5, v2}, Lmv;->h(II)I

    .line 23
    move-result v5

    .line 24
    iput v5, p0, La_73AFC5B6;->k:I

    .line 26
    if-eq v5, v2, :cond_0

    .line 28
    iget v5, p0, La_73AFC5B6;->j:I

    .line 30
    and-int/2addr v5, v1

    .line 31
    or-int/2addr v5, v3

    .line 32
    iput v5, p0, La_73AFC5B6;->j:I

    .line 34
    :cond_0
    const/16 v5, 0xa

    .line 36
    invoke-virtual {p2, v5}, Lmv;->l(I)Z

    .line 39
    move-result v6

    .line 40
    const/16 v7, 0xc

    .line 42
    const/4 v8, 0x1

    .line 43
    if-nez v6, :cond_6

    .line 45
    invoke-virtual {p2, v7}, Lmv;->l(I)Z

    .line 48
    move-result v6

    .line 49
    if-eqz v6, :cond_1

    .line 51
    goto :goto_1

    .line 52
    :cond_1
    invoke-virtual {p2, v8}, Lmv;->l(I)Z

    .line 55
    move-result p1

    .line 56
    if-eqz p1, :cond_5

    .line 58
    iput-boolean v3, p0, La_73AFC5B6;->m:Z

    .line 60
    invoke-virtual {p2, v8, v8}, Lmv;->h(II)I

    .line 63
    move-result p1

    .line 64
    if-eq p1, v8, :cond_4

    .line 66
    if-eq p1, v1, :cond_3

    .line 68
    const/4 p2, 0x3

    .line 69
    if-eq p1, p2, :cond_2

    .line 71
    goto :goto_0

    .line 72
    :cond_2
    sget-object p1, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    .line 74
    iput-object p1, p0, La_73AFC5B6;->l:Landroid/graphics/Typeface;

    .line 76
    goto :goto_0

    .line 77
    :cond_3
    sget-object p1, Landroid/graphics/Typeface;->SERIF:Landroid/graphics/Typeface;

    .line 79
    iput-object p1, p0, La_73AFC5B6;->l:Landroid/graphics/Typeface;

    .line 81
    goto :goto_0

    .line 82
    :cond_4
    sget-object p1, Landroid/graphics/Typeface;->SANS_SERIF:Landroid/graphics/Typeface;

    .line 84
    iput-object p1, p0, La_73AFC5B6;->l:Landroid/graphics/Typeface;

    .line 86
    :cond_5
    :goto_0
    return-void

    .line 87
    :cond_6
    :goto_1
    const/4 v6, 0x0

    .line 88
    iput-object v6, p0, La_73AFC5B6;->l:Landroid/graphics/Typeface;

    .line 90
    invoke-virtual {p2, v7}, Lmv;->l(I)Z

    .line 93
    move-result v6

    .line 94
    if-eqz v6, :cond_7

    .line 96
    const/16 v5, 0xc

    .line 98
    :cond_7
    iget v6, p0, La_73AFC5B6;->k:I

    .line 100
    iget v7, p0, La_73AFC5B6;->j:I

    .line 102
    invoke-virtual {p1}, Landroid/content/Context;->isRestricted()Z

    .line 105
    move-result p1

    .line 106
    if-nez p1, :cond_c

    .line 108
    new-instance p1, Ljava/lang/ref/WeakReference;

    .line 110
    iget-object v9, p0, La_73AFC5B6;->a:Landroid/widget/TextView;

    .line 112
    invoke-direct {p1, v9}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 115
    new-instance v9, La_4AF04DB9;

    .line 117
    invoke-direct {v9, p0, v6, v7, p1}, La_4AF04DB9;-><init>(La_73AFC5B6;IILjava/lang/ref/WeakReference;)V

    .line 120
    :try_start_0
    iget p1, p0, La_73AFC5B6;->j:I

    .line 122
    invoke-virtual {p2, v5, p1, v9}, Lmv;->g(IILa_4AF04DB9;)Landroid/graphics/Typeface;

    .line 125
    move-result-object p1

    .line 126
    if-eqz p1, :cond_a

    .line 128
    if-lt v0, v4, :cond_9

    .line 130
    iget v0, p0, La_73AFC5B6;->k:I

    .line 132
    if-eq v0, v2, :cond_9

    .line 134
    invoke-static {p1, v3}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    .line 137
    move-result-object p1

    .line 138
    iget v0, p0, La_73AFC5B6;->k:I

    .line 140
    iget v6, p0, La_73AFC5B6;->j:I

    .line 142
    and-int/2addr v6, v1

    .line 143
    if-eqz v6, :cond_8

    .line 145
    const/4 v6, 0x1

    .line 146
    goto :goto_2

    .line 147
    :cond_8
    const/4 v6, 0x0

    .line 148
    :goto_2
    invoke-static {p1, v0, v6}, La_757AFCB6;->a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    .line 151
    move-result-object p1

    .line 152
    iput-object p1, p0, La_73AFC5B6;->l:Landroid/graphics/Typeface;

    .line 154
    goto :goto_3

    .line 155
    :cond_9
    iput-object p1, p0, La_73AFC5B6;->l:Landroid/graphics/Typeface;

    .line 157
    :cond_a
    :goto_3
    iget-object p1, p0, La_73AFC5B6;->l:Landroid/graphics/Typeface;

    .line 159
    if-nez p1, :cond_b

    .line 161
    const/4 p1, 0x1

    .line 162
    goto :goto_4

    .line 163
    :cond_b
    const/4 p1, 0x0

    .line 164
    :goto_4
    iput-boolean p1, p0, La_73AFC5B6;->m:Z
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 166
    goto :goto_5

    .line 167
    :catch_0
    nop

    .line 168
    :cond_c
    :goto_5
    iget-object p1, p0, La_73AFC5B6;->l:Landroid/graphics/Typeface;

    .line 170
    if-nez p1, :cond_f

    .line 172
    invoke-virtual {p2, v5}, Lmv;->j(I)Ljava/lang/String;

    .line 175
    move-result-object p1

    .line 176
    if-eqz p1, :cond_f

    .line 178
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 180
    if-lt p2, v4, :cond_e

    .line 182
    iget p2, p0, La_73AFC5B6;->k:I

    # ep-cocfxqadrjrv
    .line 184
    if-eq p2, v2, :cond_e

    .line 186
    invoke-static {p1, v3}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    .line 189
    move-result-object p1

    .line 190
    iget p2, p0, La_73AFC5B6;->k:I

    .line 192
    iget v0, p0, La_73AFC5B6;->j:I

    .line 194
    and-int/2addr v0, v1

    .line 195
    if-eqz v0, :cond_d

    .line 197
    const/4 v3, 0x1

    .line 198
    :cond_d
    invoke-static {p1, p2, v3}, La_757AFCB6;->a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    .line 201
    move-result-object p1

    .line 202
    iput-object p1, p0, La_73AFC5B6;->l:Landroid/graphics/Typeface;

    .line 204
    goto :goto_6

    .line 205
    :cond_e
    iget p2, p0, La_73AFC5B6;->j:I

    .line 207
    invoke-static {p1, p2}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    .line 210
    move-result-object p1

    .line 211
    iput-object p1, p0, La_73AFC5B6;->l:Landroid/graphics/Typeface;

    .line 213
    :cond_f
    :goto_6
    return-void
.end method
