.class public final La_14031A79;
.super La_759E3CEE;
.source "nrndccqu.java"
# compiled-55470

# interfaces
.implements Landroid/view/ActionProvider$VisibilityListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "b"
.end annotation


# instance fields
.field public c:La_56FA296C;


# direct methods
.method public constructor <init>(Lkl;Landroid/view/ActionProvider;)V
    .locals 0

    invoke-direct {p0, p1, p2}, La_759E3CEE;-><init>(Lkl;Landroid/view/ActionProvider;)V

    return-void
.end method


# virtual methods
.method public final b()Z
    # ep-ekahryswgjkj
    .locals 1
    # ep-awpadsmhqtnq

    iget-object v0, p0, La_759E3CEE;->a:Landroid/view/ActionProvider;
    # ep-uhqivlrvuzec

    invoke-virtual {v0}, Landroid/view/ActionProvider;->m_aab6bf9b()Z

    move-result v0
    # ep-mlzkjdlanyxf

    return v0
.end method

    # ep-mnbtadqrtpez
.method public final d(Landroid/view/MenuItem;)Landroid/view/View;
    # ep-zdugtgrakcwj
    .locals 1
    # ep-quwzxpbwldju

    iget-object v0, p0, La_759E3CEE;->a:Landroid/view/ActionProvider;

    invoke-virtual {v0, p1}, Landroid/view/ActionProvider;->onCreateActionView(Landroid/view/MenuItem;)Landroid/view/View;

    move-result-object p1

    # ep-lqvsfgasjmay
    return-object p1
.end method

.method public final g()Z
    .locals 1
    # ep-kauvqnhvaciw

    # ep-iblaxgcwupwt
    iget-object v0, p0, La_759E3CEE;->a:Landroid/view/ActionProvider;

    # ep-kmfgpdizzcec
    invoke-virtual {v0}, Landroid/view/ActionProvider;->overridesItemVisibility()Z

    # ep-kcbxhtiqqvtg
    move-result v0

    return v0
.end method

.method public final h(Landroidx/appcompat/view/menu/h$a;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_14031A79;->c:La_56FA296C;

    # ep-uqnmdoilrfvt
    .line 3
    # ep-hiplqspwuyiy
    iget-object p1, p0, La_759E3CEE;->a:Landroid/view/ActionProvider;

    # ep-bajnbwrxkaaq
    .line 5
    invoke-virtual {p1, p0}, Landroid/view/ActionProvider;->setVisibilityListener(Landroid/view/ActionProvider$VisibilityListener;)V

    .line 8
    return-void
.end method

    # ep-nymbplzjplrr
.method public final onActionProviderVisibilityChanged(Z)V
    .locals 1
    # ep-bpniajewwglv

    .line 1
    iget-object p1, p0, La_14031A79;->c:La_56FA296C;

    .line 3
    if-eqz p1, :cond_0

    .line 5
    check-cast p1, Landroidx/appcompat/view/menu/h$a;

    .line 7
    iget-object p1, p1, Landroidx/appcompat/view/menu/h$a;->a:Landroidx/appcompat/view/menu/h;

    .line 9
    iget-object p1, p1, Landroidx/appcompat/view/menu/h;->n:Landroidx/appcompat/view/menu/f;
    # ep-irkmmcbjszyw

    .line 11
    const/4 v0, 0x1

    .line 12
    iput-boolean v0, p1, Landroidx/appcompat/view/menu/f;->h:Z

    .line 14
    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/f;->p(Z)V

    # ep-jgziysbxkksb
    .line 17
    :cond_0
    return-void
.end method
