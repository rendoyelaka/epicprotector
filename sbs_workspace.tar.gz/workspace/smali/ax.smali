.class public final Lax;
.super Ljava/lang/Object;
# ep-cggqbulbelqt
.source "SourceFile"

# validated-63952
# generated-97272
# interfaces
.implements Landroid/text/Spannable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lax$b;,
        Lax$a;
    }
.end annotation


# instance fields
.field public c:Z

.field public d:Landroid/text/Spannable;


# direct methods
.method public constructor <init>(Landroid/text/Spannable;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_wkhqypok
    goto :ep_s_wkhqypok
    :ep_d_wkhqypok
    nop
    :ep_s_wkhqypok
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lax;->c:Z

    .line 3
    iput-object p1, p0, Lax;->d:Landroid/text/Spannable;

    return-void
.end method

.method public constructor <init>(Ljava/lang/CharSequence;)V
    .locals 1

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_wmqajhsl
    goto :ep_s_wmqajhsl
    :ep_d_wmqajhsl
    nop
    :ep_s_wmqajhsl
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Lax;->c:Z

    .line 6
    new-instance v0, Landroid/text/SpannableString;

    invoke-direct {v0, p1}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_0fpfeim7
    goto :ep_s_0fpfeim7
    :ep_d_0fpfeim7
    nop
    :ep_s_0fpfeim7
    iput-object v0, p0, Lax;->d:Landroid/text/Spannable;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    .line 1
    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    .line 3
    iget-boolean v1, p0, Lax;->c:Z

    .line 5
    if-nez v1, :cond_1

    .line 7
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 9
    const/16 v2, 0x1c

    .line 11
    if-ge v1, v2, :cond_0

    .line 13
    new-instance v1, Lax$a;

    .line 15
    invoke-direct {v1}, Lax$a;-><init>()V

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    new-instance v1, Lax$b;

    .line 21
    invoke-direct {v1}, Lax$b;-><init>()V

    .line 24
    :goto_0
    invoke-virtual {v1, v0}, Lax$a;->a(Landroid/text/Spannable;)Z

    .line 27
    move-result v1

    .line 28
    if-eqz v1, :cond_1

    .line 30
    new-instance v1, Landroid/text/SpannableString;

    .line 32
    invoke-direct {v1, v0}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    .line 35
    iput-object v1, p0, Lax;->d:Landroid/text/Spannable;

    .line 37
    :cond_1
    const/4 v0, 0x1

    .line 38
    iput-boolean v0, p0, Lax;->c:Z

    .line 40
    return-void
.end method

.method public final charAt(I)C
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_3ejfurxd
    goto :ep_s_3ejfurxd
    :ep_d_3ejfurxd
    nop
    :ep_s_3ejfurxd
    invoke-interface {v0, p1}, Ljava/lang/CharSequence;->charAt(I)C

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_rwfpj4kx
    goto :ep_s_rwfpj4kx
    :ep_d_rwfpj4kx
    nop
    :ep_s_rwfpj4kx
    move-result p1

    return p1
.end method

.method public final chars()Ljava/util/stream/IntStream;
    .locals 1

    .line 1
    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    .line 3
    invoke-static {v0}, Lt;->m(Landroid/text/Spannable;)Ljava/util/stream/IntStream;

    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public final codePoints()Ljava/util/stream/IntStream;
    .locals 1

    .line 1
    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    .line 3
    invoke-static {v0}, Lt;->A(Landroid/text/Spannable;)Ljava/util/stream/IntStream;

    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public final getSpanEnd(Ljava/lang/Object;)I
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_l5m4bokf
    goto :ep_s_l5m4bokf
    :ep_d_l5m4bokf
    nop
    :ep_s_l5m4bokf
    invoke-interface {v0, p1}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_w4x8anl0
    goto :ep_s_w4x8anl0
    :ep_d_w4x8anl0
    nop
    :ep_s_w4x8anl0
    move-result p1

    return p1
.end method

.method public final getSpanFlags(Ljava/lang/Object;)I
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_c0m42a99
    goto :ep_s_c0m42a99
    :ep_d_c0m42a99
    nop
    :ep_s_c0m42a99
    invoke-interface {v0, p1}, Landroid/text/Spanned;->getSpanFlags(Ljava/lang/Object;)I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_g2bl0139
    goto :ep_s_g2bl0139
    :ep_d_g2bl0139
    nop
    :ep_s_g2bl0139
    move-result p1

    return p1
.end method

.method public final getSpanStart(Ljava/lang/Object;)I
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_naoqsvqk
    goto :ep_s_naoqsvqk
    :ep_d_naoqsvqk
    nop
    :ep_s_naoqsvqk
    invoke-interface {v0, p1}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_oz85t2by
    goto :ep_s_oz85t2by
    :ep_d_oz85t2by
    nop
    :ep_s_oz85t2by
    move-result p1

    return p1
.end method

.method public final getSpans(IILjava/lang/Class;)[Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(II",
            "Ljava/lang/Class<",
            "TT;>;)[TT;"
        }
    .end annotation

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_vbolnc71
    goto :ep_s_vbolnc71
    :ep_d_vbolnc71
    nop
    :ep_s_vbolnc71
    invoke-interface {v0, p1, p2, p3}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_t4spdcly
    goto :ep_s_t4spdcly
    :ep_d_t4spdcly
    nop
    :ep_s_t4spdcly
    move-result-object p1

    return-object p1
.end method

.method public final length()I
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_sslx4n0x
    goto :ep_s_sslx4n0x
    :ep_d_sslx4n0x
    nop
    :ep_s_sslx4n0x
    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_7btgqust
    goto :ep_s_7btgqust
    :ep_d_7btgqust
    nop
    :ep_s_7btgqust
    move-result v0

    return v0
.end method

.method public final nextSpanTransition(IILjava/lang/Class;)I
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_5smov6ml
    goto :ep_s_5smov6ml
    :ep_d_5smov6ml
    nop
    :ep_s_5smov6ml
    invoke-interface {v0, p1, p2, p3}, Landroid/text/Spanned;->nextSpanTransition(IILjava/lang/Class;)I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_8a7zljru
    goto :ep_s_8a7zljru
    :ep_d_8a7zljru
    nop
    :ep_s_8a7zljru
    move-result p1

    return p1
.end method

.method public final removeSpan(Ljava/lang/Object;)V
    .locals 1

    .line 1
    invoke-virtual {p0}, Lax;->a()V

    .line 4
    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    .line 6
    invoke-interface {v0, p1}, Landroid/text/Spannable;->removeSpan(Ljava/lang/Object;)V

    .line 9
    return-void
.end method

.method public final setSpan(Ljava/lang/Object;III)V
    .locals 1

    .line 1
    invoke-virtual {p0}, Lax;->a()V

    .line 4
    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    .line 6
    invoke-interface {v0, p1, p2, p3, p4}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 9
    return-void
.end method

.method public final subSequence(II)Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_ti15xtsf
    goto :ep_s_ti15xtsf
    :ep_d_ti15xtsf
    nop
    :ep_s_ti15xtsf
    invoke-interface {v0, p1, p2}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_fizic7hz
    goto :ep_s_fizic7hz
    :ep_d_fizic7hz
    nop
    :ep_s_fizic7hz
    move-result-object p1

    return-object p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_0cfa0mto
    goto :ep_s_0cfa0mto
    :ep_d_0cfa0mto
    nop
    :ep_s_0cfa0mto
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_sno238p6
    goto :ep_s_sno238p6
    :ep_d_sno238p6
    nop
    :ep_s_sno238p6
    move-result-object v0

    return-object v0
.end method
