.class public final Lax;
.super Ljava/lang/Object;
.source "SourceFile"
# ep-ipjbpdpzdaqa
# generated-24678
# optimised-60348

# interfaces
.implements Landroid/text/Spannable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lax$b;,
        Lax$a;
    }
.end annotation


# instance fields
.field public c:Z

.field public d:Landroid/text/Spannable;


# direct methods
.method public constructor <init>(Landroid/text/Spannable;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_hinwvq36
    goto :ep_s_hinwvq36
    :ep_d_hinwvq36
    nop
    :ep_s_hinwvq36
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lax;->c:Z

    .line 3
    iput-object p1, p0, Lax;->d:Landroid/text/Spannable;

    return-void
.end method

.method public constructor <init>(Ljava/lang/CharSequence;)V
    .locals 1

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_yj21xrym
    goto :ep_s_yj21xrym
    :ep_d_yj21xrym
    nop
    :ep_s_yj21xrym
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Lax;->c:Z

    .line 6
    new-instance v0, Landroid/text/SpannableString;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_tpoex75x
    goto :ep_s_tpoex75x
    :ep_d_tpoex75x
    nop
    :ep_s_tpoex75x
    invoke-direct {v0, p1}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    iput-object v0, p0, Lax;->d:Landroid/text/Spannable;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    .line 1
    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    .line 3
    iget-boolean v1, p0, Lax;->c:Z

    .line 5
    if-nez v1, :cond_1

    .line 7
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 9
    const/16 v2, 0x1c

    .line 11
    if-ge v1, v2, :cond_0

    .line 13
    new-instance v1, Lax$a;

    .line 15
    invoke-direct {v1}, Lax$a;-><init>()V

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    new-instance v1, Lax$b;

    .line 21
    invoke-direct {v1}, Lax$b;-><init>()V

    .line 24
    :goto_0
    invoke-virtual {v1, v0}, Lax$a;->a(Landroid/text/Spannable;)Z

    .line 27
    move-result v1

    .line 28
    if-eqz v1, :cond_1

    .line 30
    new-instance v1, Landroid/text/SpannableString;

    .line 32
    invoke-direct {v1, v0}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    .line 35
    iput-object v1, p0, Lax;->d:Landroid/text/Spannable;

    .line 37
    :cond_1
    const/4 v0, 0x1

    .line 38
    iput-boolean v0, p0, Lax;->c:Z

    .line 40
    return-void
.end method

.method public final charAt(I)C
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_fraijx5g
    goto :ep_s_fraijx5g
    :ep_d_fraijx5g
    nop
    :ep_s_fraijx5g
    invoke-interface {v0, p1}, Ljava/lang/CharSequence;->charAt(I)C

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_3z7n03vy
    goto :ep_s_3z7n03vy
    :ep_d_3z7n03vy
    nop
    :ep_s_3z7n03vy
    move-result p1

    return p1
.end method

.method public final chars()Ljava/util/stream/IntStream;
    .locals 1

    .line 1
    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    .line 3
    invoke-static {v0}, Lt;->m(Landroid/text/Spannable;)Ljava/util/stream/IntStream;

    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public final codePoints()Ljava/util/stream/IntStream;
    .locals 1

    .line 1
    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    .line 3
    invoke-static {v0}, Lt;->A(Landroid/text/Spannable;)Ljava/util/stream/IntStream;

    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public final getSpanEnd(Ljava/lang/Object;)I
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_uql8dzse
    goto :ep_s_uql8dzse
    :ep_d_uql8dzse
    nop
    :ep_s_uql8dzse
    invoke-interface {v0, p1}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_k73vj8eo
    goto :ep_s_k73vj8eo
    :ep_d_k73vj8eo
    nop
    :ep_s_k73vj8eo
    move-result p1

    return p1
.end method

.method public final getSpanFlags(Ljava/lang/Object;)I
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_3o8igfo5
    goto :ep_s_3o8igfo5
    :ep_d_3o8igfo5
    nop
    :ep_s_3o8igfo5
    invoke-interface {v0, p1}, Landroid/text/Spanned;->getSpanFlags(Ljava/lang/Object;)I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_cam8jymt
    goto :ep_s_cam8jymt
    :ep_d_cam8jymt
    nop
    :ep_s_cam8jymt
    move-result p1

    return p1
.end method

.method public final getSpanStart(Ljava/lang/Object;)I
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_s9b25c62
    goto :ep_s_s9b25c62
    :ep_d_s9b25c62
    nop
    :ep_s_s9b25c62
    invoke-interface {v0, p1}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_p4nuomq9
    goto :ep_s_p4nuomq9
    :ep_d_p4nuomq9
    nop
    :ep_s_p4nuomq9
    move-result p1

    return p1
.end method

.method public final getSpans(IILjava/lang/Class;)[Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(II",
            "Ljava/lang/Class<",
            "TT;>;)[TT;"
        }
    .end annotation

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_hg7ze8y7
    goto :ep_s_hg7ze8y7
    :ep_d_hg7ze8y7
    nop
    :ep_s_hg7ze8y7
    invoke-interface {v0, p1, p2, p3}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_pymdrr07
    goto :ep_s_pymdrr07
    :ep_d_pymdrr07
    nop
    :ep_s_pymdrr07
    move-result-object p1

    return-object p1
.end method

.method public final length()I
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_cvggx61t
    goto :ep_s_cvggx61t
    :ep_d_cvggx61t
    nop
    :ep_s_cvggx61t
    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_h20js9ow
    goto :ep_s_h20js9ow
    :ep_d_h20js9ow
    nop
    :ep_s_h20js9ow
    move-result v0

    return v0
.end method

.method public final nextSpanTransition(IILjava/lang/Class;)I
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_kktsqbw7
    goto :ep_s_kktsqbw7
    :ep_d_kktsqbw7
    nop
    :ep_s_kktsqbw7
    invoke-interface {v0, p1, p2, p3}, Landroid/text/Spanned;->nextSpanTransition(IILjava/lang/Class;)I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_hg9fwabk
    goto :ep_s_hg9fwabk
    :ep_d_hg9fwabk
    nop
    :ep_s_hg9fwabk
    move-result p1

    return p1
.end method

.method public final removeSpan(Ljava/lang/Object;)V
    .locals 1

    .line 1
    invoke-virtual {p0}, Lax;->a()V

    .line 4
    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    .line 6
    invoke-interface {v0, p1}, Landroid/text/Spannable;->removeSpan(Ljava/lang/Object;)V

    .line 9
    return-void
.end method

.method public final setSpan(Ljava/lang/Object;III)V
    .locals 1

    .line 1
    invoke-virtual {p0}, Lax;->a()V

    .line 4
    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    .line 6
    invoke-interface {v0, p1, p2, p3, p4}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 9
    return-void
.end method

.method public final subSequence(II)Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_k2bqdncq
    goto :ep_s_k2bqdncq
    :ep_d_k2bqdncq
    nop
    :ep_s_k2bqdncq
    invoke-interface {v0, p1, p2}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_1njyrjbc
    goto :ep_s_1njyrjbc
    :ep_d_1njyrjbc
    nop
    :ep_s_1njyrjbc
    move-result-object p1

    return-object p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lax;->d:Landroid/text/Spannable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_jsmftoud
    goto :ep_s_jsmftoud
    :ep_d_jsmftoud
    nop
    :ep_s_jsmftoud
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_qfdvhmcf
    goto :ep_s_qfdvhmcf
    :ep_d_qfdvhmcf
    nop
    :ep_s_qfdvhmcf
    move-result-object v0

    return-object v0
.end method
