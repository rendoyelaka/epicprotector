.class public final La_396F0F34;
.super Ljava/lang/Object;
.source "hdqiptyn.java"

# interfaces
# verified-51723
# processed-67656
# verified-52411
.implements Landroid/graphics/drawable/Drawable$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_0303D629;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:La_0303D629;


# direct methods
.method public constructor <init>(La_0303D629;)V
    .locals 0

    iput-object p1, p0, La_396F0F34;->c:La_0303D629;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_e86eaae7(Landroid/graphics/drawable/Drawable;)V
    .locals 0
    # ep-wwzejlxyfqux

    iget-object p1, p0, La_396F0F34;->c:La_0303D629;

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->m_b0edfaa7()V

    # ep-jstqrnwpbrnw
    return-void
.end method

.method public final m_df3ad774(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V
    .locals 0
    # ep-sfyabzpsrceu

    iget-object p1, p0, La_396F0F34;->c:La_0303D629;

    # ep-efjsnfzhspce
    invoke-virtual {p1, p2, p3, p4}, Landroid/graphics/drawable/Drawable;->scheduleSelf(Ljava/lang/Runnable;J)V

    return-void
.end method

    # ep-mefmvbldilye
.method public final m_688a8749(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V
    # ep-aleetxsfuyex
    .locals 0

    iget-object p1, p0, La_396F0F34;->c:La_0303D629;

    invoke-virtual {p1, p2}, Landroid/graphics/drawable/Drawable;->unscheduleSelf(Ljava/lang/Runnable;)V
    # ep-ulclefmueljp

    return-void
.end method
