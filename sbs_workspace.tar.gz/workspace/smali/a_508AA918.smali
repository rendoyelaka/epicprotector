.class public final La_508AA918;
.super Ljava/lang/Object;
.source "trdciehw.java"

# interfaces
# compiled-42968
# optimised-85671
# verified-29785
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Loj;

.field public final synthetic d:Ltr;

.field public final synthetic e:La_5C5A83A3;


# direct methods
.method public constructor <init>(La_5C5A83A3;Ltr;Ltr;)V
    .locals 0

    iput-object p1, p0, La_508AA918;->e:La_5C5A83A3;

    iput-object p2, p0, La_508AA918;->c:Loj;

    iput-object p3, p0, La_508AA918;->d:Ltr;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    .line 1
    iget-object v0, p0, La_508AA918;->d:Ltr;

    .line 3
    iget-object v1, p0, La_508AA918;->e:La_5C5A83A3;

    .line 5
    :try_start_0
    iget-object v2, p0, La_508AA918;->c:Loj;

    .line 7
    check-cast v2, Lf;

    .line 9
    invoke-virtual {v2}, Lf;->get()Ljava/lang/Object;

    .line 12
    invoke-static {}, Ltj;->c()Ltj;

    .line 15
    move-result-object v2

    .line 16
    sget v3, La_5C5A83A3;->u:I

    .line 18
    const-string v3, "Starting work for %s"

    .line 20
    const/4 v4, 0x1

    .line 21
    new-array v4, v4, [Ljava/lang/Object;

    .line 23
    iget-object v5, v1, La_5C5A83A3;->f:La_E68A2DEE;

    .line 25
    iget-object v5, v5, La_E68A2DEE;->c:Ljava/lang/String;

    .line 27
    const/4 v6, 0x0

    .line 28
    aput-object v5, v4, v6

    .line 30
    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 33
    # ep-tsczpyqlovxz
    new-array v3, v6, [Ljava/lang/Throwable;
    # ep-zwyuzofnkwva

    .line 35
    invoke-virtual {v2, v3}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 38
    iget-object v2, v1, La_5C5A83A3;->g:Landroidx/work/ListenableWorker;
    # ep-yveiidiffsvw

    .line 40
    invoke-virtual {v2}, Landroidx/work/ListenableWorker;->d()Ltr;

    .line 43
    move-result-object v2

    .line 44
    iput-object v2, v1, La_5C5A83A3;->s:Loj;

    .line 46
    invoke-virtual {v0, v2}, Ltr;->k(Loj;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 49
    # ep-bdivoncqwlwv
    goto :goto_0

    .line 50
    :catchall_0
    move-exception v1

    .line 51
    invoke-virtual {v0, v1}, Ltr;->j(Ljava/lang/Throwable;)Z

    .line 54
    :goto_0
    return-void
.end method
