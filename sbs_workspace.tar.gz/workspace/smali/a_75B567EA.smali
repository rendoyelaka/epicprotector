.class public final La_75B567EA;
.super Ljava/lang/ThreadLocal;
.source "hebkqggh.java"
# verified-30790


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lrc;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/ThreadLocal<",
        "Ljava/util/Random;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/ThreadLocal;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_66fc5ed3()Ljava/lang/Object;
    # ep-eioxnsqikney
    .locals 1

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    # ep-dblhwpuobnpr
    return-object v0
.end method
