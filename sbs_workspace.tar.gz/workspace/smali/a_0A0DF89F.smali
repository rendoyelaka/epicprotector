.class public abstract La_0A0DF89F;
# ep-qnnpxymwmwsq
.super Ljava/lang/Object;
.source "wbeumonp.java"

# optimised-57099
# optimised-71958
# compiled-41516
# interfaces
.implements Ljava/util/Iterator;
.implements La_44A19DD9;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "e"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "Ljava/util/Map$Entry<",
        "TK;TV;>;>;",
        "Lwq$f<",
        "TK;TV;>;"
    }
.end annotation


# instance fields
.field public c:La_EC2B235F;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lwq$c<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field public d:La_EC2B235F;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lwq$c<",
            "TK;TV;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(La_EC2B235F;La_EC2B235F;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;",
            "Lwq$c<",
            "TK;TV;>;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p2, p0, La_0A0DF89F;->c:La_EC2B235F;

    .line 6
    iput-object p1, p0, La_0A0DF89F;->d:La_EC2B235F;

    .line 8
    return-void
.end method


# virtual methods
.method public final a(La_EC2B235F;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;)V"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_0A0DF89F;->c:La_EC2B235F;

    .line 3
    const/4 v1, 0x0

    .line 4
    if-ne v0, p1, :cond_0

    .line 6
    iget-object v0, p0, La_0A0DF89F;->d:La_EC2B235F;

    .line 8
    if-ne p1, v0, :cond_0

    .line 10
    iput-object v1, p0, La_0A0DF89F;->d:La_EC2B235F;

    .line 12
    iput-object v1, p0, La_0A0DF89F;->c:La_EC2B235F;

    .line 14
    :cond_0
    iget-object v0, p0, La_0A0DF89F;->c:La_EC2B235F;

    .line 16
    if-ne v0, p1, :cond_1

    .line 18
    invoke-virtual {p0, v0}, La_0A0DF89F;->b(La_EC2B235F;)La_EC2B235F;

    .line 21
    move-result-object v0

    .line 22
    iput-object v0, p0, La_0A0DF89F;->c:La_EC2B235F;

    .line 24
    :cond_1
    iget-object v0, p0, La_0A0DF89F;->d:La_EC2B235F;

    .line 26
    if-ne v0, p1, :cond_4

    .line 28
    iget-object p1, p0, La_0A0DF89F;->c:La_EC2B235F;

    .line 30
    if-eq v0, p1, :cond_3

    .line 32
    if-nez p1, :cond_2

    .line 34
    goto :goto_0

    .line 35
    :cond_2
    invoke-virtual {p0, v0}, La_0A0DF89F;->c(La_EC2B235F;)La_EC2B235F;

    .line 38
    move-result-object v1

    .line 39
    :cond_3
    :goto_0
    iput-object v1, p0, La_0A0DF89F;->d:La_EC2B235F;

    .line 41
    :cond_4
    return-void
.end method

.method public abstract b(La_EC2B235F;)La_EC2B235F;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;)",
            "Lwq$c<",
            "TK;TV;>;"
        }
    .end annotation
.end method

.method public abstract c(La_EC2B235F;)La_EC2B235F;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;)",
            "Lwq$c<",
            "TK;TV;>;"
        }
    .end annotation
.end method

.method public final m_bd51c992()Z
    .locals 1

    iget-object v0, p0, La_0A0DF89F;->d:La_EC2B235F;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final m_092c0567()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, La_0A0DF89F;->d:La_EC2B235F;

    .line 3
    iget-object v1, p0, La_0A0DF89F;->c:La_EC2B235F;

    .line 5
    if-eq v0, v1, :cond_1

    .line 7
    if-nez v1, :cond_0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    invoke-virtual {p0, v0}, La_0A0DF89F;->c(La_EC2B235F;)La_EC2B235F;

    .line 13
    move-result-object v1

    .line 14
    goto :goto_1

    .line 15
    :cond_1
    :goto_0
    const/4 v1, 0x0

    .line 16
    :goto_1
    iput-object v1, p0, La_0A0DF89F;->d:La_EC2B235F;

    .line 18
    return-object v0
.end method
