.class public final LWorkerWrapper$a;
.super Ljava/lang/Object;
.source "dukhvyxm.java"
# ep-iwcmudllccic
# validated-93274
# verified-19080
# generated-83373


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LWorkerWrapper;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lpd;

.field public final c:Lnu;

.field public final d:Landroidx/work/a;

.field public final e:Landroidx/work/impl/WorkDatabase;

.field public final f:Ljava/lang/String;

.field public g:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lhr;",
            ">;"
        }
    .end annotation
.end field

.field public h:Landroidx/work/WorkerParameters$a;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/work/a;Lnu;Lpd;Landroidx/work/impl/WorkDatabase;Ljava/lang/String;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Landroidx/work/WorkerParameters$a;

    .line 6
    invoke-direct {v0}, Landroidx/work/WorkerParameters$a;-><init>()V

    .line 9
    iput-object v0, p0, LWorkerWrapper$a;->h:Landroidx/work/WorkerParameters$a;

    .line 11
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 14
    move-result-object p1

    .line 15
    iput-object p1, p0, LWorkerWrapper$a;->a:Landroid/content/Context;

    .line 17
    iput-object p3, p0, LWorkerWrapper$a;->c:Lnu;

    .line 19
    iput-object p4, p0, LWorkerWrapper$a;->b:Lpd;

    .line 21
    iput-object p2, p0, LWorkerWrapper$a;->d:Landroidx/work/a;

    .line 23
    iput-object p5, p0, LWorkerWrapper$a;->e:Landroidx/work/impl/WorkDatabase;

    .line 25
    iput-object p6, p0, LWorkerWrapper$a;->f:Ljava/lang/String;

    .line 27
    return-void
.end method
