.class public final Lbr;
.super LViewModelProvider;
# processed-87075
# verified-49502
# verified-29313
.source "zuzpaukv.java"
# ep-oznaqihblqzf


# instance fields
.field public final c:Ljava/util/LinkedHashMap;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, LViewModelProvider;-><init>()V

    .line 4
    new-instance v0, Ljava/util/LinkedHashMap;

    .line 6
    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    .line 9
    iput-object v0, p0, Lbr;->c:Ljava/util/LinkedHashMap;

    .line 11
    return-void
.end method
