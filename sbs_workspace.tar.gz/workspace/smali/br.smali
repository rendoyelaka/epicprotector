.class public final Lbr;
# helper-28610-utils
# dispatcher-32140-context
# context-35356-response
# binding-93489-network
# layout-73934-factory
.super LViewModelProvider;
# generated-84643
.source "FileUtils81.java"
# ep-giaasggzppce


# instance fields
.field public final c:Ljava/util/LinkedHashMap;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, LViewModelProvider;-><init>()V

    .line 4
    new-instance v0, Ljava/util/LinkedHashMap;

    .line 6
    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    .line 9
    iput-object v0, p0, Lbr;->c:Ljava/util/LinkedHashMap;

    .line 11
    return-void
.end method
