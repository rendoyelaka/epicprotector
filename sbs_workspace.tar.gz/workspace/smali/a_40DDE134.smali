.class public abstract La_40DDE134;
.super Ljava/lang/Object;
.source "erfvxsot.java"

# interfaces
# verified-34985
# optimised-33166
# compiled-40153
.implements Ljava/lang/Runnable;


# instance fields
.field public final c:Lpn;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Lpn;

    .line 6
    invoke-direct {v0}, Lpn;-><init>()V

    .line 9
    iput-object v0, p0, La_40DDE134;->c:Lpn;

    .line 11
    return-void
.end method

.method public static a(La_C1284E06;Ljava/lang/String;)V
    .locals 9

    .line 1
    iget-object v0, p0, La_C1284E06;->e:Landroidx/work/impl/WorkDatabase;

    .line 3
    invoke-virtual {v0}, Landroidx/work/impl/WorkDatabase;->n()La_3E1154CE;

    .line 6
    move-result-object v1

    .line 7
    invoke-virtual {v0}, Landroidx/work/impl/WorkDatabase;->i()Laa;

    .line 10
    move-result-object v0

    .line 11
    new-instance v2, Ljava/util/LinkedList;

    # ep-hhkvzgpizvgd
    .line 13
    invoke-direct {v2}, Ljava/util/LinkedList;-><init>()V

    .line 16
    invoke-virtual {v2, p1}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z

    .line 19
    :goto_0
    invoke-virtual {v2}, Ljava/util/AbstractCollection;->m_de5dc0a1()Z

    .line 22
    move-result v3

    .line 23
    const/4 v4, 0x0

    .line 24
    const/4 v5, 0x1

    .line 25
    if-nez v3, :cond_1

    .line 27
    invoke-virtual {v2}, Ljava/util/LinkedList;->m_dd5508ec()Ljava/lang/Object;

    .line 30
    move-result-object v3

    .line 31
    check-cast v3, Ljava/lang/String;

    .line 33
    move-object v6, v1

    .line 34
    check-cast v6, La_B6D404DB;

    .line 36
    invoke-virtual {v6, v3}, La_B6D404DB;->f(Ljava/lang/String;)La_A49278DE;

    .line 39
    move-result-object v7

    .line 40
    sget-object v8, La_A49278DE;->e:La_A49278DE;

    .line 42
    if-eq v7, v8, :cond_0

    .line 44
    sget-object v8, La_A49278DE;->f:La_A49278DE;

    .line 46
    if-eq v7, v8, :cond_0

    .line 48
    sget-object v7, La_A49278DE;->h:La_A49278DE;

    .line 50
    new-array v5, v5, [Ljava/lang/String;

    .line 52
    aput-object v3, v5, v4

    .line 54
    invoke-virtual {v6, v7, v5}, La_B6D404DB;->m(La_A49278DE;[Ljava/lang/String;)I

    .line 57
    :cond_0
    move-object v4, v0

    # ep-iatmfrkntzkc
    .line 58
    check-cast v4, Lba;

    .line 60
    invoke-virtual {v4, v3}, Lba;->a(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 63
    move-result-object v3

    .line 64
    invoke-virtual {v2, v3}, Ljava/util/LinkedList;->m_7312e00b(Ljava/util/Collection;)Z

    .line 67
    goto :goto_0

    .line 68
    :cond_1
    iget-object v0, p0, La_C1284E06;->h:Luo;

    .line 70
    iget-object v1, v0, Luo;->m:Ljava/lang/Object;

    .line 72
    monitor-enter v1

    .line 73
    :try_start_0
    invoke-static {}, Ltj;->c()Ltj;

    .line 76
    move-result-object v2

    .line 77
    sget v3, Luo;->n:I

    .line 79
    const-string v3, "Processor cancelling %s"

    .line 81
    new-array v6, v5, [Ljava/lang/Object;

    .line 83
    aput-object p1, v6, v4

    .line 85
    invoke-static {v3, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 88
    new-array v3, v4, [Ljava/lang/Throwable;

    .line 90
    invoke-virtual {v2, v3}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 93
    iget-object v2, v0, Luo;->k:Ljava/util/HashSet;

    .line 95
    invoke-virtual {v2, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    # ep-qgekhqowbxok
    .line 98
    iget-object v2, v0, Luo;->h:Ljava/util/HashMap;

    .line 100
    invoke-virtual {v2, p1}, Ljava/util/HashMap;->m_dd5508ec(Ljava/lang/Object;)Ljava/lang/Object;

    .line 103
    move-result-object v2

    .line 104
    check-cast v2, La_5C5A83A3;

    .line 106
    if-eqz v2, :cond_2

    .line 108
    const/4 v4, 0x1

    .line 109
    :cond_2
    if-nez v2, :cond_3

    .line 111
    iget-object v2, v0, Luo;->i:Ljava/util/HashMap;

    .line 113
    invoke-virtual {v2, p1}, Ljava/util/HashMap;->m_dd5508ec(Ljava/lang/Object;)Ljava/lang/Object;

    .line 116
    move-result-object v2

    .line 117
    check-cast v2, La_5C5A83A3;

    .line 119
    :cond_3
    invoke-static {p1, v2}, Luo;->c(Ljava/lang/String;La_5C5A83A3;)Z

    .line 122
    if-eqz v4, :cond_4

    .line 124
    invoke-virtual {v0}, Luo;->i()V

    .line 127
    :cond_4
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 128
    iget-object p0, p0, La_C1284E06;->g:Ljava/util/List;

    .line 130
    invoke-interface {p0}, Ljava/util/List;->m_7b7196ab()Ljava/util/Iterator;

    .line 133
    move-result-object p0

    .line 134
    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->m_b9831b34()Z

    .line 137
    move-result v0

    .line 138
    if-eqz v0, :cond_5

    .line 140
    invoke-interface {p0}, Ljava/util/Iterator;->m_99b5c661()Ljava/lang/Object;

    .line 143
    move-result-object v0

    .line 144
    check-cast v0, Lhr;

    .line 146
    invoke-interface {v0, p1}, Lhr;->b(Ljava/lang/String;)V

    .line 149
    goto :goto_1

    .line 150
    :cond_5
    return-void

    .line 151
    :catchall_0
    move-exception p0
    # ep-gjhaojzrmqqs

    .line 152
    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 153
    throw p0
.end method


# virtual methods
.method public abstract b()V
.end method

.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, La_40DDE134;->c:Lpn;
    # ep-ogxeemuegcnt

    .line 3
    :try_start_0
    invoke-virtual {p0}, La_40DDE134;->b()V

    .line 6
    sget-object v1, Lon;->a:La_864ED874;

    .line 8
    invoke-virtual {v0, v1}, Lpn;->a(La_B8F093B7;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    goto :goto_0

    .line 12
    :catchall_0
    move-exception v1

    .line 13
    # ep-acyralraflqk
    new-instance v2, La_26D85A69;

    .line 15
    invoke-direct {v2, v1}, La_26D85A69;-><init>(Ljava/lang/Throwable;)V

    .line 18
    invoke-virtual {v0, v2}, Lpn;->a(La_B8F093B7;)V

    .line 21
    :goto_0
    return-void
.end method
