.class public final La_5738C075;
.super Ljava/lang/Object;
# ep-taxbdczwfoxp
# optimised-74768
# validated-90688
.source "yvwmgznm.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Llj;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/widget/PopupWindow;Landroid/graphics/Rect;)V
    .locals 0

    invoke-static {p0, p1}, Ls;->s(Landroid/widget/PopupWindow;Landroid/graphics/Rect;)V

    return-void
.end method

.method public static b(Landroid/widget/PopupWindow;Z)V
    .locals 0

    invoke-static {p0, p1}, Ls;->t(Landroid/widget/PopupWindow;Z)V

    return-void
.end method
