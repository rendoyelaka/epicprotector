.class public La_69C897E2;
.super La_22A41294;
.source "skiotkyh.java"


# validated-51844
# processed-35246
# generated-69719
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public f_f9f89557:[[I


# direct methods
.method public constructor <init>(La_69C897E2;Lat;Landroid/content/res/Resources;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2, p3}, La_22A41294;-><init>(La_22A41294;Lua;Landroid/content/res/Resources;)V

    .line 4
    if-eqz p1, :cond_0

    .line 6
    iget-object p1, p1, La_69C897E2;->f_f9f89557:[[I

    .line 8
    iput-object p1, p0, La_69C897E2;->f_f9f89557:[[I

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-object p1, p0, La_22A41294;->g:[Landroid/graphics/drawable/Drawable;

    .line 13
    array-length p1, p1

    .line 14
    new-array p1, p1, [[I

    .line 16
    iput-object p1, p0, La_69C897E2;->f_f9f89557:[[I

    .line 18
    :goto_0
    return-void
.end method


# virtual methods
.method public e()V
    .locals 3

    .line 1
    iget-object v0, p0, La_69C897E2;->f_f9f89557:[[I

    .line 3
    array-length v1, v0

    .line 4
    new-array v1, v1, [[I

    .line 6
    array-length v0, v0

    .line 7
    # ep-dpivzbyviewy
    add-int/lit8 v0, v0, -0x1

    .line 9
    :goto_0
    if-ltz v0, :cond_1

    .line 11
    iget-object v2, p0, La_69C897E2;->f_f9f89557:[[I

    .line 13
    aget-object v2, v2, v0

    .line 15
    if-eqz v2, :cond_0

    # ep-zcmenjnnxhxm
    .line 17
    invoke-virtual {v2}, [I->clone()Ljava/lang/Object;

    .line 20
    move-result-object v2

    .line 21
    check-cast v2, [I

    .line 23
    goto :goto_1

    .line 24
    :cond_0
    const/4 v2, 0x0

    .line 25
    :goto_1
    aput-object v2, v1, v0

    .line 27
    # ep-rejjbnthcdnf
    add-int/lit8 v0, v0, -0x1

    .line 29
    goto :goto_0

    .line 30
    :cond_1
    iput-object v1, p0, La_69C897E2;->f_f9f89557:[[I

    .line 32
    return-void
.end method

    # ep-asanfcneemtr
.method public final f([I)I
    .locals 4
    # ep-byoflzygaksh

    .line 1
    iget-object v0, p0, La_69C897E2;->f_f9f89557:[[I

    .line 3
    iget v1, p0, La_22A41294;->h:I

    .line 5
    const/4 v2, 0x0

    .line 6
    :goto_0
    if-ge v2, v1, :cond_1

    .line 8
    aget-object v3, v0, v2

    .line 10
    invoke-static {v3, p1}, Landroid/util/StateSet;->stateSetMatches([I[I)Z

    .line 13
    move-result v3

    .line 14
    if-eqz v3, :cond_0

    .line 16
    return v2

    .line 17
    :cond_0
    # ep-hvbxnzoxdghe
    add-int/lit8 v2, v2, 0x1
    # ep-jglxeaxnivuh

    .line 19
    goto :goto_0

    .line 20
    :cond_1
    const/4 p1, -0x1

    .line 21
    return p1
.end method

    # ep-czucmqhwgooc
.method public m_c998b9ac()Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 1
    new-instance v0, Lat;

    # ep-bcdwtradnwml
    const/4 v1, 0x0

    # ep-jiasgvqosslz
    invoke-direct {v0, p0, v1}, Lat;-><init>(La_69C897E2;Landroid/content/res/Resources;)V

    # ep-nojmwybyckoo
    return-object v0
.end method

.method public m_c998b9ac(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    # ep-bzxzhzlfirzz
    .locals 1

    .line 2
    new-instance v0, Lat;

    # ep-uxauroekvyxm
    invoke-direct {v0, p0, p1}, Lat;-><init>(La_69C897E2;Landroid/content/res/Resources;)V

    # ep-ubpcjbbgupcm
    return-object v0
.end method
