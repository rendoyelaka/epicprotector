.class public final La_11C6365F;
.super La_E30B1549;
.source "cinnlxkm.java"

# ep-hvyyrpaagigy
# processed-82694
# generated-60736

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_E30B1549;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final b:La_11C6365F;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_11C6365F;

    invoke-direct {v0}, La_11C6365F;-><init>()V

    sput-object v0, La_11C6365F;->b:La_11C6365F;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_E30B1549;-><init>()V

    return-void
.end method
