.class public final La_273722B1;
# ep-bblsizhkxots
.super La_07EFADCD;
.source "rtjmcbuh.java"

# processed-76675

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La_07EFADCD;"
    }
.end annotation


# instance fields
.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Landroidx/activity/result/a;


# direct methods
.method public constructor <init>(Landroidx/activity/result/a;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, La_273722B1;->d:Landroidx/activity/result/a;

    iput-object p2, p0, La_273722B1;->c:Ljava/lang/String;

    invoke-direct {p0}, La_07EFADCD;-><init>()V

    return-void
.end method
