.class public interface abstract La_2CD78352;
# ep-bbajdcusxvrr
.super Ljava/lang/Object;
.source "bzzimdcc.java"

# verified-21759
# verified-99517

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Luk;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method
