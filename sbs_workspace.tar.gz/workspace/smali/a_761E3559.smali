.class public final La_761E3559;
.super Ljava/lang/Object;
# generated-91536
.source "whahoecm.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_126D8786;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public static a(Landroid/content/Context;)Ljava/io/File;
    .locals 0
    # ep-bbbglbxtnrzr

    invoke-virtual {p0}, Landroid/content/Context;->getCodeCacheDir()Ljava/io/File;
    # ep-uvupjlymjhrf

    # ep-xjmfffwebmrq
    move-result-object p0

    return-object p0
.end method

.method public static b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .locals 0
    # ep-luaiqvrtxgio

    # ep-mqqisbfouajz
    invoke-virtual {p0, p1}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method

.method public static c(Landroid/content/Context;)Ljava/io/File;
    .locals 0
    # ep-sakgddojcztw

    invoke-virtual {p0}, Landroid/content/Context;->getNoBackupFilesDir()Ljava/io/File;

    move-result-object p0

    # ep-ecdvezndubhn
    return-object p0
.end method
