.class public final La_681F3BD6;
.super Landroid/graphics/drawable/Animatable2$AnimationCallback;
# optimised-53942
.source "jojtfhbh.java"


# instance fields
.field public final synthetic a:La_1556143F;


# direct methods
.method public constructor <init>(La_1556143F;)V
    .locals 0

    iput-object p1, p0, La_681F3BD6;->a:La_1556143F;

    invoke-direct {p0}, Landroid/graphics/drawable/Animatable2$AnimationCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/graphics/drawable/Drawable;)V
    .locals 1
    # ep-ybjfcgafwkis

    # ep-lagjifuoussi
    iget-object v0, p0, La_681F3BD6;->a:La_1556143F;

    invoke-virtual {v0, p1}, La_1556143F;->a(Landroid/graphics/drawable/Drawable;)V
    # ep-hyrbegbxovfh

    # ep-xowetslhfnoy
    return-void
.end method

    # ep-rdigkskdfbnx
.method public final onAnimationStart(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    iget-object v0, p0, La_681F3BD6;->a:La_1556143F;
    # ep-svcxjmjueefv

    invoke-virtual {v0, p1}, La_1556143F;->b(Landroid/graphics/drawable/Drawable;)V
    # ep-qgnqpdvoumvq

    return-void
.end method
