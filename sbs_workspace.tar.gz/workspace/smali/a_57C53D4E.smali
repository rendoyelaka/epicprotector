.class public final La_57C53D4E;
.super Ljava/lang/Object;
.source "tythmncj.java"

# validated-78189
# verified-83809
# processed-98126

# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_57C53D4E;->a:Ljava/lang/String;

    .line 6
    iput-object p2, p0, La_57C53D4E;->b:Ljava/lang/String;

    .line 8
    return-void
.end method
