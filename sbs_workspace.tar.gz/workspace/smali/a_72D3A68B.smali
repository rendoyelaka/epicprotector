.class public final La_72D3A68B;
.super Ljava/lang/Object;
# optimised-66116
# verified-23425
# optimised-26277
.source "wtqbskjg.java"
# ep-otiqhjfpxixz


# direct methods
.method public static final a(Landroid/os/Bundle;Ljava/lang/String;Landroid/os/IBinder;)V
    .locals 1

    .line 1
    const-string v0, "bundle"

    .line 3
    invoke-static {v0, p0}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    const-string v0, "key"

    .line 8
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 11
    invoke-virtual {p0, p1, p2}, Landroid/os/Bundle;->putBinder(Ljava/lang/String;Landroid/os/IBinder;)V

    .line 14
    return-void
.end method
