.class public final LEnqueueRunnable;
.super Ljava/lang/Object;
.source "njagznrp.java"

# ep-qrghgmnhcvee
# compiled-72357
# verified-48142
# compiled-41731
# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final c:LWorkContinuationImpl;

.field public final d:Lpn;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "EnqueueRunnable"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(LWorkContinuationImpl;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, LEnqueueRunnable;->c:LWorkContinuationImpl;

    .line 6
    new-instance p1, Lpn;

    .line 8
    invoke-direct {p1}, Lpn;-><init>()V

    .line 11
    iput-object p1, p0, LEnqueueRunnable;->d:Lpn;

    .line 13
    return-void
.end method

.method public static a(LWorkContinuationImpl;)Z
    .locals 27

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v1, v0, LWorkContinuationImpl;->i:Ljava/util/List;

    .line 5
    const/4 v2, 0x1

    .line 6
    const/4 v3, 0x0

    .line 7
    if-eqz v1, :cond_1

    .line 9
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 12
    move-result-object v1

    .line 13
    const/4 v4, 0x0

    .line 14
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    move-result v5

    .line 18
    if-eqz v5, :cond_2

    .line 20
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    move-result-object v5

    .line 24
    check-cast v5, LWorkContinuationImpl;

    .line 26
    iget-boolean v6, v5, LWorkContinuationImpl;->j:Z

    .line 28
    if-nez v6, :cond_0

    .line 30
    invoke-static {v5}, LEnqueueRunnable;->a(LWorkContinuationImpl;)Z

    .line 33
    move-result v5

    .line 34
    or-int/2addr v4, v5

    .line 35
    goto :goto_0

    .line 36
    :cond_0
    invoke-static {}, Ltj;->c()Ltj;

    .line 39
    move-result-object v6

    .line 40
    new-array v7, v2, [Ljava/lang/Object;

    .line 42
    iget-object v5, v5, LWorkContinuationImpl;->g:Ljava/util/ArrayList;

    .line 44
    const-string v8, ", "

    .line 46
    invoke-static {v8, v5}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    .line 49
    move-result-object v5

    .line 50
    aput-object v5, v7, v3

    .line 52
    const-string v5, "Already enqueued work ids (%s)."

    .line 54
    invoke-static {v5, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 57
    new-array v5, v3, [Ljava/lang/Throwable;

    .line 59
    invoke-virtual {v6, v5}, Ltj;->f([Ljava/lang/Throwable;)V

    .line 62
    goto :goto_0

    .line 63
    :cond_1
    const/4 v4, 0x0

    .line 64
    :cond_2
    invoke-static/range {p0 .. p0}, LWorkContinuationImpl;->r(LWorkContinuationImpl;)Ljava/util/HashSet;

    .line 67
    move-result-object v1

    .line 68
    new-array v5, v3, [Ljava/lang/String;

    .line 70
    invoke-interface {v1, v5}, Ljava/util/Set;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 73
    move-result-object v1

    .line 74
    check-cast v1, [Ljava/lang/String;

    .line 76
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 79
    move-result-wide v5

    .line 80
    iget-object v7, v0, LWorkContinuationImpl;->c:LWorkManagerImpl;

    .line 82
    iget-object v8, v7, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 84
    if-eqz v1, :cond_3

    .line 86
    array-length v9, v1

    .line 87
    if-lez v9, :cond_3

    .line 89
    const/4 v9, 0x1

    .line 90
    goto :goto_1

    .line 91
    :cond_3
    const/4 v9, 0x0

    .line 92
    :goto_1
    sget-object v10, LWorkInfo_State;->e:LWorkInfo_State;

    .line 94
    sget-object v11, LWorkInfo_State;->h:LWorkInfo_State;

    .line 96
    sget-object v12, LWorkInfo_State;->f:LWorkInfo_State;

    .line 98
    if-eqz v9, :cond_8

    .line 100
    array-length v13, v1

    .line 101
    const/4 v14, 0x0

    .line 102
    const/4 v15, 0x1

    .line 103
    const/16 v16, 0x0

    .line 105
    const/16 v17, 0x0

    .line 107
    :goto_2
    if-ge v14, v13, :cond_9

    .line 109
    aget-object v3, v1, v14

    .line 111
    invoke-virtual {v8}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 114
    move-result-object v18

    .line 115
    move-object/from16 v2, v18

    .line 117
    check-cast v2, LWorkSpecDao;

    .line 119
    invoke-virtual {v2, v3}, LWorkSpecDao;->h(Ljava/lang/String;)LWorkSpec;

    .line 122
    move-result-object v2

    .line 123
    if-nez v2, :cond_4

    .line 125
    invoke-static {}, Ltj;->c()Ltj;

    .line 128
    move-result-object v1

    .line 129
    const/4 v2, 0x1

    .line 130
    new-array v5, v2, [Ljava/lang/Object;

    .line 132
    const/4 v2, 0x0

    .line 133
    aput-object v3, v5, v2

    .line 135
    const-string v3, "Prerequisite %s doesn\'t exist; not enqueuing"

    .line 137
    invoke-static {v3, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 140
    new-array v3, v2, [Ljava/lang/Throwable;

    .line 142
    invoke-virtual {v1, v3}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 145
    move/from16 v20, v4

    .line 147
    goto/16 :goto_6

    .line 149
    :cond_4
    iget-object v2, v2, LWorkSpec;->b:LWorkInfo_State;

    .line 151
    if-ne v2, v10, :cond_5

    .line 153
    const/4 v3, 0x1

    .line 154
    goto :goto_3

    .line 155
    :cond_5
    const/4 v3, 0x0

    .line 156
    :goto_3
    and-int/2addr v15, v3

    .line 157
    if-ne v2, v12, :cond_6

    .line 159
    const/16 v17, 0x1

    .line 161
    goto :goto_4

    .line 162
    :cond_6
    if-ne v2, v11, :cond_7

    .line 164
    const/16 v16, 0x1

    .line 166
    :cond_7
    :goto_4
    add-int/lit8 v14, v14, 0x1

    .line 168
    const/4 v2, 0x1

    .line 169
    const/4 v3, 0x0

    .line 170
    goto :goto_2

    .line 171
    :cond_8
    const/4 v15, 0x1

    .line 172
    const/16 v16, 0x0

    .line 174
    const/16 v17, 0x0

    .line 176
    :cond_9
    iget-object v2, v0, LWorkContinuationImpl;->d:Ljava/lang/String;

    .line 178
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 181
    move-result v3

    .line 182
    const/4 v13, 0x1

    .line 183
    xor-int/2addr v3, v13

    .line 184
    if-eqz v3, :cond_a

    .line 186
    if-nez v9, :cond_a

    .line 188
    const/4 v13, 0x1

    .line 189
    goto :goto_5

    .line 190
    :cond_a
    const/4 v13, 0x0

    .line 191
    :goto_5
    sget-object v14, LWorkInfo_State;->c:LWorkInfo_State;

    .line 193
    if-eqz v13, :cond_1d

    .line 195
    invoke-virtual {v8}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 198
    move-result-object v13

    .line 199
    check-cast v13, LWorkSpecDao;

    .line 201
    invoke-virtual {v13, v2}, LWorkSpecDao;->i(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 204
    move-result-object v13

    .line 205
    invoke-virtual {v13}, Ljava/util/ArrayList;->isEmpty()Z

    .line 208
    move-result v18

    .line 209
    if-nez v18, :cond_1d

    .line 211
    move/from16 v18, v9

    .line 213
    sget-object v9, Lkc;->e:Lkc;

    .line 215
    move/from16 v19, v15

    .line 217
    sget-object v15, Lkc;->f:Lkc;

    .line 219
    move/from16 v20, v4

    .line 221
    iget-object v4, v0, LWorkContinuationImpl;->e:Lkc;

    .line 223
    if-eq v4, v9, :cond_10

    .line 225
    if-ne v4, v15, :cond_b

    .line 227
    goto :goto_8

    .line 228
    :cond_b
    sget-object v9, Lkc;->d:Lkc;

    .line 230
    if-ne v4, v9, :cond_e

    .line 232
    invoke-virtual {v13}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 235
    move-result-object v4

    .line 236
    :cond_c
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 239
    move-result v9

    .line 240
    if-eqz v9, :cond_e

    .line 242
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 245
    move-result-object v9

    .line 246
    check-cast v9, LWorkSpec$a;

    .line 248
    iget-object v9, v9, LWorkSpec$a;->b:LWorkInfo_State;

    .line 250
    if-eq v9, v14, :cond_d

    .line 252
    sget-object v10, LWorkInfo_State;->d:LWorkInfo_State;

    .line 254
    if-ne v9, v10, :cond_c

    .line 256
    :cond_d
    :goto_6
    const/4 v1, 0x1

    .line 257
    const/4 v3, 0x0

    .line 258
    goto/16 :goto_1e

    .line 260
    :cond_e
    new-instance v4, Ln5;

    .line 262
    invoke-direct {v4, v7, v2}, Ln5;-><init>(LWorkManagerImpl;Ljava/lang/String;)V

    .line 265
    invoke-virtual {v4}, Lo5;->run()V

    .line 268
    invoke-virtual {v8}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 271
    move-result-object v4

    .line 272
    invoke-virtual {v13}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 275
    move-result-object v9

    .line 276
    :goto_7
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 279
    move-result v10

    .line 280
    if-eqz v10, :cond_f

    .line 282
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 285
    move-result-object v10

    .line 286
    check-cast v10, LWorkSpec$a;

    .line 288
    iget-object v10, v10, LWorkSpec$a;->a:Ljava/lang/String;

    .line 290
    move-object v13, v4

    .line 291
    check-cast v13, LWorkSpecDao;

    .line 293
    invoke-virtual {v13, v10}, LWorkSpecDao;->a(Ljava/lang/String;)V

    .line 296
    goto :goto_7

    .line 297
    :cond_f
    move/from16 v21, v3

    .line 299
    move-wide/from16 v25, v5

    .line 301
    move-object/from16 v24, v7

    .line 303
    move-object/from16 v23, v14

    .line 305
    move/from16 v9, v18

    .line 307
    move/from16 v15, v19

    .line 309
    const/4 v3, 0x1

    .line 310
    const/4 v7, 0x0

    .line 311
    goto/16 :goto_10

    .line 313
    :cond_10
    :goto_8
    invoke-virtual {v8}, Landroidx/work/impl/WorkDatabase;->i()Laa;

    .line 316
    move-result-object v9

    .line 317
    move/from16 v21, v3

    .line 319
    new-instance v3, Ljava/util/ArrayList;

    .line 321
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 324
    invoke-virtual {v13}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 327
    move-result-object v13

    .line 328
    :goto_9
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    .line 331
    move-result v18

    .line 332
    if-eqz v18, :cond_18

    .line 334
    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 337
    move-result-object v18

    .line 338
    move-object/from16 v22, v13

    .line 340
    move-object/from16 v13, v18

    .line 342
    check-cast v13, LWorkSpec$a;

    .line 344
    move-object/from16 v23, v14

    .line 346
    iget-object v14, v13, LWorkSpec$a;->a:Ljava/lang/String;

    .line 348
    move-object/from16 v24, v7

    .line 350
    move-object v7, v9

    .line 351
    check-cast v7, Lba;

    .line 353
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 356
    move-object/from16 v18, v9

    .line 358
    const-string v9, "SELECT COUNT(*)>0 FROM dependency WHERE prerequisite_id=?"

    .line 360
    move-wide/from16 v25, v5

    .line 362
    const/4 v5, 0x1

    .line 363
    invoke-static {v9, v5}, Llq;->r(Ljava/lang/String;I)Llq;

    .line 366
    move-result-object v6

    .line 367
    if-nez v14, :cond_11

    .line 369
    invoke-virtual {v6, v5}, Llq;->t(I)V

    .line 372
    goto :goto_a

    .line 373
    :cond_11
    invoke-virtual {v6, v14, v5}, Llq;->u(Ljava/lang/String;I)V

    .line 376
    :goto_a
    iget-object v5, v7, Lba;->a:Ljq;

    .line 378
    invoke-virtual {v5}, Ljq;->b()V

    .line 381
    invoke-virtual {v5, v6}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 384
    move-result-object v5

    .line 385
    :try_start_0
    invoke-interface {v5}, Landroid/database/Cursor;->moveToFirst()Z

    .line 388
    move-result v7

    .line 389
    if-eqz v7, :cond_12

    .line 391
    const/4 v7, 0x0

    .line 392
    invoke-interface {v5, v7}, Landroid/database/Cursor;->getInt(I)I

    .line 395
    move-result v9
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 396
    if-eqz v9, :cond_13

    .line 398
    const/4 v9, 0x1

    .line 399
    goto :goto_b

    .line 400
    :cond_12
    const/4 v7, 0x0

    .line 401
    :cond_13
    const/4 v9, 0x0

    .line 402
    :goto_b
    invoke-interface {v5}, Landroid/database/Cursor;->close()V

    .line 405
    invoke-virtual {v6}, Llq;->v()V

    .line 408
    if-nez v9, :cond_17

    .line 410
    iget-object v5, v13, LWorkSpec$a;->b:LWorkInfo_State;

    .line 412
    if-ne v5, v10, :cond_14

    .line 414
    const/4 v6, 0x1

    .line 415
    goto :goto_c

    .line 416
    :cond_14
    const/4 v6, 0x0

    .line 417
    :goto_c
    and-int v6, v19, v6

    .line 419
    if-ne v5, v12, :cond_15

    .line 421
    const/16 v17, 0x1

    .line 423
    goto :goto_d

    .line 424
    :cond_15
    if-ne v5, v11, :cond_16

    .line 426
    const/16 v16, 0x1

    .line 428
    :cond_16
    :goto_d
    iget-object v5, v13, LWorkSpec$a;->a:Ljava/lang/String;

    .line 430
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 433
    move/from16 v19, v6

    .line 435
    :cond_17
    move-object/from16 v9, v18

    .line 437
    move-object/from16 v13, v22

    .line 439
    move-object/from16 v14, v23

    .line 441
    move-object/from16 v7, v24

    .line 443
    move-wide/from16 v5, v25

    .line 445
    goto :goto_9

    .line 446
    :catchall_0
    move-exception v0

    .line 447
    invoke-interface {v5}, Landroid/database/Cursor;->close()V

    .line 450
    invoke-virtual {v6}, Llq;->v()V

    .line 453
    throw v0

    .line 454
    :cond_18
    move-wide/from16 v25, v5

    .line 456
    move-object/from16 v24, v7

    .line 458
    move-object/from16 v23, v14

    .line 460
    const/4 v7, 0x0

    .line 461
    if-ne v4, v15, :cond_1b

    .line 463
    if-nez v16, :cond_19

    .line 465
    if-eqz v17, :cond_1b

    .line 467
    :cond_19
    invoke-virtual {v8}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 470
    move-result-object v3

    .line 471
    check-cast v3, LWorkSpecDao;

    .line 473
    invoke-virtual {v3, v2}, LWorkSpecDao;->i(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 476
    move-result-object v4

    .line 477
    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 480
    move-result-object v4

    .line 481
    :goto_e
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 484
    move-result v5

    .line 485
    if-eqz v5, :cond_1a

    .line 487
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 490
    move-result-object v5

    .line 491
    check-cast v5, LWorkSpec$a;

    .line 493
    iget-object v5, v5, LWorkSpec$a;->a:Ljava/lang/String;

    .line 495
    invoke-virtual {v3, v5}, LWorkSpecDao;->a(Ljava/lang/String;)V

    .line 498
    goto :goto_e

    .line 499
    :cond_1a
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 502
    move-result-object v3

    .line 503
    const/16 v16, 0x0

    .line 505
    const/16 v17, 0x0

    .line 507
    :cond_1b
    invoke-interface {v3, v1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 510
    move-result-object v1

    .line 511
    check-cast v1, [Ljava/lang/String;

    .line 513
    array-length v3, v1

    .line 514
    move/from16 v15, v19

    .line 516
    if-lez v3, :cond_1c

    .line 518
    const/4 v9, 0x1

    .line 519
    goto :goto_f

    .line 520
    :cond_1c
    const/4 v9, 0x0

    .line 521
    goto :goto_f

    .line 522
    :cond_1d
    move/from16 v21, v3

    .line 524
    move/from16 v20, v4

    .line 526
    move-wide/from16 v25, v5

    .line 528
    move-object/from16 v24, v7

    .line 530
    move/from16 v18, v9

    .line 532
    move-object/from16 v23, v14

    .line 534
    move/from16 v19, v15

    .line 536
    const/4 v7, 0x0

    .line 537
    move/from16 v9, v18

    .line 539
    move/from16 v15, v19

    .line 541
    :goto_f
    const/4 v3, 0x0

    .line 542
    :goto_10
    iget-object v4, v0, LWorkContinuationImpl;->f:Ljava/util/List;

    .line 544
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 547
    move-result-object v4

    .line 548
    :goto_11
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 551
    move-result v5

    .line 552
    if-eqz v5, :cond_2b

    .line 554
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 557
    move-result-object v5

    .line 558
    check-cast v5, Lx00;

    .line 560
    iget-object v6, v5, Lx00;->b:LWorkSpec;

    .line 562
    if-eqz v9, :cond_20

    .line 564
    if-nez v15, :cond_20

    .line 566
    if-eqz v17, :cond_1e

    .line 568
    iput-object v12, v6, LWorkSpec;->b:LWorkInfo_State;

    .line 570
    goto :goto_12

    .line 571
    :cond_1e
    if-eqz v16, :cond_1f

    .line 573
    iput-object v11, v6, LWorkSpec;->b:LWorkInfo_State;

    .line 575
    goto :goto_12

    .line 576
    :cond_1f
    sget-object v10, LWorkInfo_State;->g:LWorkInfo_State;

    .line 578
    iput-object v10, v6, LWorkSpec;->b:LWorkInfo_State;

    .line 580
    :goto_12
    move-object v10, v8

    .line 581
    move-wide/from16 v13, v25

    .line 583
    goto :goto_13

    .line 584
    :cond_20
    invoke-virtual {v6}, LWorkSpec;->c()Z

    .line 587
    move-result v10

    .line 588
    if-nez v10, :cond_21

    .line 590
    move-wide/from16 v13, v25

    .line 592
    iput-wide v13, v6, LWorkSpec;->n:J

    .line 594
    move-object v10, v8

    .line 595
    goto :goto_13

    .line 596
    :cond_21
    move-object v10, v8

    .line 597
    move-wide/from16 v13, v25

    .line 599
    const-wide/16 v7, 0x0

    .line 601
    iput-wide v7, v6, LWorkSpec;->n:J

    .line 603
    :goto_13
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 605
    const/16 v8, 0x17

    .line 607
    if-lt v7, v8, :cond_22

    .line 609
    const/16 v8, 0x19

    .line 611
    if-gt v7, v8, :cond_22

    .line 613
    invoke-static {v6}, LEnqueueRunnable;->b(LWorkSpec;)V

    .line 616
    goto :goto_18

    .line 617
    :cond_22
    const/16 v8, 0x16

    .line 619
    if-gt v7, v8, :cond_25

    .line 621
    const-string v7, "androidx.work.impl.background.gcm.GcmScheduler"

    .line 623
    :try_start_1
    invoke-static {v7}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 626
    move-result-object v7
    :try_end_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    .line 627
    move/from16 v18, v3

    .line 629
    move-object/from16 v8, v24

    .line 631
    :try_start_2
    iget-object v3, v8, LWorkManagerImpl;->g:Ljava/util/List;

    .line 633
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 636
    move-result-object v3

    .line 637
    :goto_14
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 640
    move-result v19

    .line 641
    if-eqz v19, :cond_24

    .line 643
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 646
    move-result-object v19

    .line 647
    check-cast v19, Lhr;

    .line 649
    move-object/from16 v22, v3

    .line 651
    invoke-virtual/range {v19 .. v19}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 654
    move-result-object v3

    .line 655
    invoke-virtual {v7, v3}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 658
    move-result v3
    :try_end_2
    .catch Ljava/lang/ClassNotFoundException; {:try_start_2 .. :try_end_2} :catch_0

    .line 659
    if-eqz v3, :cond_23

    .line 661
    const/4 v3, 0x1

    .line 662
    goto :goto_17

    .line 663
    :cond_23
    move-object/from16 v3, v22

    .line 665
    goto :goto_14

    .line 666
    :catch_0
    :goto_15
    nop

    .line 667
    goto :goto_16

    .line 668
    :catch_1
    move/from16 v18, v3

    .line 670
    move-object/from16 v8, v24

    .line 672
    goto :goto_15

    .line 673
    :cond_24
    :goto_16
    const/4 v3, 0x0

    .line 674
    :goto_17
    if-eqz v3, :cond_26

    .line 676
    invoke-static {v6}, LEnqueueRunnable;->b(LWorkSpec;)V

    .line 679
    goto :goto_19

    .line 680
    :cond_25
    :goto_18
    move/from16 v18, v3

    .line 682
    move-object/from16 v8, v24

    .line 684
    :cond_26
    :goto_19
    iget-object v3, v6, LWorkSpec;->b:LWorkInfo_State;

    .line 686
    move-object/from16 v7, v23

    .line 688
    if-ne v3, v7, :cond_27

    .line 690
    const/4 v3, 0x1

    .line 691
    goto :goto_1a

    .line 692
    :cond_27
    move/from16 v3, v18

    .line 694
    :goto_1a
    invoke-virtual {v10}, Landroidx/work/impl/WorkDatabase;->n()Lz00;

    .line 697
    move-result-object v18

    .line 698
    move/from16 v19, v3

    .line 700
    move-object/from16 v3, v18

    .line 702
    check-cast v3, LWorkSpecDao;

    .line 704
    move-object/from16 v22, v4

    .line 706
    iget-object v4, v3, LWorkSpecDao;->a:Ljq;

    .line 708
    invoke-virtual {v4}, Ljq;->b()V

    .line 711
    invoke-virtual {v4}, Ljq;->c()V

    .line 714
    :try_start_3
    iget-object v3, v3, LWorkSpecDao;->b:LWorkSpecDao$a;

    .line 716
    invoke-virtual {v3, v6}, Lec;->e(Ljava/lang/Object;)V

    .line 719
    invoke-virtual {v4}, Ljq;->h()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_4

    .line 722
    invoke-virtual {v4}, Ljq;->f()V

    .line 725
    iget-object v3, v5, Lx00;->a:Ljava/util/UUID;

    .line 727
    if-eqz v9, :cond_28

    .line 729
    array-length v4, v1

    .line 730
    const/4 v6, 0x0

    .line 731
    :goto_1b
    if-ge v6, v4, :cond_28

    .line 733
    move/from16 v18, v4

    .line 735
    aget-object v4, v1, v6

    .line 737
    move-object/from16 v23, v1

    .line 739
    new-instance v1, Ly9;

    .line 741
    move-object/from16 v24, v7

    .line 743
    invoke-virtual {v3}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 746
    move-result-object v7

    .line 747
    invoke-direct {v1, v7, v4}, Ly9;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 750
    invoke-virtual {v10}, Landroidx/work/impl/WorkDatabase;->i()Laa;

    .line 753
    move-result-object v4

    .line 754
    check-cast v4, Lba;

    .line 756
    iget-object v7, v4, Lba;->a:Ljq;

    .line 758
    invoke-virtual {v7}, Ljq;->b()V

    .line 761
    invoke-virtual {v7}, Ljq;->c()V

    .line 764
    :try_start_4
    iget-object v4, v4, Lba;->b:Lba$a;

    .line 766
    invoke-virtual {v4, v1}, Lec;->e(Ljava/lang/Object;)V

    .line 769
    invoke-virtual {v7}, Ljq;->h()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 772
    invoke-virtual {v7}, Ljq;->f()V

    .line 775
    add-int/lit8 v6, v6, 0x1

    .line 777
    move/from16 v4, v18

    .line 779
    move-object/from16 v1, v23

    .line 781
    move-object/from16 v7, v24

    .line 783
    goto :goto_1b

    .line 784
    :catchall_1
    move-exception v0

    .line 785
    invoke-virtual {v7}, Ljq;->f()V

    .line 788
    throw v0

    .line 789
    :cond_28
    move-object/from16 v23, v1

    .line 791
    move-object/from16 v24, v7

    .line 793
    iget-object v1, v5, Lx00;->c:Ljava/util/Set;

    .line 795
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 798
    move-result-object v1

    .line 799
    :goto_1c
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 802
    move-result v4

    .line 803
    if-eqz v4, :cond_29

    .line 805
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 808
    move-result-object v4

    .line 809
    check-cast v4, Ljava/lang/String;

    .line 811
    invoke-virtual {v10}, Landroidx/work/impl/WorkDatabase;->o()Lc10;

    .line 814
    move-result-object v5

    .line 815
    new-instance v6, Lb10;

    .line 817
    invoke-virtual {v3}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 820
    move-result-object v7

    .line 821
    invoke-direct {v6, v4, v7}, Lb10;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 824
    check-cast v5, Ld10;

    .line 826
    iget-object v4, v5, Ld10;->a:Ljq;

    .line 828
    invoke-virtual {v4}, Ljq;->b()V

    .line 831
    invoke-virtual {v4}, Ljq;->c()V

    .line 834
    :try_start_5
    iget-object v5, v5, Ld10;->b:Ld10$a;

    .line 836
    invoke-virtual {v5, v6}, Lec;->e(Ljava/lang/Object;)V

    .line 839
    invoke-virtual {v4}, Ljq;->h()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 842
    invoke-virtual {v4}, Ljq;->f()V

    .line 845
    goto :goto_1c

    .line 846
    :catchall_2
    move-exception v0

    .line 847
    invoke-virtual {v4}, Ljq;->f()V

    .line 850
    throw v0

    .line 851
    :cond_29
    if-eqz v21, :cond_2a

    .line 853
    invoke-virtual {v10}, Landroidx/work/impl/WorkDatabase;->l()Lr00;

    .line 856
    move-result-object v1

    .line 857
    new-instance v4, Lq00;

    .line 859
    invoke-virtual {v3}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 862
    move-result-object v3

    .line 863
    invoke-direct {v4, v2, v3}, Lq00;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 866
    check-cast v1, Ls00;

    .line 868
    iget-object v3, v1, Ls00;->a:Ljq;

    .line 870
    invoke-virtual {v3}, Ljq;->b()V

    .line 873
    invoke-virtual {v3}, Ljq;->c()V

    .line 876
    :try_start_6
    iget-object v1, v1, Ls00;->b:Ls00$a;

    .line 878
    invoke-virtual {v1, v4}, Lec;->e(Ljava/lang/Object;)V

    .line 881
    invoke-virtual {v3}, Ljq;->h()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 884
    invoke-virtual {v3}, Ljq;->f()V

    .line 887
    goto :goto_1d

    .line 888
    :catchall_3
    move-exception v0

    .line 889
    invoke-virtual {v3}, Ljq;->f()V

    .line 892
    throw v0

    .line 893
    :cond_2a
    :goto_1d
    move-wide/from16 v25, v13

    .line 895
    move/from16 v3, v19

    .line 897
    move-object/from16 v4, v22

    .line 899
    move-object/from16 v1, v23

    .line 901
    move-object/from16 v23, v24

    .line 903
    const/4 v7, 0x0

    .line 904
    move-object/from16 v24, v8

    .line 906
    move-object v8, v10

    .line 907
    goto/16 :goto_11

    .line 909
    :catchall_4
    move-exception v0

    .line 910
    invoke-virtual {v4}, Ljq;->f()V

    .line 913
    throw v0

    .line 914
    :cond_2b
    move/from16 v18, v3

    .line 916
    const/4 v1, 0x1

    .line 917
    :goto_1e
    iput-boolean v1, v0, LWorkContinuationImpl;->j:Z

    .line 919
    or-int v0, v20, v3

    .line 921
    return v0
.end method

.method public static b(LWorkSpec;)V
    .locals 4

    .line 1
    iget-object v0, p0, LWorkSpec;->j:Lf8;

    .line 3
    iget-object v1, p0, LWorkSpec;->c:Ljava/lang/String;

    .line 5
    const-class v2, Landroidx/work/impl/workers/ConstraintTrackingWorker;

    .line 7
    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 10
    move-result-object v3

    .line 11
    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 14
    move-result v3

    .line 15
    if-nez v3, :cond_1

    .line 17
    iget-boolean v3, v0, Lf8;->d:Z

    .line 19
    if-nez v3, :cond_0

    .line 21
    iget-boolean v0, v0, Lf8;->e:Z

    .line 23
    if-eqz v0, :cond_1

    .line 25
    :cond_0
    new-instance v0, Landroidx/work/b$a;

    .line 27
    invoke-direct {v0}, Landroidx/work/b$a;-><init>()V

    .line 30
    iget-object v3, p0, LWorkSpec;->e:Landroidx/work/b;

    .line 32
    iget-object v3, v3, Landroidx/work/b;->a:Ljava/util/HashMap;

    .line 34
    invoke-virtual {v0, v3}, Landroidx/work/b$a;->a(Ljava/util/HashMap;)V

    .line 37
    iget-object v0, v0, Landroidx/work/b$a;->a:Ljava/util/HashMap;

    .line 39
    const-string v3, "androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME"

    .line 41
    invoke-virtual {v0, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 47
    move-result-object v1

    .line 48
    iput-object v1, p0, LWorkSpec;->c:Ljava/lang/String;

    .line 50
    new-instance v1, Landroidx/work/b;

    .line 52
    invoke-direct {v1, v0}, Landroidx/work/b;-><init>(Ljava/util/HashMap;)V

    .line 55
    invoke-static {v1}, Landroidx/work/b;->b(Landroidx/work/b;)[B

    .line 58
    iput-object v1, p0, LWorkSpec;->e:Landroidx/work/b;

    .line 60
    :cond_1
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    .line 1
    iget-object v0, p0, LEnqueueRunnable;->d:Lpn;

    .line 3
    iget-object v1, p0, LEnqueueRunnable;->c:LWorkContinuationImpl;

    .line 5
    :try_start_0
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 8
    iget-object v2, v1, LWorkContinuationImpl;->c:LWorkManagerImpl;

    .line 10
    :try_start_1
    new-instance v3, Ljava/util/HashSet;

    .line 12
    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    .line 15
    invoke-static {v1, v3}, LWorkContinuationImpl;->q(LWorkContinuationImpl;Ljava/util/HashSet;)Z

    .line 18
    move-result v3

    .line 19
    const/4 v4, 0x1

    .line 20
    if-nez v3, :cond_1

    .line 22
    iget-object v3, v2, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 24
    invoke-virtual {v3}, Ljq;->c()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 27
    :try_start_2
    invoke-static {v1}, LEnqueueRunnable;->a(LWorkContinuationImpl;)Z

    .line 30
    move-result v1

    .line 31
    invoke-virtual {v3}, Ljq;->h()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 34
    :try_start_3
    invoke-virtual {v3}, Ljq;->f()V

    .line 37
    if-eqz v1, :cond_0

    .line 39
    iget-object v1, v2, LWorkManagerImpl;->c:Landroid/content/Context;

    .line 41
    const-class v3, Landroidx/work/impl/background/systemalarm/RescheduleReceiver;

    .line 43
    invoke-static {v1, v3, v4}, Lqn;->a(Landroid/content/Context;Ljava/lang/Class;Z)V

    .line 46
    iget-object v1, v2, LWorkManagerImpl;->d:Landroidx/work/a;

    .line 48
    iget-object v3, v2, LWorkManagerImpl;->e:Landroidx/work/impl/WorkDatabase;

    .line 50
    iget-object v2, v2, LWorkManagerImpl;->g:Ljava/util/List;

    .line 52
    invoke-static {v1, v3, v2}, LSchedulers;->a(Landroidx/work/a;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V

    .line 55
    :cond_0
    sget-object v1, Lon;->a:Lon$a$c;

    .line 57
    invoke-virtual {v0, v1}, Lpn;->a(Lon$a;)V

    .line 60
    goto :goto_0

    .line 61
    :catchall_0
    move-exception v1

    .line 62
    invoke-virtual {v3}, Ljq;->f()V

    .line 65
    throw v1

    .line 66
    :cond_1
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 68
    const-string v3, "WorkContinuation has cycles (%s)"

    .line 70
    new-array v4, v4, [Ljava/lang/Object;

    .line 72
    const/4 v5, 0x0

    .line 73
    aput-object v1, v4, v5

    .line 75
    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 78
    move-result-object v1

    .line 79
    invoke-direct {v2, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 82
    throw v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 83
    :catchall_1
    move-exception v1

    .line 84
    new-instance v2, Lon$a$a;

    .line 86
    invoke-direct {v2, v1}, Lon$a$a;-><init>(Ljava/lang/Throwable;)V

    .line 89
    invoke-virtual {v0, v2}, Lpn;->a(Lon$a;)V

    .line 92
    :goto_0
    return-void
.end method
