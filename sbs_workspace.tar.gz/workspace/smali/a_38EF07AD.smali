.class public final La_38EF07AD;
# ep-drojxrnsyuxr
.super La_AD33B00A;
# processed-81158
# processed-44700
.source "wfrebnnh.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La_AD33B00A;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_AD33B00A;-><init>()V

    return-void
.end method


# virtual methods
.method public final o(Landroid/content/Intent;I)Ljava/lang/Object;
    .locals 1

    new-instance v0, La_3F93B28C;

    invoke-direct {v0, p1, p2}, La_3F93B28C;-><init>(Landroid/content/Intent;I)V

    return-object v0
.end method
