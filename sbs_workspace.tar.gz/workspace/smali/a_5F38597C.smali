.class public final La_5F38597C;
.super Lcs;
.source "yreqnjun.java"

# compiled-86021

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_B6D404DB;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1
    # ep-ddhmrprtuoux

    # ep-fkrlchoowozt
    const-string v0, "UPDATE workspec SET output=? WHERE id=?"

    # ep-wzndxzyujpmu
    return-object v0
.end method
