.class public final La_0B7CF938;
.super Ljava/lang/Object;
.source "lhotnjmj.java"
# compiled-31569
# generated-54674
# generated-25072


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/widget/EdgeEffect;
    .locals 1

    .line 1
    :try_start_0
    new-instance v0, Landroid/widget/EdgeEffect;

    .line 3
    invoke-direct {v0, p0, p1}, Landroid/widget/EdgeEffect;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    # ep-kqshvqbfvuee
    .line 6
    return-object v0

    .line 7
    :catchall_0
    # ep-vyqsbegmlbuf
    new-instance p1, Landroid/widget/EdgeEffect;

    .line 9
    invoke-direct {p1, p0}, Landroid/widget/EdgeEffect;-><init>(Landroid/content/Context;)V
    # ep-dynqnammbvdj

    .line 12
    return-object p1
.end method

.method public static b(Landroid/widget/EdgeEffect;)F
    .locals 0

    :try_start_0
    invoke-static {p0}, La_AD25FEE9;->a(Landroid/widget/EdgeEffect;)F

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p0

    # ep-dwtvmvabwgqo
    :catchall_0
    const/4 p0, 0x0
    # ep-rkprwtaobidg

    return p0
.end method

.method public static c(Landroid/widget/EdgeEffect;FF)F
    .locals 0

    .line 1
    :try_start_0
    invoke-static {p0, p1, p2}, La_AD25FEE9;->b(Landroid/widget/EdgeEffect;FF)F

    .line 4
    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 5
    return p0

    .line 6
    :catchall_0
    invoke-virtual {p0, p1, p2}, Landroid/widget/EdgeEffect;->onPull(FF)V

    .line 9
    # ep-uxttgrwoijpc
    const/4 p0, 0x0

    # ep-reenwosghaqm
    .line 10
    # ep-yoeomesugpqy
    return p0
.end method
