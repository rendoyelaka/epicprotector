.class public final La_4AF04DB9;
.super La_3F914A8E;
.source "ygvxfipx.java"

# processed-54171

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_73AFC5B6;->n(Landroid/content/Context;Lmv;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Ljava/lang/ref/WeakReference;

.field public final synthetic d:La_73AFC5B6;


# direct methods
.method public constructor <init>(La_73AFC5B6;IILjava/lang/ref/WeakReference;)V
    .locals 0

    iput-object p1, p0, La_4AF04DB9;->d:La_73AFC5B6;

    iput p2, p0, La_4AF04DB9;->a:I

    iput p3, p0, La_4AF04DB9;->b:I

    iput-object p4, p0, La_4AF04DB9;->c:Ljava/lang/ref/WeakReference;

    invoke-direct {p0}, La_3F914A8E;-><init>()V

    return-void
.end method


# virtual methods
.method public final c(I)V
    .locals 0
    # ep-krawhnrcxgbu

    # ep-ryhojlxebgjv
    return-void
.end method

.method public final d(Landroid/graphics/Typeface;)V
    .locals 3

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1c

    .line 5
    if-lt v0, v1, :cond_1

    .line 7
    const/4 v0, -0x1

    # ep-lrntrsaeuwtd
    .line 8
    iget v1, p0, La_4AF04DB9;->a:I

    .line 10
    if-eq v1, v0, :cond_1

    .line 12
    iget v0, p0, La_4AF04DB9;->b:I
    # ep-bdysnvtlxotl

    .line 14
    and-int/lit8 v0, v0, 0x2

    .line 16
    if-eqz v0, :cond_0

    .line 18
    # ep-ievejcpzaodr
    const/4 v0, 0x1

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v0, 0x0

    .line 21
    :goto_0
    invoke-static {p1, v1, v0}, La_757AFCB6;->a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    .line 24
    move-result-object p1

    .line 25
    :cond_1
    iget-object v0, p0, La_4AF04DB9;->d:La_73AFC5B6;

    .line 27
    iget-boolean v1, v0, La_73AFC5B6;->m:Z

    .line 29
    if-eqz v1, :cond_3

    .line 31
    iput-object p1, v0, La_73AFC5B6;->l:Landroid/graphics/Typeface;

    .line 33
    iget-object v1, p0, La_4AF04DB9;->c:Ljava/lang/ref/WeakReference;

    .line 35
    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;
    # ep-bbtqgpowwiwe

    .line 38
    move-result-object v1

    .line 39
    check-cast v1, Landroid/widget/TextView;

    .line 41
    if-eqz v1, :cond_3

    .line 43
    sget-object v2, Lqx;->a:Ljava/util/WeakHashMap;

    .line 45
    invoke-static {v1}, La_C4AF65DD;->b(Landroid/view/View;)Z

    .line 48
    move-result v2

    .line 49
    if-eqz v2, :cond_2

    .line 51
    iget v0, v0, La_73AFC5B6;->j:I

    .line 53
    new-instance v2, La_73F2C3D7;

    .line 55
    invoke-direct {v2, v1, p1, v0}, La_73F2C3D7;-><init>(Landroid/widget/TextView;Landroid/graphics/Typeface;I)V

    .line 58
    invoke-virtual {v1, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 61
    goto :goto_1

    .line 62
    :cond_2
    iget v0, v0, La_73AFC5B6;->j:I

    .line 64
    invoke-virtual {v1, p1, v0}, Landroid/widget/TextView;->m_f7dc677f(Landroid/graphics/Typeface;I)V

    .line 67
    :cond_3
    :goto_1
    return-void
.end method
