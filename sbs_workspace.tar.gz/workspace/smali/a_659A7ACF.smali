.class public final La_659A7ACF;
# ep-pdxgtiuaeroe
.super Ljava/lang/Object;
# optimised-77738
# validated-74561
.source "tuyvnjzd.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Ltr;

.field public final synthetic d:Ljava/util/UUID;

.field public final synthetic e:Lnd;

.field public final synthetic f:Landroid/content/Context;

.field public final synthetic g:La_36F4FCD3;


# direct methods
.method public constructor <init>(La_36F4FCD3;Ltr;Ljava/util/UUID;Lnd;Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, La_659A7ACF;->g:La_36F4FCD3;

    iput-object p2, p0, La_659A7ACF;->c:Ltr;

    iput-object p3, p0, La_659A7ACF;->d:Ljava/util/UUID;

    iput-object p4, p0, La_659A7ACF;->e:Lnd;

    iput-object p5, p0, La_659A7ACF;->f:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    :try_start_0
    iget-object v0, p0, La_659A7ACF;->c:Ltr;

    .line 3
    iget-object v0, v0, Lf;->c:Ljava/lang/Object;

    .line 5
    instance-of v0, v0, La_3E1A2EED;

    .line 7
    if-nez v0, :cond_1

    .line 9
    iget-object v0, p0, La_659A7ACF;->d:Ljava/util/UUID;

    .line 11
    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 14
    move-result-object v0

    .line 15
    iget-object v1, p0, La_659A7ACF;->g:La_36F4FCD3;

    .line 17
    iget-object v1, v1, La_36F4FCD3;->c:La_950A75D2;

    .line 19
    check-cast v1, La_D44F417E;

    .line 21
    invoke-virtual {v1, v0}, La_D44F417E;->f(Ljava/lang/String;)La_B7B9DBF2;

    .line 24
    move-result-object v1

    .line 25
    if-eqz v1, :cond_0

    .line 27
    invoke-virtual {v1}, La_B7B9DBF2;->a()Z

    .line 30
    move-result v1

    .line 31
    if-nez v1, :cond_0

    .line 33
    iget-object v1, p0, La_659A7ACF;->g:La_36F4FCD3;

    .line 35
    iget-object v1, v1, La_36F4FCD3;->b:Lpd;

    .line 37
    iget-object v2, p0, La_659A7ACF;->e:Lnd;

    .line 39
    check-cast v1, Luo;

    .line 41
    invoke-virtual {v1, v0, v2}, Luo;->g(Ljava/lang/String;Lnd;)V

    .line 44
    iget-object v1, p0, La_659A7ACF;->f:Landroid/content/Context;

    .line 46
    iget-object v2, p0, La_659A7ACF;->e:Lnd;

    .line 48
    invoke-static {v1, v0, v2}, Landroidx/work/impl/foreground/a;->b(Landroid/content/Context;Ljava/lang/String;Lnd;)Landroid/content/Intent;

    .line 51
    move-result-object v0

    .line 52
    iget-object v1, p0, La_659A7ACF;->f:Landroid/content/Context;

    .line 54
    invoke-virtual {v1, v0}, Landroid/content/Context;->m_aca8528d(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 57
    goto :goto_0

    .line 58
    :cond_0
    const-string v0, "Calls to setForegroundAsync() must complete before a ListenableWorker signals completion of work by returning an instance of Result."

    .line 60
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 62
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 65
    throw v1

    .line 66
    :cond_1
    :goto_0
    iget-object v0, p0, La_659A7ACF;->c:Ltr;

    .line 68
    const/4 v1, 0x0

    .line 69
    invoke-virtual {v0, v1}, Ltr;->i(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 72
    goto :goto_1

    .line 73
    :catchall_0
    move-exception v0

    .line 74
    iget-object v1, p0, La_659A7ACF;->c:Ltr;

    .line 76
    invoke-virtual {v1, v0}, Ltr;->j(Ljava/lang/Throwable;)Z

    .line 79
    :goto_1
    return-void
.end method
