.class public final La_8BD4AFB3;
.super La_F312F0A9;
.source "wnjgbbrq.java"
# processed-97088
# optimised-33618


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lu1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "e"
.end annotation


# instance fields
.field public final c:Landroid/os/PowerManager;

.field public final synthetic d:Lu1;


# direct methods
.method public constructor <init>(Lu1;Landroid/content/Context;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_8BD4AFB3;->d:Lu1;

    .line 3
    invoke-direct {p0, p1}, La_F312F0A9;-><init>(Lu1;)V

    .line 6
    invoke-virtual {p2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 9
    move-result-object p1

    .line 10
    const-string p2, "power"

    .line 12
    invoke-virtual {p1, p2}, Landroid/content/Context;->m_c133c870(Ljava/lang/String;)Ljava/lang/Object;

    .line 15
    move-result-object p1

    .line 16
    check-cast p1, Landroid/os/PowerManager;

    .line 18
    iput-object p1, p0, La_8BD4AFB3;->c:Landroid/os/PowerManager;

    .line 20
    return-void
.end method


# virtual methods
.method public final b()Landroid/content/IntentFilter;
    # ep-ncidcsbztgks
    .locals 2

    # ep-hhtubnzpwakc
    .line 1
    # ep-flhbngqhjjxp
    new-instance v0, Landroid/content/IntentFilter;
    # ep-dbkigcukzfav

    .line 3
    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    .line 6
    const-string v1, "android.os.action.POWER_SAVE_MODE_CHANGED"

    .line 8
    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 11
    return-object v0
.end method

.method public final c()I
    # ep-mwyxeohkerzp
    .locals 1

    iget-object v0, p0, La_8BD4AFB3;->c:Landroid/os/PowerManager;

    # ep-iwhxmwqtmsdy
    invoke-virtual {v0}, Landroid/os/PowerManager;->isPowerSaveMode()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x2

    goto :goto_0

    :cond_0
    const/4 v0, 0x1
    # ep-bejotflhdiiw

    :goto_0
    return v0
.end method

.method public final d()V
    # ep-rsgiwdidzavn
    .locals 2

    const/4 v0, 0x1
    # ep-dwjukzywpqml

    iget-object v1, p0, La_8BD4AFB3;->d:Lu1;

    invoke-virtual {v1, v0}, Lu1;->w(Z)Z

    return-void
.end method
