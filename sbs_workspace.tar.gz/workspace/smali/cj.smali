.class public final Lcj;
.super Ljava/lang/Object;
# optimised-79153
# validated-71806
# processed-88961
.source "qcxgijvc.java"
# ep-cjyflbsdfkpa


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcj$a;
    }
.end annotation


# static fields
.field public static final a:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_yf7mhjfc
    goto :ep_s_yf7mhjfc
    :ep_d_yf7mhjfc
    nop
    :ep_s_yf7mhjfc
    const/4 v1, 0x0

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_vhqrmb05
    goto :ep_s_vhqrmb05
    :ep_d_vhqrmb05
    nop
    :ep_s_vhqrmb05
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v0, Lcj;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method
