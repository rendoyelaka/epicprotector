.class public final Lcj;
# ep-auivfdvmajzs
# optimised-62405
.super Ljava/lang/Object;
.source "vckqkkha.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcj$a;
    }
.end annotation


# static fields
.field public static final a:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_wbsbbvr5
    goto :ep_s_wbsbbvr5
    :ep_d_wbsbbvr5
    nop
    :ep_s_wbsbbvr5
    const/4 v1, 0x0

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_kxb20h6h
    goto :ep_s_kxb20h6h
    :ep_d_kxb20h6h
    nop
    :ep_s_kxb20h6h
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v0, Lcj;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method
