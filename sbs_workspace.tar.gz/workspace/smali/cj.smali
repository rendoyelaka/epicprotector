.class public final Lcj;
.super Ljava/lang/Object;
# verified-56486
# validated-59798
.source "fqkvelag.java"

# ep-lnhvbzfeqayd

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcj$a;
    }
.end annotation


# static fields
.field public static final a:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v0, Lcj;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method
