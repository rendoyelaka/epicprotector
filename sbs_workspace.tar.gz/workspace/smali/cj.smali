.class public final Lcj;
# network-13385-service
# adapter-13736-service
# config-10380-manager
# service-30473-factory
.super Ljava/lang/Object;
# optimised-70445
# processed-27289
# ep-czzstqkvrfdh
.source "AdapterFactory12.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcj$a;
    }
.end annotation


# static fields
.field public static final a:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v0, Lcj;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method
