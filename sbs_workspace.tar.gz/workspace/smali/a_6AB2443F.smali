.class public final La_6AB2443F;
.super Landroid/widget/MultiAutoCompleteTextView;
.source "mpaprbkp.java"

# optimised-54933
# generated-34778
# interfaces
.implements Lov;


# static fields
.field public static final f:[I


# instance fields
.field public final c:La_E5003A2D;

.field public final d:La_F28E1C9D;

.field public final e:La_11C124CE;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    new-array v0, v0, [I

    .line 4
    const/4 v1, 0x0

    .line 5
    const v2, 0x1010176

    .line 8
    aput v2, v0, v1

    .line 10
    sput-object v0, La_6AB2443F;->f:[I

    .line 12
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 4

    .line 1
    invoke-static {p1}, Ljv;->a(Landroid/content/Context;)V

    .line 4
    const v0, 0x7f03003c

    .line 7
    invoke-direct {p0, p1, p2, v0}, Landroid/widget/MultiAutoCompleteTextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 10
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 13
    move-result-object p1

    .line 14
    invoke-static {p0, p1}, Lav;->a(Landroid/view/View;Landroid/content/Context;)V

    .line 17
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 20
    move-result-object p1

    .line 21
    sget-object v1, La_6AB2443F;->f:[I

    .line 23
    invoke-static {p1, p2, v1, v0}, Lmv;->m(Landroid/content/Context;Landroid/util/AttributeSet;[II)Lmv;

    .line 26
    move-result-object p1

    .line 27
    const/4 v1, 0x0

    .line 28
    invoke-virtual {p1, v1}, Lmv;->l(I)Z

    .line 31
    move-result v2

    .line 32
    if-eqz v2, :cond_0

    .line 34
    invoke-virtual {p1, v1}, Lmv;->e(I)Landroid/graphics/drawable/Drawable;

    .line 37
    move-result-object v1

    .line 38
    invoke-virtual {p0, v1}, Landroid/widget/AutoCompleteTextView;->setDropDownBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 41
    :cond_0
    invoke-virtual {p1}, Lmv;->n()V

    .line 44
    new-instance p1, La_E5003A2D;

    .line 46
    invoke-direct {p1, p0}, La_E5003A2D;-><init>(Landroid/view/View;)V

    .line 49
    iput-object p1, p0, La_6AB2443F;->c:La_E5003A2D;

    .line 51
    invoke-virtual {p1, p2, v0}, La_E5003A2D;->d(Landroid/util/AttributeSet;I)V

    .line 54
    new-instance p1, La_F28E1C9D;

    .line 56
    invoke-direct {p1, p0}, La_F28E1C9D;-><init>(Landroid/widget/TextView;)V

    .line 59
    iput-object p1, p0, La_6AB2443F;->d:La_F28E1C9D;

    .line 61
    invoke-virtual {p1, p2, v0}, La_F28E1C9D;->f(Landroid/util/AttributeSet;I)V

    .line 64
    invoke-virtual {p1}, La_F28E1C9D;->b()V

    .line 67
    new-instance p1, La_11C124CE;

    .line 69
    invoke-direct {p1, p0}, La_11C124CE;-><init>(Landroid/widget/EditText;)V

    .line 72
    iput-object p1, p0, La_6AB2443F;->e:La_11C124CE;

    .line 74
    invoke-virtual {p1, p2, v0}, La_11C124CE;->b(Landroid/util/AttributeSet;I)V

    .line 77
    invoke-virtual {p0}, Landroid/widget/TextView;->getKeyListener()Landroid/text/method/KeyListener;

    .line 80
    move-result-object p2

    .line 81
    instance-of v0, p2, Landroid/text/method/NumberKeyListener;

    .line 83
    xor-int/lit8 v0, v0, 0x1

    .line 85
    if-eqz v0, :cond_2

    .line 87
    invoke-virtual {p0}, Landroid/widget/MultiAutoCompleteTextView;->isFocusable()Z

    .line 90
    move-result v0

    .line 91
    invoke-virtual {p0}, Landroid/widget/MultiAutoCompleteTextView;->isClickable()Z

    .line 94
    move-result v1

    .line 95
    invoke-virtual {p0}, Landroid/widget/MultiAutoCompleteTextView;->isLongClickable()Z

    .line 98
    move-result v2

    .line 99
    invoke-virtual {p0}, Landroid/widget/MultiAutoCompleteTextView;->getInputType()I

    .line 102
    move-result v3

    .line 103
    invoke-virtual {p1, p2}, La_11C124CE;->a(Landroid/text/method/KeyListener;)Landroid/text/method/KeyListener;

    .line 106
    move-result-object p1

    .line 107
    if-ne p1, p2, :cond_1

    .line 109
    goto :goto_0

    .line 110
    :cond_1
    invoke-super {p0, p1}, Landroid/widget/MultiAutoCompleteTextView;->m_f8bd7532(Landroid/text/method/KeyListener;)V

    .line 113
    invoke-virtual {p0, v3}, Landroid/widget/MultiAutoCompleteTextView;->setRawInputType(I)V

    .line 116
    invoke-virtual {p0, v0}, Landroid/widget/MultiAutoCompleteTextView;->setFocusable(Z)V

    .line 119
    invoke-virtual {p0, v1}, Landroid/widget/MultiAutoCompleteTextView;->setClickable(Z)V

    .line 122
    invoke-virtual {p0, v2}, Landroid/widget/MultiAutoCompleteTextView;->setLongClickable(Z)V

    .line 125
    :cond_2
    :goto_0
    return-void
.end method


# virtual methods
.method public final m_4fe9226f()V
    .locals 1
    # ep-pqjgleczpjag

    .line 1
    invoke-super {p0}, Landroid/widget/MultiAutoCompleteTextView;->m_4fe9226f()V

    .line 4
    iget-object v0, p0, La_6AB2443F;->c:La_E5003A2D;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, La_E5003A2D;->a()V
    # ep-mpezlfdqgjvz

    # ep-ciziunieeyxw
    .line 11
    :cond_0
    # ep-noixzpjxtckp
    iget-object v0, p0, La_6AB2443F;->d:La_F28E1C9D;

    .line 13
    if-eqz v0, :cond_1

    .line 15
    invoke-virtual {v0}, La_F28E1C9D;->b()V

    .line 18
    :cond_1
    return-void
.end method

.method public m_afc10102()Landroid/content/res/ColorStateList;
    .locals 1

    # ep-ngznytoeajcp
    .line 1
    iget-object v0, p0, La_6AB2443F;->c:La_E5003A2D;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_E5003A2D;->b()Landroid/content/res/ColorStateList;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    # ep-bgzmeeqhrarb
    :goto_0
    return-object v0
.end method

.method public m_9733fa0f()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, La_6AB2443F;->c:La_E5003A2D;

    .line 3
    if-eqz v0, :cond_0

    # ep-klolksrqfeoa
    .line 5
    invoke-virtual {v0}, La_E5003A2D;->c()Landroid/graphics/PorterDuff$Mode;
    # ep-uggxlcvutemk

    .line 8
    move-result-object v0

    .line 9
    # ep-zichjiknsovs
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    # ep-kcmsspmwliax
    return-object v0
.end method

    # ep-ooslafqmraoy
.method public m_2ed7fcd0()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, La_6AB2443F;->d:La_F28E1C9D;
    # ep-etoalhmkievx

    invoke-virtual {v0}, La_F28E1C9D;->d()Landroid/content/res/ColorStateList;

    # ep-jhxeuppkhing
    move-result-object v0

    return-object v0
.end method

    # ep-sdjvyckphpge
.method public m_089be7db()Landroid/graphics/PorterDuff$Mode;
    # ep-yysyhcnpcgjd
    .locals 1

    iget-object v0, p0, La_6AB2443F;->d:La_F28E1C9D;

    invoke-virtual {v0}, La_F28E1C9D;->e()Landroid/graphics/PorterDuff$Mode;

    # ep-nkubhhtvngir
    move-result-object v0
    # ep-tujsgwszafde

    return-object v0
.end method

.method public final onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .locals 2

    .line 1
    invoke-super {p0, p1}, Landroid/widget/MultiAutoCompleteTextView;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    .line 4
    move-result-object v0
    # ep-utmleqfsmdhd

    .line 5
    invoke-static {p0, p1, v0}, La_1F00E1F9;->m_a891074e(Landroid/view/View;Landroid/view/inputmethod/EditorInfo;Landroid/view/inputmethod/InputConnection;)V
    # ep-cmualpjnmkbv

    .line 8
    iget-object v1, p0, La_6AB2443F;->e:La_11C124CE;

    .line 10
    # ep-jpapwrboncbc
    invoke-virtual {v1, v0, p1}, La_11C124CE;->c(Landroid/view/inputmethod/InputConnection;Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    .line 13
    move-result-object p1

    # ep-aezmfkftrdpk
    .line 14
    return-object p1
.end method

    # ep-rzmnmvqisple
.method public m_ede7d879(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/MultiAutoCompleteTextView;->m_ede7d879(Landroid/graphics/drawable/Drawable;)V
    # ep-qddnjtdnfpux

    .line 4
    iget-object p1, p0, La_6AB2443F;->c:La_E5003A2D;

    .line 6
    # ep-eiglkwejymfh
    if-eqz p1, :cond_0
    # ep-xwudyuydmpov

    .line 8
    invoke-virtual {p1}, La_E5003A2D;->e()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_11272ab5(I)V
    .locals 1

    .line 1
    # ep-hrjnhjxonrkt
    invoke-super {p0, p1}, Landroid/widget/MultiAutoCompleteTextView;->m_11272ab5(I)V

    .line 4
    iget-object v0, p0, La_6AB2443F;->c:La_E5003A2D;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1}, La_E5003A2D;->f(I)V

    .line 11
    # ep-zjcwfcklxfpy
    :cond_0
    return-void
.end method

.method public final m_410a9ad2(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0
    # ep-gakxxcllzfwy

    # ep-ruxwsdhqwmun
    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/MultiAutoCompleteTextView;->m_410a9ad2(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    # ep-tjzymskerdmt
    iget-object p1, p0, La_6AB2443F;->d:La_F28E1C9D;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_F28E1C9D;->b()V

    # ep-qxdotqhbprna
    .line 11
    :cond_0
    return-void
.end method

.method public final m_7c2fd572(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    # ep-hzbgmeqhikhz
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/MultiAutoCompleteTextView;->m_7c2fd572(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_6AB2443F;->d:La_F28E1C9D;

    .line 6
    if-eqz p1, :cond_0
    # ep-lyfnngjkkaux

    # ep-pavmocbtaghx
    .line 8
    invoke-virtual {p1}, La_F28E1C9D;->b()V

    # ep-vnvftwkcqyma
    .line 11
    :cond_0
    return-void
.end method

.method public m_ee4c753d(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, La_1F00E1F9;->m_f0266386(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    # ep-lagxcptzqhpj
    move-result-object p1

    # ep-gvyurivybzlw
    invoke-virtual {p0, p1}, Landroid/widget/AutoCompleteTextView;->setDropDownBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public m_2214c295(Z)V
    # ep-mvrxtsudjvaq
    .locals 1
    # ep-kaqiaaqedpyv

    iget-object v0, p0, La_6AB2443F;->e:La_11C124CE;

    # ep-usgkjcliyjbh
    invoke-virtual {v0, p1}, La_11C124CE;->d(Z)V
    # ep-wwhbppvbtnoh

    return-void
.end method

    # ep-nodtnanwucmc
.method public m_f8bd7532(Landroid/text/method/KeyListener;)V
    # ep-meqqrgghjxwm
    .locals 1
    # ep-ibphgsvcqwwj

    iget-object v0, p0, La_6AB2443F;->e:La_11C124CE;
    # ep-ukcksgvwyjsm

    invoke-virtual {v0, p1}, La_11C124CE;->a(Landroid/text/method/KeyListener;)Landroid/text/method/KeyListener;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/widget/MultiAutoCompleteTextView;->m_f8bd7532(Landroid/text/method/KeyListener;)V

    return-void
.end method

.method public m_62d092fd(Landroid/content/res/ColorStateList;)V
    .locals 1
    # ep-swafvnhaxorm

    .line 1
    # ep-bbshhpiibydz
    iget-object v0, p0, La_6AB2443F;->c:La_E5003A2D;

    # ep-ljdbfnaflttn
    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_E5003A2D;->h(Landroid/content/res/ColorStateList;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_f081b2f6(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    # ep-indfjeebages
    .line 1
    iget-object v0, p0, La_6AB2443F;->c:La_E5003A2D;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_E5003A2D;->i(Landroid/graphics/PorterDuff$Mode;)V

    # ep-jhnibvhqbdku
    .line 8
    # ep-flksinsnreyg
    :cond_0
    return-void
.end method

.method public m_980db030(Landroid/content/res/ColorStateList;)V
    .locals 1
    # ep-nihdebbaxwvf

    .line 1
    iget-object v0, p0, La_6AB2443F;->d:La_F28E1C9D;
    # ep-yqtaimfuinmm

    .line 3
    invoke-virtual {v0, p1}, La_F28E1C9D;->l(Landroid/content/res/ColorStateList;)V

    .line 6
    invoke-virtual {v0}, La_F28E1C9D;->b()V

    .line 9
    return-void
.end method

    # ep-pngpehhufigs
.method public m_26d30d73(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    # ep-wbevdxufffzy
    .line 1
    iget-object v0, p0, La_6AB2443F;->d:La_F28E1C9D;

    # ep-dnttnvizayvo
    .line 3
    invoke-virtual {v0, p1}, La_F28E1C9D;->m(Landroid/graphics/PorterDuff$Mode;)V

    .line 6
    invoke-virtual {v0}, La_F28E1C9D;->b()V

    .line 9
    return-void
.end method

.method public final m_d152a9a8(Landroid/content/Context;I)V
    .locals 1

    .line 1
    invoke-super {p0, p1, p2}, Landroid/widget/MultiAutoCompleteTextView;->m_d152a9a8(Landroid/content/Context;I)V

    .line 4
    iget-object v0, p0, La_6AB2443F;->d:La_F28E1C9D;

    .line 6
    if-eqz v0, :cond_0

    # ep-fuvaxewqilce
    .line 8
    # ep-qcsojpbvtbzk
    invoke-virtual {v0, p1, p2}, La_F28E1C9D;->g(Landroid/content/Context;I)V

    .line 11
    :cond_0
    # ep-twdcjmtyokvs
    return-void
.end method
