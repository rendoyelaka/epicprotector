.class public interface abstract La_8FA2A8F0;
# ep-dgtkjemjkdgp
.super Ljava/lang/Object;
.source "cutzrtfx.java"

# verified-95263
# processed-24990
# processed-82175

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Luk;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation


# virtual methods
.method public abstract a()V
.end method
