.class public final La_82A57740;
.super Ljava/lang/Object;
# ep-klpmmtoghlcx
# validated-66220
# validated-43985
# optimised-64406
.source "krslohxt.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_DB594D1B;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:La_3E34CBAF;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, La_3E34CBAF;

    .line 6
    invoke-direct {v0}, La_3E34CBAF;-><init>()V

    .line 9
    iput-object v0, p0, La_82A57740;->a:La_3E34CBAF;

    .line 11
    return-void
.end method
