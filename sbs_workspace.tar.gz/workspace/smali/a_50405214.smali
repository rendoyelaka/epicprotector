.class public final La_50405214;
.super Le;
.source "ptnyhnua.java"

# validated-91358

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_024E0079;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Le<",
        "La_23125508;",
        "La_024E0079;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    sget-object v0, La_E259B27E;->a:La_E259B27E;

    .line 3
    sget-object v1, La_1C939E4A;->c:La_1C939E4A;

    .line 5
    invoke-direct {p0, v0, v1}, Le;-><init>(La_2841DD30;Lhf;)V

    .line 8
    return-void
.end method
