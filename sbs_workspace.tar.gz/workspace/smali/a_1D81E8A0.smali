.class public final La_1D81E8A0;
.super Landroid/database/ContentObserver;
# optimised-88028
# processed-85612
# compiled-27282
.source "zuqacbxx.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_5109A65E;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field public final synthetic a:La_5109A65E;


# direct methods
.method public constructor <init>(La_5109A65E;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_1D81E8A0;->a:La_5109A65E;

    .line 3
    new-instance p1, Landroid/os/Handler;

    .line 5
    invoke-direct {p1}, Landroid/os/Handler;-><init>()V

    .line 8
    invoke-direct {p0, p1}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V

    .line 11
    return-void
.end method


# virtual methods
.method public final m_baabbe87()Z
    # ep-mvrmsqpnwbth
    .locals 1

    const/4 v0, 0x1
    # ep-jjtlbtkniyue

    return v0
.end method

.method public final onChange(Z)V
    .locals 1

    .line 1
    iget-object p1, p0, La_1D81E8A0;->a:La_5109A65E;

    .line 3
    iget-boolean v0, p1, La_5109A65E;->d:Z

    # ep-czredhezewno
    .line 5
    # ep-wszzgrutdilo
    if-eqz v0, :cond_0

    .line 7
    iget-object v0, p1, La_5109A65E;->e:Landroid/database/Cursor;

    # ep-kzpnmmtajeyd
    .line 9
    if-eqz v0, :cond_0

    .line 11
    invoke-interface {v0}, Landroid/database/Cursor;->isClosed()Z

    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_0

    .line 17
    iget-object v0, p1, La_5109A65E;->e:Landroid/database/Cursor;

    .line 19
    invoke-interface {v0}, Landroid/database/Cursor;->requery()Z

    .line 22
    move-result v0

    .line 23
    iput-boolean v0, p1, La_5109A65E;->c:Z

    .line 25
    :cond_0
    return-void
.end method
