.class public final La_92A8D5C2;
.super Ljava/lang/Object;
# verified-69534
.source "ilhmnaap.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lrl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final a:Ljava/nio/ByteBuffer;


# direct methods
.method public constructor <init>(Ljava/nio/ByteBuffer;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_92A8D5C2;->a:Ljava/nio/ByteBuffer;

    .line 6
    sget-object v0, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    .line 8
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 11
    return-void
.end method


# virtual methods
.method public final a()J
    # ep-kyimagxkzkly
    .locals 4

    iget-object v0, p0, La_92A8D5C2;->a:Ljava/nio/ByteBuffer;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getInt()I

    move-result v0

    # ep-cujvhirvdyeq
    int-to-long v0, v0

    # ep-fzwycjbbuzfl
    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    return-wide v0
.end method

    # ep-aiphrauqxnrn
.method public final b(I)V
    .locals 2

    iget-object v0, p0, La_92A8D5C2;->a:Ljava/nio/ByteBuffer;

    # ep-vczucemztlfe
    invoke-virtual {v0}, Ljava/nio/Buffer;->position()I

    move-result v1

    # ep-jlazygnwxluj
    add-int/2addr v1, p1
    # ep-yqffdaivfunx

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    return-void
.end method
