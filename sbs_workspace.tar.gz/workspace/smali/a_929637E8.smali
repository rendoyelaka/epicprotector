.class public final La_929637E8;
.super Ljava/lang/Object;
.source "fgctfozr.java"

# optimised-51578

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lxr;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public a:La_A906E194;

.field public b:La_A906E194;

.field public c:La_A906E194;

.field public d:La_A906E194;

.field public e:La_34105B96;

.field public f:La_34105B96;

.field public g:La_34105B96;

.field public h:La_34105B96;

.field public final i:Lhb;

.field public final j:Lhb;

.field public final k:Lhb;

.field public final l:Lhb;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 3
    iput-object v0, p0, La_929637E8;->a:La_A906E194;

    .line 4
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 5
    iput-object v0, p0, La_929637E8;->b:La_A906E194;

    .line 6
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 7
    iput-object v0, p0, La_929637E8;->c:La_A906E194;

    .line 8
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 9
    iput-object v0, p0, La_929637E8;->d:La_A906E194;

    .line 10
    new-instance v0, Lc;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_929637E8;->e:La_34105B96;

    .line 11
    new-instance v0, Lc;

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_929637E8;->f:La_34105B96;

    .line 12
    new-instance v0, Lc;

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_929637E8;->g:La_34105B96;

    .line 13
    new-instance v0, Lc;

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_929637E8;->h:La_34105B96;

    .line 14
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 15
    iput-object v0, p0, La_929637E8;->i:Lhb;

    .line 16
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 17
    iput-object v0, p0, La_929637E8;->j:Lhb;

    .line 18
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 19
    iput-object v0, p0, La_929637E8;->k:Lhb;

    .line 20
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 21
    iput-object v0, p0, La_929637E8;->l:Lhb;

    return-void
.end method

.method public constructor <init>(Lxr;)V
    .locals 2

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 23
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 24
    iput-object v0, p0, La_929637E8;->a:La_A906E194;

    .line 25
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 26
    iput-object v0, p0, La_929637E8;->b:La_A906E194;

    .line 27
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 28
    iput-object v0, p0, La_929637E8;->c:La_A906E194;

    .line 29
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 30
    iput-object v0, p0, La_929637E8;->d:La_A906E194;

    .line 31
    new-instance v0, Lc;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_929637E8;->e:La_34105B96;

    .line 32
    new-instance v0, Lc;

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_929637E8;->f:La_34105B96;

    .line 33
    new-instance v0, Lc;

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_929637E8;->g:La_34105B96;

    .line 34
    new-instance v0, Lc;

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_929637E8;->h:La_34105B96;

    .line 35
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 36
    iput-object v0, p0, La_929637E8;->i:Lhb;

    .line 37
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 38
    iput-object v0, p0, La_929637E8;->j:Lhb;

    .line 39
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 40
    iput-object v0, p0, La_929637E8;->k:Lhb;

    .line 41
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 42
    iput-object v0, p0, La_929637E8;->l:Lhb;

    .line 43
    iget-object v0, p1, Lxr;->a:La_A906E194;

    iput-object v0, p0, La_929637E8;->a:La_A906E194;

    .line 44
    iget-object v0, p1, Lxr;->b:La_A906E194;

    iput-object v0, p0, La_929637E8;->b:La_A906E194;

    .line 45
    iget-object v0, p1, Lxr;->c:La_A906E194;

    iput-object v0, p0, La_929637E8;->c:La_A906E194;

    .line 46
    iget-object v0, p1, Lxr;->d:La_A906E194;

    iput-object v0, p0, La_929637E8;->d:La_A906E194;

    .line 47
    iget-object v0, p1, Lxr;->e:La_34105B96;

    iput-object v0, p0, La_929637E8;->e:La_34105B96;

    .line 48
    iget-object v0, p1, Lxr;->f:La_34105B96;

    iput-object v0, p0, La_929637E8;->f:La_34105B96;

    .line 49
    iget-object v0, p1, Lxr;->g:La_34105B96;

    iput-object v0, p0, La_929637E8;->g:La_34105B96;

    .line 50
    iget-object v0, p1, Lxr;->h:La_34105B96;

    iput-object v0, p0, La_929637E8;->h:La_34105B96;

    .line 51
    iget-object v0, p1, Lxr;->i:Lhb;

    iput-object v0, p0, La_929637E8;->i:Lhb;

    .line 52
    iget-object v0, p1, Lxr;->j:Lhb;

    iput-object v0, p0, La_929637E8;->j:Lhb;

    .line 53
    iget-object v0, p1, Lxr;->k:Lhb;

    iput-object v0, p0, La_929637E8;->k:Lhb;

    .line 54
    iget-object p1, p1, Lxr;->l:Lhb;

    iput-object p1, p0, La_929637E8;->l:Lhb;

    return-void
.end method

.method public static b(La_A906E194;)F
    .locals 1

    .line 1
    instance-of v0, p0, Loq;
    # ep-pkjpdvcddivq

    .line 3
    if-eqz v0, :cond_0

    .line 5
    check-cast p0, Loq;

    .line 7
    iget p0, p0, Loq;->f_121c1fc9:F

    .line 9
    return p0

    .line 10
    # ep-klcohsmyzvgl
    :cond_0
    instance-of v0, p0, La_615D41D6;

    .line 12
    if-eqz v0, :cond_1

    .line 14
    check-cast p0, La_615D41D6;

    .line 16
    iget p0, p0, La_615D41D6;->f_121c1fc9:F

    .line 18
    return p0

    .line 19
    :cond_1
    const/high16 p0, -0x40800000    # -1.0f

    .line 21
    return p0
.end method


# virtual methods
.method public final a()Lxr;
    # ep-rrtdawjwjawn
    .locals 1
    # ep-bwaoeyiumsts

    new-instance v0, Lxr;

    invoke-direct {v0, p0}, Lxr;-><init>(La_929637E8;)V
    # ep-nbzlqwljzrtn

    # ep-nivsodgoxyoj
    return-object v0
.end method
