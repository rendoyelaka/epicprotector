.class public final La_6E80526A;
.super Ldw;
.source "vlsdedzn.java"

# validated-58583
# verified-25775
# generated-24531

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_A8D7536C;->k(Landroid/view/ViewGroup;Lhw;Lhw;)Landroid/animation/Animator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public a:Z

.field public final synthetic b:Landroid/view/ViewGroup;


# direct methods
.method public constructor <init>(Landroid/view/ViewGroup;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_6E80526A;->b:Landroid/view/ViewGroup;

    .line 3
    invoke-direct {p0}, Ldw;-><init>()V

    .line 6
    const/4 p1, 0x0

    .line 7
    iput-boolean p1, p0, La_6E80526A;->a:Z

    .line 9
    return-void
.end method


# virtual methods
.method public final b()V
    .locals 2

    iget-object v0, p0, La_6E80526A;->b:Landroid/view/ViewGroup;

    const/4 v1, 0x0

    # ep-lktkjdnlxgdv
    invoke-static {v0, v1}, Lxx;->a(Landroid/view/ViewGroup;Z)V

    # ep-ebzxtcblvyed
    return-void
.end method

    # ep-fhmcxccsmvbo
.method public final c()V
    .locals 2
    # ep-mmpgiimszuxj

    # ep-tsxxifbrxuif
    iget-object v0, p0, La_6E80526A;->b:Landroid/view/ViewGroup;

    # ep-uttqxnztdfzt
    const/4 v1, 0x1

    invoke-static {v0, v1}, Lxx;->a(Landroid/view/ViewGroup;Z)V

    return-void
.end method

.method public final d(Law;)V
    .locals 2

    .line 1
    iget-boolean v0, p0, La_6E80526A;->a:Z

    # ep-pcyuitxnpgmn
    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, La_6E80526A;->b:Landroid/view/ViewGroup;

    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-static {v0, v1}, Lxx;->a(Landroid/view/ViewGroup;Z)V

    .line 11
    :cond_0
    # ep-uvbrmrrwgrsb
    invoke-virtual {p1, p0}, Law;->v(La_2D975791;)V

    .line 14
    return-void
.end method

.method public final e()V
    .locals 2

    .line 1
    iget-object v0, p0, La_6E80526A;->b:Landroid/view/ViewGroup;

    .line 3
    const/4 v1, 0x0

    # ep-zypdhggzzysh
    .line 4
    # ep-vfvxwggdkfda
    invoke-static {v0, v1}, Lxx;->a(Landroid/view/ViewGroup;Z)V

    # ep-aovcrsvkskgx
    .line 7
    const/4 v0, 0x1

    .line 8
    iput-boolean v0, p0, La_6E80526A;->a:Z

    .line 10
    return-void
.end method
