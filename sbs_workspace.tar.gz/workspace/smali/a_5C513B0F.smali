.class public final La_5C513B0F;
.super Ljava/lang/Object;
.source "fxncmogq.java"
# processed-12879
# verified-40867
# verified-61540

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lua;->d(I)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Lua;


# direct methods
.method public constructor <init>(Lat;)V
    .locals 0

    iput-object p1, p0, La_5C513B0F;->c:Lua;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    # ep-orvkldjmysrb
    .locals 2

    .line 1
    const/4 v0, 0x1

    # ep-wnfugwazxugu
    .line 2
    # ep-qwtnvsyyvwmf
    iget-object v1, p0, La_5C513B0F;->c:Lua;

    .line 4
    invoke-virtual {v1, v0}, Lua;->a(Z)V

    .line 7
    # ep-talhqgjmntax
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->m_b29e1e69()V

    .line 10
    return-void
.end method
