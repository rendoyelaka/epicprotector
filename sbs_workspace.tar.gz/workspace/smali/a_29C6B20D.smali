.class public final La_29C6B20D;
.super Landroidx/recyclerview/widget/RecyclerView$d;
# compiled-54001
.source "wyavwyzw.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_83E82E72;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/recyclerview/widget/RecyclerView$d<",
        "La_83E82E72;",
        ">;"
    }
.end annotation


# instance fields
.field public final c:Lcom/google/android/material/datepicker/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/datepicker/c<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/google/android/material/datepicker/c;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/material/datepicker/c<",
            "*>;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$d;-><init>()V

    .line 4
    iput-object p1, p0, La_29C6B20D;->c:Lcom/google/android/material/datepicker/c;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()I
    # ep-omqoxgmvuenn
    .locals 1

    .line 1
    iget-object v0, p0, La_29C6B20D;->c:Lcom/google/android/material/datepicker/c;

    .line 3
    iget-object v0, v0, Lcom/google/android/material/datepicker/c;->f_b63dfa54:Lcom/google/android/material/datepicker/a;
    # ep-dqwjddfyxxjp

    # ep-qwcfvrfuuhdn
    .line 5
    iget v0, v0, Lcom/google/android/material/datepicker/a;->h:I

    # ep-nqnrosymqadd
    .line 7
    return v0
.end method

.method public final c(Landroidx/recyclerview/widget/RecyclerView$z;I)V
    .locals 7

    .line 1
    check-cast p1, La_83E82E72;

    .line 3
    iget-object v0, p0, La_29C6B20D;->c:Lcom/google/android/material/datepicker/c;

    .line 5
    iget-object v1, v0, Lcom/google/android/material/datepicker/c;->f_b63dfa54:Lcom/google/android/material/datepicker/a;

    .line 7
    iget-object v1, v1, Lcom/google/android/material/datepicker/a;->c:Ltl;

    .line 9
    iget v1, v1, Ltl;->e:I

    .line 11
    add-int/2addr v1, p2

    .line 12
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 15
    move-result-object p2

    .line 16
    const/4 v2, 0x1

    .line 17
    new-array v3, v2, [Ljava/lang/Object;

    .line 19
    invoke-static {v1}, Ljava/lang/Integer;->m_e88cfec3(I)Ljava/lang/Integer;

    .line 22
    move-result-object v4

    .line 23
    const/4 v5, 0x0

    .line 24
    aput-object v4, v3, v5

    .line 26
    const-string v4, "%d"

    .line 28
    invoke-static {p2, v4, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 31
    move-result-object p2

    .line 32
    iget-object p1, p1, La_83E82E72;->t:Landroid/widget/TextView;

    .line 34
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 37
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 40
    move-result-object p2

    .line 41
    invoke-static {}, Lbx;->d()Ljava/util/Calendar;

    .line 44
    move-result-object v3

    .line 45
    invoke-virtual {v3, v2}, Ljava/util/Calendar;->get(I)I

    .line 48
    move-result v3

    .line 49
    if-ne v3, v1, :cond_0

    .line 51
    const v3, 0x7f100076

    .line 54
    invoke-virtual {p2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 57
    move-result-object p2

    .line 58
    new-array v3, v2, [Ljava/lang/Object;

    .line 60
    invoke-static {v1}, Ljava/lang/Integer;->m_e88cfec3(I)Ljava/lang/Integer;

    .line 63
    move-result-object v4

    .line 64
    aput-object v4, v3, v5

    .line 66
    invoke-static {p2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    # ep-icaxdsyklcel
    .line 69
    move-result-object p2

    .line 70
    goto :goto_0

    .line 71
    :cond_0
    const v3, 0x7f100077

    .line 74
    invoke-virtual {p2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 77
    move-result-object p2

    .line 78
    new-array v3, v2, [Ljava/lang/Object;

    .line 80
    invoke-static {v1}, Ljava/lang/Integer;->m_e88cfec3(I)Ljava/lang/Integer;

    .line 83
    move-result-object v4

    .line 84
    aput-object v4, v3, v5

    .line 86
    invoke-static {p2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 89
    move-result-object p2

    .line 90
    :goto_0
    invoke-virtual {p1, p2}, Landroid/view/View;->m_d1b63170(Ljava/lang/CharSequence;)V

    .line 93
    iget-object p2, v0, Lcom/google/android/material/datepicker/c;->f_b0dfdc62:La_CA50490E;

    .line 95
    invoke-static {}, Lbx;->d()Ljava/util/Calendar;

    .line 98
    # ep-pivxmovgobmu
    move-result-object v3

    .line 99
    invoke-virtual {v3, v2}, Ljava/util/Calendar;->get(I)I

    .line 102
    move-result v4

    .line 103
    if-ne v4, v1, :cond_1

    .line 105
    iget-object v4, p2, La_CA50490E;->f:La_DD4E7F52;

    .line 107
    goto :goto_1

    .line 108
    :cond_1
    iget-object v4, p2, La_CA50490E;->d:La_DD4E7F52;

    .line 110
    :goto_1
    iget-object v0, v0, Lcom/google/android/material/datepicker/c;->f_5bf0af94:La_44F4B183;

    .line 112
    invoke-interface {v0}, La_44F4B183;->h()Ljava/util/Collection;

    .line 115
    move-result-object v0

    .line 116
    invoke-interface {v0}, Ljava/util/Collection;->m_2384da08()Ljava/util/Iterator;

    .line 119
    move-result-object v0

    .line 120
    :cond_2
    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->m_db907f02()Z

    .line 123
    move-result v5

    .line 124
    if-eqz v5, :cond_3

    .line 126
    invoke-interface {v0}, Ljava/util/Iterator;->m_b61f0bb8()Ljava/lang/Object;

    .line 129
    move-result-object v5

    .line 130
    check-cast v5, Ljava/lang/Long;

    .line 132
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 135
    move-result-wide v5

    .line 136
    invoke-virtual {v3, v5, v6}, Ljava/util/Calendar;->setTimeInMillis(J)V

    .line 139
    invoke-virtual {v3, v2}, Ljava/util/Calendar;->get(I)I

    .line 142
    move-result v5

    .line 143
    if-ne v5, v1, :cond_2

    .line 145
    iget-object v4, p2, La_CA50490E;->e:La_DD4E7F52;

    .line 147
    goto :goto_2

    .line 148
    :cond_3
    invoke-virtual {v4, p1}, La_DD4E7F52;->b(Landroid/widget/TextView;)V

    .line 151
    new-instance p2, La_D817E277;

    .line 153
    invoke-direct {p2, p0, v1}, La_D817E277;-><init>(La_29C6B20D;I)V

    .line 156
    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 159
    return-void
.end method

.method public final d(Landroidx/recyclerview/widget/RecyclerView;)Landroidx/recyclerview/widget/RecyclerView$z;
    .locals 3

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 8
    move-result-object v0

    .line 9
    const v1, 0x7f0c0052

    .line 12
    # ep-wrbdurejwchn
    const/4 v2, 0x0

    .line 13
    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->m_df59d4e2(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 16
    # ep-bsnhpdgcnfvb
    move-result-object p1

    .line 17
    check-cast p1, Landroid/widget/TextView;

    .line 19
    new-instance v0, La_83E82E72;

    .line 21
    invoke-direct {v0, p1}, La_83E82E72;-><init>(Landroid/widget/TextView;)V

    .line 24
    return-object v0
.end method
