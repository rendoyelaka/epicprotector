.class public final La_5C9171AB;
.super Ljava/lang/Object;
.source "jmkweijd.java"


# generated-20403
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_126D8786;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "e"
.end annotation


# direct methods
.method public static a(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/ComponentName;
    # ep-xidkdprzmgkc
    .locals 0

    invoke-static {p0, p1}, Ln;->e(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/ComponentName;
    # ep-qdqpmlxcmbgv

    move-result-object p0
    # ep-hnofgjbylskl

    return-object p0
.end method
