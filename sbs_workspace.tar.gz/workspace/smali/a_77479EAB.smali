.class public final La_77479EAB;
.super Landroid/animation/AnimatorListenerAdapter;
# validated-79654
# compiled-92049
# ep-xepyjtxofcce
.source "hbngcowe.java"


# instance fields
.field public final synthetic a:La_F45CFC0D;


# direct methods
.method public constructor <init>(La_F45CFC0D;)V
    .locals 0

    iput-object p1, p0, La_77479EAB;->a:La_F45CFC0D;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 0

    iget-object p1, p0, La_77479EAB;->a:La_F45CFC0D;

    invoke-interface {p1}, La_F45CFC0D;->a()V

    return-void
.end method

.method public final onAnimationStart(Landroid/animation/Animator;)V
    .locals 0

    iget-object p1, p0, La_77479EAB;->a:La_F45CFC0D;

    invoke-interface {p1}, La_F45CFC0D;->b()V

    return-void
.end method
