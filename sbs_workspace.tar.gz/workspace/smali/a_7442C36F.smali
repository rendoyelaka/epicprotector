.class public final La_7442C36F;
.super Ljava/lang/Object;
.source "kzbzfils.java"

# optimised-64982
# generated-56637
# ep-yxekxubqbocg
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_ED331A67;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Ltr;

.field public final synthetic d:La_ED331A67;


# direct methods
.method public constructor <init>(La_ED331A67;Ltr;)V
    .locals 0

    iput-object p1, p0, La_7442C36F;->d:La_ED331A67;

    iput-object p2, p0, La_7442C36F;->c:Ltr;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, La_7442C36F;->d:La_ED331A67;

    .line 3
    iget-object v0, v0, La_ED331A67;->f:Landroidx/work/ListenableWorker;

    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    new-instance v0, Ltr;

    .line 10
    invoke-direct {v0}, Ltr;-><init>()V

    .line 13
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 15
    const-string v2, "Expedited WorkRequests require a ListenableWorker to provide an implementation for `getForegroundInfoAsync()`"

    .line 17
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 20
    invoke-virtual {v0, v1}, Ltr;->j(Ljava/lang/Throwable;)Z

    .line 23
    iget-object v1, p0, La_7442C36F;->c:Ltr;

    .line 25
    invoke-virtual {v1, v0}, Ltr;->k(Loj;)Z

    .line 28
    return-void
.end method
