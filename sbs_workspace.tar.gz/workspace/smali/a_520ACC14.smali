.class public final La_520ACC14;
.super Ljava/lang/Object;
.source "dqhxfquh.java"
# processed-48552
# optimised-69362
# ep-ohdokyrbnncu

# interfaces
.implements La_46C8EA32;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;Landroid/content/res/XmlResourceParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 1
    :try_start_0
    invoke-virtual {p1}, Landroid/content/Context;->m_201f7e66()Landroid/content/res/Resources;

    .line 4
    move-result-object v0

    .line 5
    new-instance v1, La_94C80C78;

    .line 7
    invoke-direct {v1, p1}, La_94C80C78;-><init>(Landroid/content/Context;)V

    .line 10
    invoke-virtual {v1, v0, p2, p3, p4}, La_94C80C78;->m_5414ecff(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 13
    return-object v1

    .line 14
    :catch_0
    const/4 p1, 0x0

    .line 15
    return-object p1
.end method
