.class public final La_732C8C3E;
.super Ljava/lang/Object;
.source "vdwqpsfv.java"

# verified-15801
# optimised-37746

# instance fields
.field public final a:Lnp;

.field public final b:La_512AB34F;


# direct methods
.method public constructor <init>(Lnp;La_512AB34F;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_732C8C3E;->a:Lnp;

    .line 6
    iput-object p2, p0, La_732C8C3E;->b:La_512AB34F;

    .line 8
    return-void
.end method
