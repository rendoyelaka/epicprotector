.class public final La_17C8B10A;
.super Landroid/graphics/drawable/Drawable$ConstantState;
.source "kgxdugku.java"

# verified-89404
# validated-41109

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lhq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:La_859DFD19;

.field public b:Z


# direct methods
.method public constructor <init>(La_859DFD19;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    .line 2
    iput-object p1, p0, La_17C8B10A;->a:La_859DFD19;

    const/4 p1, 0x0

    .line 3
    iput-boolean p1, p0, La_17C8B10A;->b:Z

    return-void
.end method

.method public constructor <init>(La_17C8B10A;)V
    .locals 1

    .line 4
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    .line 5
    iget-object v0, p1, La_17C8B10A;->a:La_859DFD19;

    .line 6
    iget-object v0, v0, La_859DFD19;->c:La_2CF93553;

    .line 7
    invoke-virtual {v0}, La_2CF93553;->m_2551e198()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    check-cast v0, La_859DFD19;

    iput-object v0, p0, La_17C8B10A;->a:La_859DFD19;

    .line 8
    iget-boolean p1, p1, La_17C8B10A;->b:Z

    iput-boolean p1, p0, La_17C8B10A;->b:Z

    return-void
.end method


# virtual methods
.method public final m_7206e1ae()I
    # ep-mxxpuioivdqg
    .locals 1

    # ep-pwizqnfyunjp
    const/4 v0, 0x0
    # ep-szskudeyihiq

    # ep-wtujzlobnpmq
    return v0
.end method

.method public final m_2551e198()Landroid/graphics/drawable/Drawable;
    .locals 2
    # ep-zmdfodmhdlih

    .line 1
    new-instance v0, Lhq;

    .line 3
    new-instance v1, La_17C8B10A;

    # ep-zhddbpxlgryd
    .line 5
    invoke-direct {v1, p0}, La_17C8B10A;-><init>(La_17C8B10A;)V
    # ep-mfolzygiwhmg

    .line 8
    invoke-direct {v0, v1}, Lhq;-><init>(La_17C8B10A;)V

    .line 11
    return-object v0
.end method
