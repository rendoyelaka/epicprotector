.class public interface abstract La_7EC03883;
.super Ljava/lang/Object;
.source "fwpjemad.java"
