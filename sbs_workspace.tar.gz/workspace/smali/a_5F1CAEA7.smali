.class public final La_5F1CAEA7;
.super La_2C13166E;
# ep-bwfdneyhzhhr
.source "cjsncxeo.java"
# generated-11248
# verified-57977
# verified-95934


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lmw;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final f_d27c7b86:La_62B06315;


# direct methods
.method public constructor <init>(La_62B06315;)V
    .locals 0

    .line 1
    invoke-direct {p0}, La_2C13166E;-><init>()V

    .line 4
    iput-object p1, p0, La_5F1CAEA7;->f_d27c7b86:La_62B06315;

    .line 6
    return-void
.end method
