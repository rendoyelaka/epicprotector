.class public final La_61B1C423;
.super Ljava/lang/Object;
.source "quwetthv.java"
# ep-pncijmrcxtgh
# validated-57072


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_050815E6;
    }
.end annotation


# static fields
.field public static final c:La_61B1C423;


# instance fields
.field public final a:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "La_050815E6;",
            ">;"
        }
    .end annotation
.end field

.field public final b:La_07EFADCD;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 6
    new-instance v1, La_61B1C423;

    .line 8
    new-instance v2, Ljava/util/LinkedHashSet;

    .line 10
    invoke-direct {v2, v0}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    .line 13
    const/4 v0, 0x0

    .line 14
    invoke-direct {v1, v2, v0}, La_61B1C423;-><init>(Ljava/util/Set;La_07EFADCD;)V

    .line 17
    sput-object v1, La_61B1C423;->c:La_61B1C423;

    .line 19
    return-void
.end method

.method public constructor <init>(Ljava/util/Set;La_07EFADCD;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "La_050815E6;",
            ">;",
            "La_07EFADCD;",
            ")V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_61B1C423;->a:Ljava/util/Set;

    .line 6
    iput-object p2, p0, La_61B1C423;->b:La_07EFADCD;

    .line 8
    return-void
.end method

.method public static b(Ljava/security/cert/X509Certificate;)Ljava/lang/String;
    .locals 2

    .line 1
    instance-of v0, p0, Ljava/security/cert/X509Certificate;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    new-instance v0, Ljava/lang/StringBuilder;

    .line 7
    const-string v1, "sha256/"

    .line 9
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 12
    invoke-virtual {p0}, Ljava/security/cert/Certificate;->getPublicKey()Ljava/security/PublicKey;

    .line 15
    move-result-object p0

    .line 16
    invoke-interface {p0}, Ljava/security/Key;->getEncoded()[B

    .line 19
    move-result-object p0

    .line 20
    invoke-static {p0}, La_7D11E5D7;->g([B)La_7D11E5D7;

    .line 23
    move-result-object p0

    .line 24
    const-string v1, "SHA-256"

    .line 26
    :try_start_0
    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    .line 29
    move-result-object v1

    .line 30
    iget-object p0, p0, La_7D11E5D7;->c:[B

    .line 32
    invoke-virtual {v1, p0}, Ljava/security/MessageDigest;->digest([B)[B

    .line 35
    move-result-object p0

    .line 36
    invoke-static {p0}, La_7D11E5D7;->g([B)La_7D11E5D7;

    .line 39
    move-result-object p0
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_0

    .line 40
    invoke-virtual {p0}, La_7D11E5D7;->a()Ljava/lang/String;

    .line 43
    move-result-object p0

    .line 44
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 47
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 50
    move-result-object p0

    .line 51
    return-object p0

    .line 52
    :catch_0
    move-exception p0

    .line 53
    new-instance v0, Ljava/lang/AssertionError;

    .line 55
    invoke-direct {v0, p0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 58
    throw v0

    .line 59
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 61
    const-string v0, "Certificate pinning requires X509 certificates"

    .line 63
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 66
    throw p0
.end method


# virtual methods
.method public final a(Ljava/lang/String;Ljava/util/List;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/security/cert/Certificate;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, La_61B1C423;->a:Ljava/util/Set;

    .line 7
    invoke-interface {v1}, Ljava/util/Set;->m_722a5b0b()Ljava/util/Iterator;

    .line 10
    move-result-object v1

    .line 11
    invoke-interface {v1}, Ljava/util/Iterator;->m_f2527d92()Z

    .line 14
    move-result v2

    .line 15
    const/4 v3, 0x0

    .line 16
    if-nez v2, :cond_6

    .line 18
    invoke-interface {v0}, Ljava/util/List;->m_2bd5aeca()Z

    .line 21
    move-result v1

    .line 22
    if-eqz v1, :cond_0

    .line 24
    return-void

    .line 25
    :cond_0
    iget-object v1, p0, La_61B1C423;->b:La_07EFADCD;

    .line 27
    if-eqz v1, :cond_1

    .line 29
    invoke-virtual {v1, p1, p2}, La_07EFADCD;->e(Ljava/lang/String;Ljava/util/List;)Ljava/util/List;

    .line 32
    move-result-object p2

    .line 33
    :cond_1
    invoke-interface {p2}, Ljava/util/List;->m_79017b7d()I

    .line 36
    move-result v1

    .line 37
    const/4 v2, 0x0

    .line 38
    const/4 v4, 0x0

    .line 39
    :goto_0
    if-ge v4, v1, :cond_3

    .line 41
    invoke-interface {p2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 44
    move-result-object v5

    .line 45
    check-cast v5, Ljava/security/cert/X509Certificate;

    .line 47
    invoke-interface {v0}, Ljava/util/List;->m_79017b7d()I

    .line 50
    move-result v5

    .line 51
    if-gtz v5, :cond_2

    .line 53
    add-int/lit8 v4, v4, 0x1

    .line 55
    goto :goto_0

    .line 56
    :cond_2
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 59
    move-result-object p1

    .line 60
    check-cast p1, La_050815E6;

    .line 62
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 65
    throw v3

    .line 66
    :cond_3
    new-instance v1, Ljava/lang/StringBuilder;

    .line 68
    const-string v3, "Certificate pinning failure!\n  Peer certificate chain:"

    .line 70
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 73
    invoke-interface {p2}, Ljava/util/List;->m_79017b7d()I

    .line 76
    move-result v3

    .line 77
    const/4 v4, 0x0

    .line 78
    :goto_1
    const-string v5, "\n    "

    .line 80
    if-ge v4, v3, :cond_4

    .line 82
    invoke-interface {p2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 85
    move-result-object v6

    .line 86
    check-cast v6, Ljava/security/cert/X509Certificate;

    .line 88
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 91
    invoke-static {v6}, La_61B1C423;->b(Ljava/security/cert/X509Certificate;)Ljava/lang/String;

    .line 94
    move-result-object v5

    .line 95
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    const-string v5, ": "

    .line 100
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 103
    invoke-virtual {v6}, Ljava/security/cert/X509Certificate;->getSubjectDN()Ljava/security/Principal;

    .line 106
    move-result-object v5

    .line 107
    invoke-interface {v5}, Ljava/security/Principal;->getName()Ljava/lang/String;

    .line 110
    move-result-object v5

    .line 111
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 114
    add-int/lit8 v4, v4, 0x1

    .line 116
    goto :goto_1

    .line 117
    :cond_4
    const-string p2, "\n  Pinned certificates for "

    .line 119
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 122
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 125
    const-string p1, ":"

    .line 127
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 130
    invoke-interface {v0}, Ljava/util/List;->m_79017b7d()I

    .line 133
    move-result p1

    .line 134
    :goto_2
    if-ge v2, p1, :cond_5

    .line 136
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 139
    move-result-object p2

    .line 140
    check-cast p2, La_050815E6;

    .line 142
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 145
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 148
    add-int/lit8 v2, v2, 0x1

    .line 150
    goto :goto_2

    .line 151
    :cond_5
    new-instance p1, Ljavax/net/ssl/SSLPeerUnverifiedException;

    .line 153
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 156
    move-result-object p2

    .line 157
    invoke-direct {p1, p2}, Ljavax/net/ssl/SSLPeerUnverifiedException;-><init>(Ljava/lang/String;)V

    .line 160
    throw p1

    .line 161
    :cond_6
    invoke-interface {v1}, Ljava/util/Iterator;->m_474c1ec6()Ljava/lang/Object;

    .line 164
    move-result-object p1

    .line 165
    check-cast p1, La_050815E6;

    .line 167
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 170
    throw v3
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_0

    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, La_61B1C423;

    .line 7
    if-eqz v1, :cond_1

    .line 9
    check-cast p1, La_61B1C423;

    .line 11
    iget-object v1, p1, La_61B1C423;->b:La_07EFADCD;

    .line 13
    iget-object v2, p0, La_61B1C423;->b:La_07EFADCD;

    .line 15
    invoke-static {v2, v1}, Lex;->f(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    move-result v1

    .line 19
    if-eqz v1, :cond_1

    .line 21
    iget-object v1, p0, La_61B1C423;->a:Ljava/util/Set;

    .line 23
    iget-object p1, p1, La_61B1C423;->a:Ljava/util/Set;

    .line 25
    invoke-interface {v1, p1}, Ljava/util/Set;->equals(Ljava/lang/Object;)Z

    .line 28
    move-result p1

    .line 29
    if-eqz p1, :cond_1

    .line 31
    goto :goto_0

    .line 32
    :cond_1
    const/4 v0, 0x0

    .line 33
    :goto_0
    return v0
.end method

.method public final hashCode()I
    .locals 2

    .line 1
    iget-object v0, p0, La_61B1C423;->b:La_07EFADCD;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 8
    move-result v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    mul-int/lit8 v0, v0, 0x1f

    .line 13
    iget-object v1, p0, La_61B1C423;->a:Ljava/util/Set;

    .line 15
    invoke-interface {v1}, Ljava/util/Set;->hashCode()I

    .line 18
    move-result v1

    .line 19
    add-int/2addr v1, v0

    .line 20
    return v1
.end method
