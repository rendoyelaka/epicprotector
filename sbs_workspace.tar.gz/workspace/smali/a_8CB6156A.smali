.class public final La_8CB6156A;
.super Ljava/lang/Object;
.source "hxfvhchq.java"
# verified-57993
# validated-14076

# ep-nfdaqkaqrgsp

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field public final a:I

.field public final b:La_889D3FD0;

.field public final c:J


# direct methods
.method public constructor <init>(ILa_889D3FD0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, La_8CB6156A;->a:I

    .line 6
    iput-object p2, p0, La_8CB6156A;->b:La_889D3FD0;

    .line 8
    const-wide/32 p1, 0xea60

    .line 11
    iput-wide p1, p0, La_8CB6156A;->c:J

    .line 13
    return-void
.end method
