.class public final La_45E52AC3;
.super Ljava/lang/Object;
# optimised-16681
# optimised-47473
# generated-68678
.source "suqbqybv.java"
# ep-fsrfnxxhlrgl


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "WorkProgressUpdater"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method
