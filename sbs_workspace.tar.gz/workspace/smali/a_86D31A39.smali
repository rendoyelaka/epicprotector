.class public final synthetic La_86D31A39;
.super Ljava/lang/Object;
.source "vozzjjhr.java"

# interfaces
# verified-62907
# processed-49316
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:I

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    iput p1, p0, La_86D31A39;->c:I

    iput-object p2, p0, La_86D31A39;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 14

    .line 1
    iget v0, p0, La_86D31A39;->c:I

    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x0

    .line 5
    iget-object v3, p0, La_86D31A39;->d:Ljava/lang/Object;

    .line 7
    packed-switch v0, :pswitch_data_0

    .line 10
    goto/16 :goto_7

    .line 12
    :pswitch_0
    check-cast v3, Lbo;

    .line 14
    invoke-virtual {v3}, Lbo;->e()V

    .line 17
    return-void

    .line 18
    :pswitch_1
    check-cast v3, La_6319B5AD;

    .line 20
    invoke-virtual {v3}, La_6319B5AD;->d()V

    .line 23
    return-void

    .line 24
    :pswitch_2
    check-cast v3, Landroidx/emoji2/text/g$b;

    .line 26
    invoke-virtual {v3}, Landroidx/emoji2/text/g$b;->c()V

    .line 29
    return-void

    .line 30
    :pswitch_3
    check-cast v3, Landroid/app/Activity;

    .line 32
    sget v0, La_6D39E7CC;->b:I

    .line 34
    invoke-virtual {v3}, Landroid/app/Activity;->isFinishing()Z

    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_a

    .line 40
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 42
    const/16 v4, 0x1c

    .line 44
    const/4 v5, 0x1

    .line 45
    if-lt v0, v4, :cond_0

    .line 47
    sget-object v0, La_101B91DA;->a:Ljava/lang/Class;

    .line 49
    invoke-virtual {v3}, Landroid/app/Activity;->recreate()V

    .line 52
    goto/16 :goto_5

    .line 54
    :cond_0
    sget-object v4, La_101B91DA;->a:Ljava/lang/Class;

    .line 56
    const/16 v4, 0x1b

    .line 58
    const/16 v6, 0x1a

    .line 60
    if-eq v0, v6, :cond_2

    .line 62
    if-ne v0, v4, :cond_1

    .line 64
    goto :goto_0

    .line 65
    :cond_1
    const/4 v7, 0x0

    .line 66
    goto :goto_1

    .line 67
    :cond_2
    :goto_0
    const/4 v7, 0x1

    .line 68
    :goto_1
    sget-object v8, La_101B91DA;->f:Ljava/lang/reflect/Method;

    .line 70
    if-eqz v7, :cond_3

    .line 72
    if-nez v8, :cond_3

    .line 74
    goto/16 :goto_6

    .line 76
    :cond_3
    sget-object v7, La_101B91DA;->e:Ljava/lang/reflect/Method;

    .line 78
    if-nez v7, :cond_4

    .line 80
    sget-object v7, La_101B91DA;->d:Ljava/lang/reflect/Method;

    .line 82
    if-nez v7, :cond_4

    .line 84
    goto/16 :goto_6

    .line 86
    :cond_4
    :try_start_0
    sget-object v7, La_101B91DA;->c:Ljava/lang/reflect/Field;

    .line 88
    invoke-virtual {v7, v3}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 91
    move-result-object v7

    .line 92
    if-nez v7, :cond_5

    .line 94
    goto :goto_6

    .line 95
    :cond_5
    sget-object v9, La_101B91DA;->b:Ljava/lang/reflect/Field;

    .line 97
    invoke-virtual {v9, v3}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 100
    move-result-object v9

    .line 101
    if-nez v9, :cond_6
    # ep-xczpvlcigbmc

    .line 103
    goto :goto_6

    .line 104
    :cond_6
    invoke-virtual {v3}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    .line 107
    move-result-object v10

    .line 108
    new-instance v11, La_5AFBB1DB;

    .line 110
    invoke-direct {v11, v3}, La_5AFBB1DB;-><init>(Landroid/app/Activity;)V

    .line 113
    invoke-virtual {v10, v11}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 116
    sget-object v12, La_101B91DA;->g:Landroid/os/Handler;

    .line 118
    :try_start_1
    new-instance v13, La_CD56B9B4;

    .line 120
    invoke-direct {v13, v11, v7}, La_CD56B9B4;-><init>(La_5AFBB1DB;Ljava/lang/Object;)V

    .line 123
    invoke-virtual {v12, v13}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 126
    if-eq v0, v6, :cond_8

    .line 128
    if-ne v0, v4, :cond_7

    .line 130
    goto :goto_2

    .line 131
    :cond_7
    const/4 v0, 0x0

    .line 132
    goto :goto_3

    .line 133
    :cond_8
    :goto_2
    const/4 v0, 0x1

    .line 134
    :goto_3
    if-eqz v0, :cond_9

    .line 136
    const/16 v0, 0x9

    .line 138
    :try_start_2
    new-array v0, v0, [Ljava/lang/Object;

    .line 140
    aput-object v7, v0, v2
    # ep-ungxntvruiyy

    .line 142
    const/4 v4, 0x0

    .line 143
    aput-object v4, v0, v5

    .line 145
    aput-object v4, v0, v1

    .line 147
    invoke-static {v2}, Ljava/lang/Integer;->m_e88cfec3(I)Ljava/lang/Integer;

    .line 150
    move-result-object v1

    .line 151
    const/4 v6, 0x3

    .line 152
    aput-object v1, v0, v6

    .line 154
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 156
    const/4 v6, 0x4

    .line 157
    aput-object v1, v0, v6

    .line 159
    const/4 v6, 0x5

    .line 160
    aput-object v4, v0, v6

    .line 162
    const/4 v6, 0x6

    .line 163
    aput-object v4, v0, v6

    .line 165
    const/4 v4, 0x7

    .line 166
    aput-object v1, v0, v4

    .line 168
    const/16 v4, 0x8

    .line 170
    aput-object v1, v0, v4

    .line 172
    invoke-virtual {v8, v9, v0}, Ljava/lang/reflect/Method;->m_e9c47b14(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 175
    goto :goto_4

    .line 176
    :cond_9
    invoke-virtual {v3}, Landroid/app/Activity;->recreate()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 179
    :goto_4
    :try_start_3
    new-instance v0, La_A9F9A8BD;

    .line 181
    invoke-direct {v0, v10, v11}, La_A9F9A8BD;-><init>(Landroid/app/Application;La_5AFBB1DB;)V

    .line 184
    invoke-virtual {v12, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 187
    :goto_5
    const/4 v2, 0x1

    .line 188
    goto :goto_6

    .line 189
    :catchall_0
    move-exception v0

    .line 190
    new-instance v1, La_A9F9A8BD;

    .line 192
    invoke-direct {v1, v10, v11}, La_A9F9A8BD;-><init>(Landroid/app/Application;La_5AFBB1DB;)V

    .line 195
    invoke-virtual {v12, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 198
    throw v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 199
    :catchall_1
    nop

    .line 200
    :goto_6
    if-nez v2, :cond_a

    .line 202
    invoke-virtual {v3}, Landroid/app/Activity;->recreate()V

    .line 205
    :cond_a
    return-void

    .line 206
    :pswitch_4
    check-cast v3, Ltv;

    .line 208
    invoke-virtual {v3, v2}, Ltv;->c(Z)V

    .line 211
    return-void

    .line 212
    :pswitch_5
    check-cast v3, Landroidx/appcompat/widget/Toolbar;

    .line 214
    invoke-virtual {v3}, Landroidx/appcompat/widget/Toolbar;->l()V

    .line 217
    return-void

    .line 218
    :pswitch_6
    check-cast v3, Landroidx/activity/ComponentActivity;

    .line 220
    invoke-virtual {v3}, Landroid/app/Activity;->invalidateOptionsMenu()V

    .line 223
    return-void

    .line 224
    :goto_7
    check-cast v3, Lcom/google/android/material/sidesheet/SideSheetBehavior$c;

    .line 226
    iput-boolean v2, v3, Lcom/google/android/material/sidesheet/SideSheetBehavior$c;->b:Z

    .line 228
    iget-object v0, v3, Lcom/google/android/material/sidesheet/SideSheetBehavior$c;->d:Lcom/google/android/material/sidesheet/SideSheetBehavior;

    .line 230
    iget-object v2, v0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->i:Lux;

    .line 232
    if-eqz v2, :cond_b

    .line 234
    invoke-virtual {v2}, Lux;->g()Z

    .line 237
    move-result v2

    .line 238
    if-eqz v2, :cond_b

    .line 240
    iget v0, v3, Lcom/google/android/material/sidesheet/SideSheetBehavior$c;->a:I

    .line 242
    invoke-virtual {v3, v0}, Lcom/google/android/material/sidesheet/SideSheetBehavior$c;->a(I)V

    .line 245
    goto :goto_8

    .line 246
    :cond_b
    iget v2, v0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->h:I

    .line 248
    if-ne v2, v1, :cond_c

    .line 250
    iget v1, v3, Lcom/google/android/material/sidesheet/SideSheetBehavior$c;->a:I

    .line 252
    invoke-virtual {v0, v1}, Lcom/google/android/material/sidesheet/SideSheetBehavior;->s(I)V

    .line 255
    :cond_c
    :goto_8
    return-void

    .line 256
    nop

    .line 257
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
    # ep-miqaztqoqhzt
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
