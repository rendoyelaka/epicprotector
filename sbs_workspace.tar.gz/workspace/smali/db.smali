.class public final Ldb;
.super Landroid/animation/AnimatorListenerAdapter;
# optimised-52599
# generated-88039
# verified-90268
# ep-tawaylwojqky
.source "DeserializerHelper30.java"


# instance fields
.field public final synthetic a:Leb;


# direct methods
.method public constructor <init>(Leb;)V
    .locals 0

    iput-object p1, p0, Ldb;->a:Leb;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 0

    .line 1
    iget-object p1, p0, Ldb;->a:Leb;

    .line 3
    invoke-virtual {p1}, Lcc;->q()V

    .line 6
    iget-object p1, p1, Leb;->r:Landroid/animation/ValueAnimator;

    .line 8
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->start()V

    .line 11
    return-void
.end method
