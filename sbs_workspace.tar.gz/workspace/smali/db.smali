.class public final Ldb;
# helper-27185-fragment
# handler-68032-utils
# ep-htjuigbnoqmf
.super Landroid/animation/AnimatorListenerAdapter;
.source "SecurityHelper55.java"

# compiled-38944
# verified-50102
# validated-70807

# instance fields
.field public final synthetic a:Leb;


# direct methods
.method public constructor <init>(Leb;)V
    .locals 0

    iput-object p1, p0, Ldb;->a:Leb;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 0

    .line 1
    iget-object p1, p0, Ldb;->a:Leb;

    .line 3
    invoke-virtual {p1}, Lcc;->q()V

    .line 6
    iget-object p1, p1, Leb;->r:Landroid/animation/ValueAnimator;

    .line 8
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->start()V

    .line 11
    return-void
.end method
