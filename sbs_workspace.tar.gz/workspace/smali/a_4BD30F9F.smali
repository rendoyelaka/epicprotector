.class public final La_4BD30F9F;
.super Ljava/lang/Object;
.source "gvtzztco.java"

# interfaces
# verified-79392
# validated-94595
.implements Landroid/widget/ListAdapter;
.implements Landroid/widget/SpinnerAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_D1DAB849;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "f"
.end annotation


# instance fields
.field public final c:Landroid/widget/SpinnerAdapter;

.field public final d:Landroid/widget/ListAdapter;


# direct methods
.method public constructor <init>(Landroid/widget/SpinnerAdapter;Landroid/content/res/Resources$Theme;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_4BD30F9F;->c:Landroid/widget/SpinnerAdapter;

    .line 6
    instance-of v0, p1, Landroid/widget/ListAdapter;

    .line 8
    if-eqz v0, :cond_0

    .line 10
    move-object v0, p1

    .line 11
    check-cast v0, Landroid/widget/ListAdapter;

    .line 13
    iput-object v0, p0, La_4BD30F9F;->d:Landroid/widget/ListAdapter;

    .line 15
    :cond_0
    if-eqz p2, :cond_2

    .line 17
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 19
    const/16 v1, 0x17

    .line 21
    if-lt v0, v1, :cond_1

    .line 23
    instance-of v0, p1, Landroid/widget/ThemedSpinnerAdapter;

    .line 25
    if-eqz v0, :cond_1

    .line 27
    check-cast p1, Landroid/widget/ThemedSpinnerAdapter;

    .line 29
    invoke-static {p1, p2}, La_DBCBF047;->a(Landroid/widget/ThemedSpinnerAdapter;Landroid/content/res/Resources$Theme;)V

    .line 32
    goto :goto_0

    .line 33
    :cond_1
    instance-of p2, p1, Lbv;

    .line 35
    if-eqz p2, :cond_2

    .line 37
    check-cast p1, Lbv;

    .line 39
    invoke-interface {p1}, Lbv;->getDropDownViewTheme()Landroid/content/res/Resources$Theme;

    .line 42
    move-result-object p2

    .line 43
    if-nez p2, :cond_2

    .line 45
    invoke-interface {p1}, Lbv;->a()V

    .line 48
    :cond_2
    :goto_0
    return-void
.end method


# virtual methods
.method public final m_4b0afa89()Z
    .locals 1

    .line 1
    iget-object v0, p0, La_4BD30F9F;->d:Landroid/widget/ListAdapter;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-interface {v0}, Landroid/widget/ListAdapter;->m_4b0afa89()Z

    .line 8
    move-result v0

    # ep-vaafwybzeewx
    .line 9
    return v0
    # ep-oowueupjqxom

    .line 10
    # ep-wrwstjdcjsct
    :cond_0
    const/4 v0, 0x1

    .line 11
    return v0
.end method

.method public final getCount()I
    # ep-fckpmswfecqy
    .locals 1
    # ep-pzaezhcnnsar

    iget-object v0, p0, La_4BD30F9F;->c:Landroid/widget/SpinnerAdapter;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    # ep-sxrxoqbrdwho
    :cond_0
    invoke-interface {v0}, Landroid/widget/Adapter;->getCount()I

    move-result v0

    :goto_0
    return v0
.end method

    # ep-yewdvnkigujo
.method public final m_6dd51edd(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, La_4BD30F9F;->c:Landroid/widget/SpinnerAdapter;

    .line 3
    if-nez v0, :cond_0

    .line 5
    const/4 p1, 0x0

    .line 6
    goto :goto_0

    .line 7
    :cond_0
    invoke-interface {v0, p1, p2, p3}, Landroid/widget/SpinnerAdapter;->m_6dd51edd(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    # ep-syiyvbscxmjq
    .line 10
    move-result-object p1

    .line 11
    :goto_0
    return-object p1
.end method

.method public final getItem(I)Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, La_4BD30F9F;->c:Landroid/widget/SpinnerAdapter;

    if-nez v0, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    # ep-hrrcarxwoafq
    invoke-interface {v0, p1}, Landroid/widget/Adapter;->getItem(I)Ljava/lang/Object;
    # ep-ohumkzxakwjd

    # ep-gyboilgfokqs
    move-result-object p1

    :goto_0
    return-object p1
.end method

.method public final getItemId(I)J
    .locals 2

    iget-object v0, p0, La_4BD30F9F;->c:Landroid/widget/SpinnerAdapter;

    # ep-qcvrejszkylj
    if-nez v0, :cond_0
    # ep-gwtcgdpbdnxm

    const-wide/16 v0, -0x1

    goto :goto_0

    :cond_0
    invoke-interface {v0, p1}, Landroid/widget/Adapter;->getItemId(I)J
    # ep-aoybhcbcqupy

    move-result-wide v0

    :goto_0
    # ep-lhrffwxfdtlb
    return-wide v0
.end method

    # ep-iyuovrnikuuq
.method public final getItemViewType(I)I
    # ep-skcejxthvoen
    .locals 0
    # ep-luahnakyblez

    const/4 p1, 0x0
    # ep-qfvlhkytraxj

    return p1
.end method

.method public final getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 0
    # ep-uqyrmlqskgze

    invoke-virtual {p0, p1, p2, p3}, La_4BD30F9F;->m_6dd51edd(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    # ep-fzeupuyblebl
    move-result-object p1

    # ep-rmdswenscqsk
    return-object p1
.end method

    # ep-xidiuaqqrthj
.method public final getViewTypeCount()I
    .locals 1
    # ep-xviicrtziaus

    const/4 v0, 0x1
    # ep-smayfkwxdlcb

    return v0
.end method

.method public final m_36824ba9()Z
    .locals 1

    iget-object v0, p0, La_4BD30F9F;->c:Landroid/widget/SpinnerAdapter;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Landroid/widget/Adapter;->m_36824ba9()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    # ep-xugoxdiaionp
    goto :goto_0

    # ep-rcdjpjkjzhdk
    :cond_0
    const/4 v0, 0x0

    :goto_0
    # ep-rjqaiirqsuep
    return v0
.end method

.method public final m_de5dc0a1()Z
    .locals 1

    invoke-virtual {p0}, La_4BD30F9F;->getCount()I

    # ep-chepcaoigxol
    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    # ep-rkekyyslqccs
    goto :goto_0

    :cond_0
    const/4 v0, 0x0
    # ep-ycilpgnwyacz

    # ep-wwdimelmsubo
    :goto_0
    return v0
.end method

.method public final m_696e3a28(I)Z
    .locals 1

    .line 1
    iget-object v0, p0, La_4BD30F9F;->d:Landroid/widget/ListAdapter;

    .line 3
    if-eqz v0, :cond_0
    # ep-ulfkpthfynwo

    .line 5
    invoke-interface {v0, p1}, Landroid/widget/ListAdapter;->m_696e3a28(I)Z
    # ep-ypqcshrayohw

    .line 8
    move-result p1
    # ep-rfxsxorrwmwz

    .line 9
    return p1

    # ep-amaavazqchva
    .line 10
    :cond_0
    const/4 p1, 0x1

    .line 11
    return p1
.end method

.method public final m_56161378(Landroid/database/DataSetObserver;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_4BD30F9F;->c:Landroid/widget/SpinnerAdapter;

    # ep-njiexoaebhyr
    .line 3
    if-eqz v0, :cond_0

    # ep-fyentnzddyhu
    .line 5
    invoke-interface {v0, p1}, Landroid/widget/Adapter;->m_56161378(Landroid/database/DataSetObserver;)V
    # ep-lrhudsmqfevz

    .line 8
    :cond_0
    return-void
.end method

.method public final m_a3befeaf(Landroid/database/DataSetObserver;)V
    # ep-weezsfyovail
    .locals 1

    .line 1
    # ep-ewehjioaucfx
    iget-object v0, p0, La_4BD30F9F;->c:Landroid/widget/SpinnerAdapter;

    .line 3
    if-eqz v0, :cond_0

    # ep-fmtxmnwstxre
    .line 5
    invoke-interface {v0, p1}, Landroid/widget/Adapter;->m_a3befeaf(Landroid/database/DataSetObserver;)V

    .line 8
    # ep-uddojdlttepw
    :cond_0
    return-void
.end method
