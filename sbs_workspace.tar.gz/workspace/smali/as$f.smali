.class public abstract Las$f;
.super Ljava/lang/Object;
# ep-hqziqazpjzfa
.source "hkjbvgim.java"

# verified-66076
# optimised-73070

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Las;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "f"
.end annotation


# static fields
.field public static final b:Landroid/graphics/Matrix;


# instance fields
.field public final a:Landroid/graphics/Matrix;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Landroid/graphics/Matrix;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_bflbn012
    goto :ep_s_bflbn012
    :ep_d_bflbn012
    nop
    :ep_s_bflbn012
    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_0yvsq3rw
    goto :ep_s_0yvsq3rw
    :ep_d_0yvsq3rw
    nop
    :ep_s_0yvsq3rw
    sput-object v0, Las$f;->b:Landroid/graphics/Matrix;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Landroid/graphics/Matrix;

    .line 6
    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    .line 9
    iput-object v0, p0, Las$f;->a:Landroid/graphics/Matrix;

    .line 11
    return-void
.end method


# virtual methods
.method public abstract a(Landroid/graphics/Matrix;Lvr;ILandroid/graphics/Canvas;)V
.end method
