.class public abstract Las$f;
# ep-dnojnhkdvchq
.super Ljava/lang/Object;
# compiled-20379
# optimised-93393
# verified-71476
.source "orduksqx.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Las;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "f"
.end annotation


# static fields
.field public static final b:Landroid/graphics/Matrix;


# instance fields
.field public final a:Landroid/graphics/Matrix;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Landroid/graphics/Matrix;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_8ada7yd7
    goto :ep_s_8ada7yd7
    :ep_d_8ada7yd7
    nop
    :ep_s_8ada7yd7
    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_fvxd6yay
    goto :ep_s_fvxd6yay
    :ep_d_fvxd6yay
    nop
    :ep_s_fvxd6yay
    sput-object v0, Las$f;->b:Landroid/graphics/Matrix;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Landroid/graphics/Matrix;

    .line 6
    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    .line 9
    iput-object v0, p0, Las$f;->a:Landroid/graphics/Matrix;

    .line 11
    return-void
.end method


# virtual methods
.method public abstract a(Landroid/graphics/Matrix;Lvr;ILandroid/graphics/Canvas;)V
.end method
