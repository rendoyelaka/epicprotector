.class public final La_61548FA8;
.super Ljava/lang/Object;
# verified-89698
# ep-jvwckfdwfujv
.source "imtwysdj.java"

# interfaces
.implements La_A8CFCDB0;


# instance fields
.field public final synthetic a:Z

.field public final synthetic b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;


# direct methods
.method public constructor <init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;Z)V
    .locals 0

    iput-object p1, p0, La_61548FA8;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    iput-boolean p2, p0, La_61548FA8;->a:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
