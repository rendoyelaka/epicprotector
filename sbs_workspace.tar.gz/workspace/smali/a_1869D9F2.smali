.class public final La_1869D9F2;
# ep-qhmrgukevcne
.super La_697115C4;
.source "nghcyqfo.java"
# verified-89881
# compiled-33327


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lx7<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Landroid/content/Context;Lnu;)V
    .locals 0

    .line 1
    invoke-static {p1, p2}, Lxv;->a(Landroid/content/Context;Lnu;)Lxv;

    .line 4
    move-result-object p1

    .line 5
    iget-object p1, p1, Lxv;->b:La_F09681FA;

    .line 7
    invoke-direct {p0, p1}, La_697115C4;-><init>(La_466D4563;)V

    .line 10
    return-void
.end method


# virtual methods
.method public final b(La_F9B89BF9;)Z
    .locals 0

    .line 1
    iget-object p1, p1, La_F9B89BF9;->j:La_2F18FABF;

    .line 3
    iget-boolean p1, p1, La_2F18FABF;->d:Z

    .line 5
    return p1
.end method

.method public final c(Ljava/lang/Object;)Z
    .locals 0

    .line 1
    check-cast p1, Ljava/lang/Boolean;

    .line 3
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 6
    move-result p1

    .line 7
    xor-int/lit8 p1, p1, 0x1

    .line 9
    return p1
.end method
