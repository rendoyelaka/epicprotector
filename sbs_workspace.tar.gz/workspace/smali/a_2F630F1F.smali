.class public interface abstract La_2F630F1F;
.super Ljava/lang/Object;
.source "iywcpjla.java"
# ep-xiwocndpqkjg

# processed-72511

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljj;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a([Z)Lqs;
.end method
