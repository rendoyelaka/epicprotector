.class public final La_4E6FEC47;
# ep-vqozrgoujrea
.super Landroid/content/BroadcastReceiver;
.source "gxzwzlev.java"
# validated-48579


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_CBEDFCDC;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_CBEDFCDC;


# direct methods
.method public constructor <init>(La_CBEDFCDC;)V
    .locals 0

    iput-object p1, p0, La_4E6FEC47;->a:La_CBEDFCDC;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0

    if-eqz p2, :cond_0

    iget-object p1, p0, La_4E6FEC47;->a:La_CBEDFCDC;

    invoke-virtual {p1, p2}, La_CBEDFCDC;->g(Landroid/content/Intent;)V

    :cond_0
    return-void
.end method
