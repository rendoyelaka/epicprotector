.class public interface abstract La_7258AEBF;
.super Ljava/lang/Object;
.source "mjmpzkpa.java"

# verified-72873
# optimised-87479
# compiled-81546

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_6D39E7CC;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation


# virtual methods
.method public abstract onRequestPermissionsResult(I[Ljava/lang/String;[I)V
.end method
