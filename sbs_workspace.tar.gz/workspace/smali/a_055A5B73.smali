.class public final La_055A5B73;
# ep-bgrvmnhlfupu
# processed-17419
# validated-60569
# optimised-77215
.super Ljava/lang/Object;
.source "cvsowekl.java"

# interfaces
.implements La_FED45020;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_7477FB2B;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv8$b<",
        "La_7477FB2B;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
