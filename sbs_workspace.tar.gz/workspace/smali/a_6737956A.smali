.class public final La_6737956A;
.super La_13EE40C9;
.source "ierqcskx.java"
# verified-28488
# optimised-42748
# optimised-54462


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_13EE40C9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_13EE40C9;-><init>()V

    return-void
.end method


# virtual methods
.method public final b(Ldh;)V
    .locals 1
    # ep-cqpbmyjrnoti

    # ep-xwbjvlhrfxeq
    const/4 v0, 0x5
    # ep-zjtezeoqcpbm

    invoke-virtual {p1, v0}, Ldh;->c(I)V
    # ep-mvowsbdevazl

    return-void
.end method
