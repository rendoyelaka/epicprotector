.class public La_161F0E8B;
.super La_C079EF02;
.source "stynawgj.java"
# ep-bypisuhwhhve
# validated-22346
# processed-66924


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_1E86679E;,
        La_FBE6E675;
    }
.end annotation


# static fields
.field public static final synthetic f_a1e82d85:I


# instance fields
.field public z:La_1E86679E;


# direct methods
.method public constructor <init>(La_1E86679E;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, La_C079EF02;-><init>(La_2001E4FC;)V

    .line 4
    iput-object p1, p0, La_161F0E8B;->z:La_1E86679E;

    .line 6
    return-void
.end method


# virtual methods
.method public final m_414d03cc()Landroid/graphics/drawable/Drawable;
    .locals 2

    new-instance v0, La_1E86679E;

    iget-object v1, p0, La_161F0E8B;->z:La_1E86679E;

    invoke-direct {v0, v1}, La_1E86679E;-><init>(La_1E86679E;)V

    iput-object v0, p0, La_161F0E8B;->z:La_1E86679E;

    return-object p0
.end method

.method public final s(FFFF)V
    .locals 2

    .line 1
    iget-object v0, p0, La_161F0E8B;->z:La_1E86679E;

    .line 3
    iget-object v0, v0, La_1E86679E;->v:Landroid/graphics/RectF;

    .line 5
    iget v1, v0, Landroid/graphics/RectF;->left:F

    .line 7
    cmpl-float v1, p1, v1

    .line 9
    if-nez v1, :cond_0

    .line 11
    iget v1, v0, Landroid/graphics/RectF;->top:F

    .line 13
    cmpl-float v1, p2, v1

    .line 15
    if-nez v1, :cond_0

    .line 17
    iget v1, v0, Landroid/graphics/RectF;->right:F

    .line 19
    cmpl-float v1, p3, v1

    .line 21
    if-nez v1, :cond_0

    .line 23
    iget v1, v0, Landroid/graphics/RectF;->bottom:F

    .line 25
    cmpl-float v1, p4, v1

    .line 27
    if-eqz v1, :cond_1

    .line 29
    :cond_0
    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/graphics/RectF;->set(FFFF)V

    .line 32
    invoke-virtual {p0}, La_C079EF02;->m_0a2649d1()V

    .line 35
    :cond_1
    return-void
.end method
