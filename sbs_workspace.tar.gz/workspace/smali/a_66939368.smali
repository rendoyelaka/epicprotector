.class public final La_66939368;
.super La_13373377;
# optimised-18074
# processed-55219
.source "enoihzbe.java"
# ep-ilozogflwxdt


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, La_13373377;-><init>()V

    return-void
.end method

.method public constructor <init>(Lwz;)V
    .locals 0

    .line 2
    invoke-direct {p0, p1}, La_13373377;-><init>(Lwz;)V

    return-void
.end method


# virtual methods
.method public c(ILii;)V
    .locals 1

    .line 1
    invoke-static {p1}, La_6007FC41;->a(I)I

    .line 4
    move-result p1

    .line 5
    invoke-virtual {p2}, Lii;->d()Landroid/graphics/Insets;

    .line 8
    move-result-object p2

    .line 9
    iget-object v0, p0, La_13373377;->c:Landroid/view/WindowInsets$Builder;

    .line 11
    invoke-static {v0, p1, p2}, Lq;->q(Landroid/view/WindowInsets$Builder;ILandroid/graphics/Insets;)V

    .line 14
    return-void
.end method
