.class public final LSavedStateRegistry;
# ep-ccbiexjiqvjj
.super Ljava/lang/Object;
# optimised-95270
# generated-23500
.source "ryzqdtcz.java"


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "RestrictedApi"
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LSavedStateRegistry$a;,
        LSavedStateRegistry$b;
    }
.end annotation


# instance fields
.field public final a:Lwq;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lwq<",
            "Ljava/lang/String;",
            "LSavedStateRegistry$b;",
            ">;"
        }
    .end annotation
.end field

.field public b:Z

.field public c:Landroid/os/Bundle;

.field public d:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Lwq;

    .line 6
    invoke-direct {v0}, Lwq;-><init>()V

    .line 9
    iput-object v0, p0, LSavedStateRegistry;->a:Lwq;

    .line 11
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)Landroid/os/Bundle;
    .locals 3

    .line 1
    iget-boolean v0, p0, LSavedStateRegistry;->d:Z

    .line 3
    if-eqz v0, :cond_4

    .line 5
    iget-object v0, p0, LSavedStateRegistry;->c:Landroid/os/Bundle;

    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_3

    .line 10
    invoke-virtual {v0, p1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 13
    move-result-object v0

    .line 14
    iget-object v2, p0, LSavedStateRegistry;->c:Landroid/os/Bundle;

    .line 16
    if-eqz v2, :cond_0

    .line 18
    invoke-virtual {v2, p1}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 21
    :cond_0
    iget-object p1, p0, LSavedStateRegistry;->c:Landroid/os/Bundle;

    .line 23
    if-eqz p1, :cond_1

    .line 25
    invoke-virtual {p1}, Landroid/os/BaseBundle;->isEmpty()Z

    .line 28
    move-result p1

    .line 29
    if-nez p1, :cond_1

    .line 31
    const/4 p1, 0x1

    .line 32
    goto :goto_0

    .line 33
    :cond_1
    const/4 p1, 0x0

    .line 34
    :goto_0
    if-nez p1, :cond_2

    .line 36
    iput-object v1, p0, LSavedStateRegistry;->c:Landroid/os/Bundle;

    .line 38
    :cond_2
    return-object v0

    .line 39
    :cond_3
    return-object v1

    .line 40
    :cond_4
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 42
    const-string v0, "You can consumeRestoredStateForKey only after super.onCreate of corresponding component"

    .line 44
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 47
    move-result-object v0

    .line 48
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 51
    throw p1
.end method

.method public final b(Ljava/lang/String;LSavedStateRegistry$b;)V
    .locals 1

    .line 1
    const-string v0, "provider"

    .line 3
    invoke-static {v0, p2}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    iget-object v0, p0, LSavedStateRegistry;->a:Lwq;

    .line 8
    invoke-virtual {v0, p1, p2}, Lwq;->b(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    move-result-object p1

    .line 12
    check-cast p1, LSavedStateRegistry$b;

    .line 14
    if-nez p1, :cond_0

    .line 16
    const/4 p1, 0x1

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const/4 p1, 0x0

    .line 19
    :goto_0
    if-eqz p1, :cond_1

    .line 21
    return-void

    .line 22
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 24
    const-string p2, "SavedStateProvider with the given key is already registered"

    .line 26
    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 29
    move-result-object p2

    .line 30
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 33
    throw p1
.end method
