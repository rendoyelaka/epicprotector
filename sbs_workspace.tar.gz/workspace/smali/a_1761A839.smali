.class public final La_1761A839;
.super Ljava/lang/Object;
# optimised-95686
.source "dvxpdctx.java"

# ep-efvlgtyqelsh

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lvu;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Ljava/util/Locale;)I
    .locals 0

    invoke-static {p0}, Landroid/text/TextUtils;->getLayoutDirectionFromLocale(Ljava/util/Locale;)I

    move-result p0

    return p0
.end method
