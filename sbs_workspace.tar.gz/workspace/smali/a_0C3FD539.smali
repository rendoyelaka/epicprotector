.class public final La_0C3FD539;
.super Ldw;
.source "cwxbkkun.java"

# generated-60729
# verified-67877
# verified-79769

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lfw;->y()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Law;


# direct methods
.method public constructor <init>(Law;)V
    .locals 0

    iput-object p1, p0, La_0C3FD539;->a:Law;

    invoke-direct {p0}, Ldw;-><init>()V

    return-void
.end method


# virtual methods
.method public final d(Law;)V
    .locals 1
    # ep-nzliqfhgerui

    .line 1
    iget-object v0, p0, La_0C3FD539;->a:Law;

    .line 3
    invoke-virtual {v0}, Law;->y()V

    # ep-ldhlozjjyxtj
    .line 6
    invoke-virtual {p1, p0}, Law;->v(La_2D975791;)V

    .line 9
    # ep-zzogchajewbh
    return-void
.end method
