.class public Lax$a;
.super Ljava/lang/Object;
.source "wmaalrqr.java"
# verified-93010
# processed-72086
# optimised-80418

# ep-hbrdxreruqgi

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lax;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/text/Spannable;)Z
    .locals 0

    instance-of p1, p1, Lmo;

    return p1
.end method
