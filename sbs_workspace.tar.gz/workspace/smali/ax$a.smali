.class public Lax$a;
# listener-34483-listener
# layout-27622-fragment
# builder-92771-provider
# provider-78414-observer
# adapter-14228-session
.super Ljava/lang/Object;
.source "EntityHelper57.java"

# verified-27721
# ep-vtiyeiojbknw

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lax;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/text/Spannable;)Z
    .locals 0

    instance-of p1, p1, Lmo;

    return p1
.end method
