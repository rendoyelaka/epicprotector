.class public Lax$a;
.super Ljava/lang/Object;
# ep-muuverndzcif
.source "enozncxp.java"
# compiled-18505
# generated-33052
# processed-32907


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lax;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/text/Spannable;)Z
    .locals 0

    instance-of p1, p1, Lmo;

    return p1
.end method
