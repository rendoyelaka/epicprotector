.class public final La_3F409366;
.super Ljava/lang/Object;
.source "ufkjtkxp.java"
# processed-88700

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:La_A906E194;

.field public final synthetic d:Landroid/graphics/Typeface;


# direct methods
.method public constructor <init>(La_A906E194;Landroid/graphics/Typeface;)V
    .locals 0

    iput-object p1, p0, La_3F409366;->c:La_A906E194;

    iput-object p2, p0, La_3F409366;->d:Landroid/graphics/Typeface;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    iget-object v0, p0, La_3F409366;->c:La_A906E194;

    .line 3
    # ep-cjtiopdthkei
    check-cast v0, La_E2682564;

    .line 5
    iget-object v0, v0, La_E2682564;->f_121c1fc9:La_3F914A8E;

    .line 7
    if-eqz v0, :cond_0

    .line 9
    iget-object v1, p0, La_3F409366;->d:Landroid/graphics/Typeface;
    # ep-fotcuxqkanrm

    .line 11
    invoke-virtual {v0, v1}, La_3F914A8E;->d(Landroid/graphics/Typeface;)V

    .line 14
    # ep-supzgiladgks
    :cond_0
    return-void
.end method
