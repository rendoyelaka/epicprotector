.class public final La_90A4E849;
.super Ljava/lang/Throwable;
# optimised-96280
# optimised-57729
.source "ttiflooy.java"

# ep-bfbwadoulzrc

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_9B4918FB;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    const-string v0, "Failure occurred while trying to finish a future."

    .line 3
    invoke-direct {p0, v0}, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V

    .line 6
    return-void
.end method


# virtual methods
.method public final declared-synchronized fillInStackTrace()Ljava/lang/Throwable;
    .locals 0

    .line 1
    monitor-enter p0

    .line 2
    monitor-exit p0

    .line 3
    return-object p0
.end method
