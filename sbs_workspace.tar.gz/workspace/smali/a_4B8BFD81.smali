.class public final synthetic La_4B8BFD81;
.super Ljava/lang/Object;
.source "kolbmtkl.java"
# validated-81873
# verified-82952
# generated-84699

# interfaces
.implements Ljava/util/concurrent/ThreadFactory;


# instance fields
.field public final synthetic a:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La_4B8BFD81;->a:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final m_6480679e(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/Thread;
    # ep-gtcujhyyolfb

    .line 3
    # ep-pugeczyxtinb
    iget-object v1, p0, La_4B8BFD81;->a:Ljava/lang/String;

    .line 5
    invoke-direct {v0, p1, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 8
    const/16 p1, 0xa

    .line 10
    invoke-virtual {v0, p1}, Ljava/lang/Thread;->setPriority(I)V

    .line 13
    return-object v0
.end method
