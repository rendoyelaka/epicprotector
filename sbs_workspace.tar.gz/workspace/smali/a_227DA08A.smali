.class public final La_227DA08A;
.super La_2CF93553;
# verified-43540
.source "ykxrrhxn.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_AE44E5A4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final v:Landroid/graphics/RectF;


# direct methods
.method public constructor <init>(La_227DA08A;)V
    .locals 0

    .line 3
    invoke-direct {p0, p1}, La_2CF93553;-><init>(La_2CF93553;)V

    .line 4
    iget-object p1, p1, La_227DA08A;->v:Landroid/graphics/RectF;

    iput-object p1, p0, La_227DA08A;->v:Landroid/graphics/RectF;

    return-void
.end method

.method public constructor <init>(Lxr;Landroid/graphics/RectF;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, La_2CF93553;-><init>(Lxr;)V

    .line 2
    iput-object p2, p0, La_227DA08A;->v:Landroid/graphics/RectF;

    return-void
.end method


# virtual methods
.method public final m_2551e198()Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    new-instance v0, La_51943802;
    # ep-wqjziuvlzygv

    .line 3
    # ep-xjphevrfvxun
    invoke-direct {v0, p0}, La_51943802;-><init>(La_227DA08A;)V

    .line 6
    invoke-virtual {v0}, La_859DFD19;->m_b29e1e69()V

    .line 9
    return-object v0
.end method
