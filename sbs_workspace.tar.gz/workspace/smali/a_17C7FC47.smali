.class public abstract La_17C7FC47;
.super Ljava/lang/Object;
.source "vtccyfuh.java"


# generated-25568
# generated-87418
# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_D26A157B;,
        La_1740DE15;
    }
.end annotation


# instance fields
.field public final a:Ljava/util/LinkedHashMap;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/LinkedHashMap;

    .line 6
    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    .line 9
    iput-object v0, p0, La_17C7FC47;->a:Ljava/util/LinkedHashMap;

    .line 11
    return-void
.end method
