.class public final La_4996D669;
.super Ljava/lang/Object;
.source "oymvlrfu.java"

# interfaces
# processed-25708
# compiled-73965
# generated-77554
.implements Lrd;


# instance fields
.field public final a:Lnu;

.field public final b:Lpd;

.field public final c:La_3E1154CE;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "WMFgUpdater"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(Landroidx/work/impl/WorkDatabase;Lpd;Lnu;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p2, p0, La_4996D669;->b:Lpd;

    .line 6
    iput-object p3, p0, La_4996D669;->a:Lnu;

    .line 8
    invoke-virtual {p1}, Landroidx/work/impl/WorkDatabase;->n()La_3E1154CE;

    .line 11
    move-result-object p1

    .line 12
    iput-object p1, p0, La_4996D669;->c:La_3E1154CE;

    .line 14
    return-void
.end method
