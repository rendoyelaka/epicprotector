.class public abstract Ld;
.super Ljava/lang/Object;
.source "SourceFile"
# ep-qgycpuvgusaf
# verified-66143
# processed-55734
# optimised-19799

# interfaces
.implements Lv8$a;


# instance fields
.field private final key:Lv8$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lv8$b<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lv8$b;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lv8$b<",
            "*>;)V"
        }
    .end annotation

    .line 1
    const-string v0, "key"

    .line 3
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    iput-object p1, p0, Ld;->key:Lv8$b;

    .line 11
    return-void
.end method


# virtual methods
.method public fold(Ljava/lang/Object;Llf;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            ">(TR;",
            "Llf<",
            "-TR;-",
            "Lv8$a;",
            "+TR;>;)TR;"
        }
    .end annotation

    .line 1
    const-string v0, "p5boV6St9Ft7"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-static {v0, p2}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    invoke-interface {p2, p1, p0}, Llf;->b(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    move-result-object p1

    .line 10
    return-object p1
.end method

.method public get(Lv8$b;)Lv8$a;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E::",
            "Lv8$a;",
            ">(",
            "Lv8$b<",
            "TE;>;)TE;"
        }
    .end annotation

    invoke-static {p0, p1}, Lv8$a$a;->a(Lv8$a;Lv8$b;)Lv8$a;

    move-result-object p1

    return-object p1
.end method

.method public getKey()Lv8$b;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lv8$b<",
            "*>;"
        }
    .end annotation

    iget-object v0, p0, Ld;->key:Lv8$b;

    return-object v0
.end method

.method public minusKey(Lv8$b;)Lv8;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lv8$b<",
            "*>;)",
            "Lv8;"
        }
    .end annotation

    invoke-static {p0, p1}, Lv8$a$a;->b(Lv8$a;Lv8$b;)Lv8;

    move-result-object p1

    return-object p1
.end method

.method public plus(Lv8;)Lv8;
    .locals 1

    .line 1
    const-string v0, "q4njUaCh6Q=="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    sget-object v0, Lxb;->c:Lxb;

    .line 8
    if-ne p1, v0, :cond_0

    .line 10
    move-object p1, p0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    sget-object v0, Lw8;->c:Lw8;

    .line 14
    invoke-interface {p1, p0, v0}, Lv8;->fold(Ljava/lang/Object;Llf;)Ljava/lang/Object;

    .line 17
    move-result-object p1

    .line 18
    check-cast p1, Lv8;

    .line 20
    :goto_0
    return-object p1
.end method
