.class public final La_63FEB720;
.super Ljava/lang/Object;
# verified-51077
.source "tygtfadf.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_361A72A6;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public a:I

.field public b:I

.field public c:I

.field public d:I

.field public e:I

.field public f:I

.field public g:I

.field public h:Z

.field public i:Z

.field public j:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
