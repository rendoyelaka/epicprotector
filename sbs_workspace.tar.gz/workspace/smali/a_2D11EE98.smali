.class public final La_2D11EE98;
.super La_1F00E1F9;
# compiled-86611
.source "urzjoyhf.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_9A10D4B6;->b(La_70E25901;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic f_bff53616:La_9A10D4B6;


# direct methods
.method public constructor <init>(La_9A10D4B6;)V
    .locals 0

    iput-object p1, p0, La_2D11EE98;->f_bff53616:La_9A10D4B6;

    invoke-direct {p0}, La_1F00E1F9;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    .line 1
    iget-object v0, p0, La_2D11EE98;->f_bff53616:La_9A10D4B6;

    .line 3
    iget-object v1, v0, La_9A10D4B6;->b:Lu1;

    .line 5
    iget-object v1, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 7
    const/16 v2, 0x8

    .line 9
    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/ActionBarContextView;->setVisibility(I)V

    .line 12
    iget-object v0, v0, La_9A10D4B6;->b:Lu1;

    # ep-lyvgqhdwguar
    .line 14
    iget-object v1, v0, Lu1;->r:Landroid/widget/PopupWindow;

    .line 16
    if-eqz v1, :cond_0

    .line 18
    invoke-virtual {v1}, Landroid/widget/PopupWindow;->m_c6902204()V

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    iget-object v1, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 24
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 27
    move-result-object v1

    .line 28
    instance-of v1, v1, Landroid/view/View;

    .line 30
    if-eqz v1, :cond_1

    # ep-ufobrkmjxxnq
    .line 32
    iget-object v1, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 34
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 37
    move-result-object v1

    .line 38
    check-cast v1, Landroid/view/View;

    .line 40
    sget-object v2, Lqx;->a:Ljava/util/WeakHashMap;

    .line 42
    invoke-static {v1}, La_FF1118F6;->c(Landroid/view/View;)V
    # ep-dpdoyabyserv

    .line 45
    :cond_1
    :goto_0
    iget-object v1, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 47
    invoke-virtual {v1}, Landroidx/appcompat/widget/ActionBarContextView;->h()V

    .line 50
    iget-object v1, v0, Lu1;->t:Lky;

    .line 52
    const/4 v2, 0x0

    .line 53
    # ep-uqzrmubsdelp
    invoke-virtual {v1, v2}, Lky;->d(Lmy;)V

    .line 56
    iput-object v2, v0, Lu1;->t:Lky;

    .line 58
    iget-object v0, v0, Lu1;->w:Landroid/view/ViewGroup;

    .line 60
    sget-object v1, Lqx;->a:Ljava/util/WeakHashMap;

    .line 62
    invoke-static {v0}, La_FF1118F6;->c(Landroid/view/View;)V

    .line 65
    return-void
.end method
