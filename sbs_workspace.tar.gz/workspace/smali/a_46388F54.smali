.class public final La_46388F54;
.super Ljava/lang/Object;
# validated-73864
# generated-46616
# optimised-45426
.source "hvbdlxkx.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Landroid/database/Cursor;
    .locals 7

    move-object v6, p6

    # ep-swentlkhkysl
    check-cast v6, Landroid/os/CancellationSignal;

    move-object v0, p0

    # ep-drndezufdttx
    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    # ep-sydffzihbkbq
    move-object v4, p4
    # ep-vaikhsooecdv

    move-object v5, p5

    invoke-virtual/range {v0 .. v6}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object p0

    return-object p0
.end method
