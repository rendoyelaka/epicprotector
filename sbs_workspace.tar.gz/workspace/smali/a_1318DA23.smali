.class public final La_1318DA23;
.super Ljava/lang/Object;
.source "xuoliozq.java"


# generated-29985
# compiled-72969
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_6BC701CA;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/widget/CompoundButton;)Landroid/graphics/drawable/Drawable;
    # ep-jfwruhyvmaop
    .locals 0

    # ep-qvgtkgklkulp
    invoke-static {p0}, La_B8440B58;->g(Landroid/widget/CompoundButton;)Landroid/graphics/drawable/Drawable;

    # ep-chzcefjscdlc
    move-result-object p0
    # ep-uwubbbffseku

    return-object p0
.end method
