.class public final La_29BFF934;
.super La_07EFADCD;
# ep-kdpkkejfwncb
.source "mzvhjney.java"

# compiled-79579
# verified-25975
# optimised-36840

# instance fields
.field public final c:Liw;


# direct methods
.method public constructor <init>(Liw;)V
    .locals 0

    .line 1
    invoke-direct {p0}, La_07EFADCD;-><init>()V

    .line 4
    iput-object p1, p0, La_29BFF934;->c:Liw;

    .line 6
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/String;Ljava/util/List;)Ljava/util/List;
    .locals 9

    .line 1
    new-instance p1, Ljava/util/ArrayDeque;

    .line 3
    invoke-direct {p1, p2}, Ljava/util/ArrayDeque;-><init>(Ljava/util/Collection;)V

    .line 6
    new-instance p2, Ljava/util/ArrayList;

    .line 8
    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    .line 11
    invoke-virtual {p1}, Ljava/util/ArrayDeque;->removeFirst()Ljava/lang/Object;

    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 18
    const/4 v0, 0x0

    .line 19
    const/4 v1, 0x0

    .line 20
    const/4 v2, 0x0

    .line 21
    :goto_0
    const/16 v3, 0x9

    .line 23
    if-ge v1, v3, :cond_9

    .line 25
    invoke-virtual {p2}, Ljava/util/ArrayList;->m_79017b7d()I

    .line 28
    move-result v3

    .line 29
    const/4 v4, 0x1

    .line 30
    sub-int/2addr v3, v4

    .line 31
    invoke-virtual {p2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 34
    move-result-object v3

    .line 35
    check-cast v3, Ljava/security/cert/X509Certificate;

    .line 37
    iget-object v5, p0, La_29BFF934;->c:Liw;

    .line 39
    invoke-virtual {v5, v3}, Liw;->a(Ljava/security/cert/X509Certificate;)Ljava/security/cert/X509Certificate;

    .line 42
    move-result-object v5

    .line 43
    if-eqz v5, :cond_4

    .line 45
    invoke-virtual {p2}, Ljava/util/ArrayList;->m_79017b7d()I

    .line 48
    move-result v2

    .line 49
    if-gt v2, v4, :cond_0

    .line 51
    invoke-virtual {v3, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 54
    move-result v2

    .line 55
    if-nez v2, :cond_1

    .line 57
    :cond_0
    invoke-virtual {p2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 60
    :cond_1
    invoke-virtual {v5}, Ljava/security/cert/X509Certificate;->getIssuerDN()Ljava/security/Principal;

    .line 63
    move-result-object v2

    .line 64
    invoke-virtual {v5}, Ljava/security/cert/X509Certificate;->getSubjectDN()Ljava/security/Principal;

    .line 67
    move-result-object v3

    .line 68
    invoke-interface {v2, v3}, Ljava/security/Principal;->equals(Ljava/lang/Object;)Z

    .line 71
    move-result v2

    .line 72
    if-nez v2, :cond_2

    .line 74
    :catch_0
    const/4 v2, 0x0

    .line 75
    goto :goto_1

    .line 76
    :cond_2
    :try_start_0
    invoke-virtual {v5}, Ljava/security/cert/Certificate;->getPublicKey()Ljava/security/PublicKey;

    .line 79
    move-result-object v2

    .line 80
    invoke-virtual {v5, v2}, Ljava/security/cert/Certificate;->verify(Ljava/security/PublicKey;)V
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 83
    const/4 v2, 0x1

    .line 84
    :goto_1
    if-eqz v2, :cond_3

    .line 86
    return-object p2

    .line 87
    :cond_3
    const/4 v2, 0x1

    .line 88
    goto :goto_3

    .line 89
    :cond_4
    invoke-virtual {p1}, Ljava/util/ArrayDeque;->m_722a5b0b()Ljava/util/Iterator;

    .line 92
    move-result-object v5

    .line 93
    :cond_5
    invoke-interface {v5}, Ljava/util/Iterator;->m_f2527d92()Z

    .line 96
    move-result v6

    .line 97
    if-eqz v6, :cond_7

    .line 99
    invoke-interface {v5}, Ljava/util/Iterator;->m_474c1ec6()Ljava/lang/Object;

    .line 102
    move-result-object v6

    .line 103
    check-cast v6, Ljava/security/cert/X509Certificate;

    .line 105
    invoke-virtual {v3}, Ljava/security/cert/X509Certificate;->getIssuerDN()Ljava/security/Principal;

    .line 108
    move-result-object v7

    .line 109
    invoke-virtual {v6}, Ljava/security/cert/X509Certificate;->getSubjectDN()Ljava/security/Principal;

    .line 112
    move-result-object v8

    .line 113
    invoke-interface {v7, v8}, Ljava/security/Principal;->equals(Ljava/lang/Object;)Z

    .line 116
    move-result v7

    .line 117
    if-nez v7, :cond_6

    .line 119
    :catch_1
    const/4 v7, 0x0

    .line 120
    goto :goto_2

    .line 121
    :cond_6
    :try_start_1
    invoke-virtual {v6}, Ljava/security/cert/Certificate;->getPublicKey()Ljava/security/PublicKey;

    .line 124
    move-result-object v7

    .line 125
    invoke-virtual {v3, v7}, Ljava/security/cert/Certificate;->verify(Ljava/security/PublicKey;)V
    :try_end_1
    .catch Ljava/security/GeneralSecurityException; {:try_start_1 .. :try_end_1} :catch_1

    .line 128
    const/4 v7, 0x1

    .line 129
    :goto_2
    if-eqz v7, :cond_5

    .line 131
    invoke-interface {v5}, Ljava/util/Iterator;->m_8eb9dccd()V

    .line 134
    invoke-virtual {p2, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 137
    :goto_3
    add-int/lit8 v1, v1, 0x1

    .line 139
    goto :goto_0

    .line 140
    :cond_7
    if-eqz v2, :cond_8

    .line 142
    return-object p2

    .line 143
    :cond_8
    new-instance p1, Ljavax/net/ssl/SSLPeerUnverifiedException;

    .line 145
    new-instance p2, Ljava/lang/StringBuilder;

    .line 147
    const-string v0, "Failed to find a trusted cert that signed "

    .line 149
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 152
    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 155
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 158
    move-result-object p2

    .line 159
    invoke-direct {p1, p2}, Ljavax/net/ssl/SSLPeerUnverifiedException;-><init>(Ljava/lang/String;)V

    .line 162
    throw p1

    .line 163
    :cond_9
    new-instance p1, Ljavax/net/ssl/SSLPeerUnverifiedException;

    .line 165
    new-instance v0, Ljava/lang/StringBuilder;

    .line 167
    const-string v1, "Certificate chain too long: "

    .line 169
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 172
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 175
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 178
    move-result-object p2

    .line 179
    invoke-direct {p1, p2}, Ljavax/net/ssl/SSLPeerUnverifiedException;-><init>(Ljava/lang/String;)V

    .line 182
    throw p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_0

    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, La_29BFF934;

    .line 7
    if-eqz v1, :cond_1

    .line 9
    check-cast p1, La_29BFF934;

    .line 11
    iget-object p1, p1, La_29BFF934;->c:Liw;

    .line 13
    iget-object v1, p0, La_29BFF934;->c:Liw;

    .line 15
    invoke-virtual {p1, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 18
    move-result p1

    .line 19
    if-eqz p1, :cond_1

    .line 21
    goto :goto_0

    .line 22
    :cond_1
    const/4 v0, 0x0

    .line 23
    :goto_0
    return v0
.end method

.method public final hashCode()I
    .locals 1

    iget-object v0, p0, La_29BFF934;->c:Liw;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method
