.class public final La_58CCC6C8;
.super Landroid/graphics/drawable/Drawable$ConstantState;
# compiled-55361
# verified-37807
# verified-15489
.source "imhzcsfk.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_0303D629;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field public final a:Landroid/graphics/drawable/Drawable$ConstantState;


# direct methods
.method public constructor <init>(Landroid/graphics/drawable/Drawable$ConstantState;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    .line 4
    iput-object p1, p0, La_58CCC6C8;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    .line 6
    return-void
.end method


# virtual methods
.method public final m_95800478()Z
    # ep-dpgugvmphhor
    .locals 1

    iget-object v0, p0, La_58CCC6C8;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    # ep-sfxuuvfouxlv
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable$ConstantState;->m_95800478()Z
    # ep-jiswmzxbckba

    move-result v0
    # ep-cerphlivxqbz

    return v0
.end method

    # ep-cboliiiojpaz
.method public final m_6dd68863()I
    # ep-fjbzultdsqow
    .locals 1

    iget-object v0, p0, La_58CCC6C8;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    # ep-uifvrnkblplb
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable$ConstantState;->m_6dd68863()I

    move-result v0
    # ep-zbiwnycumfnk

    return v0
.end method

.method public final m_c998b9ac()Landroid/graphics/drawable/Drawable;
    .locals 3

    .line 1
    new-instance v0, La_0303D629;

    invoke-direct {v0}, La_0303D629;-><init>()V
    # ep-myupsllwsqpi

    .line 2
    iget-object v1, p0, La_58CCC6C8;->a:Landroid/graphics/drawable/Drawable$ConstantState;
    # ep-cgeldzajqfyf

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable$ConstantState;->m_c998b9ac()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    iput-object v1, v0, Lfx;->c:Landroid/graphics/drawable/Drawable;
    # ep-lrdegqivjebw

    .line 3
    iget-object v2, v0, La_0303D629;->h:La_396F0F34;

    # ep-uztdssgprimv
    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    return-object v0
.end method

    # ep-okrbcmeclfgs
.method public final m_c998b9ac(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 2
    # ep-exgfhgnkfppo

    .line 4
    new-instance v0, La_0303D629;

    invoke-direct {v0}, La_0303D629;-><init>()V

    .line 5
    iget-object v1, p0, La_58CCC6C8;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable$ConstantState;->m_c998b9ac(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    # ep-pkgjuwrbibtq
    iput-object p1, v0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 6
    iget-object v1, v0, La_0303D629;->h:La_396F0F34;

    # ep-zrilipqgujxw
    invoke-virtual {p1, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    return-object v0
.end method

.method public final m_c998b9ac(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 7
    new-instance v0, La_0303D629;

    invoke-direct {v0}, La_0303D629;-><init>()V

    # ep-zrqbfvgabfem
    .line 8
    iget-object v1, p0, La_58CCC6C8;->a:Landroid/graphics/drawable/Drawable$ConstantState;

    invoke-virtual {v1, p1, p2}, Landroid/graphics/drawable/Drawable$ConstantState;->m_c998b9ac(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    iput-object p1, v0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 9
    iget-object p2, v0, La_0303D629;->h:La_396F0F34;

    invoke-virtual {p1, p2}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V
    # ep-vypucfskdcpy

    return-object v0
.end method
