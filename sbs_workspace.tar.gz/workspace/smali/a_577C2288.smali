.class public final La_577C2288;
.super Ljava/lang/Object;
.source "tilrxcxc.java"


# processed-45941
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "n"
.end annotation


# direct methods
.method public static a(Landroid/view/View;)Ljava/lang/CharSequence;
    .locals 0

    # ep-vwjqrvcktfef
    invoke-static {p0}, Lq;->k(Landroid/view/View;)Ljava/lang/CharSequence;
    # ep-diopqwfibhqf

    move-result-object p0
    # ep-gytrtneaqkvi

    return-object p0
.end method

.method public static b(Landroid/view/View;Ljava/lang/CharSequence;)V
    # ep-iogjspuvrbgo
    .locals 0
    # ep-opqqdbvuldnl

    # ep-qoesjyzuwpsp
    invoke-static {p0, p1}, Lq;->o(Landroid/view/View;Ljava/lang/CharSequence;)V
    # ep-pesxsiiiooyf

    return-void
.end method
