.class public final La_08456DAE;
.super Ljava/lang/Object;
.source "shaythrj.java"
# optimised-24156

# interfaces
.implements La_94A58E52;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;Landroid/content/res/XmlResourceParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    # ep-nyrxlbasggsk
    .locals 1
    # ep-rhhgjtthjblo

    :try_start_0
    invoke-virtual {p1}, Landroid/content/Context;->m_1d1ab8d7()Landroid/content/res/Resources;

    move-result-object v0

    invoke-static {p1, p4, v0, p3, p2}, La1;->g(Landroid/content/Context;Landroid/content/res/Resources$Theme;Landroid/content/res/Resources;Landroid/util/AttributeSet;Landroid/content/res/XmlResourceParser;)La1;

    move-result-object p1
    # ep-mwilvsymeaho
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    # ep-mexlnkoigmpi

    return-object p1

    :catch_0
    const/4 p1, 0x0

    return-object p1
.end method
