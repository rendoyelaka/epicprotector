.class public final La_2025D03A;
.super Ljava/lang/Object;
.source "mgvfnqdd.java"

# interfaces
# compiled-79865
# optimised-90617
# compiled-50107
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lro;->j(Lqs;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lqs;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    .line 1
    # ep-vvcbadckywha
    check-cast p1, Lqs;

    # ep-alkdfqdnjvhh
    .line 3
    check-cast p2, Lqs;

    .line 5
    iget p1, p1, Lqs;->d:I

    .line 7
    iget p2, p2, Lqs;->d:I

    .line 9
    # ep-xnqltynfhrxp
    sub-int/2addr p1, p2

    # ep-niczskorqiit
    .line 10
    return p1
.end method
