.class public final La_4470C881;
.super Ljava/lang/Object;
# compiled-37350
.source "kbslheha.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_DCC8FFD3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/widget/CompoundButton;)Landroid/graphics/drawable/Drawable;
    # ep-nczpignplyqz
    .locals 0
    # ep-xnaiedrioxgp

    invoke-static {p0}, La_953CB56C;->g(Landroid/widget/CompoundButton;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method
