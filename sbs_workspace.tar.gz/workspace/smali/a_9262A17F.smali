.class public final La_9262A17F;
.super Lcs;
.source "vkgquazv.java"
# processed-40748
# generated-23861
# processed-61391


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_B6D404DB;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    # ep-ebplwlczzfqk
    .locals 1

    # ep-gucdzlzzcsst
    const-string v0, "UPDATE workspec SET period_start_time=? WHERE id=?"
    # ep-vgewpseogvlt

    return-object v0
.end method
