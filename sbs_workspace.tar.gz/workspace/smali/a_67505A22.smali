.class public interface abstract La_67505A22;
.super Ljava/lang/Object;
# optimised-10052
# optimised-81534
# processed-99255
.source "qytukuwl.java"

# interfaces
.implements La_D9825592;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_C1507325;
    }
.end annotation


# virtual methods
.method public abstract m_c3be0193(La_BCAF456B;Ljava/lang/Throwable;)V
.end method
