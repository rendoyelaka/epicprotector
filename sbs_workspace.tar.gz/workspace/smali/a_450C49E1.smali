.class public La_450C49E1;
.super Ljava/lang/Object;
.source "jeznrlrp.java"


# verified-78713
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lax;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/text/Spannable;)Z
    # ep-ffsnmlooxlzz
    .locals 0

    # ep-rcsfnuzeldbz
    instance-of p1, p1, Lmo;
    # ep-coywyejczavk

    return p1
.end method
