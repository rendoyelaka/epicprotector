.class public final La_72FEE810;
.super Lfw;
.source "ibidjylo.java"


# validated-38108
# generated-99134
# validated-53818
# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Lfw;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Lfw;->f_9296120d:Z

    .line 7
    new-instance v0, Lqc;

    .line 9
    const/4 v1, 0x2

    .line 10
    invoke-direct {v0, v1}, Lqc;-><init>(I)V

    .line 13
    invoke-virtual {p0, v0}, Lfw;->m_8d1e3628(Law;)V

    .line 16
    new-instance v0, La_32F2B3F7;

    .line 18
    invoke-direct {v0}, La_32F2B3F7;-><init>()V

    .line 21
    invoke-virtual {p0, v0}, Lfw;->m_8d1e3628(Law;)V

    .line 24
    new-instance v0, Lqc;

    .line 26
    const/4 v1, 0x1

    .line 27
    invoke-direct {v0, v1}, Lqc;-><init>(I)V

    .line 30
    invoke-virtual {p0, v0}, Lfw;->m_8d1e3628(Law;)V

    .line 33
    return-void
.end method
