.class public final La_6EA0A949;
.super Ljava/lang/Object;
# generated-60026
# generated-18763
.source "yqsnvqca.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_D7228952;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public a:Ljava/net/Socket;

.field public b:Ljava/lang/String;

.field public c:La_A566D669;

.field public d:La_EFED7928;

.field public e:La_8DBB5743;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    sget-object v0, La_8DBB5743;->a:La_70F06CED;

    .line 6
    iput-object v0, p0, La_6EA0A949;->e:La_8DBB5743;

    .line 8
    return-void
.end method
