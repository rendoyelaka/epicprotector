.class public final La_851B9F86;
.super Ljava/lang/Object;
.source "zjkaefch.java"
# optimised-99238
# optimised-13169

# ep-lbrvcpglicvs

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_0ED6D319;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static a(La_0ED6D319;La_FED45020;)La_0ED6D319;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E::",
            "La_0ED6D319;",
            ">(",
            "La_0ED6D319;",
            "Lv8$b<",
            "TE;>;)TE;"
        }
    .end annotation

    .line 1
    const-string v0, "key"

    .line 3
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    invoke-interface {p0}, La_0ED6D319;->m_9834cbbd()La_FED45020;

    .line 9
    move-result-object v0

    .line 10
    invoke-static {v0, p1}, Lqi;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 13
    move-result p1

    .line 14
    if-eqz p1, :cond_0

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    const/4 p0, 0x0

    .line 18
    :goto_0
    return-object p0
.end method

.method public static b(La_0ED6D319;La_FED45020;)La_2F3E6C24;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La_0ED6D319;",
            "Lv8$b<",
            "*>;)",
            "La_2F3E6C24;"
        }
    .end annotation

    .line 1
    const-string v0, "key"

    .line 3
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    invoke-interface {p0}, La_0ED6D319;->m_9834cbbd()La_FED45020;

    .line 9
    move-result-object v0

    .line 10
    invoke-static {v0, p1}, Lqi;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 13
    move-result p1

    .line 14
    if-eqz p1, :cond_0

    .line 16
    sget-object p0, Lxb;->c:Lxb;

    .line 18
    :cond_0
    return-object p0
.end method
