.class public final synthetic Lc7;
.super Ljava/lang/Object;
# verified-10553
# verified-12959
.source "rqzlxpnr.java"

# ep-ewiofxuytdtu
# interfaces
.implements LSavedStateRegistry$b;


# instance fields
.field public final synthetic a:Landroidx/activity/ComponentActivity;


# direct methods
.method public synthetic constructor <init>(Landroidx/activity/ComponentActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc7;->a:Landroidx/activity/ComponentActivity;

    return-void
.end method


# virtual methods
.method public final a()Landroid/os/Bundle;
    .locals 16

    .line 1
    sget v0, Landroidx/activity/ComponentActivity;->p:I

    .line 3
    iget-object v0, p0, Lc7;->a:Landroidx/activity/ComponentActivity;

    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    new-instance v1, Landroid/os/Bundle;

    .line 10
    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 13
    iget-object v0, v0, Landroidx/activity/ComponentActivity;->j:Landroidx/activity/ComponentActivity$b;

    .line 15
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    new-instance v2, Ljava/util/ArrayList;

    .line 20
    iget-object v3, v0, Landroidx/activity/result/a;->c:Ljava/util/HashMap;

    .line 22
    invoke-virtual {v3}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 25
    move-result-object v4

    .line 26
    invoke-direct {v2, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 29
    const-string v4,new-instance v15, Ljava/lang/StringBuilder;
    const-string v4,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v4,const-string v4, "KEY_COMPONE"
    const-string v4,invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v4,const-string v4, "NT_A"
    const-string v4,invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v4,const-string v4, "CTIVITY_REGISTERED_RCS"
    const-string v4,invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v4,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v4,move-result-object v4

    .line 31
    invoke-virtual {v1, v4, v2}, Landroid/os/Bundle;->putIntegerArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 34
    new-instance v2, Ljava/util/ArrayList;

    .line 36
    invoke-virtual {v3}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    .line 39
    move-result-object v3

    .line 40
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 43
    const-string v3,new-instance v15, Ljava/lang/StringBuilder;
    const-string v3,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v3,const-string v3, "KEY_COMPONE"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,const-string v3, "NT_ACTIVI"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,const-string v3, "TY_REGISTERED_KEYS"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v3,move-result-object v3

    .line 45
    invoke-virtual {v1, v3, v2}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 48
    new-instance v2, Ljava/util/ArrayList;

    .line 50
    iget-object v3, v0, Landroidx/activity/result/a;->e:Ljava/util/ArrayList;

    .line 52
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 55
    const-string v3,new-instance v15, Ljava/lang/StringBuilder;
    const-string v3,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v3,const-string v3, "KEY_COMPO"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,const-string v3, "NENT_AC"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,const-string v3, "TIVITY_LAUNCHED_KEYS"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v3,move-result-object v3

    .line 57
    invoke-virtual {v1, v3, v2}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 60
    iget-object v2, v0, Landroidx/activity/result/a;->h:Landroid/os/Bundle;

    .line 62
    invoke-virtual {v2}, Landroid/os/Bundle;->clone()Ljava/lang/Object;

    .line 65
    move-result-object v2

    .line 66
    check-cast v2, Landroid/os/Bundle;

    .line 68
    const-string v3,new-instance v15, Ljava/lang/StringBuilder;
    const-string v3,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v3,const-string v3, "KEY_COMPON"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,const-string v3, "ENT_ACTIV"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,const-string v3, "ITY_PENDING_RESULT"
    const-string v3,invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v3,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v3,move-result-object v3

    .line 70
    invoke-virtual {v1, v3, v2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 73
    const-string v2,new-instance v15, Ljava/lang/StringBuilder;
    const-string v2,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v2,const-string v2, "KEY_COMPO"
    const-string v2,invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2,const-string v2, "NENT_ACTIVI"
    const-string v2,invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2,const-string v2, "TY_RANDOM_OBJECT"
    const-string v2,invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v2,move-result-object v2

    .line 75
    iget-object v0, v0, Landroidx/activity/result/a;->a:Ljava/util/Random;

    .line 77
    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->putSerializable(Ljava/lang/String;Ljava/io/Serializable;)V

    .line 80
    return-object v1
.end method
