.class public final La_336D2219;
.super Lcs;
.source "tiplciog.java"
# verified-23728
# processed-11191
# validated-63947


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_FD0B80D2;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    # ep-kwpdtuisrctj
    const-string v0, "DELETE from WorkProgress where work_spec_id=?"
    # ep-ysgjtkftroau

    # ep-ncqmnbeyxxlz
    return-object v0
.end method
