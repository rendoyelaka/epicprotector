.class public final La_5E1A8328;
# ep-exsxdcwgfvpx
.super Ljava/lang/Object;
.source "frijltvl.java"

# verified-18938
# interfaces
.implements Lrt;


# instance fields
.field public a:Ljava/lang/CharSequence;

.field public b:Ljava/lang/CharSequence;

.field public c:Landroid/content/Intent;

.field public d:C

.field public e:I

.field public f:C

.field public g:I

.field public h:Landroid/graphics/drawable/Drawable;

.field public final i:Landroid/content/Context;

.field public j:Ljava/lang/CharSequence;

.field public k:Ljava/lang/CharSequence;

.field public l:Landroid/content/res/ColorStateList;

.field public m:Landroid/graphics/PorterDuff$Mode;

.field public n:Z

.field public o:Z

.field public p:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/CharSequence;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/16 v0, 0x1000

    .line 6
    iput v0, p0, La_5E1A8328;->e:I

    .line 8
    iput v0, p0, La_5E1A8328;->g:I

    .line 10
    const/4 v0, 0x0

    .line 11
    iput-object v0, p0, La_5E1A8328;->l:Landroid/content/res/ColorStateList;

    .line 13
    iput-object v0, p0, La_5E1A8328;->m:Landroid/graphics/PorterDuff$Mode;

    .line 15
    const/4 v0, 0x0

    .line 16
    iput-boolean v0, p0, La_5E1A8328;->n:Z

    .line 18
    iput-boolean v0, p0, La_5E1A8328;->o:Z

    .line 20
    const/16 v0, 0x10

    .line 22
    iput v0, p0, La_5E1A8328;->p:I

    .line 24
    iput-object p1, p0, La_5E1A8328;->i:Landroid/content/Context;

    .line 26
    iput-object p2, p0, La_5E1A8328;->a:Ljava/lang/CharSequence;

    .line 28
    return-void
.end method


# virtual methods
.method public final a()La_F32A8AF8;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final b(La_F32A8AF8;)Lrt;
    .locals 0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final c()V
    .locals 2

    .line 1
    iget-object v0, p0, La_5E1A8328;->h:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_2

    .line 5
    iget-boolean v1, p0, La_5E1A8328;->n:Z

    .line 7
    if-nez v1, :cond_0

    .line 9
    iget-boolean v1, p0, La_5E1A8328;->o:Z

    .line 11
    if-eqz v1, :cond_2

    .line 13
    :cond_0
    invoke-static {v0}, Lta;->g(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    .line 16
    move-result-object v0

    .line 17
    iput-object v0, p0, La_5E1A8328;->h:Landroid/graphics/drawable/Drawable;

    .line 19
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_e416d128()Landroid/graphics/drawable/Drawable;

    .line 22
    move-result-object v0

    .line 23
    iput-object v0, p0, La_5E1A8328;->h:Landroid/graphics/drawable/Drawable;

    .line 25
    iget-boolean v1, p0, La_5E1A8328;->n:Z

    .line 27
    if-eqz v1, :cond_1

    .line 29
    iget-object v1, p0, La_5E1A8328;->l:Landroid/content/res/ColorStateList;

    .line 31
    invoke-static {v0, v1}, La_4F46A9E0;->h(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 34
    :cond_1
    iget-boolean v0, p0, La_5E1A8328;->o:Z

    .line 36
    if-eqz v0, :cond_2

    .line 38
    iget-object v0, p0, La_5E1A8328;->h:Landroid/graphics/drawable/Drawable;

    .line 40
    iget-object v1, p0, La_5E1A8328;->m:Landroid/graphics/PorterDuff$Mode;

    .line 42
    invoke-static {v0, v1}, La_4F46A9E0;->i(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    .line 45
    :cond_2
    return-void
.end method

.method public final m_d04c398c()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final m_35fe27fb()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final m_0acddec4()Landroid/view/ActionProvider;
    .locals 1

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final m_47213d05()Landroid/view/View;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final m_75c238f6()I
    .locals 1

    iget v0, p0, La_5E1A8328;->g:I

    return v0
.end method

.method public final m_79248e64()C
    .locals 1

    iget-char v0, p0, La_5E1A8328;->f:C

    return v0
.end method

.method public final m_fd08e4b9()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, La_5E1A8328;->j:Ljava/lang/CharSequence;

    return-object v0
.end method

.method public final m_68cc1f57()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final m_34add397()Landroid/graphics/drawable/Drawable;
    .locals 1

    iget-object v0, p0, La_5E1A8328;->h:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method public final m_6276e189()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, La_5E1A8328;->l:Landroid/content/res/ColorStateList;

    return-object v0
.end method

.method public final m_6b68a9e1()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    iget-object v0, p0, La_5E1A8328;->m:Landroid/graphics/PorterDuff$Mode;

    return-object v0
.end method

.method public final m_4b698a78()Landroid/content/Intent;
    .locals 1

    iget-object v0, p0, La_5E1A8328;->c:Landroid/content/Intent;

    return-object v0
.end method

.method public final getItemId()I
    .locals 1

    const v0, 0x102002c

    return v0
.end method

.method public final m_ee39cb14()Landroid/view/ContextMenu$ContextMenuInfo;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final m_ad6d5f8b()I
    .locals 1

    iget v0, p0, La_5E1A8328;->e:I

    return v0
.end method

.method public final m_185b5a86()C
    .locals 1

    iget-char v0, p0, La_5E1A8328;->d:C

    return v0
.end method

.method public final m_2c43ae74()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final m_3395b31d()Landroid/view/SubMenu;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final m_217e394b()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, La_5E1A8328;->a:Ljava/lang/CharSequence;

    return-object v0
.end method

.method public final m_878ea020()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, La_5E1A8328;->b:Ljava/lang/CharSequence;

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, La_5E1A8328;->a:Ljava/lang/CharSequence;

    :goto_0
    return-object v0
.end method

.method public final m_b167149f()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, La_5E1A8328;->k:Ljava/lang/CharSequence;

    return-object v0
.end method

.method public final m_28b5a414()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final m_b5366e31()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final m_4d9490d6()Z
    .locals 2

    iget v0, p0, La_5E1A8328;->p:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public final m_51eaf22e()Z
    .locals 1

    iget v0, p0, La_5E1A8328;->p:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final m_a360e872()Z
    .locals 1

    iget v0, p0, La_5E1A8328;->p:I

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final m_f0135d0f()Z
    .locals 1

    iget v0, p0, La_5E1A8328;->p:I

    and-int/lit8 v0, v0, 0x8

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final m_6bf39c64(Landroid/view/ActionProvider;)Landroid/view/MenuItem;
    .locals 0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final m_606cac90(I)Landroid/view/MenuItem;
    .locals 0

    .line 2
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final m_606cac90(Landroid/view/View;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final m_1e8cc1bb(C)Landroid/view/MenuItem;
    .locals 0

    .line 1
    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, La_5E1A8328;->f:C

    return-object p0
.end method

.method public final m_1e8cc1bb(CI)Landroid/view/MenuItem;
    .locals 0

    .line 2
    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, La_5E1A8328;->f:C

    .line 3
    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, La_5E1A8328;->g:I

    return-object p0
.end method

.method public final m_d52749ba(Z)Landroid/view/MenuItem;
    .locals 1

    iget v0, p0, La_5E1A8328;->p:I

    and-int/lit8 v0, v0, -0x2

    or-int/2addr p1, v0

    iput p1, p0, La_5E1A8328;->p:I

    return-object p0
.end method

.method public final m_3d75c0dd(Z)Landroid/view/MenuItem;
    .locals 1

    iget v0, p0, La_5E1A8328;->p:I

    and-int/lit8 v0, v0, -0x3

    if-eqz p1, :cond_0

    const/4 p1, 0x2

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    or-int/2addr p1, v0

    iput p1, p0, La_5E1A8328;->p:I

    return-object p0
.end method

.method public final m_551d37ed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 0

    .line 2
    iput-object p1, p0, La_5E1A8328;->j:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_551d37ed(Ljava/lang/CharSequence;)Lrt;
    .locals 0

    .line 1
    iput-object p1, p0, La_5E1A8328;->j:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_2e470481(Z)Landroid/view/MenuItem;
    .locals 1

    iget v0, p0, La_5E1A8328;->p:I

    and-int/lit8 v0, v0, -0x11

    if-eqz p1, :cond_0

    const/16 p1, 0x10

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    or-int/2addr p1, v0

    iput p1, p0, La_5E1A8328;->p:I

    return-object p0
.end method

.method public final m_614e6c85(I)Landroid/view/MenuItem;
    .locals 1

    .line 3
    sget-object v0, La_6B590370;->a:Ljava/lang/Object;

    .line 4
    iget-object v0, p0, La_5E1A8328;->i:Landroid/content/Context;

    invoke-static {v0, p1}, La_D1071D58;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    .line 5
    iput-object p1, p0, La_5E1A8328;->h:Landroid/graphics/drawable/Drawable;

    .line 6
    invoke-virtual {p0}, La_5E1A8328;->c()V

    return-object p0
.end method

.method public final m_614e6c85(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-object p1, p0, La_5E1A8328;->h:Landroid/graphics/drawable/Drawable;

    .line 2
    invoke-virtual {p0}, La_5E1A8328;->c()V

    return-object p0
.end method

.method public final m_4cad4627(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-object p1, p0, La_5E1A8328;->l:Landroid/content/res/ColorStateList;

    .line 3
    const/4 p1, 0x1

    .line 4
    iput-boolean p1, p0, La_5E1A8328;->n:Z

    .line 6
    invoke-virtual {p0}, La_5E1A8328;->c()V

    .line 9
    return-object p0
.end method

.method public final m_2e5eb520(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-object p1, p0, La_5E1A8328;->m:Landroid/graphics/PorterDuff$Mode;

    .line 3
    const/4 p1, 0x1

    .line 4
    iput-boolean p1, p0, La_5E1A8328;->o:Z

    .line 6
    invoke-virtual {p0}, La_5E1A8328;->c()V

    .line 9
    return-object p0
.end method

.method public final m_78c68241(Landroid/content/Intent;)Landroid/view/MenuItem;
    .locals 0

    iput-object p1, p0, La_5E1A8328;->c:Landroid/content/Intent;

    return-object p0
.end method

.method public final m_34e3e605(C)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-char p1, p0, La_5E1A8328;->d:C

    return-object p0
.end method

.method public final m_34e3e605(CI)Landroid/view/MenuItem;
    .locals 0

    .line 2
    iput-char p1, p0, La_5E1A8328;->d:C

    .line 3
    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, La_5E1A8328;->e:I

    return-object p0
.end method

.method public final m_5babcf8f(Landroid/view/MenuItem$OnActionExpandListener;)Landroid/view/MenuItem;
    .locals 0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final m_c7849732(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;
    .locals 0

    return-object p0
.end method

.method public final m_9db2701e(CC)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-char p1, p0, La_5E1A8328;->d:C

    .line 2
    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, La_5E1A8328;->f:C

    return-object p0
.end method

.method public final m_9db2701e(CCII)Landroid/view/MenuItem;
    .locals 0

    .line 3
    iput-char p1, p0, La_5E1A8328;->d:C

    .line 4
    invoke-static {p3}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, La_5E1A8328;->e:I

    .line 5
    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, La_5E1A8328;->f:C

    .line 6
    invoke-static {p4}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, La_5E1A8328;->g:I

    return-object p0
.end method

.method public final m_d0bafa1c(I)V
    .locals 0

    return-void
.end method

.method public final m_49cab67b(I)Landroid/view/MenuItem;
    .locals 0

    return-object p0
.end method

.method public final m_742c1193(I)Landroid/view/MenuItem;
    .locals 1

    .line 2
    iget-object v0, p0, La_5E1A8328;->i:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->m_201f7e66()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, La_5E1A8328;->a:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_742c1193(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-object p1, p0, La_5E1A8328;->a:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_7deb5944(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 0

    iput-object p1, p0, La_5E1A8328;->b:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_1c276745(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 0

    .line 2
    iput-object p1, p0, La_5E1A8328;->k:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_1c276745(Ljava/lang/CharSequence;)Lrt;
    .locals 0

    .line 1
    iput-object p1, p0, La_5E1A8328;->k:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final m_0166a1e8(Z)Landroid/view/MenuItem;
    .locals 2

    iget v0, p0, La_5E1A8328;->p:I

    const/16 v1, 0x8

    and-int/2addr v0, v1

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    :cond_0
    or-int p1, v0, v1

    iput p1, p0, La_5E1A8328;->p:I

    return-object p0
.end method
