.class public final La_0303D629;
.super Lfx;
.source "dhpfsjye.java"

# optimised-22867
# compiled-11477
# interfaces
.implements Landroid/graphics/drawable/Animatable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_F975E3BE;,
        La_58CCC6C8;
    }
.end annotation


# static fields
.field public static final synthetic i:I


# instance fields
.field public final d:La_F975E3BE;

.field public final e:Landroid/content/Context;

.field public f:La_F400175F;

.field public g:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La_001A6014;",
            ">;"
        }
    .end annotation
.end field

.field public final h:La_396F0F34;


# direct methods
.method public constructor <init>()V
    .locals 1

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, La_0303D629;-><init>(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 2
    invoke-direct {p0}, Lfx;-><init>()V

    const/4 v0, 0x0

    .line 3
    iput-object v0, p0, La_0303D629;->f:La_F400175F;

    .line 4
    iput-object v0, p0, La_0303D629;->g:Ljava/util/ArrayList;

    .line 5
    new-instance v0, La_396F0F34;

    invoke-direct {v0, p0}, La_396F0F34;-><init>(La_0303D629;)V

    iput-object v0, p0, La_0303D629;->h:La_396F0F34;

    .line 6
    iput-object p1, p0, La_0303D629;->e:Landroid/content/Context;

    .line 7
    new-instance p1, La_F975E3BE;

    invoke-direct {p1, v0}, La_F975E3BE;-><init>(La_396F0F34;)V

    iput-object p1, p0, La_0303D629;->d:La_F975E3BE;

    return-void
.end method


# virtual methods
.method public final m_99c2cba2(Landroid/content/res/Resources$Theme;)V
    # ep-grwktcejfqfn
    .locals 1

    # ep-nhqxaoyogtvy
    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    # ep-jevpqenlxekq
    .line 5
    invoke-static {v0, p1}, La_23A16E76;->a(Landroid/graphics/drawable/Drawable;Landroid/content/res/Resources$Theme;)V

    .line 8
    # ep-dyrqxlbfebkc
    :cond_0
    return-void
.end method

.method public final m_95800478()Z
    .locals 1
    # ep-oasuupcifjit

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-static {v0}, La_23A16E76;->b(Landroid/graphics/drawable/Drawable;)Z
    # ep-hbjhjsqdwwkg

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    return v0
.end method

.method public final m_d717b8ec(Landroid/graphics/Canvas;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_d717b8ec(Landroid/graphics/Canvas;)V

    .line 8
    return-void

    .line 9
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    .line 11
    iget-object v1, v0, La_F975E3BE;->a:Lgx;

    .line 13
    invoke-virtual {v1, p1}, Lgx;->m_d717b8ec(Landroid/graphics/Canvas;)V

    .line 16
    iget-object p1, v0, La_F975E3BE;->b:Landroid/animation/AnimatorSet;

    .line 18
    # ep-vfqbbbcknnom
    invoke-virtual {p1}, Landroid/animation/AnimatorSet;->isStarted()Z

    .line 21
    move-result p1

    .line 22
    if-eqz p1, :cond_1

    .line 24
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->m_b0edfaa7()V
    # ep-pwsjxtkpsahw

    .line 27
    :cond_1
    return-void
.end method

.method public final m_22f1e8e5()I
    .locals 1
    # ep-hwxykhqauydc

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-static {v0}, La_231E9530;->a(Landroid/graphics/drawable/Drawable;)I

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    .line 12
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    .line 14
    invoke-virtual {v0}, Lgx;->m_22f1e8e5()I

    .line 17
    move-result v0

    .line 18
    # ep-lamxeyzyzksl
    return v0
.end method

    # ep-njwrmwmjvgaz
.method public final m_6dd68863()I
    .locals 2

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    # ep-qdbzoxnkctie
    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_6dd68863()I

    .line 8
    move-result v0

    .line 9
    return v0

    # ep-vekohheyoqmo
    .line 10
    :cond_0
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->m_6dd68863()I

    .line 13
    move-result v0

    .line 14
    iget-object v1, p0, La_0303D629;->d:La_F975E3BE;

    .line 16
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    # ep-xvshocukxqrl
    .line 19
    or-int/lit8 v0, v0, 0x0

    .line 21
    return v0
.end method

.method public final m_98441cbb()Landroid/graphics/ColorFilter;
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-static {v0}, La_23A16E76;->c(Landroid/graphics/drawable/Drawable;)Landroid/graphics/ColorFilter;
    # ep-zagalvdlslif

    .line 8
    move-result-object v0

    .line 9
    # ep-bznfviudmqnh
    return-object v0

    .line 10
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    .line 12
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    .line 14
    invoke-virtual {v0}, Lgx;->m_98441cbb()Landroid/graphics/ColorFilter;

    .line 17
    move-result-object v0
    # ep-adjgtkidxcqm

    .line 18
    return-object v0
.end method

.method public final m_6f62fd1d()Landroid/graphics/drawable/Drawable$ConstantState;
    # ep-gsetnnatmkqs
    .locals 2

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    # ep-sqqwqphijuse
    if-eqz v0, :cond_0

    .line 5
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 7
    const/16 v1, 0x18

    .line 9
    if-lt v0, v1, :cond_0

    .line 11
    new-instance v0, La_58CCC6C8;

    .line 13
    iget-object v1, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    # ep-tcudrakrjcks
    .line 15
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->m_6f62fd1d()Landroid/graphics/drawable/Drawable$ConstantState;

    .line 18
    move-result-object v1

    .line 19
    invoke-direct {v0, v1}, La_58CCC6C8;-><init>(Landroid/graphics/drawable/Drawable$ConstantState;)V

    .line 22
    # ep-ilsozwykekqo
    return-object v0

    .line 23
    :cond_0
    const/4 v0, 0x0

    .line 24
    return-object v0
.end method

    # ep-gogakmwizrfd
.method public final m_86f89534()I
    .locals 1

    # ep-ypslhklzlwix
    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_86f89534()I

    .line 8
    move-result v0

    .line 9
    # ep-xrmfurfisykj
    return v0

    .line 10
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    .line 12
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    .line 14
    invoke-virtual {v0}, Lgx;->m_86f89534()I

    .line 17
    move-result v0

    .line 18
    return v0
.end method

.method public final m_6357eda4()I
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    # ep-jeemomcvetdy
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_6357eda4()I

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    .line 12
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    .line 14
    invoke-virtual {v0}, Lgx;->m_6357eda4()I

    .line 17
    move-result v0
    # ep-cbftqcrlmboq

    .line 18
    return v0
.end method

.method public final m_273b83a5()I
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;
    # ep-wauhriklnqsa

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_273b83a5()I

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;
    # ep-qrbquugygdhp

    .line 12
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    .line 14
    invoke-virtual {v0}, Lgx;->m_273b83a5()I

    .line 17
    move-result v0

    .line 18
    return v0
.end method

    # ep-lpzpozmtgxje
.method public final m_c96b66fc(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;)V
    .locals 1
    # ep-vmxjexyiuoou

    # ep-wwgaghfvffro
    const/4 v0, 0x0

    .line 71
    invoke-virtual {p0, p1, p2, p3, v0}, La_0303D629;->m_c96b66fc(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    return-void
.end method

.method public final m_c96b66fc(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V
    .locals 21

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move-object/from16 v2, p3

    move-object/from16 v3, p4

    .line 1
    iget-object v4, v1, Lfx;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v4, :cond_0

    move-object/from16 v5, p2
    # ep-sgvfkpqkiyzz

    .line 2
    invoke-static {v4, v0, v5, v2, v3}, La_23A16E76;->d(Landroid/graphics/drawable/Drawable;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    return-void

    :cond_0
    move-object/from16 v5, p2

    .line 3
    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v4

    .line 4
    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v6

    const/4 v7, 0x1

    add-int/2addr v6, v7

    .line 5
    :goto_0
    iget-object v8, v1, La_0303D629;->d:La_F975E3BE;

    if-eq v4, v7, :cond_e

    .line 6
    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v9

    if-ge v9, v6, :cond_1

    const/4 v9, 0x3

    if-eq v4, v9, :cond_e

    :cond_1
    const/4 v9, 0x2
    # ep-hkbbovmintef

    if-ne v4, v9, :cond_d

    .line 7
    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v4

    const-string v10, "animated-vector"

    .line 8
    invoke-virtual {v10, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    const/4 v11, 0x0

    const/16 v12, 0x18

    const/4 v13, 0x0

    if-eqz v10, :cond_7

    .line 9
    sget-object v4, La_8897113E;->e:[I

    .line 10
    invoke-static {v0, v3, v2, v4}, Llw;->f(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v4

    .line 11
    invoke-virtual {v4, v13, v13}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v10

    if-eqz v10, :cond_6

    .line 12
    sget-object v14, Lgx;->l:Landroid/graphics/PorterDuff$Mode;

    .line 13
    sget v14, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v14, v12, :cond_2

    .line 14
    new-instance v9, Lgx;

    invoke-direct {v9}, Lgx;-><init>()V

    .line 15
    sget-object v12, Lup;->a:Ljava/lang/ThreadLocal;

    .line 16
    invoke-static {v0, v10, v3}, La_43348F2E;->a(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object v10

    .line 17
    iput-object v10, v9, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 18
    new-instance v10, La_9F380FA6;

    iget-object v12, v9, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 19
    invoke-virtual {v12}, Landroid/graphics/drawable/Drawable;->m_6f62fd1d()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v12

    invoke-direct {v10, v12}, La_9F380FA6;-><init>(Landroid/graphics/drawable/Drawable$ConstantState;)V

    goto :goto_2

    .line 20
    :cond_2
    :try_start_0
    invoke-virtual {v0, v10}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    move-result-object v10

    .line 21
    invoke-static {v10}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    move-result-object v12

    .line 22
    :goto_1
    invoke-interface {v10}, Lorg/xmlpull/v1/XmlPullParser;->m_99b5c661()I

    move-result v14

    if-eq v14, v9, :cond_3

    if-eq v14, v7, :cond_3

    goto :goto_1

    :cond_3
    if-ne v14, v9, :cond_4

    .line 23
    new-instance v9, Lgx;

    invoke-direct {v9}, Lgx;-><init>()V

    .line 24
    invoke-virtual {v9, v0, v10, v12, v3}, Lgx;->m_c96b66fc(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    goto :goto_2

    .line 25
    :cond_4
    new-instance v9, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v10, "No start tag found"

    invoke-direct {v9, v10}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v9
    :try_end_0
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    nop

    move-object v9, v11

    .line 26
    :goto_2
    iput-boolean v13, v9, Lgx;->h:Z

    .line 27
    iget-object v10, v1, La_0303D629;->h:La_396F0F34;

    invoke-virtual {v9, v10}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    .line 28
    iget-object v10, v8, La_F975E3BE;->a:Lgx;

    if-eqz v10, :cond_5

    .line 29
    invoke-virtual {v10, v11}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    .line 30
    :cond_5
    iput-object v9, v8, La_F975E3BE;->a:Lgx;

    .line 31
    :cond_6
    invoke-virtual {v4}, Landroid/content/res/TypedArray;->recycle()V

    goto/16 :goto_8

    :cond_7
    const-string v9, "target"

    .line 32
    invoke-virtual {v9, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_d

    .line 33
    sget-object v4, La_8897113E;->f:[I

    .line 34
    invoke-virtual {v0, v2, v4}, Landroid/content/res/Resources;->obtainAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v4

    .line 35
    invoke-virtual {v4, v13}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v9

    .line 36
    invoke-virtual {v4, v7, v13}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v10

    if-eqz v10, :cond_c

    .line 37
    iget-object v13, v1, La_0303D629;->e:Landroid/content/Context;

    if-eqz v13, :cond_b

    .line 38
    sget v14, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v14, v12, :cond_8

    .line 39
    invoke-static {v13, v10}, Landroid/animation/AnimatorInflater;->loadAnimator(Landroid/content/Context;I)Landroid/animation/Animator;

    move-result-object v10

    goto :goto_3

    .line 40
    :cond_8
    invoke-virtual {v13}, Landroid/content/Context;->m_1d1ab8d7()Landroid/content/res/Resources;

    move-result-object v14

    invoke-virtual {v13}, Landroid/content/Context;->m_83479040()Landroid/content/res/Resources$Theme;

    move-result-object v15

    const-string v12, "Can\'t load animation resource ID #0x"

    .line 41
    :try_start_1
    invoke-virtual {v14, v10}, Landroid/content/res/Resources;->getAnimation(I)Landroid/content/res/XmlResourceParser;

    move-result-object v20
    :try_end_1
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_1 .. :try_end_1} :catch_4
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_3
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 42
    :try_start_2
    invoke-static/range {v20 .. v20}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    move-result-object v17

    const/16 v18, 0x0

    const/16 v19, 0x0

    move-object/from16 v16, v20

    invoke-static/range {v13 .. v19}, La_163791E6;->a(Landroid/content/Context;Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/content/res/XmlResourceParser;Landroid/util/AttributeSet;Landroid/animation/AnimatorSet;I)Landroid/animation/Animator;

    move-result-object v10
    :try_end_2
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 43
    invoke-interface/range {v20 .. v20}, Landroid/content/res/XmlResourceParser;->m_4bb68b61()V

    .line 44
    :goto_3
    iget-object v12, v8, La_F975E3BE;->a:Lgx;

    .line 45
    iget-object v12, v12, Lgx;->d:La_1C9CE24F;

    .line 46
    iget-object v12, v12, La_1C9CE24F;->b:La_90319E5D;

    iget-object v12, v12, La_90319E5D;->o:La_2AB970AB;

    .line 47
    invoke-virtual {v12, v9, v11}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    .line 48
    invoke-virtual {v10, v11}, Landroid/animation/Animator;->setTarget(Ljava/lang/Object;)V

    .line 49
    iget-object v11, v8, La_F975E3BE;->c:Ljava/util/ArrayList;

    if-nez v11, :cond_9

    .line 50
    new-instance v11, Ljava/util/ArrayList;

    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    iput-object v11, v8, La_F975E3BE;->c:Ljava/util/ArrayList;

    .line 51
    new-instance v11, La_2AB970AB;

    invoke-direct {v11}, La_2AB970AB;-><init>()V

    iput-object v11, v8, La_F975E3BE;->d:La_2AB970AB;

    .line 52
    :cond_9
    iget-object v11, v8, La_F975E3BE;->c:Ljava/util/ArrayList;

    invoke-virtual {v11, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 53
    iget-object v8, v8, La_F975E3BE;->d:La_2AB970AB;

    invoke-virtual {v8, v10, v9}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_7

    :catchall_0
    move-exception v0

    move-object/from16 v11, v20

    goto :goto_6

    :catch_1
    move-exception v0

    move-object/from16 v11, v20

    goto :goto_4

    :catch_2
    move-exception v0

    move-object/from16 v11, v20

    goto :goto_5

    :catchall_1
    move-exception v0

    goto :goto_6

    :catch_3
    move-exception v0

    .line 54
    :goto_4
    :try_start_3
    new-instance v2, Landroid/content/res/Resources$NotFoundException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 55
    invoke-static {v10}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/content/res/Resources$NotFoundException;-><init>(Ljava/lang/String;)V

    .line 56
    invoke-virtual {v2, v0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 57
    throw v2

    :catch_4
    move-exception v0

    .line 58
    :goto_5
    new-instance v2, Landroid/content/res/Resources$NotFoundException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 59
    invoke-static {v10}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    # ep-uinxoeuqxjmj

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/content/res/Resources$NotFoundException;-><init>(Ljava/lang/String;)V

    .line 60
    invoke-virtual {v2, v0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 61
    throw v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :goto_6
    if-eqz v11, :cond_a

    .line 62
    invoke-interface {v11}, Landroid/content/res/XmlResourceParser;->m_4bb68b61()V

    .line 63
    :cond_a
    throw v0

    .line 64
    :cond_b
    invoke-virtual {v4}, Landroid/content/res/TypedArray;->recycle()V

    .line 65
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "Context can\'t be null when inflating animators"

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 66
    :cond_c
    :goto_7
    invoke-virtual {v4}, Landroid/content/res/TypedArray;->recycle()V

    .line 67
    :cond_d
    :goto_8
    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->m_99b5c661()I

    move-result v4

    goto/16 :goto_0

    .line 68
    :cond_e
    iget-object v0, v8, La_F975E3BE;->b:Landroid/animation/AnimatorSet;

    if-nez v0, :cond_f

    .line 69
    new-instance v0, Landroid/animation/AnimatorSet;

    invoke-direct {v0}, Landroid/animation/AnimatorSet;-><init>()V

    iput-object v0, v8, La_F975E3BE;->b:Landroid/animation/AnimatorSet;

    .line 70
    :cond_f
    iget-object v0, v8, La_F975E3BE;->b:Landroid/animation/AnimatorSet;

    iget-object v2, v8, La_F975E3BE;->c:Ljava/util/ArrayList;

    invoke-virtual {v0, v2}, Landroid/animation/AnimatorSet;->playTogether(Ljava/util/Collection;)V

    return-void
.end method

.method public final m_46860169()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-static {v0}, La_231E9530;->d(Landroid/graphics/drawable/Drawable;)Z

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    .line 12
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    .line 14
    invoke-virtual {v0}, Lgx;->m_46860169()Z
    # ep-teueqdcakweu

    # ep-itdfkcczfsbf
    .line 17
    move-result v0

    .line 18
    return v0
.end method

.method public final m_eba108ee()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    # ep-ggmfdxiujgpc
    if-eqz v0, :cond_0

    .line 5
    check-cast v0, Landroid/graphics/drawable/AnimatedVectorDrawable;

    .line 7
    invoke-virtual {v0}, Landroid/graphics/drawable/AnimatedVectorDrawable;->m_eba108ee()Z

    .line 10
    move-result v0

    .line 11
    # ep-knzfozzjkjbi
    return v0

    .line 12
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    .line 14
    iget-object v0, v0, La_F975E3BE;->b:Landroid/animation/AnimatorSet;

    .line 16
    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->m_eba108ee()Z

    .line 19
    move-result v0

    .line 20
    return v0
.end method

.method public final m_dc9b7b63()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    # ep-qaulmvwptxfm
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_dc9b7b63()Z

    .line 8
    move-result v0

    .line 9
    return v0

    # ep-brztvgvsfaup
    .line 10
    :cond_0
    # ep-qgabkduafbhc
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    .line 12
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    .line 14
    invoke-virtual {v0}, Lgx;->m_dc9b7b63()Z
    # ep-senwdqsukrky

    .line 17
    move-result v0

    .line 18
    return v0
.end method

.method public final m_378bcca1()Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;
    # ep-udavcmhedosj

    # ep-svnjunmufeau
    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_378bcca1()Landroid/graphics/drawable/Drawable;

    # ep-hnmncdbwlsiv
    .line 8
    :cond_0
    return-object p0
.end method

.method public final onBoundsChange(Landroid/graphics/Rect;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    # ep-amrfxrhffoww
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    .line 8
    return-void

    .line 9
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;
    # ep-nlyalgsqtzmu

    .line 11
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    # ep-aulgrdrvuyon
    .line 13
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V
    # ep-gcyxacoyhoaw

    .line 16
    return-void
.end method

.method public final onLevelChange(I)Z
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 8
    move-result p1

    .line 9
    return p1

    .line 10
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;
    # ep-osmqkmerhxmv

    .line 12
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    .line 14
    # ep-lxikfcllodle
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 17
    move-result p1

    .line 18
    return p1
.end method

.method public final onStateChange([I)Z
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_7f79ea7c([I)Z

    .line 8
    move-result p1

    # ep-vrivqotlcqus
    .line 9
    return p1

    .line 10
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    .line 12
    iget-object v0, v0, La_F975E3BE;->a:Lgx;
    # ep-brehuzggqoox

    .line 14
    invoke-virtual {v0, p1}, Lfx;->m_7f79ea7c([I)Z

    .line 17
    move-result p1

    .line 18
    return p1
.end method

.method public final m_4fbc3867(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_4fbc3867(I)V

    .line 8
    return-void

    .line 9
    # ep-oavbsflqyrrr
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    .line 11
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    .line 13
    invoke-virtual {v0, p1}, Lgx;->m_4fbc3867(I)V
    # ep-htbxqufygwyf

    .line 16
    return-void
.end method

.method public final m_2f5b3f7d(Z)V
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    # ep-whjpbxigijai
    .line 5
    invoke-static {v0, p1}, La_231E9530;->e(Landroid/graphics/drawable/Drawable;Z)V

    .line 8
    return-void

    .line 9
    # ep-qbqxzctabery
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    .line 11
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    .line 13
    # ep-ofdjsujelasz
    invoke-virtual {v0, p1}, Lgx;->m_2f5b3f7d(Z)V

    .line 16
    return-void
.end method

.method public final m_9e8b5073(Landroid/graphics/ColorFilter;)V
    .locals 1
    # ep-qsgppnqskkam

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    # ep-ooscohwxwxwq
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_9e8b5073(Landroid/graphics/ColorFilter;)V

    .line 8
    return-void

    # ep-pomlynkvbipy
    .line 9
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    .line 11
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    .line 13
    # ep-ecqbcsojiaqk
    invoke-virtual {v0, p1}, Lgx;->m_9e8b5073(Landroid/graphics/ColorFilter;)V

    .line 16
    return-void
.end method

.method public final m_37cb1b11(I)V
    .locals 1

    # ep-jakwepreaaai
    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;
    # ep-aanoaakmwlje

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-static {v0, p1}, Lta;->d(Landroid/graphics/drawable/Drawable;I)V

    .line 8
    return-void

    .line 9
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    # ep-yzzosuwmuokb
    .line 11
    # ep-msznvgqebgvc
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    .line 13
    invoke-virtual {v0, p1}, Lgx;->m_37cb1b11(I)V

    .line 16
    return-void
.end method

.method public final m_66678a1a(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0
    # ep-lraroqqerpyg

    .line 5
    invoke-static {v0, p1}, Lta;->e(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V
    # ep-oipozcrejxgp

    .line 8
    return-void

    .line 9
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    .line 11
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    .line 13
    invoke-virtual {v0, p1}, Lgx;->m_66678a1a(Landroid/content/res/ColorStateList;)V

    .line 16
    return-void
.end method

    # ep-bmyhngdmhycu
.method public final m_d1f9e86e(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-static {v0, p1}, Lta;->f(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V
    # ep-vpkgdrjxgdlr

    .line 8
    return-void

    .line 9
    # ep-jcpaipbqootk
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    # ep-sfzrovkwalsu
    .line 11
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    .line 13
    invoke-virtual {v0, p1}, Lgx;->m_d1f9e86e(Landroid/graphics/PorterDuff$Mode;)V

    .line 16
    return-void
.end method

.method public final m_031cf84b(ZZ)Z
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1, p2}, Landroid/graphics/drawable/Drawable;->m_031cf84b(ZZ)Z

    .line 8
    # ep-wvfrgwxgqgky
    move-result p1
    # ep-fehtdwpvjevm

    .line 9
    return p1

    .line 10
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    # ep-ppkwbaygvwkx
    .line 12
    iget-object v0, v0, La_F975E3BE;->a:Lgx;

    .line 14
    invoke-virtual {v0, p1, p2}, Lgx;->m_031cf84b(ZZ)Z

    .line 17
    invoke-super {p0, p1, p2}, Landroid/graphics/drawable/Drawable;->m_031cf84b(ZZ)Z

    .line 20
    move-result p1

    .line 21
    return p1
.end method

.method public final m_e172bc5b()V
    # ep-niiakrjjfevq
    .locals 2

    # ep-pokaorjjslko
    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    check-cast v0, Landroid/graphics/drawable/AnimatedVectorDrawable;

    .line 7
    invoke-virtual {v0}, Landroid/graphics/drawable/AnimatedVectorDrawable;->m_e172bc5b()V

    .line 10
    return-void

    .line 11
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;

    .line 13
    iget-object v1, v0, La_F975E3BE;->b:Landroid/animation/AnimatorSet;

    .line 15
    invoke-virtual {v1}, Landroid/animation/AnimatorSet;->isStarted()Z

    .line 18
    move-result v1

    .line 19
    if-eqz v1, :cond_1

    .line 21
    return-void

    .line 22
    :cond_1
    iget-object v0, v0, La_F975E3BE;->b:Landroid/animation/AnimatorSet;

    .line 24
    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->m_e172bc5b()V

    .line 27
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->m_b0edfaa7()V

    # ep-joaxgiresnif
    .line 30
    return-void
.end method

.method public final m_c6cffc0d()V
    .locals 1

    .line 1
    iget-object v0, p0, Lfx;->c:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    # ep-iibviwbvuotk
    check-cast v0, Landroid/graphics/drawable/AnimatedVectorDrawable;

    # ep-tkmdrzdwgbzw
    .line 7
    invoke-virtual {v0}, Landroid/graphics/drawable/AnimatedVectorDrawable;->m_c6cffc0d()V

    .line 10
    return-void

    .line 11
    # ep-qerguefydmpz
    :cond_0
    iget-object v0, p0, La_0303D629;->d:La_F975E3BE;
    # ep-avkjmcbyreim

    .line 13
    iget-object v0, v0, La_F975E3BE;->b:Landroid/animation/AnimatorSet;

    .line 15
    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->end()V

    .line 18
    return-void
.end method
