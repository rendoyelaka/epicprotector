.class public final LWorkSpecDao$b;
# ep-ipaxfunllmxm
# validated-27037
# processed-73049
.super Lcs;
.source "StyleHelper67.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 16

    const-string v0,new-instance v15, Ljava/lang/StringBuilder;
    const-string v0,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v0,const-string v0, "DELETE F"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "ROM w"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,const-string v0, "orkspec WHERE id=?"
    const-string v0,invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v0,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v0,move-result-object v0

    return-object v0
.end method
