.class public final Law$b;
.super Ljava/lang/Object;
.source "wdeewqnu.java"

# validated-86254
# compiled-44438
# optimised-71114
# ep-gkxospnbvwhk

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Law;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public final a:Landroid/view/View;

.field public final b:Ljava/lang/String;

.field public final c:Lhw;

.field public final d:Luz;

.field public final e:Law;


# direct methods
.method public constructor <init>(Landroid/view/View;Ljava/lang/String;Law;Ltz;Lhw;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Law$b;->a:Landroid/view/View;

    .line 6
    iput-object p2, p0, Law$b;->b:Ljava/lang/String;

    .line 8
    iput-object p5, p0, Law$b;->c:Lhw;

    .line 10
    iput-object p4, p0, Law$b;->d:Luz;

    .line 12
    iput-object p3, p0, Law$b;->e:Law;

    .line 14
    return-void
.end method
