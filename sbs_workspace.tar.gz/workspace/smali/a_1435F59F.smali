.class public interface abstract La_1435F59F;
.super Ljava/lang/Object;
.source "ogwtqdtf.java"

# optimised-86019
# compiled-61356

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract b()La_E7306629;
.end method
