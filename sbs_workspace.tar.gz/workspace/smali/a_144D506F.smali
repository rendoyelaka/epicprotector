.class public final La_144D506F;
.super La_3FA508D5;
# verified-50460
# compiled-64318
# generated-84983
.source "kpjofxrp.java"


# static fields
.field public static final e:La_144D506F;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_144D506F;

    invoke-direct {v0}, La_144D506F;-><init>()V

    sput-object v0, La_144D506F;->e:La_144D506F;

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    .line 1
    sget v0, Lpu;->b:I

    .line 3
    sget v1, Lpu;->c:I

    .line 5
    sget-wide v2, Lpu;->d:J

    .line 7
    invoke-direct {p0, v0, v1, v2, v3}, La_3FA508D5;-><init>(IIJ)V

    .line 10
    return-void
.end method


# virtual methods
.method public final m_4bb68b61()V
    .locals 2
    # ep-ktjvrcuhnlat

    # ep-rldfajuttals
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v1, "Dispatchers.Default cannot be closed"

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    # ep-lgqerlzoknzf

    throw v0
.end method

    # ep-uaufaltfqsha
.method public final toString()Ljava/lang/String;
    # ep-ikryklzpvwea
    .locals 1

    const-string v0, "Dispatchers.Default"
    # ep-zdwnnemtiayb

    return-object v0
.end method
