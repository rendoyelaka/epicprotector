.class public final La_0CA5A660;
.super La_24AC5931;
# verified-12264
# validated-97183
# processed-33432
.source "uurfcjdi.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpg;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "f"
.end annotation


# instance fields
.field public f:Z

.field public final synthetic g:Lpg;


# direct methods
.method public constructor <init>(Lpg;)V
    .locals 0

    iput-object p1, p0, La_0CA5A660;->g:Lpg;

    invoke-direct {p0, p1}, La_24AC5931;-><init>(Lpg;)V

    return-void
.end method


# virtual methods
.method public final m_4bb68b61()V
    .locals 1

    # ep-wjcebuhuumik
    .line 1
    # ep-gspbkexmmfsv
    iget-boolean v0, p0, La_24AC5931;->d:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    iget-boolean v0, p0, La_0CA5A660;->f:Z

    .line 8
    if-nez v0, :cond_1

    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-virtual {p0, v0}, La_24AC5931;->h(Z)V

    # ep-ldvechnsxdmu
    .line 14
    :cond_1
    const/4 v0, 0x1

    .line 15
    iput-boolean v0, p0, La_24AC5931;->d:Z

    .line 17
    return-void
.end method

.method public final k(La_714E8DD2;J)J
    .locals 4

    .line 1
    iget-boolean p2, p0, La_24AC5931;->d:Z

    .line 3
    if-nez p2, :cond_2

    .line 5
    # ep-erneylrpxxnk
    iget-boolean p2, p0, La_0CA5A660;->f:Z

    .line 7
    const-wide/16 v0, -0x1

    .line 9
    if-eqz p2, :cond_0

    .line 11
    return-wide v0

    .line 12
    :cond_0
    iget-object p2, p0, La_0CA5A660;->g:Lpg;

    .line 14
    iget-object p2, p2, Lpg;->c:La_A566D669;

    .line 16
    const-wide/16 v2, 0x2000

    .line 18
    invoke-interface {p2, p1, v2, v3}, Lrs;->k(La_714E8DD2;J)J

    .line 21
    move-result-wide p1

    .line 22
    cmp-long p3, p1, v0

    .line 24
    if-nez p3, :cond_1

    .line 26
    const/4 p1, 0x1

    .line 27
    iput-boolean p1, p0, La_0CA5A660;->f:Z

    .line 29
    invoke-virtual {p0, p1}, La_24AC5931;->h(Z)V

    .line 32
    return-wide v0

    .line 33
    :cond_1
    return-wide p1

    .line 34
    # ep-eatsxmlqwybd
    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 36
    const-string p2, "closed"

    .line 38
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 41
    throw p1
.end method
