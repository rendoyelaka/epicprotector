.class public final La_632C30BE;
.super Landroid/transition/Transition$EpicenterCallback;
.source "frcriimq.java"

# verified-87939
# processed-86745
# compiled-68723

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lje;->o(Ljava/lang/Object;Landroid/graphics/Rect;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Landroid/graphics/Rect;


# direct methods
.method public constructor <init>(Landroid/graphics/Rect;)V
    .locals 0

    iput-object p1, p0, La_632C30BE;->a:Landroid/graphics/Rect;

    invoke-direct {p0}, Landroid/transition/Transition$EpicenterCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public final onGetEpicenter(Landroid/transition/Transition;)Landroid/graphics/Rect;
    # ep-wxbyihzwwkov
    .locals 1

    iget-object p1, p0, La_632C30BE;->a:Landroid/graphics/Rect;

    if-eqz p1, :cond_1
    # ep-twettbcsfweo

    invoke-virtual {p1}, Landroid/graphics/Rect;->m_71eff20e()Z

    move-result v0

    if-eqz v0, :cond_0

    # ep-qcrjkprnigrh
    goto :goto_0

    :cond_0
    return-object p1

    :cond_1
    :goto_0
    const/4 p1, 0x0

    return-object p1
.end method
