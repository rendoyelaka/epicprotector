.class public La_6F41FBA1;
.super La_A4B4F578;
.source "kurddcti.java"
# generated-46782
# processed-54012
# ep-ymoayrtlfduq


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "f"
.end annotation


# static fields
.field public static h:Z

.field public static i:Ljava/lang/reflect/Method;

.field public static j:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field public static k:Ljava/lang/reflect/Field;

.field public static l:Ljava/lang/reflect/Field;


# instance fields
.field public final c:Landroid/view/WindowInsets;

.field public d:[Lii;

.field public e:Lii;

.field public f:Lwz;

.field public g:Lii;


# direct methods
.method public constructor <init>(Lwz;Landroid/view/WindowInsets;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, La_A4B4F578;-><init>(Lwz;)V

    .line 4
    const/4 p1, 0x0

    .line 5
    iput-object p1, p0, La_6F41FBA1;->e:Lii;

    .line 7
    iput-object p2, p0, La_6F41FBA1;->c:Landroid/view/WindowInsets;

    .line 9
    return-void
.end method

.method private r(IZ)Lii;
    .locals 3
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "WrongConstant"
        }
    .end annotation

    .line 1
    sget-object v0, Lii;->e:Lii;

    .line 3
    const/4 v1, 0x1

    .line 4
    :goto_0
    const/16 v2, 0x100

    .line 6
    if-gt v1, v2, :cond_1

    .line 8
    and-int v2, p1, v1

    .line 10
    if-nez v2, :cond_0

    .line 12
    goto :goto_1

    .line 13
    :cond_0
    invoke-virtual {p0, v1, p2}, La_6F41FBA1;->s(IZ)Lii;

    .line 16
    move-result-object v2

    .line 17
    invoke-static {v0, v2}, Lii;->a(Lii;Lii;)Lii;

    .line 20
    move-result-object v0

    .line 21
    :goto_1
    shl-int/lit8 v1, v1, 0x1

    .line 23
    goto :goto_0

    .line 24
    :cond_1
    return-object v0
.end method

.method private t()Lii;
    .locals 1

    .line 1
    iget-object v0, p0, La_6F41FBA1;->f:Lwz;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, v0, Lwz;->a:La_A4B4F578;

    .line 7
    invoke-virtual {v0}, La_A4B4F578;->h()Lii;

    .line 10
    move-result-object v0

    .line 11
    return-object v0

    .line 12
    :cond_0
    sget-object v0, Lii;->e:Lii;

    .line 14
    return-object v0
.end method

.method private u(Landroid/view/View;)Lii;
    .locals 4

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1e

    .line 5
    if-ge v0, v1, :cond_5

    .line 7
    sget-boolean v0, La_6F41FBA1;->h:Z

    .line 9
    if-nez v0, :cond_0

    .line 11
    invoke-static {}, La_6F41FBA1;->v()V

    .line 14
    :cond_0
    sget-object v0, La_6F41FBA1;->i:Ljava/lang/reflect/Method;

    .line 16
    const/4 v1, 0x0

    .line 17
    if-eqz v0, :cond_4

    .line 19
    sget-object v2, La_6F41FBA1;->j:Ljava/lang/Class;

    .line 21
    if-eqz v2, :cond_4

    .line 23
    sget-object v2, La_6F41FBA1;->k:Ljava/lang/reflect/Field;

    .line 25
    if-nez v2, :cond_1

    .line 27
    goto :goto_0

    .line 28
    :cond_1
    const/4 v2, 0x0

    .line 29
    :try_start_0
    new-array v2, v2, [Ljava/lang/Object;

    .line 31
    invoke-virtual {v0, p1, v2}, Ljava/lang/reflect/Method;->m_fa56d4ad(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    move-result-object p1

    .line 35
    if-nez p1, :cond_2

    .line 37
    return-object v1

    .line 38
    :cond_2
    sget-object v0, La_6F41FBA1;->l:Ljava/lang/reflect/Field;

    .line 40
    invoke-virtual {v0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    move-result-object p1

    .line 44
    sget-object v0, La_6F41FBA1;->k:Ljava/lang/reflect/Field;

    .line 46
    invoke-virtual {v0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    move-result-object p1

    .line 50
    check-cast p1, Landroid/graphics/Rect;

    .line 52
    if-eqz p1, :cond_3

    .line 54
    iget v0, p1, Landroid/graphics/Rect;->left:I

    .line 56
    iget v2, p1, Landroid/graphics/Rect;->top:I

    .line 58
    iget v3, p1, Landroid/graphics/Rect;->right:I

    .line 60
    iget p1, p1, Landroid/graphics/Rect;->bottom:I

    .line 62
    invoke-static {v0, v2, v3, p1}, Lii;->b(IIII)Lii;

    .line 65
    move-result-object v1
    :try_end_0
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_0 .. :try_end_0} :catch_0

    .line 66
    :cond_3
    return-object v1

    .line 67
    :catch_0
    move-exception p1

    .line 68
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 71
    :cond_4
    :goto_0
    return-object v1

    .line 72
    :cond_5
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 74
    const-string v0, "getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead."

    .line 76
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 79
    throw p1
.end method

.method private static v()V
    .locals 4
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "PrivateApi"
        }
    .end annotation

    .line 1
    const/4 v0, 0x1

    .line 2
    :try_start_0
    const-class v1, Landroid/view/View;

    .line 4
    const-string v2, "getViewRootImpl"

    .line 6
    const/4 v3, 0x0

    .line 7
    new-array v3, v3, [Ljava/lang/Class;

    .line 9
    invoke-virtual {v1, v2, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 12
    move-result-object v1

    .line 13
    sput-object v1, La_6F41FBA1;->i:Ljava/lang/reflect/Method;

    .line 15
    const-string v1, "android.view.View$AttachInfo"

    .line 17
    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 20
    move-result-object v1

    .line 21
    sput-object v1, La_6F41FBA1;->j:Ljava/lang/Class;

    .line 23
    const-string v2, "mVisibleInsets"

    .line 25
    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 28
    move-result-object v1

    .line 29
    sput-object v1, La_6F41FBA1;->k:Ljava/lang/reflect/Field;

    .line 31
    const-string v1, "android.view.ViewRootImpl"

    .line 33
    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 36
    move-result-object v1

    .line 37
    const-string v2, "mAttachInfo"

    .line 39
    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 42
    move-result-object v1

    .line 43
    sput-object v1, La_6F41FBA1;->l:Ljava/lang/reflect/Field;

    .line 45
    sget-object v1, La_6F41FBA1;->k:Ljava/lang/reflect/Field;

    .line 47
    invoke-virtual {v1, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 50
    sget-object v1, La_6F41FBA1;->l:Ljava/lang/reflect/Field;

    .line 52
    invoke-virtual {v1, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_0
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_0 .. :try_end_0} :catch_0

    .line 55
    goto :goto_0

    .line 56
    :catch_0
    move-exception v1

    .line 57
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 60
    :goto_0
    sput-boolean v0, La_6F41FBA1;->h:Z

    .line 62
    return-void
.end method


# virtual methods
.method public d(Landroid/view/View;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, La_6F41FBA1;->u(Landroid/view/View;)Lii;

    .line 4
    move-result-object p1

    .line 5
    if-nez p1, :cond_0

    .line 7
    sget-object p1, Lii;->e:Lii;

    .line 9
    :cond_0
    invoke-virtual {p0, p1}, La_6F41FBA1;->w(Lii;)V

    .line 12
    return-void
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    invoke-super {p0, p1}, La_A4B4F578;->equals(Ljava/lang/Object;)Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_0

    .line 7
    const/4 p1, 0x0

    .line 8
    return p1

    .line 9
    :cond_0
    check-cast p1, La_6F41FBA1;

    .line 11
    iget-object v0, p0, La_6F41FBA1;->g:Lii;

    .line 13
    iget-object p1, p1, La_6F41FBA1;->g:Lii;

    .line 15
    invoke-static {v0, p1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    move-result p1

    .line 19
    return p1
.end method

.method public f(I)Lii;
    .locals 1

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, La_6F41FBA1;->r(IZ)Lii;

    move-result-object p1

    return-object p1
.end method

.method public final j()Lii;
    .locals 4

    .line 1
    iget-object v0, p0, La_6F41FBA1;->e:Lii;

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, La_6F41FBA1;->c:Landroid/view/WindowInsets;

    .line 7
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getSystemWindowInsetLeft()I

    .line 10
    move-result v1

    .line 11
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getSystemWindowInsetTop()I

    .line 14
    move-result v2

    .line 15
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getSystemWindowInsetRight()I

    .line 18
    move-result v3

    .line 19
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getSystemWindowInsetBottom()I

    .line 22
    move-result v0

    .line 23
    invoke-static {v1, v2, v3, v0}, Lii;->b(IIII)Lii;

    .line 26
    move-result-object v0

    .line 27
    iput-object v0, p0, La_6F41FBA1;->e:Lii;

    .line 29
    :cond_0
    iget-object v0, p0, La_6F41FBA1;->e:Lii;

    .line 31
    return-object v0
.end method

.method public l(IIII)Lwz;
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, La_6F41FBA1;->c:Landroid/view/WindowInsets;

    .line 4
    invoke-static {v0, v1}, Lwz;->h(Landroid/view/View;Landroid/view/WindowInsets;)Lwz;

    .line 7
    move-result-object v0

    .line 8
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 10
    const/16 v2, 0x1e

    .line 12
    if-lt v1, v2, :cond_0

    .line 14
    new-instance v1, La_5177E135;

    .line 16
    invoke-direct {v1, v0}, La_5177E135;-><init>(Lwz;)V

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/16 v2, 0x1d

    .line 22
    if-lt v1, v2, :cond_1

    .line 24
    new-instance v1, La_3454C529;

    .line 26
    invoke-direct {v1, v0}, La_3454C529;-><init>(Lwz;)V

    .line 29
    goto :goto_0

    .line 30
    :cond_1
    new-instance v1, La_7DC107E4;

    .line 32
    invoke-direct {v1, v0}, La_7DC107E4;-><init>(Lwz;)V

    .line 35
    :goto_0
    invoke-virtual {p0}, La_6F41FBA1;->j()Lii;

    .line 38
    move-result-object v0

    .line 39
    invoke-static {v0, p1, p2, p3, p4}, Lwz;->f(Lii;IIII)Lii;

    .line 42
    move-result-object v0

    .line 43
    invoke-virtual {v1, v0}, La_B567B431;->g(Lii;)V

    .line 46
    invoke-virtual {p0}, La_A4B4F578;->h()Lii;

    .line 49
    move-result-object v0

    .line 50
    invoke-static {v0, p1, p2, p3, p4}, Lwz;->f(Lii;IIII)Lii;

    .line 53
    move-result-object p1

    .line 54
    invoke-virtual {v1, p1}, La_B567B431;->e(Lii;)V

    .line 57
    invoke-virtual {v1}, La_B567B431;->b()Lwz;

    .line 60
    move-result-object p1

    .line 61
    return-object p1
.end method

.method public n()Z
    .locals 1

    iget-object v0, p0, La_6F41FBA1;->c:Landroid/view/WindowInsets;

    invoke-virtual {v0}, Landroid/view/WindowInsets;->isRound()Z

    move-result v0

    return v0
.end method

.method public o([Lii;)V
    .locals 0

    iput-object p1, p0, La_6F41FBA1;->d:[Lii;

    return-void
.end method

.method public p(Lwz;)V
    .locals 0

    iput-object p1, p0, La_6F41FBA1;->f:Lwz;

    return-void
.end method

.method public s(IZ)Lii;
    .locals 5

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    if-eq p1, v0, :cond_13

    .line 5
    const/4 v0, 0x2

    .line 6
    const/4 v2, 0x0

    .line 7
    if-eq p1, v0, :cond_f

    .line 9
    sget-object p2, Lii;->e:Lii;

    .line 11
    const/16 v0, 0x8

    .line 13
    if-eq p1, v0, :cond_a

    .line 15
    const/16 v0, 0x10

    .line 17
    if-eq p1, v0, :cond_9

    .line 19
    const/16 v0, 0x20

    .line 21
    if-eq p1, v0, :cond_8

    .line 23
    const/16 v0, 0x40

    .line 25
    if-eq p1, v0, :cond_7

    .line 27
    const/16 v0, 0x80

    .line 29
    if-eq p1, v0, :cond_0

    .line 31
    return-object p2

    .line 32
    :cond_0
    iget-object p1, p0, La_6F41FBA1;->f:Lwz;

    .line 34
    if-eqz p1, :cond_1

    .line 36
    iget-object p1, p1, Lwz;->a:La_A4B4F578;

    .line 38
    invoke-virtual {p1}, La_A4B4F578;->e()Lpa;

    .line 41
    move-result-object p1

    .line 42
    goto :goto_0

    .line 43
    :cond_1
    invoke-virtual {p0}, La_A4B4F578;->e()Lpa;

    .line 46
    move-result-object p1

    .line 47
    :goto_0
    if-eqz p1, :cond_6

    .line 49
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 51
    const/16 v0, 0x1c

    .line 53
    iget-object p1, p1, Lpa;->a:Landroid/view/DisplayCutout;

    .line 55
    if-lt p2, v0, :cond_2

    .line 57
    invoke-static {p1}, La_C5F5DC06;->d(Landroid/view/DisplayCutout;)I

    .line 60
    move-result v2

    .line 61
    goto :goto_1

    .line 62
    :cond_2
    const/4 v2, 0x0

    .line 63
    :goto_1
    if-lt p2, v0, :cond_3

    .line 65
    invoke-static {p1}, La_C5F5DC06;->f(Landroid/view/DisplayCutout;)I

    .line 68
    move-result v3

    .line 69
    goto :goto_2

    .line 70
    :cond_3
    const/4 v3, 0x0

    .line 71
    :goto_2
    if-lt p2, v0, :cond_4

    .line 73
    invoke-static {p1}, La_C5F5DC06;->e(Landroid/view/DisplayCutout;)I

    .line 76
    move-result v4

    .line 77
    goto :goto_3

    .line 78
    :cond_4
    const/4 v4, 0x0

    .line 79
    :goto_3
    if-lt p2, v0, :cond_5

    .line 81
    invoke-static {p1}, La_C5F5DC06;->c(Landroid/view/DisplayCutout;)I

    .line 84
    move-result v1

    .line 85
    :cond_5
    invoke-static {v2, v3, v4, v1}, Lii;->b(IIII)Lii;

    .line 88
    move-result-object p1

    .line 89
    return-object p1

    .line 90
    :cond_6
    return-object p2

    .line 91
    :cond_7
    invoke-virtual {p0}, La_A4B4F578;->k()Lii;

    .line 94
    move-result-object p1

    .line 95
    return-object p1

    .line 96
    :cond_8
    invoke-virtual {p0}, La_A4B4F578;->g()Lii;

    .line 99
    move-result-object p1

    .line 100
    return-object p1

    .line 101
    :cond_9
    invoke-virtual {p0}, La_A4B4F578;->i()Lii;

    .line 104
    move-result-object p1

    .line 105
    return-object p1

    .line 106
    :cond_a
    iget-object p1, p0, La_6F41FBA1;->d:[Lii;

    .line 108
    if-eqz p1, :cond_b

    .line 110
    invoke-static {v0}, La_C8854E85;->a(I)I

    .line 113
    move-result v0

    .line 114
    aget-object v2, p1, v0

    .line 116
    :cond_b
    if-eqz v2, :cond_c

    .line 118
    return-object v2

    .line 119
    :cond_c
    invoke-virtual {p0}, La_6F41FBA1;->j()Lii;

    .line 122
    move-result-object p1

    .line 123
    invoke-direct {p0}, La_6F41FBA1;->t()Lii;

    .line 126
    move-result-object v0

    .line 127
    iget p1, p1, Lii;->d:I

    .line 129
    iget v2, v0, Lii;->d:I

    .line 131
    if-le p1, v2, :cond_d

    .line 133
    invoke-static {v1, v1, v1, p1}, Lii;->b(IIII)Lii;

    .line 136
    move-result-object p1

    .line 137
    return-object p1

    .line 138
    :cond_d
    iget-object p1, p0, La_6F41FBA1;->g:Lii;

    .line 140
    if-eqz p1, :cond_e

    .line 142
    invoke-virtual {p1, p2}, Lii;->equals(Ljava/lang/Object;)Z

    .line 145
    move-result p1

    .line 146
    if-nez p1, :cond_e

    .line 148
    iget-object p1, p0, La_6F41FBA1;->g:Lii;

    .line 150
    iget p1, p1, Lii;->d:I

    .line 152
    iget v0, v0, Lii;->d:I

    .line 154
    if-le p1, v0, :cond_e

    .line 156
    invoke-static {v1, v1, v1, p1}, Lii;->b(IIII)Lii;

    .line 159
    move-result-object p1

    .line 160
    return-object p1

    .line 161
    :cond_e
    return-object p2

    .line 162
    :cond_f
    if-eqz p2, :cond_10

    .line 164
    invoke-direct {p0}, La_6F41FBA1;->t()Lii;

    .line 167
    move-result-object p1

    .line 168
    invoke-virtual {p0}, La_A4B4F578;->h()Lii;

    .line 171
    move-result-object p2

    .line 172
    iget v0, p1, Lii;->a:I

    .line 174
    iget v2, p2, Lii;->a:I

    .line 176
    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    .line 179
    move-result v0

    .line 180
    iget v2, p1, Lii;->c:I

    .line 182
    iget v3, p2, Lii;->c:I

    .line 184
    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    .line 187
    move-result v2

    .line 188
    iget p1, p1, Lii;->d:I

    .line 190
    iget p2, p2, Lii;->d:I

    .line 192
    invoke-static {p1, p2}, Ljava/lang/Math;->max(II)I

    .line 195
    move-result p1

    .line 196
    invoke-static {v0, v1, v2, p1}, Lii;->b(IIII)Lii;

    .line 199
    move-result-object p1

    .line 200
    return-object p1

    .line 201
    :cond_10
    invoke-virtual {p0}, La_6F41FBA1;->j()Lii;

    .line 204
    move-result-object p1

    .line 205
    iget-object p2, p0, La_6F41FBA1;->f:Lwz;

    .line 207
    if-eqz p2, :cond_11

    .line 209
    iget-object p2, p2, Lwz;->a:La_A4B4F578;

    .line 211
    invoke-virtual {p2}, La_A4B4F578;->h()Lii;

    .line 214
    move-result-object v2

    .line 215
    :cond_11
    iget p2, p1, Lii;->d:I

    .line 217
    if-eqz v2, :cond_12

    .line 219
    iget v0, v2, Lii;->d:I

    .line 221
    invoke-static {p2, v0}, Ljava/lang/Math;->min(II)I

    .line 224
    move-result p2

    .line 225
    :cond_12
    iget v0, p1, Lii;->a:I

    .line 227
    iget p1, p1, Lii;->c:I

    .line 229
    invoke-static {v0, v1, p1, p2}, Lii;->b(IIII)Lii;

    .line 232
    move-result-object p1

    .line 233
    return-object p1

    .line 234
    :cond_13
    if-eqz p2, :cond_14

    .line 236
    invoke-direct {p0}, La_6F41FBA1;->t()Lii;

    .line 239
    move-result-object p1

    .line 240
    iget p1, p1, Lii;->b:I

    .line 242
    invoke-virtual {p0}, La_6F41FBA1;->j()Lii;

    .line 245
    move-result-object p2

    .line 246
    iget p2, p2, Lii;->b:I

    .line 248
    invoke-static {p1, p2}, Ljava/lang/Math;->max(II)I

    .line 251
    move-result p1

    .line 252
    invoke-static {v1, p1, v1, v1}, Lii;->b(IIII)Lii;

    .line 255
    move-result-object p1

    .line 256
    return-object p1

    .line 257
    :cond_14
    invoke-virtual {p0}, La_6F41FBA1;->j()Lii;

    .line 260
    move-result-object p1

    .line 261
    iget p1, p1, Lii;->b:I

    .line 263
    invoke-static {v1, p1, v1, v1}, Lii;->b(IIII)Lii;

    .line 266
    move-result-object p1

    .line 267
    return-object p1
.end method

.method public w(Lii;)V
    .locals 0

    iput-object p1, p0, La_6F41FBA1;->g:Lii;

    return-void
.end method
