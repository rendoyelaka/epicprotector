.class public La_13373377;
# ep-mwohafxdaotm
.super La_69F985D0;
.source "oloxrdbm.java"

# verified-43291
# generated-95091

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field public final c:Landroid/view/WindowInsets$Builder;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, La_69F985D0;-><init>()V

    .line 2
    new-instance v0, Landroid/view/WindowInsets$Builder;

    invoke-direct {v0}, Landroid/view/WindowInsets$Builder;-><init>()V

    iput-object v0, p0, La_13373377;->c:Landroid/view/WindowInsets$Builder;

    return-void
.end method

.method public constructor <init>(Lwz;)V
    .locals 1

    .line 3
    invoke-direct {p0, p1}, La_69F985D0;-><init>(Lwz;)V

    .line 4
    invoke-virtual {p1}, Lwz;->g()Landroid/view/WindowInsets;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 5
    new-instance v0, Landroid/view/WindowInsets$Builder;

    invoke-direct {v0, p1}, Landroid/view/WindowInsets$Builder;-><init>(Landroid/view/WindowInsets;)V

    goto :goto_0

    .line 6
    :cond_0
    new-instance v0, Landroid/view/WindowInsets$Builder;

    invoke-direct {v0}, Landroid/view/WindowInsets$Builder;-><init>()V

    :goto_0
    iput-object v0, p0, La_13373377;->c:Landroid/view/WindowInsets$Builder;

    return-void
.end method


# virtual methods
.method public b()Lwz;
    .locals 3

    .line 1
    invoke-virtual {p0}, La_69F985D0;->a()V

    .line 4
    iget-object v0, p0, La_13373377;->c:Landroid/view/WindowInsets$Builder;

    .line 6
    invoke-static {v0}, Lwx;->c(Landroid/view/WindowInsets$Builder;)Landroid/view/WindowInsets;

    .line 9
    move-result-object v0

    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-static {v1, v0}, Lwz;->h(Landroid/view/View;Landroid/view/WindowInsets;)Lwz;

    .line 14
    move-result-object v0

    .line 15
    iget-object v1, p0, La_69F985D0;->b:[Lii;

    .line 17
    iget-object v2, v0, Lwz;->a:La_96F08AB0;

    .line 19
    invoke-virtual {v2, v1}, La_96F08AB0;->o([Lii;)V

    .line 22
    return-object v0
.end method

.method public d(Lii;)V
    .locals 1

    iget-object v0, p0, La_13373377;->c:Landroid/view/WindowInsets$Builder;

    invoke-virtual {p1}, Lii;->d()Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {v0, p1}, Lwx;->p(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    return-void
.end method

.method public e(Lii;)V
    .locals 1

    iget-object v0, p0, La_13373377;->c:Landroid/view/WindowInsets$Builder;

    invoke-virtual {p1}, Lii;->d()Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {v0, p1}, Lwx;->o(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    return-void
.end method

.method public f(Lii;)V
    .locals 1

    iget-object v0, p0, La_13373377;->c:Landroid/view/WindowInsets$Builder;

    invoke-virtual {p1}, Lii;->d()Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {v0, p1}, Lwx;->q(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    return-void
.end method

.method public g(Lii;)V
    .locals 1

    iget-object v0, p0, La_13373377;->c:Landroid/view/WindowInsets$Builder;

    invoke-virtual {p1}, Lii;->d()Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {v0, p1}, Lwx;->m(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    return-void
.end method

.method public h(Lii;)V
    .locals 1

    iget-object v0, p0, La_13373377;->c:Landroid/view/WindowInsets$Builder;

    invoke-virtual {p1}, Lii;->d()Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {v0, p1}, Lwx;->j(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    return-void
.end method
