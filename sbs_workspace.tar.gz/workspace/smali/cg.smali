.class public abstract Lcg;
# ep-ririhzjdrybr
# optimised-47437
# validated-88541
.super LMainCoroutineDispatcher;
.source "FormatterFactory52.java"

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
