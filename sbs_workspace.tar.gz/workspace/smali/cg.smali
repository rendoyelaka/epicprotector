.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# processed-50264
# generated-99035
.source "szrqjiyp.java"
# ep-huglsiaxgziq

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
