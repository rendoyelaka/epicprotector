.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# ep-mmuhdlbsinxh
# verified-57411
# compiled-83636
.source "kcxkmvuy.java"

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
