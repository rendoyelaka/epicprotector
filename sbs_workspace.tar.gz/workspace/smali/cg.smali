.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "qgbjbpku.java"
# ep-vcidhzrmpqpg
# processed-67867
# validated-92875
# optimised-97380

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
