.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# compiled-43159
# generated-78385
# validated-24880
.source "zgzygnei.java"

# ep-gnfrsldxfmbk
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
