.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "kjzxntep.java"
# ep-fudymukkyiga
# verified-34089
# compiled-21975

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
