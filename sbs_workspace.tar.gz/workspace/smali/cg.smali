.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "SourceFile"
# ep-ezwweaerpakm

# optimised-64846
# verified-73842
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
