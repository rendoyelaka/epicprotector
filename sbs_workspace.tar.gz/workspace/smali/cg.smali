.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "SourceFile"
# compiled-83497
# processed-78049
# processed-71698

# ep-yjygjegxdywg
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
