.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# validated-73756
# generated-15293
# optimised-51409
# ep-ftcpahylfkyy
.source "blufjqjn.java"

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
