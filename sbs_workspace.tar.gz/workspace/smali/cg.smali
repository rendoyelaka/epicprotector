.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "zatxjdyi.java"
# ep-auycfbaqnnnj
# compiled-93357
# validated-60476
# generated-46922

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
