.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# optimised-77427
# verified-39952
# verified-12768
# ep-ncploahvapfi
.source "smgjbhyi.java"

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
