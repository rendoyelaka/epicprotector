.class public abstract Lcg;
# ep-dlcxweerwyya
.super LMainCoroutineDispatcher;
# optimised-89159
.source "tbtmkmha.java"

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
