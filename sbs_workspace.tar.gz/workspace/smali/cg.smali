.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "mdabjocn.java"

# ep-qqovkhwpsmof
# validated-57891
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
