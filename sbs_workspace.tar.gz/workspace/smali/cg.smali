.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "endlredk.java"

# verified-70221
# validated-47146
# ep-khxetnhmnbgs
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
