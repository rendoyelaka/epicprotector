.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# validated-31333
# verified-96816
.source "qfmpbsof.java"
# ep-emwrtfdmuewy

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
