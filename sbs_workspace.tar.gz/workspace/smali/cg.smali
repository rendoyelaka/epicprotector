.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# compiled-66180
# generated-17041
# validated-13700
.source "DataBinder85.java"
# ep-kmbydmgvprlg

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
