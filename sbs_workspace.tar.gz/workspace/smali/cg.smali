.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# ep-ezyqdoyosezh
.source "vvoehzog.java"

# validated-58331
# compiled-93091
# optimised-91380
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
