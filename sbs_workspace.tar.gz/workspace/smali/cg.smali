.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# ep-bozdeacfqgye
# generated-67747
# generated-69565
# generated-66892
.source "SourceFile"

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
