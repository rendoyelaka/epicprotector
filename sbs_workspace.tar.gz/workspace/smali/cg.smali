.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# processed-30616
# verified-79778
.source "jrnaahvi.java"
# ep-rghmsadegswb

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
