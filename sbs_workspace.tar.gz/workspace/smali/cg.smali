.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# verified-26504
# processed-69314
# compiled-63574
.source "iucomxfy.java"
# ep-orieewqqkmop

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
