.class public abstract Lcg;
# ep-hnrywodvemwj
.super LMainCoroutineDispatcher;
# optimised-79205
# optimised-34517
# compiled-29675
.source "srmmqsdn.java"

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
