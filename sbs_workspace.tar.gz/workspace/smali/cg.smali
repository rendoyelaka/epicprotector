.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "dkxlcxam.java"
# validated-23164
# compiled-66788
# optimised-12745
# ep-ifgmmihpalzz

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
