.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# ep-dtslokzruwtq
.source "DataMapper85.java"

# verified-84593
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
