.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "TimerManager38.java"
# validated-24215
# ep-fwpydgosoind

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
