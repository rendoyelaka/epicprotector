.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "RequestManager53.java"

# optimised-31926
# ep-ildgcjaafqnv
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
