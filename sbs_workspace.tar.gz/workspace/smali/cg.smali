.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# ep-tlfzsoohyuhb
# processed-56016
# validated-15837
# optimised-41489
.source "hmadekwb.java"

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
