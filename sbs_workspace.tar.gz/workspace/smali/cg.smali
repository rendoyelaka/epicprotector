.class public abstract Lcg;
# ep-dqgyodrobklz
.super LMainCoroutineDispatcher;
# verified-89606
# processed-10274
.source "ptgyevri.java"

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
