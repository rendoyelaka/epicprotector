.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "SourceFile"
# generated-28369
# validated-54634
# validated-79194

# ep-uqrwiuatwuzp
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
