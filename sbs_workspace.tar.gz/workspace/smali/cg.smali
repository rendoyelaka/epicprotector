.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "mgkquiez.java"

# processed-97457
# verified-61770
# verified-61658
# ep-ldkhnfdfnkqf
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
