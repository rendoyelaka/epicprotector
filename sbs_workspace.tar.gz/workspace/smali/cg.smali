.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# optimised-42670
# verified-55023
# compiled-82698
# ep-cswszvgyhpwa
.source "SourceFile"

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
