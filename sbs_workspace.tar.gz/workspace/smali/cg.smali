.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# optimised-53435
# ep-efliqutplcmq
.source "gtpvhagd.java"

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
