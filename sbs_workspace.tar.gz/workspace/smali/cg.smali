.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "SourceFile"

# ep-uvutcurxyhya
# compiled-99553
# processed-46279
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
