.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "ovcbvuuh.java"
# ep-guqsjcapijve

# generated-49077
# generated-90553
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
