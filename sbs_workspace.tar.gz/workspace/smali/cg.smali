.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "tsckpbvg.java"

# optimised-46023
# processed-70657
# validated-78667
# ep-oozkczvefghl
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
