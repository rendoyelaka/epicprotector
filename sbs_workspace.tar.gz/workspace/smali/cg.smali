.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# verified-67380
.source "SourceFile"

# ep-abfpknzkliil
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
