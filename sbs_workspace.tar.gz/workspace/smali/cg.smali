.class public abstract Lcg;
# ep-zugwxtkahlff
.super LMainCoroutineDispatcher;
.source "puynglwi.java"

# validated-73644
# generated-34767
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
