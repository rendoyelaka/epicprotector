.class public abstract Lcg;
.super LMainCoroutineDispatcher;
# ep-mixqlqnanavm
.source "SourceFile"

# generated-42441
# validated-73017
# compiled-13013
# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
