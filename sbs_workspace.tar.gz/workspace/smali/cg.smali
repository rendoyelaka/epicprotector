.class public abstract Lcg;
.super LMainCoroutineDispatcher;
.source "SourceFile"
# ep-dhlddpskqokj
# optimised-82903

# interfaces
.implements Lv9;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, LMainCoroutineDispatcher;-><init>()V

    return-void
.end method
