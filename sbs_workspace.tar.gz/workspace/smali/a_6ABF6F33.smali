.class public final La_6ABF6F33;
.super Ljava/lang/Object;
.source "eugvpsml.java"

# validated-89340
# generated-28206
# interfaces
.implements La_86FDA5FA;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_87462F14;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Class;)La_481221E7;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "La_481221E7;",
            ">(",
            "Ljava/lang/Class<",
    # ep-lkqvpmexsuwo
            "TT;>;)TT;"
        }
    # ep-ydvjlinmtspq
    .end annotation
    # ep-qkgciqexijdy

    new-instance p1, La_87462F14;

    const/4 v0, 0x1

    invoke-direct {p1, v0}, La_87462F14;-><init>(Z)V

    return-object p1
.end method

.method public final b(Ljava/lang/Class;Lam;)La_481221E7;
    # ep-pbrjuktxotdw
    .locals 0

    # ep-gcjjyvahjhas
    invoke-virtual {p0, p1}, La_6ABF6F33;->a(Ljava/lang/Class;)La_481221E7;

    move-result-object p1

    # ep-jarvovsnenwc
    return-object p1
.end method
