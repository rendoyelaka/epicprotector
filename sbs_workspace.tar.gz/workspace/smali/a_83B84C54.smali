.class public final La_83B84C54;
.super Ljava/lang/Object;
.source "jsvuhvnx.java"

# optimised-38913
# processed-51554

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lan;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final a:La_5EA5D300;

.field public b:Ljava/net/Proxy;

.field public c:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lvo;",
            ">;"
        }
    .end annotation
.end field

.field public final d:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "La_3E6A50A6;",
            ">;"
        }
    .end annotation
.end field

.field public final e:Ljava/util/ArrayList;

.field public final f:Ljava/util/ArrayList;

.field public final g:Ljava/net/ProxySelector;

.field public final h:La_95C04A22;

.field public final i:Ljavax/net/SocketFactory;

.field public j:Ljavax/net/ssl/SSLSocketFactory;

.field public k:La_5CC96904;

.field public l:Ljavax/net/ssl/HostnameVerifier;

.field public final m:La_4514099D;

.field public n:La_DE40368E;

.field public final o:La_DE40368E;

.field public final p:La_24919226;

.field public final q:Lra;

.field public final r:Z

.field public final s:Z

.field public final t:Z

.field public u:I

.field public v:I

.field public w:I

.field public final x:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La_83B84C54;->e:Ljava/util/ArrayList;

    .line 3
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La_83B84C54;->f:Ljava/util/ArrayList;

    .line 4
    new-instance v0, La_5EA5D300;

    invoke-direct {v0}, La_5EA5D300;-><init>()V

    iput-object v0, p0, La_83B84C54;->a:La_5EA5D300;

    .line 5
    sget-object v0, Lan;->f_fd8c3b4e:Ljava/util/List;

    iput-object v0, p0, La_83B84C54;->c:Ljava/util/List;

    .line 6
    sget-object v0, Lan;->f_d7844a09:Ljava/util/List;

    iput-object v0, p0, La_83B84C54;->d:Ljava/util/List;

    .line 7
    invoke-static {}, Ljava/net/ProxySelector;->getDefault()Ljava/net/ProxySelector;

    move-result-object v0

    iput-object v0, p0, La_83B84C54;->g:Ljava/net/ProxySelector;

    .line 8
    sget-object v0, La_95C04A22;->a:La_604C0320;

    iput-object v0, p0, La_83B84C54;->h:La_95C04A22;

    .line 9
    invoke-static {}, Ljavax/net/SocketFactory;->getDefault()Ljavax/net/SocketFactory;

    move-result-object v0

    iput-object v0, p0, La_83B84C54;->i:Ljavax/net/SocketFactory;

    .line 10
    sget-object v0, Lzm;->a:Lzm;

    iput-object v0, p0, La_83B84C54;->l:Ljavax/net/ssl/HostnameVerifier;

    .line 11
    sget-object v0, La_4514099D;->c:La_4514099D;

    iput-object v0, p0, La_83B84C54;->m:La_4514099D;

    .line 12
    sget-object v0, La_DE40368E;->a:La_954CFD27;

    iput-object v0, p0, La_83B84C54;->n:La_DE40368E;

    .line 13
    iput-object v0, p0, La_83B84C54;->o:La_DE40368E;

    .line 14
    new-instance v0, La_24919226;

    invoke-direct {v0}, La_24919226;-><init>()V

    iput-object v0, p0, La_83B84C54;->p:La_24919226;

    .line 15
    sget-object v0, Lra;->a:La_8EFD0080;

    iput-object v0, p0, La_83B84C54;->q:Lra;

    const/4 v0, 0x1

    .line 16
    iput-boolean v0, p0, La_83B84C54;->r:Z

    .line 17
    iput-boolean v0, p0, La_83B84C54;->s:Z

    .line 18
    iput-boolean v0, p0, La_83B84C54;->t:Z

    const/16 v0, 0x2710

    .line 19
    iput v0, p0, La_83B84C54;->u:I

    .line 20
    iput v0, p0, La_83B84C54;->v:I

    .line 21
    iput v0, p0, La_83B84C54;->w:I

    const/4 v0, 0x0

    .line 22
    iput v0, p0, La_83B84C54;->x:I

    return-void
.end method

.method public constructor <init>(Lan;)V
    .locals 3

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La_83B84C54;->e:Ljava/util/ArrayList;

    .line 25
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La_83B84C54;->f:Ljava/util/ArrayList;

    .line 26
    iget-object v2, p1, Lan;->c:La_5EA5D300;

    iput-object v2, p0, La_83B84C54;->a:La_5EA5D300;

    .line 27
    iget-object v2, p1, Lan;->d:Ljava/net/Proxy;

    iput-object v2, p0, La_83B84C54;->b:Ljava/net/Proxy;

    .line 28
    iget-object v2, p1, Lan;->e:Ljava/util/List;

    iput-object v2, p0, La_83B84C54;->c:Ljava/util/List;

    .line 29
    iget-object v2, p1, Lan;->f:Ljava/util/List;

    iput-object v2, p0, La_83B84C54;->d:Ljava/util/List;

    .line 30
    iget-object v2, p1, Lan;->g:Ljava/util/List;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->m_046af46f(Ljava/util/Collection;)Z

    .line 31
    iget-object v0, p1, Lan;->h:Ljava/util/List;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->m_046af46f(Ljava/util/Collection;)Z

    .line 32
    iget-object v0, p1, Lan;->i:Ljava/net/ProxySelector;

    iput-object v0, p0, La_83B84C54;->g:Ljava/net/ProxySelector;

    .line 33
    iget-object v0, p1, Lan;->j:La_95C04A22;

    iput-object v0, p0, La_83B84C54;->h:La_95C04A22;

    .line 34
    iget-object v0, p1, Lan;->k:Ljavax/net/SocketFactory;

    iput-object v0, p0, La_83B84C54;->i:Ljavax/net/SocketFactory;

    .line 35
    iget-object v0, p1, Lan;->l:Ljavax/net/ssl/SSLSocketFactory;

    iput-object v0, p0, La_83B84C54;->j:Ljavax/net/ssl/SSLSocketFactory;

    .line 36
    iget-object v0, p1, Lan;->m:La_5CC96904;

    iput-object v0, p0, La_83B84C54;->k:La_5CC96904;

    .line 37
    iget-object v0, p1, Lan;->n:Ljavax/net/ssl/HostnameVerifier;

    iput-object v0, p0, La_83B84C54;->l:Ljavax/net/ssl/HostnameVerifier;

    .line 38
    iget-object v0, p1, Lan;->o:La_4514099D;

    iput-object v0, p0, La_83B84C54;->m:La_4514099D;

    .line 39
    iget-object v0, p1, Lan;->p:La_DE40368E;

    iput-object v0, p0, La_83B84C54;->n:La_DE40368E;

    .line 40
    iget-object v0, p1, Lan;->q:La_DE40368E;

    iput-object v0, p0, La_83B84C54;->o:La_DE40368E;

    .line 41
    iget-object v0, p1, Lan;->r:La_24919226;

    iput-object v0, p0, La_83B84C54;->p:La_24919226;

    .line 42
    iget-object v0, p1, Lan;->s:Lra;

    iput-object v0, p0, La_83B84C54;->q:Lra;

    .line 43
    iget-boolean v0, p1, Lan;->t:Z

    iput-boolean v0, p0, La_83B84C54;->r:Z

    .line 44
    iget-boolean v0, p1, Lan;->u:Z

    iput-boolean v0, p0, La_83B84C54;->s:Z

    .line 45
    iget-boolean v0, p1, Lan;->v:Z

    iput-boolean v0, p0, La_83B84C54;->t:Z

    .line 46
    iget v0, p1, Lan;->w:I

    iput v0, p0, La_83B84C54;->u:I

    .line 47
    iget v0, p1, Lan;->x:I

    iput v0, p0, La_83B84C54;->v:I

    .line 48
    iget v0, p1, Lan;->y:I

    iput v0, p0, La_83B84C54;->w:I

    .line 49
    iget p1, p1, Lan;->z:I

    iput p1, p0, La_83B84C54;->x:I

    return-void
.end method

.method public static a(Ljava/util/concurrent/TimeUnit;)I
    .locals 4

    .line 1
    if-eqz p0, :cond_1

    .line 3
    const-wide/16 v0, 0x0

    .line 5
    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 8
    move-result-wide v0

    .line 9
    const-wide/32 v2, 0x7fffffff
    # ep-ymgtkbomanbq

    .line 12
    cmp-long p0, v0, v2

    # ep-knbxilgltstm
    .line 14
    if-gtz p0, :cond_0

    .line 16
    long-to-int p0, v0

    .line 17
    return p0

    .line 18
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 20
    # ep-wblgqdrleija
    const-string v0, "timeout too large."

    .line 22
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 25
    throw p0

    .line 26
    :cond_1
    new-instance p0, Ljava/lang/NullPointerException;

    .line 28
    const-string v0, "unit == null"

    .line 30
    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V
    # ep-bzshgoeehjpz

    .line 33
    throw p0
.end method
