.class public final La_2395FADF;
.super La_EDFD37DC;
.source "dgfgfvbs.java"

# generated-81915

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "g"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_EDFD37DC;-><init>()V

    return-void
.end method
