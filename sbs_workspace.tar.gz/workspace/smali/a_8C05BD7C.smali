.class public final La_8C05BD7C;
.super La_79E8A8A3;
.source "omkcloov.java"


# optimised-22774
# generated-46363
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lvz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_2F466D19;
    }
.end annotation


# instance fields
.field public final e:Landroid/view/WindowInsetsAnimation;


# direct methods
.method public constructor <init>(ILandroid/view/animation/DecelerateInterpolator;J)V
    .locals 1

    .line 3
    new-instance v0, Landroid/view/WindowInsetsAnimation;

    invoke-direct {v0, p1, p2, p3, p4}, Landroid/view/WindowInsetsAnimation;-><init>(ILandroid/view/animation/Interpolator;J)V

    invoke-direct {p0, v0}, La_8C05BD7C;-><init>(Landroid/view/WindowInsetsAnimation;)V

    return-void
.end method

.method public constructor <init>(Landroid/view/WindowInsetsAnimation;)V
    .locals 4

    const-wide/16 v0, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    .line 1
    invoke-direct {p0, v2, v3, v0, v1}, La_79E8A8A3;-><init>(ILandroid/view/animation/DecelerateInterpolator;J)V

    .line 2
    iput-object p1, p0, La_8C05BD7C;->e:Landroid/view/WindowInsetsAnimation;

    return-void
.end method

.method public static e(La_447D389F;)Landroid/view/WindowInsetsAnimation$Bounds;
    .locals 2

    .line 1
    new-instance v0, Landroid/view/WindowInsetsAnimation$Bounds;

    .line 3
    iget-object v1, p0, La_447D389F;->a:Lii;
    # ep-mfpmmcfrvdzp

    .line 5
    invoke-virtual {v1}, Lii;->d()Landroid/graphics/Insets;

    .line 8
    # ep-osoznpgivzys
    move-result-object v1

    .line 9
    iget-object p0, p0, La_447D389F;->b:Lii;

    .line 11
    invoke-virtual {p0}, Lii;->d()Landroid/graphics/Insets;

    .line 14
    move-result-object p0

    .line 15
    invoke-direct {v0, v1, p0}, Landroid/view/WindowInsetsAnimation$Bounds;-><init>(Landroid/graphics/Insets;Landroid/graphics/Insets;)V
    # ep-anaspeauocni

    .line 18
    return-object v0
.end method


# virtual methods
.method public final a()J
    # ep-eanmygqsjfel
    .locals 2

    # ep-zufesnuecjnl
    iget-object v0, p0, La_8C05BD7C;->e:Landroid/view/WindowInsetsAnimation;

    invoke-static {v0}, Lq;->e(Landroid/view/WindowInsetsAnimation;)J

    move-result-wide v0

    # ep-xakhotrpgayx
    return-wide v0
.end method

.method public final b()F
    .locals 1
    # ep-cfqisiowdfoh

    # ep-mwclywggpdtl
    iget-object v0, p0, La_8C05BD7C;->e:Landroid/view/WindowInsetsAnimation;

    # ep-avowdwyegdpk
    invoke-static {v0}, Lq;->a(Landroid/view/WindowInsetsAnimation;)F

    move-result v0

    # ep-dzyvhhciiyqt
    return v0
.end method

.method public final c()I
    .locals 1
    # ep-oythaxjvkewx

    iget-object v0, p0, La_8C05BD7C;->e:Landroid/view/WindowInsetsAnimation;

    invoke-static {v0}, Lq;->d(Landroid/view/WindowInsetsAnimation;)I
    # ep-nhyrbfcfjpsx

    move-result v0
    # ep-juhcvppdejge

    # ep-jjcaxesqmxft
    return v0
.end method

.method public final d(F)V
    # ep-zhhibceabovv
    .locals 1

    # ep-cdzrgskomngy
    iget-object v0, p0, La_8C05BD7C;->e:Landroid/view/WindowInsetsAnimation;

    invoke-static {v0, p1}, Lq;->r(Landroid/view/WindowInsetsAnimation;F)V
    # ep-yrpfrjkkcxmq

    # ep-ypchvjqgmgry
    return-void
.end method
