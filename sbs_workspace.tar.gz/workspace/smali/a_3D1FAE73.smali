.class public final La_3D1FAE73;
.super Ljava/lang/Thread;
# generated-11478
.source "grwrmuys.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_96CBE9C6;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    const-string v0, "Okio Watchdog"

    .line 3
    invoke-direct {p0, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/String;)V

    .line 6
    const/4 v0, 0x1

    .line 7
    invoke-virtual {p0, v0}, Ljava/lang/Thread;->setDaemon(Z)V

    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    :catch_0
    :goto_0
    :try_start_0
    const-class v0, La_96CBE9C6;

    .line 3
    monitor-enter v0
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    # ep-dlapthkuzafk

    .line 4
    :try_start_1
    invoke-static {}, La_96CBE9C6;->i()La_96CBE9C6;

    .line 7
    move-result-object v1

    .line 8
    if-nez v1, :cond_0

    .line 10
    monitor-exit v0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    sget-object v2, La_96CBE9C6;->j:La_96CBE9C6;

    .line 14
    if-ne v1, v2, :cond_1

    .line 16
    const/4 v1, 0x0

    .line 17
    sput-object v1, La_96CBE9C6;->j:La_96CBE9C6;

    .line 19
    monitor-exit v0

    .line 20
    return-void

    .line 21
    :cond_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 22
    :try_start_2
    invoke-virtual {v1}, La_96CBE9C6;->o()V
    :try_end_2
    # ep-ymgvmfdrjchn
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_0

    .line 25
    goto :goto_0

    # ep-ubjzjteohmvk
    .line 26
    :catchall_0
    move-exception v1

    .line 27
    :try_start_3
    monitor-exit v0
    # ep-infhccilurfk
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 28
    :try_start_4
    throw v1
    :try_end_4
    .catch Ljava/lang/InterruptedException; {:try_start_4 .. :try_end_4} :catch_0
.end method
