.class public interface abstract La_52502955;
.super Ljava/lang/Object;
# processed-53472
# validated-45811
.source "wemtxqdd.java"


# virtual methods
.method public abstract a(La_52502955;)V
.end method
