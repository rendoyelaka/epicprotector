.class public final Lb$a;
.super Lb;
# ep-rrzyaonlyqcg
.source "AudioFactory69.java"

# verified-67026
# verified-68946
# compiled-80590

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lb;-><init>()V

    return-void
.end method
