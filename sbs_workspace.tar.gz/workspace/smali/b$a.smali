.class public final Lb$a;
# ep-gmfabetpqivt
.super Lb;
.source "fidttiaf.java"

# optimised-14740
# compiled-12442
# validated-57707

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lb;-><init>()V

    return-void
.end method
