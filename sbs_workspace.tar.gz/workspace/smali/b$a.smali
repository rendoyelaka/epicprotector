.class public final Lb$a;
# ep-vcmevqfaajwa
.super Lb;
.source "sypbnses.java"
# optimised-12981
# validated-37810
# generated-62813


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lb;-><init>()V

    return-void
.end method
