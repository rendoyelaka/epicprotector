.class public final Lb$a;
# ep-iqpddcwewglj
.super Lb;
# optimised-84215
# compiled-92251
# optimised-77750
.source "xeawgmyr.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lb;-><init>()V

    return-void
.end method
