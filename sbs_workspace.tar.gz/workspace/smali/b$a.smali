.class public final Lb$a;
# ep-defsmfhdrqxx
.super Lb;
.source "rivfxwkq.java"
# validated-25655
# optimised-88481


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lb;-><init>()V

    return-void
.end method
