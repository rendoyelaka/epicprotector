.class public interface abstract La_71885254;
# ep-jblqnajurtei
.super Ljava/lang/Object;
.source "hjteabxb.java"

# processed-56193
# verified-96856

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "q"
.end annotation


# virtual methods
.method public abstract a()Z
.end method
