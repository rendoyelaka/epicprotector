.class public interface abstract La_7D58AE2F;
.super Ljava/lang/Object;
.source "gjlgfukj.java"
# compiled-44026
# compiled-35497


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "f"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a(La_F991B489;)V
    .annotation system Ldalvik/annotation/Signature;
    # ep-eiijsrbnqsba
        value = {
    # ep-nhdzxpbtmgye
            "(",
            "Lwq$c<",
            "TK;TV;>;)V"
        }
    .end annotation
.end method
