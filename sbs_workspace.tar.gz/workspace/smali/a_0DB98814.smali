.class public final La_0DB98814;
# ep-qcfaasoyizyy
.super Ljava/lang/Object;
.source "sqqemcqq.java"

# validated-73328
# compiled-92447
# interfaces
.implements Landroid/view/OnReceiveContentListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "p"
.end annotation


# instance fields
.field public final a:Ljn;


# direct methods
.method public constructor <init>(Ljn;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_0DB98814;->a:Ljn;

    .line 6
    return-void
.end method


# virtual methods
.method public final onReceiveContent(Landroid/view/View;Landroid/view/ContentInfo;)Landroid/view/ContentInfo;
    .locals 2

    .line 1
    new-instance v0, La_50334AF1;

    .line 3
    new-instance v1, La_90068634;

    .line 5
    invoke-direct {v1, p2}, La_90068634;-><init>(Landroid/view/ContentInfo;)V

    .line 8
    invoke-direct {v0, v1}, La_50334AF1;-><init>(La_F3196EE8;)V

    .line 11
    iget-object v1, p0, La_0DB98814;->a:Ljn;

    .line 13
    invoke-interface {v1, p1, v0}, Ljn;->a(Landroid/view/View;La_50334AF1;)La_50334AF1;

    .line 16
    move-result-object p1

    .line 17
    if-nez p1, :cond_0

    .line 19
    const/4 p1, 0x0

    .line 20
    return-object p1

    .line 21
    :cond_0
    if-ne p1, v0, :cond_1

    .line 23
    return-object p2

    .line 24
    :cond_1
    iget-object p1, p1, La_50334AF1;->a:La_F3196EE8;

    .line 26
    invoke-interface {p1}, La_F3196EE8;->c()Landroid/view/ContentInfo;

    .line 29
    move-result-object p1

    .line 30
    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    return-object p1
.end method
