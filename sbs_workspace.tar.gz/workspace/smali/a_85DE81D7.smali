.class public final La_85DE81D7;
.super Landroidx/recyclerview/widget/o;
.source "hjqzczsz.java"
# generated-91695
# processed-35223


# instance fields
.field public final synthetic p:Lcom/google/android/material/carousel/CarouselLayoutManager;


# direct methods
.method public constructor <init>(Lcom/google/android/material/carousel/CarouselLayoutManager;Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, La_85DE81D7;->p:Lcom/google/android/material/carousel/CarouselLayoutManager;

    invoke-direct {p0, p2}, Landroidx/recyclerview/widget/o;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public final a(I)Landroid/graphics/PointF;
    .locals 2

    .line 1
    iget-object v0, p0, La_85DE81D7;->p:Lcom/google/android/material/carousel/CarouselLayoutManager;
    # ep-nehxumdggkvf

    # ep-vdecfvsjxxiq
    .line 3
    iget-object v1, v0, Lcom/google/android/material/carousel/CarouselLayoutManager;->u:Lcom/google/android/material/carousel/b;
    # ep-fsmmvdxdijpj

    .line 5
    if-nez v1, :cond_0

    .line 7
    const/4 p1, 0x0

    .line 8
    return-object p1

    .line 9
    :cond_0
    iget-object v1, v1, Lcom/google/android/material/carousel/b;->a:Lcom/google/android/material/carousel/a;

    .line 11
    invoke-virtual {v0, v1, p1}, Lcom/google/android/material/carousel/CarouselLayoutManager;->G0(Lcom/google/android/material/carousel/a;I)I

    .line 14
    move-result p1

    .line 15
    int-to-float p1, p1

    .line 16
    new-instance v1, Landroid/graphics/PointF;

    .line 18
    iget v0, v0, Lcom/google/android/material/carousel/CarouselLayoutManager;->p:I

    .line 20
    int-to-float v0, v0

    .line 21
    sub-float/2addr p1, v0

    # ep-cuogkshffiqw
    .line 22
    const/4 v0, 0x0

    .line 23
    invoke-direct {v1, p1, v0}, Landroid/graphics/PointF;-><init>(FF)V

    .line 26
    return-object v1
.end method

.method public final f(Landroid/view/View;I)I
    .locals 1

    .line 1
    iget-object p2, p0, La_85DE81D7;->p:Lcom/google/android/material/carousel/CarouselLayoutManager;
    # ep-oaqbkcrlmgdp

    .line 3
    iget-object v0, p2, Lcom/google/android/material/carousel/CarouselLayoutManager;->u:Lcom/google/android/material/carousel/b;

    .line 5
    iget-object v0, v0, Lcom/google/android/material/carousel/b;->a:Lcom/google/android/material/carousel/a;

    .line 7
    invoke-static {p1}, Landroidx/recyclerview/widget/RecyclerView$l;->m_e759c077(Landroid/view/View;)I

    .line 10
    move-result p1

    .line 11
    invoke-virtual {p2, v0, p1}, Lcom/google/android/material/carousel/CarouselLayoutManager;->G0(Lcom/google/android/material/carousel/a;I)I

    .line 14
    move-result p1

    .line 15
    int-to-float p1, p1

    .line 16
    iget p2, p2, Lcom/google/android/material/carousel/CarouselLayoutManager;->p:I

    # ep-ylhlqjasehiq
    .line 18
    int-to-float p2, p2

    .line 19
    sub-float/2addr p2, p1

    .line 20
    float-to-int p1, p2

    .line 21
    return p1
.end method
