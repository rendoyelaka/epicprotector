.class public final LGreedyScheduler;
# ep-bksvohsoamlc
.super Ljava/lang/Object;
# verified-56973
.source "kerfvblz.java"

# interfaces
.implements Lhr;
.implements Ld00;
.implements Lic;


# instance fields
.field public final c:Landroid/content/Context;

.field public final d:LWorkManagerImpl;

.field public final e:Le00;

.field public final f:Ljava/util/HashSet;

.field public final g:Lx9;

.field public h:Z

.field public final i:Ljava/lang/Object;

.field public j:Ljava/lang/Boolean;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "GreedyScheduler"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/work/a;Lp00;LWorkManagerImpl;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/HashSet;

    .line 6
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 9
    iput-object v0, p0, LGreedyScheduler;->f:Ljava/util/HashSet;

    .line 11
    iput-object p1, p0, LGreedyScheduler;->c:Landroid/content/Context;

    .line 13
    iput-object p4, p0, LGreedyScheduler;->d:LWorkManagerImpl;

    .line 15
    new-instance p4, Le00;

    .line 17
    invoke-direct {p4, p1, p3, p0}, Le00;-><init>(Landroid/content/Context;Lnu;Ld00;)V

    .line 20
    iput-object p4, p0, LGreedyScheduler;->e:Le00;

    .line 22
    new-instance p1, Lx9;

    .line 24
    iget-object p2, p2, Landroidx/work/a;->e:Lri;

    .line 26
    invoke-direct {p1, p0, p2}, Lx9;-><init>(LGreedyScheduler;Lri;)V

    .line 29
    iput-object p1, p0, LGreedyScheduler;->g:Lx9;

    .line 31
    new-instance p1, Ljava/lang/Object;

    .line 33
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 36
    iput-object p1, p0, LGreedyScheduler;->i:Ljava/lang/Object;

    .line 38
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;Z)V
    .locals 5

    .line 1
    iget-object p2, p0, LGreedyScheduler;->i:Ljava/lang/Object;

    .line 3
    monitor-enter p2

    .line 4
    :try_start_0
    iget-object v0, p0, LGreedyScheduler;->f:Ljava/util/HashSet;

    .line 6
    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 9
    move-result-object v0

    .line 10
    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    move-result v1

    .line 14
    if-eqz v1, :cond_1

    .line 16
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    move-result-object v1

    .line 20
    check-cast v1, LWorkSpec;

    .line 22
    iget-object v2, v1, LWorkSpec;->a:Ljava/lang/String;

    .line 24
    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 27
    move-result v2

    .line 28
    if-eqz v2, :cond_0

    .line 30
    invoke-static {}, Ltj;->c()Ltj;

    .line 33
    move-result-object v0

    .line 34
    const-string v2, "Stopping tracking for %s"

    .line 36
    const/4 v3, 0x1

    .line 37
    new-array v3, v3, [Ljava/lang/Object;

    .line 39
    const/4 v4, 0x0

    .line 40
    aput-object p1, v3, v4

    .line 42
    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 45
    new-array p1, v4, [Ljava/lang/Throwable;

    .line 47
    invoke-virtual {v0, p1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 50
    iget-object p1, p0, LGreedyScheduler;->f:Ljava/util/HashSet;

    .line 52
    invoke-virtual {p1, v1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 55
    iget-object p1, p0, LGreedyScheduler;->e:Le00;

    .line 57
    iget-object v0, p0, LGreedyScheduler;->f:Ljava/util/HashSet;

    .line 59
    invoke-virtual {p1, v0}, Le00;->c(Ljava/util/Collection;)V

    .line 62
    :cond_1
    monitor-exit p2

    .line 63
    return-void

    .line 64
    :catchall_0
    move-exception p1

    .line 65
    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 66
    throw p1
.end method

.method public final b(Ljava/lang/String;)V
    .locals 5

    .line 1
    iget-object v0, p0, LGreedyScheduler;->j:Ljava/lang/Boolean;

    .line 3
    iget-object v1, p0, LGreedyScheduler;->d:LWorkManagerImpl;

    .line 5
    if-nez v0, :cond_0

    .line 7
    iget-object v0, v1, LWorkManagerImpl;->d:Landroidx/work/a;

    .line 9
    iget-object v2, p0, LGreedyScheduler;->c:Landroid/content/Context;

    .line 11
    invoke-static {v2, v0}, Lto;->a(Landroid/content/Context;Landroidx/work/a;)Z

    .line 14
    move-result v0

    .line 15
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 18
    move-result-object v0

    .line 19
    iput-object v0, p0, LGreedyScheduler;->j:Ljava/lang/Boolean;

    .line 21
    :cond_0
    iget-object v0, p0, LGreedyScheduler;->j:Ljava/lang/Boolean;

    .line 23
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 26
    move-result v0

    .line 27
    const/4 v2, 0x0

    .line 28
    if-nez v0, :cond_1

    .line 30
    invoke-static {}, Ltj;->c()Ltj;

    .line 33
    move-result-object p1

    .line 34
    new-array v0, v2, [Ljava/lang/Throwable;

    .line 36
    invoke-virtual {p1, v0}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 39
    return-void

    .line 40
    :cond_1
    iget-boolean v0, p0, LGreedyScheduler;->h:Z

    .line 42
    const/4 v3, 0x1

    .line 43
    if-nez v0, :cond_2

    .line 45
    iget-object v0, v1, LWorkManagerImpl;->h:Luo;

    .line 47
    invoke-virtual {v0, p0}, Luo;->b(Lic;)V

    .line 50
    iput-boolean v3, p0, LGreedyScheduler;->h:Z

    .line 52
    :cond_2
    invoke-static {}, Ltj;->c()Ltj;

    .line 55
    move-result-object v0

    .line 56
    new-array v3, v3, [Ljava/lang/Object;

    .line 58
    aput-object p1, v3, v2

    .line 60
    const-string v4, "Cancelling work ID %s"

    .line 62
    invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 65
    new-array v2, v2, [Ljava/lang/Throwable;

    .line 67
    invoke-virtual {v0, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 70
    iget-object v0, p0, LGreedyScheduler;->g:Lx9;

    .line 72
    if-eqz v0, :cond_3

    .line 74
    iget-object v2, v0, Lx9;->c:Ljava/util/HashMap;

    .line 76
    invoke-virtual {v2, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 79
    move-result-object v2

    .line 80
    check-cast v2, Ljava/lang/Runnable;

    .line 82
    if-eqz v2, :cond_3

    .line 84
    iget-object v0, v0, Lx9;->b:Lri;

    .line 86
    iget-object v0, v0, Lri;->c:Ljava/lang/Object;

    .line 88
    check-cast v0, Landroid/os/Handler;

    .line 90
    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 93
    :cond_3
    invoke-virtual {v1, p1}, LWorkManagerImpl;->x(Ljava/lang/String;)V

    .line 96
    return-void
.end method

.method public final c(Ljava/util/ArrayList;)V
    .locals 5

    .line 1
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 4
    move-result-object p1

    .line 5
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 11
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Ljava/lang/String;

    .line 17
    invoke-static {}, Ltj;->c()Ltj;

    .line 20
    move-result-object v1

    .line 21
    const/4 v2, 0x1

    .line 22
    new-array v2, v2, [Ljava/lang/Object;

    .line 24
    const/4 v3, 0x0

    .line 25
    aput-object v0, v2, v3

    .line 27
    const-string v4, "Constraints not met: Cancelling work ID %s"

    .line 29
    invoke-static {v4, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 32
    new-array v2, v3, [Ljava/lang/Throwable;

    .line 34
    invoke-virtual {v1, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 37
    iget-object v1, p0, LGreedyScheduler;->d:LWorkManagerImpl;

    .line 39
    invoke-virtual {v1, v0}, LWorkManagerImpl;->x(Ljava/lang/String;)V

    .line 42
    goto :goto_0

    .line 43
    :cond_0
    return-void
.end method

.method public final varargs d([LWorkSpec;)V
    .locals 13

    .line 1
    iget-object v0, p0, LGreedyScheduler;->j:Ljava/lang/Boolean;

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, LGreedyScheduler;->d:LWorkManagerImpl;

    .line 7
    iget-object v0, v0, LWorkManagerImpl;->d:Landroidx/work/a;

    .line 9
    iget-object v1, p0, LGreedyScheduler;->c:Landroid/content/Context;

    .line 11
    invoke-static {v1, v0}, Lto;->a(Landroid/content/Context;Landroidx/work/a;)Z

    .line 14
    move-result v0

    .line 15
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 18
    move-result-object v0

    .line 19
    iput-object v0, p0, LGreedyScheduler;->j:Ljava/lang/Boolean;

    .line 21
    :cond_0
    iget-object v0, p0, LGreedyScheduler;->j:Ljava/lang/Boolean;

    .line 23
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 26
    move-result v0

    .line 27
    const/4 v1, 0x0

    .line 28
    if-nez v0, :cond_1

    .line 30
    invoke-static {}, Ltj;->c()Ltj;

    .line 33
    move-result-object p1

    .line 34
    new-array v0, v1, [Ljava/lang/Throwable;

    .line 36
    invoke-virtual {p1, v0}, Ltj;->d([Ljava/lang/Throwable;)V

    .line 39
    return-void

    .line 40
    :cond_1
    iget-boolean v0, p0, LGreedyScheduler;->h:Z

    .line 42
    const/4 v2, 0x1

    .line 43
    if-nez v0, :cond_2

    .line 45
    iget-object v0, p0, LGreedyScheduler;->d:LWorkManagerImpl;

    .line 47
    iget-object v0, v0, LWorkManagerImpl;->h:Luo;

    .line 49
    invoke-virtual {v0, p0}, Luo;->b(Lic;)V

    .line 52
    iput-boolean v2, p0, LGreedyScheduler;->h:Z

    .line 54
    :cond_2
    new-instance v0, Ljava/util/HashSet;

    .line 56
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 59
    new-instance v3, Ljava/util/HashSet;

    .line 61
    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    .line 64
    array-length v4, p1

    .line 65
    const/4 v5, 0x0

    .line 66
    :goto_0
    if-ge v5, v4, :cond_a

    .line 68
    aget-object v6, p1, v5

    .line 70
    invoke-virtual {v6}, LWorkSpec;->a()J

    .line 73
    move-result-wide v7

    .line 74
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 77
    move-result-wide v9

    .line 78
    iget-object v11, v6, LWorkSpec;->b:LWorkInfo_State;

    .line 80
    sget-object v12, LWorkInfo_State;->c:LWorkInfo_State;

    .line 82
    if-ne v11, v12, :cond_9

    .line 84
    cmp-long v11, v9, v7

    .line 86
    if-gez v11, :cond_4

    .line 88
    iget-object v7, p0, LGreedyScheduler;->g:Lx9;

    .line 90
    if-eqz v7, :cond_9

    .line 92
    iget-object v8, v7, Lx9;->c:Ljava/util/HashMap;

    .line 94
    iget-object v9, v6, LWorkSpec;->a:Ljava/lang/String;

    .line 96
    invoke-virtual {v8, v9}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 99
    move-result-object v9

    .line 100
    check-cast v9, Ljava/lang/Runnable;

    .line 102
    iget-object v10, v7, Lx9;->b:Lri;

    .line 104
    if-eqz v9, :cond_3

    .line 106
    iget-object v11, v10, Lri;->c:Ljava/lang/Object;

    .line 108
    check-cast v11, Landroid/os/Handler;

    .line 110
    invoke-virtual {v11, v9}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 113
    :cond_3
    new-instance v9, Lw9;

    .line 115
    invoke-direct {v9, v7, v6}, Lw9;-><init>(Lx9;LWorkSpec;)V

    .line 118
    iget-object v7, v6, LWorkSpec;->a:Ljava/lang/String;

    .line 120
    invoke-virtual {v8, v7, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 123
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 126
    move-result-wide v7

    .line 127
    invoke-virtual {v6}, LWorkSpec;->a()J

    .line 130
    move-result-wide v11

    .line 131
    sub-long/2addr v11, v7

    .line 132
    iget-object v6, v10, Lri;->c:Ljava/lang/Object;

    .line 134
    check-cast v6, Landroid/os/Handler;

    .line 136
    invoke-virtual {v6, v9, v11, v12}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 139
    goto/16 :goto_2

    .line 141
    :cond_4
    invoke-virtual {v6}, LWorkSpec;->b()Z

    .line 144
    move-result v7

    .line 145
    if-eqz v7, :cond_8

    .line 147
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 149
    const/16 v8, 0x17

    .line 151
    if-lt v7, v8, :cond_5

    .line 153
    iget-object v8, v6, LWorkSpec;->j:Lf8;

    .line 155
    iget-boolean v8, v8, Lf8;->c:Z

    .line 157
    if-eqz v8, :cond_5

    .line 159
    invoke-static {}, Ltj;->c()Ltj;

    .line 162
    move-result-object v7

    .line 163
    const-string v8, "Ignoring WorkSpec %s, Requires device idle."

    .line 165
    new-array v9, v2, [Ljava/lang/Object;

    .line 167
    aput-object v6, v9, v1

    .line 169
    invoke-static {v8, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 172
    new-array v6, v1, [Ljava/lang/Throwable;

    .line 174
    invoke-virtual {v7, v6}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 177
    goto :goto_2

    .line 178
    :cond_5
    const/16 v8, 0x18

    .line 180
    if-lt v7, v8, :cond_7

    .line 182
    iget-object v7, v6, LWorkSpec;->j:Lf8;

    .line 184
    iget-object v7, v7, Lf8;->h:Ll8;

    .line 186
    iget-object v7, v7, Ll8;->a:Ljava/util/HashSet;

    .line 188
    invoke-virtual {v7}, Ljava/util/HashSet;->size()I

    .line 191
    move-result v7

    .line 192
    if-lez v7, :cond_6

    .line 194
    const/4 v7, 0x1

    .line 195
    goto :goto_1

    .line 196
    :cond_6
    const/4 v7, 0x0

    .line 197
    :goto_1
    if-eqz v7, :cond_7

    .line 199
    invoke-static {}, Ltj;->c()Ltj;

    .line 202
    move-result-object v7

    .line 203
    const-string v8, "Ignoring WorkSpec %s, Requires ContentUri triggers."

    .line 205
    new-array v9, v2, [Ljava/lang/Object;

    .line 207
    aput-object v6, v9, v1

    .line 209
    invoke-static {v8, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 212
    new-array v6, v1, [Ljava/lang/Throwable;

    .line 214
    invoke-virtual {v7, v6}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 217
    goto :goto_2

    .line 218
    :cond_7
    invoke-virtual {v0, v6}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 221
    iget-object v6, v6, LWorkSpec;->a:Ljava/lang/String;

    .line 223
    invoke-virtual {v3, v6}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 226
    goto :goto_2

    .line 227
    :cond_8
    invoke-static {}, Ltj;->c()Ltj;

    .line 230
    move-result-object v7

    .line 231
    const-string v8, "Starting work for %s"

    .line 233
    new-array v9, v2, [Ljava/lang/Object;

    .line 235
    iget-object v10, v6, LWorkSpec;->a:Ljava/lang/String;

    .line 237
    aput-object v10, v9, v1

    .line 239
    invoke-static {v8, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 242
    new-array v8, v1, [Ljava/lang/Throwable;

    .line 244
    invoke-virtual {v7, v8}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 247
    iget-object v7, p0, LGreedyScheduler;->d:LWorkManagerImpl;

    .line 249
    iget-object v6, v6, LWorkSpec;->a:Ljava/lang/String;

    .line 251
    const/4 v8, 0x0

    .line 252
    invoke-virtual {v7, v6, v8}, LWorkManagerImpl;->w(Ljava/lang/String;Landroidx/work/WorkerParameters$a;)V

    .line 255
    :cond_9
    :goto_2
    add-int/lit8 v5, v5, 0x1

    .line 257
    goto/16 :goto_0

    .line 259
    :cond_a
    iget-object p1, p0, LGreedyScheduler;->i:Ljava/lang/Object;

    .line 261
    monitor-enter p1

    .line 262
    :try_start_0
    invoke-virtual {v0}, Ljava/util/HashSet;->isEmpty()Z

    .line 265
    move-result v4

    .line 266
    if-nez v4, :cond_b

    .line 268
    invoke-static {}, Ltj;->c()Ltj;

    .line 271
    move-result-object v4

    .line 272
    const-string v5, "Starting tracking for [%s]"

    .line 274
    new-array v2, v2, [Ljava/lang/Object;

    .line 276
    const-string v6, ","

    .line 278
    invoke-static {v6, v3}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    .line 281
    move-result-object v3

    .line 282
    aput-object v3, v2, v1

    .line 284
    invoke-static {v5, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 287
    new-array v1, v1, [Ljava/lang/Throwable;

    .line 289
    invoke-virtual {v4, v1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 292
    iget-object v1, p0, LGreedyScheduler;->f:Ljava/util/HashSet;

    .line 294
    invoke-interface {v1, v0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 297
    iget-object v0, p0, LGreedyScheduler;->e:Le00;

    .line 299
    iget-object v1, p0, LGreedyScheduler;->f:Ljava/util/HashSet;

    .line 301
    invoke-virtual {v0, v1}, Le00;->c(Ljava/util/Collection;)V

    .line 304
    :cond_b
    monitor-exit p1

    .line 305
    return-void

    .line 306
    :catchall_0
    move-exception v0

    .line 307
    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 308
    throw v0
.end method

.method public final e(Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 1
    check-cast p1, Ljava/util/ArrayList;

    .line 3
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 6
    move-result-object p1

    .line 7
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 13
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Ljava/lang/String;

    .line 19
    invoke-static {}, Ltj;->c()Ltj;

    .line 22
    move-result-object v1

    .line 23
    const/4 v2, 0x1

    .line 24
    new-array v2, v2, [Ljava/lang/Object;

    .line 26
    const/4 v3, 0x0

    .line 27
    aput-object v0, v2, v3

    .line 29
    const-string v4, "Constraints met: Scheduling work ID %s"

    .line 31
    invoke-static {v4, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 34
    new-array v2, v3, [Ljava/lang/Throwable;

    .line 36
    invoke-virtual {v1, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 39
    const/4 v1, 0x0

    .line 40
    iget-object v2, p0, LGreedyScheduler;->d:LWorkManagerImpl;

    .line 42
    invoke-virtual {v2, v0, v1}, LWorkManagerImpl;->w(Ljava/lang/String;Landroidx/work/WorkerParameters$a;)V

    .line 45
    goto :goto_0

    .line 46
    :cond_0
    return-void
.end method

.method public final f()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method
