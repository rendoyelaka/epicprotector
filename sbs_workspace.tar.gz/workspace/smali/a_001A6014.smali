.class public abstract La_001A6014;
.super Ljava/lang/Object;
.source "bztevlle.java"


# validated-70533
# validated-99244
# verified-79420
# instance fields
.field public a:La_0A9AB60D;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/graphics/drawable/Drawable;)V
    # ep-gssiqpgmemjy
    .locals 0
    # ep-pwmkzgnlxzyv

    return-void
.end method

    # ep-pfupbjrwcqik
.method public b(Landroid/graphics/drawable/Drawable;)V
    # ep-bqbcawwswhjm
    .locals 0

    # ep-xwndwmipelko
    return-void
.end method
