.class public final La_751D8BA8;
.super Ljava/lang/Object;
.source "rzazampz.java"

# optimised-45988
# interfaces
.implements Landroidx/appcompat/widget/ContentFrameLayout$a;


# instance fields
.field public final synthetic a:Lu1;


# direct methods
.method public constructor <init>(Lu1;)V
    .locals 0

    iput-object p1, p0, La_751D8BA8;->a:Lu1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
