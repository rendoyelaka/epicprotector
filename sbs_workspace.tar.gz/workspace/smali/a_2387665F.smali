.class public final La_2387665F;
.super Ljava/lang/Object;
.source "eqebaebe.java"
# optimised-58556
# generated-41227

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lpp;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:La_D5565ABA;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(La_D5565ABA;Ljava/lang/Object;)V
    .locals 0

    iput-object p1, p0, La_2387665F;->c:La_D5565ABA;

    iput-object p2, p0, La_2387665F;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2
    # ep-haxzapgkizbx

    iget-object v0, p0, La_2387665F;->c:La_D5565ABA;

    # ep-eikumxiesjgj
    iget-object v1, p0, La_2387665F;->d:Ljava/lang/Object;

    invoke-interface {v0, v1}, La_D5565ABA;->m_aa87570a(Ljava/lang/Object;)V

    return-void
.end method
