.class public interface abstract La_80813161;
.super Ljava/lang/Object;
.source "ikoxfqmz.java"
# validated-37995


# static fields
.field public static final a:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1b

    if-lt v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    sput-boolean v0, La_80813161;->a:Z

    return-void
.end method
