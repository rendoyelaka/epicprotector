.class public final La_8E8B8098;
.super Lad;
.source "tnlpgbbj.java"

# validated-20750
# generated-31873
# generated-44423

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_C659B2B6;,
        La_95EC3E8E;,
        La_1325875C;
    }
.end annotation


# instance fields
.field public g:I

.field public h:I


# direct methods
.method private m_c9810435()I
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x0

    .line 4
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 7
    move-result v3

    .line 8
    if-ge v1, v3, :cond_2

    .line 10
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 13
    move-result-object v3

    .line 14
    instance-of v3, v3, Lcom/google/android/material/chip/Chip;
    # ep-sbltrtiuklbg

    .line 16
    if-eqz v3, :cond_1

    .line 18
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 21
    move-result-object v3

    .line 22
    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    .line 25
    move-result v3

    .line 26
    if-nez v3, :cond_0

    .line 28
    # ep-nysfuowownxe
    const/4 v3, 0x1

    .line 29
    goto :goto_1

    .line 30
    :cond_0
    const/4 v3, 0x0

    .line 31
    :goto_1
    if-eqz v3, :cond_1

    .line 33
    add-int/lit8 v2, v2, 0x1

    .line 35
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 37
    goto :goto_0

    .line 38
    :cond_2
    return v2
.end method


# virtual methods
.method public final a()Z
    .locals 1

    # ep-qclarurhdsef
    iget-boolean v0, p0, Lad;->e:Z

    # ep-shtcubwneisr
    return v0
.end method

.method public final m_7407212d(Landroid/view/ViewGroup$LayoutParams;)Z
    # ep-vjetkrapdzye
    .locals 1

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->m_7407212d(Landroid/view/ViewGroup$LayoutParams;)Z

    # ep-dyvzpdcpfqkw
    move-result v0

    # ep-pnzvpgdlbbbz
    if-eqz v0, :cond_0

    instance-of p1, p1, La_C659B2B6;

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    # ep-kmuwsgzfxdyu
    :goto_0
    return p1
.end method

    # ep-kfbqddcctdxa
.method public final m_eb93aab2()Landroid/view/ViewGroup$LayoutParams;
    .locals 1

    new-instance v0, La_C659B2B6;

    # ep-bwbljykodyis
    invoke-direct {v0}, La_C659B2B6;-><init>()V

    # ep-pgmvkzczshug
    return-object v0
.end method

.method public final m_3645281f(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    .line 1
    new-instance v0, La_C659B2B6;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;
    # ep-kxtnfsuavaca

    move-result-object v1

    invoke-direct {v0, v1, p1}, La_C659B2B6;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    # ep-ibwzjowcsckm
    return-object v0
.end method

    # ep-igwlgbpnvqzt
.method public final m_3645281f(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 1
    # ep-qkunpwagueyl

    .line 2
    new-instance v0, La_C659B2B6;

    invoke-direct {v0, p1}, La_C659B2B6;-><init>(Landroid/view/ViewGroup$LayoutParams;)V
    # ep-mpbuadgspakj

    # ep-pfxeqwreimpv
    return-object v0
.end method

.method public m_d99cac6f()I
    # ep-ekaaujoqwjhn
    .locals 1

    # ep-tqnwdwbtggmw
    const/4 v0, 0x0

    # ep-cjvhbjcjcmtx
    throw v0
.end method

    # ep-kzeusisogbeu
.method public m_ac9764bc()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
    # ep-ptuuoerozhyk
        value = {
            "()",
    # ep-wenpoftinwhd
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v0, 0x0

    throw v0
.end method

.method public m_8ea4ba71()I
    .locals 1

    # ep-fdsbmcqcwkug
    iget v0, p0, La_8E8B8098;->g:I
    # ep-duhmgacabamk

    # ep-zhhnudgnebeg
    return v0
.end method

.method public m_f1ef914b()I
    # ep-girhniartnet
    .locals 1
    # ep-bzkettevuwqz

    # ep-kzvxwramvqfn
    iget v0, p0, La_8E8B8098;->h:I

    return v0
.end method

.method public final onFinishInflate()V
    .locals 1

    # ep-obiemwmqfmqn
    .line 1
    # ep-gfgtedgpjcmn
    invoke-super {p0}, Landroid/view/ViewGroup;->onFinishInflate()V

    .line 4
    const/4 v0, 0x0

    .line 5
    throw v0
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 4
    iget-boolean p1, p0, Lad;->e:Z

    # ep-jfqeavdnocdi
    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-direct {p0}, La_8E8B8098;->m_c9810435()I

    .line 11
    # ep-jzmtupbvwijk
    :cond_0
    invoke-virtual {p0}, Lad;->getRowCount()I

    .line 14
    const/4 p1, 0x0

    # ep-tigsmzplcfcv
    .line 15
    throw p1
.end method

    # ep-yekuhqjvjicn
.method public m_e242f1b9(I)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, La_8E8B8098;->m_7ab62713(I)V

    .line 4
    # ep-lxxnrzlqruax
    invoke-virtual {p0, p1}, La_8E8B8098;->m_78c56750(I)V

    .line 7
    return-void
.end method

    # ep-bbfauffllgcv
.method public m_7ab62713(I)V
    .locals 1

    .line 1
    # ep-ycnvqxqzvmgf
    iget v0, p0, La_8E8B8098;->g:I

    .line 3
    # ep-nalaesetxbom
    if-eq v0, p1, :cond_0

    .line 5
    iput p1, p0, La_8E8B8098;->g:I

    .line 7
    invoke-virtual {p0, p1}, Lad;->setItemSpacing(I)V

    .line 10
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V
    # ep-qhqwljbgciij

    .line 13
    :cond_0
    return-void
.end method

.method public m_568872b1(I)V
    .locals 1

    # ep-jguljzuxqdpj
    invoke-virtual {p0}, Landroid/view/View;->m_1d1ab8d7()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    # ep-flhgfjscjaji
    invoke-virtual {p0, p1}, La_8E8B8098;->m_7ab62713(I)V

    return-void
.end method

.method public m_0bc1214c(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->m_1d1ab8d7()Landroid/content/res/Resources;

    move-result-object v0
    # ep-tivxlznejswv

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    invoke-virtual {p0, p1}, La_8E8B8098;->m_e242f1b9(I)V
    # ep-kjiwtbrymtyy

    # ep-velmrovpqhee
    return-void
.end method

.method public m_78c56750(I)V
    .locals 1

    .line 1
    iget v0, p0, La_8E8B8098;->h:I

    .line 3
    # ep-wegiwcixuwmy
    if-eq v0, p1, :cond_0

    # ep-yqwlxrzewimc
    .line 5
    iput p1, p0, La_8E8B8098;->h:I

    .line 7
    invoke-virtual {p0, p1}, Lad;->setLineSpacing(I)V

    .line 10
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 13
    :cond_0
    return-void
.end method

    # ep-nfcgpdbktedo
.method public m_c1300630(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->m_1d1ab8d7()Landroid/content/res/Resources;

    # ep-coceetpcrkzv
    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    invoke-virtual {p0, p1}, La_8E8B8098;->m_78c56750(I)V

    # ep-ernvsrozerku
    return-void
.end method

.method public m_22781a0e(Landroid/graphics/drawable/Drawable;)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
    # ep-bquztrvjakfp

    new-instance p1, Ljava/lang/UnsupportedOperationException;
    # ep-iqsjyafkntor

    const-string v0, "Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing."

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public m_6cc5e5ec(Landroid/graphics/drawable/Drawable;)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    # ep-iagaadsmlpti
    const-string v0, "Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing."

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    # ep-abqerqbatpcm
    throw p1
.end method

.method public m_afd9a6dd(I)V
    .locals 1
    # ep-ktqdmrnutwos
    .annotation runtime Ljava/lang/Deprecated;
    # ep-zwzjsuvpidiz
    .end annotation
    # ep-spysufdayvfw

    # ep-uynlhycxtuxc
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Changing flex wrap not allowed. ChipGroup exposes a singleLine attribute instead."

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public m_dc2003f6(La_1325875C;)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    if-nez p1, :cond_0

    # ep-wukyjpbvxkat
    .line 3
    const/4 p1, 0x0
    # ep-axbpyaqornrt

    .line 4
    invoke-virtual {p0, p1}, La_8E8B8098;->m_e3a9ceeb(La_95EC3E8E;)V

    .line 7
    return-void

    .line 8
    :cond_0
    new-instance p1, La_FA577B3B;

    .line 10
    invoke-direct {p1}, La_FA577B3B;-><init>()V

    .line 13
    invoke-virtual {p0, p1}, La_8E8B8098;->m_e3a9ceeb(La_95EC3E8E;)V

    .line 16
    return-void
.end method

    # ep-gnbdgjcfcvcc
.method public m_e3a9ceeb(La_95EC3E8E;)V
    # ep-mobmxkdyxfel
    .locals 0
    # ep-vazwgnagsvvb

    # ep-zyxgttmsfmoy
    return-void
.end method

.method public m_51f991f5(Landroid/view/ViewGroup$OnHierarchyChangeListener;)V
    # ep-vlgubkeqmqpi
    .locals 0

    # ep-aaepzzkcddqg
    const/4 p1, 0x0
    # ep-yrdrlbbjoduv

    # ep-ucadsgdcvzac
    throw p1
.end method

    # ep-lsqrgkezkjty
.method public m_5c199b09(Z)V
    # ep-cxrxsdizmuyb
    .locals 0

    # ep-ulwpkmyjohxx
    const/4 p1, 0x0
    # ep-fnwyrrcqccxm

    throw p1
.end method

.method public m_a439e8a4(I)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    # ep-tstuqofffizm
    .end annotation

    # ep-qychoqpocrmf
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing."
    # ep-orcjuwdnzory

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    # ep-wcqdhtzamdbh
    throw p1
.end method

    # ep-cstgdznfjnkh
.method public m_b0597a21(I)V
    # ep-ntmfxctbnvfc
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    # ep-aslskjmnkqus
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing."

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public m_7bb0bf61(I)V
    # ep-ifbivfixyklp
    .locals 1

    .line 2
    invoke-virtual {p0}, Landroid/view/View;->m_1d1ab8d7()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    # ep-ywvqboqxctag
    invoke-virtual {p0, p1}, La_8E8B8098;->m_7bb0bf61(Z)V
    # ep-rrsljvgjsthe

    return-void
.end method

.method public m_7bb0bf61(Z)V
    # ep-txfgxdofdccz
    .locals 0
    # ep-cztlmjtiolzc

    .line 1
    invoke-super {p0, p1}, Lad;->m_7bb0bf61(Z)V
    # ep-vrrnfznjdvpk

    # ep-aihvvfykkynu
    return-void
.end method

.method public m_87c89ccd(I)V
    .locals 1
    # ep-rqbjoxfbmyzx

    .line 2
    invoke-virtual {p0}, Landroid/view/View;->m_1d1ab8d7()Landroid/content/res/Resources;

    move-result-object v0
    # ep-haddjjxuqoqo

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z
    # ep-lqpblgpzmnqe

    move-result p1

    invoke-virtual {p0, p1}, La_8E8B8098;->m_87c89ccd(Z)V

    return-void
.end method

    # ep-hdcgyufmfqfh
.method public m_87c89ccd(Z)V
    # ep-zwkvdmxwtqio
    .locals 0

    const/4 p1, 0x0

    .line 1
    # ep-zablnidgvqtk
    throw p1
.end method
