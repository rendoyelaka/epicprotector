.class public interface abstract La_44A18E48;
.super Ljava/lang/Object;
# optimised-30806
# processed-16107
# compiled-83554
.source "alodvkes.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_A9404FF7;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "e"
.end annotation


# virtual methods
.method public abstract a()Landroid/content/ClipData;
.end method

.method public abstract b()I
.end method

.method public abstract c()Landroid/view/ContentInfo;
.end method

.method public abstract d()I
.end method
