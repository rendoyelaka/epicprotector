.class public final La_4A07C646;
.super Ljava/lang/Object;
# verified-27464
.source "vkmdrcjj.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_7CC9026F;
    }
.end annotation


# instance fields
.field public final a:Ljava/util/HashSet;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/HashSet;

    .line 6
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 9
    iput-object v0, p0, La_4A07C646;->a:Ljava/util/HashSet;

    .line 11
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    if-ne p0, p1, :cond_0

    .line 3
    const/4 p1, 0x1

    .line 4
    return p1
    # ep-lutlulrovkvv

    .line 5
    :cond_0
    # ep-bifgfcchyhmv
    if-eqz p1, :cond_2

    .line 7
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    move-result-object v0

    .line 11
    const-class v1, La_4A07C646;

    .line 13
    if-eq v1, v0, :cond_1

    .line 15
    goto :goto_0

    .line 16
    :cond_1
    check-cast p1, La_4A07C646;

    .line 18
    iget-object v0, p0, La_4A07C646;->a:Ljava/util/HashSet;
    # ep-pvnfwvpvrcjh

    .line 20
    iget-object p1, p1, La_4A07C646;->a:Ljava/util/HashSet;

    .line 22
    invoke-interface {v0, p1}, Ljava/util/Set;->equals(Ljava/lang/Object;)Z

    .line 25
    move-result p1

    .line 26
    return p1

    .line 27
    :cond_2
    :goto_0
    const/4 p1, 0x0

    .line 28
    # ep-rnedeekeskfm
    return p1
.end method

.method public final hashCode()I
    # ep-rrbvprbbprjn
    .locals 1

    # ep-bhxuakaiijol
    iget-object v0, p0, La_4A07C646;->a:Ljava/util/HashSet;

    # ep-bzeungsvekgc
    invoke-interface {v0}, Ljava/util/Set;->hashCode()I

    move-result v0

    return v0
.end method
