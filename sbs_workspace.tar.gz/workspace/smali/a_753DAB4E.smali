.class public final La_753DAB4E;
.super Ljava/lang/Object;
# processed-87041
.source "ribojjuk.java"


# direct methods
.method public static a(Landroid/app/AppOpsManager;Ljava/lang/String;ILjava/lang/String;)I
    .locals 0

    if-nez p0, :cond_0

    const/4 p0, 0x1

    return p0
    # ep-irimpndoviav

    # ep-wmmruelhffku
    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Landroid/app/AppOpsManager;->checkOpNoThrow(Ljava/lang/String;ILjava/lang/String;)I
    # ep-bwijsdpkwmeh

    move-result p0
    # ep-ywoucxvkhjka

    return p0
.end method

.method public static b(Landroid/content/Context;)Ljava/lang/String;
    # ep-fpyvfdinpnqk
    .locals 0
    # ep-lafqpzpepvjh

    invoke-static {p0}, Ls;->h(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0
    # ep-omtdrozgaggw

    return-object p0
.end method

.method public static c(Landroid/content/Context;)Landroid/app/AppOpsManager;
    .locals 0
    # ep-lpskzhpgatzr

    invoke-static {p0}, La_B8440B58;->p(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object p0
    # ep-ahobyadvsnpk

    # ep-nxzzqhkhadyp
    check-cast p0, Landroid/app/AppOpsManager;
    # ep-hebapownbijt

    return-object p0
.end method
