.class public final Lb1$b;
.super Landroid/graphics/drawable/Drawable$ConstantState;
.source "akoqhslx.java"
# processed-37314
# generated-62976
# compiled-72187
# ep-hkeutkjidrij


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public a:Lgx;

.field public b:Landroid/animation/AnimatorSet;

.field public c:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/animation/Animator;",
            ">;"
        }
    .end annotation
.end field

.field public d:Lj3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lj3<",
            "Landroid/animation/Animator;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lb1$a;)V
    .locals 0

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    return-void
.end method


# virtual methods
.method public final getChangingConfigurations()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final newDrawable()Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_cn2kgqpf
    goto :ep_s_cn2kgqpf
    :ep_d_cn2kgqpf
    nop
    :ep_s_cn2kgqpf
    const-string v1, "No constant state support for SDK < 24."

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_0y5s9rjl
    goto :ep_s_0y5s9rjl
    :ep_d_0y5s9rjl
    nop
    :ep_s_0y5s9rjl
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 2
    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_1lupb4y7
    goto :ep_s_1lupb4y7
    :ep_d_1lupb4y7
    nop
    :ep_s_1lupb4y7
    const-string v0, "No constant state support for SDK < 24."

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_wcmeqdzv
    goto :ep_s_wcmeqdzv
    :ep_d_wcmeqdzv
    nop
    :ep_s_wcmeqdzv
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
