.class public final Lb1$b;
.super Landroid/graphics/drawable/Drawable$ConstantState;
# ep-ipvekouixgcn
.source "tvfdtsyv.java"
# compiled-67769
# generated-44012


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public a:Lgx;

.field public b:Landroid/animation/AnimatorSet;

.field public c:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/animation/Animator;",
            ">;"
        }
    .end annotation
.end field

.field public d:Lj3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lj3<",
            "Landroid/animation/Animator;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lb1$a;)V
    .locals 0

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    return-void
.end method


# virtual methods
.method public final getChangingConfigurations()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final newDrawable()Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_4ux7fr3p
    goto :ep_s_4ux7fr3p
    :ep_d_4ux7fr3p
    nop
    :ep_s_4ux7fr3p
    const-string v1, "No constant state support for SDK < 24."

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_qd86inmq
    goto :ep_s_qd86inmq
    :ep_d_qd86inmq
    nop
    :ep_s_qd86inmq
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 2
    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_tayqi0rq
    goto :ep_s_tayqi0rq
    :ep_d_tayqi0rq
    nop
    :ep_s_tayqi0rq
    const-string v0, "No constant state support for SDK < 24."

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_clqgixcn
    goto :ep_s_clqgixcn
    :ep_d_clqgixcn
    nop
    :ep_s_clqgixcn
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
