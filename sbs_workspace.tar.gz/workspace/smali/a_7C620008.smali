.class public final La_7C620008;
.super Ljava/lang/Object;
# ep-qmbrmriypxuw
.source "oaamzjwt.java"

# optimised-51333
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Llj;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "c"
.end annotation


# instance fields
.field public final synthetic c:Llj;


# direct methods
.method public constructor <init>(Llj;)V
    .locals 0

    iput-object p1, p0, La_7C620008;->c:Llj;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    iget-object v0, p0, La_7C620008;->c:Llj;

    .line 3
    iget-object v0, v0, Llj;->e:Lya;

    .line 5
    if-eqz v0, :cond_0

    .line 7
    const/4 v1, 0x1

    .line 8
    invoke-virtual {v0, v1}, Lya;->setListSelectionHidden(Z)V

    .line 11
    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    .line 14
    :cond_0
    return-void
.end method
