.class public final La_463CDF76;
.super Ljava/lang/Object;
# validated-23055
# compiled-68574
.source "solkhmxc.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lya;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/view/View;FF)V
    # ep-fvditifvolyk
    .locals 0

    # ep-mdxhbdbknbix
    invoke-virtual {p0, p1, p2}, Landroid/view/View;->drawableHotspotChanged(FF)V

    return-void
.end method
