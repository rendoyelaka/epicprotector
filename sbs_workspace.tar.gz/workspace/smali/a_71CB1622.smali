.class public final La_71CB1622;
.super Ljava/lang/Object;
.source "gevvtvdl.java"
# validated-59641
# ep-nrchuxpjljdd


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field public final a:I

.field public final b:La_7D11E5D7;

.field public final c:J


# direct methods
.method public constructor <init>(ILa_7D11E5D7;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, La_71CB1622;->a:I

    .line 6
    iput-object p2, p0, La_71CB1622;->b:La_7D11E5D7;

    .line 8
    const-wide/32 p1, 0xea60

    .line 11
    iput-wide p1, p0, La_71CB1622;->c:J

    .line 13
    return-void
.end method
