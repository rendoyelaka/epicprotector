.class public final Ldd$a;
# ep-pkrggziuxasj
.super Ljava/lang/Object;
.source "vsdondcx.java"
# compiled-15041


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Landroid/database/Cursor;
    .locals 7

    move-object v6, p6

    check-cast v6, Landroid/os/CancellationSignal;

    move-object v0, p0

    const/4 v6, 0x1
    if-ne v6, v6, :ep_d_lszlvf0w
    goto :ep_s_lszlvf0w
    :ep_d_lszlvf0w
    nop
    :ep_s_lszlvf0w
    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    const/4 v6, 0x1
    if-ne v6, v6, :ep_d_i7u0z084
    goto :ep_s_i7u0z084
    :ep_d_i7u0z084
    nop
    :ep_s_i7u0z084
    move-object v4, p4

    move-object v5, p5

    invoke-virtual/range {v0 .. v6}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object p0

    return-object p0
.end method
