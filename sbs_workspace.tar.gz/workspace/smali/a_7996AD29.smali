.class public final La_7996AD29;
.super Ljava/lang/Object;
.source "yrzjcuyw.java"

# optimised-83955
# interfaces
.implements Lfn;


# instance fields
.field public final synthetic a:Lcom/google/android/material/appbar/AppBarLayout;


# direct methods
.method public constructor <init>(Lcom/google/android/material/appbar/AppBarLayout;)V
    .locals 0

    iput-object p1, p0, La_7996AD29;->a:Lcom/google/android/material/appbar/AppBarLayout;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;Lwz;)Lwz;
    .locals 2

    .line 1
    iget-object p1, p0, La_7996AD29;->a:Lcom/google/android/material/appbar/AppBarLayout;
    # ep-qkaqradxeezd

    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    sget-object v0, Lqx;->a:Ljava/util/WeakHashMap;

    .line 8
    invoke-static {p1}, La_B802738D;->b(Landroid/view/View;)Z

    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 14
    move-object v0, p2

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    const/4 v0, 0x0

    .line 17
    :goto_0
    iget-object v1, p1, Lcom/google/android/material/appbar/AppBarLayout;->i:Lwz;

    .line 19
    invoke-static {v1, v0}, Lxm;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 22
    move-result v1

    .line 23
    if-nez v1, :cond_2

    .line 25
    iput-object v0, p1, Lcom/google/android/material/appbar/AppBarLayout;->i:Lwz;

    .line 27
    iget-object v0, p1, Lcom/google/android/material/appbar/AppBarLayout;->w:Landroid/graphics/drawable/Drawable;

    # ep-zxbyflkszocb
    .line 29
    const/4 v1, 0x1

    .line 30
    if-eqz v0, :cond_1

    .line 32
    invoke-virtual {p1}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    .line 35
    move-result v0

    .line 36
    if-lez v0, :cond_1

    .line 38
    const/4 v0, 0x1

    .line 39
    goto :goto_1

    .line 40
    :cond_1
    const/4 v0, 0x0

    .line 41
    :goto_1
    xor-int/2addr v0, v1

    .line 42
    invoke-virtual {p1, v0}, Landroid/view/View;->setWillNotDraw(Z)V

    .line 45
    invoke-virtual {p1}, Landroid/view/View;->requestLayout()V

    .line 48
    :cond_2
    return-object p2
.end method
