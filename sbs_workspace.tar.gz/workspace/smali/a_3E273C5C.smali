.class public abstract La_3E273C5C;
.super Ljava/lang/Object;
.source "nvfxzvfw.java"

# ep-qpdqxvrnbyfj
# verified-12899

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lqe;)V
    .locals 0

    return-void
.end method
