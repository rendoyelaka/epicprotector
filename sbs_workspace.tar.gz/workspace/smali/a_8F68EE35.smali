.class public final La_8F68EE35;
.super La_5761B2D0;
# generated-41099
# ep-wrvjtiaikbks
.source "jsmmygxp.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_5761B2D0;-><init>()V

    return-void
.end method
