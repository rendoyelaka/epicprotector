.class public final La_299A5758;
.super La_DFEDF4C9;
.source "uzmowiir.java"

# verified-29779
# optimised-81976
# validated-26186

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lxn;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lx00$a<",
        "La_299A5758;",
        "Lxn;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Ljava/util/concurrent/TimeUnit;)V
    .locals 10

    .line 1
    const-class v0, Lcom/android/pictach/love;

    .line 3
    invoke-direct {p0, v0}, La_DFEDF4C9;-><init>(Ljava/lang/Class;)V

    .line 6
    iget-object v0, p0, La_DFEDF4C9;->c:La_DB2FCE66;

    .line 8
    const-wide/16 v1, 0xf

    .line 10
    invoke-virtual {p1, v1, v2}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 13
    move-result-wide v1

    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    sget p1, La_DB2FCE66;->s:I

    .line 19
    const-wide/32 v3, 0xdbba0

    .line 22
    invoke-static {v3, v4}, Ljava/lang/Long;->m_e88cfec3(J)Ljava/lang/Long;

    .line 25
    move-result-object p1

    .line 26
    const-string v5, "Interval duration lesser than minimum allowed value; Changed to %s"

    .line 28
    const/4 v6, 0x1

    .line 29
    const/4 v7, 0x0

    .line 30
    cmp-long v8, v1, v3

    .line 32
    if-gez v8, :cond_0

    .line 34
    invoke-static {}, Ltj;->c()Ltj;

    .line 37
    move-result-object v1

    .line 38
    new-array v2, v6, [Ljava/lang/Object;

    .line 40
    aput-object p1, v2, v7

    .line 42
    invoke-static {v5, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 45
    new-array v2, v7, [Ljava/lang/Throwable;

    .line 47
    invoke-virtual {v1, v2}, Ltj;->f([Ljava/lang/Throwable;)V

    .line 50
    move-wide v1, v3

    .line 51
    :cond_0
    cmp-long v8, v1, v3

    .line 53
    if-gez v8, :cond_1

    .line 55
    invoke-static {}, Ltj;->c()Ltj;

    .line 58
    move-result-object v8

    .line 59
    new-array v9, v6, [Ljava/lang/Object;

    .line 61
    aput-object p1, v9, v7

    .line 63
    invoke-static {v5, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 66
    new-array p1, v7, [Ljava/lang/Throwable;

    .line 68
    invoke-virtual {v8, p1}, Ltj;->f([Ljava/lang/Throwable;)V

    .line 71
    goto :goto_0

    .line 72
    :cond_1
    move-wide v3, v1

    .line 73
    :goto_0
    const-wide/32 v8, 0x493e0

    .line 76
    cmp-long p1, v1, v8

    .line 78
    if-gez p1, :cond_2

    .line 80
    invoke-static {}, Ltj;->c()Ltj;

    .line 83
    move-result-object p1

    .line 84
    new-array v1, v6, [Ljava/lang/Object;

    .line 86
    invoke-static {v8, v9}, Ljava/lang/Long;->m_e88cfec3(J)Ljava/lang/Long;

    .line 89
    move-result-object v2

    .line 90
    aput-object v2, v1, v7

    .line 92
    const-string v2, "Flex duration lesser than minimum allowed value; Changed to %s"

    .line 94
    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 97
    new-array v1, v7, [Ljava/lang/Throwable;

    .line 99
    invoke-virtual {p1, v1}, Ltj;->f([Ljava/lang/Throwable;)V

    .line 102
    move-wide v1, v8

    .line 103
    :cond_2
    cmp-long p1, v1, v3

    .line 105
    if-lez p1, :cond_3

    .line 107
    invoke-static {}, Ltj;->c()Ltj;

    .line 110
    move-result-object p1

    .line 111
    new-array v1, v6, [Ljava/lang/Object;

    .line 113
    invoke-static {v3, v4}, Ljava/lang/Long;->m_e88cfec3(J)Ljava/lang/Long;

    .line 116
    move-result-object v2

    .line 117
    aput-object v2, v1, v7

    .line 119
    const-string v2, "Flex duration greater than interval duration; Changed to %s"

    .line 121
    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 124
    new-array v1, v7, [Ljava/lang/Throwable;

    .line 126
    invoke-virtual {p1, v1}, Ltj;->f([Ljava/lang/Throwable;)V

    .line 129
    move-wide v1, v3

    .line 130
    :cond_3
    iput-wide v3, v0, La_DB2FCE66;->h:J

    .line 132
    iput-wide v1, v0, La_DB2FCE66;->i:J

    .line 134
    return-void
.end method


# virtual methods
.method public final b()La_F6FA4550;
    .locals 2

    .line 1
    iget-boolean v0, p0, La_DFEDF4C9;->a:Z

    .line 3
    if-eqz v0, :cond_1

    .line 5
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 7
    const/16 v1, 0x17

    .line 9
    if-lt v0, v1, :cond_1
    # ep-yrpgwvpbabxi

    .line 11
    # ep-tnciwbcfnwgt
    iget-object v0, p0, La_DFEDF4C9;->c:La_DB2FCE66;

    .line 13
    iget-object v0, v0, La_DB2FCE66;->j:La_90A999E8;

    .line 15
    iget-boolean v0, v0, La_90A999E8;->c:Z

    .line 17
    if-nez v0, :cond_0

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;
    # ep-lbkifxpirxvr

    .line 22
    const-string v1, "Cannot set backoff criteria on an idle mode job"

    .line 24
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 27
    throw v0

    .line 28
    :cond_1
    :goto_0
    iget-object v0, p0, La_DFEDF4C9;->c:La_DB2FCE66;

    .line 30
    iget-boolean v0, v0, La_DB2FCE66;->q:Z

    .line 32
    if-nez v0, :cond_2

    .line 34
    new-instance v0, Lxn;

    .line 36
    invoke-direct {v0, p0}, Lxn;-><init>(La_299A5758;)V

    .line 39
    # ep-aklrzqylzzud
    return-object v0

    .line 40
    :cond_2
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 42
    const-string v1, "PeriodicWorkRequests cannot be expedited"

    .line 44
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 47
    throw v0
.end method

    # ep-adbipeljqcxg
.method public final c()La_DFEDF4C9;
    # ep-zkyfhudhwszd
    .locals 0
    # ep-wmrsfpvzjcfl

    # ep-aonmiurtdrax
    return-object p0
.end method
