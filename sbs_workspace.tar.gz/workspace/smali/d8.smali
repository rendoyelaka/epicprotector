.class public Ld8;
.super Ljava/lang/Object;
# generated-47201
# verified-74481
# ep-vndmphwcnyan
.source "jvtnkmir.java"


# instance fields
.field public A:F

.field public B:I

.field public C:F

.field public final D:[I

.field public E:F

.field public F:Z

.field public G:Z

.field public H:Z

.field public I:I

.field public J:I

.field public final K:Lv7;

.field public final L:Lv7;

.field public final M:Lv7;

.field public final N:Lv7;

.field public final O:Lv7;

.field public final P:Lv7;

.field public final Q:Lv7;

.field public final R:Lv7;

.field public final S:[Lv7;

.field public final T:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lv7;",
            ">;"
        }
    .end annotation
.end field

.field public final U:[Z

.field public final V:[I

.field public W:Ld8;

.field public X:I

.field public Y:I

.field public Z:F

.field public a:Z

.field public a0:I

.field public b:Ly5;

.field public b0:I

.field public c:Ly5;

.field public c0:I

.field public d:Lng;

.field public d0:I

.field public e:Llx;

.field public e0:I

.field public final f:[Z

.field public f0:I

.field public g:Z

.field public g0:F

.field public final h:Z

.field public h0:F

.field public i:I

.field public i0:Ljava/lang/Object;

.field public j:I

.field public j0:I

.field public k:Ljava/lang/String;

.field public k0:Ljava/lang/String;

.field public l:Z

.field public l0:I

.field public m:Z

.field public m0:I

.field public n:Z

.field public final n0:[F

.field public o:Z

.field public final o0:[Ld8;

.field public p:I

.field public final p0:[Ld8;

.field public q:I

.field public q0:I

.field public r:I

.field public r0:I

.field public s:I

.field public t:I

.field public final u:[I

.field public v:I

.field public w:I

.field public x:F

.field public y:I

.field public z:I


# direct methods
.method public constructor <init>()V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 3
    invoke-direct/range {p0 .. p0}, Ljava/lang/Object;-><init>()V

    .line 6
    const/4 v1, 0x0

    .line 7
    iput-boolean v1, v0, Ld8;->a:Z

    .line 9
    const/4 v2, 0x0

    .line 10
    iput-object v2, v0, Ld8;->d:Lng;

    .line 12
    iput-object v2, v0, Ld8;->e:Llx;

    .line 14
    const/4 v3, 0x2

    .line 15
    new-array v4, v3, [Z

    .line 17
    fill-array-data v4, :array_0

    .line 20
    iput-object v4, v0, Ld8;->f:[Z

    .line 22
    const/4 v4, 0x1

    .line 23
    iput-boolean v4, v0, Ld8;->g:Z

    .line 25
    iput-boolean v4, v0, Ld8;->h:Z

    .line 27
    const/4 v5, -0x1

    .line 28
    iput v5, v0, Ld8;->i:I

    .line 30
    iput v5, v0, Ld8;->j:I

    .line 32
    new-instance v6, Ljava/util/HashMap;

    .line 34
    invoke-direct {v6}, Ljava/util/HashMap;-><init>()V

    .line 37
    iput-boolean v1, v0, Ld8;->l:Z

    .line 39
    iput-boolean v1, v0, Ld8;->m:Z

    .line 41
    iput-boolean v1, v0, Ld8;->n:Z

    .line 43
    iput-boolean v1, v0, Ld8;->o:Z

    .line 45
    iput v5, v0, Ld8;->p:I

    .line 47
    iput v5, v0, Ld8;->q:I

    .line 49
    iput v1, v0, Ld8;->r:I

    .line 51
    iput v1, v0, Ld8;->s:I

    .line 53
    iput v1, v0, Ld8;->t:I

    .line 55
    new-array v6, v3, [I

    .line 57
    iput-object v6, v0, Ld8;->u:[I

    .line 59
    iput v1, v0, Ld8;->v:I

    .line 61
    iput v1, v0, Ld8;->w:I

    .line 63
    const/high16 v6, 0x3f800000    # 1.0f

    .line 65
    iput v6, v0, Ld8;->x:F

    .line 67
    iput v1, v0, Ld8;->y:I

    .line 69
    iput v1, v0, Ld8;->z:I

    .line 71
    iput v6, v0, Ld8;->A:F

    .line 73
    iput v5, v0, Ld8;->B:I

    .line 75
    iput v6, v0, Ld8;->C:F

    .line 77
    new-array v6, v3, [I

    .line 79
    fill-array-data v6, :array_1

    .line 82
    iput-object v6, v0, Ld8;->D:[I

    .line 84
    const/4 v6, 0x0

    .line 85
    iput v6, v0, Ld8;->E:F

    .line 87
    iput-boolean v1, v0, Ld8;->F:Z

    .line 89
    iput-boolean v1, v0, Ld8;->H:Z

    .line 91
    iput v1, v0, Ld8;->I:I

    .line 93
    iput v1, v0, Ld8;->J:I

    .line 95
    new-instance v7, Lv7;

    .line 97
    sget-object v8, Lv7$a;->c:Lv7$a;

    .line 99
    invoke-direct {v7, v0, v8}, Lv7;-><init>(Ld8;Lv7$a;)V

    .line 102
    iput-object v7, v0, Ld8;->K:Lv7;

    .line 104
    new-instance v8, Lv7;

    .line 106
    sget-object v9, Lv7$a;->d:Lv7$a;

    .line 108
    invoke-direct {v8, v0, v9}, Lv7;-><init>(Ld8;Lv7$a;)V

    .line 111
    iput-object v8, v0, Ld8;->L:Lv7;

    .line 113
    new-instance v9, Lv7;

    .line 115
    sget-object v10, Lv7$a;->e:Lv7$a;

    .line 117
    invoke-direct {v9, v0, v10}, Lv7;-><init>(Ld8;Lv7$a;)V

    .line 120
    iput-object v9, v0, Ld8;->M:Lv7;

    .line 122
    new-instance v10, Lv7;

    .line 124
    sget-object v11, Lv7$a;->f:Lv7$a;

    .line 126
    invoke-direct {v10, v0, v11}, Lv7;-><init>(Ld8;Lv7$a;)V

    .line 129
    iput-object v10, v0, Ld8;->N:Lv7;

    .line 131
    new-instance v11, Lv7;

    .line 133
    sget-object v12, Lv7$a;->g:Lv7$a;

    .line 135
    invoke-direct {v11, v0, v12}, Lv7;-><init>(Ld8;Lv7$a;)V

    .line 138
    iput-object v11, v0, Ld8;->O:Lv7;

    .line 140
    new-instance v12, Lv7;

    .line 142
    sget-object v13, Lv7$a;->i:Lv7$a;

    .line 144
    invoke-direct {v12, v0, v13}, Lv7;-><init>(Ld8;Lv7$a;)V

    .line 147
    iput-object v12, v0, Ld8;->P:Lv7;

    .line 149
    new-instance v13, Lv7;

    .line 151
    sget-object v14, Lv7$a;->j:Lv7$a;

    .line 153
    invoke-direct {v13, v0, v14}, Lv7;-><init>(Ld8;Lv7$a;)V

    .line 156
    iput-object v13, v0, Ld8;->Q:Lv7;

    .line 158
    new-instance v14, Lv7;

    .line 160
    sget-object v15, Lv7$a;->h:Lv7$a;

    .line 162
    invoke-direct {v14, v0, v15}, Lv7;-><init>(Ld8;Lv7$a;)V

    .line 165
    iput-object v14, v0, Ld8;->R:Lv7;

    .line 167
    const/4 v15, 0x6

    .line 168
    new-array v15, v15, [Lv7;

    .line 170
    aput-object v7, v15, v1

    .line 172
    aput-object v9, v15, v4

    .line 174
    aput-object v8, v15, v3

    .line 176
    const/16 v16, 0x3

    .line 178
    aput-object v10, v15, v16

    .line 180
    const/16 v16, 0x4

    .line 182
    aput-object v11, v15, v16

    .line 184
    const/16 v16, 0x5

    .line 186
    aput-object v14, v15, v16

    .line 188
    iput-object v15, v0, Ld8;->S:[Lv7;

    .line 190
    new-instance v15, Ljava/util/ArrayList;

    .line 192
    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    .line 195
    iput-object v15, v0, Ld8;->T:Ljava/util/ArrayList;

    .line 197
    new-array v4, v3, [Z

    .line 199
    iput-object v4, v0, Ld8;->U:[Z

    .line 201
    new-array v4, v3, [I

    .line 203
    fill-array-data v4, :array_2

    .line 206
    iput-object v4, v0, Ld8;->V:[I

    .line 208
    iput-object v2, v0, Ld8;->W:Ld8;

    .line 210
    iput v1, v0, Ld8;->X:I

    .line 212
    iput v1, v0, Ld8;->Y:I

    .line 214
    iput v6, v0, Ld8;->Z:F

    .line 216
    iput v5, v0, Ld8;->a0:I

    .line 218
    iput v1, v0, Ld8;->b0:I

    .line 220
    iput v1, v0, Ld8;->c0:I

    .line 222
    iput v1, v0, Ld8;->d0:I

    .line 224
    const/high16 v4, 0x3f000000    # 0.5f

    .line 226
    iput v4, v0, Ld8;->g0:F

    .line 228
    iput v4, v0, Ld8;->h0:F

    .line 230
    iput v1, v0, Ld8;->j0:I

    .line 232
    iput-object v2, v0, Ld8;->k0:Ljava/lang/String;

    .line 234
    iput v1, v0, Ld8;->l0:I

    .line 236
    iput v1, v0, Ld8;->m0:I

    .line 238
    new-array v4, v3, [F

    .line 240
    fill-array-data v4, :array_3

    .line 243
    iput-object v4, v0, Ld8;->n0:[F

    .line 245
    new-array v4, v3, [Ld8;

    .line 247
    aput-object v2, v4, v1

    .line 249
    const/4 v6, 0x1

    .line 250
    aput-object v2, v4, v6

    .line 252
    iput-object v4, v0, Ld8;->o0:[Ld8;

    .line 254
    new-array v3, v3, [Ld8;

    .line 256
    aput-object v2, v3, v1

    .line 258
    aput-object v2, v3, v6

    .line 260
    iput-object v3, v0, Ld8;->p0:[Ld8;

    .line 262
    iput v5, v0, Ld8;->q0:I

    .line 264
    iput v5, v0, Ld8;->r0:I

    .line 266
    invoke-virtual {v15, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 269
    invoke-virtual {v15, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 272
    invoke-virtual {v15, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 275
    invoke-virtual {v15, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 278
    invoke-virtual {v15, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 281
    invoke-virtual {v15, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 284
    invoke-virtual {v15, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 287
    invoke-virtual {v15, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 290
    return-void

    .line 291
    :array_0
    .array-data 1
        0x1t
        0x1t
    .end array-data

    .line 296
    nop

    .line 297
    :array_1
    .array-data 4
        0x7fffffff
        0x7fffffff
    .end array-data

    .line 305
    :array_2
    .array-data 4
        0x1
        0x1
    .end array-data

    .line 313
    :array_3
    .array-data 4
        -0x40800000    # -1.0f
        -0x40800000    # -1.0f
    .end array-data
.end method

.method public static H(IILjava/lang/String;Ljava/lang/StringBuilder;)V
    .locals 0

    .line 1
    if-ne p0, p1, :cond_0

    .line 3
    return-void

    .line 4
    :cond_0
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 7
    const-string p1, " :   "

    .line 9
    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 12
    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 15
    const-string p0, ",\n"

    .line 17
    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    return-void
.end method

.method public static I(Ljava/lang/StringBuilder;Ljava/lang/String;FF)V
    .locals 0

    .line 1
    cmpl-float p3, p2, p3

    .line 3
    if-nez p3, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    const-string p1, " :   "

    .line 11
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 17
    const-string p1, ",\n"

    .line 19
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 22
    return-void
.end method

.method public static p(Ljava/lang/StringBuilder;Ljava/lang/String;IIIIIF)V
    .locals 1

    .line 1
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4
    const-string p1, " :  {\n"

    .line 6
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    const-string p1, "      size"

    .line 11
    const/4 v0, 0x0

    .line 12
    invoke-static {p2, v0, p1, p0}, Ld8;->H(IILjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 15
    const-string p1, "      min"

    .line 17
    invoke-static {p3, v0, p1, p0}, Ld8;->H(IILjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 20
    const-string p1, "      max"

    .line 22
    const p2, 0x7fffffff

    .line 25
    invoke-static {p4, p2, p1, p0}, Ld8;->H(IILjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 28
    const-string p1, "      matchMin"

    .line 30
    invoke-static {p5, v0, p1, p0}, Ld8;->H(IILjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 33
    const-string p1, "      matchDef"

    .line 35
    invoke-static {p6, v0, p1, p0}, Ld8;->H(IILjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 38
    const-string p1, "      matchPercent"

    .line 40
    const/high16 p2, 0x3f800000    # 1.0f

    .line 42
    invoke-static {p0, p1, p7, p2}, Ld8;->I(Ljava/lang/StringBuilder;Ljava/lang/String;FF)V

    .line 45
    const-string p1, "    },\n"

    .line 47
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    return-void
.end method

.method public static q(Ljava/lang/StringBuilder;Ljava/lang/String;Lv7;)V
    .locals 2

    .line 1
    iget-object v0, p2, Lv7;->f:Lv7;

    .line 3
    if-nez v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    const-string v0, "    "

    .line 8
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    const-string p1, " : [ \'"

    .line 16
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 19
    iget-object p1, p2, Lv7;->f:Lv7;

    .line 21
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 24
    const-string p1, "\'"

    .line 26
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    iget p1, p2, Lv7;->h:I

    .line 31
    const/high16 v0, -0x80000000

    .line 33
    if-ne p1, v0, :cond_1

    .line 35
    iget p1, p2, Lv7;->g:I

    .line 37
    if-eqz p1, :cond_2

    .line 39
    :cond_1
    const-string p1, ","

    .line 41
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    iget v1, p2, Lv7;->g:I

    .line 46
    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 49
    iget v1, p2, Lv7;->h:I

    .line 51
    if-eq v1, v0, :cond_2

    .line 53
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    iget p2, p2, Lv7;->h:I

    .line 58
    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 61
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    :cond_2
    const-string p1, " ] ,\n"

    .line 66
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 69
    return-void
.end method


# virtual methods
.method public final A()Z
    .locals 2

    iget-boolean v0, p0, Ld8;->g:Z

    if-eqz v0, :cond_0

    iget v0, p0, Ld8;->j0:I

    const/16 v1, 0x8

    if-eq v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public B()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Ld8;->l:Z

    .line 3
    if-nez v0, :cond_1

    .line 5
    iget-object v0, p0, Ld8;->K:Lv7;

    .line 7
    iget-boolean v0, v0, Lv7;->c:Z

    .line 9
    if-eqz v0, :cond_0

    .line 11
    iget-object v0, p0, Ld8;->M:Lv7;

    .line 13
    iget-boolean v0, v0, Lv7;->c:Z

    .line 15
    if-eqz v0, :cond_0

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const/4 v0, 0x0

    .line 19
    goto :goto_1

    .line 20
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 21
    :goto_1
    return v0
.end method

.method public C()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Ld8;->m:Z

    .line 3
    if-nez v0, :cond_1

    .line 5
    iget-object v0, p0, Ld8;->L:Lv7;

    .line 7
    iget-boolean v0, v0, Lv7;->c:Z

    .line 9
    if-eqz v0, :cond_0

    .line 11
    iget-object v0, p0, Ld8;->N:Lv7;

    .line 13
    iget-boolean v0, v0, Lv7;->c:Z

    .line 15
    if-eqz v0, :cond_0

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const/4 v0, 0x0

    .line 19
    goto :goto_1

    .line 20
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 21
    :goto_1
    return v0
.end method

.method public D()V
    .locals 5

    .line 1
    iget-object v0, p0, Ld8;->K:Lv7;

    .line 3
    invoke-virtual {v0}, Lv7;->j()V

    .line 6
    iget-object v0, p0, Ld8;->L:Lv7;

    .line 8
    invoke-virtual {v0}, Lv7;->j()V

    .line 11
    iget-object v0, p0, Ld8;->M:Lv7;

    .line 13
    invoke-virtual {v0}, Lv7;->j()V

    .line 16
    iget-object v0, p0, Ld8;->N:Lv7;

    .line 18
    invoke-virtual {v0}, Lv7;->j()V

    .line 21
    iget-object v0, p0, Ld8;->O:Lv7;

    .line 23
    invoke-virtual {v0}, Lv7;->j()V

    .line 26
    iget-object v0, p0, Ld8;->P:Lv7;

    .line 28
    invoke-virtual {v0}, Lv7;->j()V

    .line 31
    iget-object v0, p0, Ld8;->Q:Lv7;

    .line 33
    invoke-virtual {v0}, Lv7;->j()V

    .line 36
    iget-object v0, p0, Ld8;->R:Lv7;

    .line 38
    invoke-virtual {v0}, Lv7;->j()V

    .line 41
    const/4 v0, 0x0

    .line 42
    iput-object v0, p0, Ld8;->W:Ld8;

    .line 44
    const/4 v1, 0x0

    .line 45
    iput v1, p0, Ld8;->E:F

    .line 47
    const/4 v2, 0x0

    .line 48
    iput v2, p0, Ld8;->X:I

    .line 50
    iput v2, p0, Ld8;->Y:I

    .line 52
    iput v1, p0, Ld8;->Z:F

    .line 54
    const/4 v1, -0x1

    .line 55
    iput v1, p0, Ld8;->a0:I

    .line 57
    iput v2, p0, Ld8;->b0:I

    .line 59
    iput v2, p0, Ld8;->c0:I

    .line 61
    iput v2, p0, Ld8;->d0:I

    .line 63
    iput v2, p0, Ld8;->e0:I

    .line 65
    iput v2, p0, Ld8;->f0:I

    .line 67
    const/high16 v3, 0x3f000000    # 0.5f

    .line 69
    iput v3, p0, Ld8;->g0:F

    .line 71
    iput v3, p0, Ld8;->h0:F

    .line 73
    iget-object v3, p0, Ld8;->V:[I

    .line 75
    const/4 v4, 0x1

    .line 76
    aput v4, v3, v2

    .line 78
    aput v4, v3, v4

    .line 80
    iput-object v0, p0, Ld8;->i0:Ljava/lang/Object;

    .line 82
    iput v2, p0, Ld8;->j0:I

    .line 84
    iput v2, p0, Ld8;->l0:I

    .line 86
    iput v2, p0, Ld8;->m0:I

    .line 88
    iget-object v0, p0, Ld8;->n0:[F

    .line 90
    const/high16 v3, -0x40800000    # -1.0f

    .line 92
    aput v3, v0, v2

    .line 94
    aput v3, v0, v4

    .line 96
    iput v1, p0, Ld8;->p:I

    .line 98
    iput v1, p0, Ld8;->q:I

    .line 100
    iget-object v0, p0, Ld8;->D:[I

    .line 102
    const v3, 0x7fffffff

    .line 105
    aput v3, v0, v2

    .line 107
    aput v3, v0, v4

    .line 109
    iput v2, p0, Ld8;->s:I

    .line 111
    iput v2, p0, Ld8;->t:I

    .line 113
    const/high16 v0, 0x3f800000    # 1.0f

    .line 115
    iput v0, p0, Ld8;->x:F

    .line 117
    iput v0, p0, Ld8;->A:F

    .line 119
    iput v3, p0, Ld8;->w:I

    .line 121
    iput v3, p0, Ld8;->z:I

    .line 123
    iput v2, p0, Ld8;->v:I

    .line 125
    iput v2, p0, Ld8;->y:I

    .line 127
    iput v1, p0, Ld8;->B:I

    .line 129
    iput v0, p0, Ld8;->C:F

    .line 131
    iget-object v0, p0, Ld8;->f:[Z

    .line 133
    aput-boolean v4, v0, v2

    .line 135
    aput-boolean v4, v0, v4

    .line 137
    iput-boolean v2, p0, Ld8;->H:Z

    .line 139
    iget-object v0, p0, Ld8;->U:[Z

    .line 141
    aput-boolean v2, v0, v2

    .line 143
    aput-boolean v2, v0, v4

    .line 145
    iput-boolean v4, p0, Ld8;->g:Z

    .line 147
    iget-object v0, p0, Ld8;->u:[I

    .line 149
    aput v2, v0, v2

    .line 151
    aput v2, v0, v4

    .line 153
    iput v1, p0, Ld8;->i:I

    .line 155
    iput v1, p0, Ld8;->j:I

    .line 157
    return-void
.end method

.method public final E()V
    .locals 4

    .line 1
    iget-object v0, p0, Ld8;->W:Ld8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    instance-of v1, v0, Le8;

    .line 7
    if-eqz v1, :cond_0

    .line 9
    check-cast v0, Le8;

    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    :cond_0
    iget-object v0, p0, Ld8;->T:Ljava/util/ArrayList;

    .line 16
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 19
    move-result v1

    .line 20
    const/4 v2, 0x0

    .line 21
    :goto_0
    if-ge v2, v1, :cond_1

    .line 23
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 26
    move-result-object v3

    .line 27
    check-cast v3, Lv7;

    .line 29
    invoke-virtual {v3}, Lv7;->j()V

    .line 32
    add-int/lit8 v2, v2, 0x1

    .line 34
    goto :goto_0

    .line 35
    :cond_1
    return-void
.end method

.method public final F()V
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Ld8;->l:Z

    .line 4
    iput-boolean v0, p0, Ld8;->m:Z

    .line 6
    iput-boolean v0, p0, Ld8;->n:Z

    .line 8
    iput-boolean v0, p0, Ld8;->o:Z

    .line 10
    iget-object v1, p0, Ld8;->T:Ljava/util/ArrayList;

    .line 12
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 15
    move-result v2

    .line 16
    const/4 v3, 0x0

    .line 17
    :goto_0
    if-ge v3, v2, :cond_0

    .line 19
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 22
    move-result-object v4

    .line 23
    check-cast v4, Lv7;

    .line 25
    iput-boolean v0, v4, Lv7;->c:Z

    .line 27
    iput v0, v4, Lv7;->b:I

    .line 29
    add-int/lit8 v3, v3, 0x1

    .line 31
    goto :goto_0

    .line 32
    :cond_0
    return-void
.end method

.method public G(La5;)V
    .locals 0

    .line 1
    iget-object p1, p0, Ld8;->K:Lv7;

    .line 3
    invoke-virtual {p1}, Lv7;->k()V

    .line 6
    iget-object p1, p0, Ld8;->L:Lv7;

    .line 8
    invoke-virtual {p1}, Lv7;->k()V

    .line 11
    iget-object p1, p0, Ld8;->M:Lv7;

    .line 13
    invoke-virtual {p1}, Lv7;->k()V

    .line 16
    iget-object p1, p0, Ld8;->N:Lv7;

    .line 18
    invoke-virtual {p1}, Lv7;->k()V

    .line 21
    iget-object p1, p0, Ld8;->O:Lv7;

    .line 23
    invoke-virtual {p1}, Lv7;->k()V

    .line 26
    iget-object p1, p0, Ld8;->R:Lv7;

    .line 28
    invoke-virtual {p1}, Lv7;->k()V

    .line 31
    iget-object p1, p0, Ld8;->P:Lv7;

    .line 33
    invoke-virtual {p1}, Lv7;->k()V

    .line 36
    iget-object p1, p0, Ld8;->Q:Lv7;

    .line 38
    invoke-virtual {p1}, Lv7;->k()V

    .line 41
    return-void
.end method

.method public final J(II)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Ld8;->l:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    iget-object v0, p0, Ld8;->K:Lv7;

    .line 8
    invoke-virtual {v0, p1}, Lv7;->l(I)V

    .line 11
    iget-object v0, p0, Ld8;->M:Lv7;

    .line 13
    invoke-virtual {v0, p2}, Lv7;->l(I)V

    .line 16
    iput p1, p0, Ld8;->b0:I

    .line 18
    sub-int/2addr p2, p1

    .line 19
    iput p2, p0, Ld8;->X:I

    .line 21
    const/4 p1, 0x1

    .line 22
    iput-boolean p1, p0, Ld8;->l:Z

    .line 24
    return-void
.end method

.method public final K(II)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Ld8;->m:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    iget-object v0, p0, Ld8;->L:Lv7;

    .line 8
    invoke-virtual {v0, p1}, Lv7;->l(I)V

    .line 11
    iget-object v0, p0, Ld8;->N:Lv7;

    .line 13
    invoke-virtual {v0, p2}, Lv7;->l(I)V

    .line 16
    iput p1, p0, Ld8;->c0:I

    .line 18
    sub-int/2addr p2, p1

    .line 19
    iput p2, p0, Ld8;->Y:I

    .line 21
    iget-boolean p2, p0, Ld8;->F:Z

    .line 23
    if-eqz p2, :cond_1

    .line 25
    iget p2, p0, Ld8;->d0:I

    .line 27
    add-int/2addr p1, p2

    .line 28
    iget-object p2, p0, Ld8;->O:Lv7;

    .line 30
    invoke-virtual {p2, p1}, Lv7;->l(I)V

    .line 33
    :cond_1
    const/4 p1, 0x1

    .line 34
    iput-boolean p1, p0, Ld8;->m:Z

    .line 36
    return-void
.end method

.method public final L(I)V
    .locals 1

    .line 1
    iput p1, p0, Ld8;->Y:I

    .line 3
    iget v0, p0, Ld8;->f0:I

    .line 5
    if-ge p1, v0, :cond_0

    .line 7
    iput v0, p0, Ld8;->Y:I

    .line 9
    :cond_0
    return-void
.end method

.method public final M(I)V
    .locals 2

    iget-object v0, p0, Ld8;->V:[I

    const/4 v1, 0x0

    aput p1, v0, v1

    return-void
.end method

.method public final N(I)V
    .locals 2

    iget-object v0, p0, Ld8;->V:[I

    const/4 v1, 0x1

    aput p1, v0, v1

    return-void
.end method

.method public final O(I)V
    .locals 1

    .line 1
    iput p1, p0, Ld8;->X:I

    .line 3
    iget v0, p0, Ld8;->e0:I

    .line 5
    if-ge p1, v0, :cond_0

    .line 7
    iput v0, p0, Ld8;->X:I

    .line 9
    :cond_0
    return-void
.end method

.method public P(ZZ)V
    .locals 7

    .line 1
    iget-object v0, p0, Ld8;->d:Lng;

    .line 3
    iget-boolean v1, v0, Loz;->g:Z

    .line 5
    and-int/2addr p1, v1

    .line 6
    iget-object v1, p0, Ld8;->e:Llx;

    .line 8
    iget-boolean v2, v1, Loz;->g:Z

    .line 10
    and-int/2addr p2, v2

    .line 11
    iget-object v2, v0, Loz;->h:Lda;

    .line 13
    iget v2, v2, Lda;->g:I

    .line 15
    iget-object v3, v1, Loz;->h:Lda;

    .line 17
    iget v3, v3, Lda;->g:I

    .line 19
    iget-object v0, v0, Loz;->i:Lda;

    .line 21
    iget v0, v0, Lda;->g:I

    .line 23
    iget-object v1, v1, Loz;->i:Lda;

    .line 25
    iget v1, v1, Lda;->g:I

    .line 27
    sub-int v4, v0, v2

    .line 29
    sub-int v5, v1, v3

    .line 31
    const/4 v6, 0x0

    .line 32
    if-ltz v4, :cond_0

    .line 34
    if-ltz v5, :cond_0

    .line 36
    const/high16 v4, -0x80000000

    .line 38
    if-eq v2, v4, :cond_0

    .line 40
    const v5, 0x7fffffff

    .line 43
    if-eq v2, v5, :cond_0

    .line 45
    if-eq v3, v4, :cond_0

    .line 47
    if-eq v3, v5, :cond_0

    .line 49
    if-eq v0, v4, :cond_0

    .line 51
    if-eq v0, v5, :cond_0

    .line 53
    if-eq v1, v4, :cond_0

    .line 55
    if-ne v1, v5, :cond_1

    .line 57
    :cond_0
    const/4 v0, 0x0

    .line 58
    const/4 v1, 0x0

    .line 59
    const/4 v2, 0x0

    .line 60
    const/4 v3, 0x0

    .line 61
    :cond_1
    sub-int/2addr v0, v2

    .line 62
    sub-int/2addr v1, v3

    .line 63
    if-eqz p1, :cond_2

    .line 65
    iput v2, p0, Ld8;->b0:I

    .line 67
    :cond_2
    if-eqz p2, :cond_3

    .line 69
    iput v3, p0, Ld8;->c0:I

    .line 71
    :cond_3
    iget v2, p0, Ld8;->j0:I

    .line 73
    const/16 v3, 0x8

    .line 75
    if-ne v2, v3, :cond_4

    .line 77
    iput v6, p0, Ld8;->X:I

    .line 79
    iput v6, p0, Ld8;->Y:I

    .line 81
    return-void

    .line 82
    :cond_4
    const/4 v2, 0x1

    .line 83
    iget-object v3, p0, Ld8;->V:[I

    .line 85
    if-eqz p1, :cond_6

    .line 87
    aget p1, v3, v6

    .line 89
    if-ne p1, v2, :cond_5

    .line 91
    iget p1, p0, Ld8;->X:I

    .line 93
    if-ge v0, p1, :cond_5

    .line 95
    move v0, p1

    .line 96
    :cond_5
    iput v0, p0, Ld8;->X:I

    .line 98
    iget p1, p0, Ld8;->e0:I

    .line 100
    if-ge v0, p1, :cond_6

    .line 102
    iput p1, p0, Ld8;->X:I

    .line 104
    :cond_6
    if-eqz p2, :cond_8

    .line 106
    aget p1, v3, v2

    .line 108
    if-ne p1, v2, :cond_7

    .line 110
    iget p1, p0, Ld8;->Y:I

    .line 112
    if-ge v1, p1, :cond_7

    .line 114
    move v1, p1

    .line 115
    :cond_7
    iput v1, p0, Ld8;->Y:I

    .line 117
    iget p1, p0, Ld8;->f0:I

    .line 119
    if-ge v1, p1, :cond_8

    .line 121
    iput p1, p0, Ld8;->Y:I

    .line 123
    :cond_8
    return-void
.end method

.method public Q(Ljj;Z)V
    .locals 6

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    iget-object p1, p0, Ld8;->K:Lv7;

    .line 6
    invoke-static {p1}, Ljj;->n(Lv7;)I

    .line 9
    move-result p1

    .line 10
    iget-object v0, p0, Ld8;->L:Lv7;

    .line 12
    invoke-static {v0}, Ljj;->n(Lv7;)I

    .line 15
    move-result v0

    .line 16
    iget-object v1, p0, Ld8;->M:Lv7;

    .line 18
    invoke-static {v1}, Ljj;->n(Lv7;)I

    .line 21
    move-result v1

    .line 22
    iget-object v2, p0, Ld8;->N:Lv7;

    .line 24
    invoke-static {v2}, Ljj;->n(Lv7;)I

    .line 27
    move-result v2

    .line 28
    if-eqz p2, :cond_0

    .line 30
    iget-object v3, p0, Ld8;->d:Lng;

    .line 32
    if-eqz v3, :cond_0

    .line 34
    iget-object v4, v3, Loz;->h:Lda;

    .line 36
    iget-boolean v5, v4, Lda;->j:Z

    .line 38
    if-eqz v5, :cond_0

    .line 40
    iget-object v3, v3, Loz;->i:Lda;

    .line 42
    iget-boolean v5, v3, Lda;->j:Z

    .line 44
    if-eqz v5, :cond_0

    .line 46
    iget p1, v4, Lda;->g:I

    .line 48
    iget v1, v3, Lda;->g:I

    .line 50
    :cond_0
    if-eqz p2, :cond_1

    .line 52
    iget-object p2, p0, Ld8;->e:Llx;

    .line 54
    if-eqz p2, :cond_1

    .line 56
    iget-object v3, p2, Loz;->h:Lda;

    .line 58
    iget-boolean v4, v3, Lda;->j:Z

    .line 60
    if-eqz v4, :cond_1

    .line 62
    iget-object p2, p2, Loz;->i:Lda;

    .line 64
    iget-boolean v4, p2, Lda;->j:Z

    .line 66
    if-eqz v4, :cond_1

    .line 68
    iget v0, v3, Lda;->g:I

    .line 70
    iget v2, p2, Lda;->g:I

    .line 72
    :cond_1
    sub-int p2, v1, p1

    .line 74
    sub-int v3, v2, v0

    .line 76
    const/4 v4, 0x0

    .line 77
    if-ltz p2, :cond_2

    .line 79
    if-ltz v3, :cond_2

    .line 81
    const/high16 p2, -0x80000000

    .line 83
    if-eq p1, p2, :cond_2

    .line 85
    const v3, 0x7fffffff

    .line 88
    if-eq p1, v3, :cond_2

    .line 90
    if-eq v0, p2, :cond_2

    .line 92
    if-eq v0, v3, :cond_2

    .line 94
    if-eq v1, p2, :cond_2

    .line 96
    if-eq v1, v3, :cond_2

    .line 98
    if-eq v2, p2, :cond_2

    .line 100
    if-ne v2, v3, :cond_3

    .line 102
    :cond_2
    const/4 p1, 0x0

    .line 103
    const/4 v0, 0x0

    .line 104
    const/4 v1, 0x0

    .line 105
    const/4 v2, 0x0

    .line 106
    :cond_3
    sub-int/2addr v1, p1

    .line 107
    sub-int/2addr v2, v0

    .line 108
    iput p1, p0, Ld8;->b0:I

    .line 110
    iput v0, p0, Ld8;->c0:I

    .line 112
    iget p1, p0, Ld8;->j0:I

    .line 114
    const/16 p2, 0x8

    .line 116
    if-ne p1, p2, :cond_4

    .line 118
    iput v4, p0, Ld8;->X:I

    .line 120
    iput v4, p0, Ld8;->Y:I

    .line 122
    goto :goto_0

    .line 123
    :cond_4
    iget-object p1, p0, Ld8;->V:[I

    .line 125
    aget p2, p1, v4

    .line 127
    const/4 v0, 0x1

    .line 128
    if-ne p2, v0, :cond_5

    .line 130
    iget v3, p0, Ld8;->X:I

    .line 132
    if-ge v1, v3, :cond_5

    .line 134
    move v1, v3

    .line 135
    :cond_5
    aget v3, p1, v0

    .line 137
    if-ne v3, v0, :cond_6

    .line 139
    iget v3, p0, Ld8;->Y:I

    .line 141
    if-ge v2, v3, :cond_6

    .line 143
    move v2, v3

    .line 144
    :cond_6
    iput v1, p0, Ld8;->X:I

    .line 146
    iput v2, p0, Ld8;->Y:I

    .line 148
    iget v3, p0, Ld8;->f0:I

    .line 150
    if-ge v2, v3, :cond_7

    .line 152
    iput v3, p0, Ld8;->Y:I

    .line 154
    :cond_7
    iget v3, p0, Ld8;->e0:I

    .line 156
    if-ge v1, v3, :cond_8

    .line 158
    iput v3, p0, Ld8;->X:I

    .line 160
    :cond_8
    iget v3, p0, Ld8;->w:I

    .line 162
    const/4 v4, 0x3

    .line 163
    if-lez v3, :cond_9

    .line 165
    if-ne p2, v4, :cond_9

    .line 167
    iget p2, p0, Ld8;->X:I

    .line 169
    invoke-static {p2, v3}, Ljava/lang/Math;->min(II)I

    .line 172
    move-result p2

    .line 173
    iput p2, p0, Ld8;->X:I

    .line 175
    :cond_9
    iget p2, p0, Ld8;->z:I

    .line 177
    if-lez p2, :cond_a

    .line 179
    aget p1, p1, v0

    .line 181
    if-ne p1, v4, :cond_a

    .line 183
    iget p1, p0, Ld8;->Y:I

    .line 185
    invoke-static {p1, p2}, Ljava/lang/Math;->min(II)I

    .line 188
    move-result p1

    .line 189
    iput p1, p0, Ld8;->Y:I

    .line 191
    :cond_a
    iget p1, p0, Ld8;->X:I

    .line 193
    if-eq v1, p1, :cond_b

    .line 195
    iput p1, p0, Ld8;->i:I

    .line 197
    :cond_b
    iget p1, p0, Ld8;->Y:I

    .line 199
    if-eq v2, p1, :cond_c

    .line 201
    iput p1, p0, Ld8;->j:I

    .line 203
    :cond_c
    :goto_0
    return-void
.end method

.method public final b(Le8;Ljj;Ljava/util/HashSet;IZ)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Le8;",
            "Ljj;",
            "Ljava/util/HashSet<",
            "Ld8;",
            ">;IZ)V"
        }
    .end annotation

    .line 1
    if-eqz p5, :cond_1

    .line 3
    invoke-virtual {p3, p0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 6
    move-result p5

    .line 7
    if-nez p5, :cond_0

    .line 9
    return-void

    .line 10
    :cond_0
    invoke-static {p1, p2, p0}, Lp2;->k(Le8;Ljj;Ld8;)V

    .line 13
    invoke-virtual {p3, p0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 16
    const/16 p5, 0x40

    .line 18
    invoke-virtual {p1, p5}, Le8;->W(I)Z

    .line 21
    move-result p5

    .line 22
    invoke-virtual {p0, p2, p5}, Ld8;->c(Ljj;Z)V

    .line 25
    :cond_1
    if-nez p4, :cond_3

    .line 27
    iget-object p5, p0, Ld8;->K:Lv7;

    .line 29
    iget-object p5, p5, Lv7;->a:Ljava/util/HashSet;

    .line 31
    if-eqz p5, :cond_2

    .line 33
    invoke-virtual {p5}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 36
    move-result-object p5

    .line 37
    :goto_0
    invoke-interface {p5}, Ljava/util/Iterator;->hasNext()Z

    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_2

    .line 43
    invoke-interface {p5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 46
    move-result-object v0

    .line 47
    check-cast v0, Lv7;

    .line 49
    iget-object v1, v0, Lv7;->d:Ld8;

    .line 51
    const/4 v6, 0x1

    .line 52
    move-object v2, p1

    .line 53
    move-object v3, p2

    .line 54
    move-object v4, p3

    .line 55
    move v5, p4

    .line 56
    invoke-virtual/range {v1 .. v6}, Ld8;->b(Le8;Ljj;Ljava/util/HashSet;IZ)V

    .line 59
    goto :goto_0

    .line 60
    :cond_2
    iget-object p5, p0, Ld8;->M:Lv7;

    .line 62
    iget-object p5, p5, Lv7;->a:Ljava/util/HashSet;

    .line 64
    if-eqz p5, :cond_6

    .line 66
    invoke-virtual {p5}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 69
    move-result-object p5

    .line 70
    :goto_1
    invoke-interface {p5}, Ljava/util/Iterator;->hasNext()Z

    .line 73
    move-result v0

    .line 74
    if-eqz v0, :cond_6

    .line 76
    invoke-interface {p5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 79
    move-result-object v0

    .line 80
    check-cast v0, Lv7;

    .line 82
    iget-object v1, v0, Lv7;->d:Ld8;

    .line 84
    const/4 v6, 0x1

    .line 85
    move-object v2, p1

    .line 86
    move-object v3, p2

    .line 87
    move-object v4, p3

    .line 88
    move v5, p4

    .line 89
    invoke-virtual/range {v1 .. v6}, Ld8;->b(Le8;Ljj;Ljava/util/HashSet;IZ)V

    .line 92
    goto :goto_1

    .line 93
    :cond_3
    iget-object p5, p0, Ld8;->L:Lv7;

    .line 95
    iget-object p5, p5, Lv7;->a:Ljava/util/HashSet;

    .line 97
    if-eqz p5, :cond_4

    .line 99
    invoke-virtual {p5}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 102
    move-result-object p5

    .line 103
    :goto_2
    invoke-interface {p5}, Ljava/util/Iterator;->hasNext()Z

    .line 106
    move-result v0

    .line 107
    if-eqz v0, :cond_4

    .line 109
    invoke-interface {p5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 112
    move-result-object v0

    .line 113
    check-cast v0, Lv7;

    .line 115
    iget-object v1, v0, Lv7;->d:Ld8;

    .line 117
    const/4 v6, 0x1

    .line 118
    move-object v2, p1

    .line 119
    move-object v3, p2

    .line 120
    move-object v4, p3

    .line 121
    move v5, p4

    .line 122
    invoke-virtual/range {v1 .. v6}, Ld8;->b(Le8;Ljj;Ljava/util/HashSet;IZ)V

    .line 125
    goto :goto_2

    .line 126
    :cond_4
    iget-object p5, p0, Ld8;->N:Lv7;

    .line 128
    iget-object p5, p5, Lv7;->a:Ljava/util/HashSet;

    .line 130
    if-eqz p5, :cond_5

    .line 132
    invoke-virtual {p5}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 135
    move-result-object p5

    .line 136
    :goto_3
    invoke-interface {p5}, Ljava/util/Iterator;->hasNext()Z

    .line 139
    move-result v0

    .line 140
    if-eqz v0, :cond_5

    .line 142
    invoke-interface {p5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 145
    move-result-object v0

    .line 146
    check-cast v0, Lv7;

    .line 148
    iget-object v1, v0, Lv7;->d:Ld8;

    .line 150
    const/4 v6, 0x1

    .line 151
    move-object v2, p1

    .line 152
    move-object v3, p2

    .line 153
    move-object v4, p3

    .line 154
    move v5, p4

    .line 155
    invoke-virtual/range {v1 .. v6}, Ld8;->b(Le8;Ljj;Ljava/util/HashSet;IZ)V

    .line 158
    goto :goto_3

    .line 159
    :cond_5
    iget-object p5, p0, Ld8;->O:Lv7;

    .line 161
    iget-object p5, p5, Lv7;->a:Ljava/util/HashSet;

    .line 163
    if-eqz p5, :cond_6

    .line 165
    invoke-virtual {p5}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 168
    move-result-object p5

    .line 169
    :goto_4
    invoke-interface {p5}, Ljava/util/Iterator;->hasNext()Z

    .line 172
    move-result v0

    .line 173
    if-eqz v0, :cond_6

    .line 175
    invoke-interface {p5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 178
    move-result-object v0

    .line 179
    check-cast v0, Lv7;

    .line 181
    iget-object v1, v0, Lv7;->d:Ld8;

    .line 183
    const/4 v6, 0x1

    .line 184
    move-object v2, p1

    .line 185
    move-object v3, p2

    .line 186
    move-object v4, p3

    .line 187
    move v5, p4

    .line 188
    :try_start_0
    invoke-virtual/range {v1 .. v6}, Ld8;->b(Le8;Ljj;Ljava/util/HashSet;IZ)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 191
    goto :goto_4

    .line 192
    :catchall_0
    move-exception p1

    .line 193
    throw p1

    .line 194
    :cond_6
    return-void
.end method

.method public c(Ljj;Z)V
    .locals 62

    move-object/from16 v15, p0

    move-object/from16 v14, p1

    .line 1
    iget-object v0, v15, Ld8;->K:Lv7;

    invoke-virtual {v14, v0}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v13

    .line 2
    iget-object v1, v15, Ld8;->M:Lv7;

    invoke-virtual {v14, v1}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v12

    .line 3
    iget-object v2, v15, Ld8;->L:Lv7;

    invoke-virtual {v14, v2}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v11

    .line 4
    iget-object v10, v15, Ld8;->N:Lv7;

    invoke-virtual {v14, v10}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v9

    .line 5
    iget-object v8, v15, Ld8;->O:Lv7;

    invoke-virtual {v14, v8}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v7

    .line 6
    iget-object v3, v15, Ld8;->W:Ld8;

    const/4 v4, 0x2

    const/4 v6, 0x0

    if-eqz v3, :cond_3

    .line 7
    iget-object v3, v3, Ld8;->V:[I

    aget v5, v3, v6

    if-ne v5, v4, :cond_0

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    :goto_0
    const/4 v6, 0x1

    .line 8
    aget v3, v3, v6

    if-ne v3, v4, :cond_1

    const/16 v19, 0x1

    goto :goto_1

    :cond_1
    const/16 v19, 0x0

    .line 9
    :goto_1
    iget v3, v15, Ld8;->r:I

    if-eq v3, v6, :cond_2

    if-eq v3, v4, :cond_4

    const/4 v6, 0x3

    if-eq v3, v6, :cond_3

    move/from16 v29, v5

    move/from16 v28, v19

    goto :goto_2

    :cond_2
    move/from16 v29, v5

    const/16 v28, 0x0

    goto :goto_2

    :cond_3
    const/16 v19, 0x0

    :cond_4
    move/from16 v28, v19

    const/16 v29, 0x0

    .line 10
    :goto_2
    iget v3, v15, Ld8;->j0:I

    const/16 v6, 0x8

    iget-object v5, v15, Ld8;->U:[Z

    if-ne v3, v6, :cond_9

    .line 11
    iget-object v3, v15, Ld8;->T:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v6, 0x0

    :goto_3
    if-ge v6, v4, :cond_8

    .line 12
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v21

    move-object/from16 v22, v3

    move-object/from16 v3, v21

    check-cast v3, Lv7;

    .line 13
    iget-object v3, v3, Lv7;->a:Ljava/util/HashSet;

    if-nez v3, :cond_5

    goto :goto_4

    .line 14
    :cond_5
    invoke-virtual {v3}, Ljava/util/HashSet;->size()I

    move-result v3

    if-lez v3, :cond_6

    const/4 v3, 0x1

    goto :goto_5

    :cond_6
    :goto_4
    const/4 v3, 0x0

    :goto_5
    if-eqz v3, :cond_7

    const/4 v3, 0x1

    goto :goto_6

    :cond_7
    add-int/lit8 v6, v6, 0x1

    move-object/from16 v3, v22

    goto :goto_3

    :cond_8
    const/4 v3, 0x0

    :goto_6
    if-nez v3, :cond_9

    const/4 v3, 0x0

    .line 15
    aget-boolean v4, v5, v3

    if-nez v4, :cond_9

    const/4 v3, 0x1

    aget-boolean v4, v5, v3

    if-nez v4, :cond_9

    return-void

    .line 16
    :cond_9
    iget-boolean v3, v15, Ld8;->l:Z

    if-nez v3, :cond_b

    iget-boolean v4, v15, Ld8;->m:Z

    if-eqz v4, :cond_a

    goto :goto_7

    :cond_a
    move-object/from16 v22, v5

    const/4 v6, 0x5

    goto/16 :goto_e

    .line 17
    :cond_b
    :goto_7
    iget-boolean v4, v15, Ld8;->h:Z

    if-eqz v3, :cond_10

    .line 18
    iget v3, v15, Ld8;->b0:I

    invoke-virtual {v14, v13, v3}, Ljj;->d(Lqs;I)V

    .line 19
    iget v3, v15, Ld8;->b0:I

    iget v6, v15, Ld8;->X:I

    add-int/2addr v3, v6

    invoke-virtual {v14, v12, v3}, Ljj;->d(Lqs;I)V

    if-eqz v29, :cond_10

    .line 20
    iget-object v3, v15, Ld8;->W:Ld8;

    if-eqz v3, :cond_10

    if-eqz v4, :cond_f

    .line 21
    check-cast v3, Le8;

    .line 22
    iget-object v6, v3, Le8;->J0:Ljava/lang/ref/WeakReference;

    if-eqz v6, :cond_c

    invoke-virtual {v6}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v6

    if-eqz v6, :cond_c

    .line 23
    invoke-virtual {v0}, Lv7;->d()I

    move-result v6

    move-object/from16 v22, v5

    iget-object v5, v3, Le8;->J0:Ljava/lang/ref/WeakReference;

    invoke-virtual {v5}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lv7;

    invoke-virtual {v5}, Lv7;->d()I

    move-result v5

    if-le v6, v5, :cond_d

    goto :goto_8

    :cond_c
    move-object/from16 v22, v5

    .line 24
    :goto_8
    new-instance v5, Ljava/lang/ref/WeakReference;

    invoke-direct {v5, v0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v5, v3, Le8;->J0:Ljava/lang/ref/WeakReference;

    .line 25
    :cond_d
    iget-object v5, v3, Le8;->L0:Ljava/lang/ref/WeakReference;

    if-eqz v5, :cond_e

    invoke-virtual {v5}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v5

    if-eqz v5, :cond_e

    .line 26
    invoke-virtual {v1}, Lv7;->d()I

    move-result v5

    iget-object v6, v3, Le8;->L0:Ljava/lang/ref/WeakReference;

    invoke-virtual {v6}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lv7;

    invoke-virtual {v6}, Lv7;->d()I

    move-result v6

    if-le v5, v6, :cond_11

    .line 27
    :cond_e
    new-instance v5, Ljava/lang/ref/WeakReference;

    invoke-direct {v5, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v5, v3, Le8;->L0:Ljava/lang/ref/WeakReference;

    goto :goto_9

    :cond_f
    move-object/from16 v22, v5

    .line 28
    iget-object v3, v3, Ld8;->M:Lv7;

    invoke-virtual {v14, v3}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v14, v3, v12, v6, v5}, Ljj;->f(Lqs;Lqs;II)V

    goto :goto_9

    :cond_10
    move-object/from16 v22, v5

    .line 29
    :cond_11
    :goto_9
    iget-boolean v3, v15, Ld8;->m:Z

    if-eqz v3, :cond_19

    .line 30
    iget v3, v15, Ld8;->c0:I

    invoke-virtual {v14, v11, v3}, Ljj;->d(Lqs;I)V

    .line 31
    iget v3, v15, Ld8;->c0:I

    iget v5, v15, Ld8;->Y:I

    add-int/2addr v3, v5

    invoke-virtual {v14, v9, v3}, Ljj;->d(Lqs;I)V

    .line 32
    iget-object v3, v8, Lv7;->a:Ljava/util/HashSet;

    if-nez v3, :cond_12

    goto :goto_a

    .line 33
    :cond_12
    invoke-virtual {v3}, Ljava/util/HashSet;->size()I

    move-result v3

    if-lez v3, :cond_13

    const/4 v3, 0x1

    goto :goto_b

    :cond_13
    :goto_a
    const/4 v3, 0x0

    :goto_b
    if-eqz v3, :cond_14

    .line 34
    iget v3, v15, Ld8;->c0:I

    iget v5, v15, Ld8;->d0:I

    add-int/2addr v3, v5

    invoke-virtual {v14, v7, v3}, Ljj;->d(Lqs;I)V

    :cond_14
    if-eqz v28, :cond_19

    .line 35
    iget-object v3, v15, Ld8;->W:Ld8;

    if-eqz v3, :cond_19

    if-eqz v4, :cond_18

    .line 36
    check-cast v3, Le8;

    .line 37
    iget-object v4, v3, Le8;->I0:Ljava/lang/ref/WeakReference;

    if-eqz v4, :cond_15

    invoke-virtual {v4}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_15

    .line 38
    invoke-virtual {v2}, Lv7;->d()I

    move-result v4

    iget-object v5, v3, Le8;->I0:Ljava/lang/ref/WeakReference;

    invoke-virtual {v5}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lv7;

    invoke-virtual {v5}, Lv7;->d()I

    move-result v5

    if-le v4, v5, :cond_16

    .line 39
    :cond_15
    new-instance v4, Ljava/lang/ref/WeakReference;

    invoke-direct {v4, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v4, v3, Le8;->I0:Ljava/lang/ref/WeakReference;

    .line 40
    :cond_16
    iget-object v4, v3, Le8;->K0:Ljava/lang/ref/WeakReference;

    if-eqz v4, :cond_17

    invoke-virtual {v4}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_17

    .line 41
    invoke-virtual {v10}, Lv7;->d()I

    move-result v4

    iget-object v5, v3, Le8;->K0:Ljava/lang/ref/WeakReference;

    invoke-virtual {v5}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lv7;

    invoke-virtual {v5}, Lv7;->d()I

    move-result v5

    if-le v4, v5, :cond_19

    .line 42
    :cond_17
    new-instance v4, Ljava/lang/ref/WeakReference;

    invoke-direct {v4, v10}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v4, v3, Le8;->K0:Ljava/lang/ref/WeakReference;

    goto :goto_c

    .line 43
    :cond_18
    iget-object v3, v3, Ld8;->N:Lv7;

    invoke-virtual {v14, v3}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v3

    const/4 v4, 0x0

    const/4 v6, 0x5

    invoke-virtual {v14, v3, v9, v4, v6}, Ljj;->f(Lqs;Lqs;II)V

    goto :goto_d

    :cond_19
    :goto_c
    const/4 v4, 0x0

    const/4 v6, 0x5

    .line 44
    :goto_d
    iget-boolean v3, v15, Ld8;->l:Z

    if-eqz v3, :cond_1a

    iget-boolean v3, v15, Ld8;->m:Z

    if-eqz v3, :cond_1a

    .line 45
    iput-boolean v4, v15, Ld8;->l:Z

    .line 46
    iput-boolean v4, v15, Ld8;->m:Z

    return-void

    .line 47
    :cond_1a
    :goto_e
    iget-object v5, v15, Ld8;->f:[Z

    if-eqz p2, :cond_1d

    iget-object v3, v15, Ld8;->d:Lng;

    if-eqz v3, :cond_1d

    iget-object v4, v15, Ld8;->e:Llx;

    if-eqz v4, :cond_1d

    iget-object v6, v3, Loz;->h:Lda;

    move-object/from16 v23, v8

    iget-boolean v8, v6, Lda;->j:Z

    if-eqz v8, :cond_1e

    iget-object v3, v3, Loz;->i:Lda;

    iget-boolean v3, v3, Lda;->j:Z

    if-eqz v3, :cond_1e

    iget-object v3, v4, Loz;->h:Lda;

    iget-boolean v3, v3, Lda;->j:Z

    if-eqz v3, :cond_1e

    iget-object v3, v4, Loz;->i:Lda;

    iget-boolean v3, v3, Lda;->j:Z

    if-eqz v3, :cond_1e

    .line 48
    iget v0, v6, Lda;->g:I

    invoke-virtual {v14, v13, v0}, Ljj;->d(Lqs;I)V

    .line 49
    iget-object v0, v15, Ld8;->d:Lng;

    iget-object v0, v0, Loz;->i:Lda;

    iget v0, v0, Lda;->g:I

    invoke-virtual {v14, v12, v0}, Ljj;->d(Lqs;I)V

    .line 50
    iget-object v0, v15, Ld8;->e:Llx;

    iget-object v0, v0, Loz;->h:Lda;

    iget v0, v0, Lda;->g:I

    invoke-virtual {v14, v11, v0}, Ljj;->d(Lqs;I)V

    .line 51
    iget-object v0, v15, Ld8;->e:Llx;

    iget-object v0, v0, Loz;->i:Lda;

    iget v0, v0, Lda;->g:I

    invoke-virtual {v14, v9, v0}, Ljj;->d(Lqs;I)V

    .line 52
    iget-object v0, v15, Ld8;->e:Llx;

    iget-object v0, v0, Llx;->k:Lda;

    iget v0, v0, Lda;->g:I

    invoke-virtual {v14, v7, v0}, Ljj;->d(Lqs;I)V

    .line 53
    iget-object v0, v15, Ld8;->W:Ld8;

    if-eqz v0, :cond_1c

    if-eqz v29, :cond_1b

    const/4 v0, 0x0

    .line 54
    aget-boolean v1, v5, v0

    if-eqz v1, :cond_1b

    invoke-virtual/range {p0 .. p0}, Ld8;->y()Z

    move-result v1

    if-nez v1, :cond_1b

    .line 55
    iget-object v1, v15, Ld8;->W:Ld8;

    iget-object v1, v1, Ld8;->M:Lv7;

    invoke-virtual {v14, v1}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v1

    const/16 v2, 0x8

    .line 56
    invoke-virtual {v14, v1, v12, v0, v2}, Ljj;->f(Lqs;Lqs;II)V

    :cond_1b
    if-eqz v28, :cond_1c

    const/4 v0, 0x1

    .line 57
    aget-boolean v0, v5, v0

    if-eqz v0, :cond_1c

    invoke-virtual/range {p0 .. p0}, Ld8;->z()Z

    move-result v0

    if-nez v0, :cond_1c

    .line 58
    iget-object v0, v15, Ld8;->W:Ld8;

    iget-object v0, v0, Ld8;->N:Lv7;

    invoke-virtual {v14, v0}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v0

    const/16 v1, 0x8

    const/4 v2, 0x0

    .line 59
    invoke-virtual {v14, v0, v9, v2, v1}, Ljj;->f(Lqs;Lqs;II)V

    goto :goto_f

    :cond_1c
    const/4 v2, 0x0

    .line 60
    :goto_f
    iput-boolean v2, v15, Ld8;->l:Z

    .line 61
    iput-boolean v2, v15, Ld8;->m:Z

    return-void

    :cond_1d
    move-object/from16 v23, v8

    .line 62
    :cond_1e
    iget-object v3, v15, Ld8;->W:Ld8;

    if-eqz v3, :cond_23

    const/4 v3, 0x0

    .line 63
    invoke-virtual {v15, v3}, Ld8;->x(I)Z

    move-result v4

    if-eqz v4, :cond_1f

    .line 64
    iget-object v4, v15, Ld8;->W:Ld8;

    check-cast v4, Le8;

    invoke-virtual {v4, v3, v15}, Le8;->S(ILd8;)V

    const/4 v3, 0x1

    goto :goto_10

    .line 65
    :cond_1f
    invoke-virtual/range {p0 .. p0}, Ld8;->y()Z

    move-result v3

    :goto_10
    const/4 v4, 0x1

    .line 66
    invoke-virtual {v15, v4}, Ld8;->x(I)Z

    move-result v6

    if-eqz v6, :cond_20

    .line 67
    iget-object v6, v15, Ld8;->W:Ld8;

    check-cast v6, Le8;

    invoke-virtual {v6, v4, v15}, Le8;->S(ILd8;)V

    const/4 v4, 0x1

    goto :goto_11

    .line 68
    :cond_20
    invoke-virtual/range {p0 .. p0}, Ld8;->z()Z

    move-result v4

    :goto_11
    if-nez v3, :cond_21

    if-eqz v29, :cond_21

    .line 69
    iget v6, v15, Ld8;->j0:I

    const/16 v8, 0x8

    if-eq v6, v8, :cond_21

    iget-object v6, v0, Lv7;->f:Lv7;

    if-nez v6, :cond_21

    iget-object v6, v1, Lv7;->f:Lv7;

    if-nez v6, :cond_21

    .line 70
    iget-object v6, v15, Ld8;->W:Ld8;

    iget-object v6, v6, Ld8;->M:Lv7;

    invoke-virtual {v14, v6}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v6

    move/from16 v24, v3

    const/4 v3, 0x0

    const/4 v8, 0x1

    .line 71
    invoke-virtual {v14, v6, v12, v3, v8}, Ljj;->f(Lqs;Lqs;II)V

    goto :goto_12

    :cond_21
    move/from16 v24, v3

    :goto_12
    if-nez v4, :cond_22

    if-eqz v28, :cond_22

    .line 72
    iget v3, v15, Ld8;->j0:I

    const/16 v6, 0x8

    if-eq v3, v6, :cond_22

    iget-object v3, v2, Lv7;->f:Lv7;

    if-nez v3, :cond_22

    iget-object v3, v10, Lv7;->f:Lv7;

    if-nez v3, :cond_22

    if-nez v23, :cond_22

    .line 73
    iget-object v3, v15, Ld8;->W:Ld8;

    iget-object v3, v3, Ld8;->N:Lv7;

    invoke-virtual {v14, v3}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v8, 0x0

    .line 74
    invoke-virtual {v14, v3, v9, v8, v6}, Ljj;->f(Lqs;Lqs;II)V

    :cond_22
    move/from16 v30, v4

    move/from16 v31, v24

    goto :goto_13

    :cond_23
    const/16 v30, 0x0

    const/16 v31, 0x0

    .line 75
    :goto_13
    iget v3, v15, Ld8;->X:I

    .line 76
    iget v4, v15, Ld8;->e0:I

    if-ge v3, v4, :cond_24

    goto :goto_14

    :cond_24
    move v4, v3

    .line 77
    :goto_14
    iget v6, v15, Ld8;->Y:I

    .line 78
    iget v8, v15, Ld8;->f0:I

    if-ge v6, v8, :cond_25

    goto :goto_15

    :cond_25
    move v8, v6

    :goto_15
    move-object/from16 v27, v11

    .line 79
    iget-object v11, v15, Ld8;->V:[I

    move/from16 v24, v4

    const/16 v18, 0x0

    aget v4, v11, v18

    move-object/from16 v32, v7

    const/4 v7, 0x3

    move/from16 v26, v8

    const/16 v16, 0x1

    if-eq v4, v7, :cond_26

    const/16 v25, 0x1

    goto :goto_16

    :cond_26
    const/16 v25, 0x0

    .line 80
    :goto_16
    aget v8, v11, v16

    move-object/from16 v33, v9

    if-eq v8, v7, :cond_27

    const/4 v7, 0x1

    goto :goto_17

    :cond_27
    const/4 v7, 0x0

    .line 81
    :goto_17
    iget v9, v15, Ld8;->a0:I

    iput v9, v15, Ld8;->B:I

    move-object/from16 v34, v5

    .line 82
    iget v5, v15, Ld8;->Z:F

    iput v5, v15, Ld8;->C:F

    move-object/from16 v35, v12

    .line 83
    iget v12, v15, Ld8;->s:I

    move-object/from16 v36, v13

    .line 84
    iget v13, v15, Ld8;->t:I

    const/16 v37, 0x0

    cmpl-float v37, v5, v37

    if-lez v37, :cond_3a

    .line 85
    iget v14, v15, Ld8;->j0:I

    move-object/from16 v39, v11

    const/16 v11, 0x8

    if-eq v14, v11, :cond_3b

    const/4 v11, 0x3

    if-ne v4, v11, :cond_28

    if-nez v12, :cond_28

    const/4 v12, 0x3

    :cond_28
    if-ne v8, v11, :cond_29

    if-nez v13, :cond_29

    const/4 v13, 0x3

    :cond_29
    if-ne v4, v11, :cond_34

    if-ne v8, v11, :cond_34

    if-ne v12, v11, :cond_34

    if-ne v13, v11, :cond_34

    const/4 v11, -0x1

    if-ne v9, v11, :cond_2b

    if-eqz v25, :cond_2a

    if-nez v7, :cond_2a

    const/4 v3, 0x0

    .line 86
    iput v3, v15, Ld8;->B:I

    goto :goto_18

    :cond_2a
    if-nez v25, :cond_2b

    if-eqz v7, :cond_2b

    const/4 v3, 0x1

    .line 87
    iput v3, v15, Ld8;->B:I

    if-ne v9, v11, :cond_2b

    const/high16 v3, 0x3f800000    # 1.0f

    div-float v14, v3, v5

    .line 88
    iput v14, v15, Ld8;->C:F

    .line 89
    :cond_2b
    :goto_18
    iget v3, v15, Ld8;->B:I

    if-nez v3, :cond_2d

    invoke-virtual {v2}, Lv7;->h()Z

    move-result v3

    if-eqz v3, :cond_2c

    invoke-virtual {v10}, Lv7;->h()Z

    move-result v3

    if-nez v3, :cond_2d

    :cond_2c
    const/4 v3, 0x1

    .line 90
    iput v3, v15, Ld8;->B:I

    goto :goto_19

    :cond_2d
    const/4 v3, 0x1

    .line 91
    iget v4, v15, Ld8;->B:I

    if-ne v4, v3, :cond_2f

    invoke-virtual {v0}, Lv7;->h()Z

    move-result v3

    if-eqz v3, :cond_2e

    invoke-virtual {v1}, Lv7;->h()Z

    move-result v3

    if-nez v3, :cond_2f

    :cond_2e
    const/4 v3, 0x0

    .line 92
    iput v3, v15, Ld8;->B:I

    .line 93
    :cond_2f
    :goto_19
    iget v3, v15, Ld8;->B:I

    const/4 v4, -0x1

    if-ne v3, v4, :cond_32

    .line 94
    invoke-virtual {v2}, Lv7;->h()Z

    move-result v3

    if-eqz v3, :cond_30

    invoke-virtual {v10}, Lv7;->h()Z

    move-result v3

    if-eqz v3, :cond_30

    .line 95
    invoke-virtual {v0}, Lv7;->h()Z

    move-result v3

    if-eqz v3, :cond_30

    invoke-virtual {v1}, Lv7;->h()Z

    move-result v3

    if-nez v3, :cond_32

    .line 96
    :cond_30
    invoke-virtual {v2}, Lv7;->h()Z

    move-result v2

    if-eqz v2, :cond_31

    invoke-virtual {v10}, Lv7;->h()Z

    move-result v2

    if-eqz v2, :cond_31

    const/4 v2, 0x0

    .line 97
    iput v2, v15, Ld8;->B:I

    goto :goto_1a

    .line 98
    :cond_31
    invoke-virtual {v0}, Lv7;->h()Z

    move-result v0

    if-eqz v0, :cond_32

    invoke-virtual {v1}, Lv7;->h()Z

    move-result v0

    if-eqz v0, :cond_32

    .line 99
    iget v0, v15, Ld8;->C:F

    const/high16 v1, 0x3f800000    # 1.0f

    div-float v14, v1, v0

    iput v14, v15, Ld8;->C:F

    const/4 v0, 0x1

    .line 100
    iput v0, v15, Ld8;->B:I

    .line 101
    :cond_32
    :goto_1a
    iget v0, v15, Ld8;->B:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_39

    .line 102
    iget v0, v15, Ld8;->v:I

    if-lez v0, :cond_33

    iget v1, v15, Ld8;->y:I

    if-nez v1, :cond_33

    const/4 v1, 0x0

    .line 103
    iput v1, v15, Ld8;->B:I

    goto :goto_1c

    :cond_33
    if-nez v0, :cond_39

    .line 104
    iget v0, v15, Ld8;->y:I

    if-lez v0, :cond_39

    .line 105
    iget v0, v15, Ld8;->C:F

    const/high16 v1, 0x3f800000    # 1.0f

    div-float v14, v1, v0

    iput v14, v15, Ld8;->C:F

    const/4 v0, 0x1

    .line 106
    iput v0, v15, Ld8;->B:I

    goto :goto_1c

    :cond_34
    const/4 v0, 0x4

    const/4 v1, 0x3

    if-ne v4, v1, :cond_36

    if-ne v12, v1, :cond_36

    const/4 v2, 0x0

    .line 107
    iput v2, v15, Ld8;->B:I

    int-to-float v2, v6

    mul-float v5, v5, v2

    float-to-int v4, v5

    if-eq v8, v1, :cond_35

    move/from16 v41, v13

    move/from16 v40, v26

    const/high16 v2, 0x3f800000    # 1.0f

    const/16 v38, 0x0

    const/16 v42, 0x4

    goto :goto_1f

    :cond_35
    const/high16 v2, 0x3f800000    # 1.0f

    goto :goto_1d

    :cond_36
    if-ne v8, v1, :cond_39

    if-ne v13, v1, :cond_39

    const/4 v2, 0x1

    .line 108
    iput v2, v15, Ld8;->B:I

    const/4 v2, -0x1

    if-ne v9, v2, :cond_37

    const/high16 v2, 0x3f800000    # 1.0f

    div-float v14, v2, v5

    .line 109
    iput v14, v15, Ld8;->C:F

    goto :goto_1b

    :cond_37
    const/high16 v2, 0x3f800000    # 1.0f

    .line 110
    :goto_1b
    iget v5, v15, Ld8;->C:F

    int-to-float v3, v3

    mul-float v5, v5, v3

    float-to-int v8, v5

    if-eq v4, v1, :cond_38

    move/from16 v40, v8

    move/from16 v42, v12

    move/from16 v4, v24

    const/16 v38, 0x0

    const/16 v41, 0x4

    goto :goto_1f

    :cond_38
    move/from16 v4, v24

    goto :goto_1e

    :cond_39
    :goto_1c
    const/high16 v2, 0x3f800000    # 1.0f

    move/from16 v4, v24

    :goto_1d
    move/from16 v8, v26

    :goto_1e
    move/from16 v40, v8

    move/from16 v42, v12

    move/from16 v41, v13

    const/16 v38, 0x1

    goto :goto_1f

    :cond_3a
    move-object/from16 v39, v11

    :cond_3b
    const/high16 v2, 0x3f800000    # 1.0f

    move/from16 v42, v12

    move/from16 v41, v13

    move/from16 v4, v24

    move/from16 v40, v26

    const/16 v38, 0x0

    .line 111
    :goto_1f
    iget-object v0, v15, Ld8;->u:[I

    const/4 v1, 0x0

    aput v42, v0, v1

    const/4 v1, 0x1

    .line 112
    aput v41, v0, v1

    if-eqz v38, :cond_3d

    .line 113
    iget v0, v15, Ld8;->B:I

    const/4 v1, -0x1

    if-eqz v0, :cond_3c

    if-ne v0, v1, :cond_3e

    :cond_3c
    const/16 v37, 0x1

    goto :goto_20

    :cond_3d
    const/4 v1, -0x1

    :cond_3e
    const/16 v37, 0x0

    :goto_20
    if-eqz v38, :cond_40

    .line 114
    iget v0, v15, Ld8;->B:I

    const/4 v3, 0x1

    if-eq v0, v3, :cond_3f

    if-ne v0, v1, :cond_40

    :cond_3f
    const/4 v0, 0x0

    const/16 v43, 0x1

    goto :goto_21

    :cond_40
    const/4 v0, 0x0

    const/16 v43, 0x0

    .line 115
    :goto_21
    aget v1, v39, v0

    const/4 v0, 0x2

    if-ne v1, v0, :cond_41

    instance-of v0, v15, Le8;

    if-eqz v0, :cond_41

    const/4 v9, 0x1

    goto :goto_22

    :cond_41
    const/4 v9, 0x0

    :goto_22
    if-eqz v9, :cond_42

    const/4 v13, 0x0

    goto :goto_23

    :cond_42
    move v13, v4

    .line 116
    :goto_23
    iget-object v14, v15, Ld8;->R:Lv7;

    invoke-virtual {v14}, Lv7;->h()Z

    move-result v0

    const/4 v1, 0x1

    xor-int/lit8 v44, v0, 0x1

    const/4 v0, 0x0

    .line 117
    aget-boolean v45, v22, v0

    .line 118
    aget-boolean v46, v22, v1

    .line 119
    iget v0, v15, Ld8;->p:I

    iget-object v12, v15, Ld8;->D:[I

    const/16 v47, 0x0

    const/4 v4, 0x2

    if-eq v0, v4, :cond_4a

    iget-boolean v0, v15, Ld8;->l:Z

    if-nez v0, :cond_4a

    if-eqz p2, :cond_46

    .line 120
    iget-object v0, v15, Ld8;->d:Lng;

    if-eqz v0, :cond_46

    iget-object v1, v0, Loz;->h:Lda;

    iget-boolean v3, v1, Lda;->j:Z

    if-eqz v3, :cond_46

    iget-object v0, v0, Loz;->i:Lda;

    iget-boolean v0, v0, Lda;->j:Z

    if-nez v0, :cond_43

    goto :goto_25

    :cond_43
    if-eqz p2, :cond_45

    .line 121
    iget v0, v1, Lda;->g:I

    move-object/from16 v11, p1

    move-object/from16 v8, v36

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-virtual {v11, v8, v0}, Ljj;->d(Lqs;I)V

    .line 122
    iget-object v0, v15, Ld8;->d:Lng;

    iget-object v0, v0, Loz;->i:Lda;

    iget v0, v0, Lda;->g:I

    move-object/from16 v6, v35

    invoke-virtual {v11, v6, v0}, Ljj;->d(Lqs;I)V

    .line 123
    iget-object v0, v15, Ld8;->W:Ld8;

    if-eqz v0, :cond_44

    if-eqz v29, :cond_44

    const/4 v0, 0x0

    .line 124
    aget-boolean v1, v34, v0

    if-eqz v1, :cond_44

    invoke-virtual/range {p0 .. p0}, Ld8;->y()Z

    move-result v1

    if-nez v1, :cond_44

    .line 125
    iget-object v1, v15, Ld8;->W:Ld8;

    iget-object v1, v1, Ld8;->M:Lv7;

    invoke-virtual {v11, v1}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v1

    const/16 v5, 0x8

    .line 126
    invoke-virtual {v11, v1, v6, v0, v5}, Ljj;->f(Lqs;Lqs;II)V

    goto :goto_24

    :cond_44
    const/16 v5, 0x8

    :goto_24
    move-object/from16 v58, v6

    move-object/from16 v59, v8

    move-object/from16 v56, v10

    move-object/from16 v35, v14

    move-object/from16 v54, v23

    move-object/from16 v57, v27

    move-object/from16 v53, v32

    move-object/from16 v55, v33

    move-object/from16 v32, v39

    move-object/from16 v33, v12

    goto/16 :goto_2a

    :cond_45
    move-object/from16 v11, p1

    goto/16 :goto_29

    :cond_46
    :goto_25
    move-object/from16 v11, p1

    move-object/from16 v6, v35

    move-object/from16 v8, v36

    const/16 v5, 0x8

    const/high16 v7, 0x3f800000    # 1.0f

    .line 127
    iget-object v0, v15, Ld8;->W:Ld8;

    if-eqz v0, :cond_47

    iget-object v0, v0, Ld8;->M:Lv7;

    invoke-virtual {v11, v0}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v0

    move-object/from16 v19, v0

    goto :goto_26

    :cond_47
    move-object/from16 v19, v47

    .line 128
    :goto_26
    iget-object v0, v15, Ld8;->W:Ld8;

    if-eqz v0, :cond_48

    iget-object v0, v0, Ld8;->K:Lv7;

    invoke-virtual {v11, v0}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v0

    move-object/from16 v18, v0

    goto :goto_27

    :cond_48
    move-object/from16 v18, v47

    :goto_27
    const/16 v20, 0x0

    .line 129
    aget-boolean v22, v34, v20

    aget v35, v39, v20

    iget-object v3, v15, Ld8;->K:Lv7;

    iget-object v1, v15, Ld8;->M:Lv7;

    iget v0, v15, Ld8;->b0:I

    iget v2, v15, Ld8;->e0:I

    aget v36, v12, v20

    move/from16 v48, v2

    iget v2, v15, Ld8;->g0:F

    const/16 v17, 0x1

    aget v4, v39, v17

    const/4 v7, 0x3

    if-ne v4, v7, :cond_49

    const/16 v49, 0x1

    goto :goto_28

    :cond_49
    const/16 v49, 0x0

    :goto_28
    iget v4, v15, Ld8;->v:I

    move/from16 v24, v4

    iget v4, v15, Ld8;->w:I

    move/from16 v25, v4

    iget v4, v15, Ld8;->x:F

    move/from16 v26, v4

    const/4 v4, 0x1

    move/from16 v16, v48

    move/from16 v48, v2

    move v2, v4

    move/from16 v50, v0

    move-object/from16 v0, p0

    move-object/from16 v51, v1

    move-object/from16 v1, p1

    move-object/from16 v52, v3

    move/from16 v3, v29

    move/from16 v4, v28

    const/16 v17, 0x8

    move/from16 v5, v22

    move-object/from16 v17, v6

    const/4 v7, 0x0

    move-object/from16 v6, v18

    move-object/from16 v53, v32

    move-object/from16 v7, v19

    move-object/from16 v18, v8

    move-object/from16 v54, v23

    move/from16 v8, v35

    move-object/from16 v55, v33

    move-object/from16 v56, v10

    move-object/from16 v10, v52

    move-object/from16 v57, v27

    move-object/from16 v32, v39

    move-object/from16 v11, v51

    move-object/from16 v33, v12

    move-object/from16 v58, v17

    move/from16 v12, v50

    move-object/from16 v59, v18

    move-object/from16 v35, v14

    move/from16 v14, v16

    move/from16 v15, v36

    move/from16 v16, v48

    move/from16 v17, v37

    move/from16 v18, v49

    move/from16 v19, v31

    move/from16 v20, v30

    move/from16 v21, v45

    move/from16 v22, v42

    move/from16 v23, v41

    move/from16 v27, v44

    invoke-virtual/range {v0 .. v27}, Ld8;->e(Ljj;ZZZZLqs;Lqs;IZLv7;Lv7;IIIIFZZZZZIIIIFZ)V

    goto :goto_2a

    :cond_4a
    :goto_29
    move-object/from16 v56, v10

    move-object/from16 v54, v23

    move-object/from16 v57, v27

    move-object/from16 v53, v32

    move-object/from16 v55, v33

    move-object/from16 v58, v35

    move-object/from16 v59, v36

    move-object/from16 v32, v39

    move-object/from16 v33, v12

    move-object/from16 v35, v14

    :goto_2a
    if-eqz p2, :cond_4e

    move-object/from16 v15, p0

    .line 130
    iget-object v0, v15, Ld8;->e:Llx;

    if-eqz v0, :cond_4d

    iget-object v1, v0, Loz;->h:Lda;

    iget-boolean v2, v1, Lda;->j:Z

    if-eqz v2, :cond_4d

    iget-object v0, v0, Loz;->i:Lda;

    iget-boolean v0, v0, Lda;->j:Z

    if-eqz v0, :cond_4d

    .line 131
    iget v0, v1, Lda;->g:I

    move-object/from16 v14, p1

    move-object/from16 v13, v57

    invoke-virtual {v14, v13, v0}, Ljj;->d(Lqs;I)V

    .line 132
    iget-object v0, v15, Ld8;->e:Llx;

    iget-object v0, v0, Loz;->i:Lda;

    iget v0, v0, Lda;->g:I

    move-object/from16 v12, v55

    invoke-virtual {v14, v12, v0}, Ljj;->d(Lqs;I)V

    .line 133
    iget-object v0, v15, Ld8;->e:Llx;

    iget-object v0, v0, Llx;->k:Lda;

    iget v0, v0, Lda;->g:I

    move-object/from16 v1, v53

    invoke-virtual {v14, v1, v0}, Ljj;->d(Lqs;I)V

    .line 134
    iget-object v0, v15, Ld8;->W:Ld8;

    if-eqz v0, :cond_4c

    if-nez v30, :cond_4c

    if-eqz v28, :cond_4c

    const/4 v11, 0x1

    .line 135
    aget-boolean v2, v34, v11

    if-eqz v2, :cond_4b

    .line 136
    iget-object v0, v0, Ld8;->N:Lv7;

    invoke-virtual {v14, v0}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v0

    const/16 v2, 0x8

    const/4 v10, 0x0

    .line 137
    invoke-virtual {v14, v0, v12, v10, v2}, Ljj;->f(Lqs;Lqs;II)V

    goto :goto_2b

    :cond_4b
    const/16 v2, 0x8

    const/4 v10, 0x0

    goto :goto_2b

    :cond_4c
    const/16 v2, 0x8

    const/4 v10, 0x0

    const/4 v11, 0x1

    :goto_2b
    const/4 v5, 0x0

    goto :goto_2d

    :cond_4d
    move-object/from16 v14, p1

    move-object/from16 v1, v53

    move-object/from16 v12, v55

    move-object/from16 v13, v57

    const/16 v2, 0x8

    const/4 v10, 0x0

    const/4 v11, 0x1

    goto :goto_2c

    :cond_4e
    const/16 v2, 0x8

    const/4 v10, 0x0

    const/4 v11, 0x1

    move-object/from16 v15, p0

    move-object/from16 v14, p1

    move-object/from16 v1, v53

    move-object/from16 v12, v55

    move-object/from16 v13, v57

    :goto_2c
    const/4 v5, 0x1

    .line 138
    :goto_2d
    iget v0, v15, Ld8;->q:I

    const/4 v3, 0x2

    if-ne v0, v3, :cond_4f

    const/4 v6, 0x0

    goto :goto_2e

    :cond_4f
    move v6, v5

    :goto_2e
    if-eqz v6, :cond_5a

    .line 139
    iget-boolean v0, v15, Ld8;->m:Z

    if-nez v0, :cond_5a

    .line 140
    aget v0, v32, v11

    if-ne v0, v3, :cond_50

    instance-of v0, v15, Le8;

    if-eqz v0, :cond_50

    const/4 v9, 0x1

    goto :goto_2f

    :cond_50
    const/4 v9, 0x0

    :goto_2f
    if-eqz v9, :cond_51

    const/16 v40, 0x0

    .line 141
    :cond_51
    iget-object v0, v15, Ld8;->W:Ld8;

    if-eqz v0, :cond_52

    iget-object v0, v0, Ld8;->N:Lv7;

    invoke-virtual {v14, v0}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v0

    move-object v7, v0

    goto :goto_30

    :cond_52
    move-object/from16 v7, v47

    .line 142
    :goto_30
    iget-object v0, v15, Ld8;->W:Ld8;

    if-eqz v0, :cond_53

    iget-object v0, v0, Ld8;->L:Lv7;

    invoke-virtual {v14, v0}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v0

    move-object v6, v0

    goto :goto_31

    :cond_53
    move-object/from16 v6, v47

    .line 143
    :goto_31
    iget v0, v15, Ld8;->d0:I

    if-gtz v0, :cond_54

    iget v3, v15, Ld8;->j0:I

    if-ne v3, v2, :cond_58

    :cond_54
    move-object/from16 v3, v54

    .line 144
    iget-object v4, v3, Lv7;->f:Lv7;

    if-eqz v4, :cond_56

    .line 145
    invoke-virtual {v14, v1, v13, v0, v2}, Ljj;->e(Lqs;Lqs;II)V

    .line 146
    iget-object v0, v3, Lv7;->f:Lv7;

    invoke-virtual {v14, v0}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v0

    .line 147
    invoke-virtual {v3}, Lv7;->e()I

    move-result v3

    .line 148
    invoke-virtual {v14, v1, v0, v3, v2}, Ljj;->e(Lqs;Lqs;II)V

    if-eqz v28, :cond_55

    move-object/from16 v0, v56

    .line 149
    invoke-virtual {v14, v0}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v0

    const/4 v1, 0x5

    .line 150
    invoke-virtual {v14, v7, v0, v10, v1}, Ljj;->f(Lqs;Lqs;II)V

    :cond_55
    const/16 v27, 0x0

    goto :goto_33

    .line 151
    :cond_56
    iget v4, v15, Ld8;->j0:I

    if-ne v4, v2, :cond_57

    .line 152
    invoke-virtual {v3}, Lv7;->e()I

    move-result v0

    invoke-virtual {v14, v1, v13, v0, v2}, Ljj;->e(Lqs;Lqs;II)V

    goto :goto_32

    .line 153
    :cond_57
    invoke-virtual {v14, v1, v13, v0, v2}, Ljj;->e(Lqs;Lqs;II)V

    :cond_58
    :goto_32
    move/from16 v27, v44

    .line 154
    :goto_33
    aget-boolean v5, v34, v11

    aget v8, v32, v11

    iget-object v4, v15, Ld8;->L:Lv7;

    iget-object v3, v15, Ld8;->N:Lv7;

    iget v1, v15, Ld8;->c0:I

    iget v0, v15, Ld8;->f0:I

    aget v16, v33, v11

    iget v2, v15, Ld8;->h0:F

    aget v11, v32, v10

    const/4 v10, 0x3

    if-ne v11, v10, :cond_59

    const/16 v19, 0x1

    goto :goto_34

    :cond_59
    const/16 v19, 0x0

    :goto_34
    iget v10, v15, Ld8;->y:I

    move/from16 v24, v10

    iget v10, v15, Ld8;->z:I

    move/from16 v25, v10

    iget v10, v15, Ld8;->A:F

    move/from16 v26, v10

    const/4 v10, 0x0

    move/from16 v17, v2

    move v2, v10

    move/from16 v20, v0

    move-object/from16 v0, p0

    move/from16 v21, v1

    move-object/from16 v1, p1

    move-object v11, v3

    move/from16 v3, v28

    move-object v10, v4

    move/from16 v4, v29

    move-object/from16 v60, v12

    move/from16 v12, v21

    move-object/from16 v61, v13

    move/from16 v13, v40

    move/from16 v14, v20

    move/from16 v15, v16

    move/from16 v16, v17

    move/from16 v17, v43

    move/from16 v18, v19

    move/from16 v19, v30

    move/from16 v20, v31

    move/from16 v21, v46

    move/from16 v22, v41

    move/from16 v23, v42

    invoke-virtual/range {v0 .. v27}, Ld8;->e(Ljj;ZZZZLqs;Lqs;IZLv7;Lv7;IIIIFZZZZZIIIIFZ)V

    goto :goto_35

    :cond_5a
    move-object/from16 v60, v12

    move-object/from16 v61, v13

    :goto_35
    if-eqz v38, :cond_5c

    move-object/from16 v0, p0

    .line 155
    iget v1, v0, Ld8;->B:I

    const/high16 v2, -0x40800000    # -1.0f

    const/4 v3, 0x1

    if-ne v1, v3, :cond_5b

    .line 156
    iget v1, v0, Ld8;->C:F

    .line 157
    invoke-virtual/range {p1 .. p1}, Ljj;->l()Ll3;

    move-result-object v3

    .line 158
    iget-object v4, v3, Ll3;->d:Ll3$a;

    move-object/from16 v5, v60

    invoke-interface {v4, v5, v2}, Ll3$a;->j(Lqs;F)V

    .line 159
    iget-object v2, v3, Ll3;->d:Ll3$a;

    move-object/from16 v4, v61

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-interface {v2, v4, v6}, Ll3$a;->j(Lqs;F)V

    .line 160
    iget-object v2, v3, Ll3;->d:Ll3$a;

    move-object/from16 v7, v58

    invoke-interface {v2, v7, v1}, Ll3$a;->j(Lqs;F)V

    .line 161
    iget-object v2, v3, Ll3;->d:Ll3$a;

    neg-float v1, v1

    move-object/from16 v8, v59

    invoke-interface {v2, v8, v1}, Ll3$a;->j(Lqs;F)V

    move-object/from16 v1, p1

    .line 162
    invoke-virtual {v1, v3}, Ljj;->c(Ll3;)V

    goto :goto_36

    :cond_5b
    move-object/from16 v1, p1

    move-object/from16 v7, v58

    move-object/from16 v8, v59

    move-object/from16 v5, v60

    move-object/from16 v4, v61

    const/high16 v6, 0x3f800000    # 1.0f

    .line 163
    iget v3, v0, Ld8;->C:F

    .line 164
    invoke-virtual/range {p1 .. p1}, Ljj;->l()Ll3;

    move-result-object v9

    .line 165
    iget-object v10, v9, Ll3;->d:Ll3$a;

    invoke-interface {v10, v7, v2}, Ll3$a;->j(Lqs;F)V

    .line 166
    iget-object v2, v9, Ll3;->d:Ll3$a;

    invoke-interface {v2, v8, v6}, Ll3$a;->j(Lqs;F)V

    .line 167
    iget-object v2, v9, Ll3;->d:Ll3$a;

    invoke-interface {v2, v5, v3}, Ll3$a;->j(Lqs;F)V

    .line 168
    iget-object v2, v9, Ll3;->d:Ll3$a;

    neg-float v3, v3

    invoke-interface {v2, v4, v3}, Ll3$a;->j(Lqs;F)V

    .line 169
    invoke-virtual {v1, v9}, Ljj;->c(Ll3;)V

    goto :goto_36

    :cond_5c
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 170
    :goto_36
    invoke-virtual/range {v35 .. v35}, Lv7;->h()Z

    move-result v2

    if-eqz v2, :cond_5d

    move-object/from16 v2, v35

    .line 171
    iget-object v3, v2, Lv7;->f:Lv7;

    .line 172
    iget-object v3, v3, Lv7;->d:Ld8;

    .line 173
    iget v4, v0, Ld8;->E:F

    const/high16 v5, 0x42b40000    # 90.0f

    add-float/2addr v4, v5

    float-to-double v4, v4

    invoke-static {v4, v5}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v4

    double-to-float v4, v4

    invoke-virtual {v2}, Lv7;->e()I

    move-result v2

    .line 174
    sget-object v5, Lv7$a;->c:Lv7$a;

    invoke-virtual {v0, v5}, Ld8;->j(Lv7$a;)Lv7;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v6

    .line 175
    sget-object v7, Lv7$a;->d:Lv7$a;

    invoke-virtual {v0, v7}, Ld8;->j(Lv7$a;)Lv7;

    move-result-object v8

    invoke-virtual {v1, v8}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v8

    .line 176
    sget-object v9, Lv7$a;->e:Lv7$a;

    invoke-virtual {v0, v9}, Ld8;->j(Lv7$a;)Lv7;

    move-result-object v10

    invoke-virtual {v1, v10}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v10

    .line 177
    sget-object v11, Lv7$a;->f:Lv7$a;

    invoke-virtual {v0, v11}, Ld8;->j(Lv7$a;)Lv7;

    move-result-object v12

    invoke-virtual {v1, v12}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v12

    .line 178
    invoke-virtual {v3, v5}, Ld8;->j(Lv7$a;)Lv7;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v5

    .line 179
    invoke-virtual {v3, v7}, Ld8;->j(Lv7$a;)Lv7;

    move-result-object v7

    invoke-virtual {v1, v7}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v7

    .line 180
    invoke-virtual {v3, v9}, Ld8;->j(Lv7$a;)Lv7;

    move-result-object v9

    invoke-virtual {v1, v9}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v9

    .line 181
    invoke-virtual {v3, v11}, Ld8;->j(Lv7$a;)Lv7;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v3

    .line 182
    invoke-virtual/range {p1 .. p1}, Ljj;->l()Ll3;

    move-result-object v11

    float-to-double v13, v4

    .line 183
    invoke-static {v13, v14}, Ljava/lang/Math;->sin(D)D

    move-result-wide v15

    move-object v4, v9

    move-object/from16 p2, v10

    int-to-double v9, v2

    move-object/from16 v17, v4

    move-object v2, v5

    mul-double v4, v15, v9

    double-to-float v4, v4

    .line 184
    iget-object v5, v11, Ll3;->d:Ll3$a;

    const/high16 v15, 0x3f000000    # 0.5f

    invoke-interface {v5, v7, v15}, Ll3$a;->j(Lqs;F)V

    .line 185
    iget-object v5, v11, Ll3;->d:Ll3$a;

    invoke-interface {v5, v3, v15}, Ll3$a;->j(Lqs;F)V

    .line 186
    iget-object v3, v11, Ll3;->d:Ll3$a;

    const/high16 v5, -0x41000000    # -0.5f

    invoke-interface {v3, v8, v5}, Ll3$a;->j(Lqs;F)V

    .line 187
    iget-object v3, v11, Ll3;->d:Ll3$a;

    invoke-interface {v3, v12, v5}, Ll3$a;->j(Lqs;F)V

    neg-float v3, v4

    .line 188
    iput v3, v11, Ll3;->b:F

    .line 189
    invoke-virtual {v1, v11}, Ljj;->c(Ll3;)V

    .line 190
    invoke-virtual/range {p1 .. p1}, Ljj;->l()Ll3;

    move-result-object v3

    .line 191
    invoke-static {v13, v14}, Ljava/lang/Math;->cos(D)D

    move-result-wide v7

    mul-double v7, v7, v9

    double-to-float v4, v7

    .line 192
    iget-object v7, v3, Ll3;->d:Ll3$a;

    invoke-interface {v7, v2, v15}, Ll3$a;->j(Lqs;F)V

    .line 193
    iget-object v2, v3, Ll3;->d:Ll3$a;

    move-object/from16 v7, v17

    invoke-interface {v2, v7, v15}, Ll3$a;->j(Lqs;F)V

    .line 194
    iget-object v2, v3, Ll3;->d:Ll3$a;

    invoke-interface {v2, v6, v5}, Ll3$a;->j(Lqs;F)V

    .line 195
    iget-object v2, v3, Ll3;->d:Ll3$a;

    move-object/from16 v6, p2

    invoke-interface {v2, v6, v5}, Ll3$a;->j(Lqs;F)V

    neg-float v2, v4

    .line 196
    iput v2, v3, Ll3;->b:F

    .line 197
    invoke-virtual {v1, v3}, Ljj;->c(Ll3;)V

    :cond_5d
    const/4 v1, 0x0

    .line 198
    iput-boolean v1, v0, Ld8;->l:Z

    .line 199
    iput-boolean v1, v0, Ld8;->m:Z

    return-void
.end method

.method public d()Z
    .locals 2

    iget v0, p0, Ld8;->j0:I

    const/16 v1, 0x8

    if-eq v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final e(Ljj;ZZZZLqs;Lqs;IZLv7;Lv7;IIIIFZZZZZIIIIFZ)V
    .locals 28

    move-object/from16 v0, p0

    move-object/from16 v10, p1

    move-object/from16 v11, p6

    move-object/from16 v12, p7

    move-object/from16 v13, p10

    move-object/from16 v14, p11

    move/from16 v15, p14

    move/from16 v1, p15

    move/from16 v2, p23

    move/from16 v3, p24

    move/from16 v4, p25

    move/from16 v5, p26

    .line 1
    invoke-virtual {v10, v13}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v9

    .line 2
    invoke-virtual {v10, v14}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v8

    .line 3
    iget-object v6, v13, Lv7;->f:Lv7;

    .line 4
    invoke-virtual {v10, v6}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v7

    .line 5
    iget-object v6, v14, Lv7;->f:Lv7;

    .line 6
    invoke-virtual {v10, v6}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v6

    .line 7
    invoke-virtual/range {p10 .. p10}, Lv7;->h()Z

    move-result v16

    .line 8
    invoke-virtual/range {p11 .. p11}, Lv7;->h()Z

    move-result v17

    .line 9
    iget-object v12, v0, Ld8;->R:Lv7;

    invoke-virtual {v12}, Lv7;->h()Z

    move-result v12

    if-eqz v17, :cond_0

    add-int/lit8 v18, v16, 0x1

    goto :goto_0

    :cond_0
    move/from16 v18, v16

    :goto_0
    if-eqz v12, :cond_1

    add-int/lit8 v18, v18, 0x1

    :cond_1
    move/from16 v2, v18

    if-eqz p17, :cond_2

    const/4 v14, 0x3

    goto :goto_1

    :cond_2
    move/from16 v14, p22

    :goto_1
    if-eqz p8, :cond_63

    const/4 v11, -0x1

    move-object/from16 v19, v6

    add-int/lit8 v6, p8, -0x1

    const/4 v11, 0x1

    if-eqz v6, :cond_4

    if-eq v6, v11, :cond_4

    const/4 v11, 0x2

    if-eq v6, v11, :cond_3

    goto :goto_2

    :cond_3
    const/4 v11, 0x4

    if-eq v14, v11, :cond_4

    const/4 v6, 0x1

    goto :goto_3

    :cond_4
    :goto_2
    const/4 v6, 0x0

    .line 10
    :goto_3
    iget v11, v0, Ld8;->i:I

    move/from16 v21, v6

    const/4 v6, -0x1

    if-eq v11, v6, :cond_5

    if-eqz p2, :cond_5

    .line 11
    iput v6, v0, Ld8;->i:I

    move/from16 p13, v11

    const/16 v21, 0x0

    .line 12
    :cond_5
    iget v11, v0, Ld8;->j:I

    if-eq v11, v6, :cond_6

    if-nez p2, :cond_6

    .line 13
    iput v6, v0, Ld8;->j:I

    const/16 v21, 0x0

    goto :goto_4

    :cond_6
    move/from16 v11, p13

    .line 14
    :goto_4
    iget v6, v0, Ld8;->j0:I

    move/from16 p13, v11

    const/16 v11, 0x8

    if-ne v6, v11, :cond_7

    const/4 v6, 0x0

    const/16 v21, 0x0

    goto :goto_5

    :cond_7
    move/from16 v6, p13

    :goto_5
    if-eqz p27, :cond_9

    if-nez v16, :cond_8

    if-nez v17, :cond_8

    if-nez v12, :cond_8

    move/from16 v11, p12

    .line 15
    invoke-virtual {v10, v9, v11}, Ljj;->d(Lqs;I)V

    goto :goto_6

    :cond_8
    if-eqz v16, :cond_9

    if-nez v17, :cond_9

    .line 16
    invoke-virtual/range {p10 .. p10}, Lv7;->e()I

    move-result v11

    move/from16 v22, v12

    const/16 v12, 0x8

    invoke-virtual {v10, v9, v7, v11, v12}, Ljj;->e(Lqs;Lqs;II)V

    goto :goto_7

    :cond_9
    :goto_6
    move/from16 v22, v12

    const/16 v12, 0x8

    :goto_7
    if-nez v21, :cond_d

    if-eqz p9, :cond_b

    const/4 v5, 0x3

    const/4 v11, 0x0

    .line 17
    invoke-virtual {v10, v8, v9, v11, v5}, Ljj;->e(Lqs;Lqs;II)V

    if-lez v15, :cond_a

    .line 18
    invoke-virtual {v10, v8, v9, v15, v12}, Ljj;->f(Lqs;Lqs;II)V

    :cond_a
    const v6, 0x7fffffff

    if-ge v1, v6, :cond_c

    .line 19
    invoke-virtual {v10, v8, v9, v1, v12}, Ljj;->g(Lqs;Lqs;II)V

    goto :goto_8

    :cond_b
    const/4 v5, 0x3

    .line 20
    invoke-virtual {v10, v8, v9, v6, v12}, Ljj;->e(Lqs;Lqs;II)V

    :cond_c
    :goto_8
    move/from16 v11, p5

    move/from16 v23, v2

    :goto_9
    move v12, v3

    goto/16 :goto_f

    :cond_d
    const/4 v1, 0x3

    const/4 v11, 0x2

    if-eq v2, v11, :cond_10

    if-nez p17, :cond_10

    const/4 v11, 0x1

    if-eq v14, v11, :cond_e

    if-nez v14, :cond_10

    .line 21
    :cond_e
    invoke-static {v3, v6}, Ljava/lang/Math;->max(II)I

    move-result v5

    if-lez v4, :cond_f

    .line 22
    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    :cond_f
    const/16 v6, 0x8

    .line 23
    invoke-virtual {v10, v8, v9, v5, v6}, Ljj;->e(Lqs;Lqs;II)V

    move/from16 v11, p5

    move/from16 v23, v2

    move v12, v3

    const/16 v21, 0x0

    goto/16 :goto_f

    :cond_10
    const/4 v11, -0x2

    if-ne v3, v11, :cond_11

    move v3, v6

    :cond_11
    if-ne v4, v11, :cond_12

    move v4, v6

    :cond_12
    if-lez v6, :cond_13

    const/4 v11, 0x1

    if-eq v14, v11, :cond_13

    const/4 v6, 0x0

    :cond_13
    if-lez v3, :cond_14

    const/16 v11, 0x8

    .line 24
    invoke-virtual {v10, v8, v9, v3, v11}, Ljj;->f(Lqs;Lqs;II)V

    .line 25
    invoke-static {v6, v3}, Ljava/lang/Math;->max(II)I

    move-result v6

    :cond_14
    if-lez v4, :cond_17

    if-eqz p3, :cond_15

    const/4 v11, 0x1

    if-ne v14, v11, :cond_15

    const/4 v11, 0x0

    goto :goto_a

    :cond_15
    const/4 v11, 0x1

    :goto_a
    if-eqz v11, :cond_16

    const/16 v11, 0x8

    .line 26
    invoke-virtual {v10, v8, v9, v4, v11}, Ljj;->g(Lqs;Lqs;II)V

    goto :goto_b

    :cond_16
    const/16 v11, 0x8

    .line 27
    :goto_b
    invoke-static {v6, v4}, Ljava/lang/Math;->min(II)I

    move-result v6

    goto :goto_c

    :cond_17
    const/16 v11, 0x8

    :goto_c
    const/4 v12, 0x1

    if-ne v14, v12, :cond_1a

    if-eqz p3, :cond_18

    .line 28
    invoke-virtual {v10, v8, v9, v6, v11}, Ljj;->e(Lqs;Lqs;II)V

    goto :goto_8

    :cond_18
    if-eqz p19, :cond_19

    const/4 v5, 0x5

    .line 29
    invoke-virtual {v10, v8, v9, v6, v5}, Ljj;->e(Lqs;Lqs;II)V

    .line 30
    invoke-virtual {v10, v8, v9, v6, v11}, Ljj;->g(Lqs;Lqs;II)V

    goto :goto_8

    :cond_19
    const/4 v5, 0x5

    .line 31
    invoke-virtual {v10, v8, v9, v6, v5}, Ljj;->e(Lqs;Lqs;II)V

    .line 32
    invoke-virtual {v10, v8, v9, v6, v11}, Ljj;->g(Lqs;Lqs;II)V

    goto :goto_8

    :cond_1a
    const/4 v6, 0x2

    if-ne v14, v6, :cond_1e

    .line 33
    sget-object v6, Lv7$a;->d:Lv7$a;

    sget-object v11, Lv7$a;->f:Lv7$a;

    iget-object v12, v13, Lv7;->e:Lv7$a;

    if-eq v12, v6, :cond_1c

    if-ne v12, v11, :cond_1b

    goto :goto_d

    .line 34
    :cond_1b
    iget-object v6, v0, Ld8;->W:Ld8;

    sget-object v11, Lv7$a;->c:Lv7$a;

    invoke-virtual {v6, v11}, Ld8;->j(Lv7$a;)Lv7;

    move-result-object v6

    invoke-virtual {v10, v6}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v6

    .line 35
    iget-object v11, v0, Ld8;->W:Ld8;

    sget-object v12, Lv7$a;->e:Lv7$a;

    invoke-virtual {v11, v12}, Ld8;->j(Lv7$a;)Lv7;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v11

    goto :goto_e

    .line 36
    :cond_1c
    :goto_d
    iget-object v12, v0, Ld8;->W:Ld8;

    invoke-virtual {v12, v6}, Ld8;->j(Lv7$a;)Lv7;

    move-result-object v6

    invoke-virtual {v10, v6}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v6

    .line 37
    iget-object v12, v0, Ld8;->W:Ld8;

    invoke-virtual {v12, v11}, Ld8;->j(Lv7$a;)Lv7;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljj;->k(Ljava/lang/Object;)Lqs;

    move-result-object v11

    .line 38
    :goto_e
    invoke-virtual/range {p1 .. p1}, Ljj;->l()Ll3;

    move-result-object v12

    .line 39
    iget-object v1, v12, Ll3;->d:Ll3$a;

    move/from16 v23, v2

    const/high16 v2, -0x40800000    # -1.0f

    invoke-interface {v1, v8, v2}, Ll3$a;->j(Lqs;F)V

    .line 40
    iget-object v1, v12, Ll3;->d:Ll3$a;

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-interface {v1, v9, v2}, Ll3$a;->j(Lqs;F)V

    .line 41
    iget-object v1, v12, Ll3;->d:Ll3$a;

    invoke-interface {v1, v11, v5}, Ll3$a;->j(Lqs;F)V

    .line 42
    iget-object v1, v12, Ll3;->d:Ll3$a;

    neg-float v2, v5

    invoke-interface {v1, v6, v2}, Ll3$a;->j(Lqs;F)V

    .line 43
    invoke-virtual {v10, v12}, Ljj;->c(Ll3;)V

    if-eqz p3, :cond_1d

    const/16 v21, 0x0

    :cond_1d
    move/from16 v11, p5

    goto/16 :goto_9

    :cond_1e
    move/from16 v23, v2

    move v12, v3

    const/4 v11, 0x1

    :goto_f
    if-eqz p27, :cond_5d

    if-eqz p19, :cond_1f

    goto/16 :goto_35

    :cond_1f
    if-nez v16, :cond_20

    if-nez v17, :cond_20

    if-nez v22, :cond_20

    move-object/from16 v14, p11

    move-object v5, v8

    move/from16 p5, v11

    move-object/from16 v2, v19

    :goto_10
    const/4 v3, 0x5

    goto/16 :goto_31

    :cond_20
    if-eqz v16, :cond_22

    if-nez v17, :cond_22

    .line 44
    iget-object v1, v13, Lv7;->f:Lv7;

    iget-object v1, v1, Lv7;->d:Ld8;

    if-eqz p3, :cond_21

    .line 45
    instance-of v1, v1, Lv3;

    if-eqz v1, :cond_21

    const/16 v1, 0x8

    goto :goto_11

    :cond_21
    const/4 v1, 0x5

    :goto_11
    move-object/from16 v14, p11

    move-object v5, v8

    move/from16 p5, v11

    move-object/from16 v2, v19

    move v11, v1

    move/from16 v1, p3

    goto/16 :goto_33

    :cond_22
    if-nez v16, :cond_23

    if-eqz v17, :cond_23

    .line 46
    invoke-virtual/range {p11 .. p11}, Lv7;->e()I

    move-result v1

    neg-int v1, v1

    move-object/from16 v6, v19

    const/16 v2, 0x8

    invoke-virtual {v10, v8, v6, v1, v2}, Ljj;->e(Lqs;Lqs;II)V

    if-eqz p3, :cond_5a

    move-object/from16 v5, p6

    const/4 v1, 0x5

    const/4 v2, 0x0

    .line 47
    invoke-virtual {v10, v9, v5, v2, v1}, Ljj;->f(Lqs;Lqs;II)V

    goto/16 :goto_30

    :cond_23
    move-object/from16 v5, p6

    move-object/from16 v6, v19

    const/4 v1, -0x1

    if-eqz v16, :cond_5a

    if-eqz v17, :cond_5a

    .line 48
    iget-object v2, v13, Lv7;->f:Lv7;

    iget-object v3, v2, Lv7;->d:Ld8;

    move-object/from16 v2, p11

    .line 49
    iget-object v1, v2, Lv7;->f:Lv7;

    iget-object v1, v1, Lv7;->d:Ld8;

    .line 50
    iget-object v13, v0, Ld8;->W:Ld8;

    const/16 v16, 0x6

    if-eqz v21, :cond_39

    if-nez v14, :cond_28

    if-nez v4, :cond_25

    if-nez v12, :cond_25

    .line 51
    iget-boolean v4, v7, Lqs;->h:Z

    if-eqz v4, :cond_24

    iget-boolean v4, v6, Lqs;->h:Z

    if-eqz v4, :cond_24

    .line 52
    invoke-virtual/range {p10 .. p10}, Lv7;->e()I

    move-result v1

    const/16 v3, 0x8

    invoke-virtual {v10, v9, v7, v1, v3}, Ljj;->e(Lqs;Lqs;II)V

    .line 53
    invoke-virtual/range {p11 .. p11}, Lv7;->e()I

    move-result v1

    neg-int v1, v1

    invoke-virtual {v10, v8, v6, v1, v3}, Ljj;->e(Lqs;Lqs;II)V

    return-void

    :cond_24
    const/16 p2, 0x8

    const/16 v17, 0x8

    const/16 v19, 0x0

    const/16 v22, 0x1

    const/16 v23, 0x0

    goto :goto_12

    :cond_25
    const/16 p2, 0x5

    const/16 v17, 0x5

    const/16 v19, 0x1

    const/16 v22, 0x0

    const/16 v23, 0x1

    .line 54
    :goto_12
    instance-of v4, v3, Lv3;

    if-nez v4, :cond_27

    instance-of v4, v1, Lv3;

    if-eqz v4, :cond_26

    goto :goto_13

    :cond_26
    move/from16 v15, v17

    move/from16 v24, v22

    const/4 v4, 0x6

    move/from16 v17, v14

    move/from16 v22, v19

    move/from16 v19, p2

    goto :goto_17

    :cond_27
    :goto_13
    move/from16 v15, v17

    move/from16 v24, v22

    const/4 v4, 0x6

    move/from16 v17, v14

    move/from16 v22, v19

    const/16 v19, 0x4

    goto :goto_17

    :cond_28
    const/4 v15, 0x2

    if-ne v14, v15, :cond_2b

    .line 55
    instance-of v4, v3, Lv3;

    if-nez v4, :cond_2a

    instance-of v4, v1, Lv3;

    if-eqz v4, :cond_29

    goto :goto_14

    :cond_29
    move/from16 v17, v14

    const/4 v4, 0x6

    const/4 v15, 0x5

    const/16 v19, 0x5

    goto :goto_16

    :cond_2a
    :goto_14
    move/from16 v17, v14

    const/4 v4, 0x6

    const/4 v15, 0x5

    goto :goto_15

    :cond_2b
    const/4 v15, 0x1

    if-ne v14, v15, :cond_2c

    move/from16 v17, v14

    const/4 v4, 0x6

    const/16 v15, 0x8

    :goto_15
    const/16 v19, 0x4

    :goto_16
    const/16 v22, 0x1

    const/16 v23, 0x1

    const/16 v24, 0x0

    :goto_17
    move-object/from16 v14, p7

    goto/16 :goto_22

    :cond_2c
    const/4 v15, 0x3

    if-ne v14, v15, :cond_38

    .line 56
    iget v15, v0, Ld8;->B:I

    move/from16 v17, v14

    const/4 v14, -0x1

    if-ne v15, v14, :cond_2f

    move-object/from16 v14, p7

    if-eqz p20, :cond_2e

    if-eqz p3, :cond_2d

    const/4 v4, 0x5

    goto :goto_18

    :cond_2d
    const/4 v4, 0x4

    goto :goto_18

    :cond_2e
    const/16 v4, 0x8

    :goto_18
    const/16 v15, 0x8

    :goto_19
    const/16 v19, 0x5

    :goto_1a
    const/16 v22, 0x1

    const/16 v23, 0x1

    const/16 v24, 0x1

    goto/16 :goto_22

    :cond_2f
    if-eqz p17, :cond_33

    move/from16 v14, p23

    const/4 v15, 0x2

    if-eq v14, v15, :cond_31

    const/4 v4, 0x1

    if-ne v14, v4, :cond_30

    goto :goto_1b

    :cond_30
    const/4 v4, 0x0

    goto :goto_1c

    :cond_31
    :goto_1b
    const/4 v4, 0x1

    :goto_1c
    if-nez v4, :cond_32

    const/16 v4, 0x8

    const/4 v14, 0x5

    goto :goto_1d

    :cond_32
    const/4 v4, 0x5

    const/4 v14, 0x4

    :goto_1d
    move v15, v4

    move/from16 v19, v14

    const/4 v4, 0x6

    const/16 v22, 0x1

    const/16 v23, 0x1

    const/16 v24, 0x1

    goto :goto_17

    :cond_33
    if-lez v4, :cond_34

    move-object/from16 v14, p7

    const/4 v4, 0x6

    const/4 v15, 0x5

    goto :goto_19

    :cond_34
    if-nez v4, :cond_37

    if-nez v12, :cond_37

    if-nez p20, :cond_35

    move-object/from16 v14, p7

    const/4 v4, 0x6

    const/4 v15, 0x5

    const/16 v19, 0x8

    goto :goto_1a

    :cond_35
    if-eq v3, v13, :cond_36

    if-eq v1, v13, :cond_36

    const/4 v4, 0x4

    goto :goto_1e

    :cond_36
    const/4 v4, 0x5

    :goto_1e
    move-object/from16 v14, p7

    move v15, v4

    const/4 v4, 0x6

    goto :goto_1f

    :cond_37
    move-object/from16 v14, p7

    const/4 v4, 0x6

    const/4 v15, 0x5

    :goto_1f
    const/16 v19, 0x4

    goto :goto_1a

    :cond_38
    move/from16 v17, v14

    move-object/from16 v14, p7

    const/4 v4, 0x6

    const/4 v15, 0x5

    const/16 v19, 0x4

    const/16 v22, 0x0

    const/16 v23, 0x0

    goto :goto_21

    :cond_39
    move/from16 v17, v14

    .line 57
    iget-boolean v4, v7, Lqs;->h:Z

    if-eqz v4, :cond_3c

    iget-boolean v4, v6, Lqs;->h:Z

    if-eqz v4, :cond_3c

    .line 58
    invoke-virtual/range {p10 .. p10}, Lv7;->e()I

    move-result v1

    .line 59
    invoke-virtual/range {p11 .. p11}, Lv7;->e()I

    move-result v3

    const/16 v4, 0x8

    move-object/from16 p17, p1

    move-object/from16 p18, v9

    move-object/from16 p19, v7

    move/from16 p20, v1

    move/from16 p21, p16

    move-object/from16 p22, v6

    move-object/from16 p23, v8

    move/from16 p24, v3

    move/from16 p25, v4

    .line 60
    invoke-virtual/range {p17 .. p25}, Ljj;->b(Lqs;Lqs;IFLqs;Lqs;II)V

    if-eqz p3, :cond_3b

    if-eqz v11, :cond_3b

    .line 61
    iget-object v1, v2, Lv7;->f:Lv7;

    if-eqz v1, :cond_3a

    .line 62
    invoke-virtual/range {p11 .. p11}, Lv7;->e()I

    move-result v11

    move-object/from16 v14, p7

    goto :goto_20

    :cond_3a
    move-object/from16 v14, p7

    const/4 v11, 0x0

    :goto_20
    if-eq v6, v14, :cond_3b

    const/4 v1, 0x5

    .line 63
    invoke-virtual {v10, v14, v8, v11, v1}, Ljj;->f(Lqs;Lqs;II)V

    :cond_3b
    return-void

    :cond_3c
    move-object/from16 v14, p7

    const/4 v4, 0x6

    const/4 v15, 0x5

    const/16 v19, 0x4

    const/16 v22, 0x1

    const/16 v23, 0x1

    :goto_21
    const/16 v24, 0x0

    :goto_22
    if-eqz v23, :cond_3d

    if-ne v7, v6, :cond_3d

    if-eq v3, v13, :cond_3d

    const/16 v23, 0x0

    const/16 v25, 0x0

    goto :goto_23

    :cond_3d
    move/from16 v25, v23

    const/16 v23, 0x1

    :goto_23
    if-eqz v22, :cond_3f

    if-nez v21, :cond_3e

    if-nez p18, :cond_3e

    if-nez p20, :cond_3e

    if-ne v7, v5, :cond_3e

    if-ne v6, v14, :cond_3e

    const/4 v15, 0x0

    const/16 v22, 0x8

    const/16 v23, 0x8

    const/16 v26, 0x0

    goto :goto_24

    :cond_3e
    move/from16 v22, v15

    move/from16 v26, v23

    move/from16 v15, p3

    move/from16 v23, v4

    .line 64
    :goto_24
    invoke-virtual/range {p10 .. p10}, Lv7;->e()I

    move-result v4

    .line 65
    invoke-virtual/range {p11 .. p11}, Lv7;->e()I

    move-result v27

    move/from16 p2, v15

    const/4 v14, 0x3

    move-object v15, v1

    move-object/from16 v1, p1

    move-object v14, v2

    move-object v2, v9

    move/from16 p5, v11

    move-object v11, v3

    move-object v3, v7

    move/from16 p8, v12

    move-object v12, v5

    move/from16 v5, p16

    move-object/from16 p9, v6

    move-object v12, v7

    move-object v7, v8

    move-object/from16 p15, v13

    move-object v13, v8

    move/from16 v8, v27

    move-object/from16 v27, v13

    move-object v13, v9

    move/from16 v9, v23

    .line 66
    invoke-virtual/range {v1 .. v9}, Ljj;->b(Lqs;Lqs;IFLqs;Lqs;II)V

    move/from16 v1, p2

    move/from16 v4, v22

    move/from16 v23, v26

    goto :goto_25

    :cond_3f
    move-object v14, v2

    move-object/from16 p9, v6

    move-object/from16 v27, v8

    move/from16 p5, v11

    move/from16 p8, v12

    move-object/from16 p15, v13

    move v4, v15

    move-object v15, v1

    move-object v11, v3

    move-object v12, v7

    move-object v13, v9

    move/from16 v1, p3

    .line 67
    :goto_25
    iget v2, v0, Ld8;->j0:I

    const/16 v3, 0x8

    if-ne v2, v3, :cond_42

    .line 68
    iget-object v2, v14, Lv7;->a:Ljava/util/HashSet;

    if-nez v2, :cond_40

    goto :goto_26

    .line 69
    :cond_40
    invoke-virtual {v2}, Ljava/util/HashSet;->size()I

    move-result v2

    if-lez v2, :cond_41

    const/4 v2, 0x1

    goto :goto_27

    :cond_41
    :goto_26
    const/4 v2, 0x0

    :goto_27
    if-nez v2, :cond_42

    return-void

    :cond_42
    if-eqz v25, :cond_46

    if-eqz v1, :cond_44

    move-object/from16 v2, p9

    if-eq v12, v2, :cond_45

    if-nez v21, :cond_45

    .line 70
    instance-of v3, v11, Lv3;

    if-nez v3, :cond_43

    instance-of v3, v15, Lv3;

    if-eqz v3, :cond_45

    :cond_43
    const/4 v4, 0x6

    goto :goto_28

    :cond_44
    move-object/from16 v2, p9

    .line 71
    :cond_45
    :goto_28
    invoke-virtual/range {p10 .. p10}, Lv7;->e()I

    move-result v3

    invoke-virtual {v10, v13, v12, v3, v4}, Ljj;->f(Lqs;Lqs;II)V

    .line 72
    invoke-virtual/range {p11 .. p11}, Lv7;->e()I

    move-result v3

    neg-int v3, v3

    move-object/from16 v5, v27

    invoke-virtual {v10, v5, v2, v3, v4}, Ljj;->g(Lqs;Lqs;II)V

    goto :goto_29

    :cond_46
    move-object/from16 v2, p9

    move-object/from16 v5, v27

    :goto_29
    if-eqz v1, :cond_47

    if-eqz p21, :cond_47

    .line 73
    instance-of v3, v11, Lv3;

    if-nez v3, :cond_47

    instance-of v3, v15, Lv3;

    if-nez v3, :cond_47

    move-object/from16 v3, p15

    if-eq v15, v3, :cond_48

    const/4 v4, 0x6

    const/4 v6, 0x6

    const/16 v20, 0x1

    goto :goto_2a

    :cond_47
    move-object/from16 v3, p15

    :cond_48
    move/from16 v6, v19

    move/from16 v20, v23

    :goto_2a
    if-eqz v20, :cond_55

    if-eqz v24, :cond_51

    if-eqz p20, :cond_49

    if-eqz p4, :cond_51

    :cond_49
    if-eq v11, v3, :cond_4b

    if-ne v15, v3, :cond_4a

    goto :goto_2b

    :cond_4a
    move/from16 v16, v6

    .line 74
    :cond_4b
    :goto_2b
    instance-of v7, v11, Lyf;

    if-nez v7, :cond_4c

    instance-of v7, v15, Lyf;

    if-eqz v7, :cond_4d

    :cond_4c
    const/16 v16, 0x5

    .line 75
    :cond_4d
    instance-of v7, v11, Lv3;

    if-nez v7, :cond_4e

    instance-of v7, v15, Lv3;

    if-eqz v7, :cond_4f

    :cond_4e
    const/16 v16, 0x5

    :cond_4f
    if-eqz p20, :cond_50

    const/4 v7, 0x5

    goto :goto_2c

    :cond_50
    move/from16 v7, v16

    .line 76
    :goto_2c
    invoke-static {v7, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    :cond_51
    if-eqz v1, :cond_54

    .line 77
    invoke-static {v4, v6}, Ljava/lang/Math;->min(II)I

    move-result v4

    if-eqz p17, :cond_53

    if-nez p20, :cond_53

    if-eq v11, v3, :cond_52

    if-ne v15, v3, :cond_53

    :cond_52
    const/4 v11, 0x4

    goto :goto_2d

    :cond_53
    move v11, v4

    goto :goto_2d

    :cond_54
    move v11, v6

    .line 78
    :goto_2d
    invoke-virtual/range {p10 .. p10}, Lv7;->e()I

    move-result v3

    invoke-virtual {v10, v13, v12, v3, v11}, Ljj;->e(Lqs;Lqs;II)V

    .line 79
    invoke-virtual/range {p11 .. p11}, Lv7;->e()I

    move-result v3

    neg-int v3, v3

    invoke-virtual {v10, v5, v2, v3, v11}, Ljj;->e(Lqs;Lqs;II)V

    :cond_55
    if-eqz v1, :cond_57

    move-object/from16 v3, p6

    move-object v4, v12

    if-ne v3, v4, :cond_56

    .line 80
    invoke-virtual/range {p10 .. p10}, Lv7;->e()I

    move-result v6

    goto :goto_2e

    :cond_56
    const/4 v6, 0x0

    :goto_2e
    if-eq v4, v3, :cond_57

    const/4 v4, 0x5

    .line 81
    invoke-virtual {v10, v13, v3, v6, v4}, Ljj;->f(Lqs;Lqs;II)V

    :cond_57
    if-eqz v1, :cond_59

    if-eqz v21, :cond_59

    if-nez p14, :cond_59

    if-nez p8, :cond_59

    if-eqz v21, :cond_58

    move/from16 v3, v17

    const/4 v4, 0x3

    if-ne v3, v4, :cond_58

    const/16 v3, 0x8

    const/4 v4, 0x0

    .line 82
    invoke-virtual {v10, v5, v13, v4, v3}, Ljj;->f(Lqs;Lqs;II)V

    goto :goto_2f

    :cond_58
    const/4 v4, 0x0

    const/4 v3, 0x5

    .line 83
    invoke-virtual {v10, v5, v13, v4, v3}, Ljj;->f(Lqs;Lqs;II)V

    goto :goto_32

    :cond_59
    :goto_2f
    const/4 v3, 0x5

    goto :goto_32

    :cond_5a
    :goto_30
    move-object/from16 v14, p11

    move-object v2, v6

    move-object v5, v8

    move/from16 p5, v11

    goto/16 :goto_10

    :goto_31
    move/from16 v1, p3

    :goto_32
    const/4 v11, 0x5

    :goto_33
    if-eqz v1, :cond_5c

    if-eqz p5, :cond_5c

    .line 84
    iget-object v1, v14, Lv7;->f:Lv7;

    if-eqz v1, :cond_5b

    .line 85
    invoke-virtual/range {p11 .. p11}, Lv7;->e()I

    move-result v1

    move-object/from16 v4, p7

    goto :goto_34

    :cond_5b
    move-object/from16 v4, p7

    const/4 v1, 0x0

    :goto_34
    if-eq v2, v4, :cond_5c

    .line 86
    invoke-virtual {v10, v4, v5, v1, v11}, Ljj;->f(Lqs;Lqs;II)V

    :cond_5c
    return-void

    :cond_5d
    :goto_35
    move-object/from16 v3, p6

    move-object/from16 v4, p7

    move-object v5, v8

    move-object v13, v9

    move/from16 p5, v11

    move/from16 v1, v23

    const/4 v2, 0x3

    const/4 v6, 0x2

    if-ge v1, v6, :cond_62

    if-eqz p3, :cond_62

    if-eqz p5, :cond_62

    const/16 v1, 0x8

    const/4 v6, 0x0

    .line 87
    invoke-virtual {v10, v13, v3, v6, v1}, Ljj;->f(Lqs;Lqs;II)V

    .line 88
    iget-object v1, v0, Ld8;->O:Lv7;

    if-nez p2, :cond_5f

    iget-object v3, v1, Lv7;->f:Lv7;

    if-nez v3, :cond_5e

    goto :goto_36

    :cond_5e
    const/4 v11, 0x0

    goto :goto_37

    :cond_5f
    :goto_36
    const/4 v11, 0x1

    :goto_37
    if-nez p2, :cond_61

    .line 89
    iget-object v1, v1, Lv7;->f:Lv7;

    if-eqz v1, :cond_61

    .line 90
    iget-object v1, v1, Lv7;->d:Ld8;

    iget v3, v1, Ld8;->Z:F

    const/4 v6, 0x0

    cmpl-float v3, v3, v6

    if-eqz v3, :cond_60

    iget-object v1, v1, Ld8;->V:[I

    const/4 v3, 0x0

    aget v6, v1, v3

    if-ne v6, v2, :cond_60

    const/4 v3, 0x1

    aget v1, v1, v3

    if-ne v1, v2, :cond_60

    const/4 v11, 0x1

    goto :goto_38

    :cond_60
    const/4 v11, 0x0

    :cond_61
    :goto_38
    if-eqz v11, :cond_62

    const/16 v1, 0x8

    const/4 v2, 0x0

    .line 91
    invoke-virtual {v10, v4, v5, v2, v1}, Ljj;->f(Lqs;Lqs;II)V

    :cond_62
    return-void

    :cond_63
    const/4 v1, 0x0

    .line 92
    throw v1
.end method

.method public final f(Lv7$a;Ld8;Lv7$a;I)V
    .locals 10

    .line 1
    sget-object v0, Lv7$a;->h:Lv7$a;

    .line 3
    sget-object v1, Lv7$a;->j:Lv7$a;

    .line 5
    sget-object v2, Lv7$a;->i:Lv7$a;

    .line 7
    sget-object v3, Lv7$a;->c:Lv7$a;

    .line 9
    sget-object v4, Lv7$a;->d:Lv7$a;

    .line 11
    sget-object v5, Lv7$a;->e:Lv7$a;

    .line 13
    sget-object v6, Lv7$a;->f:Lv7$a;

    .line 15
    const/4 v7, 0x0

    .line 16
    if-ne p1, v0, :cond_c

    .line 18
    if-ne p3, v0, :cond_8

    .line 20
    invoke-virtual {p0, v3}, Ld8;->j(Lv7$a;)Lv7;

    .line 23
    move-result-object p1

    .line 24
    invoke-virtual {p0, v5}, Ld8;->j(Lv7$a;)Lv7;

    .line 27
    move-result-object p3

    .line 28
    invoke-virtual {p0, v4}, Ld8;->j(Lv7$a;)Lv7;

    .line 31
    move-result-object p4

    .line 32
    invoke-virtual {p0, v6}, Ld8;->j(Lv7$a;)Lv7;

    .line 35
    move-result-object v8

    .line 36
    const/4 v9, 0x1

    .line 37
    if-eqz p1, :cond_0

    .line 39
    invoke-virtual {p1}, Lv7;->h()Z

    .line 42
    move-result p1

    .line 43
    if-nez p1, :cond_1

    .line 45
    :cond_0
    if-eqz p3, :cond_2

    .line 47
    invoke-virtual {p3}, Lv7;->h()Z

    .line 50
    move-result p1

    .line 51
    if-eqz p1, :cond_2

    .line 53
    :cond_1
    const/4 p1, 0x0

    .line 54
    goto :goto_0

    .line 55
    :cond_2
    invoke-virtual {p0, v3, p2, v3, v7}, Ld8;->f(Lv7$a;Ld8;Lv7$a;I)V

    .line 58
    invoke-virtual {p0, v5, p2, v5, v7}, Ld8;->f(Lv7$a;Ld8;Lv7$a;I)V

    .line 61
    const/4 p1, 0x1

    .line 62
    :goto_0
    if-eqz p4, :cond_3

    .line 64
    invoke-virtual {p4}, Lv7;->h()Z

    .line 67
    move-result p3

    .line 68
    if-nez p3, :cond_4

    .line 70
    :cond_3
    if-eqz v8, :cond_5

    .line 72
    invoke-virtual {v8}, Lv7;->h()Z

    .line 75
    move-result p3

    .line 76
    if-eqz p3, :cond_5

    .line 78
    :cond_4
    const/4 v9, 0x0

    .line 79
    goto :goto_1

    .line 80
    :cond_5
    invoke-virtual {p0, v4, p2, v4, v7}, Ld8;->f(Lv7$a;Ld8;Lv7$a;I)V

    .line 83
    invoke-virtual {p0, v6, p2, v6, v7}, Ld8;->f(Lv7$a;Ld8;Lv7$a;I)V

    .line 86
    :goto_1
    if-eqz p1, :cond_6

    .line 88
    if-eqz v9, :cond_6

    .line 90
    invoke-virtual {p0, v0}, Ld8;->j(Lv7$a;)Lv7;

    .line 93
    move-result-object p1

    .line 94
    invoke-virtual {p2, v0}, Ld8;->j(Lv7$a;)Lv7;

    .line 97
    move-result-object p2

    .line 98
    invoke-virtual {p1, p2, v7}, Lv7;->a(Lv7;I)V

    .line 101
    goto/16 :goto_5

    .line 103
    :cond_6
    if-eqz p1, :cond_7

    .line 105
    invoke-virtual {p0, v2}, Ld8;->j(Lv7$a;)Lv7;

    .line 108
    move-result-object p1

    .line 109
    invoke-virtual {p2, v2}, Ld8;->j(Lv7$a;)Lv7;

    .line 112
    move-result-object p2

    .line 113
    invoke-virtual {p1, p2, v7}, Lv7;->a(Lv7;I)V

    .line 116
    goto/16 :goto_5

    .line 118
    :cond_7
    if-eqz v9, :cond_1c

    .line 120
    invoke-virtual {p0, v1}, Ld8;->j(Lv7$a;)Lv7;

    .line 123
    move-result-object p1

    .line 124
    invoke-virtual {p2, v1}, Ld8;->j(Lv7$a;)Lv7;

    .line 127
    move-result-object p2

    .line 128
    invoke-virtual {p1, p2, v7}, Lv7;->a(Lv7;I)V

    .line 131
    goto/16 :goto_5

    .line 133
    :cond_8
    if-eq p3, v3, :cond_b

    .line 135
    if-ne p3, v5, :cond_9

    .line 137
    goto :goto_2

    .line 138
    :cond_9
    if-eq p3, v4, :cond_a

    .line 140
    if-ne p3, v6, :cond_1c

    .line 142
    :cond_a
    invoke-virtual {p0, v4, p2, p3, v7}, Ld8;->f(Lv7$a;Ld8;Lv7$a;I)V

    .line 145
    invoke-virtual {p0, v6, p2, p3, v7}, Ld8;->f(Lv7$a;Ld8;Lv7$a;I)V

    .line 148
    invoke-virtual {p0, v0}, Ld8;->j(Lv7$a;)Lv7;

    .line 151
    move-result-object p1

    .line 152
    invoke-virtual {p2, p3}, Ld8;->j(Lv7$a;)Lv7;

    .line 155
    move-result-object p2

    .line 156
    invoke-virtual {p1, p2, v7}, Lv7;->a(Lv7;I)V

    .line 159
    goto/16 :goto_5

    .line 161
    :cond_b
    :goto_2
    invoke-virtual {p0, v3, p2, p3, v7}, Ld8;->f(Lv7$a;Ld8;Lv7$a;I)V

    .line 164
    :try_start_0
    invoke-virtual {p0, v5, p2, p3, v7}, Ld8;->f(Lv7$a;Ld8;Lv7$a;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 167
    invoke-virtual {p0, v0}, Ld8;->j(Lv7$a;)Lv7;

    .line 170
    move-result-object p1

    .line 171
    invoke-virtual {p2, p3}, Ld8;->j(Lv7$a;)Lv7;

    .line 174
    move-result-object p2

    .line 175
    invoke-virtual {p1, p2, v7}, Lv7;->a(Lv7;I)V

    .line 178
    goto/16 :goto_5

    .line 180
    :catchall_0
    move-exception p1

    .line 181
    throw p1

    .line 182
    :cond_c
    if-ne p1, v2, :cond_e

    .line 184
    if-eq p3, v3, :cond_d

    .line 186
    if-ne p3, v5, :cond_e

    .line 188
    :cond_d
    invoke-virtual {p0, v3}, Ld8;->j(Lv7$a;)Lv7;

    .line 191
    move-result-object p1

    .line 192
    invoke-virtual {p2, p3}, Ld8;->j(Lv7$a;)Lv7;

    .line 195
    move-result-object p2

    .line 196
    invoke-virtual {p0, v5}, Ld8;->j(Lv7$a;)Lv7;

    .line 199
    move-result-object p3

    .line 200
    invoke-virtual {p1, p2, v7}, Lv7;->a(Lv7;I)V

    .line 203
    invoke-virtual {p3, p2, v7}, Lv7;->a(Lv7;I)V

    .line 206
    invoke-virtual {p0, v2}, Ld8;->j(Lv7$a;)Lv7;

    .line 209
    move-result-object p1

    .line 210
    invoke-virtual {p1, p2, v7}, Lv7;->a(Lv7;I)V

    .line 213
    goto/16 :goto_5

    .line 215
    :cond_e
    if-ne p1, v1, :cond_10

    .line 217
    if-eq p3, v4, :cond_f

    .line 219
    if-ne p3, v6, :cond_10

    .line 221
    :cond_f
    invoke-virtual {p2, p3}, Ld8;->j(Lv7$a;)Lv7;

    .line 224
    move-result-object p1

    .line 225
    invoke-virtual {p0, v4}, Ld8;->j(Lv7$a;)Lv7;

    .line 228
    move-result-object p2

    .line 229
    invoke-virtual {p2, p1, v7}, Lv7;->a(Lv7;I)V

    .line 232
    invoke-virtual {p0, v6}, Ld8;->j(Lv7$a;)Lv7;

    .line 235
    move-result-object p2

    .line 236
    invoke-virtual {p2, p1, v7}, Lv7;->a(Lv7;I)V

    .line 239
    invoke-virtual {p0, v1}, Ld8;->j(Lv7$a;)Lv7;

    .line 242
    move-result-object p2

    .line 243
    invoke-virtual {p2, p1, v7}, Lv7;->a(Lv7;I)V

    .line 246
    goto/16 :goto_5

    .line 248
    :cond_10
    if-ne p1, v2, :cond_11

    .line 250
    if-ne p3, v2, :cond_11

    .line 252
    invoke-virtual {p0, v3}, Ld8;->j(Lv7$a;)Lv7;

    .line 255
    move-result-object p1

    .line 256
    invoke-virtual {p2, v3}, Ld8;->j(Lv7$a;)Lv7;

    .line 259
    move-result-object p4

    .line 260
    invoke-virtual {p1, p4, v7}, Lv7;->a(Lv7;I)V

    .line 263
    invoke-virtual {p0, v5}, Ld8;->j(Lv7$a;)Lv7;

    .line 266
    move-result-object p1

    .line 267
    invoke-virtual {p2, v5}, Ld8;->j(Lv7$a;)Lv7;

    .line 270
    move-result-object p4

    .line 271
    invoke-virtual {p1, p4, v7}, Lv7;->a(Lv7;I)V

    .line 274
    invoke-virtual {p0, v2}, Ld8;->j(Lv7$a;)Lv7;

    .line 277
    move-result-object p1

    .line 278
    invoke-virtual {p2, p3}, Ld8;->j(Lv7$a;)Lv7;

    .line 281
    move-result-object p2

    .line 282
    invoke-virtual {p1, p2, v7}, Lv7;->a(Lv7;I)V

    .line 285
    goto/16 :goto_5

    .line 287
    :cond_11
    if-ne p1, v1, :cond_12

    .line 289
    if-ne p3, v1, :cond_12

    .line 291
    invoke-virtual {p0, v4}, Ld8;->j(Lv7$a;)Lv7;

    .line 294
    move-result-object p1

    .line 295
    invoke-virtual {p2, v4}, Ld8;->j(Lv7$a;)Lv7;

    .line 298
    move-result-object p4

    .line 299
    invoke-virtual {p1, p4, v7}, Lv7;->a(Lv7;I)V

    .line 302
    invoke-virtual {p0, v6}, Ld8;->j(Lv7$a;)Lv7;

    .line 305
    move-result-object p1

    .line 306
    invoke-virtual {p2, v6}, Ld8;->j(Lv7$a;)Lv7;

    .line 309
    move-result-object p4

    .line 310
    invoke-virtual {p1, p4, v7}, Lv7;->a(Lv7;I)V

    .line 313
    invoke-virtual {p0, v1}, Ld8;->j(Lv7$a;)Lv7;

    .line 316
    move-result-object p1

    .line 317
    invoke-virtual {p2, p3}, Ld8;->j(Lv7$a;)Lv7;

    .line 320
    move-result-object p2

    .line 321
    invoke-virtual {p1, p2, v7}, Lv7;->a(Lv7;I)V

    .line 324
    goto/16 :goto_5

    .line 326
    :cond_12
    invoke-virtual {p0, p1}, Ld8;->j(Lv7$a;)Lv7;

    .line 329
    move-result-object v7

    .line 330
    invoke-virtual {p2, p3}, Ld8;->j(Lv7$a;)Lv7;

    .line 333
    move-result-object p2

    .line 334
    invoke-virtual {v7, p2}, Lv7;->i(Lv7;)Z

    .line 337
    move-result p3

    .line 338
    if-eqz p3, :cond_1c

    .line 340
    sget-object p3, Lv7$a;->g:Lv7$a;

    .line 342
    if-ne p1, p3, :cond_14

    .line 344
    invoke-virtual {p0, v4}, Ld8;->j(Lv7$a;)Lv7;

    .line 347
    move-result-object p1

    .line 348
    invoke-virtual {p0, v6}, Ld8;->j(Lv7$a;)Lv7;

    .line 351
    move-result-object p3

    .line 352
    if-eqz p1, :cond_13

    .line 354
    invoke-virtual {p1}, Lv7;->j()V

    .line 357
    :cond_13
    if-eqz p3, :cond_1b

    .line 359
    invoke-virtual {p3}, Lv7;->j()V

    .line 362
    goto :goto_4

    .line 363
    :cond_14
    if-eq p1, v4, :cond_18

    .line 365
    if-ne p1, v6, :cond_15

    .line 367
    goto :goto_3

    .line 368
    :cond_15
    if-eq p1, v3, :cond_16

    .line 370
    if-ne p1, v5, :cond_1b

    .line 372
    :cond_16
    invoke-virtual {p0, v0}, Ld8;->j(Lv7$a;)Lv7;

    .line 375
    move-result-object p3

    .line 376
    iget-object v0, p3, Lv7;->f:Lv7;

    .line 378
    if-eq v0, p2, :cond_17

    .line 380
    invoke-virtual {p3}, Lv7;->j()V

    .line 383
    :cond_17
    invoke-virtual {p0, p1}, Ld8;->j(Lv7$a;)Lv7;

    .line 386
    move-result-object p1

    .line 387
    invoke-virtual {p1}, Lv7;->f()Lv7;

    .line 390
    move-result-object p1

    .line 391
    invoke-virtual {p0, v2}, Ld8;->j(Lv7$a;)Lv7;

    .line 394
    move-result-object p3

    .line 395
    invoke-virtual {p3}, Lv7;->h()Z

    .line 398
    move-result v0

    .line 399
    if-eqz v0, :cond_1b

    .line 401
    invoke-virtual {p1}, Lv7;->j()V

    .line 404
    invoke-virtual {p3}, Lv7;->j()V

    .line 407
    goto :goto_4

    .line 408
    :cond_18
    :goto_3
    invoke-virtual {p0, p3}, Ld8;->j(Lv7$a;)Lv7;

    .line 411
    move-result-object p3

    .line 412
    if-eqz p3, :cond_19

    .line 414
    invoke-virtual {p3}, Lv7;->j()V

    .line 417
    :cond_19
    invoke-virtual {p0, v0}, Ld8;->j(Lv7$a;)Lv7;

    .line 420
    move-result-object p3

    .line 421
    iget-object v0, p3, Lv7;->f:Lv7;

    .line 423
    if-eq v0, p2, :cond_1a

    .line 425
    invoke-virtual {p3}, Lv7;->j()V

    .line 428
    :cond_1a
    invoke-virtual {p0, p1}, Ld8;->j(Lv7$a;)Lv7;

    .line 431
    move-result-object p1

    .line 432
    invoke-virtual {p1}, Lv7;->f()Lv7;

    .line 435
    move-result-object p1

    .line 436
    invoke-virtual {p0, v1}, Ld8;->j(Lv7$a;)Lv7;

    .line 439
    move-result-object p3

    .line 440
    invoke-virtual {p3}, Lv7;->h()Z

    .line 443
    move-result v0

    .line 444
    if-eqz v0, :cond_1b

    .line 446
    invoke-virtual {p1}, Lv7;->j()V

    .line 449
    invoke-virtual {p3}, Lv7;->j()V

    .line 452
    :cond_1b
    :goto_4
    invoke-virtual {v7, p2, p4}, Lv7;->a(Lv7;I)V

    .line 455
    :cond_1c
    :goto_5
    return-void
.end method

.method public final g(Lv7;Lv7;I)V
    .locals 1

    .line 1
    iget-object v0, p1, Lv7;->d:Ld8;

    .line 3
    if-ne v0, p0, :cond_0

    .line 5
    iget-object v0, p2, Lv7;->d:Ld8;

    .line 7
    iget-object p1, p1, Lv7;->e:Lv7$a;

    .line 9
    iget-object p2, p2, Lv7;->e:Lv7$a;

    .line 11
    invoke-virtual {p0, p1, v0, p2, p3}, Ld8;->f(Lv7$a;Ld8;Lv7$a;I)V

    .line 14
    :cond_0
    return-void
.end method

.method public final h(Ljj;)V
    .locals 1

    .line 1
    iget-object v0, p0, Ld8;->K:Lv7;

    .line 3
    invoke-virtual {p1, v0}, Ljj;->k(Ljava/lang/Object;)Lqs;

    .line 6
    iget-object v0, p0, Ld8;->L:Lv7;

    .line 8
    invoke-virtual {p1, v0}, Ljj;->k(Ljava/lang/Object;)Lqs;

    .line 11
    iget-object v0, p0, Ld8;->M:Lv7;

    .line 13
    invoke-virtual {p1, v0}, Ljj;->k(Ljava/lang/Object;)Lqs;

    .line 16
    iget-object v0, p0, Ld8;->N:Lv7;

    .line 18
    invoke-virtual {p1, v0}, Ljj;->k(Ljava/lang/Object;)Lqs;

    .line 21
    iget v0, p0, Ld8;->d0:I

    .line 23
    if-lez v0, :cond_0

    .line 25
    iget-object v0, p0, Ld8;->O:Lv7;

    .line 27
    invoke-virtual {p1, v0}, Ljj;->k(Ljava/lang/Object;)Lqs;

    .line 30
    :cond_0
    return-void
.end method

.method public final i()V
    .locals 1

    .line 1
    iget-object v0, p0, Ld8;->d:Lng;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, Lng;

    .line 7
    invoke-direct {v0, p0}, Lng;-><init>(Ld8;)V

    .line 10
    iput-object v0, p0, Ld8;->d:Lng;

    .line 12
    :cond_0
    iget-object v0, p0, Ld8;->e:Llx;

    .line 14
    if-nez v0, :cond_1

    .line 16
    new-instance v0, Llx;

    .line 18
    invoke-direct {v0, p0}, Llx;-><init>(Ld8;)V

    .line 21
    iput-object v0, p0, Ld8;->e:Llx;

    .line 23
    :cond_1
    return-void
.end method

.method public j(Lv7$a;)Lv7;
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 4
    move-result v0

    .line 5
    packed-switch v0, :pswitch_data_0

    .line 8
    new-instance v0, Ljava/lang/AssertionError;

    .line 10
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 13
    move-result-object p1

    .line 14
    invoke-direct {v0, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 17
    throw v0

    .line 18
    :pswitch_0
    iget-object p1, p0, Ld8;->Q:Lv7;

    .line 20
    return-object p1

    .line 21
    :pswitch_1
    iget-object p1, p0, Ld8;->P:Lv7;

    .line 23
    return-object p1

    .line 24
    :pswitch_2
    iget-object p1, p0, Ld8;->R:Lv7;

    .line 26
    return-object p1

    .line 27
    :pswitch_3
    iget-object p1, p0, Ld8;->O:Lv7;

    .line 29
    return-object p1

    .line 30
    :pswitch_4
    iget-object p1, p0, Ld8;->N:Lv7;

    .line 32
    return-object p1

    .line 33
    :pswitch_5
    iget-object p1, p0, Ld8;->M:Lv7;

    .line 35
    return-object p1

    .line 36
    :pswitch_6
    iget-object p1, p0, Ld8;->L:Lv7;

    .line 38
    return-object p1

    .line 39
    :pswitch_7
    iget-object p1, p0, Ld8;->K:Lv7;

    .line 41
    return-object p1

    .line 42
    :pswitch_8
    const/4 p1, 0x0

    .line 43
    return-object p1

    .line 44
    nop

    .line 45
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final k(I)I
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, Ld8;->V:[I

    .line 4
    if-nez p1, :cond_0

    .line 6
    aget p1, v1, v0

    .line 8
    return p1

    .line 9
    :cond_0
    const/4 v2, 0x1

    .line 10
    if-ne p1, v2, :cond_1

    .line 12
    aget p1, v1, v2

    .line 14
    return p1

    .line 15
    :cond_1
    return v0
.end method

.method public final l()I
    .locals 2

    .line 1
    iget v0, p0, Ld8;->j0:I

    .line 3
    const/16 v1, 0x8

    .line 5
    if-ne v0, v1, :cond_0

    .line 7
    const/4 v0, 0x0

    .line 8
    return v0

    .line 9
    :cond_0
    iget v0, p0, Ld8;->Y:I

    .line 11
    return v0
.end method

.method public final m(I)Ld8;
    .locals 2

    .line 1
    if-nez p1, :cond_0

    .line 3
    iget-object p1, p0, Ld8;->M:Lv7;

    .line 5
    iget-object v0, p1, Lv7;->f:Lv7;

    .line 7
    if-eqz v0, :cond_1

    .line 9
    iget-object v1, v0, Lv7;->f:Lv7;

    .line 11
    if-ne v1, p1, :cond_1

    .line 13
    iget-object p1, v0, Lv7;->d:Ld8;

    .line 15
    return-object p1

    .line 16
    :cond_0
    const/4 v0, 0x1

    .line 17
    if-ne p1, v0, :cond_1

    .line 19
    iget-object p1, p0, Ld8;->N:Lv7;

    .line 21
    iget-object v0, p1, Lv7;->f:Lv7;

    .line 23
    if-eqz v0, :cond_1

    .line 25
    iget-object v1, v0, Lv7;->f:Lv7;

    .line 27
    if-ne v1, p1, :cond_1

    .line 29
    iget-object p1, v0, Lv7;->d:Ld8;

    .line 31
    return-object p1

    .line 32
    :cond_1
    const/4 p1, 0x0

    .line 33
    return-object p1
.end method

.method public final n(I)Ld8;
    .locals 2

    .line 1
    if-nez p1, :cond_0

    .line 3
    iget-object p1, p0, Ld8;->K:Lv7;

    .line 5
    iget-object v0, p1, Lv7;->f:Lv7;

    .line 7
    if-eqz v0, :cond_1

    .line 9
    iget-object v1, v0, Lv7;->f:Lv7;

    .line 11
    if-ne v1, p1, :cond_1

    .line 13
    iget-object p1, v0, Lv7;->d:Ld8;

    .line 15
    return-object p1

    .line 16
    :cond_0
    const/4 v0, 0x1

    .line 17
    if-ne p1, v0, :cond_1

    .line 19
    iget-object p1, p0, Ld8;->L:Lv7;

    .line 21
    iget-object v0, p1, Lv7;->f:Lv7;

    .line 23
    if-eqz v0, :cond_1

    .line 25
    iget-object v1, v0, Lv7;->f:Lv7;

    .line 27
    if-ne v1, p1, :cond_1

    .line 29
    iget-object p1, v0, Lv7;->d:Ld8;

    .line 31
    return-object p1

    .line 32
    :cond_1
    const/4 p1, 0x0

    .line 33
    return-object p1
.end method

.method public o(Ljava/lang/StringBuilder;)V
    .locals 11

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    const-string v1, "  "

    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 8
    iget-object v1, p0, Ld8;->k:Ljava/lang/String;

    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 13
    const-string v1, ":{\n"

    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 18
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    new-instance v0, Ljava/lang/StringBuilder;

    .line 27
    const-string v1, "    actualWidth:"

    .line 29
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 32
    iget v1, p0, Ld8;->X:I

    .line 34
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 37
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 40
    move-result-object v0

    .line 41
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    const-string v0, "\n"

    .line 46
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    new-instance v1, Ljava/lang/StringBuilder;

    .line 51
    const-string v2, "    actualHeight:"

    .line 53
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 56
    iget v2, p0, Ld8;->Y:I

    .line 58
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 61
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 64
    move-result-object v1

    .line 65
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 71
    new-instance v1, Ljava/lang/StringBuilder;

    .line 73
    const-string v2, "    actualLeft:"

    .line 75
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 78
    iget v2, p0, Ld8;->b0:I

    .line 80
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 83
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 86
    move-result-object v1

    .line 87
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 90
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 93
    new-instance v1, Ljava/lang/StringBuilder;

    .line 95
    const-string v2, "    actualTop:"

    .line 97
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 100
    iget v2, p0, Ld8;->c0:I

    .line 102
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 105
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 108
    move-result-object v1

    .line 109
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 112
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 115
    const-string v0, "left"

    .line 117
    iget-object v1, p0, Ld8;->K:Lv7;

    .line 119
    invoke-static {p1, v0, v1}, Ld8;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Lv7;)V

    .line 122
    const-string v0, "top"

    .line 124
    iget-object v1, p0, Ld8;->L:Lv7;

    .line 126
    invoke-static {p1, v0, v1}, Ld8;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Lv7;)V

    .line 129
    const-string v0, "right"

    .line 131
    iget-object v1, p0, Ld8;->M:Lv7;

    .line 133
    invoke-static {p1, v0, v1}, Ld8;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Lv7;)V

    .line 136
    const-string v0, "bottom"

    .line 138
    iget-object v1, p0, Ld8;->N:Lv7;

    .line 140
    invoke-static {p1, v0, v1}, Ld8;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Lv7;)V

    .line 143
    const-string v0, "baseline"

    .line 145
    iget-object v1, p0, Ld8;->O:Lv7;

    .line 147
    invoke-static {p1, v0, v1}, Ld8;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Lv7;)V

    .line 150
    const-string v0, "centerX"

    .line 152
    iget-object v1, p0, Ld8;->P:Lv7;

    .line 154
    invoke-static {p1, v0, v1}, Ld8;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Lv7;)V

    .line 157
    const-string v0, "centerY"

    .line 159
    iget-object v1, p0, Ld8;->Q:Lv7;

    .line 161
    invoke-static {p1, v0, v1}, Ld8;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Lv7;)V

    .line 164
    const-string v1, "    width"

    .line 166
    iget v2, p0, Ld8;->X:I

    .line 168
    iget v3, p0, Ld8;->e0:I

    .line 170
    iget-object v8, p0, Ld8;->D:[I

    .line 172
    const/4 v9, 0x0

    .line 173
    aget v4, v8, v9

    .line 175
    iget v5, p0, Ld8;->v:I

    .line 177
    iget v6, p0, Ld8;->s:I

    .line 179
    iget v7, p0, Ld8;->x:F

    .line 181
    iget-object v10, p0, Ld8;->n0:[F

    .line 183
    aget v0, v10, v9

    .line 185
    move-object v0, p1

    .line 186
    invoke-static/range {v0 .. v7}, Ld8;->p(Ljava/lang/StringBuilder;Ljava/lang/String;IIIIIF)V

    .line 189
    const-string v1, "    height"

    .line 191
    iget v2, p0, Ld8;->Y:I

    .line 193
    iget v3, p0, Ld8;->f0:I

    .line 195
    const/4 v0, 0x1

    .line 196
    aget v4, v8, v0

    .line 198
    iget v5, p0, Ld8;->y:I

    .line 200
    iget v6, p0, Ld8;->t:I

    .line 202
    iget v7, p0, Ld8;->A:F

    .line 204
    aget v0, v10, v0

    .line 206
    move-object v0, p1

    .line 207
    invoke-static/range {v0 .. v7}, Ld8;->p(Ljava/lang/StringBuilder;Ljava/lang/String;IIIIIF)V

    .line 210
    iget v0, p0, Ld8;->Z:F

    .line 212
    iget v1, p0, Ld8;->a0:I

    .line 214
    const/4 v2, 0x0

    .line 215
    cmpl-float v2, v0, v2

    .line 217
    if-nez v2, :cond_0

    .line 219
    goto :goto_0

    .line 220
    :cond_0
    const-string v2, "    dimensionRatio"

    .line 222
    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 225
    const-string v2, " :  ["

    .line 227
    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 230
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 233
    const-string v0, ","

    .line 235
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 238
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 241
    const-string v0, ""

    .line 243
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 246
    const-string v0, "],\n"

    .line 248
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 251
    :goto_0
    iget v0, p0, Ld8;->g0:F

    .line 253
    const-string v1, "    horizontalBias"

    .line 255
    const/high16 v2, 0x3f000000    # 0.5f

    .line 257
    invoke-static {p1, v1, v0, v2}, Ld8;->I(Ljava/lang/StringBuilder;Ljava/lang/String;FF)V

    .line 260
    const-string v0, "    verticalBias"

    .line 262
    iget v1, p0, Ld8;->h0:F

    .line 264
    invoke-static {p1, v0, v1, v2}, Ld8;->I(Ljava/lang/StringBuilder;Ljava/lang/String;FF)V

    .line 267
    const-string v0, "    horizontalChainStyle"

    .line 269
    iget v1, p0, Ld8;->l0:I

    .line 271
    invoke-static {v1, v9, v0, p1}, Ld8;->H(IILjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 274
    const-string v0, "    verticalChainStyle"

    .line 276
    iget v1, p0, Ld8;->m0:I

    .line 278
    invoke-static {v1, v9, v0, p1}, Ld8;->H(IILjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 281
    const-string v0, "  }"

    .line 283
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 286
    return-void
.end method

.method public final r()I
    .locals 2

    .line 1
    iget v0, p0, Ld8;->j0:I

    .line 3
    const/16 v1, 0x8

    .line 5
    if-ne v0, v1, :cond_0

    .line 7
    const/4 v0, 0x0

    .line 8
    return v0

    .line 9
    :cond_0
    iget v0, p0, Ld8;->X:I

    .line 11
    return v0
.end method

.method public final s()I
    .locals 2

    .line 1
    iget-object v0, p0, Ld8;->W:Ld8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    instance-of v1, v0, Le8;

    .line 7
    if-eqz v1, :cond_0

    .line 9
    check-cast v0, Le8;

    .line 11
    iget v0, v0, Le8;->z0:I

    .line 13
    iget v1, p0, Ld8;->b0:I

    .line 15
    add-int/2addr v0, v1

    .line 16
    return v0

    .line 17
    :cond_0
    iget v0, p0, Ld8;->b0:I

    .line 19
    return v0
.end method

.method public final t()I
    .locals 2

    .line 1
    iget-object v0, p0, Ld8;->W:Ld8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    instance-of v1, v0, Le8;

    .line 7
    if-eqz v1, :cond_0

    .line 9
    check-cast v0, Le8;

    .line 11
    iget v0, v0, Le8;->A0:I

    .line 13
    iget v1, p0, Ld8;->c0:I

    .line 15
    add-int/2addr v0, v1

    .line 16
    return v0

    .line 17
    :cond_0
    iget v0, p0, Ld8;->c0:I

    .line 19
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 6
    const-string v1, ""

    .line 8
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    iget-object v2, p0, Ld8;->k0:Ljava/lang/String;

    .line 13
    if-eqz v2, :cond_0

    .line 15
    new-instance v1, Ljava/lang/StringBuilder;

    .line 17
    const-string v2, "id: "

    .line 19
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 22
    iget-object v2, p0, Ld8;->k0:Ljava/lang/String;

    .line 24
    const-string v3, " "

    .line 26
    invoke-static {v1, v2, v3}, Lps;->e(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 29
    move-result-object v1

    .line 30
    :cond_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    const-string v1, "("

    .line 35
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 38
    iget v1, p0, Ld8;->b0:I

    .line 40
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 43
    const-string v1, ", "

    .line 45
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 48
    iget v1, p0, Ld8;->c0:I

    .line 50
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 53
    const-string v1, ") - ("

    .line 55
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 58
    iget v1, p0, Ld8;->X:I

    .line 60
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 63
    const-string v1, " x "

    .line 65
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    iget v1, p0, Ld8;->Y:I

    .line 70
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 73
    const-string v1, ")"

    .line 75
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 78
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 81
    move-result-object v0

    .line 82
    return-object v0
.end method

.method public final u(I)Z
    .locals 4

    .line 1
    const/4 v0, 0x2

    .line 2
    const/4 v1, 0x1

    .line 3
    const/4 v2, 0x0

    .line 4
    if-nez p1, :cond_3

    .line 6
    iget-object p1, p0, Ld8;->K:Lv7;

    .line 8
    iget-object p1, p1, Lv7;->f:Lv7;

    .line 10
    if-eqz p1, :cond_0

    .line 12
    const/4 p1, 0x1

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 p1, 0x0

    .line 15
    :goto_0
    iget-object v3, p0, Ld8;->M:Lv7;

    .line 17
    iget-object v3, v3, Lv7;->f:Lv7;

    .line 19
    if-eqz v3, :cond_1

    .line 21
    const/4 v3, 0x1

    .line 22
    goto :goto_1

    .line 23
    :cond_1
    const/4 v3, 0x0

    .line 24
    :goto_1
    add-int/2addr p1, v3

    .line 25
    if-ge p1, v0, :cond_2

    .line 27
    goto :goto_2

    .line 28
    :cond_2
    const/4 v1, 0x0

    .line 29
    :goto_2
    return v1

    .line 30
    :cond_3
    iget-object p1, p0, Ld8;->L:Lv7;

    .line 32
    iget-object p1, p1, Lv7;->f:Lv7;

    .line 34
    if-eqz p1, :cond_4

    .line 36
    const/4 p1, 0x1

    .line 37
    goto :goto_3

    .line 38
    :cond_4
    const/4 p1, 0x0

    .line 39
    :goto_3
    iget-object v3, p0, Ld8;->N:Lv7;

    .line 41
    iget-object v3, v3, Lv7;->f:Lv7;

    .line 43
    if-eqz v3, :cond_5

    .line 45
    const/4 v3, 0x1

    .line 46
    goto :goto_4

    .line 47
    :cond_5
    const/4 v3, 0x0

    .line 48
    :goto_4
    add-int/2addr p1, v3

    .line 49
    iget-object v3, p0, Ld8;->O:Lv7;

    .line 51
    iget-object v3, v3, Lv7;->f:Lv7;

    .line 53
    if-eqz v3, :cond_6

    .line 55
    const/4 v3, 0x1

    .line 56
    goto :goto_5

    .line 57
    :cond_6
    const/4 v3, 0x0

    .line 58
    :goto_5
    add-int/2addr p1, v3

    .line 59
    if-ge p1, v0, :cond_7

    .line 61
    goto :goto_6

    .line 62
    :cond_7
    const/4 v1, 0x0

    .line 63
    :goto_6
    return v1
.end method

.method public final v(II)Z
    .locals 5

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    if-nez p1, :cond_1

    .line 5
    iget-object p1, p0, Ld8;->K:Lv7;

    .line 7
    iget-object v2, p1, Lv7;->f:Lv7;

    .line 9
    if-eqz v2, :cond_3

    .line 11
    iget-boolean v2, v2, Lv7;->c:Z

    .line 13
    if-eqz v2, :cond_3

    .line 15
    iget-object v2, p0, Ld8;->M:Lv7;

    .line 17
    iget-object v3, v2, Lv7;->f:Lv7;

    .line 19
    if-eqz v3, :cond_3

    .line 21
    iget-boolean v4, v3, Lv7;->c:Z

    .line 23
    if-eqz v4, :cond_3

    .line 25
    invoke-virtual {v3}, Lv7;->d()I

    .line 28
    move-result v3

    .line 29
    invoke-virtual {v2}, Lv7;->e()I

    .line 32
    move-result v2

    .line 33
    sub-int/2addr v3, v2

    .line 34
    iget-object v2, p1, Lv7;->f:Lv7;

    .line 36
    invoke-virtual {v2}, Lv7;->d()I

    .line 39
    move-result v2

    .line 40
    invoke-virtual {p1}, Lv7;->e()I

    .line 43
    move-result p1

    .line 44
    add-int/2addr p1, v2

    .line 45
    sub-int/2addr v3, p1

    .line 46
    if-lt v3, p2, :cond_0

    .line 48
    goto :goto_0

    .line 49
    :cond_0
    const/4 v0, 0x0

    .line 50
    :goto_0
    return v0

    .line 51
    :cond_1
    iget-object p1, p0, Ld8;->L:Lv7;

    .line 53
    iget-object v2, p1, Lv7;->f:Lv7;

    .line 55
    if-eqz v2, :cond_3

    .line 57
    iget-boolean v2, v2, Lv7;->c:Z

    .line 59
    if-eqz v2, :cond_3

    .line 61
    iget-object v2, p0, Ld8;->N:Lv7;

    .line 63
    iget-object v3, v2, Lv7;->f:Lv7;

    .line 65
    if-eqz v3, :cond_3

    .line 67
    iget-boolean v4, v3, Lv7;->c:Z

    .line 69
    if-eqz v4, :cond_3

    .line 71
    invoke-virtual {v3}, Lv7;->d()I

    .line 74
    move-result v3

    .line 75
    invoke-virtual {v2}, Lv7;->e()I

    .line 78
    move-result v2

    .line 79
    sub-int/2addr v3, v2

    .line 80
    iget-object v2, p1, Lv7;->f:Lv7;

    .line 82
    invoke-virtual {v2}, Lv7;->d()I

    .line 85
    move-result v2

    .line 86
    invoke-virtual {p1}, Lv7;->e()I

    .line 89
    move-result p1

    .line 90
    add-int/2addr p1, v2

    .line 91
    sub-int/2addr v3, p1

    .line 92
    if-lt v3, p2, :cond_2

    .line 94
    goto :goto_1

    .line 95
    :cond_2
    const/4 v0, 0x0

    .line 96
    :goto_1
    return v0

    .line 97
    :cond_3
    return v1
.end method

.method public final w(Lv7$a;Ld8;Lv7$a;II)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Ld8;->j(Lv7$a;)Lv7;

    .line 4
    move-result-object p1

    .line 5
    invoke-virtual {p2, p3}, Ld8;->j(Lv7$a;)Lv7;

    .line 8
    move-result-object p2

    .line 9
    const/4 p3, 0x1

    .line 10
    invoke-virtual {p1, p2, p4, p5, p3}, Lv7;->b(Lv7;IIZ)Z

    .line 13
    return-void
.end method

.method public final x(I)Z
    .locals 3

    mul-int/lit8 p1, p1, 0x2

    iget-object v0, p0, Ld8;->S:[Lv7;

    aget-object v1, v0, p1

    iget-object v2, v1, Lv7;->f:Lv7;

    if-eqz v2, :cond_0

    iget-object v2, v2, Lv7;->f:Lv7;

    if-eq v2, v1, :cond_0

    const/4 v1, 0x1

    add-int/2addr p1, v1

    aget-object p1, v0, p1

    iget-object v0, p1, Lv7;->f:Lv7;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lv7;->f:Lv7;

    if-ne v0, p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public final y()Z
    .locals 2

    iget-object v0, p0, Ld8;->K:Lv7;

    iget-object v1, v0, Lv7;->f:Lv7;

    if-eqz v1, :cond_0

    iget-object v1, v1, Lv7;->f:Lv7;

    if-eq v1, v0, :cond_1

    :cond_0
    iget-object v0, p0, Ld8;->M:Lv7;

    iget-object v1, v0, Lv7;->f:Lv7;

    if-eqz v1, :cond_2

    iget-object v1, v1, Lv7;->f:Lv7;

    if-ne v1, v0, :cond_2

    :cond_1
    const/4 v0, 0x1

    return v0

    :cond_2
    const/4 v0, 0x0

    return v0
.end method

.method public final z()Z
    .locals 2

    iget-object v0, p0, Ld8;->L:Lv7;

    iget-object v1, v0, Lv7;->f:Lv7;

    if-eqz v1, :cond_0

    iget-object v1, v1, Lv7;->f:Lv7;

    if-eq v1, v0, :cond_1

    :cond_0
    iget-object v0, p0, Ld8;->N:Lv7;

    iget-object v1, v0, Lv7;->f:Lv7;

    if-eqz v1, :cond_2

    iget-object v1, v1, Lv7;->f:Lv7;

    if-ne v1, v0, :cond_2

    :cond_1
    const/4 v0, 0x1

    return v0

    :cond_2
    const/4 v0, 0x0

    return v0
.end method
