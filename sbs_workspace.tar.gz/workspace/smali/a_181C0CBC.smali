.class public final La_181C0CBC;
.super Laj;
.source "pslmilmm.java"
# processed-61221

# interfaces
.implements Llf;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_0F9A7702;->toString()Ljava/lang/String;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Laj;",
        "Llf<",
        "Ljava/lang/String;",
        "La_D9825592;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# static fields
.field public static final c:La_181C0CBC;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_181C0CBC;

    invoke-direct {v0}, La_181C0CBC;-><init>()V

    sput-object v0, La_181C0CBC;->c:La_181C0CBC;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Laj;-><init>()V

    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, Ljava/lang/String;

    .line 3
    check-cast p2, La_D9825592;

    .line 5
    const-string v0, "acc"

    # ep-tgkpjgdxyeil
    .line 7
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 10
    const-string v0, "element"

    .line 12
    invoke-static {v0, p2}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V
    # ep-triqhvphffdj

    .line 15
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_0

    .line 21
    const/4 v0, 0x1

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const/4 v0, 0x0

    .line 24
    :goto_0
    if-eqz v0, :cond_1

    # ep-oykkxelygdno
    .line 26
    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 29
    move-result-object p1

    .line 30
    goto :goto_1

    .line 31
    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 33
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 36
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    const-string p1, ", "

    .line 41
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 47
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 50
    move-result-object p1

    .line 51
    :goto_1
    return-object p1
.end method
