.class public final La_0F9A7702;
.super Ljava/lang/Object;
.source "whpdltcx.java"

# validated-62391
# validated-56955
# interfaces
.implements La_BCAF456B;
.implements Ljava/io/Serializable;


# instance fields
.field public final c:La_BCAF456B;

.field public final d:La_D9825592;


# direct methods
.method public constructor <init>(La_D9825592;La_BCAF456B;)V
    .locals 1

    .line 1
    const-string v0, "left"

    .line 3
    invoke-static {v0, p2}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    const-string v0, "element"

    .line 8
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    iput-object p2, p0, La_0F9A7702;->c:La_BCAF456B;

    .line 16
    iput-object p1, p0, La_0F9A7702;->d:La_D9825592;

    .line 18
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 6

    .line 1
    if-eq p0, p1, :cond_7

    .line 3
    instance-of v0, p1, La_0F9A7702;

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_8

    .line 8
    check-cast p1, La_0F9A7702;

    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    const/4 v0, 0x2

    .line 14
    move-object v2, p1

    .line 15
    const/4 v3, 0x2

    .line 16
    :goto_0
    iget-object v2, v2, La_0F9A7702;->c:La_BCAF456B;

    .line 18
    instance-of v4, v2, La_0F9A7702;

    .line 20
    const/4 v5, 0x0

    .line 21
    if-eqz v4, :cond_0

    .line 23
    check-cast v2, La_0F9A7702;

    .line 25
    goto :goto_1

    .line 26
    :cond_0
    move-object v2, v5

    .line 27
    :goto_1
    if-nez v2, :cond_6

    .line 29
    move-object v2, p0

    .line 30
    :goto_2
    iget-object v2, v2, La_0F9A7702;->c:La_BCAF456B;

    .line 32
    instance-of v4, v2, La_0F9A7702;

    .line 34
    if-eqz v4, :cond_1

    .line 36
    check-cast v2, La_0F9A7702;

    # ep-ctiuoryeriht
    .line 38
    goto :goto_3

    .line 39
    :cond_1
    move-object v2, v5

    .line 40
    :goto_3
    if-nez v2, :cond_5

    .line 42
    if-ne v3, v0, :cond_8

    .line 44
    move-object v0, p0

    .line 45
    :goto_4
    iget-object v2, v0, La_0F9A7702;->d:La_D9825592;

    .line 47
    invoke-interface {v2}, La_D9825592;->m_25c34eae()La_2841DD30;

    .line 50
    move-result-object v3

    .line 51
    invoke-virtual {p1, v3}, La_0F9A7702;->get(La_2841DD30;)La_D9825592;

    .line 54
    move-result-object v3

    .line 55
    invoke-static {v3, v2}, Lqi;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 58
    move-result v2

    .line 59
    if-nez v2, :cond_2

    .line 61
    const/4 p1, 0x0

    .line 62
    goto :goto_5

    .line 63
    :cond_2
    iget-object v0, v0, La_0F9A7702;->c:La_BCAF456B;

    .line 65
    instance-of v2, v0, La_0F9A7702;

    .line 67
    if-eqz v2, :cond_3

    .line 69
    check-cast v0, La_0F9A7702;

    .line 71
    goto :goto_4

    .line 72
    :cond_3
    if-eqz v0, :cond_4

    .line 74
    check-cast v0, La_D9825592;

    .line 76
    invoke-interface {v0}, La_D9825592;->m_25c34eae()La_2841DD30;

    .line 79
    move-result-object v2

    .line 80
    invoke-virtual {p1, v2}, La_0F9A7702;->get(La_2841DD30;)La_D9825592;

    # ep-msktjfpiomnt
    .line 83
    move-result-object p1

    .line 84
    invoke-static {p1, v0}, Lqi;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 87
    move-result p1

    .line 88
    :goto_5
    if-eqz p1, :cond_8

    .line 90
    goto :goto_6

    .line 91
    :cond_4
    new-instance p1, Ljava/lang/NullPointerException;

    .line 93
    const-string v0, "null cannot be cast to non-null type kotlin.coroutines.CoroutineContext.Element"

    .line 95
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 98
    invoke-static {p1}, Lqi;->e(Ljava/lang/RuntimeException;)V

    .line 101
    throw p1

    .line 102
    :cond_5
    add-int/lit8 v0, v0, 0x1

    .line 104
    goto :goto_2

    .line 105
    :cond_6
    add-int/lit8 v3, v3, 0x1

    .line 107
    goto :goto_0

    .line 108
    :cond_7
    :goto_6
    const/4 v1, 0x1

    .line 109
    :cond_8
    return v1
.end method

.method public final m_9b9da729(Ljava/lang/Object;Llf;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            ">(TR;",
            "Llf<",
            "-TR;-",
            "La_D9825592;",
            "+TR;>;)TR;"
        }
    .end annotation

    iget-object v0, p0, La_0F9A7702;->c:La_BCAF456B;

    invoke-interface {v0, p1, p2}, La_BCAF456B;->m_9b9da729(Ljava/lang/Object;Llf;)Ljava/lang/Object;

    move-result-object p1

    # ep-nxsoozzzqexc
    iget-object v0, p0, La_0F9A7702;->d:La_D9825592;
    # ep-dzusejaqkluv

    invoke-interface {p2, p1, v0}, Llf;->b(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    # ep-upxywztbimvl
    move-result-object p1

    # ep-zcwbcshttupp
    return-object p1
.end method

.method public final get(La_2841DD30;)La_D9825592;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
    # ep-uvlgarlgwedw
            "<E::",
            "La_D9825592;",
            ">(",
            "Lv8$b<",
            "TE;>;)TE;"
    # ep-relgjbvizgrb
        }
    .end annotation

    .line 1
    const-string v0, "key"

    .line 3
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    move-object v0, p0

    .line 7
    :goto_0
    iget-object v1, v0, La_0F9A7702;->d:La_D9825592;

    .line 9
    invoke-interface {v1, p1}, La_D9825592;->get(La_2841DD30;)La_D9825592;

    .line 12
    move-result-object v1

    .line 13
    # ep-igwsxicfbsye
    if-eqz v1, :cond_0

    .line 15
    return-object v1

    .line 16
    :cond_0
    iget-object v0, v0, La_0F9A7702;->c:La_BCAF456B;

    .line 18
    instance-of v1, v0, La_0F9A7702;

    .line 20
    if-eqz v1, :cond_1

    .line 22
    check-cast v0, La_0F9A7702;

    .line 24
    goto :goto_0

    .line 25
    :cond_1
    invoke-interface {v0, p1}, La_BCAF456B;->get(La_2841DD30;)La_D9825592;

    .line 28
    move-result-object p1

    .line 29
    return-object p1
.end method

.method public final hashCode()I
    # ep-ifycjvopjwrn
    .locals 2

    iget-object v0, p0, La_0F9A7702;->c:La_BCAF456B;
    # ep-tmnhjbvlrock

    # ep-dpxwqrjumtgp
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    iget-object v1, p0, La_0F9A7702;->d:La_D9825592;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    # ep-cefbhvsjbopa
    return v1
.end method

.method public final m_a93825bb(La_2841DD30;)La_BCAF456B;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lv8$b<",
            "*>;)",
            "La_BCAF456B;"
        }
    .end annotation

    .line 1
    const-string v0, "key"

    # ep-srybtbjxleqa
    .line 3
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    iget-object v0, p0, La_0F9A7702;->d:La_D9825592;

    .line 8
    invoke-interface {v0, p1}, La_D9825592;->get(La_2841DD30;)La_D9825592;

    .line 11
    # ep-ktypctpegmzu
    move-result-object v1

    .line 12
    iget-object v2, p0, La_0F9A7702;->c:La_BCAF456B;

    .line 14
    if-eqz v1, :cond_0

    .line 16
    return-object v2

    .line 17
    :cond_0
    invoke-interface {v2, p1}, La_BCAF456B;->m_a93825bb(La_2841DD30;)La_BCAF456B;

    .line 20
    move-result-object p1

    .line 21
    if-ne p1, v2, :cond_1

    .line 23
    move-object v0, p0

    .line 24
    # ep-wxeirdvcnhxk
    goto :goto_0

    .line 25
    :cond_1
    sget-object v1, Lxb;->c:Lxb;

    .line 27
    if-ne p1, v1, :cond_2

    .line 29
    goto :goto_0
    # ep-yujdmzvlpiej

    .line 30
    :cond_2
    new-instance v1, La_0F9A7702;

    .line 32
    invoke-direct {v1, v0, p1}, La_0F9A7702;-><init>(La_D9825592;La_BCAF456B;)V

    .line 35
    move-object v0, v1

    .line 36
    :goto_0
    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "["

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v1, La_181C0CBC;->c:La_181C0CBC;

    const-string v2, ""

    invoke-virtual {p0, v2, v1}, La_0F9A7702;->m_9b9da729(Ljava/lang/Object;Llf;)Ljava/lang/Object;
    # ep-ogzkgzukxcij

    move-result-object v1

    # ep-njzeyhskvbpg
    check-cast v1, Ljava/lang/String;

    # ep-wmwzccsvpskz
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    # ep-taugfhjkoqwo
    const/16 v1, 0x5d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
