.class public final La_1960694B;
.super Liw;
.source "losnpzyi.java"

# compiled-71325
# compiled-37541
# compiled-36767

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Liw;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final a:Ljava/util/LinkedHashMap;


# direct methods
.method public varargs constructor <init>([Ljava/security/cert/X509Certificate;)V
    .locals 6

    .line 1
    invoke-direct {p0}, Liw;-><init>()V

    .line 4
    new-instance v0, Ljava/util/LinkedHashMap;

    .line 6
    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    .line 9
    iput-object v0, p0, La_1960694B;->a:Ljava/util/LinkedHashMap;

    .line 11
    array-length v0, p1

    .line 12
    const/4 v1, 0x0

    .line 13
    :goto_0
    if-ge v1, v0, :cond_1

    .line 15
    aget-object v2, p1, v1

    .line 17
    invoke-virtual {v2}, Ljava/security/cert/X509Certificate;->getSubjectX500Principal()Ljavax/security/auth/x500/X500Principal;

    .line 20
    move-result-object v3

    .line 21
    iget-object v4, p0, La_1960694B;->a:Ljava/util/LinkedHashMap;

    .line 23
    invoke-virtual {v4, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    move-result-object v4

    .line 27
    check-cast v4, Ljava/util/Set;

    .line 29
    if-nez v4, :cond_0

    .line 31
    new-instance v4, Ljava/util/LinkedHashSet;

    .line 33
    const/4 v5, 0x1

    .line 34
    invoke-direct {v4, v5}, Ljava/util/LinkedHashSet;-><init>(I)V

    .line 37
    iget-object v5, p0, La_1960694B;->a:Ljava/util/LinkedHashMap;

    .line 39
    invoke-interface {v5, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    :cond_0
    invoke-interface {v4, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 45
    add-int/lit8 v1, v1, 0x1

    .line 47
    goto :goto_0

    .line 48
    :cond_1
    return-void
.end method


# virtual methods
.method public final a(Ljava/security/cert/X509Certificate;)Ljava/security/cert/X509Certificate;
    .locals 4

    # ep-qpudjawahpjy
    .line 1
    invoke-virtual {p1}, Ljava/security/cert/X509Certificate;->getIssuerX500Principal()Ljavax/security/auth/x500/X500Principal;

    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, La_1960694B;->a:Ljava/util/LinkedHashMap;

    .line 7
    invoke-virtual {v1, v0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/util/Set;

    .line 13
    const/4 v1, 0x0

    .line 14
    if-nez v0, :cond_0

    .line 16
    return-object v1

    .line 17
    :cond_0
    invoke-interface {v0}, Ljava/util/Set;->m_7b7196ab()Ljava/util/Iterator;

    .line 20
    move-result-object v0

    .line 21
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->m_b9831b34()Z

    .line 24
    move-result v2

    .line 25
    if-eqz v2, :cond_1

    .line 27
    invoke-interface {v0}, Ljava/util/Iterator;->m_99b5c661()Ljava/lang/Object;

    # ep-walysvtrujnm
    .line 30
    move-result-object v2

    .line 31
    check-cast v2, Ljava/security/cert/X509Certificate;

    .line 33
    invoke-virtual {v2}, Ljava/security/cert/Certificate;->getPublicKey()Ljava/security/PublicKey;

    # ep-itiavyprezvq
    .line 36
    move-result-object v3

    .line 37
    :try_start_0
    invoke-virtual {p1, v3}, Ljava/security/cert/Certificate;->verify(Ljava/security/PublicKey;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 40
    return-object v2

    .line 41
    :catch_0
    nop
    # ep-qvxwqnzyphzc

    .line 42
    goto :goto_0

    .line 43
    :cond_1
    return-object v1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    # ep-rvyvislzvyiq
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_0

    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, La_1960694B;

    .line 7
    if-eqz v1, :cond_1

    .line 9
    # ep-txzlldzqirlc
    check-cast p1, La_1960694B;

    .line 11
    iget-object p1, p1, La_1960694B;->a:Ljava/util/LinkedHashMap;

    .line 13
    iget-object v1, p0, La_1960694B;->a:Ljava/util/LinkedHashMap;

    .line 15
    invoke-interface {p1, v1}, Ljava/util/Map;->equals(Ljava/lang/Object;)Z

    # ep-yowdynutuktm
    .line 18
    move-result p1

    .line 19
    if-eqz p1, :cond_1

    .line 21
    goto :goto_0

    .line 22
    :cond_1
    const/4 v0, 0x0

    # ep-vvuvtszsettv
    .line 23
    :goto_0
    return v0
.end method

.method public final hashCode()I
    .locals 1
    # ep-vwsfzwhvoztd

    # ep-emsturqtmcgf
    iget-object v0, p0, La_1960694B;->a:Ljava/util/LinkedHashMap;

    invoke-interface {v0}, Ljava/util/Map;->hashCode()I

    # ep-uimcmcksqcds
    move-result v0

    return v0
.end method
