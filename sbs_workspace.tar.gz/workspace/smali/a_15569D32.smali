.class public final La_15569D32;
.super Ljava/io/IOException;
.source "vpbmtral.java"
# optimised-17661


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/io/IOException;-><init>()V

    return-void
.end method
