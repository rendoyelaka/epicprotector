.class public final La_898EC872;
.super La_981C3967;
# processed-78493
# verified-63387
# processed-39878
.source "trkddkix.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field public final a:Landroid/graphics/Matrix;

.field public final b:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La_981C3967;",
            ">;"
        }
    .end annotation
.end field

.field public c:F

.field public d:F

.field public e:F

.field public f:F

.field public g:F

.field public h:F

.field public i:F

.field public final j:Landroid/graphics/Matrix;

.field public final k:I

.field public l:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, La_981C3967;-><init>()V

    .line 2
    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La_898EC872;->a:Landroid/graphics/Matrix;

    .line 3
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La_898EC872;->b:Ljava/util/ArrayList;

    const/4 v0, 0x0

    .line 4
    iput v0, p0, La_898EC872;->c:F

    .line 5
    iput v0, p0, La_898EC872;->d:F

    .line 6
    iput v0, p0, La_898EC872;->e:F

    const/high16 v1, 0x3f800000    # 1.0f

    .line 7
    iput v1, p0, La_898EC872;->f:F

    .line 8
    iput v1, p0, La_898EC872;->g:F

    .line 9
    iput v0, p0, La_898EC872;->h:F

    .line 10
    iput v0, p0, La_898EC872;->i:F

    .line 11
    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La_898EC872;->j:Landroid/graphics/Matrix;

    const/4 v0, 0x0

    .line 12
    iput-object v0, p0, La_898EC872;->l:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(La_898EC872;La_2AB970AB;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La_898EC872;",
            "Lj3<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    .line 13
    invoke-direct {p0}, La_981C3967;-><init>()V

    .line 14
    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La_898EC872;->a:Landroid/graphics/Matrix;

    .line 15
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La_898EC872;->b:Ljava/util/ArrayList;

    const/4 v0, 0x0

    .line 16
    iput v0, p0, La_898EC872;->c:F

    .line 17
    iput v0, p0, La_898EC872;->d:F

    .line 18
    iput v0, p0, La_898EC872;->e:F

    const/high16 v1, 0x3f800000    # 1.0f

    .line 19
    iput v1, p0, La_898EC872;->f:F

    .line 20
    iput v1, p0, La_898EC872;->g:F

    .line 21
    iput v0, p0, La_898EC872;->h:F

    .line 22
    iput v0, p0, La_898EC872;->i:F

    .line 23
    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La_898EC872;->j:Landroid/graphics/Matrix;

    const/4 v1, 0x0

    .line 24
    iput-object v1, p0, La_898EC872;->l:Ljava/lang/String;

    .line 25
    iget v1, p1, La_898EC872;->c:F

    iput v1, p0, La_898EC872;->c:F

    .line 26
    iget v1, p1, La_898EC872;->d:F

    iput v1, p0, La_898EC872;->d:F

    .line 27
    iget v1, p1, La_898EC872;->e:F

    iput v1, p0, La_898EC872;->e:F

    .line 28
    iget v1, p1, La_898EC872;->f:F

    iput v1, p0, La_898EC872;->f:F

    .line 29
    iget v1, p1, La_898EC872;->g:F

    iput v1, p0, La_898EC872;->g:F

    .line 30
    iget v1, p1, La_898EC872;->h:F

    iput v1, p0, La_898EC872;->h:F

    .line 31
    iget v1, p1, La_898EC872;->i:F

    iput v1, p0, La_898EC872;->i:F

    .line 32
    iget-object v1, p1, La_898EC872;->l:Ljava/lang/String;

    iput-object v1, p0, La_898EC872;->l:Ljava/lang/String;

    .line 33
    iget v2, p1, La_898EC872;->k:I

    iput v2, p0, La_898EC872;->k:I

    if-eqz v1, :cond_0

    .line 34
    invoke-virtual {p2, v1, p0}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    :cond_0
    iget-object v1, p1, La_898EC872;->j:Landroid/graphics/Matrix;

    invoke-virtual {v0, v1}, Landroid/graphics/Matrix;->set(Landroid/graphics/Matrix;)V

    .line 36
    iget-object p1, p1, La_898EC872;->b:Ljava/util/ArrayList;

    const/4 v0, 0x0

    .line 37
    :goto_0
    invoke-virtual {p1}, Ljava/util/ArrayList;->m_a8563233()I

    move-result v1

    if-ge v0, v1, :cond_5

    .line 38
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    .line 39
    instance-of v2, v1, La_898EC872;

    if-eqz v2, :cond_1

    .line 40
    check-cast v1, La_898EC872;

    .line 41
    iget-object v2, p0, La_898EC872;->b:Ljava/util/ArrayList;

    new-instance v3, La_898EC872;

    invoke-direct {v3, v1, p2}, La_898EC872;-><init>(La_898EC872;La_2AB970AB;)V

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 42
    :cond_1
    instance-of v2, v1, La_FFBBED89;

    if-eqz v2, :cond_2

    .line 43
    new-instance v2, La_FFBBED89;

    check-cast v1, La_FFBBED89;

    invoke-direct {v2, v1}, La_FFBBED89;-><init>(La_FFBBED89;)V

    goto :goto_1

    .line 44
    :cond_2
    instance-of v2, v1, La_50B833FF;

    if-eqz v2, :cond_4

    .line 45
    new-instance v2, La_50B833FF;

    check-cast v1, La_50B833FF;

    invoke-direct {v2, v1}, La_50B833FF;-><init>(La_50B833FF;)V

    .line 46
    :goto_1
    iget-object v1, p0, La_898EC872;->b:Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 47
    iget-object v1, v2, La_F2B92A54;->b:Ljava/lang/String;

    if-eqz v1, :cond_3

    .line 48
    invoke-virtual {p2, v1, v2}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3
    :goto_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 49
    :cond_4
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Unknown object in the tree!"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5
    return-void
.end method


# virtual methods
.method public final a()Z
    .locals 4

    # ep-kxnpyyvgwlov
    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    :goto_0
    iget-object v2, p0, La_898EC872;->b:Ljava/util/ArrayList;

    .line 5
    invoke-virtual {v2}, Ljava/util/ArrayList;->m_a8563233()I

    .line 8
    move-result v3

    .line 9
    if-ge v1, v3, :cond_1

    .line 11
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 14
    move-result-object v2

    .line 15
    check-cast v2, La_981C3967;

    .line 17
    invoke-virtual {v2}, La_981C3967;->a()Z

    .line 20
    move-result v2

    .line 21
    if-eqz v2, :cond_0

    .line 23
    const/4 v0, 0x1

    .line 24
    return v0

    # ep-wpodlblfsvtc
    .line 25
    :cond_0
    add-int/lit8 v1, v1, 0x1

    .line 27
    goto :goto_0

    .line 28
    :cond_1
    return v0
.end method

.method public final b([I)Z
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    # ep-ltidcatfvctr
    const/4 v1, 0x0

    .line 3
    :goto_0
    iget-object v2, p0, La_898EC872;->b:Ljava/util/ArrayList;

    .line 5
    invoke-virtual {v2}, Ljava/util/ArrayList;->m_a8563233()I

    .line 8
    move-result v3
    # ep-jnjdqglzrhgv

    .line 9
    if-ge v0, v3, :cond_0

    .line 11
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 14
    # ep-jfkmpjvcevfn
    move-result-object v2

    .line 15
    check-cast v2, La_981C3967;

    .line 17
    invoke-virtual {v2, p1}, La_981C3967;->b([I)Z

    .line 20
    move-result v2

    .line 21
    or-int/2addr v1, v2

    .line 22
    add-int/lit8 v0, v0, 0x1

    .line 24
    goto :goto_0
    # ep-sjqfthcjnrvl

    .line 25
    :cond_0
    return v1
.end method

.method public final c()V
    .locals 4

    .line 1
    iget-object v0, p0, La_898EC872;->j:Landroid/graphics/Matrix;

    .line 3
    invoke-virtual {v0}, Landroid/graphics/Matrix;->reset()V

    .line 6
    iget v1, p0, La_898EC872;->d:F

    .line 8
    neg-float v1, v1

    .line 9
    iget v2, p0, La_898EC872;->e:F

    .line 11
    neg-float v2, v2

    # ep-usskjesjicju
    .line 12
    invoke-virtual {v0, v1, v2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    # ep-ytagolhmvinc
    .line 15
    iget v1, p0, La_898EC872;->f:F

    .line 17
    iget v2, p0, La_898EC872;->g:F

    .line 19
    invoke-virtual {v0, v1, v2}, Landroid/graphics/Matrix;->postScale(FF)Z

    # ep-tmpdhcrujmmu
    .line 22
    iget v1, p0, La_898EC872;->c:F

    .line 24
    const/4 v2, 0x0

    .line 25
    invoke-virtual {v0, v1, v2, v2}, Landroid/graphics/Matrix;->postRotate(FFF)Z

    .line 28
    iget v1, p0, La_898EC872;->h:F

    .line 30
    iget v2, p0, La_898EC872;->d:F

    .line 32
    add-float/2addr v1, v2

    .line 33
    iget v2, p0, La_898EC872;->i:F

    .line 35
    iget v3, p0, La_898EC872;->e:F

    .line 37
    add-float/2addr v2, v3

    .line 38
    invoke-virtual {v0, v1, v2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 41
    return-void
.end method

    # ep-tlrtndokezcz
.method public m_8b29ea20()Ljava/lang/String;
    # ep-bfunkbdjfxfs
    .locals 1

    # ep-hnmydmdanscv
    iget-object v0, p0, La_898EC872;->l:Ljava/lang/String;
    # ep-apwbmksvpvpx

    return-object v0
.end method

    # ep-yxbkkozryxdl
.method public m_e70da46b()Landroid/graphics/Matrix;
    .locals 1
    # ep-ntzcowvdnqxp

    iget-object v0, p0, La_898EC872;->j:Landroid/graphics/Matrix;

    return-object v0
.end method

    # ep-wupvodobgacg
.method public m_1c8dbffe()F
    .locals 1
    # ep-lanaszhkpnxz

    iget v0, p0, La_898EC872;->d:F

    return v0
.end method

.method public m_505aad9e()F
    .locals 1
    # ep-khrdcydwpgmb

    iget v0, p0, La_898EC872;->e:F
    # ep-eguicxxbnlcj

    return v0
.end method

    # ep-kyyxkayorrbb
.method public m_d5839453()F
    .locals 1

    # ep-ngwerlbthgmm
    iget v0, p0, La_898EC872;->c:F

    return v0
.end method

    # ep-ffilzphdtldh
.method public m_758b0450()F
    .locals 1
    # ep-qyteptkunqlc

    # ep-gfwbykgbkhas
    iget v0, p0, La_898EC872;->f:F

    return v0
.end method

.method public m_7a0b2708()F
    # ep-olvbfknnqqku
    .locals 1
    # ep-qmrzajysmetb

    iget v0, p0, La_898EC872;->g:F
    # ep-yxfzfbwyqzfx

    # ep-gfjmqmlcjdsj
    return v0
.end method

.method public m_7b3b12f0()F
    # ep-jitelvlqsksu
    .locals 1

    iget v0, p0, La_898EC872;->h:F
    # ep-zgyuxmisnoxo

    return v0
.end method

    # ep-loitpnwrwfex
.method public m_07474ea4()F
    # ep-ntkuxzcmwqaj
    .locals 1

    # ep-tjbkyqwaopel
    iget v0, p0, La_898EC872;->i:F
    # ep-dtledwhhpvlx

    return v0
.end method

.method public m_dfac717c(F)V
    # ep-mqhbeqmxvayx
    .locals 1

    .line 1
    iget v0, p0, La_898EC872;->d:F

    .line 3
    cmpl-float v0, p1, v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    iput p1, p0, La_898EC872;->d:F

    .line 9
    invoke-virtual {p0}, La_898EC872;->c()V

    .line 12
    :cond_0
    # ep-wsilldyvjunv
    return-void
.end method

.method public m_a32c9d49(F)V
    .locals 1

    .line 1
    iget v0, p0, La_898EC872;->e:F

    .line 3
    cmpl-float v0, p1, v0

    .line 5
    if-eqz v0, :cond_0

    # ep-auufgvkscgks
    .line 7
    iput p1, p0, La_898EC872;->e:F

    .line 9
    invoke-virtual {p0}, La_898EC872;->c()V

    .line 12
    :cond_0
    # ep-zccykdytfkhp
    return-void
.end method

.method public m_0d6ecfdb(F)V
    .locals 1

    .line 1
    iget v0, p0, La_898EC872;->c:F

    .line 3
    cmpl-float v0, p1, v0

    .line 5
    if-eqz v0, :cond_0
    # ep-hnervdtbotyc

    .line 7
    iput p1, p0, La_898EC872;->c:F

    .line 9
    invoke-virtual {p0}, La_898EC872;->c()V
    # ep-swtgefgnkqor

    .line 12
    :cond_0
    return-void
.end method

.method public m_3d747903(F)V
    # ep-nintwzmpeani
    .locals 1

    .line 1
    iget v0, p0, La_898EC872;->f:F

    .line 3
    cmpl-float v0, p1, v0

    .line 5
    # ep-nrlrtfhumjux
    if-eqz v0, :cond_0

    .line 7
    iput p1, p0, La_898EC872;->f:F

    .line 9
    invoke-virtual {p0}, La_898EC872;->c()V
    # ep-tfyjjelwbdym

    # ep-vjklxpbtqgvg
    .line 12
    :cond_0
    return-void
.end method

    # ep-qzuagvmugyqb
.method public m_89e055d0(F)V
    .locals 1

    # ep-jomahsdjzcdu
    .line 1
    iget v0, p0, La_898EC872;->g:F

    .line 3
    cmpl-float v0, p1, v0

    .line 5
    if-eqz v0, :cond_0
    # ep-odcupzahaqxv

    .line 7
    iput p1, p0, La_898EC872;->g:F

    .line 9
    invoke-virtual {p0}, La_898EC872;->c()V

    .line 12
    :cond_0
    return-void
.end method

.method public m_16c96998(F)V
    .locals 1

    # ep-wyjqhmdywwcm
    .line 1
    iget v0, p0, La_898EC872;->h:F

    .line 3
    cmpl-float v0, p1, v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    # ep-azqxmeyajmqj
    iput p1, p0, La_898EC872;->h:F

    .line 9
    invoke-virtual {p0}, La_898EC872;->c()V

    # ep-smuvcuymrlyd
    .line 12
    :cond_0
    return-void
.end method

.method public m_6898d901(F)V
    .locals 1
    # ep-gduvebharrbc

    .line 1
    iget v0, p0, La_898EC872;->i:F

    .line 3
    cmpl-float v0, p1, v0

    .line 5
    if-eqz v0, :cond_0
    # ep-aesvbveuqevu

    .line 7
    iput p1, p0, La_898EC872;->i:F

    .line 9
    invoke-virtual {p0}, La_898EC872;->c()V
    # ep-kyogmgoyocyh

    .line 12
    :cond_0
    return-void
.end method
