.class public final La_8EFD0080;
.super Ljava/lang/Object;
.source "njbwjqyh.java"

# compiled-11406
# compiled-60728
# validated-49451
# interfaces
.implements Lra;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lra;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
