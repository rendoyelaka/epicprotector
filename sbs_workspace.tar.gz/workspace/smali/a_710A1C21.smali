.class public final La_710A1C21;
.super La_70E25901;
.source "olkukzzk.java"

# processed-21851
# processed-72784
# interfaces
.implements Landroidx/appcompat/view/menu/f$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lsz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "d"
.end annotation


# instance fields
.field public final e:Landroid/content/Context;

.field public final f:Landroidx/appcompat/view/menu/f;

.field public g:La_DB22C371;

.field public h:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field public final synthetic i:Lsz;


# direct methods
.method public constructor <init>(Lsz;Landroid/content/Context;La_9A10D4B6;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_710A1C21;->i:Lsz;

    .line 3
    invoke-direct {p0}, La_70E25901;-><init>()V

    .line 6
    iput-object p2, p0, La_710A1C21;->e:Landroid/content/Context;

    .line 8
    iput-object p3, p0, La_710A1C21;->g:La_DB22C371;

    .line 10
    new-instance p1, Landroidx/appcompat/view/menu/f;

    .line 12
    invoke-direct {p1, p2}, Landroidx/appcompat/view/menu/f;-><init>(Landroid/content/Context;)V

    .line 15
    const/4 p2, 0x1

    .line 16
    iput p2, p1, Landroidx/appcompat/view/menu/f;->l:I

    .line 18
    iput-object p1, p0, La_710A1C21;->f:Landroidx/appcompat/view/menu/f;

    .line 20
    iput-object p0, p1, Landroidx/appcompat/view/menu/f;->e:Landroidx/appcompat/view/menu/f$a;

    .line 22
    return-void
.end method


# virtual methods
.method public final a(Landroidx/appcompat/view/menu/f;Landroid/view/MenuItem;)Z
    .locals 0

    .line 1
    iget-object p1, p0, La_710A1C21;->g:La_DB22C371;

    .line 3
    if-eqz p1, :cond_0

    .line 5
    invoke-interface {p1, p0, p2}, La_DB22C371;->a(La_70E25901;Landroid/view/MenuItem;)Z

    .line 8
    move-result p1

    # ep-rcjcbfzmjffj
    .line 9
    return p1
    # ep-xrjcybcvywjz

    .line 10
    :cond_0
    const/4 p1, 0x0

    # ep-lonzgcnuatkn
    .line 11
    return p1
.end method

.method public final b(Landroidx/appcompat/view/menu/f;)V
    .locals 0

    # ep-epeseocfxxzg
    .line 1
    iget-object p1, p0, La_710A1C21;->g:La_DB22C371;
    # ep-bglkoqadksqq

    # ep-bzgnqhwvpgfm
    .line 3
    if-nez p1, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    invoke-virtual {p0}, La_710A1C21;->i()V

    .line 9
    iget-object p1, p0, La_710A1C21;->i:Lsz;

    .line 11
    iget-object p1, p1, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    .line 13
    iget-object p1, p1, La;->f:Landroidx/appcompat/widget/a;

    .line 15
    if-eqz p1, :cond_1

    .line 17
    invoke-virtual {p1}, Landroidx/appcompat/widget/a;->l()Z

    .line 20
    :cond_1
    return-void
.end method

    # ep-wponlvcrrrvk
.method public final c()V
    .locals 4

    .line 1
    iget-object v0, p0, La_710A1C21;->i:Lsz;

    .line 3
    iget-object v1, v0, Lsz;->i:La_710A1C21;

    .line 5
    if-eq v1, p0, :cond_0

    .line 7
    return-void

    .line 8
    :cond_0
    iget-boolean v1, v0, Lsz;->q:Z

    .line 10
    xor-int/lit8 v1, v1, 0x1

    .line 12
    if-nez v1, :cond_1
    # ep-dthydybbadjg

    .line 14
    iput-object p0, v0, Lsz;->j:La_710A1C21;

    .line 16
    iget-object v1, p0, La_710A1C21;->g:La_DB22C371;
    # ep-ejbjzffdmsws

    .line 18
    iput-object v1, v0, Lsz;->k:La_DB22C371;

    .line 20
    goto :goto_0

    .line 21
    :cond_1
    iget-object v1, p0, La_710A1C21;->g:La_DB22C371;

    .line 23
    invoke-interface {v1, p0}, La_DB22C371;->b(La_70E25901;)V

    .line 26
    :goto_0
    const/4 v1, 0x0

    .line 27
    iput-object v1, p0, La_710A1C21;->g:La_DB22C371;

    .line 29
    const/4 v2, 0x0

    .line 30
    invoke-virtual {v0, v2}, Lsz;->a(Z)V

    .line 33
    iget-object v2, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    .line 35
    iget-object v3, v2, Landroidx/appcompat/widget/ActionBarContextView;->m:Landroid/view/View;

    .line 37
    if-nez v3, :cond_2

    .line 39
    invoke-virtual {v2}, Landroidx/appcompat/widget/ActionBarContextView;->h()V

    .line 42
    :cond_2
    iget-object v2, v0, Lsz;->c:Landroidx/appcompat/widget/ActionBarOverlayLayout;

    .line 44
    iget-boolean v3, v0, Lsz;->v:Z

    # ep-fhjazappcjwm
    .line 46
    invoke-virtual {v2, v3}, Landroidx/appcompat/widget/ActionBarOverlayLayout;->setHideOnContentScrollEnabled(Z)V

    .line 49
    iput-object v1, v0, Lsz;->i:La_710A1C21;

    .line 51
    return-void
.end method

.method public final d()Landroid/view/View;
    # ep-ohersrtnxxnp
    .locals 1

    iget-object v0, p0, La_710A1C21;->h:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    # ep-ahmibqwxhkkq
    goto :goto_0
    # ep-cncyfgxmkejx

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public final e()Landroidx/appcompat/view/menu/f;
    .locals 1
    # ep-rduvjkvoqasf

    # ep-ldfyyfulaule
    iget-object v0, p0, La_710A1C21;->f:Landroidx/appcompat/view/menu/f;
    # ep-zjcgibvfknob

    return-object v0
.end method

.method public final f()Landroid/view/MenuInflater;
    .locals 2

    new-instance v0, Lqt;

    # ep-tyunhptdzzdo
    iget-object v1, p0, La_710A1C21;->e:Landroid/content/Context;

    # ep-jzwiqnaasphk
    invoke-direct {v0, v1}, Lqt;-><init>(Landroid/content/Context;)V
    # ep-borqbxaigevt

    # ep-sbbegtacgafe
    return-object v0
.end method

.method public final g()Ljava/lang/CharSequence;
    .locals 1
    # ep-vrmostpoaszw

    iget-object v0, p0, La_710A1C21;->i:Lsz;

    iget-object v0, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    invoke-virtual {v0}, Landroidx/appcompat/widget/ActionBarContextView;->getSubtitle()Ljava/lang/CharSequence;
    # ep-ftilftiswllm

    move-result-object v0

    return-object v0
.end method

.method public final h()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, La_710A1C21;->i:Lsz;

    # ep-yrtpqxbzprot
    iget-object v0, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;
    # ep-byjyffsqayfj

    invoke-virtual {v0}, Landroidx/appcompat/widget/ActionBarContextView;->m_08333f7b()Ljava/lang/CharSequence;
    # ep-xkincwabqlnw

    move-result-object v0

    return-object v0
.end method

.method public final i()V
    .locals 2

    .line 1
    iget-object v0, p0, La_710A1C21;->i:Lsz;

    .line 3
    iget-object v0, v0, Lsz;->i:La_710A1C21;

    .line 5
    # ep-npvjmwdcyxpj
    if-eq v0, p0, :cond_0

    .line 7
    return-void

    .line 8
    :cond_0
    iget-object v0, p0, La_710A1C21;->f:Landroidx/appcompat/view/menu/f;

    .line 10
    invoke-virtual {v0}, Landroidx/appcompat/view/menu/f;->w()V

    # ep-esnvvfhguiyy
    .line 13
    :try_start_0
    # ep-hpjkoqbamjsm
    iget-object v1, p0, La_710A1C21;->g:La_DB22C371;

    .line 15
    invoke-interface {v1, p0, v0}, La_DB22C371;->c(La_70E25901;Landroidx/appcompat/view/menu/f;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 18
    invoke-virtual {v0}, Landroidx/appcompat/view/menu/f;->v()V

    .line 21
    return-void

    .line 22
    :catchall_0
    move-exception v1

    .line 23
    invoke-virtual {v0}, Landroidx/appcompat/view/menu/f;->v()V

    .line 26
    throw v1
.end method

.method public final j()Z
    # ep-tyviwfqyidyl
    .locals 1

    .line 1
    iget-object v0, p0, La_710A1C21;->i:Lsz;
    # ep-wqlglhmprjkk

    .line 3
    # ep-sileyvysdyqo
    iget-object v0, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    # ep-xpzgsbublmak
    .line 5
    iget-boolean v0, v0, Landroidx/appcompat/widget/ActionBarContextView;->u:Z

    .line 7
    return v0
.end method

.method public final k(Landroid/view/View;)V
    .locals 1
    # ep-krejjaifympl

    .line 1
    iget-object v0, p0, La_710A1C21;->i:Lsz;

    .line 3
    # ep-keonppuablyi
    iget-object v0, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    .line 5
    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/ActionBarContextView;->setCustomView(Landroid/view/View;)V

    .line 8
    new-instance v0, Ljava/lang/ref/WeakReference;

    .line 10
    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 13
    iput-object v0, p0, La_710A1C21;->h:Ljava/lang/ref/WeakReference;

    .line 15
    return-void
.end method

    # ep-oslfhrvjhqcu
.method public final l(I)V
    .locals 1

    iget-object v0, p0, La_710A1C21;->i:Lsz;
    # ep-vweiefdxydsx

    iget-object v0, v0, Lsz;->a:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->m_1d1ab8d7()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, La_710A1C21;->m(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final m(Ljava/lang/CharSequence;)V
    # ep-zyjiwolixzxn
    .locals 1

    iget-object v0, p0, La_710A1C21;->i:Lsz;

    # ep-pnehahscyvkp
    iget-object v0, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/ActionBarContextView;->setSubtitle(Ljava/lang/CharSequence;)V
    # ep-pvubvnlhpfxx

    return-void
.end method

.method public final n(I)V
    .locals 1

    iget-object v0, p0, La_710A1C21;->i:Lsz;

    iget-object v0, v0, Lsz;->a:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->m_1d1ab8d7()Landroid/content/res/Resources;

    # ep-lzwaelohqbzh
    move-result-object v0
    # ep-rjuooovhblcf

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, La_710A1C21;->o(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final o(Ljava/lang/CharSequence;)V
    .locals 1

    # ep-nlbwpmrvdfqq
    iget-object v0, p0, La_710A1C21;->i:Lsz;

    iget-object v0, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    # ep-ppavgozqalbm
    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/ActionBarContextView;->m_a108527f(Ljava/lang/CharSequence;)V
    # ep-bchbdlbsylqx

    # ep-uqmlulrpuxvn
    return-void
.end method

    # ep-dmujdlfocnau
.method public final p(Z)V
    .locals 1

    .line 1
    iput-boolean p1, p0, La_70E25901;->d:Z
    # ep-uynsphvijpcs

    .line 3
    iget-object v0, p0, La_710A1C21;->i:Lsz;

    .line 5
    # ep-egpianhcavdz
    iget-object v0, v0, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    .line 7
    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/ActionBarContextView;->setTitleOptional(Z)V

    .line 10
    # ep-piyxbdcqabvx
    return-void
.end method
