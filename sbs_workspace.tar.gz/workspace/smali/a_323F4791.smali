.class public interface abstract La_323F4791;
# ep-rbgnzwutnzhs
.super Ljava/lang/Object;
.source "bcijvwdb.java"
# verified-88094
# optimised-13760


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_90072CF5;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract f()V
.end method
