.class public final La_7F694063;
.super Ljava/lang/RuntimeException;
# compiled-72511
# verified-68942
# optimised-79729
.source "rjjbvmpo.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_E7844521;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Exception;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
