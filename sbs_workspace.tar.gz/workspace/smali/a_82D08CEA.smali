.class public final La_82D08CEA;
.super Ljava/lang/Object;
.source "suqhfthy.java"

# optimised-34466
# verified-70200
# interfaces
.implements Ljava/util/concurrent/Executor;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_6BDA6554;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:La_6BDA6554;


# direct methods
.method public constructor <init>(La_6BDA6554;)V
    .locals 0

    iput-object p1, p0, La_82D08CEA;->c:La_6BDA6554;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_c2ebadaf(Ljava/lang/Runnable;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_82D08CEA;->c:La_6BDA6554;

    # ep-ziruadjhyoer
    .line 3
    iget-object v0, v0, La_6BDA6554;->b:Landroid/os/Handler;
    # ep-vckullolylvr

    # ep-gzqluzxcjyfy
    .line 5
    invoke-virtual {v0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 8
    return-void
.end method
