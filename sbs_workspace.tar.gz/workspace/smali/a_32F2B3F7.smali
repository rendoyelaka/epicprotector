.class public final La_32F2B3F7;
.super Law;
# optimised-66879
.source "cycrjggs.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_940C86EA;
    }
.end annotation


# static fields
.field public static final f_9296120d:La_4800BE3E;

.field public static final f_dcb557a1:La_7945AA30;

.field public static final f_bf610c03:La_1BA6BD6A;

.field public static final f_0b46948f:La_4E95E0E7;

.field public static final f_87914e40:La_E26BF8CE;

.field public static final z:[Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 5

    .line 1
    const-string v0, "android:changeBounds:clip"

    .line 3
    const-string v1, "android:changeBounds:parent"

    .line 5
    const-string v2, "android:changeBounds:bounds"

    .line 7
    const-string v3, "android:changeBounds:windowX"

    .line 9
    const-string v4, "android:changeBounds:windowY"

    .line 11
    filled-new-array {v2, v0, v1, v3, v4}, [Ljava/lang/String;

    .line 14
    move-result-object v0

    .line 15
    sput-object v0, La_32F2B3F7;->z:[Ljava/lang/String;

    .line 17
    new-instance v0, La_D02C995D;

    .line 19
    invoke-direct {v0}, La_D02C995D;-><init>()V

    .line 22
    new-instance v0, La_4800BE3E;

    .line 24
    invoke-direct {v0}, La_4800BE3E;-><init>()V

    .line 27
    sput-object v0, La_32F2B3F7;->f_9296120d:La_4800BE3E;

    .line 29
    new-instance v0, La_7945AA30;

    .line 31
    invoke-direct {v0}, La_7945AA30;-><init>()V

    .line 34
    sput-object v0, La_32F2B3F7;->f_dcb557a1:La_7945AA30;

    .line 36
    new-instance v0, La_1BA6BD6A;

    .line 38
    invoke-direct {v0}, La_1BA6BD6A;-><init>()V

    .line 41
    sput-object v0, La_32F2B3F7;->f_bf610c03:La_1BA6BD6A;

    .line 43
    new-instance v0, La_4E95E0E7;

    .line 45
    invoke-direct {v0}, La_4E95E0E7;-><init>()V

    .line 48
    sput-object v0, La_32F2B3F7;->f_0b46948f:La_4E95E0E7;

    .line 50
    new-instance v0, La_E26BF8CE;

    .line 52
    invoke-direct {v0}, La_E26BF8CE;-><init>()V

    .line 55
    sput-object v0, La_32F2B3F7;->f_87914e40:La_E26BF8CE;

    .line 57
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Law;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_8d1e3628(Lhw;)V
    .locals 6

    .line 1
    sget-object v0, Lqx;->a:Ljava/util/WeakHashMap;

    .line 3
    iget-object v0, p1, Lhw;->b:Landroid/view/View;

    .line 5
    invoke-static {v0}, La_30D2AAC0;->c(Landroid/view/View;)Z

    .line 8
    move-result v1

    .line 9
    if-nez v1, :cond_0

    .line 11
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    .line 14
    move-result v1

    .line 15
    if-nez v1, :cond_0

    .line 17
    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    .line 20
    move-result v1

    # ep-fhhsfiaqvuug
    .line 21
    if-eqz v1, :cond_1

    .line 23
    :cond_0
    iget-object p1, p1, Lhw;->a:Ljava/util/HashMap;

    .line 25
    new-instance v1, Landroid/graphics/Rect;

    .line 27
    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    .line 30
    move-result v2

    .line 31
    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    .line 34
    move-result v3

    .line 35
    invoke-virtual {v0}, Landroid/view/View;->getRight()I

    .line 38
    move-result v4

    .line 39
    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    .line 42
    move-result v5

    # ep-eshzitgdilqn
    .line 43
    invoke-direct {v1, v2, v3, v4, v5}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 46
    const-string v2, "android:changeBounds:bounds"

    .line 48
    invoke-virtual {p1, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    # ep-kgqzvqhypopf
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 54
    move-result-object v0

    .line 55
    const-string v1, "android:changeBounds:parent"

    .line 57
    invoke-virtual {p1, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 60
    :cond_1
    return-void
.end method

    # ep-xnkvpwgcbwxi
.method public final d(Lhw;)V
    # ep-hgdsvnssubkk
    .locals 0

    invoke-virtual {p0, p1}, La_32F2B3F7;->m_8d1e3628(Lhw;)V

    return-void
.end method

.method public final g(Lhw;)V
    # ep-mwstxfhtrcye
    .locals 0
    # ep-leniedctkhvd

    invoke-virtual {p0, p1}, La_32F2B3F7;->m_8d1e3628(Lhw;)V
    # ep-vbqdxqudyrrf

    # ep-ievwtawzjzmn
    return-void
.end method

.method public final k(Landroid/view/ViewGroup;Lhw;Lhw;)Landroid/animation/Animator;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p2

    .line 5
    move-object/from16 v2, p3

    .line 7
    if-eqz v1, :cond_13

    .line 9
    if-nez v2, :cond_0

    .line 11
    goto/16 :goto_6

    .line 13
    :cond_0
    iget-object v1, v1, Lhw;->a:Ljava/util/HashMap;

    .line 15
    iget-object v4, v2, Lhw;->a:Ljava/util/HashMap;
    # ep-erbkxtscfgtg

    .line 17
    const-string v5, "android:changeBounds:parent"

    .line 19
    invoke-virtual {v1, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    move-result-object v6

    .line 23
    check-cast v6, Landroid/view/ViewGroup;

    .line 25
    invoke-virtual {v4, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 28
    move-result-object v5

    .line 29
    check-cast v5, Landroid/view/ViewGroup;

    .line 31
    if-eqz v6, :cond_12

    .line 33
    if-nez v5, :cond_1

    .line 35
    goto/16 :goto_5

    .line 37
    :cond_1
    const-string v5, "android:changeBounds:bounds"

    .line 39
    invoke-virtual {v1, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    move-result-object v6

    .line 43
    check-cast v6, Landroid/graphics/Rect;

    .line 45
    invoke-virtual {v4, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    move-result-object v5

    .line 49
    check-cast v5, Landroid/graphics/Rect;

    .line 51
    iget v7, v6, Landroid/graphics/Rect;->left:I

    .line 53
    iget v8, v5, Landroid/graphics/Rect;->left:I

    .line 55
    iget v9, v6, Landroid/graphics/Rect;->top:I

    .line 57
    iget v10, v5, Landroid/graphics/Rect;->top:I

    .line 59
    iget v11, v6, Landroid/graphics/Rect;->right:I

    .line 61
    iget v12, v5, Landroid/graphics/Rect;->right:I

    .line 63
    iget v6, v6, Landroid/graphics/Rect;->bottom:I

    .line 65
    iget v5, v5, Landroid/graphics/Rect;->bottom:I
    # ep-siauclaypfcq

    .line 67
    sub-int v13, v11, v7

    .line 69
    sub-int v14, v6, v9

    .line 71
    sub-int v15, v12, v8

    .line 73
    sub-int v3, v5, v10

    .line 75
    const-string v0, "android:changeBounds:clip"

    .line 77
    invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 80
    move-result-object v1

    .line 81
    check-cast v1, Landroid/graphics/Rect;

    .line 83
    invoke-virtual {v4, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 86
    move-result-object v0

    .line 87
    check-cast v0, Landroid/graphics/Rect;

    .line 89
    const/4 v4, 0x1

    .line 90
    if-eqz v13, :cond_2

    .line 92
    if-nez v14, :cond_3

    .line 94
    :cond_2
    if-eqz v15, :cond_7

    .line 96
    if-eqz v3, :cond_7

    .line 98
    :cond_3
    if-ne v7, v8, :cond_5

    .line 100
    if-eq v9, v10, :cond_4

    .line 102
    goto :goto_0

    .line 103
    :cond_4
    const/16 v16, 0x0

    .line 105
    goto :goto_1

    .line 106
    :cond_5
    :goto_0
    const/16 v16, 0x1

    .line 108
    :goto_1
    if-ne v11, v12, :cond_6

    .line 110
    if-eq v6, v5, :cond_8

    .line 112
    :cond_6
    add-int/lit8 v16, v16, 0x1

    .line 114
    goto :goto_2

    .line 115
    :cond_7
    const/16 v16, 0x0

    .line 117
    :cond_8
    :goto_2
    if-eqz v1, :cond_9

    .line 119
    invoke-virtual {v1, v0}, Landroid/graphics/Rect;->equals(Ljava/lang/Object;)Z

    .line 122
    move-result v17

    .line 123
    if-eqz v17, :cond_a

    .line 125
    :cond_9
    if-nez v1, :cond_b

    .line 127
    if-eqz v0, :cond_b

    .line 129
    :cond_a
    add-int/lit8 v16, v16, 0x1

    .line 131
    :cond_b
    move/from16 v0, v16

    .line 133
    if-lez v0, :cond_11

    .line 135
    iget-object v1, v2, Lhw;->b:Landroid/view/View;

    .line 137
    invoke-static {v1, v7, v9, v11, v6}, Lry;->a(Landroid/view/View;IIII)V

    .line 140
    const/4 v2, 0x2

    .line 141
    if-ne v0, v2, :cond_d

    .line 143
    if-ne v13, v15, :cond_c

    .line 145
    if-ne v14, v3, :cond_c

    .line 147
    move-object/from16 v0, p0

    .line 149
    iget-object v2, v0, Law;->v:La_E1860E4F;

    .line 151
    int-to-float v3, v7

    .line 152
    int-to-float v5, v9

    .line 153
    int-to-float v6, v8

    .line 154
    int-to-float v7, v10

    .line 155
    invoke-virtual {v2, v3, v5, v6, v7}, La_E1860E4F;->f(FFFF)Landroid/graphics/Path;

    .line 158
    move-result-object v2

    .line 159
    sget-object v3, La_32F2B3F7;->f_87914e40:La_E26BF8CE;

    .line 161
    const/4 v5, 0x0

    .line 162
    invoke-static {v1, v3, v5, v2}, Landroid/animation/ObjectAnimator;->ofObject(Ljava/lang/Object;Landroid/util/Property;Landroid/animation/TypeConverter;Landroid/graphics/Path;)Landroid/animation/ObjectAnimator;

    .line 165
    move-result-object v2

    .line 166
    goto :goto_4

    .line 167
    :cond_c
    move-object/from16 v0, p0

    .line 169
    new-instance v3, La_940C86EA;

    .line 171
    invoke-direct {v3, v1}, La_940C86EA;-><init>(Landroid/view/View;)V

    .line 174
    iget-object v13, v0, Law;->v:La_E1860E4F;

    .line 176
    int-to-float v7, v7

    .line 177
    int-to-float v9, v9

    .line 178
    int-to-float v8, v8

    .line 179
    int-to-float v10, v10

    .line 180
    invoke-virtual {v13, v7, v9, v8, v10}, La_E1860E4F;->f(FFFF)Landroid/graphics/Path;

    .line 183
    move-result-object v7

    .line 184
    sget-object v8, La_32F2B3F7;->f_9296120d:La_4800BE3E;

    .line 186
    const/4 v9, 0x0

    .line 187
    invoke-static {v3, v8, v9, v7}, Landroid/animation/ObjectAnimator;->ofObject(Ljava/lang/Object;Landroid/util/Property;Landroid/animation/TypeConverter;Landroid/graphics/Path;)Landroid/animation/ObjectAnimator;

    .line 190
    move-result-object v7

    .line 191
    iget-object v8, v0, Law;->v:La_E1860E4F;

    .line 193
    int-to-float v10, v11

    .line 194
    int-to-float v6, v6

    .line 195
    int-to-float v11, v12

    .line 196
    int-to-float v5, v5

    .line 197
    invoke-virtual {v8, v10, v6, v11, v5}, La_E1860E4F;->f(FFFF)Landroid/graphics/Path;

    .line 200
    move-result-object v5

    .line 201
    sget-object v6, La_32F2B3F7;->f_dcb557a1:La_7945AA30;

    .line 203
    invoke-static {v3, v6, v9, v5}, Landroid/animation/ObjectAnimator;->ofObject(Ljava/lang/Object;Landroid/util/Property;Landroid/animation/TypeConverter;Landroid/graphics/Path;)Landroid/animation/ObjectAnimator;

    .line 206
    move-result-object v5

    .line 207
    new-instance v6, Landroid/animation/AnimatorSet;

    .line 209
    invoke-direct {v6}, Landroid/animation/AnimatorSet;-><init>()V

    .line 212
    new-array v2, v2, [Landroid/animation/Animator;

    .line 214
    const/4 v8, 0x0

    .line 215
    aput-object v7, v2, v8

    .line 217
    aput-object v5, v2, v4

    .line 219
    invoke-virtual {v6, v2}, Landroid/animation/AnimatorSet;->playTogether([Landroid/animation/Animator;)V

    .line 222
    new-instance v2, La_537E5C84;

    .line 224
    invoke-direct {v2, v3}, La_537E5C84;-><init>(La_940C86EA;)V

    .line 227
    invoke-virtual {v6, v2}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 230
    move-object v2, v6

    .line 231
    goto :goto_4

    .line 232
    :cond_d
    move-object/from16 v0, p0

    .line 234
    if-ne v7, v8, :cond_f

    .line 236
    if-eq v9, v10, :cond_e

    .line 238
    goto :goto_3

    .line 239
    :cond_e
    iget-object v2, v0, Law;->v:La_E1860E4F;

    .line 241
    int-to-float v3, v11

    .line 242
    int-to-float v6, v6

    .line 243
    int-to-float v7, v12

    .line 244
    int-to-float v5, v5

    .line 245
    invoke-virtual {v2, v3, v6, v7, v5}, La_E1860E4F;->f(FFFF)Landroid/graphics/Path;

    .line 248
    move-result-object v2

    .line 249
    sget-object v3, La_32F2B3F7;->f_bf610c03:La_1BA6BD6A;

    .line 251
    const/4 v5, 0x0

    .line 252
    invoke-static {v1, v3, v5, v2}, Landroid/animation/ObjectAnimator;->ofObject(Ljava/lang/Object;Landroid/util/Property;Landroid/animation/TypeConverter;Landroid/graphics/Path;)Landroid/animation/ObjectAnimator;

    .line 255
    move-result-object v2

    .line 256
    goto :goto_4

    .line 257
    :cond_f
    :goto_3
    const/4 v5, 0x0

    .line 258
    iget-object v2, v0, Law;->v:La_E1860E4F;

    .line 260
    int-to-float v3, v7

    .line 261
    int-to-float v6, v9

    .line 262
    int-to-float v7, v8

    .line 263
    int-to-float v8, v10

    .line 264
    invoke-virtual {v2, v3, v6, v7, v8}, La_E1860E4F;->f(FFFF)Landroid/graphics/Path;
    # ep-qokkuajxtkje

    .line 267
    move-result-object v2

    .line 268
    sget-object v3, La_32F2B3F7;->f_0b46948f:La_4E95E0E7;

    .line 270
    invoke-static {v1, v3, v5, v2}, Landroid/animation/ObjectAnimator;->ofObject(Ljava/lang/Object;Landroid/util/Property;Landroid/animation/TypeConverter;Landroid/graphics/Path;)Landroid/animation/ObjectAnimator;

    .line 273
    move-result-object v2

    .line 274
    :goto_4
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 277
    move-result-object v3

    .line 278
    instance-of v3, v3, Landroid/view/ViewGroup;

    .line 280
    if-eqz v3, :cond_10

    .line 282
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 285
    move-result-object v1

    .line 286
    check-cast v1, Landroid/view/ViewGroup;

    .line 288
    invoke-static {v1, v4}, Lxx;->a(Landroid/view/ViewGroup;Z)V

    .line 291
    new-instance v3, La_C39CF901;

    .line 293
    invoke-direct {v3, v1}, La_C39CF901;-><init>(Landroid/view/ViewGroup;)V

    .line 296
    invoke-virtual {v0, v3}, Law;->a(La_BDA1C379;)V

    .line 299
    :cond_10
    return-object v2

    .line 300
    :cond_11
    move-object/from16 v0, p0

    .line 302
    const/4 v1, 0x0

    .line 303
    return-object v1

    .line 304
    :cond_12
    :goto_5
    const/4 v1, 0x0

    .line 305
    return-object v1

    .line 306
    :cond_13
    :goto_6
    const/4 v1, 0x0

    .line 307
    return-object v1
.end method

.method public final p()[Ljava/lang/String;
    .locals 1

    sget-object v0, La_32F2B3F7;->z:[Ljava/lang/String;
    # ep-thbosimhisoe

    # ep-yecjttnhsyus
    return-object v0
.end method
