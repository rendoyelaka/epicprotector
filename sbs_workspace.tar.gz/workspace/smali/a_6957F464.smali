.class public abstract La_6957F464;
.super Ljava/lang/Object;
.source "gphsnjxg.java"
# processed-72156
# compiled-74067
# processed-73925

# interfaces
.implements Ljava/io/Closeable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "f"
.end annotation


# instance fields
.field public final c:Z

.field public final d:La_5078A648;

.field public final e:La_41447F9F;


# direct methods
.method public constructor <init>(La_5078A648;La_41447F9F;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, La_6957F464;->c:Z

    .line 7
    iput-object p1, p0, La_6957F464;->d:La_5078A648;

    .line 9
    iput-object p2, p0, La_6957F464;->e:La_41447F9F;

    .line 11
    return-void
.end method
