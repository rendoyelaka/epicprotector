.class public final Lag;
.super Ljava/lang/Object;
.source "mdlvaibo.java"

# validated-73967
# validated-55628
# ep-bcygxqmdiejr
# interfaces
.implements Lrs;


# instance fields
.field public c:I

.field public final d:Lcp;

.field public final e:Ljava/util/zip/Inflater;

.field public final f:Lxh;

.field public final g:Ljava/util/zip/CRC32;


# direct methods
.method public constructor <init>(Lv4;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, Lag;->c:I

    .line 7
    new-instance v0, Ljava/util/zip/CRC32;

    .line 9
    invoke-direct {v0}, Ljava/util/zip/CRC32;-><init>()V

    .line 12
    iput-object v0, p0, Lag;->g:Ljava/util/zip/CRC32;

    .line 14
    if-eqz p1, :cond_0

    .line 16
    new-instance v0, Ljava/util/zip/Inflater;

    .line 18
    const/4 v1, 0x1

    .line 19
    invoke-direct {v0, v1}, Ljava/util/zip/Inflater;-><init>(Z)V

    .line 22
    iput-object v0, p0, Lag;->e:Ljava/util/zip/Inflater;

    .line 24
    sget-object v1, Len;->a:Ljava/util/logging/Logger;

    .line 26
    new-instance v1, Lcp;

    .line 28
    invoke-direct {v1, p1}, Lcp;-><init>(Lrs;)V

    .line 31
    iput-object v1, p0, Lag;->d:Lcp;

    .line 33
    new-instance p1, Lxh;

    .line 35
    invoke-direct {p1, v1, v0}, Lxh;-><init>(Lcp;Ljava/util/zip/Inflater;)V

    .line 38
    iput-object p1, p0, Lag;->f:Lxh;

    .line 40
    return-void

    .line 41
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 43
    const-string v0, "source == null"

    .line 45
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 48
    throw p1
.end method

.method public static h(IILjava/lang/String;)V
    .locals 3

    .line 1
    if-ne p1, p0, :cond_0

    .line 3
    return-void

    .line 4
    :cond_0
    new-instance v0, Ljava/io/IOException;

    .line 6
    const/4 v1, 0x3

    .line 7
    new-array v1, v1, [Ljava/lang/Object;

    .line 9
    const/4 v2, 0x0

    .line 10
    aput-object p2, v1, v2

    .line 12
    const/4 p2, 0x1

    .line 13
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 16
    move-result-object p1

    .line 17
    aput-object p1, v1, p2

    .line 19
    const/4 p1, 0x2

    .line 20
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 23
    move-result-object p0

    .line 24
    aput-object p0, v1, p1

    .line 26
    const-string p0, "%s: actual 0x%08x != expected 0x%08x"

    .line 28
    invoke-static {p0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 31
    move-result-object p0

    .line 32
    invoke-direct {v0, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 35
    throw v0
.end method


# virtual methods
.method public final a()Lhv;
    .locals 1

    iget-object v0, p0, Lag;->d:Lcp;

    invoke-virtual {v0}, Lcp;->a()Lhv;

    move-result-object v0

    return-object v0
.end method

.method public final close()V
    .locals 1

    iget-object v0, p0, Lag;->f:Lxh;

    invoke-virtual {v0}, Lxh;->close()V

    return-void
.end method

.method public final j(Lt4;JJ)V
    .locals 5

    .line 1
    iget-object p1, p1, Lt4;->c:Llr;

    .line 3
    :goto_0
    iget v0, p1, Llr;->c:I

    .line 5
    iget v1, p1, Llr;->b:I

    .line 7
    sub-int v2, v0, v1

    .line 9
    int-to-long v2, v2

    .line 10
    cmp-long v4, p2, v2

    .line 12
    if-ltz v4, :cond_0

    .line 14
    sub-int/2addr v0, v1

    .line 15
    int-to-long v0, v0

    .line 16
    sub-long/2addr p2, v0

    .line 17
    iget-object p1, p1, Llr;->f:Llr;

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    :goto_1
    const-wide/16 v0, 0x0

    .line 22
    cmp-long v2, p4, v0

    .line 24
    if-lez v2, :cond_1

    .line 26
    iget v2, p1, Llr;->b:I

    .line 28
    int-to-long v2, v2

    .line 29
    add-long/2addr v2, p2

    .line 30
    long-to-int p2, v2

    .line 31
    iget p3, p1, Llr;->c:I

    .line 33
    sub-int/2addr p3, p2

    .line 34
    int-to-long v2, p3

    .line 35
    invoke-static {v2, v3, p4, p5}, Ljava/lang/Math;->min(JJ)J

    .line 38
    move-result-wide v2

    .line 39
    long-to-int p3, v2

    .line 40
    iget-object v2, p0, Lag;->g:Ljava/util/zip/CRC32;

    .line 42
    iget-object v3, p1, Llr;->a:[B

    .line 44
    invoke-virtual {v2, v3, p2, p3}, Ljava/util/zip/CRC32;->update([BII)V

    .line 47
    int-to-long p2, p3

    .line 48
    sub-long/2addr p4, p2

    .line 49
    iget-object p1, p1, Llr;->f:Llr;

    .line 51
    move-wide p2, v0

    .line 52
    goto :goto_1

    .line 53
    :cond_1
    return-void
.end method

.method public final k(Lt4;J)J
    .locals 21

    .line 1
    move-object/from16 v6, p0

    .line 3
    move-object/from16 v7, p1

    .line 5
    iget v0, v6, Lag;->c:I

    .line 7
    iget-object v8, v6, Lag;->g:Ljava/util/zip/CRC32;

    .line 9
    const/4 v9, 0x1

    .line 10
    const v10, 0xff00

    .line 13
    iget-object v13, v6, Lag;->d:Lcp;

    .line 15
    if-nez v0, :cond_c

    .line 17
    const-wide/16 v0, 0xa

    .line 19
    invoke-virtual {v13, v0, v1}, Lcp;->l(J)V

    .line 22
    const-wide/16 v0, 0x3

    .line 24
    iget-object v14, v13, Lcp;->c:Lt4;

    .line 26
    invoke-virtual {v14, v0, v1}, Lt4;->r(J)B

    .line 29
    move-result v15

    .line 30
    shr-int/lit8 v0, v15, 0x1

    .line 32
    and-int/2addr v0, v9

    .line 33
    const/4 v4, 0x0

    .line 34
    if-ne v0, v9, :cond_0

    .line 36
    const/16 v16, 0x1

    .line 38
    goto :goto_0

    .line 39
    :cond_0
    const/16 v16, 0x0

    .line 41
    :goto_0
    if-eqz v16, :cond_1

    .line 43
    iget-object v1, v13, Lcp;->c:Lt4;

    .line 45
    const-wide/16 v2, 0x0

    .line 47
    const-wide/16 v17, 0xa

    .line 49
    move-object/from16 v0, p0

    .line 51
    const/4 v11, 0x0

    .line 52
    move-wide/from16 v4, v17

    .line 54
    invoke-virtual/range {v0 .. v5}, Lag;->j(Lt4;JJ)V

    .line 57
    goto :goto_1

    .line 58
    :cond_1
    const/4 v11, 0x0

    .line 59
    :goto_1
    invoke-virtual {v13}, Lcp;->readShort()S

    .line 62
    move-result v0

    .line 63
    const-string v1, "ID1ID2"

    .line 65
    const/16 v2, 0x1f8b

    .line 67
    invoke-static {v2, v0, v1}, Lag;->h(IILjava/lang/String;)V

    .line 70
    const-wide/16 v0, 0x8

    .line 72
    invoke-virtual {v13, v0, v1}, Lcp;->skip(J)V

    .line 75
    shr-int/lit8 v0, v15, 0x2

    .line 77
    and-int/2addr v0, v9

    .line 78
    const v12, 0xffff

    .line 81
    const-wide/16 v4, 0x2

    .line 83
    if-ne v0, v9, :cond_4

    .line 85
    invoke-virtual {v13, v4, v5}, Lcp;->l(J)V

    .line 88
    if-eqz v16, :cond_2

    .line 90
    iget-object v1, v13, Lcp;->c:Lt4;

    .line 92
    const-wide/16 v2, 0x0

    .line 94
    const-wide/16 v17, 0x2

    .line 96
    move-object/from16 v0, p0

    .line 98
    move-wide/from16 v4, v17

    .line 100
    invoke-virtual/range {v0 .. v5}, Lag;->j(Lt4;JJ)V

    .line 103
    :cond_2
    invoke-virtual {v14}, Lt4;->readShort()S

    .line 106
    move-result v0

    .line 107
    sget-object v1, Ldx;->a:Ljava/nio/charset/Charset;

    .line 109
    and-int/2addr v0, v12

    .line 110
    and-int v1, v0, v10

    .line 112
    ushr-int/lit8 v1, v1, 0x8

    .line 114
    and-int/lit16 v0, v0, 0xff

    .line 116
    shl-int/lit8 v0, v0, 0x8

    .line 118
    or-int/2addr v0, v1

    .line 119
    int-to-short v0, v0

    .line 120
    int-to-long v4, v0

    .line 121
    invoke-virtual {v13, v4, v5}, Lcp;->l(J)V

    .line 124
    if-eqz v16, :cond_3

    .line 126
    iget-object v1, v13, Lcp;->c:Lt4;

    .line 128
    const-wide/16 v2, 0x0

    .line 130
    move-object/from16 v0, p0

    .line 132
    move-wide/from16 v17, v4

    .line 134
    invoke-virtual/range {v0 .. v5}, Lag;->j(Lt4;JJ)V

    .line 137
    move-wide/from16 v0, v17

    .line 139
    goto :goto_2

    .line 140
    :cond_3
    move-wide v0, v4

    .line 141
    :goto_2
    invoke-virtual {v13, v0, v1}, Lcp;->skip(J)V

    .line 144
    :cond_4
    shr-int/lit8 v0, v15, 0x3

    .line 146
    and-int/2addr v0, v9

    .line 147
    const-wide/16 v17, 0x1

    .line 149
    if-ne v0, v9, :cond_7

    .line 151
    invoke-virtual {v13, v11}, Lcp;->h(B)J

    .line 154
    move-result-wide v19

    .line 155
    const-wide/16 v0, -0x1

    .line 157
    cmp-long v2, v19, v0

    .line 159
    if-eqz v2, :cond_6

    .line 161
    if-eqz v16, :cond_5

    .line 163
    iget-object v1, v13, Lcp;->c:Lt4;

    .line 165
    const-wide/16 v2, 0x0

    .line 167
    add-long v4, v19, v17

    .line 169
    move-object/from16 v0, p0

    .line 171
    invoke-virtual/range {v0 .. v5}, Lag;->j(Lt4;JJ)V

    .line 174
    :cond_5
    add-long v0, v19, v17

    .line 176
    invoke-virtual {v13, v0, v1}, Lcp;->skip(J)V

    .line 179
    goto :goto_3

    .line 180
    :cond_6
    new-instance v0, Ljava/io/EOFException;

    .line 182
    invoke-direct {v0}, Ljava/io/EOFException;-><init>()V

    .line 185
    throw v0

    .line 186
    :cond_7
    :goto_3
    shr-int/lit8 v0, v15, 0x4

    .line 188
    and-int/2addr v0, v9

    .line 189
    if-ne v0, v9, :cond_a

    .line 191
    invoke-virtual {v13, v11}, Lcp;->h(B)J

    .line 194
    move-result-wide v19

    .line 195
    const-wide/16 v0, -0x1

    .line 197
    cmp-long v2, v19, v0

    .line 199
    if-eqz v2, :cond_9

    .line 201
    if-eqz v16, :cond_8

    .line 203
    iget-object v1, v13, Lcp;->c:Lt4;

    .line 205
    const-wide/16 v2, 0x0

    .line 207
    add-long v4, v19, v17

    .line 209
    move-object/from16 v0, p0

    .line 211
    invoke-virtual/range {v0 .. v5}, Lag;->j(Lt4;JJ)V

    .line 214
    :cond_8
    add-long v0, v19, v17

    .line 216
    invoke-virtual {v13, v0, v1}, Lcp;->skip(J)V

    .line 219
    goto :goto_4

    .line 220
    :cond_9
    new-instance v0, Ljava/io/EOFException;

    .line 222
    invoke-direct {v0}, Ljava/io/EOFException;-><init>()V

    .line 225
    throw v0

    .line 226
    :cond_a
    :goto_4
    if-eqz v16, :cond_b

    .line 228
    const-wide/16 v0, 0x2

    .line 230
    invoke-virtual {v13, v0, v1}, Lcp;->l(J)V

    .line 233
    invoke-virtual {v14}, Lt4;->readShort()S

    .line 236
    move-result v0

    .line 237
    sget-object v1, Ldx;->a:Ljava/nio/charset/Charset;

    .line 239
    and-int/2addr v0, v12

    .line 240
    and-int v1, v0, v10

    .line 242
    ushr-int/lit8 v1, v1, 0x8

    .line 244
    and-int/lit16 v0, v0, 0xff

    .line 246
    shl-int/lit8 v0, v0, 0x8

    .line 248
    or-int/2addr v0, v1

    .line 249
    int-to-short v0, v0

    .line 250
    invoke-virtual {v8}, Ljava/util/zip/CRC32;->getValue()J

    .line 253
    move-result-wide v1

    .line 254
    long-to-int v2, v1

    .line 255
    int-to-short v1, v2

    .line 256
    const-string v2, "FHCRC"

    .line 258
    invoke-static {v0, v1, v2}, Lag;->h(IILjava/lang/String;)V

    .line 261
    invoke-virtual {v8}, Ljava/util/zip/CRC32;->reset()V

    .line 264
    :cond_b
    iput v9, v6, Lag;->c:I

    .line 266
    :cond_c
    iget v0, v6, Lag;->c:I

    .line 268
    const/4 v1, 0x2

    .line 269
    if-ne v0, v9, :cond_e

    .line 271
    iget-wide v2, v7, Lt4;->d:J

    .line 273
    iget-object v0, v6, Lag;->f:Lxh;

    .line 275
    const-wide/16 v4, 0x2000

    .line 277
    invoke-virtual {v0, v7, v4, v5}, Lxh;->k(Lt4;J)J

    .line 280
    move-result-wide v11

    .line 281
    const-wide/16 v4, -0x1

    .line 283
    cmp-long v0, v11, v4

    .line 285
    if-eqz v0, :cond_d

    .line 287
    move-object/from16 v0, p0

    .line 289
    move-object/from16 v1, p1

    .line 291
    move-wide v4, v11

    .line 292
    invoke-virtual/range {v0 .. v5}, Lag;->j(Lt4;JJ)V

    .line 295
    return-wide v11

    .line 296
    :cond_d
    iput v1, v6, Lag;->c:I

    .line 298
    :cond_e
    iget v0, v6, Lag;->c:I

    .line 300
    if-ne v0, v1, :cond_10

    .line 302
    const-wide/16 v0, 0x4

    .line 304
    invoke-virtual {v13, v0, v1}, Lcp;->l(J)V

    .line 307
    iget-object v2, v13, Lcp;->c:Lt4;

    .line 309
    invoke-virtual {v2}, Lt4;->readInt()I

    .line 312
    move-result v2

    .line 313
    sget-object v3, Ldx;->a:Ljava/nio/charset/Charset;

    .line 315
    const/high16 v3, -0x1000000

    .line 317
    and-int v4, v2, v3

    .line 319
    ushr-int/lit8 v4, v4, 0x18

    .line 321
    const/high16 v5, 0xff0000

    .line 323
    and-int v7, v2, v5

    .line 325
    ushr-int/lit8 v7, v7, 0x8

    .line 327
    or-int/2addr v4, v7

    .line 328
    and-int v7, v2, v10

    .line 330
    shl-int/lit8 v7, v7, 0x8

    .line 332
    or-int/2addr v4, v7

    .line 333
    and-int/lit16 v2, v2, 0xff

    .line 335
    shl-int/lit8 v2, v2, 0x18

    .line 337
    or-int/2addr v2, v4

    .line 338
    invoke-virtual {v8}, Ljava/util/zip/CRC32;->getValue()J

    .line 341
    move-result-wide v7

    .line 342
    long-to-int v4, v7

    .line 343
    const-string v7, "CRC"

    .line 345
    invoke-static {v2, v4, v7}, Lag;->h(IILjava/lang/String;)V

    .line 348
    invoke-virtual {v13, v0, v1}, Lcp;->l(J)V

    .line 351
    iget-object v0, v13, Lcp;->c:Lt4;

    .line 353
    invoke-virtual {v0}, Lt4;->readInt()I

    .line 356
    move-result v0

    .line 357
    and-int v1, v0, v3

    .line 359
    ushr-int/lit8 v1, v1, 0x18

    .line 361
    and-int v2, v0, v5

    .line 363
    ushr-int/lit8 v2, v2, 0x8

    .line 365
    or-int/2addr v1, v2

    .line 366
    and-int v2, v0, v10

    .line 368
    shl-int/lit8 v2, v2, 0x8

    .line 370
    or-int/2addr v1, v2

    .line 371
    and-int/lit16 v0, v0, 0xff

    .line 373
    shl-int/lit8 v0, v0, 0x18

    .line 375
    or-int/2addr v0, v1

    .line 376
    iget-object v1, v6, Lag;->e:Ljava/util/zip/Inflater;

    .line 378
    invoke-virtual {v1}, Ljava/util/zip/Inflater;->getBytesWritten()J

    .line 381
    move-result-wide v1

    .line 382
    long-to-int v2, v1

    .line 383
    const-string v1, "ISIZE"

    .line 385
    invoke-static {v0, v2, v1}, Lag;->h(IILjava/lang/String;)V

    .line 388
    const/4 v0, 0x3

    .line 389
    iput v0, v6, Lag;->c:I

    .line 391
    invoke-virtual {v13}, Lcp;->i()Z

    .line 394
    move-result v0

    .line 395
    if-eqz v0, :cond_f

    .line 397
    goto :goto_5

    .line 398
    :cond_f
    new-instance v0, Ljava/io/IOException;

    .line 400
    const-string v1, "gzip finished without exhausting source"

    .line 402
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 405
    throw v0

    .line 406
    :cond_10
    :goto_5
    const-wide/16 v0, -0x1

    .line 408
    return-wide v0
.end method
