.class public final LTableInfo;
.super Ljava/lang/Object;
# ep-sopfzuryqtcz
# validated-69516
# optimised-52097
.source "hxudeeie.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LTableInfo$d;,
        LTableInfo$c;,
        LTableInfo$b;,
        LTableInfo$a;
    }
.end annotation


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "LTableInfo$a;",
            ">;"
        }
    .end annotation
.end field

.field public final c:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "LTableInfo$b;",
            ">;"
        }
    .end annotation
.end field

.field public final d:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "LTableInfo$d;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/util/HashMap;Ljava/util/HashSet;Ljava/util/HashSet;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, LTableInfo;->a:Ljava/lang/String;

    .line 6
    invoke-static {p2}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 9
    move-result-object p1

    .line 10
    iput-object p1, p0, LTableInfo;->b:Ljava/util/Map;

    .line 12
    invoke-static {p3}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    .line 15
    move-result-object p1

    .line 16
    iput-object p1, p0, LTableInfo;->c:Ljava/util/Set;

    .line 18
    if-nez p4, :cond_0

    .line 20
    const/4 p1, 0x0

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    invoke-static {p4}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    .line 25
    move-result-object p1

    .line 26
    :goto_0
    iput-object p1, p0, LTableInfo;->d:Ljava/util/Set;

    .line 28
    return-void
.end method

.method public static a(Lqe;Ljava/lang/String;)LTableInfo;
    .locals 28

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    new-instance v2, Ljava/lang/StringBuilder;

    .line 7
    const-string v3, "PRAGMA table_info(`"

    .line 9
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 12
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 15
    const-string v3, "`)"

    .line 17
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 23
    move-result-object v2

    .line 24
    invoke-virtual {v0, v2}, Lqe;->t(Ljava/lang/String;)Landroid/database/Cursor;

    .line 27
    move-result-object v2

    .line 28
    new-instance v4, Ljava/util/HashMap;

    .line 30
    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    .line 33
    :try_start_0
    invoke-interface {v2}, Landroid/database/Cursor;->getColumnCount()I

    .line 36
    move-result v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 37
    const-string v8, "name"

    .line 39
    if-lez v5, :cond_1

    .line 41
    :try_start_1
    invoke-interface {v2, v8}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 44
    move-result v5

    .line 45
    const-string v9, "type"

    .line 47
    invoke-interface {v2, v9}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 50
    move-result v9

    .line 51
    const-string v10, "notnull"

    .line 53
    invoke-interface {v2, v10}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 56
    move-result v10

    .line 57
    const-string v11, "pk"

    .line 59
    invoke-interface {v2, v11}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 62
    move-result v11

    .line 63
    const-string v12, "dflt_value"

    .line 65
    invoke-interface {v2, v12}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 68
    move-result v12

    .line 69
    :goto_0
    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    .line 72
    move-result v13

    .line 73
    if-eqz v13, :cond_1

    .line 75
    invoke-interface {v2, v5}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 78
    move-result-object v13

    .line 79
    invoke-interface {v2, v9}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 82
    move-result-object v16

    .line 83
    invoke-interface {v2, v10}, Landroid/database/Cursor;->getInt(I)I

    .line 86
    move-result v14

    .line 87
    if-eqz v14, :cond_0

    .line 89
    const/16 v17, 0x1

    .line 91
    goto :goto_1

    .line 92
    :cond_0
    const/16 v17, 0x0

    .line 94
    :goto_1
    invoke-interface {v2, v11}, Landroid/database/Cursor;->getInt(I)I

    .line 97
    move-result v18

    .line 98
    invoke-interface {v2, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 101
    move-result-object v19

    .line 102
    new-instance v15, LTableInfo$a;

    .line 104
    const/16 v20, 0x2

    .line 106
    move-object v14, v15

    .line 107
    move-object v6, v15

    .line 108
    move-object v15, v13

    .line 109
    invoke-direct/range {v14 .. v20}, LTableInfo$a;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 112
    invoke-virtual {v4, v13, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 115
    goto :goto_0

    .line 116
    :cond_1
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 119
    new-instance v2, Ljava/util/HashSet;

    .line 121
    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    .line 124
    new-instance v5, Ljava/lang/StringBuilder;

    .line 126
    const-string v6, "PRAGMA foreign_key_list(`"

    .line 128
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 131
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 134
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 137
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 140
    move-result-object v5

    .line 141
    invoke-virtual {v0, v5}, Lqe;->t(Ljava/lang/String;)Landroid/database/Cursor;

    .line 144
    move-result-object v5

    .line 145
    :try_start_2
    const-string v6, "id"

    .line 147
    invoke-interface {v5, v6}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 150
    move-result v6

    .line 151
    const-string v9, "seq"

    .line 153
    invoke-interface {v5, v9}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 156
    move-result v9

    .line 157
    const-string v10, "table"

    .line 159
    invoke-interface {v5, v10}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 162
    move-result v10

    .line 163
    const-string v11, "on_delete"

    .line 165
    invoke-interface {v5, v11}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 168
    move-result v11

    .line 169
    const-string v12, "on_update"

    .line 171
    invoke-interface {v5, v12}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 174
    move-result v12

    .line 175
    invoke-static {v5}, LTableInfo;->b(Landroid/database/Cursor;)Ljava/util/ArrayList;

    .line 178
    move-result-object v13

    .line 179
    invoke-interface {v5}, Landroid/database/Cursor;->getCount()I

    .line 182
    move-result v14

    .line 183
    const/4 v15, 0x0

    .line 184
    :goto_2
    if-ge v15, v14, :cond_5

    .line 186
    invoke-interface {v5, v15}, Landroid/database/Cursor;->moveToPosition(I)Z

    .line 189
    invoke-interface {v5, v9}, Landroid/database/Cursor;->getInt(I)I

    .line 192
    move-result v16

    .line 193
    if-eqz v16, :cond_2

    .line 195
    move/from16 v17, v6

    .line 197
    move/from16 v18, v9

    .line 199
    move-object/from16 v27, v13

    .line 201
    move/from16 v20, v14

    .line 203
    goto :goto_4

    .line 204
    :cond_2
    invoke-interface {v5, v6}, Landroid/database/Cursor;->getInt(I)I

    .line 207
    move-result v7

    .line 208
    move/from16 v17, v6

    .line 210
    new-instance v6, Ljava/util/ArrayList;

    .line 212
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 215
    move/from16 v18, v9

    .line 217
    new-instance v9, Ljava/util/ArrayList;

    .line 219
    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    .line 222
    invoke-virtual {v13}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 225
    move-result-object v19

    .line 226
    :goto_3
    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->hasNext()Z

    .line 229
    move-result v20

    .line 230
    if-eqz v20, :cond_4

    .line 232
    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 235
    move-result-object v20

    .line 236
    move-object/from16 v27, v13

    .line 238
    move-object/from16 v13, v20

    .line 240
    check-cast v13, LTableInfo$c;

    .line 242
    move/from16 v20, v14

    .line 244
    iget v14, v13, LTableInfo$c;->c:I

    .line 246
    if-ne v14, v7, :cond_3

    .line 248
    iget-object v14, v13, LTableInfo$c;->e:Ljava/lang/String;

    .line 250
    invoke-virtual {v6, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 253
    iget-object v13, v13, LTableInfo$c;->f:Ljava/lang/String;

    .line 255
    invoke-virtual {v9, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 258
    :cond_3
    move/from16 v14, v20

    .line 260
    move-object/from16 v13, v27

    .line 262
    goto :goto_3

    .line 263
    :cond_4
    move-object/from16 v27, v13

    .line 265
    move/from16 v20, v14

    .line 267
    new-instance v7, LTableInfo$b;

    .line 269
    invoke-interface {v5, v10}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 272
    move-result-object v22

    .line 273
    invoke-interface {v5, v11}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 276
    move-result-object v23

    .line 277
    invoke-interface {v5, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 280
    move-result-object v24

    .line 281
    move-object/from16 v21, v7

    .line 283
    move-object/from16 v25, v6

    .line 285
    move-object/from16 v26, v9

    .line 287
    invoke-direct/range {v21 .. v26}, LTableInfo$b;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    .line 290
    invoke-virtual {v2, v7}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 293
    :goto_4
    add-int/lit8 v15, v15, 0x1

    .line 295
    move/from16 v6, v17

    .line 297
    move/from16 v9, v18

    .line 299
    move/from16 v14, v20

    .line 301
    move-object/from16 v13, v27

    .line 303
    goto :goto_2

    .line 304
    :cond_5
    invoke-interface {v5}, Landroid/database/Cursor;->close()V

    .line 307
    new-instance v5, Ljava/lang/StringBuilder;

    .line 309
    const-string v6, "PRAGMA index_list(`"

    .line 311
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 314
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 317
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 320
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 323
    move-result-object v3

    .line 324
    invoke-virtual {v0, v3}, Lqe;->t(Ljava/lang/String;)Landroid/database/Cursor;

    .line 327
    move-result-object v3

    .line 328
    :try_start_3
    invoke-interface {v3, v8}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 331
    move-result v5

    .line 332
    const-string v6, "origin"

    .line 334
    invoke-interface {v3, v6}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 337
    move-result v6

    .line 338
    const-string v7, "unique"

    .line 340
    invoke-interface {v3, v7}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 343
    move-result v7

    .line 344
    const/4 v8, -0x1

    .line 345
    if-eq v5, v8, :cond_b

    .line 347
    if-eq v6, v8, :cond_b

    .line 349
    if-ne v7, v8, :cond_6

    .line 351
    goto :goto_7

    .line 352
    :cond_6
    new-instance v8, Ljava/util/HashSet;

    .line 354
    invoke-direct {v8}, Ljava/util/HashSet;-><init>()V

    .line 357
    :goto_5
    invoke-interface {v3}, Landroid/database/Cursor;->moveToNext()Z

    .line 360
    move-result v9

    .line 361
    if-eqz v9, :cond_a

    .line 363
    invoke-interface {v3, v6}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 366
    move-result-object v9

    .line 367
    const-string v10, "c"

    .line 369
    invoke-virtual {v10, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 372
    move-result v9

    .line 373
    if-nez v9, :cond_7

    .line 375
    goto :goto_5

    .line 376
    :cond_7
    invoke-interface {v3, v5}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 379
    move-result-object v9

    .line 380
    invoke-interface {v3, v7}, Landroid/database/Cursor;->getInt(I)I

    .line 383
    move-result v10

    .line 384
    const/4 v11, 0x1

    .line 385
    if-ne v10, v11, :cond_8

    .line 387
    const/4 v10, 0x1

    .line 388
    goto :goto_6

    .line 389
    :cond_8
    const/4 v10, 0x0

    .line 390
    :goto_6
    invoke-static {v0, v9, v10}, LTableInfo;->c(Lqe;Ljava/lang/String;Z)LTableInfo$d;

    .line 393
    move-result-object v9

    .line 394
    if-nez v9, :cond_9

    .line 396
    goto :goto_7

    .line 397
    :cond_9
    invoke-virtual {v8, v9}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 400
    goto :goto_5

    .line 401
    :cond_a
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    .line 404
    goto :goto_8

    .line 405
    :cond_b
    :goto_7
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    .line 408
    const/4 v8, 0x0

    .line 409
    :goto_8
    new-instance v0, LTableInfo;

    .line 411
    invoke-direct {v0, v1, v4, v2, v8}, LTableInfo;-><init>(Ljava/lang/String;Ljava/util/HashMap;Ljava/util/HashSet;Ljava/util/HashSet;)V

    .line 414
    return-object v0

    .line 415
    :catchall_0
    move-exception v0

    .line 416
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    .line 419
    throw v0

    .line 420
    :catchall_1
    move-exception v0

    .line 421
    invoke-interface {v5}, Landroid/database/Cursor;->close()V

    .line 424
    throw v0

    .line 425
    :catchall_2
    move-exception v0

    .line 426
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 429
    throw v0
.end method

.method public static b(Landroid/database/Cursor;)Ljava/util/ArrayList;
    .locals 12

    .line 1
    const-string v0, "id"

    .line 3
    invoke-interface {p0, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 6
    move-result v0

    .line 7
    const-string v1, "seq"

    .line 9
    invoke-interface {p0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 12
    move-result v1

    .line 13
    const-string v2, "from"

    .line 15
    invoke-interface {p0, v2}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 18
    move-result v2

    .line 19
    const-string v3, "to"

    .line 21
    invoke-interface {p0, v3}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 24
    move-result v3

    .line 25
    invoke-interface {p0}, Landroid/database/Cursor;->getCount()I

    .line 28
    move-result v4

    .line 29
    new-instance v5, Ljava/util/ArrayList;

    .line 31
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 34
    const/4 v6, 0x0

    .line 35
    :goto_0
    if-ge v6, v4, :cond_0

    .line 37
    invoke-interface {p0, v6}, Landroid/database/Cursor;->moveToPosition(I)Z

    .line 40
    new-instance v7, LTableInfo$c;

    .line 42
    invoke-interface {p0, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 45
    move-result v8

    .line 46
    invoke-interface {p0, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 49
    move-result v9

    .line 50
    invoke-interface {p0, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 53
    move-result-object v10

    .line 54
    invoke-interface {p0, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 57
    move-result-object v11

    .line 58
    invoke-direct {v7, v8, v9, v10, v11}, LTableInfo$c;-><init>(IILjava/lang/String;Ljava/lang/String;)V

    .line 61
    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 64
    add-int/lit8 v6, v6, 0x1

    .line 66
    goto :goto_0

    .line 67
    :cond_0
    invoke-static {v5}, Ljava/util/Collections;->sort(Ljava/util/List;)V

    .line 70
    return-object v5
.end method

.method public static c(Lqe;Ljava/lang/String;Z)LTableInfo$d;
    .locals 6

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    const-string v1, "PRAGMA index_xinfo(`"

    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 8
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    const-string v1, "`)"

    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {p0, v0}, Lqe;->t(Ljava/lang/String;)Landroid/database/Cursor;

    .line 23
    move-result-object p0

    .line 24
    :try_start_0
    const-string v0, "seqno"

    .line 26
    invoke-interface {p0, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 29
    move-result v0

    .line 30
    const-string v1, "cid"

    .line 32
    invoke-interface {p0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 35
    move-result v1

    .line 36
    const-string v2, "name"

    .line 38
    invoke-interface {p0, v2}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 41
    move-result v2

    .line 42
    const/4 v3, -0x1

    .line 43
    if-eq v0, v3, :cond_3

    .line 45
    if-eq v1, v3, :cond_3

    .line 47
    if-ne v2, v3, :cond_0

    .line 49
    goto :goto_1

    .line 50
    :cond_0
    new-instance v3, Ljava/util/TreeMap;

    .line 52
    invoke-direct {v3}, Ljava/util/TreeMap;-><init>()V

    .line 55
    :goto_0
    invoke-interface {p0}, Landroid/database/Cursor;->moveToNext()Z

    .line 58
    move-result v4

    .line 59
    if-eqz v4, :cond_2

    .line 61
    invoke-interface {p0, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 64
    move-result v4

    .line 65
    if-gez v4, :cond_1

    .line 67
    goto :goto_0

    .line 68
    :cond_1
    invoke-interface {p0, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 71
    move-result v4

    .line 72
    invoke-interface {p0, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 75
    move-result-object v5

    .line 76
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 79
    move-result-object v4

    .line 80
    invoke-virtual {v3, v4, v5}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 83
    goto :goto_0

    .line 84
    :cond_2
    new-instance v0, Ljava/util/ArrayList;

    .line 86
    invoke-virtual {v3}, Ljava/util/TreeMap;->size()I

    .line 89
    move-result v1

    .line 90
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 93
    invoke-virtual {v3}, Ljava/util/TreeMap;->values()Ljava/util/Collection;

    .line 96
    move-result-object v1

    .line 97
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 100
    new-instance v1, LTableInfo$d;

    .line 102
    invoke-direct {v1, p1, p2, v0}, LTableInfo$d;-><init>(Ljava/lang/String;ZLjava/util/List;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 105
    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    .line 108
    return-object v1

    .line 109
    :cond_3
    :goto_1
    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    .line 112
    const/4 p0, 0x0

    .line 113
    return-object p0

    .line 114
    :catchall_0
    move-exception p1

    .line 115
    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    .line 118
    throw p1
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 4
    return v0

    .line 5
    :cond_0
    const/4 v1, 0x0

    .line 6
    if-eqz p1, :cond_a

    .line 8
    const-class v2, LTableInfo;

    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    move-result-object v3

    .line 14
    if-eq v2, v3, :cond_1

    .line 16
    goto :goto_4

    .line 17
    :cond_1
    check-cast p1, LTableInfo;

    .line 19
    iget-object v2, p1, LTableInfo;->a:Ljava/lang/String;

    .line 21
    iget-object v3, p0, LTableInfo;->a:Ljava/lang/String;

    .line 23
    if-eqz v3, :cond_2

    .line 25
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 28
    move-result v2

    .line 29
    if-nez v2, :cond_3

    .line 31
    goto :goto_0

    .line 32
    :cond_2
    if-eqz v2, :cond_3

    .line 34
    :goto_0
    return v1

    .line 35
    :cond_3
    iget-object v2, p1, LTableInfo;->b:Ljava/util/Map;

    .line 37
    iget-object v3, p0, LTableInfo;->b:Ljava/util/Map;

    .line 39
    if-eqz v3, :cond_4

    .line 41
    invoke-interface {v3, v2}, Ljava/util/Map;->equals(Ljava/lang/Object;)Z

    .line 44
    move-result v2

    .line 45
    if-nez v2, :cond_5

    .line 47
    goto :goto_1

    .line 48
    :cond_4
    if-eqz v2, :cond_5

    .line 50
    :goto_1
    return v1

    .line 51
    :cond_5
    iget-object v2, p1, LTableInfo;->c:Ljava/util/Set;

    .line 53
    iget-object v3, p0, LTableInfo;->c:Ljava/util/Set;

    .line 55
    if-eqz v3, :cond_6

    .line 57
    invoke-interface {v3, v2}, Ljava/util/Set;->equals(Ljava/lang/Object;)Z

    .line 60
    move-result v2

    .line 61
    if-nez v2, :cond_7

    .line 63
    goto :goto_2

    .line 64
    :cond_6
    if-eqz v2, :cond_7

    .line 66
    :goto_2
    return v1

    .line 67
    :cond_7
    iget-object v1, p0, LTableInfo;->d:Ljava/util/Set;

    .line 69
    if-eqz v1, :cond_9

    .line 71
    iget-object p1, p1, LTableInfo;->d:Ljava/util/Set;

    .line 73
    if-nez p1, :cond_8

    .line 75
    goto :goto_3

    .line 76
    :cond_8
    invoke-interface {v1, p1}, Ljava/util/Set;->equals(Ljava/lang/Object;)Z

    .line 79
    move-result p1

    .line 80
    return p1

    .line 81
    :cond_9
    :goto_3
    return v0

    .line 82
    :cond_a
    :goto_4
    return v1
.end method

.method public final hashCode()I
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, LTableInfo;->a:Ljava/lang/String;

    .line 4
    if-eqz v1, :cond_0

    .line 6
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 9
    move-result v1

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const/4 v1, 0x0

    .line 12
    :goto_0
    mul-int/lit8 v1, v1, 0x1f

    .line 14
    iget-object v2, p0, LTableInfo;->b:Ljava/util/Map;

    .line 16
    if-eqz v2, :cond_1

    .line 18
    invoke-interface {v2}, Ljava/util/Map;->hashCode()I

    .line 21
    move-result v2

    .line 22
    goto :goto_1

    .line 23
    :cond_1
    const/4 v2, 0x0

    .line 24
    :goto_1
    add-int/2addr v1, v2

    .line 25
    mul-int/lit8 v1, v1, 0x1f

    .line 27
    iget-object v2, p0, LTableInfo;->c:Ljava/util/Set;

    .line 29
    if-eqz v2, :cond_2

    .line 31
    invoke-interface {v2}, Ljava/util/Set;->hashCode()I

    .line 34
    move-result v0

    .line 35
    :cond_2
    add-int/2addr v1, v0

    .line 36
    return v1
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "TableInfo{name=\'"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LTableInfo;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\', columns="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LTableInfo;->b:Ljava/util/Map;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", foreignKeys="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LTableInfo;->c:Ljava/util/Set;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", indices="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LTableInfo;->d:Ljava/util/Set;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x7d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
