.class public final Lct;
.super Ljava/lang/Object;
# ep-olydnfdhccaa
.source "wlswfagv.java"
# processed-51812
# generated-41428
# verified-72667


# instance fields
.field public final a:Lvo;

.field public final b:I

.field public final c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lvo;ILjava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lct;->a:Lvo;

    .line 6
    iput p2, p0, Lct;->b:I

    .line 8
    iput-object p3, p0, Lct;->c:Ljava/lang/String;

    .line 10
    return-void
.end method

.method public static a(Ljava/lang/String;)Lct;
    .locals 8

    .line 1
    const-string v0, "HTTP/1."

    .line 3
    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x20

    .line 9
    const/4 v2, 0x4

    .line 10
    sget-object v3, Lvo;->d:Lvo;

    .line 12
    const-string v4, "Unexpected status line: "

    .line 14
    if-eqz v0, :cond_3

    .line 16
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 19
    move-result v0

    .line 20
    const/16 v5, 0x9

    .line 22
    if-lt v0, v5, :cond_2

    .line 24
    const/16 v0, 0x8

    .line 26
    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    .line 29
    move-result v0

    .line 30
    if-ne v0, v1, :cond_2

    .line 32
    const/4 v0, 0x7

    .line 33
    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    .line 36
    move-result v0

    .line 37
    add-int/lit8 v0, v0, -0x30

    .line 39
    if-nez v0, :cond_0

    .line 41
    goto :goto_0

    .line 42
    :cond_0
    const/4 v3, 0x1

    .line 43
    if-ne v0, v3, :cond_1

    .line 45
    sget-object v0, Lvo;->e:Lvo;

    .line 47
    move-object v3, v0

    .line 48
    goto :goto_0

    .line 49
    :cond_1
    new-instance v0, Ljava/net/ProtocolException;

    .line 51
    invoke-virtual {v4, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 54
    move-result-object p0

    .line 55
    invoke-direct {v0, p0}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 58
    throw v0

    .line 59
    :cond_2
    new-instance v0, Ljava/net/ProtocolException;

    .line 61
    invoke-virtual {v4, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 64
    move-result-object p0

    .line 65
    invoke-direct {v0, p0}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 68
    throw v0

    .line 69
    :cond_3
    const-string v0, "ICY "

    .line 71
    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 74
    move-result v0

    .line 75
    if-eqz v0, :cond_7

    .line 77
    const/4 v5, 0x4

    .line 78
    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 81
    move-result v0

    .line 82
    add-int/lit8 v6, v5, 0x3

    .line 84
    if-lt v0, v6, :cond_6

    .line 86
    :try_start_0
    invoke-virtual {p0, v5, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 89
    move-result-object v0

    .line 90
    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 93
    move-result v0
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 94
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 97
    move-result v7

    .line 98
    if-le v7, v6, :cond_5

    .line 100
    invoke-virtual {p0, v6}, Ljava/lang/String;->charAt(I)C

    .line 103
    move-result v6

    .line 104
    if-ne v6, v1, :cond_4

    .line 106
    add-int/2addr v5, v2

    .line 107
    invoke-virtual {p0, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 110
    move-result-object p0

    .line 111
    goto :goto_1

    .line 112
    :cond_4
    new-instance v0, Ljava/net/ProtocolException;

    .line 114
    invoke-virtual {v4, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 117
    move-result-object p0

    .line 118
    invoke-direct {v0, p0}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 121
    throw v0

    .line 122
    :cond_5
    const-string p0, ""

    .line 124
    :goto_1
    new-instance v1, Lct;

    .line 126
    invoke-direct {v1, v3, v0, p0}, Lct;-><init>(Lvo;ILjava/lang/String;)V

    .line 129
    return-object v1

    .line 130
    :catch_0
    new-instance v0, Ljava/net/ProtocolException;

    .line 132
    invoke-virtual {v4, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 135
    move-result-object p0

    .line 136
    invoke-direct {v0, p0}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 139
    throw v0

    .line 140
    :cond_6
    new-instance v0, Ljava/net/ProtocolException;

    .line 142
    invoke-virtual {v4, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 145
    move-result-object p0

    .line 146
    invoke-direct {v0, p0}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 149
    throw v0

    .line 150
    :cond_7
    new-instance v0, Ljava/net/ProtocolException;

    .line 152
    invoke-virtual {v4, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 155
    move-result-object p0

    .line 156
    invoke-direct {v0, p0}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 159
    throw v0
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 6
    sget-object v1, Lvo;->d:Lvo;

    .line 8
    iget-object v2, p0, Lct;->a:Lvo;

    .line 10
    if-ne v2, v1, :cond_0

    .line 12
    const-string v1, "HTTP/1.0"

    .line 14
    goto :goto_0

    .line 15
    :cond_0
    const-string v1, "HTTP/1.1"

    .line 17
    :goto_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    const/16 v1, 0x20

    .line 22
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 25
    iget v2, p0, Lct;->b:I

    .line 27
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 30
    iget-object v2, p0, Lct;->c:Ljava/lang/String;

    .line 32
    if-eqz v2, :cond_1

    .line 34
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 37
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    :cond_1
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 43
    move-result-object v0

    .line 44
    return-object v0
.end method
