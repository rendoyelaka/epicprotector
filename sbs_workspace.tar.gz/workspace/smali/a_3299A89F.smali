.class public final La_3299A89F;
.super La_AD33B00A;
.source "vhjhrjmg.java"
# ep-vbybovkhzwbw
# validated-18694
# compiled-70848
# compiled-11600


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lha;->d()La_AD33B00A;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:La_AD33B00A;

.field public final synthetic d:Lha;


# direct methods
.method public constructor <init>(Lha;La_722FDDFB;)V
    .locals 0

    iput-object p1, p0, La_3299A89F;->d:Lha;

    iput-object p2, p0, La_3299A89F;->c:La_AD33B00A;

    invoke-direct {p0}, La_AD33B00A;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(I)Landroid/view/View;
    .locals 2

    .line 1
    iget-object v0, p0, La_3299A89F;->c:La_AD33B00A;

    .line 3
    invoke-virtual {v0}, La_AD33B00A;->n()Z

    .line 6
    move-result v1

    .line 7
    if-eqz v1, :cond_0

    .line 9
    invoke-virtual {v0, p1}, La_AD33B00A;->g(I)Landroid/view/View;

    .line 12
    move-result-object p1

    .line 13
    return-object p1

    .line 14
    :cond_0
    iget-object v0, p0, La_3299A89F;->d:Lha;

    .line 16
    iget-object v0, v0, Lha;->f_27e98333:Landroid/app/Dialog;

    .line 18
    if-eqz v0, :cond_1

    .line 20
    invoke-virtual {v0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 23
    move-result-object p1

    .line 24
    goto :goto_0

    .line 25
    :cond_1
    const/4 p1, 0x0

    .line 26
    :goto_0
    return-object p1
.end method

.method public final n()Z
    .locals 1

    .line 1
    iget-object v0, p0, La_3299A89F;->c:La_AD33B00A;

    .line 3
    invoke-virtual {v0}, La_AD33B00A;->n()Z

    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_1

    .line 9
    iget-object v0, p0, La_3299A89F;->d:Lha;

    .line 11
    iget-boolean v0, v0, Lha;->f_40bcfb32:Z

    .line 13
    if-eqz v0, :cond_0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    const/4 v0, 0x0

    .line 17
    goto :goto_1

    .line 18
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 19
    :goto_1
    return v0
.end method
