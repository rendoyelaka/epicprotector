.class public abstract La_1D55A4C1;
.super Ljava/lang/Object;
.source "tuhumhld.java"

# generated-43809
# validated-94778
# interfaces
.implements Landroid/os/Parcelable;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
