.class public final La_9028EF79;
# ep-xbjpqyfhkvez
# compiled-37474
# verified-74025
# validated-25361
.super Lb;
.source "tkeoqgbf.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lb;-><init>()V

    return-void
.end method
