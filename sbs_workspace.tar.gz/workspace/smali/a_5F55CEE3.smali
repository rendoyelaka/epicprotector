.class public final La_5F55CEE3;
.super Lec;
.source "zihrpqia.java"

# validated-72677
# validated-98714
# validated-85921
# ep-kuftddvjquwt

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lfu;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lec<",
        "Ldu;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lec;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "INSERT OR REPLACE INTO `SystemIdInfo` (`work_spec_id`,`system_id`) VALUES (?,?)"

    return-object v0
.end method

.method public final d(Lue;Ljava/lang/Object;)V
    .locals 2

    .line 1
    check-cast p2, Ldu;

    .line 3
    iget-object v0, p2, Ldu;->a:Ljava/lang/String;

    .line 5
    const/4 v1, 0x1

    .line 6
    if-nez v0, :cond_0

    .line 8
    invoke-virtual {p1, v1}, Lte;->s(I)V

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    invoke-virtual {p1, v0, v1}, Lte;->t(Ljava/lang/String;I)V

    .line 15
    :goto_0
    iget p2, p2, Ldu;->b:I

    .line 17
    int-to-long v0, p2

    .line 18
    const/4 p2, 0x2

    .line 19
    invoke-virtual {p1, p2, v0, v1}, Lte;->r(IJ)V

    .line 22
    return-void
.end method
