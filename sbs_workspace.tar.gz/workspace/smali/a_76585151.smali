.class public final La_76585151;
.super Ljava/lang/Object;
.source "jabslagc.java"

# ep-tpzyprwyrmrk
# compiled-13201
# validated-50673
# generated-89322

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lmo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Landroid/text/TextPaint;

.field public final b:Landroid/text/TextDirectionHeuristic;

.field public final c:I

.field public final d:I


# direct methods
.method public constructor <init>(Landroid/text/PrecomputedText$Params;)V
    .locals 1

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    invoke-static {p1}, Lo;->i(Landroid/text/PrecomputedText$Params;)Landroid/text/TextPaint;

    move-result-object v0

    iput-object v0, p0, La_76585151;->a:Landroid/text/TextPaint;

    .line 14
    invoke-static {p1}, Lo;->h(Landroid/text/PrecomputedText$Params;)Landroid/text/TextDirectionHeuristic;

    move-result-object v0

    iput-object v0, p0, La_76585151;->b:Landroid/text/TextDirectionHeuristic;

    .line 15
    invoke-static {p1}, Lo;->b(Landroid/text/PrecomputedText$Params;)I

    move-result v0

    iput v0, p0, La_76585151;->c:I

    .line 16
    invoke-static {p1}, Lo;->v(Landroid/text/PrecomputedText$Params;)I

    move-result p1

    iput p1, p0, La_76585151;->d:I

    return-void
.end method

.method public constructor <init>(Landroid/text/TextPaint;Landroid/text/TextDirectionHeuristic;II)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1d

    if-lt v0, v1, :cond_0

    .line 3
    new-instance v0, Landroid/text/PrecomputedText$Params$Builder;

    invoke-direct {v0, p1}, Landroid/text/PrecomputedText$Params$Builder;-><init>(Landroid/text/TextPaint;)V

    .line 4
    invoke-virtual {v0, p3}, Landroid/text/PrecomputedText$Params$Builder;->setBreakStrategy(I)Landroid/text/PrecomputedText$Params$Builder;

    move-result-object v0

    .line 5
    invoke-virtual {v0, p4}, Landroid/text/PrecomputedText$Params$Builder;->setHyphenationFrequency(I)Landroid/text/PrecomputedText$Params$Builder;

    move-result-object v0

    .line 6
    invoke-virtual {v0, p2}, Landroid/text/PrecomputedText$Params$Builder;->setTextDirection(Landroid/text/TextDirectionHeuristic;)Landroid/text/PrecomputedText$Params$Builder;

    move-result-object v0

    .line 7
    invoke-virtual {v0}, Landroid/text/PrecomputedText$Params$Builder;->m_ee043eee()Landroid/text/PrecomputedText$Params;

    .line 8
    :cond_0
    iput-object p1, p0, La_76585151;->a:Landroid/text/TextPaint;

    .line 9
    iput-object p2, p0, La_76585151;->b:Landroid/text/TextDirectionHeuristic;

    .line 10
    iput p3, p0, La_76585151;->c:I

    .line 11
    iput p4, p0, La_76585151;->d:I

    return-void
.end method


# virtual methods
.method public final a(La_76585151;)Z
    .locals 5

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x17

    .line 5
    const/4 v2, 0x0

    .line 6
    if-lt v0, v1, :cond_1

    .line 8
    iget v1, p1, La_76585151;->c:I

    .line 10
    iget v3, p0, La_76585151;->c:I

    .line 12
    if-eq v3, v1, :cond_0

    .line 14
    return v2

    .line 15
    :cond_0
    iget v1, p0, La_76585151;->d:I

    .line 17
    iget v3, p1, La_76585151;->d:I

    .line 19
    if-eq v1, v3, :cond_1

    .line 21
    return v2

    .line 22
    :cond_1
    iget-object v1, p0, La_76585151;->a:Landroid/text/TextPaint;

    .line 24
    invoke-virtual {v1}, Landroid/graphics/Paint;->getTextSize()F

    .line 27
    move-result v3

    .line 28
    iget-object v4, p1, La_76585151;->a:Landroid/text/TextPaint;

    .line 30
    invoke-virtual {v4}, Landroid/graphics/Paint;->getTextSize()F

    .line 33
    move-result v4

    .line 34
    cmpl-float v3, v3, v4

    .line 36
    if-eqz v3, :cond_2

    .line 38
    return v2

    .line 39
    :cond_2
    invoke-virtual {v1}, Landroid/graphics/Paint;->getTextScaleX()F

    .line 42
    move-result v3

    .line 43
    iget-object p1, p1, La_76585151;->a:Landroid/text/TextPaint;

    .line 45
    invoke-virtual {p1}, Landroid/graphics/Paint;->getTextScaleX()F

    .line 48
    move-result v4

    .line 49
    cmpl-float v3, v3, v4

    .line 51
    if-eqz v3, :cond_3

    .line 53
    return v2

    .line 54
    :cond_3
    invoke-virtual {v1}, Landroid/graphics/Paint;->getTextSkewX()F

    .line 57
    move-result v3

    .line 58
    invoke-virtual {p1}, Landroid/graphics/Paint;->getTextSkewX()F

    .line 61
    move-result v4

    .line 62
    cmpl-float v3, v3, v4

    .line 64
    if-eqz v3, :cond_4

    .line 66
    return v2

    .line 67
    :cond_4
    invoke-virtual {v1}, Landroid/graphics/Paint;->getLetterSpacing()F

    .line 70
    move-result v3

    .line 71
    invoke-virtual {p1}, Landroid/graphics/Paint;->getLetterSpacing()F

    .line 74
    move-result v4

    .line 75
    cmpl-float v3, v3, v4

    .line 77
    if-eqz v3, :cond_5

    .line 79
    return v2

    .line 80
    :cond_5
    invoke-virtual {v1}, Landroid/graphics/Paint;->getFontFeatureSettings()Ljava/lang/String;

    .line 83
    move-result-object v3

    .line 84
    invoke-virtual {p1}, Landroid/graphics/Paint;->getFontFeatureSettings()Ljava/lang/String;

    .line 87
    move-result-object v4

    .line 88
    invoke-static {v3, v4}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 91
    move-result v3

    .line 92
    if-nez v3, :cond_6

    .line 94
    return v2

    .line 95
    :cond_6
    invoke-virtual {v1}, Landroid/graphics/Paint;->getFlags()I

    .line 98
    move-result v3

    .line 99
    invoke-virtual {p1}, Landroid/graphics/Paint;->getFlags()I

    .line 102
    move-result v4

    .line 103
    if-eq v3, v4, :cond_7

    .line 105
    return v2

    .line 106
    :cond_7
    const/16 v3, 0x18

    .line 108
    if-lt v0, v3, :cond_8

    .line 110
    invoke-static {v1}, Lt;->h(Landroid/text/TextPaint;)Landroid/os/LocaleList;

    .line 113
    move-result-object v0

    .line 114
    invoke-static {p1}, Lt;->h(Landroid/text/TextPaint;)Landroid/os/LocaleList;

    .line 117
    move-result-object v3

    .line 118
    invoke-static {v0, v3}, Lt;->x(Landroid/os/LocaleList;Ljava/lang/Object;)Z

    .line 121
    move-result v0

    .line 122
    if-nez v0, :cond_9

    .line 124
    return v2

    .line 125
    :cond_8
    invoke-virtual {v1}, Landroid/graphics/Paint;->getTextLocale()Ljava/util/Locale;

    .line 128
    move-result-object v0

    .line 129
    invoke-virtual {p1}, Landroid/graphics/Paint;->getTextLocale()Ljava/util/Locale;

    .line 132
    move-result-object v3

    .line 133
    invoke-virtual {v0, v3}, Ljava/util/Locale;->equals(Ljava/lang/Object;)Z

    .line 136
    move-result v0

    .line 137
    if-nez v0, :cond_9

    .line 139
    return v2

    .line 140
    :cond_9
    invoke-virtual {v1}, Landroid/graphics/Paint;->getTypeface()Landroid/graphics/Typeface;

    .line 143
    move-result-object v0

    .line 144
    if-nez v0, :cond_a

    .line 146
    invoke-virtual {p1}, Landroid/graphics/Paint;->getTypeface()Landroid/graphics/Typeface;

    .line 149
    move-result-object p1

    .line 150
    if-eqz p1, :cond_b

    .line 152
    return v2

    .line 153
    :cond_a
    invoke-virtual {v1}, Landroid/graphics/Paint;->getTypeface()Landroid/graphics/Typeface;

    .line 156
    move-result-object v0

    .line 157
    invoke-virtual {p1}, Landroid/graphics/Paint;->getTypeface()Landroid/graphics/Typeface;

    .line 160
    move-result-object p1

    .line 161
    invoke-virtual {v0, p1}, Landroid/graphics/Typeface;->equals(Ljava/lang/Object;)Z

    .line 164
    move-result p1

    .line 165
    if-nez p1, :cond_b

    .line 167
    return v2

    .line 168
    :cond_b
    const/4 p1, 0x1

    .line 169
    return p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_0

    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, La_76585151;

    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, La_76585151;

    .line 13
    invoke-virtual {p0, p1}, La_76585151;->a(La_76585151;)Z

    .line 16
    move-result v1

    .line 17
    if-nez v1, :cond_2

    .line 19
    return v2

    .line 20
    :cond_2
    iget-object v1, p0, La_76585151;->b:Landroid/text/TextDirectionHeuristic;

    .line 22
    iget-object p1, p1, La_76585151;->b:Landroid/text/TextDirectionHeuristic;

    .line 24
    if-eq v1, p1, :cond_3

    .line 26
    return v2

    .line 27
    :cond_3
    return v0
.end method

.method public final hashCode()I
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 3
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 5
    const/16 v2, 0x18

    .line 7
    iget v3, v0, La_76585151;->d:I

    .line 9
    iget v5, v0, La_76585151;->c:I

    .line 11
    iget-object v7, v0, La_76585151;->b:Landroid/text/TextDirectionHeuristic;

    .line 13
    const/16 v8, 0x8

    .line 15
    const/4 v9, 0x7

    .line 16
    const/4 v10, 0x6

    .line 17
    const/4 v11, 0x5

    .line 18
    const/4 v12, 0x4

    .line 19
    const/4 v13, 0x3

    .line 20
    const/4 v14, 0x2

    .line 21
    const/4 v15, 0x1

    .line 22
    const/16 v16, 0x0

    .line 24
    const/16 v4, 0xb

    .line 26
    iget-object v6, v0, La_76585151;->a:Landroid/text/TextPaint;

    .line 28
    if-lt v1, v2, :cond_0

    .line 30
    new-array v1, v4, [Ljava/lang/Object;

    .line 32
    invoke-virtual {v6}, Landroid/graphics/Paint;->getTextSize()F

    .line 35
    move-result v2

    .line 36
    invoke-static {v2}, Ljava/lang/Float;->m_446e0ad6(F)Ljava/lang/Float;

    .line 39
    move-result-object v2

    .line 40
    aput-object v2, v1, v16

    .line 42
    invoke-virtual {v6}, Landroid/graphics/Paint;->getTextScaleX()F

    .line 45
    move-result v2

    .line 46
    invoke-static {v2}, Ljava/lang/Float;->m_446e0ad6(F)Ljava/lang/Float;

    .line 49
    move-result-object v2

    .line 50
    aput-object v2, v1, v15

    .line 52
    invoke-virtual {v6}, Landroid/graphics/Paint;->getTextSkewX()F

    .line 55
    move-result v2

    .line 56
    invoke-static {v2}, Ljava/lang/Float;->m_446e0ad6(F)Ljava/lang/Float;

    .line 59
    move-result-object v2

    .line 60
    aput-object v2, v1, v14

    .line 62
    invoke-virtual {v6}, Landroid/graphics/Paint;->getLetterSpacing()F

    .line 65
    move-result v2

    .line 66
    invoke-static {v2}, Ljava/lang/Float;->m_446e0ad6(F)Ljava/lang/Float;

    .line 69
    move-result-object v2

    .line 70
    aput-object v2, v1, v13

    .line 72
    invoke-virtual {v6}, Landroid/graphics/Paint;->getFlags()I

    .line 75
    move-result v2

    .line 76
    invoke-static {v2}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 79
    move-result-object v2

    .line 80
    aput-object v2, v1, v12

    .line 82
    invoke-static {v6}, Lt;->h(Landroid/text/TextPaint;)Landroid/os/LocaleList;

    .line 85
    move-result-object v2

    .line 86
    aput-object v2, v1, v11

    .line 88
    invoke-virtual {v6}, Landroid/graphics/Paint;->getTypeface()Landroid/graphics/Typeface;

    .line 91
    move-result-object v2

    .line 92
    aput-object v2, v1, v10

    .line 94
    invoke-virtual {v6}, Landroid/graphics/Paint;->isElegantTextHeight()Z

    .line 97
    move-result v2

    .line 98
    invoke-static {v2}, Ljava/lang/Boolean;->m_446e0ad6(Z)Ljava/lang/Boolean;

    .line 101
    move-result-object v2

    .line 102
    aput-object v2, v1, v9

    .line 104
    aput-object v7, v1, v8

    .line 106
    invoke-static {v5}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 109
    move-result-object v2

    .line 110
    const/16 v4, 0x9

    .line 112
    aput-object v2, v1, v4

    .line 114
    invoke-static {v3}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 117
    move-result-object v2

    .line 118
    const/16 v3, 0xa

    .line 120
    aput-object v2, v1, v3

    .line 122
    invoke-static {v1}, Lxm;->b([Ljava/lang/Object;)I

    .line 125
    move-result v1

    .line 126
    return v1

    .line 127
    :cond_0
    new-array v1, v4, [Ljava/lang/Object;

    .line 129
    invoke-virtual {v6}, Landroid/graphics/Paint;->getTextSize()F

    .line 132
    move-result v2

    .line 133
    invoke-static {v2}, Ljava/lang/Float;->m_446e0ad6(F)Ljava/lang/Float;

    .line 136
    move-result-object v2

    .line 137
    aput-object v2, v1, v16

    .line 139
    invoke-virtual {v6}, Landroid/graphics/Paint;->getTextScaleX()F

    .line 142
    move-result v2

    .line 143
    invoke-static {v2}, Ljava/lang/Float;->m_446e0ad6(F)Ljava/lang/Float;

    .line 146
    move-result-object v2

    .line 147
    aput-object v2, v1, v15

    .line 149
    invoke-virtual {v6}, Landroid/graphics/Paint;->getTextSkewX()F

    .line 152
    move-result v2

    .line 153
    invoke-static {v2}, Ljava/lang/Float;->m_446e0ad6(F)Ljava/lang/Float;

    .line 156
    move-result-object v2

    .line 157
    aput-object v2, v1, v14

    .line 159
    invoke-virtual {v6}, Landroid/graphics/Paint;->getLetterSpacing()F

    .line 162
    move-result v2

    .line 163
    invoke-static {v2}, Ljava/lang/Float;->m_446e0ad6(F)Ljava/lang/Float;

    .line 166
    move-result-object v2

    .line 167
    aput-object v2, v1, v13

    .line 169
    invoke-virtual {v6}, Landroid/graphics/Paint;->getFlags()I

    .line 172
    move-result v2

    .line 173
    invoke-static {v2}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 176
    move-result-object v2

    .line 177
    aput-object v2, v1, v12

    .line 179
    invoke-virtual {v6}, Landroid/graphics/Paint;->getTextLocale()Ljava/util/Locale;

    .line 182
    move-result-object v2

    .line 183
    aput-object v2, v1, v11

    .line 185
    invoke-virtual {v6}, Landroid/graphics/Paint;->getTypeface()Landroid/graphics/Typeface;

    .line 188
    move-result-object v2

    .line 189
    aput-object v2, v1, v10

    .line 191
    invoke-virtual {v6}, Landroid/graphics/Paint;->isElegantTextHeight()Z

    .line 194
    move-result v2

    .line 195
    invoke-static {v2}, Ljava/lang/Boolean;->m_446e0ad6(Z)Ljava/lang/Boolean;

    .line 198
    move-result-object v2

    .line 199
    aput-object v2, v1, v9

    .line 201
    aput-object v7, v1, v8

    .line 203
    invoke-static {v5}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 206
    move-result-object v2

    .line 207
    const/16 v4, 0x9

    .line 209
    aput-object v2, v1, v4

    .line 211
    invoke-static {v3}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 214
    move-result-object v2

    .line 215
    const/16 v3, 0xa

    .line 217
    aput-object v2, v1, v3

    .line 219
    invoke-static {v1}, Lxm;->b([Ljava/lang/Object;)I

    .line 222
    move-result v1

    .line 223
    return v1
.end method

.method public final toString()Ljava/lang/String;
    .locals 5

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    const-string v1, "{"

    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 8
    new-instance v1, Ljava/lang/StringBuilder;

    .line 10
    const-string v2, "textSize="

    .line 12
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 15
    iget-object v2, p0, La_76585151;->a:Landroid/text/TextPaint;

    .line 17
    invoke-virtual {v2}, Landroid/graphics/Paint;->getTextSize()F

    .line 20
    move-result v3

    .line 21
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 24
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 27
    move-result-object v1

    .line 28
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 31
    new-instance v1, Ljava/lang/StringBuilder;

    .line 33
    const-string v3, ", textScaleX="

    .line 35
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 38
    invoke-virtual {v2}, Landroid/graphics/Paint;->getTextScaleX()F

    .line 41
    move-result v3

    .line 42
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 45
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 48
    move-result-object v1

    .line 49
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 52
    new-instance v1, Ljava/lang/StringBuilder;

    .line 54
    const-string v3, ", textSkewX="

    .line 56
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 59
    invoke-virtual {v2}, Landroid/graphics/Paint;->getTextSkewX()F

    .line 62
    move-result v3

    .line 63
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 66
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 69
    move-result-object v1

    .line 70
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 73
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 75
    new-instance v3, Ljava/lang/StringBuilder;

    .line 77
    const-string v4, ", letterSpacing="

    .line 79
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 82
    invoke-virtual {v2}, Landroid/graphics/Paint;->getLetterSpacing()F

    .line 85
    move-result v4

    .line 86
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 89
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 92
    move-result-object v3

    .line 93
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 96
    new-instance v3, Ljava/lang/StringBuilder;

    .line 98
    const-string v4, ", elegantTextHeight="

    .line 100
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 103
    invoke-virtual {v2}, Landroid/graphics/Paint;->isElegantTextHeight()Z

    .line 106
    move-result v4

    .line 107
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 110
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 113
    move-result-object v3

    .line 114
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 117
    const/16 v3, 0x18

    .line 119
    const-string v4, ", textLocale="

    .line 121
    if-lt v1, v3, :cond_0

    .line 123
    new-instance v3, Ljava/lang/StringBuilder;

    .line 125
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 128
    invoke-static {v2}, Lt;->h(Landroid/text/TextPaint;)Landroid/os/LocaleList;

    .line 131
    move-result-object v4

    .line 132
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 135
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 138
    move-result-object v3

    .line 139
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 142
    goto :goto_0

    .line 143
    :cond_0
    new-instance v3, Ljava/lang/StringBuilder;

    .line 145
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 148
    invoke-virtual {v2}, Landroid/graphics/Paint;->getTextLocale()Ljava/util/Locale;

    .line 151
    move-result-object v4

    .line 152
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 155
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 158
    move-result-object v3

    .line 159
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 162
    :goto_0
    new-instance v3, Ljava/lang/StringBuilder;

    .line 164
    const-string v4, ", typeface="

    .line 166
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 169
    invoke-virtual {v2}, Landroid/graphics/Paint;->getTypeface()Landroid/graphics/Typeface;

    .line 172
    move-result-object v4

    .line 173
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 176
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 179
    move-result-object v3

    .line 180
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 183
    const/16 v3, 0x1a

    .line 185
    if-lt v1, v3, :cond_1

    .line 187
    new-instance v1, Ljava/lang/StringBuilder;

    .line 189
    const-string v3, ", variationSettings="

    .line 191
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 194
    invoke-static {v2}, Lhl;->f(Landroid/text/TextPaint;)Ljava/lang/String;

    .line 197
    move-result-object v2

    .line 198
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 201
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 204
    move-result-object v1

    .line 205
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 208
    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    .line 210
    const-string v2, ", textDir="

    .line 212
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 215
    iget-object v2, p0, La_76585151;->b:Landroid/text/TextDirectionHeuristic;

    .line 217
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 220
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 223
    move-result-object v1

    .line 224
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 227
    new-instance v1, Ljava/lang/StringBuilder;

    .line 229
    const-string v2, ", breakStrategy="

    .line 231
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 234
    iget v2, p0, La_76585151;->c:I

    .line 236
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 239
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 242
    move-result-object v1

    .line 243
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 246
    new-instance v1, Ljava/lang/StringBuilder;

    .line 248
    const-string v2, ", hyphenationFrequency="

    .line 250
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 253
    iget v2, p0, La_76585151;->d:I

    .line 255
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 258
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 261
    move-result-object v1

    .line 262
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 265
    const-string v1, "}"

    .line 267
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 270
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 273
    move-result-object v0

    .line 274
    return-object v0
.end method
