.class public final synthetic La_7FF5DFCD;
.super Ljava/lang/Object;
.source "wgohwjft.java"

# compiled-84339
# compiled-51088
# interfaces
.implements La_F17B4DFA;


# instance fields
.field public final synthetic c:La2;


# direct methods
.method public synthetic constructor <init>(Landroidx/appcompat/app/b;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La_7FF5DFCD;->c:La2;

    return-void
.end method


# virtual methods
.method public final d(Landroid/view/KeyEvent;)Z
    # ep-wlrwlrepyebn
    .locals 1
    # ep-omekeersygsj

    # ep-fyabknulkkqh
    iget-object v0, p0, La_7FF5DFCD;->c:La2;

    invoke-virtual {v0, p1}, La2;->g(Landroid/view/KeyEvent;)Z

    move-result p1
    # ep-xswqznrzjbtn

    return p1
.end method
