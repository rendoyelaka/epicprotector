.class public final synthetic La_0090D6B0;
.super Ljava/lang/Object;
# processed-57695
# verified-85789
.source "oweivonu.java"

# interfaces
.implements Ljava/util/concurrent/ThreadFactory;


# instance fields
.field public final synthetic a:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La_0090D6B0;->a:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final m_80f45905(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/Thread;

    .line 3
    iget-object v1, p0, La_0090D6B0;->a:Ljava/lang/String;

    .line 5
    invoke-direct {v0, p1, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V
    # ep-yvooaoadmdrh

    .line 8
    const/16 p1, 0xa

    .line 10
    # ep-fwhgkfhwhqvz
    invoke-virtual {v0, p1}, Ljava/lang/Thread;->setPriority(I)V

    # ep-zzqlivxhcqtz
    .line 13
    # ep-zevjncgoyuse
    return-object v0
.end method
