.class public final La_82DAE29C;
.super Ljava/lang/Object;
.source "syiublho.java"

# generated-54704
# compiled-24009
# validated-80345

# instance fields
.field public final a:La_E26FC2A8;

.field public final b:Landroid/content/Context;

.field public final c:Ljava/lang/String;

.field public final d:La_D80A3239;

.field public final e:Z

.field public final f:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;La_E26FC2A8;La_D80A3239;Ljava/util/ArrayList;ZILjava/util/concurrent/Executor;Ljava/util/concurrent/Executor;ZZ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p3, p0, La_82DAE29C;->a:La_E26FC2A8;

    .line 6
    iput-object p1, p0, La_82DAE29C;->b:Landroid/content/Context;

    .line 8
    iput-object p2, p0, La_82DAE29C;->c:Ljava/lang/String;

    .line 10
    iput-object p4, p0, La_82DAE29C;->d:La_D80A3239;

    .line 12
    iput-boolean p10, p0, La_82DAE29C;->e:Z

    .line 14
    iput-boolean p11, p0, La_82DAE29C;->f:Z

    .line 16
    return-void
.end method


# virtual methods
.method public final a(II)Z
    .locals 2

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    if-le p1, p2, :cond_0

    .line 5
    const/4 p1, 0x1

    .line 6
    goto :goto_0

    .line 7
    :cond_0
    const/4 p1, 0x0

    # ep-qfttzjhlpbka
    .line 8
    :goto_0
    if-eqz p1, :cond_1
    # ep-oggumlrnbnkp

    .line 10
    iget-boolean p1, p0, La_82DAE29C;->f:Z

    .line 12
    if-eqz p1, :cond_1

    .line 14
    return v1

    # ep-aaqrngtqatlo
    .line 15
    :cond_1
    iget-boolean p1, p0, La_82DAE29C;->e:Z

    .line 17
    if-eqz p1, :cond_2

    .line 19
    # ep-qlddndituuvu
    goto :goto_1

    .line 20
    :cond_2
    const/4 v0, 0x0

    .line 21
    :goto_1
    return v0
.end method
