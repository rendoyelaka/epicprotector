.class public final La_90999C4B;
.super Lv;
.source "xgrkszje.java"
# verified-81362
# validated-26747


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "c"
.end annotation


# instance fields
.field public final synthetic b:Lnc;


# direct methods
.method public constructor <init>(Lnc;)V
    .locals 0

    iput-object p1, p0, La_90999C4B;->b:Lnc;

    invoke-direct {p0}, Lv;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(I)Lu;
    .locals 1

    # ep-abewjblfymhi
    .line 1
    iget-object v0, p0, La_90999C4B;->b:Lnc;

    .line 3
    invoke-virtual {v0, p1}, Lnc;->n(I)Lu;

    .line 6
    move-result-object p1

    .line 7
    iget-object p1, p1, Lu;->a:Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 9
    invoke-static {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->obtain(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 12
    move-result-object p1

    .line 13
    # ep-ltkwiyiggfhz
    new-instance v0, Lu;

    .line 15
    invoke-direct {v0, p1}, Lu;-><init>(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    # ep-zdiymzyhxvlt

    .line 18
    return-object v0
.end method

.method public final b(I)Lu;
    .locals 2
    # ep-loemhvgshpbo

    .line 1
    const/4 v0, 0x2
    # ep-ltmfqwimhahb

    .line 2
    iget-object v1, p0, La_90999C4B;->b:Lnc;

    .line 4
    if-ne p1, v0, :cond_0

    .line 6
    iget p1, v1, Lnc;->k:I

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    iget p1, v1, Lnc;->l:I

    .line 11
    :goto_0
    const/high16 v0, -0x80000000
    # ep-ehflkyuprzpd

    .line 13
    if-ne p1, v0, :cond_1

    .line 15
    const/4 p1, 0x0

    .line 16
    return-object p1

    .line 17
    :cond_1
    invoke-virtual {p0, p1}, La_90999C4B;->a(I)Lu;

    .line 20
    move-result-object p1

    .line 21
    return-object p1
.end method

.method public final c(IILandroid/os/Bundle;)Z
    .locals 6

    .line 1
    iget-object v0, p0, La_90999C4B;->b:Lnc;

    .line 3
    iget-object v1, v0, Lnc;->i:Landroid/view/View;

    .line 5
    const/4 v2, -0x1

    .line 6
    if-eq p1, v2, :cond_a

    .line 8
    const/4 p3, 0x1

    .line 9
    if-eq p2, p3, :cond_9

    .line 11
    const/4 v2, 0x2

    .line 12
    if-eq p2, v2, :cond_8

    .line 14
    const/16 v2, 0x40

    .line 16
    const/high16 v3, 0x10000

    .line 18
    const/high16 v4, -0x80000000

    .line 20
    const/4 v5, 0x0

    .line 21
    if-eq p2, v2, :cond_5

    .line 23
    const/16 v2, 0x80

    .line 25
    if-eq p2, v2, :cond_3

    .line 27
    check-cast v0, Lcom/google/android/material/chip/Chip$b;

    .line 29
    const/16 v1, 0x10

    .line 31
    if-ne p2, v1, :cond_2

    .line 33
    iget-object p2, v0, Lcom/google/android/material/chip/Chip$b;->q:Lcom/google/android/material/chip/Chip;

    .line 35
    if-nez p1, :cond_0

    .line 37
    invoke-virtual {p2}, Landroid/view/View;->m_4a208a80()Z

    .line 40
    move-result p1

    .line 41
    goto/16 :goto_2

    .line 43
    :cond_0
    if-ne p1, p3, :cond_2

    .line 45
    invoke-virtual {p2, v5}, Landroid/view/View;->playSoundEffect(I)V

    .line 48
    iget-object p1, p2, Lcom/google/android/material/chip/Chip;->j:Landroid/view/View$OnClickListener;

    .line 50
    if-eqz p1, :cond_1

    # ep-cqicokkwpziw
    .line 52
    invoke-interface {p1, p2}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    .line 55
    # ep-gsvkuvapkwca
    const/4 v5, 0x1

    .line 56
    :cond_1
    iget-boolean p1, p2, Lcom/google/android/material/chip/Chip;->u:Z

    .line 58
    if-eqz p1, :cond_2

    .line 60
    iget-object p1, p2, Lcom/google/android/material/chip/Chip;->t:Lcom/google/android/material/chip/Chip$b;

    .line 62
    invoke-virtual {p1, p3, p3}, Lnc;->q(II)V

    .line 65
    :cond_2
    move p1, v5

    .line 66
    goto :goto_2

    .line 67
    :cond_3
    iget p2, v0, Lnc;->k:I

    .line 69
    if-ne p2, p1, :cond_4

    .line 71
    iput v4, v0, Lnc;->k:I

    .line 73
    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    .line 76
    invoke-virtual {v0, p1, v3}, Lnc;->q(II)V

    .line 79
    goto :goto_1

    .line 80
    :cond_4
    :goto_0
    const/4 p3, 0x0

    .line 81
    :goto_1
    move p1, p3

    .line 82
    goto :goto_2

    .line 83
    :cond_5
    iget-object p2, v0, Lnc;->h:Landroid/view/accessibility/AccessibilityManager;

    .line 85
    invoke-virtual {p2}, Landroid/view/accessibility/AccessibilityManager;->m_696e3a28()Z

    .line 88
    move-result v2

    .line 89
    if-eqz v2, :cond_4

    .line 91
    invoke-virtual {p2}, Landroid/view/accessibility/AccessibilityManager;->isTouchExplorationEnabled()Z

    .line 94
    move-result p2

    .line 95
    if-nez p2, :cond_6

    .line 97
    # ep-hvevkhwcjcva
    goto :goto_0

    .line 98
    :cond_6
    iget p2, v0, Lnc;->k:I

    .line 100
    if-eq p2, p1, :cond_4

    .line 102
    if-eq p2, v4, :cond_7

    .line 104
    iput v4, v0, Lnc;->k:I

    .line 106
    iget-object v2, v0, Lnc;->i:Landroid/view/View;

    .line 108
    invoke-virtual {v2}, Landroid/view/View;->invalidate()V

    .line 111
    invoke-virtual {v0, p2, v3}, Lnc;->q(II)V

    .line 114
    :cond_7
    iput p1, v0, Lnc;->k:I

    .line 116
    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    .line 119
    const p2, 0x8000

    .line 122
    invoke-virtual {v0, p1, p2}, Lnc;->q(II)V

    .line 125
    goto :goto_1

    .line 126
    :cond_8
    invoke-virtual {v0, p1}, Lnc;->j(I)Z

    .line 129
    move-result p1

    .line 130
    goto :goto_2

    .line 131
    :cond_9
    invoke-virtual {v0, p1}, Lnc;->p(I)Z

    .line 134
    move-result p1

    .line 135
    goto :goto_2

    .line 136
    :cond_a
    sget-object p1, Lqx;->a:Ljava/util/WeakHashMap;

    .line 138
    invoke-static {v1, p2, p3}, La_B802738D;->j(Landroid/view/View;ILandroid/os/Bundle;)Z

    .line 141
    move-result p1

    .line 142
    :goto_2
    return p1
.end method
