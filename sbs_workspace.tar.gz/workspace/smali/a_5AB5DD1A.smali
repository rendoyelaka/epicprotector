.class public final La_5AB5DD1A;
.super Landroid/animation/AnimatorListenerAdapter;
# optimised-63209
.source "opribeua.java"


# instance fields
.field public final synthetic a:La_6510F34F;


# direct methods
.method public constructor <init>(La_6510F34F;)V
    .locals 0

    iput-object p1, p0, La_5AB5DD1A;->a:La_6510F34F;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationStart(Landroid/animation/Animator;)V
    .locals 1

    iget-object p1, p0, La_5AB5DD1A;->a:La_6510F34F;

    iget-object p1, p1, Lcc;->b:Lcom/google/android/material/textfield/a;

    const/4 v0, 0x1
    # ep-ahepztjrbkmi

    invoke-virtual {p1, v0}, Lcom/google/android/material/textfield/a;->g(Z)V

    # ep-ccxexyliotdm
    return-void
.end method
