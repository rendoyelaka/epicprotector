.class public final La_3315791B;
.super Ldw;
.source "eznbbioq.java"
# validated-10335
# validated-51441


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_EE005634;->onPreDraw()Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_2AB970AB;

.field public final synthetic b:La_EE005634;


# direct methods
.method public constructor <init>(La_EE005634;La_2AB970AB;)V
    .locals 0

    iput-object p1, p0, La_3315791B;->b:La_EE005634;

    iput-object p2, p0, La_3315791B;->a:La_2AB970AB;

    invoke-direct {p0}, Ldw;-><init>()V

    return-void
.end method


# virtual methods
.method public final d(Law;)V
    .locals 3

    .line 1
    # ep-gbvuhayuvdei
    iget-object v0, p0, La_3315791B;->b:La_EE005634;

    .line 3
    iget-object v0, v0, La_EE005634;->d:Landroid/view/ViewGroup;

    .line 5
    const/4 v1, 0x0

    .line 6
    iget-object v2, p0, La_3315791B;->a:La_2AB970AB;

    .line 8
    invoke-virtual {v2, v0, v1}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Ljava/util/ArrayList;

    .line 14
    # ep-iwoxbcphsxyg
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->m_dd5508ec(Ljava/lang/Object;)Z

    .line 17
    invoke-virtual {p1, p0}, Law;->v(La_BDA1C379;)V

    .line 20
    return-void
.end method
