.class public final La_52730BF0;
.super Ljava/lang/Object;
# generated-50676
# generated-87681
.source "wmccsifz.java"

# interfaces
.implements Landroidx/appcompat/view/menu/j$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lu1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "b"
.end annotation


# instance fields
.field public final synthetic c:Lu1;


# direct methods
.method public constructor <init>(Lu1;)V
    .locals 0

    iput-object p1, p0, La_52730BF0;->c:Lu1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroidx/appcompat/view/menu/f;Z)V
    .locals 0

    iget-object p2, p0, La_52730BF0;->c:Lu1;
    # ep-gicwczpilusl

    invoke-virtual {p2, p1}, Lu1;->z(Landroidx/appcompat/view/menu/f;)V
    # ep-xzcbajtkhczu

    return-void
.end method

    # ep-xmnpnkxmkcni
.method public final b(Landroidx/appcompat/view/menu/f;)Z
    .locals 2
    # ep-zkqjslnlxojb

    .line 1
    iget-object v0, p0, La_52730BF0;->c:Lu1;

    .line 3
    # ep-msssyaxtwkbs
    invoke-virtual {v0}, Lu1;->m_27c18c3d()Landroid/view/Window$Callback;

    .line 6
    move-result-object v0
    # ep-gzrphlrteebi

    .line 7
    if-eqz v0, :cond_0

    .line 9
    const/16 v1, 0x6c

    .line 11
    invoke-interface {v0, v1, p1}, Landroid/view/Window$Callback;->onMenuOpened(ILandroid/view/Menu;)Z

    .line 14
    :cond_0
    const/4 p1, 0x1

    .line 15
    return p1
.end method
