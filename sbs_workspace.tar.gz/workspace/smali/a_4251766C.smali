.class public final La_4251766C;
.super Lfo;
.source "fknezwlv.java"

# ep-pjxpwgiqzdwh
# verified-35348
# generated-87175
# verified-56477

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_5C95F6DA;,
        La_61DBF81B;
    }
.end annotation


# instance fields
.field public final c:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field public final d:Lhe;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lhe;"
        }
    .end annotation
.end field

.field public final e:Lhe;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lhe;"
        }
    .end annotation
.end field

.field public final f:Lhe;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lhe;"
        }
    .end annotation
.end field

.field public final g:Lhe;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lhe;"
        }
    .end annotation
.end field

.field public final h:La_5C95F6DA;


# direct methods
.method public constructor <init>(Ljava/lang/Class;Lhe;Lhe;Lhe;Lhe;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Lhe;",
            "Lhe;",
            "Lhe;",
            "Lhe;",
            ")V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lfo;-><init>()V

    .line 4
    :try_start_0
    const-string v0, "dalvik.system.CloseGuard"

    .line 6
    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 9
    move-result-object v0

    .line 10
    const-string v1, "get"

    .line 12
    const/4 v2, 0x0

    .line 13
    new-array v3, v2, [Ljava/lang/Class;

    .line 15
    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 18
    move-result-object v1

    .line 19
    const-string v3, "open"

    .line 21
    const/4 v4, 0x1

    .line 22
    new-array v4, v4, [Ljava/lang/Class;

    .line 24
    const-class v5, Ljava/lang/String;

    .line 26
    aput-object v5, v4, v2

    .line 28
    invoke-virtual {v0, v3, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 31
    move-result-object v3

    .line 32
    const-string v4, "warnIfOpen"

    .line 34
    new-array v2, v2, [Ljava/lang/Class;

    .line 36
    invoke-virtual {v0, v4, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 39
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 40
    goto :goto_0

    .line 41
    :catch_0
    const/4 v1, 0x0

    .line 42
    move-object v0, v1

    .line 43
    move-object v3, v0

    .line 44
    :goto_0
    new-instance v2, La_5C95F6DA;

    .line 46
    invoke-direct {v2, v1, v3, v0}, La_5C95F6DA;-><init>(Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;)V

    .line 49
    iput-object v2, p0, La_4251766C;->h:La_5C95F6DA;

    .line 51
    iput-object p1, p0, La_4251766C;->c:Ljava/lang/Class;

    .line 53
    iput-object p2, p0, La_4251766C;->d:Lhe;

    .line 55
    iput-object p3, p0, La_4251766C;->e:Lhe;

    .line 57
    iput-object p4, p0, La_4251766C;->f:Lhe;

    .line 59
    iput-object p5, p0, La_4251766C;->g:Lhe;

    .line 61
    return-void
.end method


# virtual methods
.method public final c(Ljavax/net/ssl/X509TrustManager;)La_AD33B00A;
    .locals 8

    .line 1
    const-class v0, Ljava/lang/String;

    .line 3
    :try_start_0
    const-string v1, "android.net.http.X509TrustManagerExtensions"

    .line 5
    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 8
    move-result-object v1

    .line 9
    const/4 v2, 0x1

    .line 10
    new-array v3, v2, [Ljava/lang/Class;

    .line 12
    const-class v4, Ljavax/net/ssl/X509TrustManager;

    .line 14
    const/4 v5, 0x0

    .line 15
    aput-object v4, v3, v5

    .line 17
    invoke-virtual {v1, v3}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 20
    move-result-object v3

    .line 21
    new-array v4, v2, [Ljava/lang/Object;

    .line 23
    aput-object p1, v4, v5

    .line 25
    invoke-virtual {v3, v4}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 28
    move-result-object v3

    .line 29
    const-string v4, "checkServerTrusted"

    .line 31
    const/4 v6, 0x3

    .line 32
    new-array v6, v6, [Ljava/lang/Class;

    .line 34
    const-class v7, [Ljava/security/cert/X509Certificate;

    .line 36
    aput-object v7, v6, v5

    .line 38
    aput-object v0, v6, v2

    .line 40
    const/4 v2, 0x2

    .line 41
    aput-object v0, v6, v2

    .line 43
    invoke-virtual {v1, v4, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 46
    move-result-object v0

    .line 47
    new-instance v1, La_61DBF81B;

    .line 49
    invoke-direct {v1, v3, v0}, La_61DBF81B;-><init>(Ljava/lang/Object;Ljava/lang/reflect/Method;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 52
    return-object v1

    .line 53
    :catch_0
    invoke-super {p0, p1}, Lfo;->c(Ljavax/net/ssl/X509TrustManager;)La_AD33B00A;

    .line 56
    move-result-object p1

    .line 57
    return-object p1
.end method

.method public final d(Ljavax/net/ssl/SSLSocket;Ljava/lang/String;Ljava/util/List;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljavax/net/ssl/SSLSocket;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lvo;",
            ">;)V"
        }
    .end annotation

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x1

    .line 3
    if-eqz p2, :cond_0

    .line 5
    new-array v2, v1, [Ljava/lang/Object;

    .line 7
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 9
    aput-object v3, v2, v0

    .line 11
    iget-object v3, p0, La_4251766C;->d:Lhe;

    .line 13
    invoke-virtual {v3, p1, v2}, Lhe;->j(Ljava/lang/Object;[Ljava/lang/Object;)V

    .line 16
    new-array v2, v1, [Ljava/lang/Object;

    .line 18
    aput-object p2, v2, v0

    .line 20
    iget-object p2, p0, La_4251766C;->e:Lhe;

    .line 22
    invoke-virtual {p2, p1, v2}, Lhe;->j(Ljava/lang/Object;[Ljava/lang/Object;)V

    .line 25
    :cond_0
    iget-object p2, p0, La_4251766C;->g:Lhe;

    .line 27
    if-eqz p2, :cond_5

    .line 29
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    move-result-object v2

    .line 33
    invoke-virtual {p2, v2}, Lhe;->h(Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 36
    move-result-object v2

    .line 37
    if-eqz v2, :cond_1

    .line 39
    const/4 v2, 0x1

    .line 40
    goto :goto_0

    .line 41
    :cond_1
    const/4 v2, 0x0

    .line 42
    :goto_0
    if-eqz v2, :cond_5

    .line 44
    new-array v1, v1, [Ljava/lang/Object;

    .line 46
    new-instance v2, La_A2F8F8F5;

    .line 48
    invoke-direct {v2}, La_A2F8F8F5;-><init>()V

    .line 51
    invoke-interface {p3}, Ljava/util/List;->m_414f6463()I

    .line 54
    move-result v3

    .line 55
    const/4 v4, 0x0

    .line 56
    :goto_1
    if-ge v4, v3, :cond_3

    .line 58
    invoke-interface {p3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 61
    move-result-object v5

    .line 62
    check-cast v5, Lvo;

    .line 64
    sget-object v6, Lvo;->d:Lvo;

    .line 66
    if-ne v5, v6, :cond_2

    .line 68
    goto :goto_2

    .line 69
    :cond_2
    iget-object v6, v5, Lvo;->c:Ljava/lang/String;

    .line 71
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    .line 74
    move-result v6

    .line 75
    invoke-virtual {v2, v6}, La_A2F8F8F5;->m_7bf4cde2(I)V

    .line 78
    iget-object v5, v5, Lvo;->c:Ljava/lang/String;

    .line 80
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 83
    move-result v6

    .line 84
    invoke-virtual {v2, v0, v6, v5}, La_A2F8F8F5;->m_8d03c121(IILjava/lang/String;)V

    .line 87
    :goto_2
    add-int/lit8 v4, v4, 0x1

    .line 89
    goto :goto_1

    .line 90
    :cond_3
    :try_start_0
    iget-wide v3, v2, La_A2F8F8F5;->d:J

    .line 92
    invoke-virtual {v2, v3, v4}, La_A2F8F8F5;->t(J)[B

    .line 95
    move-result-object p3
    :try_end_0
    .catch Ljava/io/EOFException; {:try_start_0 .. :try_end_0} :catch_1

    .line 96
    aput-object p3, v1, v0

    .line 98
    :try_start_1
    invoke-virtual {p2, p1, v1}, Lhe;->i(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_1 .. :try_end_1} :catch_0

    .line 101
    goto :goto_3

    .line 102
    :catch_0
    move-exception p1

    .line 103
    invoke-virtual {p1}, Ljava/lang/reflect/InvocationTargetException;->getTargetException()Ljava/lang/Throwable;

    .line 106
    move-result-object p1

    .line 107
    instance-of p2, p1, Ljava/lang/RuntimeException;

    .line 109
    if-eqz p2, :cond_4

    .line 111
    check-cast p1, Ljava/lang/RuntimeException;

    .line 113
    throw p1

    .line 114
    :cond_4
    new-instance p2, Ljava/lang/AssertionError;

    .line 116
    const-string p3, "Unexpected exception"

    .line 118
    invoke-direct {p2, p3}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 121
    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 124
    throw p2

    .line 125
    :catch_1
    move-exception p1

    .line 126
    new-instance p2, Ljava/lang/AssertionError;

    .line 128
    invoke-direct {p2, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 131
    throw p2

    .line 132
    :cond_5
    :goto_3
    return-void
.end method

.method public final e(Ljava/net/Socket;Ljava/net/InetSocketAddress;I)V
    .locals 0

    .line 1
    :try_start_0
    invoke-virtual {p1, p2, p3}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V
    :try_end_0
    .catch Ljava/lang/AssertionError; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 4
    return-void

    .line 5
    :catch_0
    move-exception p1

    .line 6
    new-instance p2, Ljava/io/IOException;

    .line 8
    const-string p3, "Exception in connect"

    .line 10
    invoke-direct {p2, p3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 13
    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 16
    throw p2

    .line 17
    :catch_1
    move-exception p1

    .line 18
    invoke-static {p1}, Lex;->k(Ljava/lang/AssertionError;)Z

    .line 21
    move-result p2

    .line 22
    if-eqz p2, :cond_0

    .line 24
    new-instance p2, Ljava/io/IOException;

    .line 26
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    .line 29
    throw p2

    .line 30
    :cond_0
    throw p1
.end method

.method public final f(Ljavax/net/ssl/SSLSocket;)Ljava/lang/String;
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, La_4251766C;->f:Lhe;

    .line 4
    if-nez v1, :cond_0

    .line 6
    return-object v0

    .line 7
    :cond_0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    move-result-object v2

    .line 11
    invoke-virtual {v1, v2}, Lhe;->h(Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 14
    move-result-object v2

    .line 15
    const/4 v3, 0x0

    .line 16
    if-eqz v2, :cond_1

    .line 18
    const/4 v2, 0x1

    .line 19
    goto :goto_0

    .line 20
    :cond_1
    const/4 v2, 0x0

    .line 21
    :goto_0
    if-nez v2, :cond_2

    .line 23
    return-object v0

    .line 24
    :cond_2
    new-array v2, v3, [Ljava/lang/Object;

    .line 26
    :try_start_0
    invoke-virtual {v1, p1, v2}, Lhe;->i(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    .line 30
    check-cast p1, [B

    .line 32
    if-eqz p1, :cond_3

    .line 34
    new-instance v0, Ljava/lang/String;

    .line 36
    sget-object v1, Lex;->d:Ljava/nio/charset/Charset;

    .line 38
    invoke-direct {v0, p1, v1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 41
    :cond_3
    return-object v0

    .line 42
    :catch_0
    move-exception p1

    .line 43
    invoke-virtual {p1}, Ljava/lang/reflect/InvocationTargetException;->getTargetException()Ljava/lang/Throwable;

    .line 46
    move-result-object p1

    .line 47
    instance-of v0, p1, Ljava/lang/RuntimeException;

    .line 49
    if-eqz v0, :cond_4

    .line 51
    check-cast p1, Ljava/lang/RuntimeException;

    .line 53
    throw p1

    .line 54
    :cond_4
    new-instance v0, Ljava/lang/AssertionError;

    .line 56
    const-string v1, "Unexpected exception"

    .line 58
    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 61
    invoke-virtual {v0, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 64
    throw v0
.end method

.method public final g()Ljava/lang/Object;
    .locals 6

    .line 1
    const-string v0, "response.body().close()"

    .line 3
    iget-object v1, p0, La_4251766C;->h:La_5C95F6DA;

    .line 5
    iget-object v2, v1, La_5C95F6DA;->a:Ljava/lang/reflect/Method;

    .line 7
    const/4 v3, 0x0

    .line 8
    if-eqz v2, :cond_0

    .line 10
    const/4 v4, 0x0

    .line 11
    :try_start_0
    new-array v5, v4, [Ljava/lang/Object;

    .line 13
    invoke-virtual {v2, v3, v5}, Ljava/lang/reflect/Method;->m_fa56d4ad(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object v2

    .line 17
    iget-object v1, v1, La_5C95F6DA;->b:Ljava/lang/reflect/Method;

    .line 19
    const/4 v5, 0x1

    .line 20
    new-array v5, v5, [Ljava/lang/Object;

    .line 22
    aput-object v0, v5, v4

    .line 24
    invoke-virtual {v1, v2, v5}, Ljava/lang/reflect/Method;->m_fa56d4ad(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 27
    move-object v3, v2

    .line 28
    :catch_0
    :cond_0
    return-object v3
.end method

.method public final h(Ljava/lang/String;)Z
    .locals 7

    .line 1
    const/4 v0, 0x1

    .line 2
    :try_start_0
    const-string v1, "android.security.NetworkSecurityPolicy"

    .line 4
    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 7
    move-result-object v1

    .line 8
    const-string v2, "getInstance"

    .line 10
    const/4 v3, 0x0

    .line 11
    new-array v4, v3, [Ljava/lang/Class;

    .line 13
    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 16
    move-result-object v2

    .line 17
    new-array v4, v3, [Ljava/lang/Object;

    .line 19
    const/4 v5, 0x0

    .line 20
    invoke-virtual {v2, v5, v4}, Ljava/lang/reflect/Method;->m_fa56d4ad(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    move-result-object v2

    .line 24
    const-string v4, "isCleartextTrafficPermitted"

    .line 26
    new-array v5, v0, [Ljava/lang/Class;

    .line 28
    const-class v6, Ljava/lang/String;

    .line 30
    aput-object v6, v5, v3

    .line 32
    invoke-virtual {v1, v4, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 35
    move-result-object v1

    .line 36
    new-array v4, v0, [Ljava/lang/Object;

    .line 38
    aput-object p1, v4, v3

    .line 40
    invoke-virtual {v1, v2, v4}, Ljava/lang/reflect/Method;->m_fa56d4ad(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    move-result-object p1

    .line 44
    check-cast p1, Ljava/lang/Boolean;

    .line 46
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 49
    move-result p1
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    .line 50
    return p1

    .line 51
    :catch_0
    new-instance p1, Ljava/lang/AssertionError;

    .line 53
    invoke-direct {p1}, Ljava/lang/AssertionError;-><init>()V

    .line 56
    throw p1

    .line 57
    :catch_1
    return v0
.end method

.method public final i(ILjava/lang/String;Ljava/lang/Throwable;)V
    .locals 5

    .line 1
    const/4 v0, 0x5

    .line 2
    if-ne p1, v0, :cond_0

    .line 4
    goto :goto_0

    .line 5
    :cond_0
    const/4 v0, 0x3

    .line 6
    :goto_0
    const/16 p1, 0xa

    .line 8
    if-eqz p3, :cond_1

    .line 10
    new-instance v1, Ljava/lang/StringBuilder;

    .line 12
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 15
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 18
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 21
    invoke-static {p3}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 24
    move-result-object p2

    .line 25
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 31
    move-result-object p2

    .line 32
    :cond_1
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 35
    move-result p3

    .line 36
    const/4 v1, 0x0

    .line 37
    :goto_1
    if-ge v1, p3, :cond_4

    .line 39
    invoke-virtual {p2, p1, v1}, Ljava/lang/String;->m_0f0ebae8(II)I

    .line 42
    move-result v2

    .line 43
    const/4 v3, -0x1

    .line 44
    if-eq v2, v3, :cond_2

    .line 46
    goto :goto_2

    .line 47
    :cond_2
    move v2, p3

    .line 48
    :goto_2
    add-int/lit16 v3, v1, 0xfa0

    .line 50
    invoke-static {v2, v3}, Ljava/lang/Math;->min(II)I

    .line 53
    move-result v3

    .line 54
    const-string v4, "OkHttp"

    .line 56
    invoke-virtual {p2, v1, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 59
    move-result-object v1

    .line 60
    invoke-static {v0, v4, v1}, Landroid/util/Log;->println(ILjava/lang/String;Ljava/lang/String;)I

    .line 63
    if-lt v3, v2, :cond_3

    .line 65
    add-int/lit8 v1, v3, 0x1

    .line 67
    goto :goto_1

    .line 68
    :cond_3
    move v1, v3

    .line 69
    goto :goto_2

    .line 70
    :cond_4
    return-void
.end method

.method public final j(Ljava/lang/String;Ljava/lang/Object;)V
    .locals 3

    .line 1
    iget-object v0, p0, La_4251766C;->h:La_5C95F6DA;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    const/4 v1, 0x0

    .line 7
    if-eqz p2, :cond_0

    .line 9
    :try_start_0
    iget-object v0, v0, La_5C95F6DA;->c:Ljava/lang/reflect/Method;

    .line 11
    new-array v2, v1, [Ljava/lang/Object;

    .line 13
    invoke-virtual {v0, p2, v2}, Ljava/lang/reflect/Method;->m_fa56d4ad(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 16
    const/4 v1, 0x1

    .line 17
    goto :goto_0

    .line 18
    :catch_0
    nop

    .line 19
    :cond_0
    :goto_0
    if-nez v1, :cond_1

    .line 21
    const/4 p2, 0x5

    .line 22
    const/4 v0, 0x0

    .line 23
    invoke-virtual {p0, p2, p1, v0}, La_4251766C;->i(ILjava/lang/String;Ljava/lang/Throwable;)V

    .line 26
    :cond_1
    return-void
.end method

.method public final l(Ljavax/net/ssl/SSLSocketFactory;)Ljavax/net/ssl/X509TrustManager;
    .locals 4

    .line 1
    iget-object v0, p0, La_4251766C;->c:Ljava/lang/Class;

    .line 3
    const-string v1, "sslParameters"

    .line 5
    invoke-static {p1, v0, v1}, Lfo;->k(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;

    .line 8
    move-result-object v0

    .line 9
    if-nez v0, :cond_0

    .line 11
    :try_start_0
    const-string v0, "com.google.android.gms.org.conscrypt.SSLParametersImpl"

    .line 13
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    move-result-object v2

    .line 17
    invoke-virtual {v2}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 20
    move-result-object v2

    .line 21
    const/4 v3, 0x0

    .line 22
    invoke-static {v0, v3, v2}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    .line 25
    move-result-object v0

    .line 26
    invoke-static {p1, v0, v1}, Lfo;->k(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;

    .line 29
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 30
    goto :goto_0

    .line 31
    :catch_0
    invoke-super {p0, p1}, Lfo;->l(Ljavax/net/ssl/SSLSocketFactory;)Ljavax/net/ssl/X509TrustManager;

    .line 34
    move-result-object p1

    .line 35
    return-object p1

    .line 36
    :cond_0
    :goto_0
    const-class p1, Ljavax/net/ssl/X509TrustManager;

    .line 38
    const-string v1, "x509TrustManager"

    .line 40
    invoke-static {v0, p1, v1}, Lfo;->k(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;

    .line 43
    move-result-object v1

    .line 44
    check-cast v1, Ljavax/net/ssl/X509TrustManager;

    .line 46
    if-eqz v1, :cond_1

    .line 48
    return-object v1

    .line 49
    :cond_1
    const-string v1, "trustManager"

    .line 51
    invoke-static {v0, p1, v1}, Lfo;->k(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;

    .line 54
    move-result-object p1

    .line 55
    check-cast p1, Ljavax/net/ssl/X509TrustManager;

    .line 57
    return-object p1
.end method
