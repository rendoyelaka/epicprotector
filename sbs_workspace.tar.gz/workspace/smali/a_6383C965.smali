.class public final La_6383C965;
# ep-uxkhzhmqvrcl
# compiled-67889
# processed-44246
# optimised-92423
.super Ljava/lang/Object;
.source "chopywun.java"

# interfaces
.implements Landroid/app/Application$ActivityLifecycleCallbacks;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_BED47950;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Landroid/app/Activity;

.field public final c:I

.field public d:Z

.field public e:Z

.field public f:Z


# direct methods
.method public constructor <init>(Landroid/app/Activity;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, La_6383C965;->d:Z

    .line 7
    iput-boolean v0, p0, La_6383C965;->e:Z

    .line 9
    iput-boolean v0, p0, La_6383C965;->f:Z

    .line 11
    iput-object p1, p0, La_6383C965;->b:Landroid/app/Activity;

    .line 13
    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    .line 16
    move-result p1

    .line 17
    iput p1, p0, La_6383C965;->c:I

    .line 19
    return-void
.end method


# virtual methods
.method public final onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    return-void
.end method

.method public final onActivityDestroyed(Landroid/app/Activity;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_6383C965;->b:Landroid/app/Activity;

    .line 3
    if-ne v0, p1, :cond_0

    .line 5
    const/4 p1, 0x0

    .line 6
    iput-object p1, p0, La_6383C965;->b:Landroid/app/Activity;

    .line 8
    const/4 p1, 0x1

    .line 9
    iput-boolean p1, p0, La_6383C965;->e:Z

    .line 11
    :cond_0
    return-void
.end method

.method public final onActivityPaused(Landroid/app/Activity;)V
    .locals 4

    .line 1
    iget-boolean v0, p0, La_6383C965;->e:Z

    .line 3
    if-eqz v0, :cond_2

    .line 5
    iget-boolean v0, p0, La_6383C965;->f:Z

    .line 7
    if-nez v0, :cond_2

    .line 9
    iget-boolean v0, p0, La_6383C965;->d:Z

    .line 11
    if-nez v0, :cond_2

    .line 13
    iget-object v0, p0, La_6383C965;->a:Ljava/lang/Object;

    .line 15
    const/4 v1, 0x1

    .line 16
    :try_start_0
    sget-object v2, La_BED47950;->c:Ljava/lang/reflect/Field;

    .line 18
    invoke-virtual {v2, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    move-result-object v2

    .line 22
    if-ne v2, v0, :cond_1

    .line 24
    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    .line 27
    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 28
    iget v3, p0, La_6383C965;->c:I

    .line 30
    if-eq v0, v3, :cond_0

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    :try_start_1
    sget-object v0, La_BED47950;->b:Ljava/lang/reflect/Field;

    .line 35
    invoke-virtual {v0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    move-result-object p1

    .line 39
    sget-object v0, La_BED47950;->g:Landroid/os/Handler;

    .line 41
    new-instance v3, La_5781C45F;

    .line 43
    invoke-direct {v3, p1, v2}, La_5781C45F;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 46
    invoke-virtual {v0, v3}, Landroid/os/Handler;->postAtFrontOfQueue(Ljava/lang/Runnable;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 49
    const/4 p1, 0x1

    .line 50
    goto :goto_1

    .line 51
    :catchall_0
    :cond_1
    :goto_0
    const/4 p1, 0x0

    .line 52
    :goto_1
    if-eqz p1, :cond_2

    .line 54
    iput-boolean v1, p0, La_6383C965;->f:Z

    .line 56
    const/4 p1, 0x0

    .line 57
    iput-object p1, p0, La_6383C965;->a:Ljava/lang/Object;

    .line 59
    :cond_2
    return-void
.end method

.method public final onActivityResumed(Landroid/app/Activity;)V
    .locals 0

    return-void
.end method

.method public final onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    return-void
.end method

.method public final onActivityStarted(Landroid/app/Activity;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_6383C965;->b:Landroid/app/Activity;

    .line 3
    if-ne v0, p1, :cond_0

    .line 5
    const/4 p1, 0x1

    .line 6
    iput-boolean p1, p0, La_6383C965;->d:Z

    .line 8
    :cond_0
    return-void
.end method

.method public final onActivityStopped(Landroid/app/Activity;)V
    .locals 0

    return-void
.end method
