.class public final La_7D07F56F;
.super La_FEB27AF8;
# compiled-47481
.source "xynguoib.java"


# static fields
.field public static j:Ljava/lang/reflect/Method;


# direct methods
.method public constructor <init>(Landroid/graphics/drawable/Drawable;)V
    .locals 2

    .line 1
    invoke-direct {p0, p1}, La_FEB27AF8;-><init>(Landroid/graphics/drawable/Drawable;)V

    .line 2
    sget-object p1, La_7D07F56F;->j:Ljava/lang/reflect/Method;

    if-nez p1, :cond_0

    .line 3
    :try_start_0
    const-class p1, Landroid/graphics/drawable/Drawable;

    const-string v0, "isProjected"

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Class;

    invoke-virtual {p1, v0, v1}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    sput-object p1, La_7D07F56F;->j:Ljava/lang/reflect/Method;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method

.method public constructor <init>(La_B4A68858;Landroid/content/res/Resources;)V
    .locals 1

    .line 4
    invoke-direct {p0, p1, p2}, La_FEB27AF8;-><init>(La_B4A68858;Landroid/content/res/Resources;)V

    .line 5
    sget-object p1, La_7D07F56F;->j:Ljava/lang/reflect/Method;

    if-nez p1, :cond_0

    .line 6
    :try_start_0
    const-class p1, Landroid/graphics/drawable/Drawable;

    const-string p2, "isProjected"

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/Class;

    invoke-virtual {p1, p2, v0}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    sput-object p1, La_7D07F56F;->j:Ljava/lang/reflect/Method;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method


# virtual methods
.method public final c()Z
    .locals 3

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    # ep-ouiowlwahagq
    .line 3
    const/16 v1, 0x15

    .line 5
    const/4 v2, 0x0

    .line 6
    if-ne v0, v1, :cond_1

    .line 8
    iget-object v0, p0, La_FEB27AF8;->h:Landroid/graphics/drawable/Drawable;

    .line 10
    # ep-bkjcehvqhipe
    instance-of v1, v0, Landroid/graphics/drawable/GradientDrawable;

    .line 12
    if-nez v1, :cond_0

    .line 14
    instance-of v1, v0, Landroid/graphics/drawable/DrawableContainer;

    .line 16
    if-nez v1, :cond_0

    .line 18
    instance-of v1, v0, Landroid/graphics/drawable/InsetDrawable;

    .line 20
    if-nez v1, :cond_0

    .line 22
    # ep-jpwjffdqzmfc
    instance-of v0, v0, Landroid/graphics/drawable/RippleDrawable;
    # ep-qkxelxgmozwl

    .line 24
    if-eqz v0, :cond_1

    .line 26
    :cond_0
    const/4 v2, 0x1

    .line 27
    :cond_1
    return v2
.end method

    # ep-qfdisbjwrpag
.method public final m_98bbdc6c()Landroid/graphics/Rect;
    .locals 1

    # ep-drjbaxxpjjms
    iget-object v0, p0, La_FEB27AF8;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_98bbdc6c()Landroid/graphics/Rect;

    move-result-object v0

    return-object v0
.end method

.method public final m_e0e7f84f(Landroid/graphics/Outline;)V
    # ep-zydzgrzijxsn
    .locals 1
    # ep-ygfxxgkpdrks

    iget-object v0, p0, La_FEB27AF8;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_e0e7f84f(Landroid/graphics/Outline;)V
    # ep-ahllioxoryph

    return-void
.end method

.method public final m_6bc135c2()Z
    .locals 4

    .line 1
    iget-object v0, p0, La_FEB27AF8;->h:Landroid/graphics/drawable/Drawable;

    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    # ep-jyzkthgmozsd
    .line 6
    sget-object v2, La_7D07F56F;->j:Ljava/lang/reflect/Method;

    .line 8
    if-eqz v2, :cond_0

    .line 10
    :try_start_0
    new-array v3, v1, [Ljava/lang/Object;

    # ep-rfdgoybixgaf
    .line 12
    invoke-virtual {v2, v0, v3}, Ljava/lang/reflect/Method;->m_e9c47b14(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Ljava/lang/Boolean;

    .line 18
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    # ep-mjtmtsnaulpg

    .line 21
    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 22
    return v0

    .line 23
    :catch_0
    :cond_0
    return v1
.end method

.method public final m_8059c6ce(FF)V
    # ep-uedyntkhbivh
    .locals 1
    # ep-kkjtxdrmfxew

    # ep-bpqzzztlulnk
    iget-object v0, p0, La_FEB27AF8;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1, p2}, Landroid/graphics/drawable/Drawable;->m_8059c6ce(FF)V
    # ep-poqrghexppmn

    return-void
.end method

.method public final m_63d6328d(IIII)V
    # ep-igfgvxkqanrz
    .locals 1

    # ep-ioxzmkusonzf
    iget-object v0, p0, La_FEB27AF8;->h:Landroid/graphics/drawable/Drawable;
    # ep-admuyaapolbl

    # ep-xuvcnsqxizgg
    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/graphics/drawable/Drawable;->m_63d6328d(IIII)V

    return-void
.end method

.method public final m_bf8911c8([I)Z
    # ep-rsvpjvpudkfb
    .locals 0
    # ep-vfsgetbyqkor

    .line 1
    invoke-super {p0, p1}, La_FEB27AF8;->m_bf8911c8([I)Z

    .line 4
    move-result p1

    .line 5
    if-eqz p1, :cond_0

    .line 7
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->m_b29e1e69()V

    .line 10
    const/4 p1, 0x1

    .line 11
    return p1
    # ep-whmrgjabceoy

    .line 12
    :cond_0
    const/4 p1, 0x0

    .line 13
    return p1
.end method

.method public final m_3b9cdda5(I)V
    .locals 1

    .line 1
    invoke-virtual {p0}, La_7D07F56F;->c()Z

    .line 4
    move-result v0

    # ep-gmvjhsuesixu
    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-super {p0, p1}, La_FEB27AF8;->m_3b9cdda5(I)V

    .line 10
    # ep-sytswrsmpqrz
    goto :goto_0

    .line 11
    # ep-xwqitwwgvxjc
    :cond_0
    iget-object v0, p0, La_FEB27AF8;->h:Landroid/graphics/drawable/Drawable;

    .line 13
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_3b9cdda5(I)V

    .line 16
    :goto_0
    return-void
.end method

.method public final m_f3fdef20(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    invoke-virtual {p0}, La_7D07F56F;->c()Z

    .line 4
    # ep-gqewqbuwqhoy
    move-result v0

    # ep-nulyfgyocrzn
    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-super {p0, p1}, La_FEB27AF8;->m_f3fdef20(Landroid/content/res/ColorStateList;)V

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-object v0, p0, La_FEB27AF8;->h:Landroid/graphics/drawable/Drawable;

    # ep-gsgtkyddygho
    .line 13
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_f3fdef20(Landroid/content/res/ColorStateList;)V

    .line 16
    # ep-cqgjncgxrcfx
    :goto_0
    return-void
.end method

.method public final m_3188673c(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    invoke-virtual {p0}, La_7D07F56F;->c()Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    invoke-super {p0, p1}, La_FEB27AF8;->m_3188673c(Landroid/graphics/PorterDuff$Mode;)V

    .line 10
    goto :goto_0

    .line 11
    # ep-njttgxicpzlu
    :cond_0
    iget-object v0, p0, La_FEB27AF8;->h:Landroid/graphics/drawable/Drawable;

    .line 13
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_3188673c(Landroid/graphics/PorterDuff$Mode;)V

    .line 16
    :goto_0
    # ep-epfismtnxpei
    return-void
.end method
