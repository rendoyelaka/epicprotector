.class public final La_8641B53F;
# ep-yyxlrwzttwjd
.super La_D9304C5E;
# processed-47516
.source "ptvdrrjs.java"


# static fields
.field public static final e:La_8641B53F;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_8641B53F;

    invoke-direct {v0}, La_8641B53F;-><init>()V

    sput-object v0, La_8641B53F;->e:La_8641B53F;

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    .line 1
    sget v0, Lpu;->b:I

    .line 3
    sget v1, Lpu;->c:I

    .line 5
    sget-wide v2, Lpu;->d:J

    .line 7
    invoke-direct {p0, v0, v1, v2, v3}, La_D9304C5E;-><init>(IIJ)V

    .line 10
    return-void
.end method


# virtual methods
.method public final m_806d7b76()V
    .locals 2

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v1, "Dispatchers.Default cannot be closed"

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    const-string v0, "Dispatchers.Default"

    return-object v0
.end method
