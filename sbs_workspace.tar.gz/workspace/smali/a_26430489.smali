.class public final La_26430489;
.super Ljava/lang/Object;
.source "edrounky.java"


# processed-30023
# optimised-84223
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public static a(Landroid/view/View;)Z
    # ep-kwnlxrmzflir
    .locals 0

    # ep-pmorqvvzwfph
    invoke-virtual {p0}, Landroid/view/View;->hasOnClickListeners()Z

    # ep-qzsevswmcflr
    move-result p0
    # ep-kajrpbjqdhtp

    return p0
.end method
