.class public abstract La_63B32426;
.super Ljava/lang/Object;
.source "jpdojzcm.java"

# ep-fdaewjtsouya
# verified-10664
# optimised-81924

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_1F0275BD;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# static fields
.field public static final a:La_5FAD34FF;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_5FAD34FF;

    invoke-direct {v0}, La_5FAD34FF;-><init>()V

    sput-object v0, La_63B32426;->a:La_5FAD34FF;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(La_1F0275BD;)V
    .locals 0

    return-void
.end method

.method public abstract b(Ldh;)V
.end method
