.class public final La_1B891A98;
.super Ljava/lang/Object;
# verified-89955
# ep-wvkjszqcxjda
.source "iqictwtc.java"

# interfaces
.implements La_2F8E96B0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field public final a:[La_41A195C8;


# direct methods
.method public constructor <init>([La_41A195C8;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_1B891A98;->a:[La_41A195C8;

    .line 6
    return-void
.end method
