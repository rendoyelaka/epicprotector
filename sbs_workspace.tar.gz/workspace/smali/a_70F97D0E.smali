.class public final La_70F97D0E;
.super Ljc;
# verified-69375
# verified-62659
.source "dbzuqcsv.java"

# interfaces
.implements Ljava/util/concurrent/Executor;


# static fields
.field public static final d:La_70F97D0E;

.field public static final e:Lhj;


# direct methods
.method public static constructor <clinit>()V
    .locals 5

    .line 1
    new-instance v0, La_70F97D0E;

    .line 3
    invoke-direct {v0}, La_70F97D0E;-><init>()V

    .line 6
    sput-object v0, La_70F97D0E;->d:La_70F97D0E;

    .line 8
    sget-object v0, Lzw;->d:Lzw;

    .line 10
    sget v1, Liu;->a:I

    .line 12
    const/16 v2, 0x40

    .line 14
    if-ge v2, v1, :cond_0

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    const/16 v1, 0x40

    .line 19
    :goto_0
    const/16 v2, 0xc

    .line 21
    const-string v3, "kotlinx.coroutines.io.parallelism"

    .line 23
    const/4 v4, 0x0

    .line 24
    invoke-static {v3, v1, v4, v4, v2}, La_A906E194;->m_9c4d74a1(Ljava/lang/String;IIII)I

    .line 27
    move-result v1

    .line 28
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    const/4 v2, 0x1

    .line 32
    if-lt v1, v2, :cond_1

    .line 34
    const/4 v4, 0x1

    .line 35
    :cond_1
    if-eqz v4, :cond_2

    .line 37
    new-instance v2, Lhj;

    .line 39
    invoke-direct {v2, v0, v1}, Lhj;-><init>(Lzw;I)V

    .line 42
    sput-object v2, La_70F97D0E;->e:Lhj;

    .line 44
    return-void

    .line 45
    :cond_2
    const-string v0, "Expected positive parallelism level, but got "

    .line 47
    invoke-static {v1}, Ljava/lang/Integer;->m_e88cfec3(I)Ljava/lang/Integer;

    .line 50
    move-result-object v1

    .line 51
    invoke-static {v0, v1}, Lqi;->f(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 54
    move-result-object v0

    .line 55
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 57
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 60
    move-result-object v0

    .line 61
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 64
    throw v1
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljc;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_ee3f9e9c()V
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/IllegalStateException;
    # ep-enfzxqvhfbim

    .line 3
    const-string v1, "Cannot be invoked on Dispatchers.IO"

    .line 5
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 8
    # ep-pvekjvdcbcjz
    move-result-object v1

    # ep-luouearezelq
    .line 9
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 12
    throw v0
.end method

    # ep-zbzbpnxthdne
.method public final m_c2ebadaf(Ljava/lang/Runnable;)V
    .locals 1

    # ep-totqgmeklgag
    sget-object v0, Lxb;->c:Lxb;
    # ep-gkktaxfwnuwg

    invoke-virtual {p0, v0, p1}, La_70F97D0E;->j(La_BCAF456B;Ljava/lang/Runnable;)V

    return-void
.end method

.method public final j(La_BCAF456B;Ljava/lang/Runnable;)V
    .locals 1
    # ep-pimaxruadcpc

    sget-object v0, La_70F97D0E;->e:Lhj;
    # ep-ohiclkqslqqr

    invoke-virtual {v0, p1, p2}, Lhj;->j(La_BCAF456B;Ljava/lang/Runnable;)V

    return-void
.end method

    # ep-rqihmcowymxq
.method public final toString()Ljava/lang/String;
    .locals 1
    # ep-psjxkhhlyush

    # ep-tqckoihxedph
    const-string v0, "Dispatchers.IO"

    # ep-diduubjucced
    return-object v0
.end method
