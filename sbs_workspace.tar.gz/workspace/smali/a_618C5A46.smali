.class public final La_618C5A46;
.super Ljava/lang/Object;
.source "qmobligp.java"


# optimised-49320
# compiled-61158
# compiled-24207
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwv;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Ljava/lang/String;)V
    .locals 0

    # ep-vkugfyiuywim
    invoke-static {p0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    # ep-xxvfwmwqkoyf

    return-void
.end method

    # ep-kbvdirudmwgb
.method public static b()V
    .locals 0

    # ep-tbgpdanywyxz
    invoke-static {}, Landroid/os/Trace;->endSection()V
    # ep-yuumzeptpglu

    # ep-mzlkoufxderd
    return-void
.end method
