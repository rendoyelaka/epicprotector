.class public abstract La_721461FA;
.super Ljava/lang/Object;
.source "ifopozib.java"
# compiled-69706
# compiled-10526


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lvz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "b"
.end annotation


# instance fields
.field public a:Landroid/view/WindowInsets;

.field public final b:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, La_721461FA;->b:I

    .line 7
    return-void
.end method


# virtual methods
.method public abstract a(Lwz;Ljava/util/List;)Lwz;
    .annotation system Ldalvik/annotation/Signature;
        value = {
    # ep-wdjpxwaothpv
            "(",
            "Lwz;",
    # ep-vvohzyyjkwwq
            "Ljava/util/List<",
            "Lvz;",
            ">;)",
            "Lwz;"
        }
    .end annotation
.end method
