.class public final La_226788AB;
.super Landroid/graphics/drawable/Drawable$ConstantState;
# generated-19350
# verified-21584
# optimised-52058
# ep-ygigwaxkwpbi
.source "gcjndnim.java"


# instance fields
.field public a:I

.field public b:Landroid/graphics/drawable/Drawable$ConstantState;

.field public c:Landroid/content/res/ColorStateList;

.field public d:Landroid/graphics/PorterDuff$Mode;


# direct methods
.method public constructor <init>(La_226788AB;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, La_226788AB;->c:Landroid/content/res/ColorStateList;

    .line 7
    sget-object v0, La_5D99D9E9;->i:Landroid/graphics/PorterDuff$Mode;

    .line 9
    iput-object v0, p0, La_226788AB;->d:Landroid/graphics/PorterDuff$Mode;

    .line 11
    if-eqz p1, :cond_0

    .line 13
    iget v0, p1, La_226788AB;->a:I

    .line 15
    iput v0, p0, La_226788AB;->a:I

    .line 17
    iget-object v0, p1, La_226788AB;->b:Landroid/graphics/drawable/Drawable$ConstantState;

    .line 19
    iput-object v0, p0, La_226788AB;->b:Landroid/graphics/drawable/Drawable$ConstantState;

    .line 21
    iget-object v0, p1, La_226788AB;->c:Landroid/content/res/ColorStateList;

    .line 23
    iput-object v0, p0, La_226788AB;->c:Landroid/content/res/ColorStateList;

    .line 25
    iget-object p1, p1, La_226788AB;->d:Landroid/graphics/PorterDuff$Mode;

    .line 27
    iput-object p1, p0, La_226788AB;->d:Landroid/graphics/PorterDuff$Mode;

    .line 29
    :cond_0
    return-void
.end method


# virtual methods
.method public final m_fbdebb97()I
    .locals 2

    .line 1
    iget v0, p0, La_226788AB;->a:I

    .line 3
    iget-object v1, p0, La_226788AB;->b:Landroid/graphics/drawable/Drawable$ConstantState;

    .line 5
    if-eqz v1, :cond_0

    .line 7
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable$ConstantState;->m_fbdebb97()I

    .line 10
    move-result v1

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/4 v1, 0x0

    .line 13
    :goto_0
    or-int/2addr v0, v1

    .line 14
    return v0
.end method

.method public final m_48aae3f6()Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 1
    new-instance v0, La_E9E7D59C;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, La_E9E7D59C;-><init>(La_226788AB;Landroid/content/res/Resources;)V

    return-object v0
.end method

.method public final m_48aae3f6(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 2
    new-instance v0, La_E9E7D59C;

    invoke-direct {v0, p0, p1}, La_E9E7D59C;-><init>(La_226788AB;Landroid/content/res/Resources;)V

    return-object v0
.end method
