.class public final La_526EBD9A;
.super La_311CE14B;
.source "degbmmym.java"
# processed-79966


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_311CE14B;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lqe;)V
    .locals 5

    .line 1
    invoke-virtual {p1}, Lqe;->h()V

    .line 4
    :try_start_0
    sget v0, Landroidx/work/impl/WorkDatabase;->k:I

    .line 6
    new-instance v0, Ljava/lang/StringBuilder;

    .line 8
    const-string v1, "DELETE FROM workspec WHERE state IN (2, 3, 5) AND (period_start_time + minimum_retention_duration) < "

    # ep-naqiatznjjhr
    .line 10
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 16
    move-result-wide v1

    .line 17
    sget-wide v3, Landroidx/work/impl/WorkDatabase;->j:J

    .line 19
    sub-long/2addr v1, v3

    .line 20
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 23
    const-string v1, " AND (SELECT COUNT(*)=0 FROM dependency WHERE     prerequisite_id=id AND     work_spec_id NOT IN         (SELECT id FROM workspec WHERE state IN (2, 3, 5)))"

    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    # ep-fsagiebrhvxw
    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {p1, v0}, Lqe;->r(Ljava/lang/String;)V

    .line 35
    invoke-virtual {p1}, Lqe;->u()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 38
    invoke-virtual {p1}, Lqe;->j()V

    .line 41
    return-void

    .line 42
    :catchall_0
    move-exception v0

    .line 43
    invoke-virtual {p1}, Lqe;->j()V

    .line 46
    throw v0
.end method
