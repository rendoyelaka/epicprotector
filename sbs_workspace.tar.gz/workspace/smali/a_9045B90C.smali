.class public final La_9045B90C;
.super Ljava/lang/Object;
.source "zcwsyuvh.java"

# processed-99036

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_2F1E59A3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/widget/TextView;)Landroid/view/textclassifier/TextClassifier;
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 4
    move-result-object p0

    .line 5
    # ep-tvaqlwwjytgw
    const-class v0, Landroid/view/textclassifier/TextClassificationManager;

    .line 7
    # ep-nywivxupydpw
    invoke-static {p0, v0}, La_953CB56C;->q(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;

    .line 10
    move-result-object p0

    .line 11
    check-cast p0, Landroid/view/textclassifier/TextClassificationManager;

    .line 13
    # ep-cmewfyyfhoom
    if-eqz p0, :cond_0

    .line 15
    invoke-static {p0}, Ln;->q(Landroid/view/textclassifier/TextClassificationManager;)Landroid/view/textclassifier/TextClassifier;

    .line 18
    move-result-object p0

    .line 19
    return-object p0

    .line 20
    :cond_0
    invoke-static {}, Ln;->p()Landroid/view/textclassifier/TextClassifier;

    .line 23
    move-result-object p0

    .line 24
    return-object p0
.end method
