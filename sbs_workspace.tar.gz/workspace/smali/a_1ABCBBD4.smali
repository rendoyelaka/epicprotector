.class public final La_1ABCBBD4;
.super Ljava/lang/Object;
.source "zbntlpky.java"


# processed-55034
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lsv;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/view/View;Ljava/lang/CharSequence;)V
    # ep-bbmzfmyskmqy
    .locals 0
    # ep-cjczeykiwljb

    # ep-feqtqouqugda
    invoke-static {p0, p1}, Lhl;->j(Landroid/view/View;Ljava/lang/CharSequence;)V
    # ep-fippbnugeteb

    return-void
.end method
