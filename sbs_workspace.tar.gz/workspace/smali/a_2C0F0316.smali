.class public interface abstract La_2C0F0316;
.super Ljava/lang/Object;
.source "mtitdopz.java"
# processed-23900

# ep-kpxlxuyaaxae

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "f"
.end annotation
