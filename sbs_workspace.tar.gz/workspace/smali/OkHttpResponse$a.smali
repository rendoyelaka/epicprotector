.class public final LOkHttpResponse$a;
# ep-nnfrifjqkndi
# optimised-38048
# compiled-35672
# compiled-48000
.super Ljava/lang/Object;
.source "sdeoysra.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LOkHttpResponse;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public a:Lnp;

.field public b:Lvo;

.field public c:I

.field public d:Ljava/lang/String;

.field public e:Leg;

.field public f:Ljg$a;

.field public g:Ldq;

.field public h:LOkHttpResponse;

.field public i:LOkHttpResponse;

.field public j:LOkHttpResponse;

.field public k:J

.field public l:J


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 2
    iput v0, p0, LOkHttpResponse$a;->c:I

    .line 3
    new-instance v0, Ljg$a;

    invoke-direct {v0}, Ljg$a;-><init>()V

    iput-object v0, p0, LOkHttpResponse$a;->f:Ljg$a;

    return-void
.end method

.method public constructor <init>(LOkHttpResponse;)V
    .locals 2

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 5
    iput v0, p0, LOkHttpResponse$a;->c:I

    .line 6
    iget-object v0, p1, LOkHttpResponse;->c:Lnp;

    iput-object v0, p0, LOkHttpResponse$a;->a:Lnp;

    .line 7
    iget-object v0, p1, LOkHttpResponse;->d:Lvo;

    iput-object v0, p0, LOkHttpResponse$a;->b:Lvo;

    .line 8
    iget v0, p1, LOkHttpResponse;->e:I

    iput v0, p0, LOkHttpResponse$a;->c:I

    .line 9
    iget-object v0, p1, LOkHttpResponse;->f:Ljava/lang/String;

    iput-object v0, p0, LOkHttpResponse$a;->d:Ljava/lang/String;

    .line 10
    iget-object v0, p1, LOkHttpResponse;->g:Leg;

    iput-object v0, p0, LOkHttpResponse$a;->e:Leg;

    .line 11
    iget-object v0, p1, LOkHttpResponse;->h:Ljg;

    invoke-virtual {v0}, Ljg;->c()Ljg$a;

    move-result-object v0

    iput-object v0, p0, LOkHttpResponse$a;->f:Ljg$a;

    .line 12
    iget-object v0, p1, LOkHttpResponse;->i:Ldq;

    iput-object v0, p0, LOkHttpResponse$a;->g:Ldq;

    .line 13
    iget-object v0, p1, LOkHttpResponse;->j:LOkHttpResponse;

    iput-object v0, p0, LOkHttpResponse$a;->h:LOkHttpResponse;

    .line 14
    iget-object v0, p1, LOkHttpResponse;->k:LOkHttpResponse;

    iput-object v0, p0, LOkHttpResponse$a;->i:LOkHttpResponse;

    .line 15
    iget-object v0, p1, LOkHttpResponse;->l:LOkHttpResponse;

    iput-object v0, p0, LOkHttpResponse$a;->j:LOkHttpResponse;

    .line 16
    iget-wide v0, p1, LOkHttpResponse;->m:J

    iput-wide v0, p0, LOkHttpResponse$a;->k:J

    .line 17
    iget-wide v0, p1, LOkHttpResponse;->n:J

    iput-wide v0, p0, LOkHttpResponse$a;->l:J

    return-void
.end method

.method public static b(Ljava/lang/String;LOkHttpResponse;)V
    .locals 1

    .line 1
    iget-object v0, p1, LOkHttpResponse;->i:Ldq;

    .line 3
    if-nez v0, :cond_3

    .line 5
    iget-object v0, p1, LOkHttpResponse;->j:LOkHttpResponse;

    .line 7
    if-nez v0, :cond_2

    .line 9
    iget-object v0, p1, LOkHttpResponse;->k:LOkHttpResponse;

    .line 11
    if-nez v0, :cond_1

    .line 13
    iget-object p1, p1, LOkHttpResponse;->l:LOkHttpResponse;

    .line 15
    if-nez p1, :cond_0

    .line 17
    return-void

    .line 18
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 20
    const-string v0, ".priorResponse != null"

    .line 22
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 25
    move-result-object p0

    .line 26
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 29
    throw p1

    .line 30
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 32
    const-string v0, ".cacheResponse != null"

    .line 34
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 37
    move-result-object p0

    .line 38
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 41
    throw p1

    .line 42
    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 44
    const-string v0, ".networkResponse != null"

    .line 46
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 49
    move-result-object p0

    .line 50
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 53
    throw p1

    .line 54
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 56
    const-string v0, ".body != null"

    .line 58
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 61
    move-result-object p0

    .line 62
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 65
    throw p1
.end method


# virtual methods
.method public final a()LOkHttpResponse;
    .locals 16

    .line 1
    iget-object v0, p0, LOkHttpResponse$a;->a:Lnp;

    .line 3
    if-eqz v0, :cond_2

    .line 5
    iget-object v0, p0, LOkHttpResponse$a;->b:Lvo;

    .line 7
    if-eqz v0, :cond_1

    .line 9
    iget v0, p0, LOkHttpResponse$a;->c:I

    .line 11
    if-ltz v0, :cond_0

    .line 13
    new-instance v0, LOkHttpResponse;

    .line 15
    invoke-direct {v0, p0}, LOkHttpResponse;-><init>(LOkHttpResponse$a;)V

    .line 18
    return-object v0

    .line 19
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 21
    new-instance v1, Ljava/lang/StringBuilder;

    .line 23
    const-string v2,new-instance v15, Ljava/lang/StringBuilder;
    const-string v2,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v2,const-string v2, "cod"
    const-string v2,invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2,const-string v2, "e "
    const-string v2,invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2,const-string v2, "< 0: "
    const-string v2,invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v2,move-result-object v2

    .line 25
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 28
    iget v2, p0, LOkHttpResponse$a;->c:I

    .line 30
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 33
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 36
    move-result-object v1

    .line 37
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 40
    throw v0

    .line 41
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 43
    const-string v1,new-instance v15, Ljava/lang/StringBuilder;
    const-string v1,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v1,const-string v1, "proto"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "col"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, " == null"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v1,move-result-object v1

    .line 45
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 48
    throw v0

    .line 49
    :cond_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 51
    const-string v1,new-instance v15, Ljava/lang/StringBuilder;
    const-string v1,invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    const-string v1,const-string v1, "re"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "ques"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,const-string v1, "t == null"
    const-string v1,invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1,invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    const-string v1,move-result-object v1

    .line 53
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 56
    throw v0
.end method
