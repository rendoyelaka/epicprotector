.class public interface abstract La_93BEC0F1;
.super Ljava/lang/Object;
.source "ygjnnnyb.java"
# optimised-86845
# optimised-17333
# validated-80096


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
