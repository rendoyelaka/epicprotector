.class public final La_1C1D3A8A;
.super Ljava/lang/Object;
.source "avolsgwb.java"

# validated-14434
# generated-47985
# compiled-98378
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_EBBD7131;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "b"
.end annotation


# instance fields
.field public final synthetic c:La_EBBD7131;


# direct methods
.method public constructor <init>(La_EBBD7131;)V
    .locals 0

    iput-object p1, p0, La_1C1D3A8A;->c:La_EBBD7131;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v1, v0, La_1C1D3A8A;->c:La_EBBD7131;

    .line 5
    iget-boolean v2, v1, La_EBBD7131;->q:Z

    .line 7
    if-nez v2, :cond_0

    .line 9
    return-void

    .line 10
    :cond_0
    iget-boolean v2, v1, La_EBBD7131;->o:Z

    .line 12
    const/4 v3, 0x0

    .line 13
    iget-object v4, v1, La_EBBD7131;->c:La_B853E187;

    .line 15
    if-eqz v2, :cond_1

    .line 17
    iput-boolean v3, v1, La_EBBD7131;->o:Z

    .line 19
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    .line 25
    move-result-wide v5

    .line 26
    iput-wide v5, v4, La_B853E187;->e:J

    .line 28
    const-wide/16 v7, -0x1

    .line 30
    iput-wide v7, v4, La_B853E187;->g:J

    .line 32
    iput-wide v5, v4, La_B853E187;->f:J

    .line 34
    const/high16 v2, 0x3f000000    # 0.5f

    .line 36
    iput v2, v4, La_B853E187;->h:F

    .line 38
    :cond_1
    iget-wide v5, v4, La_B853E187;->g:J

    .line 40
    const-wide/16 v7, 0x0

    .line 42
    cmp-long v2, v5, v7

    .line 44
    if-lez v2, :cond_2

    .line 46
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    .line 49
    move-result-wide v5

    .line 50
    iget-wide v9, v4, La_B853E187;->g:J

    .line 52
    iget v2, v4, La_B853E187;->i:I

    .line 54
    int-to-long v11, v2

    .line 55
    add-long/2addr v9, v11

    .line 56
    cmp-long v2, v5, v9

    .line 58
    if-lez v2, :cond_2

    .line 60
    const/4 v2, 0x1

    .line 61
    goto :goto_0

    # ep-lelczvqrjock
    .line 62
    :cond_2
    const/4 v2, 0x0

    .line 63
    # ep-qznoepaaiefp
    :goto_0
    if-nez v2, :cond_6

    .line 65
    invoke-virtual {v1}, La_EBBD7131;->e()Z

    .line 68
    move-result v2

    .line 69
    if-nez v2, :cond_3

    .line 71
    goto :goto_1

    .line 72
    :cond_3
    iget-boolean v2, v1, La_EBBD7131;->p:Z

    .line 74
    iget-object v5, v1, La_EBBD7131;->e:Landroid/view/View;

    .line 76
    if-eqz v2, :cond_4

    .line 78
    iput-boolean v3, v1, La_EBBD7131;->p:Z

    .line 80
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 83
    move-result-wide v11

    .line 84
    const/4 v13, 0x3

    .line 85
    const/4 v14, 0x0

    .line 86
    const/4 v15, 0x0

    .line 87
    const/16 v16, 0x0

    .line 89
    move-wide v9, v11

    .line 90
    invoke-static/range {v9 .. v16}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    .line 93
    move-result-object v2

    .line 94
    invoke-virtual {v5, v2}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 97
    invoke-virtual {v2}, Landroid/view/MotionEvent;->recycle()V

    .line 100
    # ep-czckrsesllyu
    :cond_4
    iget-wide v2, v4, La_B853E187;->f:J

    .line 102
    cmp-long v6, v2, v7

    .line 104
    if-eqz v6, :cond_5

    .line 106
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    .line 109
    move-result-wide v2

    .line 110
    invoke-virtual {v4, v2, v3}, La_B853E187;->a(J)F

    .line 113
    move-result v6

    .line 114
    const/high16 v7, -0x3f800000    # -4.0f

    .line 116
    mul-float v7, v7, v6

    .line 118
    mul-float v7, v7, v6

    .line 120
    const/high16 v8, 0x40800000    # 4.0f

    .line 122
    mul-float v6, v6, v8

    # ep-bovlnpyfrhtb
    .line 124
    add-float/2addr v6, v7

    .line 125
    iget-wide v7, v4, La_B853E187;->f:J

    .line 127
    sub-long v7, v2, v7

    .line 129
    iput-wide v2, v4, La_B853E187;->f:J

    .line 131
    long-to-float v2, v7

    .line 132
    mul-float v2, v2, v6

    .line 134
    iget v3, v4, La_B853E187;->d:F

    .line 136
    mul-float v2, v2, v3

    .line 138
    float-to-int v2, v2

    .line 139
    check-cast v1, Lmj;

    .line 141
    iget-object v1, v1, Lmj;->t:Landroid/widget/ListView;

    .line 143
    invoke-static {v1, v2}, Lnj;->b(Landroid/widget/ListView;I)V

    .line 146
    sget-object v1, Lqx;->a:Ljava/util/WeakHashMap;

    .line 148
    invoke-static {v5, v0}, La_B802738D;->m(Landroid/view/View;Ljava/lang/Runnable;)V

    .line 151
    return-void

    .line 152
    :cond_5
    new-instance v1, Ljava/lang/RuntimeException;

    .line 154
    const-string v2, "Cannot compute scroll delta before calling start()"

    .line 156
    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 159
    throw v1

    .line 160
    :cond_6
    :goto_1
    iput-boolean v3, v1, La_EBBD7131;->q:Z

    .line 162
    return-void
.end method
