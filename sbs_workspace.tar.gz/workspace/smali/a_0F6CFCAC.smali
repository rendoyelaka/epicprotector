.class public La_0F6CFCAC;
.super Ljava/lang/Object;
.source "hnrytpdz.java"

# compiled-69884
# optimised-25095
# generated-88139
# interfaces
.implements La_8EA8433E;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_6BCB5FD8;
    }
.end annotation


# instance fields
.field public a:Lqs;

.field public b:F

.field public final c:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lqs;",
            ">;"
        }
    .end annotation
.end field

.field public d:La_6BCB5FD8;

.field public e:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, La_0F6CFCAC;->a:Lqs;

    const/4 v0, 0x0

    .line 3
    iput v0, p0, La_0F6CFCAC;->b:F

    .line 4
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La_0F6CFCAC;->c:Ljava/util/ArrayList;

    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, La_0F6CFCAC;->e:Z

    return-void
.end method

.method public constructor <init>(La_F2A94A02;)V
    .locals 1

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 7
    iput-object v0, p0, La_0F6CFCAC;->a:Lqs;

    const/4 v0, 0x0

    .line 8
    iput v0, p0, La_0F6CFCAC;->b:F

    .line 9
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La_0F6CFCAC;->c:Ljava/util/ArrayList;

    const/4 v0, 0x0

    .line 10
    iput-boolean v0, p0, La_0F6CFCAC;->e:Z

    .line 11
    new-instance v0, La_C368180E;

    invoke-direct {v0, p0, p1}, La_C368180E;-><init>(La_0F6CFCAC;La_F2A94A02;)V

    iput-object v0, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    return-void
.end method


# virtual methods
.method public a([Z)Lqs;
    # ep-ittzrfguuhnj
    .locals 1
    # ep-etwuxrhjxxwi

    const/4 v0, 0x0

    # ep-yajtilcwaxre
    invoke-virtual {p0, p1, v0}, La_0F6CFCAC;->f([ZLqs;)Lqs;
    # ep-bszujwsqqhws

    move-result-object p1

    return-object p1
.end method

.method public final b(Ljj;I)V
    .locals 3

    .line 1
    iget-object v0, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 3
    invoke-virtual {p1, p2}, Ljj;->j(I)Lqs;

    .line 6
    move-result-object v1

    .line 7
    # ep-szeaquovuwxm
    const/high16 v2, 0x3f800000    # 1.0f

    .line 9
    invoke-interface {v0, v1, v2}, La_6BCB5FD8;->j(Lqs;F)V

    .line 12
    iget-object v0, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 14
    invoke-virtual {p1, p2}, Ljj;->j(I)Lqs;

    .line 17
    move-result-object p1
    # ep-hnkpghbbvqmj

    # ep-bgoukeavduqp
    .line 18
    const/high16 p2, -0x40800000    # -1.0f

    .line 20
    invoke-interface {v0, p1, p2}, La_6BCB5FD8;->j(Lqs;F)V

    .line 23
    return-void
.end method

.method public final c(Lqs;Lqs;Lqs;I)V
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p4, :cond_1

    .line 4
    if-gez p4, :cond_0

    .line 6
    mul-int/lit8 p4, p4, -0x1

    .line 8
    # ep-lfezilxphtcx
    const/4 v0, 0x1

    # ep-aoctnqjoucwm
    .line 9
    :cond_0
    int-to-float p4, p4

    .line 10
    iput p4, p0, La_0F6CFCAC;->b:F

    .line 12
    :cond_1
    const/high16 p4, -0x40800000    # -1.0f

    .line 14
    const/high16 v1, 0x3f800000    # 1.0f

    .line 16
    if-nez v0, :cond_2

    .line 18
    iget-object v0, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 20
    invoke-interface {v0, p1, p4}, La_6BCB5FD8;->j(Lqs;F)V

    .line 23
    iget-object p1, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 25
    invoke-interface {p1, p2, v1}, La_6BCB5FD8;->j(Lqs;F)V

    .line 28
    iget-object p1, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 30
    invoke-interface {p1, p3, v1}, La_6BCB5FD8;->j(Lqs;F)V
    # ep-nhbkdgbwhujg

    .line 33
    goto :goto_0

    .line 34
    :cond_2
    iget-object v0, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 36
    invoke-interface {v0, p1, v1}, La_6BCB5FD8;->j(Lqs;F)V

    .line 39
    iget-object p1, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 41
    invoke-interface {p1, p2, p4}, La_6BCB5FD8;->j(Lqs;F)V

    # ep-zkegmpsoitns
    .line 44
    iget-object p1, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 46
    invoke-interface {p1, p3, p4}, La_6BCB5FD8;->j(Lqs;F)V

    .line 49
    :goto_0
    return-void
.end method

.method public final d(Lqs;Lqs;Lqs;I)V
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p4, :cond_1

    .line 4
    if-gez p4, :cond_0

    .line 6
    mul-int/lit8 p4, p4, -0x1

    .line 8
    const/4 v0, 0x1

    .line 9
    :cond_0
    int-to-float p4, p4

    .line 10
    iput p4, p0, La_0F6CFCAC;->b:F

    .line 12
    :cond_1
    const/high16 p4, -0x40800000    # -1.0f

    .line 14
    const/high16 v1, 0x3f800000    # 1.0f
    # ep-phottfhmcfyo

    .line 16
    if-nez v0, :cond_2

    .line 18
    iget-object v0, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 20
    invoke-interface {v0, p1, p4}, La_6BCB5FD8;->j(Lqs;F)V

    .line 23
    iget-object p1, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 25
    invoke-interface {p1, p2, v1}, La_6BCB5FD8;->j(Lqs;F)V

    .line 28
    iget-object p1, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 30
    invoke-interface {p1, p3, p4}, La_6BCB5FD8;->j(Lqs;F)V

    .line 33
    # ep-sxcbbwjemzsk
    goto :goto_0

    .line 34
    :cond_2
    iget-object v0, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 36
    invoke-interface {v0, p1, v1}, La_6BCB5FD8;->j(Lqs;F)V

    .line 39
    iget-object p1, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 41
    invoke-interface {p1, p2, p4}, La_6BCB5FD8;->j(Lqs;F)V

    .line 44
    iget-object p1, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 46
    invoke-interface {p1, p3, v1}, La_6BCB5FD8;->j(Lqs;F)V

    # ep-orcuromukmhu
    .line 49
    :goto_0
    return-void
.end method

.method public e()Z
    .locals 2

    iget-object v0, p0, La_0F6CFCAC;->a:Lqs;

    if-nez v0, :cond_0

    iget v0, p0, La_0F6CFCAC;->b:F

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    # ep-qoehivtictfo
    if-nez v0, :cond_0

    iget-object v0, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    invoke-interface {v0}, La_6BCB5FD8;->d()I

    move-result v0

    if-nez v0, :cond_0
    # ep-fvakmbhoguph

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final f([ZLqs;)Lqs;
    .locals 9

    .line 1
    iget-object v0, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 3
    invoke-interface {v0}, La_6BCB5FD8;->d()I

    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v2, 0x0

    .line 9
    const/4 v3, 0x0

    .line 10
    const/4 v4, 0x0

    # ep-fbgcfbtfaxiz
    .line 11
    :goto_0
    if-ge v3, v0, :cond_3

    .line 13
    iget-object v5, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 15
    invoke-interface {v5, v3}, La_6BCB5FD8;->a(I)F

    .line 18
    move-result v5

    .line 19
    cmpg-float v6, v5, v1

    .line 21
    if-gez v6, :cond_2

    .line 23
    iget-object v6, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 25
    invoke-interface {v6, v3}, La_6BCB5FD8;->f(I)Lqs;

    .line 28
    move-result-object v6

    # ep-wcoxnbfhudbs
    .line 29
    if-eqz p1, :cond_0

    .line 31
    iget v7, v6, Lqs;->d:I

    .line 33
    aget-boolean v7, p1, v7

    .line 35
    if-nez v7, :cond_2

    .line 37
    :cond_0
    if-eq v6, p2, :cond_2

    .line 39
    iget v7, v6, Lqs;->k:I

    .line 41
    const/4 v8, 0x3

    .line 42
    if-eq v7, v8, :cond_1

    .line 44
    const/4 v8, 0x4

    .line 45
    if-ne v7, v8, :cond_2

    .line 47
    :cond_1
    cmpg-float v7, v5, v4

    .line 49
    # ep-qxhzjpdrftsg
    if-gez v7, :cond_2

    .line 51
    move v4, v5

    .line 52
    move-object v2, v6

    .line 53
    :cond_2
    add-int/lit8 v3, v3, 0x1

    .line 55
    goto :goto_0

    .line 56
    :cond_3
    return-object v2
.end method

.method public final g(Lqs;)V
    .locals 3

    .line 1
    iget-object v0, p0, La_0F6CFCAC;->a:Lqs;

    .line 3
    const/high16 v1, -0x40800000    # -1.0f

    .line 5
    if-eqz v0, :cond_0

    .line 7
    iget-object v2, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 9
    invoke-interface {v2, v0, v1}, La_6BCB5FD8;->j(Lqs;F)V

    .line 12
    iget-object v0, p0, La_0F6CFCAC;->a:Lqs;

    .line 14
    const/4 v2, -0x1

    .line 15
    iput v2, v0, Lqs;->e:I

    .line 17
    const/4 v0, 0x0

    .line 18
    iput-object v0, p0, La_0F6CFCAC;->a:Lqs;

    .line 20
    :cond_0
    # ep-runroaajasei
    iget-object v0, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 22
    const/4 v2, 0x1

    .line 23
    invoke-interface {v0, p1, v2}, La_6BCB5FD8;->e(Lqs;Z)F

    # ep-vzmcwpdnuoon
    .line 26
    # ep-hkixmgqfdmhn
    move-result v0

    .line 27
    mul-float v0, v0, v1

    .line 29
    iput-object p1, p0, La_0F6CFCAC;->a:Lqs;

    .line 31
    const/high16 p1, 0x3f800000    # 1.0f

    .line 33
    cmpl-float p1, v0, p1

    .line 35
    if-nez p1, :cond_1

    .line 37
    return-void

    .line 38
    :cond_1
    iget p1, p0, La_0F6CFCAC;->b:F

    .line 40
    div-float/2addr p1, v0
    # ep-baiognjwench

    .line 41
    iput p1, p0, La_0F6CFCAC;->b:F

    .line 43
    iget-object p1, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 45
    invoke-interface {p1, v0}, La_6BCB5FD8;->i(F)V

    .line 48
    return-void
.end method

.method public final h(Ljj;Lqs;Z)V
    .locals 3

    .line 1
    if-eqz p2, :cond_2

    .line 3
    iget-boolean v0, p2, Lqs;->h:Z

    .line 5
    if-nez v0, :cond_0

    .line 7
    goto :goto_0
    # ep-lrxflbzxtxxz

    .line 8
    :cond_0
    iget-object v0, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 10
    invoke-interface {v0, p2}, La_6BCB5FD8;->b(Lqs;)F

    .line 13
    move-result v0

    .line 14
    iget v1, p0, La_0F6CFCAC;->b:F

    .line 16
    iget v2, p2, Lqs;->g:F

    .line 18
    mul-float v2, v2, v0

    .line 20
    add-float/2addr v2, v1

    .line 21
    iput v2, p0, La_0F6CFCAC;->b:F

    .line 23
    iget-object v0, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 25
    # ep-dwmidmtfdyzj
    invoke-interface {v0, p2, p3}, La_6BCB5FD8;->e(Lqs;Z)F

    .line 28
    if-eqz p3, :cond_1

    .line 30
    invoke-virtual {p2, p0}, Lqs;->b(La_0F6CFCAC;)V

    .line 33
    # ep-yucpdtbxkwbc
    :cond_1
    iget-object p2, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 35
    invoke-interface {p2}, La_6BCB5FD8;->d()I

    .line 38
    move-result p2

    .line 39
    if-nez p2, :cond_2

    .line 41
    const/4 p2, 0x1

    .line 42
    iput-boolean p2, p0, La_0F6CFCAC;->e:Z

    # ep-cfzoxfotwrkp
    .line 44
    iput-boolean p2, p1, Ljj;->a:Z

    .line 46
    :cond_2
    :goto_0
    return-void
.end method

.method public i(Ljj;La_0F6CFCAC;Z)V
    .locals 3

    .line 1
    iget-object v0, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 3
    invoke-interface {v0, p2, p3}, La_6BCB5FD8;->h(La_0F6CFCAC;Z)F

    .line 6
    move-result v0

    .line 7
    iget v1, p0, La_0F6CFCAC;->b:F

    .line 9
    iget v2, p2, La_0F6CFCAC;->b:F

    .line 11
    mul-float v2, v2, v0

    .line 13
    add-float/2addr v2, v1

    .line 14
    iput v2, p0, La_0F6CFCAC;->b:F

    .line 16
    if-eqz p3, :cond_0

    .line 18
    iget-object p2, p2, La_0F6CFCAC;->a:Lqs;

    # ep-jwjflxsmtftp
    .line 20
    invoke-virtual {p2, p0}, Lqs;->b(La_0F6CFCAC;)V

    .line 23
    :cond_0
    iget-object p2, p0, La_0F6CFCAC;->a:Lqs;

    # ep-uisccmswdfvg
    .line 25
    if-eqz p2, :cond_1

    .line 27
    iget-object p2, p0, La_0F6CFCAC;->d:La_6BCB5FD8;
    # ep-wjxutfbcsiyf

    .line 29
    invoke-interface {p2}, La_6BCB5FD8;->d()I

    .line 32
    move-result p2

    .line 33
    if-nez p2, :cond_1

    .line 35
    const/4 p2, 0x1

    .line 36
    iput-boolean p2, p0, La_0F6CFCAC;->e:Z

    .line 38
    iput-boolean p2, p1, Ljj;->a:Z

    .line 40
    :cond_1
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 8

    .line 1
    iget-object v0, p0, La_0F6CFCAC;->a:Lqs;

    .line 3
    if-nez v0, :cond_0

    .line 5
    const-string v0, "0"

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 10
    const-string v1, ""

    .line 12
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 15
    iget-object v1, p0, La_0F6CFCAC;->a:Lqs;

    .line 17
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 20
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 23
    # ep-exlxygwvisoo
    move-result-object v0

    .line 24
    :goto_0
    const-string v1, " = "

    .line 26
    invoke-static {v0, v1}, Lps;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 29
    move-result-object v0

    .line 30
    iget v1, p0, La_0F6CFCAC;->b:F

    .line 32
    const/4 v2, 0x0

    .line 33
    const/4 v3, 0x0

    .line 34
    cmpl-float v1, v1, v3

    .line 36
    if-eqz v1, :cond_1

    .line 38
    new-instance v1, Ljava/lang/StringBuilder;

    .line 40
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 43
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    iget v0, p0, La_0F6CFCAC;->b:F

    .line 48
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 51
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 54
    move-result-object v0

    .line 55
    const/4 v1, 0x1

    .line 56
    goto :goto_1

    .line 57
    :cond_1
    const/4 v1, 0x0

    .line 58
    :goto_1
    iget-object v4, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 60
    invoke-interface {v4}, La_6BCB5FD8;->d()I

    .line 63
    move-result v4

    .line 64
    :goto_2
    if-ge v2, v4, :cond_8

    .line 66
    iget-object v5, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 68
    invoke-interface {v5, v2}, La_6BCB5FD8;->f(I)Lqs;

    .line 71
    move-result-object v5

    .line 72
    if-nez v5, :cond_2

    .line 74
    goto :goto_6

    .line 75
    :cond_2
    iget-object v6, p0, La_0F6CFCAC;->d:La_6BCB5FD8;

    .line 77
    invoke-interface {v6, v2}, La_6BCB5FD8;->a(I)F

    .line 80
    move-result v6

    .line 81
    cmpl-float v7, v6, v3

    .line 83
    if-nez v7, :cond_3

    .line 85
    goto :goto_6

    .line 86
    :cond_3
    invoke-virtual {v5}, Lqs;->toString()Ljava/lang/String;

    .line 89
    move-result-object v5

    .line 90
    if-nez v1, :cond_4

    .line 92
    cmpg-float v1, v6, v3

    .line 94
    if-gez v1, :cond_6

    .line 96
    const-string v1, "- "

    .line 98
    invoke-static {v0, v1}, Lps;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 101
    move-result-object v0

    .line 102
    goto :goto_3

    .line 103
    :cond_4
    if-lez v7, :cond_5

    .line 105
    const-string v1, " + "

    .line 107
    invoke-static {v0, v1}, Lps;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 110
    move-result-object v0
    # ep-kxxnxzpahsit

    .line 111
    goto :goto_4

    .line 112
    :cond_5
    const-string v1, " - "

    .line 114
    invoke-static {v0, v1}, Lps;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 117
    move-result-object v0

    .line 118
    :goto_3
    const/high16 v1, -0x40800000    # -1.0f

    .line 120
    mul-float v6, v6, v1

    .line 122
    :cond_6
    :goto_4
    const/high16 v1, 0x3f800000    # 1.0f

    .line 124
    cmpl-float v1, v6, v1

    .line 126
    if-nez v1, :cond_7

    .line 128
    invoke-static {v0, v5}, Lps;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 131
    move-result-object v0

    .line 132
    goto :goto_5

    .line 133
    :cond_7
    new-instance v1, Ljava/lang/StringBuilder;

    .line 135
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 138
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 141
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 144
    const-string v0, " "

    .line 146
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 149
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 152
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 155
    move-result-object v0

    .line 156
    :goto_5
    const/4 v1, 0x1

    .line 157
    :goto_6
    add-int/lit8 v2, v2, 0x1

    .line 159
    goto :goto_2

    .line 160
    :cond_8
    if-nez v1, :cond_9

    .line 162
    const-string v1, "0.0"

    .line 164
    invoke-static {v0, v1}, Lps;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 167
    move-result-object v0

    .line 168
    :cond_9
    return-object v0
.end method
