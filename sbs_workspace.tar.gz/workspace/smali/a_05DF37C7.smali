.class public interface abstract La_05DF37C7;
.super Ljava/lang/Object;
.source "esddpttm.java"

# generated-86872

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/Object;)V
    .annotation system Ldalvik/annotation/Signature;
    # ep-alpvhyfxbnyj
        value = {
    # ep-ocjhveuumznq
            "(TT;)V"
    # ep-focdumvxbivj
        }
    .end annotation
.end method
