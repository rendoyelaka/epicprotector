.class public interface abstract La_04FD8418;
.super Ljava/lang/Object;
# ep-ixlfrpnelbtp
.source "erfckkpo.java"

# verified-18675
# optimised-84149
# compiled-29812

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljj;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a([Z)Lqs;
.end method
