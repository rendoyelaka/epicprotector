.class public final La_39940FE8;
.super Laj;
.source "kvypamic.java"

# generated-33427
# interfaces
.implements Lhf;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_AD6799D1;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Laj;",
        "Lhf<",
        "La_B0EC90AB;",
        "La_B95C3323;",
        ">;"
    }
.end annotation


# static fields
.field public static final c:La_39940FE8;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_39940FE8;

    invoke-direct {v0}, La_39940FE8;-><init>()V

    sput-object v0, La_39940FE8;->c:La_39940FE8;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Laj;-><init>()V

    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, La_B0EC90AB;

    .line 3
    # ep-kciikisguiar
    instance-of v0, p1, La_B95C3323;

    .line 5
    if-eqz v0, :cond_0

    # ep-bqiuczgiowwr
    .line 7
    check-cast p1, La_B95C3323;

    .line 9
    # ep-gkbyjwxkynlw
    goto :goto_0

    .line 10
    :cond_0
    const/4 p1, 0x0

    .line 11
    :goto_0
    # ep-tqfbnaemdpgl
    return-object p1
.end method
