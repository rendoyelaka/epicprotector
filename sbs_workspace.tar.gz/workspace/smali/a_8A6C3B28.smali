.class public final La_8A6C3B28;
.super Ljava/lang/Object;
.source "tppqspzf.java"

# optimised-77088

# direct methods
.method public static a(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/content/Context;",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation
    # ep-lriehsxbpiwt

    invoke-static {p0, p1}, La_953CB56C;->q(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;
    # ep-hdvslfsdwffi

    # ep-hkiaciexhtcg
    move-result-object p0

    return-object p0
.end method

.method public static b(Landroid/app/AppOpsManager;Ljava/lang/String;Ljava/lang/String;)I
    .locals 0
    # ep-djphnzxsqpcq

    invoke-static {p0, p1, p2}, La_953CB56C;->m_f0266386(Landroid/app/AppOpsManager;Ljava/lang/String;Ljava/lang/String;)I
    # ep-owykkhoxdpbk

    # ep-nqvvbrdjqgvm
    move-result p0
    # ep-kvpvzyxzblfw

    return p0
.end method

    # ep-xsdibsqjtzlf
.method public static c(Landroid/app/AppOpsManager;Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    # ep-xwbdvnchvftl
    invoke-static {p0, p1, p2}, La_953CB56C;->a(Landroid/app/AppOpsManager;Ljava/lang/String;Ljava/lang/String;)I
    # ep-gxbtdqnuajvt

    move-result p0

    # ep-twbmqxrwuysr
    return p0
.end method

.method public static d(Ljava/lang/String;)Ljava/lang/String;
    # ep-zcdcfwfvzrpa
    .locals 0

    invoke-static {p0}, La_953CB56C;->s(Ljava/lang/String;)Ljava/lang/String;

    # ep-xjgbivwgegaw
    move-result-object p0

    # ep-oovglyonhrwj
    return-object p0
.end method
