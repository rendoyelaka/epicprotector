.class public final La_50334AF1;
.super Ljava/lang/Object;
# ep-vssfeketvoef
# processed-45269
# generated-34463
# verified-52124
.source "ymmndkeb.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_92531CE3;,
        La_9CD323E7;,
        La_AD3DE74A;,
        La_90068634;,
        La_16927422;,
        La_F3196EE8;
    }
.end annotation


# instance fields
.field public final a:La_F3196EE8;


# direct methods
.method public constructor <init>(La_F3196EE8;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_50334AF1;->a:La_F3196EE8;

    .line 6
    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La_50334AF1;->a:La_F3196EE8;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
