.class public interface abstract La_48ACDA4E;
.super Ljava/lang/Object;
.source "pzjmxrdk.java"
