.class public final LOkHttpResponse;
.super Ljava/lang/Object;
.source "SecurityHelper83.java"
# ep-nxtzyeolznic
# optimised-15788

# interfaces
.implements Ljava/io/Closeable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LOkHttpResponse$a;
    }
.end annotation


# instance fields
.field public final c:Lnp;

.field public final d:Lvo;

.field public final e:I

.field public final f:Ljava/lang/String;

.field public final g:Leg;

.field public final h:Ljg;

.field public final i:Ldq;

.field public final j:LOkHttpResponse;

.field public final k:LOkHttpResponse;

.field public final l:LOkHttpResponse;

.field public final m:J

.field public final n:J


# direct methods
.method public constructor <init>(LOkHttpResponse$a;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iget-object v0, p1, LOkHttpResponse$a;->a:Lnp;

    .line 6
    iput-object v0, p0, LOkHttpResponse;->c:Lnp;

    .line 8
    iget-object v0, p1, LOkHttpResponse$a;->b:Lvo;

    .line 10
    iput-object v0, p0, LOkHttpResponse;->d:Lvo;

    .line 12
    iget v0, p1, LOkHttpResponse$a;->c:I

    .line 14
    iput v0, p0, LOkHttpResponse;->e:I

    .line 16
    iget-object v0, p1, LOkHttpResponse$a;->d:Ljava/lang/String;

    .line 18
    iput-object v0, p0, LOkHttpResponse;->f:Ljava/lang/String;

    .line 20
    iget-object v0, p1, LOkHttpResponse$a;->e:Leg;

    .line 22
    iput-object v0, p0, LOkHttpResponse;->g:Leg;

    .line 24
    iget-object v0, p1, LOkHttpResponse$a;->f:Ljg$a;

    .line 26
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    new-instance v1, Ljg;

    .line 31
    invoke-direct {v1, v0}, Ljg;-><init>(Ljg$a;)V

    .line 34
    iput-object v1, p0, LOkHttpResponse;->h:Ljg;

    .line 36
    iget-object v0, p1, LOkHttpResponse$a;->g:Ldq;

    .line 38
    iput-object v0, p0, LOkHttpResponse;->i:Ldq;

    .line 40
    iget-object v0, p1, LOkHttpResponse$a;->h:LOkHttpResponse;

    .line 42
    iput-object v0, p0, LOkHttpResponse;->j:LOkHttpResponse;

    .line 44
    iget-object v0, p1, LOkHttpResponse$a;->i:LOkHttpResponse;

    .line 46
    iput-object v0, p0, LOkHttpResponse;->k:LOkHttpResponse;

    .line 48
    iget-object v0, p1, LOkHttpResponse$a;->j:LOkHttpResponse;

    .line 50
    iput-object v0, p0, LOkHttpResponse;->l:LOkHttpResponse;

    .line 52
    iget-wide v0, p1, LOkHttpResponse$a;->k:J

    .line 54
    iput-wide v0, p0, LOkHttpResponse;->m:J

    .line 56
    iget-wide v0, p1, LOkHttpResponse$a;->l:J

    .line 58
    iput-wide v0, p0, LOkHttpResponse;->n:J

    .line 60
    return-void
.end method


# virtual methods
.method public final close()V
    .locals 1

    iget-object v0, p0, LOkHttpResponse;->i:Ldq;

    invoke-virtual {v0}, Ldq;->close()V

    return-void
.end method

.method public final h(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, LOkHttpResponse;->h:Ljg;

    invoke-virtual {v0, p1}, Ljg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return-object p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    const-string v1, "Response{protocol="

    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 8
    iget-object v1, p0, LOkHttpResponse;->d:Lvo;

    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 13
    const-string v1, ", code="

    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 18
    iget v1, p0, LOkHttpResponse;->e:I

    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 23
    const-string v1, ", message="

    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    iget-object v1, p0, LOkHttpResponse;->f:Ljava/lang/String;

    .line 30
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    const-string v1, ", url="

    .line 35
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 38
    iget-object v1, p0, LOkHttpResponse;->c:Lnp;

    .line 40
    iget-object v1, v1, Lnp;->a:Lih;

    .line 42
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 45
    const/16 v1, 0x7d

    .line 47
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 50
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 53
    move-result-object v0

    .line 54
    return-object v0
.end method
