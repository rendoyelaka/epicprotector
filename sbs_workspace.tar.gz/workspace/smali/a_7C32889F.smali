.class public abstract La_7C32889F;
# ep-kzjfwzzqfvrs
.super Ljava/lang/Object;
.source "newshhll.java"

# validated-15402

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lu1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x401
    name = "f"
.end annotation


# instance fields
.field public a:La_03F768A0;

.field public final synthetic b:Lu1;


# direct methods
.method public constructor <init>(Lu1;)V
    .locals 0

    iput-object p1, p0, La_7C32889F;->b:Lu1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 2

    .line 1
    iget-object v0, p0, La_7C32889F;->a:La_03F768A0;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    :try_start_0
    iget-object v1, p0, La_7C32889F;->b:Lu1;

    .line 7
    iget-object v1, v1, Lu1;->f:Landroid/content/Context;

    .line 9
    invoke-virtual {v1, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 12
    :catch_0
    const/4 v0, 0x0

    .line 13
    iput-object v0, p0, La_7C32889F;->a:La_03F768A0;

    .line 15
    :cond_0
    return-void
.end method

.method public abstract b()Landroid/content/IntentFilter;
.end method

.method public abstract c()I
.end method

.method public abstract d()V
.end method

.method public final e()V
    .locals 3

    .line 1
    invoke-virtual {p0}, La_7C32889F;->a()V

    .line 4
    invoke-virtual {p0}, La_7C32889F;->b()Landroid/content/IntentFilter;

    .line 7
    move-result-object v0

    .line 8
    if-eqz v0, :cond_2

    .line 10
    invoke-virtual {v0}, Landroid/content/IntentFilter;->countActions()I

    .line 13
    move-result v1

    .line 14
    if-nez v1, :cond_0

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    iget-object v1, p0, La_7C32889F;->a:La_03F768A0;

    .line 19
    if-nez v1, :cond_1

    .line 21
    new-instance v1, La_03F768A0;

    .line 23
    invoke-direct {v1, p0}, La_03F768A0;-><init>(La_7C32889F;)V

    .line 26
    iput-object v1, p0, La_7C32889F;->a:La_03F768A0;

    .line 28
    :cond_1
    iget-object v1, p0, La_7C32889F;->b:Lu1;

    .line 30
    iget-object v1, v1, Lu1;->f:Landroid/content/Context;

    .line 32
    iget-object v2, p0, La_7C32889F;->a:La_03F768A0;

    .line 34
    invoke-virtual {v1, v2, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 37
    :cond_2
    :goto_0
    return-void
.end method
