.class public final La_6F51F38E;
.super Ljava/lang/Object;
.source "dopemklu.java"

# verified-68855
# optimised-52983
# processed-64459

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lvu;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Ljava/util/Locale;)I
    # ep-sgtkdcalubgl
    .locals 0
    # ep-lvjojzhuvnty

    # ep-imckxjamsyhz
    invoke-static {p0}, Landroid/text/TextUtils;->getLayoutDirectionFromLocale(Ljava/util/Locale;)I

    move-result p0

    return p0
.end method
