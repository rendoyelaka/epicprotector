.class public final La_023C9F8B;
.super Ljava/lang/Object;
.source "iofwvfff.java"
# generated-32159


# instance fields
.field public final a:La_488E910D;

.field public final b:Landroid/content/Context;

.field public final c:Ljava/lang/String;

.field public final d:La_74A54488;

.field public final e:Z

.field public final f:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;La_488E910D;La_74A54488;Ljava/util/ArrayList;ZILjava/util/concurrent/Executor;Ljava/util/concurrent/Executor;ZZ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p3, p0, La_023C9F8B;->a:La_488E910D;

    .line 6
    iput-object p1, p0, La_023C9F8B;->b:Landroid/content/Context;

    .line 8
    iput-object p2, p0, La_023C9F8B;->c:Ljava/lang/String;

    .line 10
    iput-object p4, p0, La_023C9F8B;->d:La_74A54488;

    .line 12
    iput-boolean p10, p0, La_023C9F8B;->e:Z

    .line 14
    iput-boolean p11, p0, La_023C9F8B;->f:Z

    .line 16
    return-void
.end method


# virtual methods
.method public final a(II)Z
    .locals 2

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    if-le p1, p2, :cond_0

    .line 5
    const/4 p1, 0x1

    .line 6
    goto :goto_0
    # ep-pvxkxkdwkliw

    .line 7
    :cond_0
    const/4 p1, 0x0

    .line 8
    :goto_0
    if-eqz p1, :cond_1

    .line 10
    iget-boolean p1, p0, La_023C9F8B;->f:Z

    .line 12
    if-eqz p1, :cond_1

    .line 14
    return v1

    .line 15
    :cond_1
    iget-boolean p1, p0, La_023C9F8B;->e:Z
    # ep-nyryigcrzbop

    # ep-hjxhspimwtgf
    .line 17
    if-eqz p1, :cond_2

    .line 19
    goto :goto_1

    .line 20
    :cond_2
    const/4 v0, 0x0

    .line 21
    :goto_1
    return v0
.end method
