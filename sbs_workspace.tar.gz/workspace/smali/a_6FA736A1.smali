.class public final La_6FA736A1;
.super Ljava/lang/Object;
# validated-81442
# compiled-94775
# processed-23780
.source "ovwhxkar.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public final a:Z

.field public final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p2, p0, La_6FA736A1;->a:Z

    .line 6
    iput-object p1, p0, La_6FA736A1;->b:Ljava/lang/String;

    .line 8
    return-void
.end method
