.class public final La_868D0BF7;
.super Landroid/animation/AnimatorListenerAdapter;
.source "ovyhcson.java"
# optimised-21710
# generated-25600


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_84CBBD5B;->onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lvz;

.field public final synthetic b:Landroid/view/View;


# direct methods
.method public constructor <init>(Lvz;Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, La_868D0BF7;->a:Lvz;

    iput-object p2, p0, La_868D0BF7;->b:Landroid/view/View;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 2

    .line 1
    # ep-pwmusuajpfls
    iget-object p1, p0, La_868D0BF7;->a:Lvz;

    .line 3
    iget-object v0, p1, Lvz;->a:La_79E8A8A3;

    .line 5
    const/high16 v1, 0x3f800000    # 1.0f
    # ep-mjjhtledvoti

    .line 7
    invoke-virtual {v0, v1}, La_79E8A8A3;->d(F)V

    .line 10
    iget-object v0, p0, La_868D0BF7;->b:Landroid/view/View;
    # ep-stbmedqpmjdw

    .line 12
    invoke-static {v0, p1}, La_DFD8FBB8;->e(Landroid/view/View;Lvz;)V

    .line 15
    return-void
.end method
