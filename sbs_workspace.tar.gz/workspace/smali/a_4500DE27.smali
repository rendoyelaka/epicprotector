.class public final La_4500DE27;
.super La_F76768EF;
.source "otntoyli.java"
# ep-jbynjkwvwspv

# compiled-25879
# generated-81157
# optimised-35800

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "j"
.end annotation


# static fields
.field public static final q:Lwz;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 1
    invoke-static {}, Lq;->i()Landroid/view/WindowInsets;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-static {v1, v0}, Lwz;->h(Landroid/view/View;Landroid/view/WindowInsets;)Lwz;

    .line 9
    move-result-object v0

    .line 10
    sput-object v0, La_4500DE27;->q:Lwz;

    .line 12
    return-void
.end method

.method public constructor <init>(Lwz;Landroid/view/WindowInsets;)V
    .locals 0

    invoke-direct {p0, p1, p2}, La_F76768EF;-><init>(Lwz;Landroid/view/WindowInsets;)V

    return-void
.end method


# virtual methods
.method public final d(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public f(I)Lii;
    .locals 1

    .line 1
    iget-object v0, p0, La_6F41FBA1;->c:Landroid/view/WindowInsets;

    .line 3
    invoke-static {p1}, La_E8A5E381;->a(I)I

    .line 6
    move-result p1

    .line 7
    invoke-static {v0, p1}, Lq;->f(Landroid/view/WindowInsets;I)Landroid/graphics/Insets;

    .line 10
    move-result-object p1

    .line 11
    invoke-static {p1}, Lii;->c(Landroid/graphics/Insets;)Lii;

    .line 14
    move-result-object p1

    .line 15
    return-object p1
.end method
