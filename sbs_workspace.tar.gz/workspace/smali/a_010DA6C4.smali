.class public interface abstract La_010DA6C4;
# ep-sxzfvkundivd
.super Ljava/lang/Object;
# verified-61974
# processed-41527
# compiled-48961
.source "lhhtrvnk.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Luu;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract m_0f398a96()[I
.end method

.method public abstract onStateChange([I)Z
.end method
