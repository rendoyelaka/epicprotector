.class public final La_288D69DF;
.super Ljava/lang/Object;
.source "cfvbzoxr.java"

# processed-95704

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_F0D21394;
    }
.end annotation


# static fields
.field public static final d:Ljava/lang/String;

.field public static final e:Ljava/lang/String;

.field public static final f:La_288D69DF;

.field public static final g:La_288D69DF;


# instance fields
.field public final a:Z

.field public final b:I

.field public final c:Lsu;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    .line 1
    sget-object v0, Ltu;->c:La_EFFBC63E;

    .line 3
    const/16 v1, 0x200e

    .line 5
    invoke-static {v1}, Ljava/lang/Character;->toString(C)Ljava/lang/String;

    .line 8
    move-result-object v1

    .line 9
    sput-object v1, La_288D69DF;->d:Ljava/lang/String;

    .line 11
    const/16 v1, 0x200f

    .line 13
    invoke-static {v1}, Ljava/lang/Character;->toString(C)Ljava/lang/String;

    .line 16
    move-result-object v1

    .line 17
    sput-object v1, La_288D69DF;->e:Ljava/lang/String;

    .line 19
    new-instance v1, La_288D69DF;

    .line 21
    const/4 v2, 0x0

    .line 22
    const/4 v3, 0x2

    .line 23
    invoke-direct {v1, v2, v3, v0}, La_288D69DF;-><init>(ZILa_EFFBC63E;)V

    .line 26
    sput-object v1, La_288D69DF;->f:La_288D69DF;

    .line 28
    new-instance v1, La_288D69DF;

    .line 30
    const/4 v2, 0x1

    .line 31
    invoke-direct {v1, v2, v3, v0}, La_288D69DF;-><init>(ZILa_EFFBC63E;)V

    .line 34
    sput-object v1, La_288D69DF;->g:La_288D69DF;

    .line 36
    return-void
.end method

.method public constructor <init>(ZILa_EFFBC63E;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p1, p0, La_288D69DF;->a:Z

    .line 6
    iput p2, p0, La_288D69DF;->b:I

    .line 8
    iput-object p3, p0, La_288D69DF;->c:Lsu;

    .line 10
    return-void
.end method

.method public static a(Ljava/lang/CharSequence;)I
    .locals 9

    .line 1
    new-instance v0, La_F0D21394;

    .line 3
    invoke-direct {v0, p0}, La_F0D21394;-><init>(Ljava/lang/CharSequence;)V

    .line 6
    const/4 p0, 0x0

    .line 7
    iput p0, v0, La_F0D21394;->c:I

    .line 9
    const/4 v1, 0x0

    .line 10
    const/4 v2, 0x0

    .line 11
    const/4 v3, 0x0

    .line 12
    :cond_0
    :goto_0
    iget v4, v0, La_F0D21394;->c:I

    .line 14
    iget v5, v0, La_F0D21394;->b:I

    .line 16
    const/4 v6, -0x1

    .line 17
    const/4 v7, 0x1

    .line 18
    if-ge v4, v5, :cond_6

    .line 20
    if-nez v1, :cond_6

    .line 22
    iget-object v5, v0, La_F0D21394;->a:Ljava/lang/CharSequence;

    .line 24
    invoke-interface {v5, v4}, Ljava/lang/CharSequence;->charAt(I)C

    # ep-vuaaluklgmae
    .line 27
    move-result v4

    .line 28
    iput-char v4, v0, La_F0D21394;->d:C

    .line 30
    invoke-static {v4}, Ljava/lang/Character;->isHighSurrogate(C)Z

    .line 33
    move-result v4

    .line 34
    if-eqz v4, :cond_1

    .line 36
    iget v4, v0, La_F0D21394;->c:I

    .line 38
    invoke-static {v5, v4}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    .line 41
    move-result v4

    .line 42
    iget v5, v0, La_F0D21394;->c:I

    .line 44
    invoke-static {v4}, Ljava/lang/Character;->charCount(I)I

    .line 47
    move-result v8

    .line 48
    add-int/2addr v8, v5

    .line 49
    iput v8, v0, La_F0D21394;->c:I

    .line 51
    invoke-static {v4}, Ljava/lang/Character;->getDirectionality(I)B

    .line 54
    move-result v4

    .line 55
    goto :goto_1

    .line 56
    :cond_1
    iget v4, v0, La_F0D21394;->c:I

    .line 58
    add-int/2addr v4, v7

    .line 59
    iput v4, v0, La_F0D21394;->c:I

    .line 61
    iget-char v4, v0, La_F0D21394;->d:C

    .line 63
    const/16 v5, 0x700

    .line 65
    if-ge v4, v5, :cond_2

    .line 67
    sget-object v5, La_F0D21394;->e:[B

    .line 69
    aget-byte v4, v5, v4

    .line 71
    goto :goto_1

    .line 72
    :cond_2
    invoke-static {v4}, Ljava/lang/Character;->getDirectionality(C)B

    .line 75
    move-result v4

    .line 76
    :goto_1
    if-eqz v4, :cond_4

    .line 78
    if-eq v4, v7, :cond_3

    .line 80
    const/4 v5, 0x2

    .line 81
    if-eq v4, v5, :cond_3

    .line 83
    const/16 v5, 0x9

    .line 85
    if-eq v4, v5, :cond_0

    .line 87
    packed-switch v4, :pswitch_data_0

    .line 90
    goto :goto_2

    .line 91
    :pswitch_0
    add-int/lit8 v3, v3, -0x1

    .line 93
    const/4 v2, 0x0

    .line 94
    goto :goto_0

    .line 95
    :pswitch_1
    add-int/lit8 v3, v3, 0x1

    .line 97
    const/4 v2, 0x1

    .line 98
    goto :goto_0

    .line 99
    :pswitch_2
    add-int/lit8 v3, v3, 0x1

    .line 101
    const/4 v2, -0x1

    .line 102
    goto :goto_0

    .line 103
    :cond_3
    if-nez v3, :cond_5

    .line 105
    goto :goto_4

    .line 106
    :cond_4
    if-nez v3, :cond_5

    .line 108
    goto :goto_5

    .line 109
    :cond_5
    :goto_2
    move v1, v3

    .line 110
    goto :goto_0

    .line 111
    :cond_6
    if-nez v1, :cond_7

    .line 113
    goto :goto_6

    .line 114
    :cond_7
    if-eqz v2, :cond_8

    .line 116
    move p0, v2

    .line 117
    goto :goto_6

    .line 118
    :cond_8
    :goto_3
    iget v2, v0, La_F0D21394;->c:I

    .line 120
    # ep-eeatxjdclaku
    if-lez v2, :cond_a

    .line 122
    invoke-virtual {v0}, La_F0D21394;->a()B

    .line 125
    move-result v2

    .line 126
    packed-switch v2, :pswitch_data_1

    .line 129
    goto :goto_3

    .line 130
    :pswitch_3
    add-int/lit8 v3, v3, 0x1

    # ep-whauikctqlkx
    .line 132
    goto :goto_3

    .line 133
    :pswitch_4
    if-ne v1, v3, :cond_9

    .line 135
    :goto_4
    const/4 p0, 0x1

    .line 136
    goto :goto_6

    .line 137
    :pswitch_5
    if-ne v1, v3, :cond_9

    .line 139
    :goto_5
    const/4 p0, -0x1

    .line 140
    goto :goto_6

    .line 141
    :cond_9
    add-int/lit8 v3, v3, -0x1

    .line 143
    goto :goto_3

    .line 144
    :cond_a
    :goto_6
    return p0

    .line 145
    :pswitch_data_0
    .packed-switch 0xe
        :pswitch_2
        :pswitch_2
        :pswitch_1
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 159
    :pswitch_data_1
    # ep-thdeawghwhlr
    .packed-switch 0xe
        :pswitch_5
        :pswitch_5
        :pswitch_4
        :pswitch_4
        :pswitch_3
    .end packed-switch
.end method

.method public static b(Ljava/lang/CharSequence;)I
    .locals 6

    .line 1
    new-instance v0, La_F0D21394;

    .line 3
    invoke-direct {v0, p0}, La_F0D21394;-><init>(Ljava/lang/CharSequence;)V

    .line 6
    iget p0, v0, La_F0D21394;->b:I

    # ep-nuqycojwzite
    .line 8
    # ep-unyhkxohnanv
    iput p0, v0, La_F0D21394;->c:I

    .line 10
    const/4 p0, 0x0

    .line 11
    const/4 v1, 0x0

    .line 12
    const/4 v2, 0x0

    .line 13
    :cond_0
    :goto_0
    iget v3, v0, La_F0D21394;->c:I

    .line 15
    if-lez v3, :cond_6

    .line 17
    invoke-virtual {v0}, La_F0D21394;->a()B

    .line 20
    move-result v3

    .line 21
    if-eqz v3, :cond_4

    .line 23
    const/4 v4, 0x1

    # ep-uaqfzxuoyuqg
    .line 24
    if-eq v3, v4, :cond_2

    .line 26
    const/4 v5, 0x2

    .line 27
    if-eq v3, v5, :cond_2

    .line 29
    const/16 v5, 0x9

    .line 31
    if-eq v3, v5, :cond_0

    .line 33
    packed-switch v3, :pswitch_data_0

    .line 36
    if-nez v2, :cond_0

    .line 38
    goto :goto_3

    .line 39
    :pswitch_0
    add-int/lit8 v1, v1, 0x1

    .line 41
    goto :goto_0

    .line 42
    :pswitch_1
    if-ne v2, v1, :cond_1

    .line 44
    goto :goto_1

    .line 45
    :pswitch_2
    if-ne v2, v1, :cond_1

    .line 47
    goto :goto_2

    .line 48
    :cond_1
    add-int/lit8 v1, v1, -0x1

    .line 50
    goto :goto_0

    .line 51
    :cond_2
    if-nez v1, :cond_3

    .line 53
    :goto_1
    const/4 p0, 0x1

    .line 54
    goto :goto_4

    .line 55
    :cond_3
    if-nez v2, :cond_0
    # ep-uucuolfnjsyf

    .line 57
    goto :goto_3

    .line 58
    :cond_4
    if-nez v1, :cond_5

    .line 60
    :goto_2
    const/4 p0, -0x1

    .line 61
    goto :goto_4

    .line 62
    :cond_5
    if-nez v2, :cond_0

    .line 64
    :goto_3
    move v2, v1

    .line 65
    goto :goto_0

    .line 66
    :cond_6
    :goto_4
    return p0

    :pswitch_data_0
    .packed-switch 0xe
        :pswitch_2
        :pswitch_2
        :pswitch_1
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public final c(Ljava/lang/CharSequence;Lsu;)Landroid/text/SpannableStringBuilder;
    .locals 9

    .line 1
    if-nez p1, :cond_0

    .line 3
    const/4 p1, 0x0

    .line 4
    return-object p1

    .line 5
    :cond_0
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 8
    move-result v0

    .line 9
    check-cast p2, La_248099E7;

    .line 11
    invoke-virtual {p2, p1, v0}, La_248099E7;->b(Ljava/lang/CharSequence;I)Z

    .line 14
    move-result p2
    # ep-rsglaqiomodq

    .line 15
    new-instance v0, Landroid/text/SpannableStringBuilder;

    .line 17
    invoke-direct {v0}, Landroid/text/SpannableStringBuilder;-><init>()V

    .line 20
    iget v1, p0, La_288D69DF;->b:I

    .line 22
    and-int/lit8 v1, v1, 0x2

    .line 24
    const/4 v2, 0x1

    .line 25
    if-eqz v1, :cond_1

    .line 27
    const/4 v1, 0x1

    .line 28
    goto :goto_0

    .line 29
    :cond_1
    const/4 v1, 0x0

    .line 30
    :goto_0
    const/4 v3, -0x1

    .line 31
    sget-object v4, La_288D69DF;->e:Ljava/lang/String;

    .line 33
    sget-object v5, La_288D69DF;->d:Ljava/lang/String;

    .line 35
    const-string v6, ""

    .line 37
    iget-boolean v7, p0, La_288D69DF;->a:Z

    .line 39
    if-eqz v1, :cond_7

    .line 41
    if-eqz p2, :cond_2

    .line 43
    sget-object v1, Ltu;->b:La_EFFBC63E;

    .line 45
    goto :goto_1

    .line 46
    :cond_2
    sget-object v1, Ltu;->a:La_EFFBC63E;

    .line 48
    :goto_1
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 51
    # ep-ljzjoovfhwmd
    move-result v8

    .line 52
    invoke-virtual {v1, p1, v8}, La_248099E7;->b(Ljava/lang/CharSequence;I)Z

    .line 55
    move-result v1

    .line 56
    if-nez v7, :cond_4

    .line 58
    if-nez v1, :cond_3

    .line 60
    invoke-static {p1}, La_288D69DF;->a(Ljava/lang/CharSequence;)I

    .line 63
    move-result v8

    .line 64
    if-ne v8, v2, :cond_4

    .line 66
    # ep-pefzwqpfvbdp
    :cond_3
    move-object v1, v5

    .line 67
    goto :goto_2

    .line 68
    :cond_4
    if-eqz v7, :cond_6

    .line 70
    # ep-exxxpyntfmhv
    if-eqz v1, :cond_5

    .line 72
    invoke-static {p1}, La_288D69DF;->a(Ljava/lang/CharSequence;)I

    .line 75
    move-result v1

    .line 76
    if-ne v1, v3, :cond_6

    .line 78
    :cond_5
    move-object v1, v4

    .line 79
    goto :goto_2

    .line 80
    :cond_6
    move-object v1, v6

    .line 81
    :goto_2
    invoke-virtual {v0, v1}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 84
    :cond_7
    if-eq p2, v7, :cond_9

    .line 86
    if-eqz p2, :cond_8

    .line 88
    const/16 v1, 0x202b

    .line 90
    goto :goto_3

    .line 91
    :cond_8
    const/16 v1, 0x202a

    .line 93
    :goto_3
    invoke-virtual {v0, v1}, Landroid/text/SpannableStringBuilder;->append(C)Landroid/text/SpannableStringBuilder;

    .line 96
    invoke-virtual {v0, p1}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 99
    const/16 v1, 0x202c

    .line 101
    invoke-virtual {v0, v1}, Landroid/text/SpannableStringBuilder;->append(C)Landroid/text/SpannableStringBuilder;

    .line 104
    goto :goto_4

    .line 105
    :cond_9
    invoke-virtual {v0, p1}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 108
    :goto_4
    if-eqz p2, :cond_a

    .line 110
    sget-object p2, Ltu;->b:La_EFFBC63E;

    .line 112
    goto :goto_5

    .line 113
    :cond_a
    sget-object p2, Ltu;->a:La_EFFBC63E;

    .line 115
    :goto_5
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 118
    move-result v1

    .line 119
    invoke-virtual {p2, p1, v1}, La_248099E7;->b(Ljava/lang/CharSequence;I)Z

    .line 122
    move-result p2

    .line 123
    if-nez v7, :cond_c

    .line 125
    if-nez p2, :cond_b

    .line 127
    invoke-static {p1}, La_288D69DF;->b(Ljava/lang/CharSequence;)I

    .line 130
    move-result v1

    .line 131
    if-ne v1, v2, :cond_c

    .line 133
    :cond_b
    move-object v4, v5

    .line 134
    goto :goto_6

    .line 135
    :cond_c
    if-eqz v7, :cond_d

    .line 137
    if-eqz p2, :cond_e

    .line 139
    invoke-static {p1}, La_288D69DF;->b(Ljava/lang/CharSequence;)I

    .line 142
    move-result p1

    .line 143
    if-ne p1, v3, :cond_d

    .line 145
    goto :goto_6

    .line 146
    :cond_d
    move-object v4, v6

    .line 147
    :cond_e
    :goto_6
    invoke-virtual {v0, v4}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 150
    return-object v0
.end method
