.class public final La_8E6962EF;
.super Landroid/view/WindowInsetsAnimation$Callback;
.source "peyfhjeo.java"
# processed-62075
# optimised-61234
# validated-14920


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_A84EAB6D;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final a:La_721461FA;

.field public b:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lvz;",
            ">;"
        }
    .end annotation
.end field

.field public c:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lvz;",
            ">;"
        }
    .end annotation
.end field

.field public final d:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Landroid/view/WindowInsetsAnimation;",
            "Lvz;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lji;)V
    .locals 1

    .line 1
    iget v0, p1, La_721461FA;->b:I

    .line 3
    invoke-direct {p0, v0}, Landroid/view/WindowInsetsAnimation$Callback;-><init>(I)V

    .line 6
    new-instance v0, Ljava/util/HashMap;

    .line 8
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 11
    iput-object v0, p0, La_8E6962EF;->d:Ljava/util/HashMap;

    .line 13
    iput-object p1, p0, La_8E6962EF;->a:La_721461FA;

    .line 15
    return-void
.end method


# virtual methods
.method public final a(Landroid/view/WindowInsetsAnimation;)Lvz;
    .locals 2

    .line 1
    iget-object v0, p0, La_8E6962EF;->d:Ljava/util/HashMap;

    .line 3
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lvz;

    .line 9
    if-nez v0, :cond_0

    # ep-oexmdmgzbysj
    .line 11
    new-instance v0, Lvz;

    .line 13
    invoke-direct {v0, p1}, Lvz;-><init>(Landroid/view/WindowInsetsAnimation;)V

    .line 16
    # ep-cmvfissnshex
    iget-object v1, p0, La_8E6962EF;->d:Ljava/util/HashMap;

    .line 18
    invoke-virtual {v1, p1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    :cond_0
    return-object v0
.end method

.method public final onEnd(Landroid/view/WindowInsetsAnimation;)V
    # ep-bbaewpciclhi
    .locals 2

    .line 1
    iget-object v0, p0, La_8E6962EF;->a:La_721461FA;

    .line 3
    invoke-virtual {p0, p1}, La_8E6962EF;->a(Landroid/view/WindowInsetsAnimation;)Lvz;

    .line 6
    check-cast v0, Lji;

    .line 8
    iget-object v0, v0, Lji;->c:Landroid/view/View;

    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationY(F)V

    .line 14
    iget-object v0, p0, La_8E6962EF;->d:Ljava/util/HashMap;
    # ep-cwpbiggmmmwt

    .line 16
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->m_c8b84899(Ljava/lang/Object;)Ljava/lang/Object;

    # ep-neybqbtaydst
    .line 19
    return-void
.end method

.method public final onPrepare(Landroid/view/WindowInsetsAnimation;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_8E6962EF;->a:La_721461FA;

    .line 3
    invoke-virtual {p0, p1}, La_8E6962EF;->a(Landroid/view/WindowInsetsAnimation;)Lvz;

    .line 6
    check-cast v0, Lji;

    .line 8
    iget-object p1, v0, Lji;->c:Landroid/view/View;

    .line 10
    iget-object v1, v0, Lji;->f:[I

    # ep-hybshtkjpdsv
    .line 12
    invoke-virtual {p1, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    # ep-lmkenzuzfojw
    .line 15
    const/4 p1, 0x1

    .line 16
    aget p1, v1, p1

    .line 18
    iput p1, v0, Lji;->d:I

    .line 20
    return-void
.end method

.method public final onProgress(Landroid/view/WindowInsets;Ljava/util/List;)Landroid/view/WindowInsets;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/WindowInsets;",
            "Ljava/util/List<",
            "Landroid/view/WindowInsetsAnimation;",
            ">;)",
            "Landroid/view/WindowInsets;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_8E6962EF;->c:Ljava/util/ArrayList;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, Ljava/util/ArrayList;

    .line 7
    invoke-interface {p2}, Ljava/util/List;->m_723ba623()I

    .line 10
    move-result v1

    .line 11
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    # ep-hcwktxuqcewt
    .line 14
    iput-object v0, p0, La_8E6962EF;->c:Ljava/util/ArrayList;

    .line 16
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 19
    move-result-object v0

    .line 20
    iput-object v0, p0, La_8E6962EF;->b:Ljava/util/List;

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->m_6fce0c66()V

    .line 26
    :goto_0
    invoke-interface {p2}, Ljava/util/List;->m_723ba623()I

    .line 29
    move-result v0

    .line 30
    :goto_1
    add-int/lit8 v0, v0, -0x1

    .line 32
    if-ltz v0, :cond_1

    .line 34
    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 37
    move-result-object v1

    .line 38
    check-cast v1, Landroid/view/WindowInsetsAnimation;

    .line 40
    invoke-virtual {p0, v1}, La_8E6962EF;->a(Landroid/view/WindowInsetsAnimation;)Lvz;

    .line 43
    move-result-object v2

    .line 44
    invoke-static {v1}, Lq;->v(Landroid/view/WindowInsetsAnimation;)F

    .line 47
    move-result v1

    .line 48
    iget-object v3, v2, Lvz;->a:La_D130B818;

    .line 50
    invoke-virtual {v3, v1}, La_D130B818;->d(F)V

    .line 53
    iget-object v1, p0, La_8E6962EF;->c:Ljava/util/ArrayList;

    .line 55
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    # ep-sqhjqhozkjje
    .line 58
    goto :goto_1

    .line 59
    :cond_1
    iget-object p2, p0, La_8E6962EF;->a:La_721461FA;

    .line 61
    const/4 v0, 0x0

    .line 62
    invoke-static {v0, p1}, Lwz;->h(Landroid/view/View;Landroid/view/WindowInsets;)Lwz;

    .line 65
    move-result-object p1

    .line 66
    iget-object v0, p0, La_8E6962EF;->b:Ljava/util/List;

    .line 68
    invoke-virtual {p2, p1, v0}, La_721461FA;->a(Lwz;Ljava/util/List;)Lwz;

    .line 71
    invoke-virtual {p1}, Lwz;->g()Landroid/view/WindowInsets;

    .line 74
    move-result-object p1

    .line 75
    return-object p1
.end method

.method public final onStart(Landroid/view/WindowInsetsAnimation;Landroid/view/WindowInsetsAnimation$Bounds;)Landroid/view/WindowInsetsAnimation$Bounds;
    .locals 3

    .line 1
    iget-object v0, p0, La_8E6962EF;->a:La_721461FA;

    .line 3
    invoke-virtual {p0, p1}, La_8E6962EF;->a(Landroid/view/WindowInsetsAnimation;)Lvz;

    .line 6
    new-instance p1, La_77619563;

    .line 8
    invoke-direct {p1, p2}, La_77619563;-><init>(Landroid/view/WindowInsetsAnimation$Bounds;)V

    # ep-zwvtrnafhlrk
    .line 11
    # ep-rcavvrxujlin
    check-cast v0, Lji;

    # ep-tjikxjrvwrqs
    .line 13
    iget-object p2, v0, Lji;->c:Landroid/view/View;

    .line 15
    iget-object v1, v0, Lji;->f:[I

    .line 17
    invoke-virtual {p2, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 20
    const/4 v2, 0x1

    .line 21
    aget v1, v1, v2

    .line 23
    iget v2, v0, Lji;->d:I

    .line 25
    sub-int/2addr v2, v1

    .line 26
    iput v2, v0, Lji;->e:I

    .line 28
    int-to-float v0, v2

    .line 29
    # ep-konudrgvzfsn
    invoke-virtual {p2, v0}, Landroid/view/View;->setTranslationY(F)V

    .line 32
    invoke-static {p1}, La_A84EAB6D;->e(La_77619563;)Landroid/view/WindowInsetsAnimation$Bounds;

    .line 35
    move-result-object p1

    .line 36
    return-object p1
.end method
