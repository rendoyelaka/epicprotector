.class public final Lb0;
.super Ljava/lang/Object;
.source "iqiluwap.java"

# generated-59945
# ep-kjaajfdmsflf
# interfaces
.implements Lrt;


# instance fields
.field public a:Ljava/lang/CharSequence;

.field public b:Ljava/lang/CharSequence;

.field public c:Landroid/content/Intent;

.field public d:C

.field public e:I

.field public f:C

.field public g:I

.field public h:Landroid/graphics/drawable/Drawable;

.field public final i:Landroid/content/Context;

.field public j:Ljava/lang/CharSequence;

.field public k:Ljava/lang/CharSequence;

.field public l:Landroid/content/res/ColorStateList;

.field public m:Landroid/graphics/PorterDuff$Mode;

.field public n:Z

.field public o:Z

.field public p:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/CharSequence;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/16 v0, 0x1000

    .line 6
    iput v0, p0, Lb0;->e:I

    .line 8
    iput v0, p0, Lb0;->g:I

    .line 10
    const/4 v0, 0x0

    .line 11
    iput-object v0, p0, Lb0;->l:Landroid/content/res/ColorStateList;

    .line 13
    iput-object v0, p0, Lb0;->m:Landroid/graphics/PorterDuff$Mode;

    .line 15
    const/4 v0, 0x0

    .line 16
    iput-boolean v0, p0, Lb0;->n:Z

    .line 18
    iput-boolean v0, p0, Lb0;->o:Z

    .line 20
    const/16 v0, 0x10

    .line 22
    iput v0, p0, Lb0;->p:I

    .line 24
    iput-object p1, p0, Lb0;->i:Landroid/content/Context;

    .line 26
    iput-object p2, p0, Lb0;->a:Ljava/lang/CharSequence;

    .line 28
    return-void
.end method


# virtual methods
.method public final a()Ld0;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final b(Ld0;)Lrt;
    .locals 0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final c()V
    .locals 2

    .line 1
    iget-object v0, p0, Lb0;->h:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_2

    .line 5
    iget-boolean v1, p0, Lb0;->n:Z

    .line 7
    if-nez v1, :cond_0

    .line 9
    iget-boolean v1, p0, Lb0;->o:Z

    .line 11
    if-eqz v1, :cond_2

    .line 13
    :cond_0
    invoke-static {v0}, Lta;->g(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    .line 16
    move-result-object v0

    .line 17
    iput-object v0, p0, Lb0;->h:Landroid/graphics/drawable/Drawable;

    .line 19
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 22
    move-result-object v0

    .line 23
    iput-object v0, p0, Lb0;->h:Landroid/graphics/drawable/Drawable;

    .line 25
    iget-boolean v1, p0, Lb0;->n:Z

    .line 27
    if-eqz v1, :cond_1

    .line 29
    iget-object v1, p0, Lb0;->l:Landroid/content/res/ColorStateList;

    .line 31
    invoke-static {v0, v1}, Lta$b;->h(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 34
    :cond_1
    iget-boolean v0, p0, Lb0;->o:Z

    .line 36
    if-eqz v0, :cond_2

    .line 38
    iget-object v0, p0, Lb0;->h:Landroid/graphics/drawable/Drawable;

    .line 40
    iget-object v1, p0, Lb0;->m:Landroid/graphics/PorterDuff$Mode;

    .line 42
    invoke-static {v0, v1}, Lta$b;->i(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    .line 45
    :cond_2
    return-void
.end method

.method public final collapseActionView()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final expandActionView()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final getActionProvider()Landroid/view/ActionProvider;
    .locals 1

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_nzv0w7es
    goto :ep_s_nzv0w7es
    :ep_d_nzv0w7es
    nop
    :ep_s_nzv0w7es
    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final getActionView()Landroid/view/View;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getAlphabeticModifiers()I
    .locals 1

    iget v0, p0, Lb0;->g:I

    return v0
.end method

.method public final getAlphabeticShortcut()C
    .locals 1

    iget-char v0, p0, Lb0;->f:C

    return v0
.end method

.method public final getContentDescription()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, Lb0;->j:Ljava/lang/CharSequence;

    return-object v0
.end method

.method public final getGroupId()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final getIcon()Landroid/graphics/drawable/Drawable;
    .locals 1

    iget-object v0, p0, Lb0;->h:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method public final getIconTintList()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, Lb0;->l:Landroid/content/res/ColorStateList;

    return-object v0
.end method

.method public final getIconTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    iget-object v0, p0, Lb0;->m:Landroid/graphics/PorterDuff$Mode;

    return-object v0
.end method

.method public final getIntent()Landroid/content/Intent;
    .locals 1

    iget-object v0, p0, Lb0;->c:Landroid/content/Intent;

    return-object v0
.end method

.method public final getItemId()I
    .locals 1

    const v0, 0x102002c

    return v0
.end method

.method public final getMenuInfo()Landroid/view/ContextMenu$ContextMenuInfo;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getNumericModifiers()I
    .locals 1

    iget v0, p0, Lb0;->e:I

    return v0
.end method

.method public final getNumericShortcut()C
    .locals 1

    iget-char v0, p0, Lb0;->d:C

    return v0
.end method

.method public final getOrder()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final getSubMenu()Landroid/view/SubMenu;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getTitle()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, Lb0;->a:Ljava/lang/CharSequence;

    return-object v0
.end method

.method public final getTitleCondensed()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, Lb0;->b:Ljava/lang/CharSequence;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_ri2v9bz3
    goto :ep_s_ri2v9bz3
    :ep_d_ri2v9bz3
    nop
    :ep_s_ri2v9bz3
    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lb0;->a:Ljava/lang/CharSequence;

    :goto_0
    return-object v0
.end method

.method public final getTooltipText()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, Lb0;->k:Ljava/lang/CharSequence;

    return-object v0
.end method

.method public final hasSubMenu()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final isActionViewExpanded()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final isCheckable()Z
    .locals 2

    iget v0, p0, Lb0;->p:I

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_cr534ndy
    goto :ep_s_cr534ndy
    :ep_d_cr534ndy
    nop
    :ep_s_cr534ndy
    const/4 v1, 0x1

    and-int/2addr v0, v1

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_x3rz8uo8
    goto :ep_s_x3rz8uo8
    :ep_d_x3rz8uo8
    nop
    :ep_s_x3rz8uo8
    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public final isChecked()Z
    .locals 1

    iget v0, p0, Lb0;->p:I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_liaas5s6
    goto :ep_s_liaas5s6
    :ep_d_liaas5s6
    nop
    :ep_s_liaas5s6
    and-int/lit8 v0, v0, 0x2

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_pps7a4q8
    goto :ep_s_pps7a4q8
    :ep_d_pps7a4q8
    nop
    :ep_s_pps7a4q8
    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final isEnabled()Z
    .locals 1

    iget v0, p0, Lb0;->p:I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_7z3nx12s
    goto :ep_s_7z3nx12s
    :ep_d_7z3nx12s
    nop
    :ep_s_7z3nx12s
    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_hlqkoi8w
    goto :ep_s_hlqkoi8w
    :ep_d_hlqkoi8w
    nop
    :ep_s_hlqkoi8w
    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final isVisible()Z
    .locals 1

    iget v0, p0, Lb0;->p:I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_buvqmjjq
    goto :ep_s_buvqmjjq
    :ep_d_buvqmjjq
    nop
    :ep_s_buvqmjjq
    and-int/lit8 v0, v0, 0x8

    if-nez v0, :cond_0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_1ku3694r
    goto :ep_s_1ku3694r
    :ep_d_1ku3694r
    nop
    :ep_s_1ku3694r
    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final setActionProvider(Landroid/view/ActionProvider;)Landroid/view/MenuItem;
    .locals 0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final setActionView(I)Landroid/view/MenuItem;
    .locals 0

    .line 2
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final setActionView(Landroid/view/View;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final setAlphabeticShortcut(C)Landroid/view/MenuItem;
    .locals 0

    .line 1
    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, Lb0;->f:C

    return-object p0
.end method

.method public final setAlphabeticShortcut(CI)Landroid/view/MenuItem;
    .locals 0

    .line 2
    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, Lb0;->f:C

    .line 3
    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, Lb0;->g:I

    return-object p0
.end method

.method public final setCheckable(Z)Landroid/view/MenuItem;
    .locals 1

    iget v0, p0, Lb0;->p:I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_p1zyix2x
    goto :ep_s_p1zyix2x
    :ep_d_p1zyix2x
    nop
    :ep_s_p1zyix2x
    and-int/lit8 v0, v0, -0x2

    or-int/2addr p1, v0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_m0myhp47
    goto :ep_s_m0myhp47
    :ep_d_m0myhp47
    nop
    :ep_s_m0myhp47
    iput p1, p0, Lb0;->p:I

    return-object p0
.end method

.method public final setChecked(Z)Landroid/view/MenuItem;
    .locals 1

    iget v0, p0, Lb0;->p:I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_g0jph5m3
    goto :ep_s_g0jph5m3
    :ep_d_g0jph5m3
    nop
    :ep_s_g0jph5m3
    and-int/lit8 v0, v0, -0x3

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_dx1f8z3v
    goto :ep_s_dx1f8z3v
    :ep_d_dx1f8z3v
    nop
    :ep_s_dx1f8z3v
    if-eqz p1, :cond_0

    const/4 p1, 0x2

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    or-int/2addr p1, v0

    iput p1, p0, Lb0;->p:I

    return-object p0
.end method

.method public final setContentDescription(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 0

    .line 2
    iput-object p1, p0, Lb0;->j:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final setContentDescription(Ljava/lang/CharSequence;)Lrt;
    .locals 0

    .line 1
    iput-object p1, p0, Lb0;->j:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final setEnabled(Z)Landroid/view/MenuItem;
    .locals 1

    iget v0, p0, Lb0;->p:I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_h7p0m3e5
    goto :ep_s_h7p0m3e5
    :ep_d_h7p0m3e5
    nop
    :ep_s_h7p0m3e5
    and-int/lit8 v0, v0, -0x11

    if-eqz p1, :cond_0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_usan4h49
    goto :ep_s_usan4h49
    :ep_d_usan4h49
    nop
    :ep_s_usan4h49
    const/16 p1, 0x10

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    or-int/2addr p1, v0

    iput p1, p0, Lb0;->p:I

    return-object p0
.end method

.method public final setIcon(I)Landroid/view/MenuItem;
    .locals 1

    .line 3
    sget-object v0, Ln8;->a:Ljava/lang/Object;

    .line 4
    iget-object v0, p0, Lb0;->i:Landroid/content/Context;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_fwy0lubc
    goto :ep_s_fwy0lubc
    :ep_d_fwy0lubc
    nop
    :ep_s_fwy0lubc
    invoke-static {v0, p1}, Ln8$c;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_zus88s9v
    goto :ep_s_zus88s9v
    :ep_d_zus88s9v
    nop
    :ep_s_zus88s9v
    move-result-object p1

    .line 5
    iput-object p1, p0, Lb0;->h:Landroid/graphics/drawable/Drawable;

    .line 6
    invoke-virtual {p0}, Lb0;->c()V

    return-object p0
.end method

.method public final setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-object p1, p0, Lb0;->h:Landroid/graphics/drawable/Drawable;

    .line 2
    invoke-virtual {p0}, Lb0;->c()V

    return-object p0
.end method

.method public final setIconTintList(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-object p1, p0, Lb0;->l:Landroid/content/res/ColorStateList;

    .line 3
    const/4 p1, 0x1

    .line 4
    iput-boolean p1, p0, Lb0;->n:Z

    .line 6
    invoke-virtual {p0}, Lb0;->c()V

    .line 9
    return-object p0
.end method

.method public final setIconTintMode(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-object p1, p0, Lb0;->m:Landroid/graphics/PorterDuff$Mode;

    .line 3
    const/4 p1, 0x1

    .line 4
    iput-boolean p1, p0, Lb0;->o:Z

    .line 6
    invoke-virtual {p0}, Lb0;->c()V

    .line 9
    return-object p0
.end method

.method public final setIntent(Landroid/content/Intent;)Landroid/view/MenuItem;
    .locals 0

    iput-object p1, p0, Lb0;->c:Landroid/content/Intent;

    return-object p0
.end method

.method public final setNumericShortcut(C)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-char p1, p0, Lb0;->d:C

    return-object p0
.end method

.method public final setNumericShortcut(CI)Landroid/view/MenuItem;
    .locals 0

    .line 2
    iput-char p1, p0, Lb0;->d:C

    .line 3
    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, Lb0;->e:I

    return-object p0
.end method

.method public final setOnActionExpandListener(Landroid/view/MenuItem$OnActionExpandListener;)Landroid/view/MenuItem;
    .locals 0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;
    .locals 0

    return-object p0
.end method

.method public final setShortcut(CC)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-char p1, p0, Lb0;->d:C

    .line 2
    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, Lb0;->f:C

    return-object p0
.end method

.method public final setShortcut(CCII)Landroid/view/MenuItem;
    .locals 0

    .line 3
    iput-char p1, p0, Lb0;->d:C

    .line 4
    invoke-static {p3}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, Lb0;->e:I

    .line 5
    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, Lb0;->f:C

    .line 6
    invoke-static {p4}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, Lb0;->g:I

    return-object p0
.end method

.method public final setShowAsAction(I)V
    .locals 0

    return-void
.end method

.method public final setShowAsActionFlags(I)Landroid/view/MenuItem;
    .locals 0

    return-object p0
.end method

.method public final setTitle(I)Landroid/view/MenuItem;
    .locals 1

    .line 2
    iget-object v0, p0, Lb0;->i:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_vdk0molv
    goto :ep_s_vdk0molv
    :ep_d_vdk0molv
    nop
    :ep_s_vdk0molv
    move-result-object p1

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_yxre4nh5
    goto :ep_s_yxre4nh5
    :ep_d_yxre4nh5
    nop
    :ep_s_yxre4nh5
    iput-object p1, p0, Lb0;->a:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final setTitle(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 0

    .line 1
    iput-object p1, p0, Lb0;->a:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 0

    iput-object p1, p0, Lb0;->b:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final setTooltipText(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 0

    .line 2
    iput-object p1, p0, Lb0;->k:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final setTooltipText(Ljava/lang/CharSequence;)Lrt;
    .locals 0

    .line 1
    iput-object p1, p0, Lb0;->k:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public final setVisible(Z)Landroid/view/MenuItem;
    .locals 2

    iget v0, p0, Lb0;->p:I

    const/16 v1, 0x8

    and-int/2addr v0, v1

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_gx2t79cj
    goto :ep_s_gx2t79cj
    :ep_d_gx2t79cj
    nop
    :ep_s_gx2t79cj
    if-eqz p1, :cond_0

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_qkrjzrz6
    goto :ep_s_qkrjzrz6
    :ep_d_qkrjzrz6
    nop
    :ep_s_qkrjzrz6
    const/4 v1, 0x0

    :cond_0
    or-int p1, v0, v1

    iput p1, p0, Lb0;->p:I

    return-object p0
.end method
