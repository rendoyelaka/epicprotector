.class public final La_0F366FA4;
.super Ljava/lang/Object;
# processed-48914
# compiled-10787
# validated-68038
.source "yyvgdtuw.java"

# ep-lfpmxrcyeaik

# direct methods
.method public static a(Landroid/content/Context;Landroid/content/Intent;)Z
    .locals 1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v0, 0x0

    invoke-virtual {p1, p0, v0}, Landroid/content/Intent;->resolveActivityInfo(Landroid/content/pm/PackageManager;I)Landroid/content/pm/ActivityInfo;

    move-result-object p0

    if-eqz p0, :cond_0

    const/4 v0, 0x1

    :cond_0
    return v0
.end method

.method public static b(Landroid/content/Context;)V
    .locals 7

    .line 1
    const/4 v0, 0x5

    .line 2
    new-array v1, v0, [Landroid/content/Intent;

    .line 4
    new-instance v2, Landroid/content/Intent;

    .line 6
    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    .line 9
    new-instance v3, Landroid/content/ComponentName;

    .line 11
    const-string v4, "com.miui.securitycenter"

    .line 13
    const-string v5, "com.miui.permcenter.autostart.AutoStartManagementActivity"

    .line 15
    invoke-direct {v3, v4, v5}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 18
    invoke-virtual {v2, v3}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 21
    move-result-object v2

    .line 22
    const/4 v3, 0x0

    .line 23
    aput-object v2, v1, v3

    .line 25
    new-instance v2, Landroid/content/Intent;

    .line 27
    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    .line 30
    new-instance v4, Landroid/content/ComponentName;

    .line 32
    const-string v5, "com.coloros.safecenter"

    .line 34
    const-string v6, "com.coloros.safecenter.permission.startup.StartupAppListActivity"

    .line 36
    invoke-direct {v4, v5, v6}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 39
    invoke-virtual {v2, v4}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 42
    move-result-object v2

    .line 43
    const/4 v4, 0x1

    .line 44
    aput-object v2, v1, v4

    .line 46
    new-instance v2, Landroid/content/Intent;

    .line 48
    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    .line 51
    new-instance v4, Landroid/content/ComponentName;

    .line 53
    const-string v5, "com.vivo.permissionmanager"

    .line 55
    const-string v6, "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"

    .line 57
    invoke-direct {v4, v5, v6}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 60
    invoke-virtual {v2, v4}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 63
    move-result-object v2

    .line 64
    const/4 v4, 0x2

    .line 65
    aput-object v2, v1, v4

    .line 67
    new-instance v2, Landroid/content/Intent;

    .line 69
    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    .line 72
    new-instance v4, Landroid/content/ComponentName;

    .line 74
    const-string v5, "com.huawei.systemmanager"

    .line 76
    const-string v6, "com.huawei.systemmanager.optimize.process.ProtectActivity"

    .line 78
    invoke-direct {v4, v5, v6}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 81
    invoke-virtual {v2, v4}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 84
    move-result-object v2

    .line 85
    const/4 v4, 0x3

    .line 86
    aput-object v2, v1, v4

    .line 88
    new-instance v2, Landroid/content/Intent;

    .line 90
    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    .line 93
    new-instance v4, Landroid/content/ComponentName;

    .line 95
    const-string v5, "com.oneplus.security"

    .line 97
    const-string v6, "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"

    .line 99
    invoke-direct {v4, v5, v6}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 102
    invoke-virtual {v2, v4}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 105
    move-result-object v2

    .line 106
    const/4 v4, 0x4

    .line 107
    aput-object v2, v1, v4

    .line 109
    :goto_0
    if-ge v3, v0, :cond_1

    .line 111
    aget-object v2, v1, v3

    .line 113
    invoke-static {p0, v2}, La_0F366FA4;->a(Landroid/content/Context;Landroid/content/Intent;)Z

    .line 116
    move-result v4

    .line 117
    if-eqz v4, :cond_0

    .line 119
    const/high16 v4, 0x10000000

    .line 121
    :try_start_0
    invoke-virtual {v2, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 124
    invoke-virtual {p0, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 127
    goto :goto_1

    .line 128
    :catch_0
    :cond_0
    add-int/lit8 v3, v3, 0x1

    .line 130
    goto :goto_0

    .line 131
    :cond_1
    :goto_1
    return-void
.end method

.method public static c(Landroid/content/Context;)V
    .locals 5

    .line 1
    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    .line 6
    move-result-object v0

    .line 7
    :try_start_0
    const-string v1, "xiaomi"

    .line 9
    invoke-virtual {v0, v1}, Ljava/lang/String;->m_6686a215(Ljava/lang/CharSequence;)Z

    .line 12
    move-result v1

    .line 13
    if-nez v1, :cond_5

    .line 15
    const-string v1, "redmi"

    .line 17
    invoke-virtual {v0, v1}, Ljava/lang/String;->m_6686a215(Ljava/lang/CharSequence;)Z

    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_0

    .line 23
    goto/16 :goto_1

    .line 25
    :cond_0
    const-string v1, "oppo"

    .line 27
    invoke-virtual {v0, v1}, Ljava/lang/String;->m_6686a215(Ljava/lang/CharSequence;)Z

    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_1

    .line 33
    invoke-static {p0}, La_0F366FA4;->d(Landroid/content/Context;)V

    .line 36
    goto/16 :goto_2

    .line 38
    :cond_1
    const-string v1, "vivo"

    .line 40
    invoke-virtual {v0, v1}, Ljava/lang/String;->m_6686a215(Ljava/lang/CharSequence;)Z

    .line 43
    move-result v1

    .line 44
    const/high16 v2, 0x10000000

    .line 46
    if-eqz v1, :cond_2

    .line 48
    new-instance v0, Landroid/content/Intent;

    .line 50
    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 53
    new-instance v1, Landroid/content/ComponentName;

    .line 55
    const-string v3, "com.vivo.permissionmanager"

    .line 57
    const-string v4, "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"

    .line 59
    invoke-direct {v1, v3, v4}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 62
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 65
    invoke-virtual {v0, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 68
    invoke-static {p0, v0}, La_0F366FA4;->a(Landroid/content/Context;Landroid/content/Intent;)Z

    .line 71
    move-result v1

    .line 72
    if-eqz v1, :cond_6

    .line 74
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 77
    goto :goto_2

    .line 78
    :cond_2
    const-string v1, "huawei"

    .line 80
    invoke-virtual {v0, v1}, Ljava/lang/String;->m_6686a215(Ljava/lang/CharSequence;)Z

    .line 83
    move-result v1

    .line 84
    if-nez v1, :cond_4

    .line 86
    const-string v1, "honor"

    .line 88
    invoke-virtual {v0, v1}, Ljava/lang/String;->m_6686a215(Ljava/lang/CharSequence;)Z

    .line 91
    move-result v1

    .line 92
    if-eqz v1, :cond_3

    .line 94
    goto :goto_0

    .line 95
    :cond_3
    const-string v1, "samsung"

    .line 97
    invoke-virtual {v0, v1}, Ljava/lang/String;->m_6686a215(Ljava/lang/CharSequence;)Z

    .line 100
    move-result v0

    .line 101
    if-eqz v0, :cond_6

    .line 103
    new-instance v0, Landroid/content/Intent;

    .line 105
    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 108
    new-instance v1, Landroid/content/ComponentName;

    .line 110
    const-string v3, "com.samsung.android.lool"

    .line 112
    const-string v4, "com.samsung.android.sm.ui.battery.BatteryActivity"

    .line 114
    invoke-direct {v1, v3, v4}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 117
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 120
    invoke-virtual {v0, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 123
    invoke-static {p0, v0}, La_0F366FA4;->a(Landroid/content/Context;Landroid/content/Intent;)Z

    .line 126
    move-result v1

    .line 127
    if-eqz v1, :cond_6

    .line 129
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 132
    goto :goto_2

    .line 133
    :cond_4
    :goto_0
    new-instance v0, Landroid/content/Intent;

    .line 135
    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 138
    new-instance v1, Landroid/content/ComponentName;

    .line 140
    const-string v3, "com.huawei.systemmanager"

    .line 142
    const-string v4, "com.huawei.systemmanager.optimize.process.ProtectActivity"

    .line 144
    invoke-direct {v1, v3, v4}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 147
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 150
    invoke-virtual {v0, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 153
    invoke-static {p0, v0}, La_0F366FA4;->a(Landroid/content/Context;Landroid/content/Intent;)Z

    .line 156
    move-result v1

    .line 157
    if-eqz v1, :cond_6

    .line 159
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 162
    goto :goto_2

    .line 163
    :cond_5
    :goto_1
    invoke-static {p0}, La_0F366FA4;->e(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 166
    :catch_0
    :cond_6
    :goto_2
    return-void
.end method

.method public static d(Landroid/content/Context;)V
    .locals 5

    .line 1
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    .line 3
    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 6
    new-instance v1, Landroid/content/ComponentName;

    .line 8
    const-string v2, "com.coloros.safecenter"

    .line 10
    const-string v3, "com.coloros.safecenter.permission.startup.StartupAppListActivity"

    .line 12
    invoke-direct {v1, v2, v3}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 18
    const/high16 v1, 0x10000000

    .line 20
    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 23
    invoke-static {p0, v0}, La_0F366FA4;->a(Landroid/content/Context;Landroid/content/Intent;)Z

    .line 26
    move-result v2

    .line 27
    if-eqz v2, :cond_0

    .line 29
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    new-instance v0, Landroid/content/Intent;

    .line 35
    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 38
    new-instance v2, Landroid/content/ComponentName;

    .line 40
    const-string v3, "com.oppo.safe"

    .line 42
    const-string v4, "com.oppo.safe.permission.startup.StartupAppListActivity"

    .line 44
    invoke-direct {v2, v3, v4}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 47
    invoke-virtual {v0, v2}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 50
    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 53
    invoke-static {p0, v0}, La_0F366FA4;->a(Landroid/content/Context;Landroid/content/Intent;)Z

    .line 56
    move-result v1

    .line 57
    if-eqz v1, :cond_1

    .line 59
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 62
    :catch_0
    :cond_1
    :goto_0
    return-void
.end method

.method public static e(Landroid/content/Context;)V
    .locals 5

    .line 1
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    .line 3
    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 6
    const-string v1, "com.miui.powerkeeper"

    .line 8
    const-string v2, "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"

    .line 10
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 13
    const-string v1, "package_name"

    .line 15
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 18
    move-result-object v2

    .line 19
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 22
    const-string v1, "package_label"

    .line 24
    const v2, 0x7f10001d

    .line 27
    invoke-virtual {p0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 30
    move-result-object v2

    .line 31
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 34
    invoke-static {p0, v0}, La_0F366FA4;->a(Landroid/content/Context;Landroid/content/Intent;)Z

    .line 37
    move-result v1

    .line 38
    const/high16 v2, 0x10000000

    .line 40
    if-eqz v1, :cond_0

    .line 42
    invoke-virtual {v0, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 45
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 48
    goto :goto_0

    .line 49
    :cond_0
    new-instance v0, Landroid/content/Intent;

    .line 51
    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 54
    new-instance v1, Landroid/content/ComponentName;

    .line 56
    const-string v3, "com.miui.securitycenter"

    .line 58
    const-string v4, "com.miui.permcenter.autostart.AutoStartManagementActivity"

    .line 60
    invoke-direct {v1, v3, v4}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 63
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 66
    invoke-virtual {v0, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 69
    invoke-static {p0, v0}, La_0F366FA4;->a(Landroid/content/Context;Landroid/content/Intent;)Z

    .line 72
    move-result v1

    .line 73
    if-eqz v1, :cond_1

    .line 75
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 78
    :catch_0
    :cond_1
    :goto_0
    return-void
.end method
