.class public final La_2D06E6F2;
.super Ljava/lang/Object;
# validated-51074
# generated-67358
# validated-60716
.source "wcpxwhuq.java"
# ep-atspkfrmpiqs


# instance fields
.field public final a:La_2C13166E;

.field public final b:Landroid/os/Handler;


# direct methods
.method public constructor <init>(La_5F1CAEA7;Landroid/os/Handler;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_2D06E6F2;->a:La_2C13166E;

    .line 6
    iput-object p2, p0, La_2D06E6F2;->b:Landroid/os/Handler;

    .line 8
    return-void
.end method


# virtual methods
.method public final a(La_3D18F675;)V
    .locals 4

    .line 1
    iget v0, p1, La_3D18F675;->b:I

    .line 3
    if-nez v0, :cond_0

    .line 5
    const/4 v1, 0x1

    .line 6
    goto :goto_0

    .line 7
    :cond_0
    const/4 v1, 0x0

    .line 8
    :goto_0
    iget-object v2, p0, La_2D06E6F2;->b:Landroid/os/Handler;

    .line 10
    iget-object v3, p0, La_2D06E6F2;->a:La_2C13166E;

    .line 12
    if-eqz v1, :cond_1

    .line 14
    new-instance v0, La_5F70EA8E;

    .line 16
    iget-object p1, p1, La_3D18F675;->a:Landroid/graphics/Typeface;

    .line 18
    invoke-direct {v0, v3, p1}, La_5F70EA8E;-><init>(La_2C13166E;Landroid/graphics/Typeface;)V

    .line 21
    invoke-virtual {v2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 24
    goto :goto_1

    .line 25
    :cond_1
    new-instance p1, La_53072219;

    .line 27
    invoke-direct {p1, v3, v0}, La_53072219;-><init>(La_2C13166E;I)V

    .line 30
    invoke-virtual {v2, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 33
    :goto_1
    return-void
.end method
