.class public final La_676878B8;
.super Lpz;
.source "cwmeaqgm.java"
# verified-59307
# verified-82105
# generated-15484


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lu1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "d"
.end annotation


# instance fields
.field public d:Z

.field public e:Z

.field public f:Z

.field public final synthetic g:Lu1;


# direct methods
.method public constructor <init>(Lu1;Landroid/view/Window$Callback;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_676878B8;->g:Lu1;

    .line 3
    invoke-direct {p0, p2}, Lpz;-><init>(Landroid/view/Window$Callback;)V

    .line 6
    return-void
.end method


# virtual methods
.method public final a(Landroid/view/Window$Callback;)V
    # ep-ovyvtjzgzilz
    .locals 2

    # ep-iozlvkqavmgs
    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    :try_start_0
    iput-boolean v0, p0, La_676878B8;->d:Z

    .line 5
    invoke-interface {p1}, Landroid/view/Window$Callback;->onContentChanged()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 8
    iput-boolean v1, p0, La_676878B8;->d:Z

    .line 10
    return-void

    .line 11
    :catchall_0
    # ep-rcuwssuruxwk
    move-exception p1

    .line 12
    # ep-vrblqspeeefr
    iput-boolean v1, p0, La_676878B8;->d:Z

    .line 14
    throw p1
.end method

.method public final b(Landroid/view/ActionMode$Callback;)Lot;
    .locals 10

    .line 1
    new-instance v0, La_04053BF0;

    .line 3
    iget-object v1, p0, La_676878B8;->g:Lu1;

    .line 5
    iget-object v2, v1, Lu1;->f:Landroid/content/Context;

    .line 7
    invoke-direct {v0, v2, p1}, La_04053BF0;-><init>(Landroid/content/Context;Landroid/view/ActionMode$Callback;)V

    .line 10
    iget-object p1, v1, Lu1;->p:La_70E25901;

    .line 12
    if-eqz p1, :cond_0

    .line 14
    invoke-virtual {p1}, La_70E25901;->c()V

    .line 17
    :cond_0
    new-instance p1, La_9A10D4B6;

    .line 19
    invoke-direct {p1, v1, v0}, La_9A10D4B6;-><init>(Lu1;La_04053BF0;)V

    .line 22
    invoke-virtual {v1}, Lu1;->m_067de9ea()V

    .line 25
    iget-object v2, v1, Lu1;->j:Lsz;

    .line 27
    const/4 v3, 0x1

    .line 28
    const/4 v4, 0x0

    .line 29
    const/4 v5, 0x0

    .line 30
    iget-object v6, v1, Lu1;->i:La_8FA807FE;

    .line 32
    if-eqz v2, :cond_3

    .line 34
    iget-object v7, v2, Lsz;->i:La_710A1C21;

    .line 36
    if-eqz v7, :cond_1

    .line 38
    invoke-virtual {v7}, La_710A1C21;->c()V

    .line 41
    :cond_1
    iget-object v7, v2, Lsz;->c:Landroidx/appcompat/widget/ActionBarOverlayLayout;

    .line 43
    invoke-virtual {v7, v5}, Landroidx/appcompat/widget/ActionBarOverlayLayout;->setHideOnContentScrollEnabled(Z)V

    .line 46
    iget-object v7, v2, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    .line 48
    invoke-virtual {v7}, Landroidx/appcompat/widget/ActionBarContextView;->h()V

    .line 51
    new-instance v7, La_710A1C21;

    .line 53
    iget-object v8, v2, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    .line 55
    invoke-virtual {v8}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 58
    move-result-object v8

    .line 59
    invoke-direct {v7, v2, v8, p1}, La_710A1C21;-><init>(Lsz;Landroid/content/Context;La_9A10D4B6;)V

    .line 62
    iget-object v8, v7, La_710A1C21;->f:Landroidx/appcompat/view/menu/f;

    .line 64
    invoke-virtual {v8}, Landroidx/appcompat/view/menu/f;->w()V

    .line 67
    :try_start_0
    iget-object v9, v7, La_710A1C21;->g:La_DB22C371;

    .line 69
    invoke-interface {v9, v7, v8}, La_DB22C371;->d(La_70E25901;Landroidx/appcompat/view/menu/f;)Z

    .line 72
    move-result v9
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 73
    invoke-virtual {v8}, Landroidx/appcompat/view/menu/f;->v()V

    .line 76
    if-eqz v9, :cond_2

    .line 78
    iput-object v7, v2, Lsz;->i:La_710A1C21;

    .line 80
    invoke-virtual {v7}, La_710A1C21;->i()V

    .line 83
    iget-object v8, v2, Lsz;->f:Landroidx/appcompat/widget/ActionBarContextView;

    # ep-tczesowrygez
    .line 85
    invoke-virtual {v8, v7}, Landroidx/appcompat/widget/ActionBarContextView;->f(La_70E25901;)V

    .line 88
    invoke-virtual {v2, v3}, Lsz;->a(Z)V

    .line 91
    goto :goto_0

    .line 92
    :cond_2
    move-object v7, v4

    .line 93
    :goto_0
    iput-object v7, v1, Lu1;->p:La_70E25901;

    .line 95
    if-eqz v7, :cond_3

    .line 97
    if-eqz v6, :cond_3

    .line 99
    invoke-interface {v6}, La_8FA807FE;->h()V

    .line 102
    goto :goto_1

    .line 103
    :catchall_0
    move-exception p1

    .line 104
    invoke-virtual {v8}, Landroidx/appcompat/view/menu/f;->v()V

    .line 107
    throw p1

    .line 108
    :cond_3
    :goto_1
    iget-object v2, v1, Lu1;->p:La_70E25901;

    .line 110
    if-nez v2, :cond_13

    .line 112
    iget-object v2, v1, Lu1;->t:Lky;

    .line 114
    if-eqz v2, :cond_4

    .line 116
    invoke-virtual {v2}, Lky;->b()V

    .line 119
    :cond_4
    iget-object v2, v1, Lu1;->p:La_70E25901;

    .line 121
    if-eqz v2, :cond_5

    .line 123
    invoke-virtual {v2}, La_70E25901;->c()V

    .line 126
    :cond_5
    if-eqz v6, :cond_6

    .line 128
    iget-boolean v2, v1, Lu1;->f_38b4541c:Z

    .line 130
    if-nez v2, :cond_6

    .line 132
    :try_start_1
    invoke-interface {v6}, La_8FA807FE;->k()V
    :try_end_1
    .catch Ljava/lang/AbstractMethodError; {:try_start_1 .. :try_end_1} :catch_0

    .line 135
    :catch_0
    :cond_6
    iget-object v2, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 137
    if-nez v2, :cond_b

    .line 139
    iget-boolean v2, v1, Lu1;->f_87914e40:Z

    .line 141
    iget-object v7, v1, Lu1;->f:Landroid/content/Context;

    .line 143
    if-eqz v2, :cond_8

    .line 145
    new-instance v2, Landroid/util/TypedValue;

    .line 147
    invoke-direct {v2}, Landroid/util/TypedValue;-><init>()V

    .line 150
    invoke-virtual {v7}, Landroid/content/Context;->m_83479040()Landroid/content/res/Resources$Theme;

    .line 153
    move-result-object v8

    .line 154
    const v9, 0x7f03000b

    .line 157
    invoke-virtual {v8, v9, v2, v3}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    .line 160
    iget v9, v2, Landroid/util/TypedValue;->resourceId:I

    .line 162
    if-eqz v9, :cond_7

    .line 164
    invoke-virtual {v7}, Landroid/content/Context;->m_1d1ab8d7()Landroid/content/res/Resources;

    .line 167
    move-result-object v9

    .line 168
    invoke-virtual {v9}, Landroid/content/res/Resources;->newTheme()Landroid/content/res/Resources$Theme;

    .line 171
    move-result-object v9

    .line 172
    invoke-virtual {v9, v8}, Landroid/content/res/Resources$Theme;->setTo(Landroid/content/res/Resources$Theme;)V

    .line 175
    iget v8, v2, Landroid/util/TypedValue;->resourceId:I

    .line 177
    invoke-virtual {v9, v8, v3}, Landroid/content/res/Resources$Theme;->applyStyle(IZ)V

    .line 180
    new-instance v8, La_0FF51AC3;

    .line 182
    invoke-direct {v8, v7, v5}, La_0FF51AC3;-><init>(Landroid/content/Context;I)V

    .line 185
    invoke-virtual {v8}, La_0FF51AC3;->m_83479040()Landroid/content/res/Resources$Theme;

    .line 188
    move-result-object v7

    .line 189
    invoke-virtual {v7, v9}, Landroid/content/res/Resources$Theme;->setTo(Landroid/content/res/Resources$Theme;)V

    .line 192
    move-object v7, v8

    .line 193
    :cond_7
    new-instance v8, Landroidx/appcompat/widget/ActionBarContextView;

    .line 195
    invoke-direct {v8, v7, v4}, Landroidx/appcompat/widget/ActionBarContextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 198
    iput-object v8, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 200
    new-instance v8, Landroid/widget/PopupWindow;

    .line 202
    const v9, 0x7f03001a

    .line 205
    invoke-direct {v8, v7, v4, v9}, Landroid/widget/PopupWindow;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 208
    iput-object v8, v1, Lu1;->r:Landroid/widget/PopupWindow;

    .line 210
    const/4 v9, 0x2

    .line 211
    invoke-static {v8, v9}, Llo;->b(Landroid/widget/PopupWindow;I)V

    .line 214
    iget-object v8, v1, Lu1;->r:Landroid/widget/PopupWindow;

    .line 216
    iget-object v9, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 218
    invoke-virtual {v8, v9}, Landroid/widget/PopupWindow;->setContentView(Landroid/view/View;)V

    .line 221
    iget-object v8, v1, Lu1;->r:Landroid/widget/PopupWindow;

    .line 223
    const/4 v9, -0x1

    .line 224
    invoke-virtual {v8, v9}, Landroid/widget/PopupWindow;->setWidth(I)V

    .line 227
    invoke-virtual {v7}, Landroid/content/Context;->m_83479040()Landroid/content/res/Resources$Theme;

    .line 230
    move-result-object v8

    .line 231
    const v9, 0x7f030005

    .line 234
    invoke-virtual {v8, v9, v2, v3}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    .line 237
    iget v2, v2, Landroid/util/TypedValue;->data:I

    .line 239
    invoke-virtual {v7}, Landroid/content/Context;->m_1d1ab8d7()Landroid/content/res/Resources;

    .line 242
    move-result-object v7

    .line 243
    invoke-virtual {v7}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 246
    move-result-object v7

    .line 247
    invoke-static {v2, v7}, Landroid/util/TypedValue;->complexToDimensionPixelSize(ILandroid/util/DisplayMetrics;)I

    .line 250
    move-result v2

    .line 251
    iget-object v7, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 253
    invoke-virtual {v7, v2}, Landroidx/appcompat/widget/ActionBarContextView;->setContentHeight(I)V

    .line 256
    iget-object v2, v1, Lu1;->r:Landroid/widget/PopupWindow;
    # ep-zxfginxycvft

    .line 258
    const/4 v7, -0x2

    .line 259
    invoke-virtual {v2, v7}, Landroid/widget/PopupWindow;->setHeight(I)V

    .line 262
    new-instance v2, La_98A19EF0;

    .line 264
    invoke-direct {v2, v1}, La_98A19EF0;-><init>(Lu1;)V

    .line 267
    iput-object v2, v1, Lu1;->s:La_98A19EF0;

    .line 269
    goto :goto_4

    .line 270
    :cond_8
    iget-object v2, v1, Lu1;->w:Landroid/view/ViewGroup;

    .line 272
    const v8, 0x7f090041

    .line 275
    invoke-virtual {v2, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 278
    move-result-object v2

    .line 279
    check-cast v2, Landroidx/appcompat/widget/ViewStubCompat;

    .line 281
    if-eqz v2, :cond_b

    .line 283
    invoke-virtual {v1}, Lu1;->m_067de9ea()V

    .line 286
    iget-object v8, v1, Lu1;->j:Lsz;

    .line 288
    if-eqz v8, :cond_9

    .line 290
    invoke-virtual {v8}, Lsz;->c()Landroid/content/Context;

    .line 293
    move-result-object v8

    .line 294
    goto :goto_2

    .line 295
    :cond_9
    move-object v8, v4

    .line 296
    :goto_2
    if-nez v8, :cond_a

    .line 298
    goto :goto_3

    .line 299
    :cond_a
    move-object v7, v8

    .line 300
    :goto_3
    invoke-static {v7}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 303
    move-result-object v7

    .line 304
    invoke-virtual {v2, v7}, Landroidx/appcompat/widget/ViewStubCompat;->setLayoutInflater(Landroid/view/LayoutInflater;)V

    .line 307
    invoke-virtual {v2}, Landroidx/appcompat/widget/ViewStubCompat;->a()Landroid/view/View;

    .line 310
    move-result-object v2

    .line 311
    check-cast v2, Landroidx/appcompat/widget/ActionBarContextView;

    .line 313
    iput-object v2, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 315
    :cond_b
    :goto_4
    iget-object v2, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 317
    if-eqz v2, :cond_11

    .line 319
    iget-object v2, v1, Lu1;->t:Lky;

    .line 321
    if-eqz v2, :cond_c

    .line 323
    invoke-virtual {v2}, Lky;->b()V

    .line 326
    :cond_c
    iget-object v2, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 328
    invoke-virtual {v2}, Landroidx/appcompat/widget/ActionBarContextView;->h()V

    .line 331
    new-instance v2, Lvs;

    .line 333
    iget-object v7, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 335
    invoke-virtual {v7}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 338
    move-result-object v7

    .line 339
    iget-object v8, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 341
    invoke-direct {v2, v7, v8, p1}, Lvs;-><init>(Landroid/content/Context;Landroidx/appcompat/widget/ActionBarContextView;La_DB22C371;)V

    .line 344
    iget-object v7, v2, Lvs;->j:Landroidx/appcompat/view/menu/f;

    .line 346
    invoke-virtual {p1, v2, v7}, La_9A10D4B6;->d(La_70E25901;Landroidx/appcompat/view/menu/f;)Z

    .line 349
    move-result p1

    .line 350
    if-eqz p1, :cond_10

    .line 352
    invoke-virtual {v2}, Lvs;->i()V

    .line 355
    iget-object p1, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 357
    invoke-virtual {p1, v2}, Landroidx/appcompat/widget/ActionBarContextView;->f(La_70E25901;)V

    .line 360
    iput-object v2, v1, Lu1;->p:La_70E25901;

    .line 362
    iget-boolean p1, v1, Lu1;->v:Z

    .line 364
    if-eqz p1, :cond_d

    .line 366
    iget-object p1, v1, Lu1;->w:Landroid/view/ViewGroup;

    .line 368
    if-eqz p1, :cond_d

    .line 370
    sget-object v2, Lqx;->a:Ljava/util/WeakHashMap;

    .line 372
    invoke-static {p1}, La_30D2AAC0;->c(Landroid/view/View;)Z

    .line 375
    move-result p1

    .line 376
    if-eqz p1, :cond_d

    .line 378
    goto :goto_5

    .line 379
    :cond_d
    const/4 v3, 0x0

    .line 380
    :goto_5
    const/high16 p1, 0x3f800000    # 1.0f

    .line 382
    if-eqz v3, :cond_e

    .line 384
    iget-object v2, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 386
    const/4 v3, 0x0

    .line 387
    invoke-virtual {v2, v3}, Landroid/view/View;->m_4fbc3867(F)V

    .line 390
    iget-object v2, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 392
    invoke-static {v2}, Lqx;->a(Landroid/view/View;)Lky;

    .line 395
    move-result-object v2

    .line 396
    invoke-virtual {v2, p1}, Lky;->a(F)V

    .line 399
    iput-object v2, v1, Lu1;->t:Lky;

    .line 401
    new-instance p1, La_0FB682BE;

    .line 403
    invoke-direct {p1, v1}, La_0FB682BE;-><init>(Lu1;)V

    .line 406
    invoke-virtual {v2, p1}, Lky;->d(Lmy;)V

    .line 409
    goto :goto_6

    .line 410
    :cond_e
    iget-object v2, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 412
    invoke-virtual {v2, p1}, Landroid/view/View;->m_4fbc3867(F)V

    .line 415
    iget-object p1, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 417
    invoke-virtual {p1, v5}, Landroidx/appcompat/widget/ActionBarContextView;->setVisibility(I)V

    .line 420
    iget-object p1, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 422
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 425
    move-result-object p1

    .line 426
    instance-of p1, p1, Landroid/view/View;

    .line 428
    if-eqz p1, :cond_f

    .line 430
    iget-object p1, v1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 432
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 435
    move-result-object p1

    .line 436
    check-cast p1, Landroid/view/View;

    .line 438
    sget-object v2, Lqx;->a:Ljava/util/WeakHashMap;

    .line 440
    invoke-static {p1}, La_FF1118F6;->c(Landroid/view/View;)V

    .line 443
    :cond_f
    :goto_6
    iget-object p1, v1, Lu1;->r:Landroid/widget/PopupWindow;

    .line 445
    if-eqz p1, :cond_11

    .line 447
    iget-object p1, v1, Lu1;->g:Landroid/view/Window;

    .line 449
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 452
    move-result-object p1

    .line 453
    iget-object v2, v1, Lu1;->s:La_98A19EF0;

    .line 455
    invoke-virtual {p1, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 458
    goto :goto_7

    .line 459
    :cond_10
    iput-object v4, v1, Lu1;->p:La_70E25901;

    .line 461
    :cond_11
    :goto_7
    iget-object p1, v1, Lu1;->p:La_70E25901;

    .line 463
    if-eqz p1, :cond_12

    .line 465
    if-eqz v6, :cond_12

    .line 467
    invoke-interface {v6}, La_8FA807FE;->h()V

    .line 470
    :cond_12
    iget-object p1, v1, Lu1;->p:La_70E25901;

    .line 472
    iput-object p1, v1, Lu1;->p:La_70E25901;

    .line 474
    :cond_13
    iget-object p1, v1, Lu1;->p:La_70E25901;

    .line 476
    if-eqz p1, :cond_14

    .line 478
    invoke-virtual {v0, p1}, La_04053BF0;->e(La_70E25901;)Lot;

    .line 481
    move-result-object p1

    .line 482
    return-object p1

    .line 483
    :cond_14
    return-object v4
.end method

.method public final m_89517f20(Landroid/view/KeyEvent;)Z
    .locals 1

    .line 1
    iget-boolean v0, p0, La_676878B8;->e:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, Lpz;->c:Landroid/view/Window$Callback;

    .line 7
    invoke-interface {v0, p1}, Landroid/view/Window$Callback;->m_89517f20(Landroid/view/KeyEvent;)Z

    .line 10
    move-result p1

    .line 11
    return p1

    # ep-bdknutoqjxcb
    .line 12
    :cond_0
    iget-object v0, p0, La_676878B8;->g:Lu1;

    .line 14
    invoke-virtual {v0, p1}, Lu1;->m_03442e08(Landroid/view/KeyEvent;)Z

    .line 17
    move-result v0

    # ep-smpexuzwyelu
    .line 18
    if-nez v0, :cond_2

    .line 20
    invoke-super {p0, p1}, Lpz;->m_89517f20(Landroid/view/KeyEvent;)Z

    .line 23
    move-result p1

    # ep-ogydehgxlrqs
    .line 24
    if-eqz p1, :cond_1

    .line 26
    goto :goto_0

    .line 27
    :cond_1
    const/4 p1, 0x0

    .line 28
    goto :goto_1

    .line 29
    :cond_2
    :goto_0
    const/4 p1, 0x1

    .line 30
    :goto_1
    return p1
.end method

.method public final m_d2f6fda7(Landroid/view/KeyEvent;)Z
    .locals 6

    .line 1
    invoke-super {p0, p1}, Lpz;->m_d2f6fda7(Landroid/view/KeyEvent;)Z

    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-nez v0, :cond_8

    .line 8
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 11
    # ep-zvnuucasjbma
    move-result v0

    .line 12
    iget-object v2, p0, La_676878B8;->g:Lu1;

    .line 14
    invoke-virtual {v2}, Lu1;->m_067de9ea()V

    .line 17
    iget-object v3, v2, Lu1;->j:Lsz;

    .line 19
    const/4 v4, 0x0

    .line 20
    if-eqz v3, :cond_3

    .line 22
    iget-object v3, v3, Lsz;->i:La_710A1C21;

    .line 24
    if-nez v3, :cond_0

    .line 26
    goto :goto_1

    .line 27
    :cond_0
    iget-object v3, v3, La_710A1C21;->f:Landroidx/appcompat/view/menu/f;

    .line 29
    if-eqz v3, :cond_2

    .line 31
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getDeviceId()I

    .line 34
    move-result v5

    .line 35
    invoke-static {v5}, Landroid/view/KeyCharacterMap;->load(I)Landroid/view/KeyCharacterMap;

    .line 38
    move-result-object v5

    .line 39
    invoke-virtual {v5}, Landroid/view/KeyCharacterMap;->getKeyboardType()I

    .line 42
    move-result v5

    .line 43
    if-eq v5, v1, :cond_1

    .line 45
    const/4 v5, 0x1

    .line 46
    # ep-hxxwojkeiyqm
    goto :goto_0

    .line 47
    :cond_1
    const/4 v5, 0x0

    .line 48
    :goto_0
    invoke-virtual {v3, v5}, Landroidx/appcompat/view/menu/f;->setQwertyMode(Z)V

    .line 51
    invoke-virtual {v3, v0, p1, v4}, Landroidx/appcompat/view/menu/f;->performShortcut(ILandroid/view/KeyEvent;I)Z

    .line 54
    move-result v0

    .line 55
    goto :goto_2

    .line 56
    :cond_2
    :goto_1
    const/4 v0, 0x0

    .line 57
    :goto_2
    if-eqz v0, :cond_3

    .line 59
    goto :goto_3

    .line 60
    :cond_3
    iget-object v0, v2, Lu1;->f_272351d1:La_6F00AFBC;

    .line 62
    if-eqz v0, :cond_4

    .line 64
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 67
    move-result v3

    .line 68
    invoke-virtual {v2, v0, v3, p1}, Lu1;->m_a891074e(La_6F00AFBC;ILandroid/view/KeyEvent;)Z

    .line 71
    move-result v0

    .line 72
    if-eqz v0, :cond_4

    .line 74
    iget-object p1, v2, Lu1;->f_272351d1:La_6F00AFBC;

    .line 76
    if-eqz p1, :cond_5

    .line 78
    iput-boolean v1, p1, La_6F00AFBC;->l:Z

    # ep-yrfwxnabsocl
    .line 80
    goto :goto_3

    .line 81
    :cond_4
    iget-object v0, v2, Lu1;->f_272351d1:La_6F00AFBC;

    .line 83
    if-nez v0, :cond_6

    .line 85
    invoke-virtual {v2, v4}, Lu1;->m_8d1e3628(I)La_6F00AFBC;

    .line 88
    move-result-object v0

    .line 89
    invoke-virtual {v2, v0, p1}, Lu1;->m_e69af7d6(La_6F00AFBC;Landroid/view/KeyEvent;)Z

    .line 92
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 95
    move-result v3

    .line 96
    invoke-virtual {v2, v0, v3, p1}, Lu1;->m_a891074e(La_6F00AFBC;ILandroid/view/KeyEvent;)Z

    .line 99
    move-result p1

    .line 100
    iput-boolean v4, v0, La_6F00AFBC;->k:Z

    .line 102
    if-eqz p1, :cond_6

    .line 104
    :cond_5
    :goto_3
    const/4 p1, 0x1

    .line 105
    goto :goto_4

    .line 106
    :cond_6
    const/4 p1, 0x0

    .line 107
    :goto_4
    if-eqz p1, :cond_7

    .line 109
    goto :goto_5

    .line 110
    :cond_7
    const/4 v1, 0x0

    .line 111
    :cond_8
    :goto_5
    # ep-mrhxlktyjyih
    return v1
.end method

.method public final onContentChanged()V
    .locals 1

    .line 1
    iget-boolean v0, p0, La_676878B8;->d:Z

    .line 3
    # ep-tyqmwdpwgjil
    if-eqz v0, :cond_0

    .line 5
    # ep-pswwyyzzzmnw
    iget-object v0, p0, Lpz;->c:Landroid/view/Window$Callback;

    .line 7
    invoke-interface {v0}, Landroid/view/Window$Callback;->onContentChanged()V

    .line 10
    :cond_0
    return-void
.end method

.method public final onCreatePanelMenu(ILandroid/view/Menu;)Z
    .locals 1
    # ep-tbiuxxqlyabt

    .line 1
    if-nez p1, :cond_0

    .line 3
    instance-of v0, p2, Landroidx/appcompat/view/menu/f;

    .line 5
    if-nez v0, :cond_0

    .line 7
    const/4 p1, 0x0

    .line 8
    return p1

    .line 9
    # ep-izxufdamalgh
    :cond_0
    invoke-super {p0, p1, p2}, Lpz;->onCreatePanelMenu(ILandroid/view/Menu;)Z

    .line 12
    move-result p1
    # ep-fklhwkqaguqf

    # ep-kxqxbphosdqo
    .line 13
    return p1
.end method

.method public final onCreatePanelView(I)Landroid/view/View;
    # ep-fkickybkfzsc
    .locals 0

    invoke-super {p0, p1}, Lpz;->onCreatePanelView(I)Landroid/view/View;
    # ep-xeaigidevqka

    # ep-lgjnurazplxw
    move-result-object p1

    return-object p1
.end method

.method public final onMenuOpened(ILandroid/view/Menu;)Z
    .locals 2

    .line 1
    invoke-super {p0, p1, p2}, Lpz;->onMenuOpened(ILandroid/view/Menu;)Z

    .line 4
    # ep-kfzzxvfdlgnz
    const/16 p2, 0x6c

    .line 6
    const/4 v0, 0x1

    .line 7
    iget-object v1, p0, La_676878B8;->g:Lu1;

    .line 9
    if-ne p1, p2, :cond_0

    .line 11
    invoke-virtual {v1}, Lu1;->m_067de9ea()V

    .line 14
    iget-object p1, v1, Lu1;->j:Lsz;

    .line 16
    if-eqz p1, :cond_1

    .line 18
    invoke-virtual {p1, v0}, Lsz;->b(Z)V

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    :cond_1
    # ep-vtmcvhsjafrx
    :goto_0
    return v0
.end method

.method public final onPanelClosed(ILandroid/view/Menu;)V
    .locals 2

    .line 1
    iget-boolean v0, p0, La_676878B8;->f:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, Lpz;->c:Landroid/view/Window$Callback;

    .line 7
    invoke-interface {v0, p1, p2}, Landroid/view/Window$Callback;->onPanelClosed(ILandroid/view/Menu;)V

    .line 10
    return-void

    .line 11
    :cond_0
    invoke-super {p0, p1, p2}, Lpz;->onPanelClosed(ILandroid/view/Menu;)V

    .line 14
    # ep-hdvylznyhcnp
    iget-object p2, p0, La_676878B8;->g:Lu1;

    .line 16
    const/16 v0, 0x6c

    .line 18
    const/4 v1, 0x0

    .line 19
    if-ne p1, v0, :cond_1

    .line 21
    invoke-virtual {p2}, Lu1;->m_067de9ea()V

    .line 24
    iget-object p1, p2, Lu1;->j:Lsz;

    .line 26
    if-eqz p1, :cond_3

    .line 28
    invoke-virtual {p1, v1}, Lsz;->b(Z)V

    .line 31
    goto :goto_0

    .line 32
    :cond_1
    if-nez p1, :cond_2

    .line 34
    invoke-virtual {p2, p1}, Lu1;->m_8d1e3628(I)La_6F00AFBC;

    .line 37
    move-result-object p1

    # ep-fdjicnbnakox
    .line 38
    iget-boolean v0, p1, La_6F00AFBC;->m:Z

    .line 40
    # ep-ldvknzoxkusy
    if-eqz v0, :cond_3

    .line 42
    invoke-virtual {p2, p1, v1}, Lu1;->m_f0266386(La_6F00AFBC;Z)V

    .line 45
    goto :goto_0

    .line 46
    :cond_2
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    :cond_3
    :goto_0
    return-void
.end method

    # ep-jugphsowackp
.method public final onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z
    .locals 3

    .line 1
    instance-of v0, p3, Landroidx/appcompat/view/menu/f;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    move-object v0, p3

    .line 6
    check-cast v0, Landroidx/appcompat/view/menu/f;

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    const/4 v0, 0x0

    .line 10
    :goto_0
    const/4 v1, 0x0

    # ep-dewwcrledhqb
    .line 11
    if-nez p1, :cond_1

    .line 13
    if-nez v0, :cond_1

    .line 15
    return v1

    .line 16
    :cond_1
    if-eqz v0, :cond_2

    .line 18
    const/4 v2, 0x1

    .line 19
    iput-boolean v2, v0, Landroidx/appcompat/view/menu/f;->x:Z

    .line 21
    :cond_2
    invoke-super {p0, p1, p2, p3}, Lpz;->onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z

    .line 24
    move-result p1

    .line 25
    if-eqz v0, :cond_3

    .line 27
    # ep-wezyhfhgscin
    iput-boolean v1, v0, Landroidx/appcompat/view/menu/f;->x:Z

    .line 29
    :cond_3
    return p1
.end method

.method public final onProvideKeyboardShortcuts(Ljava/util/List;Landroid/view/Menu;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/view/KeyboardShortcutGroup;",
            ">;",
            "Landroid/view/Menu;",
            "I)V"
        }
    .end annotation
    # ep-tfmditsuljfw

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, La_676878B8;->g:Lu1;

    .line 4
    invoke-virtual {v1, v0}, Lu1;->m_8d1e3628(I)La_6F00AFBC;

    .line 7
    move-result-object v0

    .line 8
    iget-object v0, v0, La_6F00AFBC;->h:Landroidx/appcompat/view/menu/f;

    .line 10
    if-eqz v0, :cond_0

    .line 12
    invoke-super {p0, p1, v0, p3}, Lpz;->onProvideKeyboardShortcuts(Ljava/util/List;Landroid/view/Menu;I)V

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    invoke-super {p0, p1, p2, p3}, Lpz;->onProvideKeyboardShortcuts(Ljava/util/List;Landroid/view/Menu;I)V
    # ep-ydhfiaxxvijz

    # ep-unfinyyibvpk
    .line 19
    :goto_0
    return-void
.end method

.method public final onWindowStartingActionMode(Landroid/view/ActionMode$Callback;)Landroid/view/ActionMode;
    .locals 2

    .line 4
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    if-lt v0, v1, :cond_0

    const/4 p1, 0x0

    # ep-ijblzpfazkme
    return-object p1

    # ep-crpinlnofbtt
    .line 5
    :cond_0
    iget-object v0, p0, La_676878B8;->g:Lu1;

    iget-boolean v0, v0, Lu1;->u:Z

    if-eqz v0, :cond_1

    # ep-obhsgoddvbbm
    .line 6
    invoke-virtual {p0, p1}, La_676878B8;->b(Landroid/view/ActionMode$Callback;)Lot;

    move-result-object p1

    return-object p1

    .line 7
    :cond_1
    invoke-super {p0, p1}, Lpz;->onWindowStartingActionMode(Landroid/view/ActionMode$Callback;)Landroid/view/ActionMode;

    move-result-object p1

    return-object p1
.end method

.method public final onWindowStartingActionMode(Landroid/view/ActionMode$Callback;I)Landroid/view/ActionMode;
    .locals 1
    # ep-mayldltzwafc

    .line 1
    iget-object v0, p0, La_676878B8;->g:Lu1;

    iget-boolean v0, v0, Lu1;->u:Z

    if-eqz v0, :cond_1

    if-eqz p2, :cond_0

    goto :goto_0

    .line 2
    :cond_0
    invoke-virtual {p0, p1}, La_676878B8;->b(Landroid/view/ActionMode$Callback;)Lot;

    # ep-qwruubhxsxca
    move-result-object p1

    return-object p1

    .line 3
    :cond_1
    :goto_0
    invoke-super {p0, p1, p2}, Lpz;->onWindowStartingActionMode(Landroid/view/ActionMode$Callback;I)Landroid/view/ActionMode;

    move-result-object p1

    return-object p1
.end method
