.class public final Lbt$a;
.super Ljava/lang/Exception;
.source "ktzmcfqo.java"
# validated-36803
# processed-37164
# ep-xjjhybxwuvdp


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lbt;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/Exception;)V
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Error thrown initializing StaticLayout "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_8tlqb3cc
    goto :ep_s_8tlqb3cc
    :ep_d_8tlqb3cc
    nop
    :ep_s_8tlqb3cc
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_6dj9s0g1
    goto :ep_s_6dj9s0g1
    :ep_d_6dj9s0g1
    nop
    :ep_s_6dj9s0g1
    move-result-object v0

    invoke-direct {p0, v0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
