.class public LFragment;
.super Ljava/lang/Object;
# optimised-54025
# processed-80635
.source "nztqghpl.java"
# ep-cirxafuiaohl

# interfaces
.implements Landroid/content/ComponentCallbacks;
.implements Landroid/view/View$OnCreateContextMenuListener;
.implements Lej;
.implements Ley;
.implements Lfg;
.implements Lfr;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LFragment$b;,
        LFragment$c;,
        LFragment$d;
    }
.end annotation


# static fields
.field public static final S:Ljava/lang/Object;


# instance fields
.field public A:Z

.field public B:Z

.field public C:Z

.field public final D:Z

.field public E:Z

.field public F:Landroid/view/ViewGroup;

.field public G:Landroid/view/View;

.field public H:Z

.field public I:Z

.field public J:LFragment$b;

.field public K:Z

.field public L:Z

.field public M:Landroidx/lifecycle/c$c;

.field public N:Landroidx/lifecycle/e;

.field public O:Lpe;

.field public final P:Lbm;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lbm<",
            "Lej;",
            ">;"
        }
    .end annotation
.end field

.field public Q:Ler;

.field public final R:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "LFragment$d;",
            ">;"
        }
    .end annotation
.end field

.field public c:I

.field public d:Landroid/os/Bundle;

.field public e:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Landroid/os/Parcelable;",
            ">;"
        }
    .end annotation
.end field

.field public f:Landroid/os/Bundle;

.field public g:Ljava/lang/String;

.field public h:Landroid/os/Bundle;

.field public i:LFragment;

.field public j:Ljava/lang/String;

.field public k:I

.field public l:Ljava/lang/Boolean;

.field public m:Z

.field public n:Z

.field public o:Z

.field public p:Z

.field public q:Z

.field public r:Z

.field public s:I

.field public t:Landroidx/fragment/app/m;

.field public u:Lae;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lae<",
            "*>;"
        }
    .end annotation
.end field

.field public v:Lde;

.field public w:LFragment;

.field public x:I

.field public y:I

.field public z:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LFragment;->S:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, -0x1

    .line 5
    iput v0, p0, LFragment;->c:I

    .line 7
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, LFragment;->g:Ljava/lang/String;

    .line 17
    const/4 v0, 0x0

    .line 18
    iput-object v0, p0, LFragment;->j:Ljava/lang/String;

    .line 20
    iput-object v0, p0, LFragment;->l:Ljava/lang/Boolean;

    .line 22
    new-instance v0, Lde;

    .line 24
    invoke-direct {v0}, Lde;-><init>()V

    .line 27
    iput-object v0, p0, LFragment;->v:Lde;

    .line 29
    const/4 v0, 0x1

    .line 30
    iput-boolean v0, p0, LFragment;->D:Z

    .line 32
    iput-boolean v0, p0, LFragment;->I:Z

    .line 34
    sget-object v0, Landroidx/lifecycle/c$c;->g:Landroidx/lifecycle/c$c;

    .line 36
    iput-object v0, p0, LFragment;->M:Landroidx/lifecycle/c$c;

    .line 38
    new-instance v0, Lbm;

    .line 40
    invoke-direct {v0}, Lbm;-><init>()V

    .line 43
    iput-object v0, p0, LFragment;->P:Lbm;

    .line 45
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 47
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    .line 50
    new-instance v0, Ljava/util/ArrayList;

    .line 52
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 55
    iput-object v0, p0, LFragment;->R:Ljava/util/ArrayList;

    .line 57
    new-instance v0, Landroidx/lifecycle/e;

    .line 59
    invoke-direct {v0, p0}, Landroidx/lifecycle/e;-><init>(Lej;)V

    .line 62
    iput-object v0, p0, LFragment;->N:Landroidx/lifecycle/e;

    .line 64
    new-instance v0, Ler;

    .line 66
    invoke-direct {v0, p0}, Ler;-><init>(Lfr;)V

    .line 69
    iput-object v0, p0, LFragment;->Q:Ler;

    .line 71
    return-void
.end method


# virtual methods
.method public A(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    .locals 3

    .line 1
    iget-object v0, p0, LFragment;->v:Lde;

    .line 3
    invoke-virtual {v0}, Landroidx/fragment/app/m;->K()V

    .line 6
    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, LFragment;->r:Z

    .line 9
    new-instance v1, Lpe;

    .line 11
    invoke-virtual {p0}, LFragment;->j()Ldy;

    .line 14
    move-result-object v2

    .line 15
    invoke-direct {v1, v2}, Lpe;-><init>(Ldy;)V

    .line 18
    iput-object v1, p0, LFragment;->O:Lpe;

    .line 20
    invoke-virtual {p0, p1, p2, p3}, LFragment;->s(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;

    .line 23
    move-result-object p1

    .line 24
    iput-object p1, p0, LFragment;->G:Landroid/view/View;

    .line 26
    if-eqz p1, :cond_0

    .line 28
    iget-object p1, p0, LFragment;->O:Lpe;

    .line 30
    invoke-virtual {p1}, Lpe;->e()V

    .line 33
    iget-object p1, p0, LFragment;->G:Landroid/view/View;

    .line 35
    iget-object p2, p0, LFragment;->O:Lpe;

    .line 37
    const p3, 0x7f0901e9

    .line 40
    invoke-virtual {p1, p3, p2}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 43
    iget-object p1, p0, LFragment;->G:Landroid/view/View;

    .line 45
    iget-object p2, p0, LFragment;->O:Lpe;

    .line 47
    const p3, 0x7f0901ec

    .line 50
    invoke-virtual {p1, p3, p2}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 53
    iget-object p1, p0, LFragment;->G:Landroid/view/View;

    .line 55
    iget-object p2, p0, LFragment;->O:Lpe;

    .line 57
    const-string p3, "<this>"

    .line 59
    invoke-static {p3, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 62
    const p3, 0x7f0901eb

    .line 65
    invoke-virtual {p1, p3, p2}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 68
    iget-object p1, p0, LFragment;->P:Lbm;

    .line 70
    iget-object p2, p0, LFragment;->O:Lpe;

    .line 72
    invoke-virtual {p1, p2}, Lbm;->h(Ljava/lang/Object;)V

    .line 75
    goto :goto_1

    .line 76
    :cond_0
    iget-object p1, p0, LFragment;->O:Lpe;

    .line 78
    iget-object p1, p1, Lpe;->d:Landroidx/lifecycle/e;

    .line 80
    if-eqz p1, :cond_1

    .line 82
    goto :goto_0

    .line 83
    :cond_1
    const/4 v0, 0x0

    .line 84
    :goto_0
    if-nez v0, :cond_2

    .line 86
    const/4 p1, 0x0

    .line 87
    iput-object p1, p0, LFragment;->O:Lpe;

    .line 89
    :goto_1
    return-void

    .line 90
    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 92
    const-string p2, "Called getViewLifecycleOwner() but onCreateView() returned null"

    .line 94
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 97
    throw p1
.end method

.method public final B()V
    .locals 5

    .line 1
    iget-object v0, p0, LFragment;->v:Lde;

    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-virtual {v0, v1}, Landroidx/fragment/app/m;->s(I)V

    .line 7
    iget-object v0, p0, LFragment;->G:Landroid/view/View;

    .line 9
    if-eqz v0, :cond_0

    .line 11
    iget-object v0, p0, LFragment;->O:Lpe;

    .line 13
    invoke-virtual {v0}, Lpe;->e()V

    .line 16
    iget-object v0, v0, Lpe;->d:Landroidx/lifecycle/e;

    .line 18
    iget-object v0, v0, Landroidx/lifecycle/e;->b:Landroidx/lifecycle/c$c;

    .line 20
    sget-object v2, Landroidx/lifecycle/c$c;->e:Landroidx/lifecycle/c$c;

    .line 22
    invoke-virtual {v0, v2}, Landroidx/lifecycle/c$c;->a(Landroidx/lifecycle/c$c;)Z

    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_0

    .line 28
    iget-object v0, p0, LFragment;->O:Lpe;

    .line 30
    sget-object v2, Landroidx/lifecycle/c$b;->ON_DESTROY:Landroidx/lifecycle/c$b;

    .line 32
    invoke-virtual {v0, v2}, Lpe;->d(Landroidx/lifecycle/c$b;)V

    .line 35
    :cond_0
    iput v1, p0, LFragment;->c:I

    .line 37
    const/4 v0, 0x0

    .line 38
    iput-boolean v0, p0, LFragment;->E:Z

    .line 40
    invoke-virtual {p0}, LFragment;->t()V

    .line 43
    iget-boolean v1, p0, LFragment;->E:Z

    .line 45
    if-eqz v1, :cond_2

    .line 47
    invoke-interface {p0}, Ley;->j()Ldy;

    .line 50
    move-result-object v1

    .line 51
    new-instance v2, Lcy;

    .line 53
    sget-object v3, Lpj$b;->d:Lpj$b$a;

    .line 55
    invoke-direct {v2, v1, v3}, Lcy;-><init>(Ldy;Lcy$a;)V

    .line 58
    const-class v1, Lpj$b;

    .line 60
    invoke-virtual {v2, v1}, Lcy;->a(Ljava/lang/Class;)LViewModelProvider;

    .line 63
    move-result-object v1

    .line 64
    check-cast v1, Lpj$b;

    .line 66
    iget-object v1, v1, Lpj$b;->c:Lts;

    .line 68
    iget v2, v1, Lts;->e:I

    .line 70
    const/4 v3, 0x0

    .line 71
    :goto_0
    if-ge v3, v2, :cond_1

    .line 73
    iget-object v4, v1, Lts;->d:[Ljava/lang/Object;

    .line 75
    aget-object v4, v4, v3

    .line 77
    check-cast v4, Lpj$a;

    .line 79
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 82
    add-int/lit8 v3, v3, 0x1

    .line 84
    goto :goto_0

    .line 85
    :cond_1
    iput-boolean v0, p0, LFragment;->r:Z

    .line 87
    return-void

    .line 88
    :cond_2
    new-instance v0, Lnt;

    .line 90
    new-instance v1, Ljava/lang/StringBuilder;

    .line 92
    const-string v2, "Fragment "

    .line 94
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 97
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 100
    const-string v2, " did not call through to super.onDestroyView()"

    .line 102
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 105
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 108
    move-result-object v1

    .line 109
    invoke-direct {v0, v1}, Lnt;-><init>(Ljava/lang/String;)V

    .line 112
    throw v0
.end method

.method public final C()V
    .locals 1

    .line 1
    invoke-virtual {p0}, LFragment;->onLowMemory()V

    .line 4
    iget-object v0, p0, LFragment;->v:Lde;

    .line 6
    invoke-virtual {v0}, Landroidx/fragment/app/m;->l()V

    .line 9
    return-void
.end method

.method public final D(Z)V
    .locals 1

    iget-object v0, p0, LFragment;->v:Lde;

    invoke-virtual {v0, p1}, Landroidx/fragment/app/m;->m(Z)V

    return-void
.end method

.method public final E(Z)V
    .locals 1

    iget-object v0, p0, LFragment;->v:Lde;

    invoke-virtual {v0, p1}, Landroidx/fragment/app/m;->q(Z)V

    return-void
.end method

.method public final F()Z
    .locals 2

    .line 1
    iget-boolean v0, p0, LFragment;->A:Z

    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 6
    iget-object v0, p0, LFragment;->v:Lde;

    .line 8
    invoke-virtual {v0}, Landroidx/fragment/app/m;->r()Z

    .line 11
    move-result v0

    .line 12
    or-int/2addr v1, v0

    .line 13
    :cond_0
    return v1
.end method

.method public final G()Landroid/content/Context;
    .locals 3

    .line 1
    invoke-virtual {p0}, LFragment;->i()Landroid/content/Context;

    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    return-object v0

    .line 8
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 10
    new-instance v1, Ljava/lang/StringBuilder;

    .line 12
    const-string v2, "Fragment "

    .line 14
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 20
    const-string v2, " not attached to a context."

    .line 22
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 28
    move-result-object v1

    .line 29
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 32
    throw v0
.end method

.method public final H()Landroid/view/View;
    .locals 3

    .line 1
    iget-object v0, p0, LFragment;->G:Landroid/view/View;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-object v0

    .line 6
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 8
    new-instance v1, Ljava/lang/StringBuilder;

    .line 10
    const-string v2, "Fragment "

    .line 12
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 15
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 18
    const-string v2, " did not return a View from onCreateView() or this was called before onCreateView()."

    .line 20
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 26
    move-result-object v1

    .line 27
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 30
    throw v0
.end method

.method public final I(IIII)V
    .locals 1

    .line 1
    iget-object v0, p0, LFragment;->J:LFragment$b;

    .line 3
    if-nez v0, :cond_0

    .line 5
    if-nez p1, :cond_0

    .line 7
    if-nez p2, :cond_0

    .line 9
    if-nez p3, :cond_0

    .line 11
    if-nez p4, :cond_0

    .line 13
    return-void

    .line 14
    :cond_0
    invoke-virtual {p0}, LFragment;->f()LFragment$b;

    .line 17
    move-result-object v0

    .line 18
    iput p1, v0, LFragment$b;->b:I

    .line 20
    invoke-virtual {p0}, LFragment;->f()LFragment$b;

    .line 23
    move-result-object p1

    .line 24
    iput p2, p1, LFragment$b;->c:I

    .line 26
    invoke-virtual {p0}, LFragment;->f()LFragment$b;

    .line 29
    move-result-object p1

    .line 30
    iput p3, p1, LFragment$b;->d:I

    .line 32
    invoke-virtual {p0}, LFragment;->f()LFragment$b;

    .line 35
    move-result-object p1

    .line 36
    iput p4, p1, LFragment$b;->e:I

    .line 38
    return-void
.end method

.method public final J(Landroid/os/Bundle;)V
    .locals 2

    .line 1
    iget-object v0, p0, LFragment;->t:Landroidx/fragment/app/m;

    .line 3
    if-eqz v0, :cond_3

    .line 5
    iget-boolean v1, v0, Landroidx/fragment/app/m;->y:Z

    .line 7
    if-nez v1, :cond_1

    .line 9
    iget-boolean v0, v0, Landroidx/fragment/app/m;->z:Z

    .line 11
    if-eqz v0, :cond_0

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v0, 0x0

    .line 15
    goto :goto_1

    .line 16
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 17
    :goto_1
    if-nez v0, :cond_2

    .line 19
    goto :goto_2

    .line 20
    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 22
    const-string v0, "Fragment already added and state has been saved"

    .line 24
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 27
    throw p1

    .line 28
    :cond_3
    :goto_2
    iput-object p1, p0, LFragment;->h:Landroid/os/Bundle;

    .line 30
    return-void
.end method

.method public final b()LSavedStateRegistry;
    .locals 1

    .line 1
    iget-object v0, p0, LFragment;->Q:Ler;

    .line 3
    iget-object v0, v0, Ler;->b:LSavedStateRegistry;

    .line 5
    return-object v0
.end method

.method public d()Ln00;
    .locals 1

    new-instance v0, LFragment$a;

    invoke-direct {v0, p0}, LFragment$a;-><init>(LFragment;)V

    return-object v0
.end method

.method public final e(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .locals 4

    .line 1
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 4
    const-string v0, "mFragmentId=#"

    .line 6
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 9
    iget v0, p0, LFragment;->x:I

    .line 11
    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 18
    const-string v0, " mContainerId=#"

    .line 20
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 23
    iget v0, p0, LFragment;->y:I

    .line 25
    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 28
    move-result-object v0

    .line 29
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 32
    const-string v0, " mTag="

    .line 34
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 37
    iget-object v0, p0, LFragment;->z:Ljava/lang/String;

    .line 39
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 42
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 45
    const-string v0, "mState="

    .line 47
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 50
    iget v0, p0, LFragment;->c:I

    .line 52
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(I)V

    .line 55
    const-string v0, " mWho="

    .line 57
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 60
    iget-object v0, p0, LFragment;->g:Ljava/lang/String;

    .line 62
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 65
    const-string v0, " mBackStackNesting="

    .line 67
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 70
    iget v0, p0, LFragment;->s:I

    .line 72
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(I)V

    .line 75
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 78
    const-string v0, "mAdded="

    .line 80
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 83
    iget-boolean v0, p0, LFragment;->m:Z

    .line 85
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 88
    const-string v0, " mRemoving="

    .line 90
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 93
    iget-boolean v0, p0, LFragment;->n:Z

    .line 95
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 98
    const-string v0, " mFromLayout="

    .line 100
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 103
    iget-boolean v0, p0, LFragment;->o:Z

    .line 105
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 108
    const-string v0, " mInLayout="

    .line 110
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 113
    iget-boolean v0, p0, LFragment;->p:Z

    .line 115
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    .line 118
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 121
    const-string v0, "mHidden="

    .line 123
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 126
    iget-boolean v0, p0, LFragment;->A:Z

    .line 128
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 131
    const-string v0, " mDetached="

    .line 133
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 136
    iget-boolean v0, p0, LFragment;->B:Z

    .line 138
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 141
    const-string v0, " mMenuVisible="

    .line 143
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 146
    iget-boolean v0, p0, LFragment;->D:Z

    .line 148
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 151
    const-string v0, " mHasMenu="

    .line 153
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 156
    const/4 v0, 0x0

    .line 157
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    .line 160
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 163
    const-string v1, "mRetainInstance="

    .line 165
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 168
    iget-boolean v1, p0, LFragment;->C:Z

    .line 170
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Z)V

    .line 173
    const-string v1, " mUserVisibleHint="

    .line 175
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 178
    iget-boolean v1, p0, LFragment;->I:Z

    .line 180
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(Z)V

    .line 183
    iget-object v1, p0, LFragment;->t:Landroidx/fragment/app/m;

    .line 185
    if-eqz v1, :cond_0

    .line 187
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 190
    const-string v1, "mFragmentManager="

    .line 192
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 195
    iget-object v1, p0, LFragment;->t:Landroidx/fragment/app/m;

    .line 197
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 200
    :cond_0
    iget-object v1, p0, LFragment;->u:Lae;

    .line 202
    if-eqz v1, :cond_1

    .line 204
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 207
    const-string v1, "mHost="

    .line 209
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 212
    iget-object v1, p0, LFragment;->u:Lae;

    .line 214
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 217
    :cond_1
    iget-object v1, p0, LFragment;->w:LFragment;

    .line 219
    if-eqz v1, :cond_2

    .line 221
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 224
    const-string v1, "mParentFragment="

    .line 226
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 229
    iget-object v1, p0, LFragment;->w:LFragment;

    .line 231
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 234
    :cond_2
    iget-object v1, p0, LFragment;->h:Landroid/os/Bundle;

    .line 236
    if-eqz v1, :cond_3

    .line 238
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 241
    const-string v1, "mArguments="

    .line 243
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 246
    iget-object v1, p0, LFragment;->h:Landroid/os/Bundle;

    .line 248
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 251
    :cond_3
    iget-object v1, p0, LFragment;->d:Landroid/os/Bundle;

    .line 253
    if-eqz v1, :cond_4

    .line 255
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 258
    const-string v1, "mSavedFragmentState="

    .line 260
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 263
    iget-object v1, p0, LFragment;->d:Landroid/os/Bundle;

    .line 265
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 268
    :cond_4
    iget-object v1, p0, LFragment;->e:Landroid/util/SparseArray;

    .line 270
    if-eqz v1, :cond_5

    .line 272
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 275
    const-string v1, "mSavedViewState="

    .line 277
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 280
    iget-object v1, p0, LFragment;->e:Landroid/util/SparseArray;

    .line 282
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 285
    :cond_5
    iget-object v1, p0, LFragment;->f:Landroid/os/Bundle;

    .line 287
    if-eqz v1, :cond_6

    .line 289
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 292
    const-string v1, "mSavedViewRegistryState="

    .line 294
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 297
    iget-object v1, p0, LFragment;->f:Landroid/os/Bundle;

    .line 299
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 302
    :cond_6
    iget-object v1, p0, LFragment;->i:LFragment;

    .line 304
    const/4 v2, 0x0

    .line 305
    if-eqz v1, :cond_7

    .line 307
    goto :goto_0

    .line 308
    :cond_7
    iget-object v1, p0, LFragment;->t:Landroidx/fragment/app/m;

    .line 310
    if-eqz v1, :cond_8

    .line 312
    iget-object v3, p0, LFragment;->j:Ljava/lang/String;

    .line 314
    if-eqz v3, :cond_8

    .line 316
    invoke-virtual {v1, v3}, Landroidx/fragment/app/m;->A(Ljava/lang/String;)LFragment;

    .line 319
    move-result-object v1

    .line 320
    goto :goto_0

    .line 321
    :cond_8
    move-object v1, v2

    .line 322
    :goto_0
    if-eqz v1, :cond_9

    .line 324
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 327
    const-string v2, "mTarget="

    .line 329
    invoke-virtual {p3, v2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 332
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/Object;)V

    .line 335
    const-string v1, " mTargetRequestCode="

    .line 337
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 340
    iget v1, p0, LFragment;->k:I

    .line 342
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(I)V

    .line 345
    :cond_9
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 348
    const-string v1, "mPopDirection="

    .line 350
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 353
    iget-object v1, p0, LFragment;->J:LFragment$b;

    .line 355
    if-nez v1, :cond_a

    .line 357
    const/4 v1, 0x0

    .line 358
    goto :goto_1

    .line 359
    :cond_a
    iget-boolean v1, v1, LFragment$b;->a:Z

    .line 361
    :goto_1
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(Z)V

    .line 364
    iget-object v1, p0, LFragment;->J:LFragment$b;

    .line 366
    if-nez v1, :cond_b

    .line 368
    const/4 v1, 0x0

    .line 369
    goto :goto_2

    .line 370
    :cond_b
    iget v1, v1, LFragment$b;->b:I

    .line 372
    :goto_2
    if-eqz v1, :cond_d

    .line 374
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 377
    const-string v1, "getEnterAnim="

    .line 379
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 382
    iget-object v1, p0, LFragment;->J:LFragment$b;

    .line 384
    if-nez v1, :cond_c

    .line 386
    const/4 v1, 0x0

    .line 387
    goto :goto_3

    .line 388
    :cond_c
    iget v1, v1, LFragment$b;->b:I

    .line 390
    :goto_3
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(I)V

    .line 393
    :cond_d
    iget-object v1, p0, LFragment;->J:LFragment$b;

    .line 395
    if-nez v1, :cond_e

    .line 397
    const/4 v1, 0x0

    .line 398
    goto :goto_4

    .line 399
    :cond_e
    iget v1, v1, LFragment$b;->c:I

    .line 401
    :goto_4
    if-eqz v1, :cond_10

    .line 403
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 406
    const-string v1, "getExitAnim="

    .line 408
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 411
    iget-object v1, p0, LFragment;->J:LFragment$b;

    .line 413
    if-nez v1, :cond_f

    .line 415
    const/4 v1, 0x0

    .line 416
    goto :goto_5

    .line 417
    :cond_f
    iget v1, v1, LFragment$b;->c:I

    .line 419
    :goto_5
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(I)V

    .line 422
    :cond_10
    iget-object v1, p0, LFragment;->J:LFragment$b;

    .line 424
    if-nez v1, :cond_11

    .line 426
    const/4 v1, 0x0

    .line 427
    goto :goto_6

    .line 428
    :cond_11
    iget v1, v1, LFragment$b;->d:I

    .line 430
    :goto_6
    if-eqz v1, :cond_13

    .line 432
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 435
    const-string v1, "getPopEnterAnim="

    .line 437
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 440
    iget-object v1, p0, LFragment;->J:LFragment$b;

    .line 442
    if-nez v1, :cond_12

    .line 444
    const/4 v1, 0x0

    .line 445
    goto :goto_7

    .line 446
    :cond_12
    iget v1, v1, LFragment$b;->d:I

    .line 448
    :goto_7
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(I)V

    .line 451
    :cond_13
    iget-object v1, p0, LFragment;->J:LFragment$b;

    .line 453
    if-nez v1, :cond_14

    .line 455
    const/4 v1, 0x0

    .line 456
    goto :goto_8

    .line 457
    :cond_14
    iget v1, v1, LFragment$b;->e:I

    .line 459
    :goto_8
    if-eqz v1, :cond_16

    .line 461
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 464
    const-string v1, "getPopExitAnim="

    .line 466
    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 469
    iget-object v1, p0, LFragment;->J:LFragment$b;

    .line 471
    if-nez v1, :cond_15

    .line 473
    goto :goto_9

    .line 474
    :cond_15
    iget v0, v1, LFragment$b;->e:I

    .line 476
    :goto_9
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(I)V

    .line 479
    :cond_16
    iget-object v0, p0, LFragment;->F:Landroid/view/ViewGroup;

    .line 481
    if-eqz v0, :cond_17

    .line 483
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 486
    const-string v0, "mContainer="

    .line 488
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 491
    iget-object v0, p0, LFragment;->F:Landroid/view/ViewGroup;

    .line 493
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 496
    :cond_17
    iget-object v0, p0, LFragment;->G:Landroid/view/View;

    .line 498
    if-eqz v0, :cond_18

    .line 500
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 503
    const-string v0, "mView="

    .line 505
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 508
    iget-object v0, p0, LFragment;->G:Landroid/view/View;

    .line 510
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 513
    :cond_18
    iget-object v0, p0, LFragment;->J:LFragment$b;

    .line 515
    if-nez v0, :cond_19

    .line 517
    goto :goto_a

    .line 518
    :cond_19
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 521
    :goto_a
    invoke-virtual {p0}, LFragment;->i()Landroid/content/Context;

    .line 524
    move-result-object v0

    .line 525
    if-eqz v0, :cond_1a

    .line 527
    new-instance v0, Lpj;

    .line 529
    invoke-interface {p0}, Ley;->j()Ldy;

    .line 532
    move-result-object v1

    .line 533
    invoke-direct {v0, p0, v1}, Lpj;-><init>(Lej;Ldy;)V

    .line 536
    invoke-virtual {v0, p1, p3}, Lpj;->p(Ljava/lang/String;Ljava/io/PrintWriter;)V

    .line 539
    :cond_1a
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 542
    new-instance v0, Ljava/lang/StringBuilder;

    .line 544
    const-string v1, "Child "

    .line 546
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 549
    iget-object v1, p0, LFragment;->v:Lde;

    .line 551
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 554
    const-string v1, ":"

    .line 556
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 559
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 562
    move-result-object v0

    .line 563
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 566
    iget-object v0, p0, LFragment;->v:Lde;

    .line 568
    const-string v1, "  "

    .line 570
    invoke-static {p1, v1}, Lps;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 573
    move-result-object p1

    .line 574
    invoke-virtual {v0, p1, p2, p3, p4}, Landroidx/fragment/app/m;->t(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    .line 577
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 0

    invoke-super {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public final f()LFragment$b;
    .locals 1

    .line 1
    iget-object v0, p0, LFragment;->J:LFragment$b;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, LFragment$b;

    .line 7
    invoke-direct {v0}, LFragment$b;-><init>()V

    .line 10
    iput-object v0, p0, LFragment;->J:LFragment$b;

    .line 12
    :cond_0
    iget-object v0, p0, LFragment;->J:LFragment$b;

    .line 14
    return-object v0
.end method

.method public final g()Lb9;
    .locals 1

    sget-object v0, Lb9$a;->b:Lb9$a;

    return-object v0
.end method

.method public final h()Landroidx/fragment/app/m;
    .locals 3

    .line 1
    iget-object v0, p0, LFragment;->u:Lae;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, LFragment;->v:Lde;

    .line 7
    return-object v0

    .line 8
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 10
    new-instance v1, Ljava/lang/StringBuilder;

    .line 12
    const-string v2, "Fragment "

    .line 14
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 20
    const-string v2, " has not been attached yet."

    .line 22
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 28
    move-result-object v1

    .line 29
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 32
    throw v0
.end method

.method public final hashCode()I
    .locals 1

    invoke-super {p0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method

.method public final i()Landroid/content/Context;
    .locals 1

    .line 1
    iget-object v0, p0, LFragment;->u:Lae;

    .line 3
    if-nez v0, :cond_0

    .line 5
    const/4 v0, 0x0

    .line 6
    goto :goto_0

    .line 7
    :cond_0
    iget-object v0, v0, Lae;->d:Landroid/content/Context;

    .line 9
    :goto_0
    return-object v0
.end method

.method public final j()Ldy;
    .locals 3

    .line 1
    iget-object v0, p0, LFragment;->t:Landroidx/fragment/app/m;

    .line 3
    if-eqz v0, :cond_2

    .line 5
    invoke-virtual {p0}, LFragment;->k()I

    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x1

    .line 10
    if-eq v0, v1, :cond_1

    .line 12
    iget-object v0, p0, LFragment;->t:Landroidx/fragment/app/m;

    .line 14
    iget-object v0, v0, Landroidx/fragment/app/m;->F:LFragmentManagerViewModel;

    .line 16
    iget-object v0, v0, LFragmentManagerViewModel;->e:Ljava/util/HashMap;

    .line 18
    iget-object v1, p0, LFragment;->g:Ljava/lang/String;

    .line 20
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    move-result-object v1

    .line 24
    check-cast v1, Ldy;

    .line 26
    if-nez v1, :cond_0

    .line 28
    new-instance v1, Ldy;

    .line 30
    invoke-direct {v1}, Ldy;-><init>()V

    .line 33
    iget-object v2, p0, LFragment;->g:Ljava/lang/String;

    .line 35
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    :cond_0
    return-object v1

    .line 39
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 41
    const-string v1, "Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported"

    .line 43
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 46
    throw v0

    .line 47
    :cond_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 49
    const-string v1, "Can\'t access ViewModels from detached fragment"

    .line 51
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 54
    throw v0
.end method

.method public final k()I
    .locals 2

    .line 1
    iget-object v0, p0, LFragment;->M:Landroidx/lifecycle/c$c;

    .line 3
    sget-object v1, Landroidx/lifecycle/c$c;->d:Landroidx/lifecycle/c$c;

    .line 5
    if-eq v0, v1, :cond_1

    .line 7
    iget-object v1, p0, LFragment;->w:LFragment;

    .line 9
    if-nez v1, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 15
    move-result v0

    .line 16
    iget-object v1, p0, LFragment;->w:LFragment;

    .line 18
    invoke-virtual {v1}, LFragment;->k()I

    .line 21
    move-result v1

    .line 22
    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    .line 25
    move-result v0

    .line 26
    return v0

    .line 27
    :cond_1
    :goto_0
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 30
    move-result v0

    .line 31
    return v0
.end method

.method public final l()Landroidx/lifecycle/e;
    .locals 1

    iget-object v0, p0, LFragment;->N:Landroidx/lifecycle/e;

    return-object v0
.end method

.method public final m()Landroidx/fragment/app/m;
    .locals 3

    .line 1
    iget-object v0, p0, LFragment;->t:Landroidx/fragment/app/m;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-object v0

    .line 6
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 8
    new-instance v1, Ljava/lang/StringBuilder;

    .line 10
    const-string v2, "Fragment "

    .line 12
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 15
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 18
    const-string v2, " not associated with a fragment manager."

    .line 20
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 26
    move-result-object v1

    .line 27
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 30
    throw v0
.end method

.method public final n()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, LFragment;->J:LFragment$b;

    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 6
    return-object v1

    .line 7
    :cond_0
    iget-object v0, v0, LFragment$b;->j:Ljava/lang/Object;

    .line 9
    sget-object v2, LFragment;->S:Ljava/lang/Object;

    .line 11
    if-ne v0, v2, :cond_1

    .line 13
    goto :goto_0

    .line 14
    :cond_1
    move-object v1, v0

    .line 15
    :goto_0
    return-object v1
.end method

.method public final o()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, LFragment;->J:LFragment$b;

    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 6
    return-object v1

    .line 7
    :cond_0
    iget-object v0, v0, LFragment$b;->i:Ljava/lang/Object;

    .line 9
    sget-object v2, LFragment;->S:Ljava/lang/Object;

    .line 11
    if-ne v0, v2, :cond_1

    .line 13
    goto :goto_0

    .line 14
    :cond_1
    move-object v1, v0

    .line 15
    :goto_0
    return-object v1
.end method

.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 0

    const/4 p1, 0x1

    iput-boolean p1, p0, LFragment;->E:Z

    return-void
.end method

.method public final onCreateContextMenu(Landroid/view/ContextMenu;Landroid/view/View;Landroid/view/ContextMenu$ContextMenuInfo;)V
    .locals 1

    .line 1
    iget-object v0, p0, LFragment;->u:Lae;

    .line 3
    if-nez v0, :cond_0

    .line 5
    const/4 v0, 0x0

    .line 6
    goto :goto_0

    .line 7
    :cond_0
    iget-object v0, v0, Lae;->c:Landroid/app/Activity;

    .line 9
    check-cast v0, Landroidx/fragment/app/FragmentActivity;

    .line 11
    :goto_0
    if-eqz v0, :cond_1

    .line 13
    invoke-virtual {v0, p1, p2, p3}, Landroid/app/Activity;->onCreateContextMenu(Landroid/view/ContextMenu;Landroid/view/View;Landroid/view/ContextMenu$ContextMenuInfo;)V

    .line 16
    return-void

    .line 17
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 19
    new-instance p2, Ljava/lang/StringBuilder;

    .line 21
    const-string p3, "Fragment "

    .line 23
    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 26
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 29
    const-string p3, " not attached to an activity."

    .line 31
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 37
    move-result-object p2

    .line 38
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 41
    throw p1
.end method

.method public final onLowMemory()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, LFragment;->E:Z

    return-void
.end method

.method public final p()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, LFragment;->J:LFragment$b;

    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 6
    return-object v1

    .line 7
    :cond_0
    iget-object v0, v0, LFragment$b;->k:Ljava/lang/Object;

    .line 9
    sget-object v2, LFragment;->S:Ljava/lang/Object;

    .line 11
    if-ne v0, v2, :cond_1

    .line 13
    goto :goto_0

    .line 14
    :cond_1
    move-object v1, v0

    .line 15
    :goto_0
    return-object v1
.end method

.method public q(Landroid/content/Context;)V
    .locals 1

    .line 1
    const/4 p1, 0x1

    .line 2
    iput-boolean p1, p0, LFragment;->E:Z

    .line 4
    iget-object v0, p0, LFragment;->u:Lae;

    .line 6
    if-nez v0, :cond_0

    .line 8
    const/4 v0, 0x0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    iget-object v0, v0, Lae;->c:Landroid/app/Activity;

    .line 12
    :goto_0
    if-eqz v0, :cond_1

    .line 14
    iput-boolean p1, p0, LFragment;->E:Z

    .line 16
    :cond_1
    return-void
.end method

.method public r(Landroid/os/Bundle;)V
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, LFragment;->E:Z

    .line 4
    const/4 v1, 0x0

    .line 5
    if-eqz p1, :cond_0

    .line 7
    const-string v2, "android:support:fragments"

    .line 9
    invoke-virtual {p1, v2}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 12
    move-result-object p1

    .line 13
    if-eqz p1, :cond_0

    .line 15
    iget-object v2, p0, LFragment;->v:Lde;

    .line 17
    invoke-virtual {v2, p1}, Landroidx/fragment/app/m;->P(Landroid/os/Parcelable;)V

    .line 20
    iget-object p1, p0, LFragment;->v:Lde;

    .line 22
    iput-boolean v1, p1, Landroidx/fragment/app/m;->y:Z

    .line 24
    iput-boolean v1, p1, Landroidx/fragment/app/m;->z:Z

    .line 26
    iget-object v2, p1, Landroidx/fragment/app/m;->F:LFragmentManagerViewModel;

    .line 28
    iput-boolean v1, v2, LFragmentManagerViewModel;->h:Z

    .line 30
    invoke-virtual {p1, v0}, Landroidx/fragment/app/m;->s(I)V

    .line 33
    :cond_0
    iget-object p1, p0, LFragment;->v:Lde;

    .line 35
    iget v2, p1, Landroidx/fragment/app/m;->m:I

    .line 37
    if-lt v2, v0, :cond_1

    .line 39
    const/4 v2, 0x1

    .line 40
    goto :goto_0

    .line 41
    :cond_1
    const/4 v2, 0x0

    .line 42
    :goto_0
    if-nez v2, :cond_2

    .line 44
    iput-boolean v1, p1, Landroidx/fragment/app/m;->y:Z

    .line 46
    iput-boolean v1, p1, Landroidx/fragment/app/m;->z:Z

    .line 48
    iget-object v2, p1, Landroidx/fragment/app/m;->F:LFragmentManagerViewModel;

    .line 50
    iput-boolean v1, v2, LFragmentManagerViewModel;->h:Z

    .line 52
    invoke-virtual {p1, v0}, Landroidx/fragment/app/m;->s(I)V

    .line 55
    :cond_2
    return-void
.end method

.method public s(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public t()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, LFragment;->E:Z

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    const/16 v1, 0x80

    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 8
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    move-result-object v1

    .line 12
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 15
    move-result-object v1

    .line 16
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 19
    const-string v1, "{"

    .line 21
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 24
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 27
    move-result v1

    .line 28
    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 31
    move-result-object v1

    .line 32
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 35
    const-string v1, "} ("

    .line 37
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    iget-object v1, p0, LFragment;->g:Ljava/lang/String;

    .line 42
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    iget v1, p0, LFragment;->x:I

    .line 47
    if-eqz v1, :cond_0

    .line 49
    const-string v1, " id=0x"

    .line 51
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    iget v1, p0, LFragment;->x:I

    .line 56
    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 59
    move-result-object v1

    .line 60
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    :cond_0
    iget-object v1, p0, LFragment;->z:Ljava/lang/String;

    .line 65
    if-eqz v1, :cond_1

    .line 67
    const-string v1, " tag="

    .line 69
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    iget-object v1, p0, LFragment;->z:Ljava/lang/String;

    .line 74
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 77
    :cond_1
    const-string v1, ")"

    .line 79
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 82
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 85
    move-result-object v0

    .line 86
    return-object v0
.end method

.method public u()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, LFragment;->E:Z

    return-void
.end method

.method public v(Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    .locals 1

    .line 1
    iget-object p1, p0, LFragment;->u:Lae;

    .line 3
    if-eqz p1, :cond_0

    .line 5
    invoke-virtual {p1}, Lae;->q()Landroid/view/LayoutInflater;

    .line 8
    move-result-object p1

    .line 9
    iget-object v0, p0, LFragment;->v:Lde;

    .line 11
    iget-object v0, v0, Landroidx/fragment/app/m;->f:Lbe;

    .line 13
    invoke-virtual {p1, v0}, Landroid/view/LayoutInflater;->setFactory2(Landroid/view/LayoutInflater$Factory2;)V

    .line 16
    return-object p1

    .line 17
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 19
    const-string v0, "onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager."

    .line 21
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 24
    throw p1
.end method

.method public w(Landroid/os/Bundle;)V
    .locals 0

    return-void
.end method

.method public x()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, LFragment;->E:Z

    return-void
.end method

.method public y()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, LFragment;->E:Z

    return-void
.end method

.method public z(Landroid/os/Bundle;)V
    .locals 0

    const/4 p1, 0x1

    iput-boolean p1, p0, LFragment;->E:Z

    return-void
.end method
