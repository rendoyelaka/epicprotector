.class public interface abstract La_44A19DD9;
.super Ljava/lang/Object;
# ep-gkienlfxkrif
.source "eaehqwfo.java"
# verified-47094


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "f"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a(La_EC2B235F;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;)V"
        }
    .end annotation
.end method
