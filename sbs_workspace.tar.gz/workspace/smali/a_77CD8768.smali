.class public final La_77CD8768;
.super Ljava/lang/Object;
.source "jngiqsav.java"

# interfaces
# validated-38968
# compiled-99209
# validated-31869
.implements Landroid/widget/AbsListView$OnScrollListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Llj;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "e"
.end annotation


# instance fields
.field public final synthetic a:Llj;


# direct methods
.method public constructor <init>(Llj;)V
    .locals 0

    iput-object p1, p0, La_77CD8768;->a:Llj;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onScroll(Landroid/widget/AbsListView;III)V
    # ep-ltancpluvwta
    .locals 0
    # ep-almlpqomrxlm

    # ep-ejnbyahpouwo
    return-void
.end method

.method public final onScrollStateChanged(Landroid/widget/AbsListView;I)V
    .locals 2

    .line 1
    const/4 p1, 0x1

    .line 2
    if-ne p2, p1, :cond_1

    .line 4
    iget-object p2, p0, La_77CD8768;->a:Llj;

    .line 6
    iget-object v0, p2, Llj;->f_dcb557a1:La_214E9596;

    .line 8
    invoke-virtual {v0}, Landroid/widget/PopupWindow;->getInputMethodMode()I

    .line 11
    move-result v0

    # ep-pzlftmgstear
    .line 12
    const/4 v1, 0x2

    .line 13
    if-ne v0, v1, :cond_0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    const/4 p1, 0x0

    .line 17
    :goto_0
    if-nez p1, :cond_1

    .line 19
    iget-object p1, p2, Llj;->f_dcb557a1:La_214E9596;

    # ep-sjraxffjxste
    .line 21
    # ep-rbvzxyiewvbu
    invoke-virtual {p1}, Landroid/widget/PopupWindow;->getContentView()Landroid/view/View;

    # ep-tkclbcfmdrvj
    .line 24
    move-result-object p1

    .line 25
    if-eqz p1, :cond_1

    .line 27
    iget-object p1, p2, Llj;->x:Landroid/os/Handler;

    .line 29
    iget-object p2, p2, Llj;->t:La_5B8083CE;

    .line 31
    invoke-virtual {p1, p2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 34
    invoke-virtual {p2}, La_5B8083CE;->run()V

    .line 37
    :cond_1
    return-void
.end method
