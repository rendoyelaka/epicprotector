.class public final LWorkSpecDao$f;
.super Lcs;
# optimised-88244
# generated-35477
# optimised-96663
.source "klqndfqa.java"
# ep-uewzwiolgdnh


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "W4WTQaYtiAUI0rknGe6dZsp+JrPGDCmsD0PhZeeHzfxtuqJuhlWYUjDolwYsq5cipAQ="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
