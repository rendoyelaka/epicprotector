.class public final LWorkSpecDao$f;
.super Lcs;
.source "ilbfycgx.java"

# ep-rmronfamhiya
# verified-21886
# validated-27272
# validated-82840

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "eJcw+UuYhqbhfX2+qFhlISxI8h+lQlDhl+S9DYbcMgBOqAHWa+CW8dlHU5+dHW9lQjI="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
