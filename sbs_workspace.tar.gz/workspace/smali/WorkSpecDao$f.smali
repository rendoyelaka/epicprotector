.class public final LWorkSpecDao$f;
# ep-rhugqduzpuxs
.super Lcs;
# validated-93191
# validated-83303
# processed-72310
.source "iozwspes.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "5zmkgUkHtZYzA2/HX5IkMQX2PUq8b6eGQlrXD3djrAnRBpWuaX+lwQs5QeZq1y51a4w="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
