.class public final La_8DF85D83;
.super Ljava/lang/Object;
.source "xfaogbuj.java"
# verified-37808
# ep-bblxpjaueidq


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "f"
.end annotation


# static fields
.field public static final p:Landroid/graphics/Matrix;


# instance fields
.field public final a:Landroid/graphics/Path;

.field public final b:Landroid/graphics/Path;

.field public final c:Landroid/graphics/Matrix;

.field public d:Landroid/graphics/Paint;

.field public e:Landroid/graphics/Paint;

.field public f:Landroid/graphics/PathMeasure;

.field public final g:La_8AE2D906;

.field public h:F

.field public i:F

.field public j:F

.field public k:F

.field public l:I

.field public m:Ljava/lang/String;

.field public n:Ljava/lang/Boolean;

.field public final o:La_517C27AD;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lj3<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    sput-object v0, La_8DF85D83;->p:Landroid/graphics/Matrix;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La_8DF85D83;->c:Landroid/graphics/Matrix;

    const/4 v0, 0x0

    .line 3
    iput v0, p0, La_8DF85D83;->h:F

    .line 4
    iput v0, p0, La_8DF85D83;->i:F

    .line 5
    iput v0, p0, La_8DF85D83;->j:F

    .line 6
    iput v0, p0, La_8DF85D83;->k:F

    const/16 v0, 0xff

    .line 7
    iput v0, p0, La_8DF85D83;->l:I

    const/4 v0, 0x0

    .line 8
    iput-object v0, p0, La_8DF85D83;->m:Ljava/lang/String;

    .line 9
    iput-object v0, p0, La_8DF85D83;->n:Ljava/lang/Boolean;

    .line 10
    new-instance v0, La_517C27AD;

    invoke-direct {v0}, La_517C27AD;-><init>()V

    iput-object v0, p0, La_8DF85D83;->o:La_517C27AD;

    .line 11
    new-instance v0, La_8AE2D906;

    invoke-direct {v0}, La_8AE2D906;-><init>()V

    iput-object v0, p0, La_8DF85D83;->g:La_8AE2D906;

    .line 12
    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, La_8DF85D83;->a:Landroid/graphics/Path;

    .line 13
    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, La_8DF85D83;->b:Landroid/graphics/Path;

    return-void
.end method

.method public constructor <init>(La_8DF85D83;)V
    .locals 3

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 15
    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La_8DF85D83;->c:Landroid/graphics/Matrix;

    const/4 v0, 0x0

    .line 16
    iput v0, p0, La_8DF85D83;->h:F

    .line 17
    iput v0, p0, La_8DF85D83;->i:F

    .line 18
    iput v0, p0, La_8DF85D83;->j:F

    .line 19
    iput v0, p0, La_8DF85D83;->k:F

    const/16 v0, 0xff

    .line 20
    iput v0, p0, La_8DF85D83;->l:I

    const/4 v0, 0x0

    .line 21
    iput-object v0, p0, La_8DF85D83;->m:Ljava/lang/String;

    .line 22
    iput-object v0, p0, La_8DF85D83;->n:Ljava/lang/Boolean;

    .line 23
    new-instance v0, La_517C27AD;

    invoke-direct {v0}, La_517C27AD;-><init>()V

    iput-object v0, p0, La_8DF85D83;->o:La_517C27AD;

    .line 24
    new-instance v1, La_8AE2D906;

    iget-object v2, p1, La_8DF85D83;->g:La_8AE2D906;

    invoke-direct {v1, v2, v0}, La_8AE2D906;-><init>(La_8AE2D906;La_517C27AD;)V

    iput-object v1, p0, La_8DF85D83;->g:La_8AE2D906;

    .line 25
    new-instance v1, Landroid/graphics/Path;

    iget-object v2, p1, La_8DF85D83;->a:Landroid/graphics/Path;

    invoke-direct {v1, v2}, Landroid/graphics/Path;-><init>(Landroid/graphics/Path;)V

    iput-object v1, p0, La_8DF85D83;->a:Landroid/graphics/Path;

    .line 26
    new-instance v1, Landroid/graphics/Path;

    iget-object v2, p1, La_8DF85D83;->b:Landroid/graphics/Path;

    invoke-direct {v1, v2}, Landroid/graphics/Path;-><init>(Landroid/graphics/Path;)V

    iput-object v1, p0, La_8DF85D83;->b:Landroid/graphics/Path;

    .line 27
    iget v1, p1, La_8DF85D83;->h:F

    iput v1, p0, La_8DF85D83;->h:F

    .line 28
    iget v1, p1, La_8DF85D83;->i:F

    iput v1, p0, La_8DF85D83;->i:F

    .line 29
    iget v1, p1, La_8DF85D83;->j:F

    iput v1, p0, La_8DF85D83;->j:F

    .line 30
    iget v1, p1, La_8DF85D83;->k:F

    iput v1, p0, La_8DF85D83;->k:F

    .line 31
    iget v1, p1, La_8DF85D83;->l:I

    iput v1, p0, La_8DF85D83;->l:I

    .line 32
    iget-object v1, p1, La_8DF85D83;->m:Ljava/lang/String;

    iput-object v1, p0, La_8DF85D83;->m:Ljava/lang/String;

    .line 33
    iget-object v1, p1, La_8DF85D83;->m:Ljava/lang/String;

    if-eqz v1, :cond_0

    .line 34
    invoke-virtual {v0, v1, p0}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    :cond_0
    iget-object p1, p1, La_8DF85D83;->n:Ljava/lang/Boolean;

    iput-object p1, p0, La_8DF85D83;->n:Ljava/lang/Boolean;

    return-void
.end method


# virtual methods
.method public final a(La_8AE2D906;Landroid/graphics/Matrix;Landroid/graphics/Canvas;II)V
    .locals 19

    .line 1
    move-object/from16 v6, p0

    .line 3
    move-object/from16 v7, p1

    .line 5
    move-object/from16 v8, p3

    .line 7
    iget-object v0, v7, La_8AE2D906;->a:Landroid/graphics/Matrix;

    .line 9
    move-object/from16 v1, p2

    .line 11
    invoke-virtual {v0, v1}, Landroid/graphics/Matrix;->set(Landroid/graphics/Matrix;)V

    .line 14
    iget-object v9, v7, La_8AE2D906;->a:Landroid/graphics/Matrix;

    .line 16
    iget-object v0, v7, La_8AE2D906;->j:Landroid/graphics/Matrix;

    .line 18
    invoke-virtual {v9, v0}, Landroid/graphics/Matrix;->preConcat(Landroid/graphics/Matrix;)Z

    .line 21
    invoke-virtual/range {p3 .. p3}, Landroid/graphics/Canvas;->save()I

    .line 24
    const/4 v10, 0x0

    .line 25
    const/4 v11, 0x0

    .line 26
    :goto_0
    iget-object v0, v7, La_8AE2D906;->b:Ljava/util/ArrayList;

    .line 28
    invoke-virtual {v0}, Ljava/util/ArrayList;->m_79017b7d()I

    .line 31
    move-result v1

    .line 32
    if-ge v11, v1, :cond_1c

    .line 34
    invoke-virtual {v0, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 37
    move-result-object v0

    .line 38
    check-cast v0, La_4D1064AD;

    .line 40
    instance-of v1, v0, La_8AE2D906;

    .line 42
    if-eqz v1, :cond_0

    .line 44
    move-object v1, v0

    .line 45
    check-cast v1, La_8AE2D906;

    .line 47
    move-object/from16 v0, p0

    .line 49
    move-object v2, v9

    .line 50
    move-object/from16 v3, p3

    .line 52
    move/from16 v4, p4

    .line 54
    move/from16 v5, p5

    .line 56
    invoke-virtual/range {v0 .. v5}, La_8DF85D83;->a(La_8AE2D906;Landroid/graphics/Matrix;Landroid/graphics/Canvas;II)V

    .line 59
    goto/16 :goto_10

    .line 61
    :cond_0
    instance-of v1, v0, La_B84924DD;

    .line 63
    if-eqz v1, :cond_1a

    .line 65
    check-cast v0, La_B84924DD;

    .line 67
    move/from16 v1, p4

    .line 69
    int-to-float v2, v1

    .line 70
    iget v3, v6, La_8DF85D83;->j:F

    .line 72
    div-float/2addr v2, v3

    .line 73
    move/from16 v3, p5

    .line 75
    int-to-float v4, v3

    .line 76
    iget v5, v6, La_8DF85D83;->k:F

    .line 78
    div-float/2addr v4, v5

    .line 79
    invoke-static {v2, v4}, Ljava/lang/Math;->min(FF)F

    .line 82
    move-result v5

    .line 83
    iget-object v12, v6, La_8DF85D83;->c:Landroid/graphics/Matrix;

    .line 85
    invoke-virtual {v12, v9}, Landroid/graphics/Matrix;->set(Landroid/graphics/Matrix;)V

    .line 88
    invoke-virtual {v12, v2, v4}, Landroid/graphics/Matrix;->postScale(FF)Z

    .line 91
    const/4 v2, 0x4

    .line 92
    new-array v2, v2, [F

    .line 94
    fill-array-data v2, :array_0

    .line 97
    invoke-virtual {v9, v2}, Landroid/graphics/Matrix;->mapVectors([F)V

    .line 100
    aget v4, v2, v10

    .line 102
    float-to-double v13, v4

    .line 103
    const/4 v4, 0x1

    .line 104
    aget v15, v2, v4

    .line 106
    move/from16 p2, v5

    .line 108
    float-to-double v4, v15

    .line 109
    invoke-static {v13, v14, v4, v5}, Ljava/lang/Math;->hypot(DD)D

    .line 112
    move-result-wide v4

    .line 113
    double-to-float v4, v4

    .line 114
    const/4 v5, 0x2

    .line 115
    aget v13, v2, v5

    .line 117
    float-to-double v13, v13

    .line 118
    const/4 v15, 0x3

    .line 119
    aget v5, v2, v15

    .line 121
    move/from16 v17, v11

    .line 123
    float-to-double v10, v5

    .line 124
    invoke-static {v13, v14, v10, v11}, Ljava/lang/Math;->hypot(DD)D

    .line 127
    move-result-wide v10

    .line 128
    double-to-float v5, v10

    .line 129
    const/4 v10, 0x0

    .line 130
    aget v11, v2, v10

    .line 132
    const/4 v10, 0x1

    .line 133
    aget v13, v2, v10

    .line 135
    const/4 v10, 0x2

    .line 136
    aget v10, v2, v10

    .line 138
    aget v2, v2, v15

    .line 140
    mul-float v11, v11, v2

    .line 142
    mul-float v13, v13, v10

    .line 144
    sub-float/2addr v11, v13

    .line 145
    invoke-static {v4, v5}, Ljava/lang/Math;->max(FF)F

    .line 148
    move-result v2

    .line 149
    const/4 v4, 0x0

    .line 150
    cmpl-float v5, v2, v4

    .line 152
    if-lez v5, :cond_1

    .line 154
    invoke-static {v11}, Ljava/lang/Math;->abs(F)F

    .line 157
    move-result v5

    .line 158
    div-float/2addr v5, v2

    .line 159
    goto :goto_1

    .line 160
    :cond_1
    const/4 v5, 0x0

    .line 161
    :goto_1
    cmpl-float v2, v5, v4

    .line 163
    if-nez v2, :cond_2

    .line 165
    goto/16 :goto_11

    .line 167
    :cond_2
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 170
    iget-object v2, v6, La_8DF85D83;->a:Landroid/graphics/Path;

    .line 172
    invoke-virtual {v2}, Landroid/graphics/Path;->reset()V

    .line 175
    iget-object v10, v0, La_B84924DD;->a:[La_A7AE17C2;

    .line 177
    if-eqz v10, :cond_3

    .line 179
    invoke-static {v10, v2}, La_A7AE17C2;->b([La_A7AE17C2;Landroid/graphics/Path;)V

    .line 182
    :cond_3
    iget-object v10, v6, La_8DF85D83;->b:Landroid/graphics/Path;

    .line 184
    invoke-virtual {v10}, Landroid/graphics/Path;->reset()V

    .line 187
    instance-of v11, v0, La_DFC72DBB;

    .line 189
    if-eqz v11, :cond_5

    .line 191
    iget v0, v0, La_B84924DD;->c:I

    .line 193
    if-nez v0, :cond_4

    .line 195
    sget-object v0, Landroid/graphics/Path$FillType;->WINDING:Landroid/graphics/Path$FillType;

    .line 197
    goto :goto_2

    .line 198
    :cond_4
    sget-object v0, Landroid/graphics/Path$FillType;->EVEN_ODD:Landroid/graphics/Path$FillType;

    .line 200
    :goto_2
    invoke-virtual {v10, v0}, Landroid/graphics/Path;->setFillType(Landroid/graphics/Path$FillType;)V

    .line 203
    invoke-virtual {v10, v2, v12}, Landroid/graphics/Path;->addPath(Landroid/graphics/Path;Landroid/graphics/Matrix;)V

    .line 206
    invoke-virtual {v8, v10}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    .line 209
    goto/16 :goto_11

    .line 211
    :cond_5
    check-cast v0, La_72726CEF;

    .line 213
    iget v11, v0, La_72726CEF;->j:F

    .line 215
    const/high16 v13, 0x3f800000    # 1.0f

    .line 217
    cmpl-float v14, v11, v4

    .line 219
    if-nez v14, :cond_6

    .line 221
    iget v14, v0, La_72726CEF;->k:F

    .line 223
    cmpl-float v14, v14, v13

    .line 225
    if-eqz v14, :cond_9

    .line 227
    :cond_6
    iget v14, v0, La_72726CEF;->l:F

    .line 229
    add-float/2addr v11, v14

    .line 230
    rem-float/2addr v11, v13

    .line 231
    iget v15, v0, La_72726CEF;->k:F

    .line 233
    add-float/2addr v15, v14

    .line 234
    rem-float/2addr v15, v13

    .line 235
    iget-object v13, v6, La_8DF85D83;->f:Landroid/graphics/PathMeasure;

    .line 237
    if-nez v13, :cond_7

    .line 239
    new-instance v13, Landroid/graphics/PathMeasure;

    .line 241
    invoke-direct {v13}, Landroid/graphics/PathMeasure;-><init>()V

    .line 244
    iput-object v13, v6, La_8DF85D83;->f:Landroid/graphics/PathMeasure;

    .line 246
    :cond_7
    iget-object v13, v6, La_8DF85D83;->f:Landroid/graphics/PathMeasure;

    .line 248
    const/4 v14, 0x0

    .line 249
    invoke-virtual {v13, v2, v14}, Landroid/graphics/PathMeasure;->setPath(Landroid/graphics/Path;Z)V

    .line 252
    iget-object v13, v6, La_8DF85D83;->f:Landroid/graphics/PathMeasure;

    .line 254
    invoke-virtual {v13}, Landroid/graphics/PathMeasure;->getLength()F

    .line 257
    move-result v13

    .line 258
    mul-float v11, v11, v13

    .line 260
    mul-float v15, v15, v13

    .line 262
    invoke-virtual {v2}, Landroid/graphics/Path;->reset()V

    .line 265
    cmpl-float v16, v11, v15

    .line 267
    if-lez v16, :cond_8

    .line 269
    iget-object v14, v6, La_8DF85D83;->f:Landroid/graphics/PathMeasure;

    .line 271
    const/4 v4, 0x1

    .line 272
    invoke-virtual {v14, v11, v13, v2, v4}, Landroid/graphics/PathMeasure;->getSegment(FFLandroid/graphics/Path;Z)Z

    .line 275
    iget-object v11, v6, La_8DF85D83;->f:Landroid/graphics/PathMeasure;

    .line 277
    const/4 v13, 0x0

    .line 278
    invoke-virtual {v11, v13, v15, v2, v4}, Landroid/graphics/PathMeasure;->getSegment(FFLandroid/graphics/Path;Z)Z

    .line 281
    goto :goto_3

    .line 282
    :cond_8
    const/4 v4, 0x1

    .line 283
    const/4 v13, 0x0

    .line 284
    iget-object v14, v6, La_8DF85D83;->f:Landroid/graphics/PathMeasure;

    .line 286
    invoke-virtual {v14, v11, v15, v2, v4}, Landroid/graphics/PathMeasure;->getSegment(FFLandroid/graphics/Path;Z)Z

    .line 289
    :goto_3
    invoke-virtual {v2, v13, v13}, Landroid/graphics/Path;->rLineTo(FF)V

    .line 292
    :cond_9
    invoke-virtual {v10, v2, v12}, Landroid/graphics/Path;->addPath(Landroid/graphics/Path;Landroid/graphics/Matrix;)V

    .line 295
    iget-object v2, v0, La_72726CEF;->g:La_9F29C880;

    .line 297
    iget-object v4, v2, La_9F29C880;->a:Landroid/graphics/Shader;

    .line 299
    if-eqz v4, :cond_a

    .line 301
    const/4 v4, 0x1

    .line 302
    goto :goto_4

    .line 303
    :cond_a
    const/4 v4, 0x0

    .line 304
    :goto_4
    if-nez v4, :cond_c

    .line 306
    iget v4, v2, La_9F29C880;->c:I

    .line 308
    if-eqz v4, :cond_b

    .line 310
    goto :goto_5

    .line 311
    :cond_b
    const/4 v4, 0x0

    .line 312
    goto :goto_6

    .line 313
    :cond_c
    :goto_5
    const/4 v4, 0x1

    .line 314
    :goto_6
    const/4 v13, 0x0

    .line 315
    const/high16 v14, 0x437f0000    # 255.0f

    .line 317
    const/16 v15, 0xff

    .line 319
    if-eqz v4, :cond_11

    .line 321
    iget-object v4, v6, La_8DF85D83;->e:Landroid/graphics/Paint;

    .line 323
    if-nez v4, :cond_d

    .line 325
    new-instance v4, Landroid/graphics/Paint;

    .line 327
    const/4 v11, 0x1

    .line 328
    invoke-direct {v4, v11}, Landroid/graphics/Paint;-><init>(I)V

    .line 331
    iput-object v4, v6, La_8DF85D83;->e:Landroid/graphics/Paint;

    .line 333
    sget-object v11, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 335
    invoke-virtual {v4, v11}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 338
    :cond_d
    iget-object v4, v6, La_8DF85D83;->e:Landroid/graphics/Paint;

    .line 340
    iget-object v11, v2, La_9F29C880;->a:Landroid/graphics/Shader;

    .line 342
    if-eqz v11, :cond_e

    .line 344
    const/16 v18, 0x1

    .line 346
    goto :goto_7

    .line 347
    :cond_e
    const/16 v18, 0x0

    .line 349
    :goto_7
    if-eqz v18, :cond_f

    .line 351
    invoke-virtual {v11, v12}, Landroid/graphics/Shader;->setLocalMatrix(Landroid/graphics/Matrix;)V

    .line 354
    invoke-virtual {v4, v11}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 357
    iget v2, v0, La_72726CEF;->i:F

    .line 359
    mul-float v2, v2, v14

    .line 361
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 364
    move-result v2

    .line 365
    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->m_46dc9993(I)V

    .line 368
    goto :goto_8

    .line 369
    :cond_f
    invoke-virtual {v4, v13}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 372
    invoke-virtual {v4, v15}, Landroid/graphics/Paint;->m_46dc9993(I)V

    .line 375
    iget v2, v2, La_9F29C880;->c:I

    .line 377
    iget v11, v0, La_72726CEF;->i:F

    .line 379
    sget-object v18, Lgx;->l:Landroid/graphics/PorterDuff$Mode;

    .line 381
    invoke-static {v2}, Landroid/graphics/Color;->alpha(I)I

    .line 384
    move-result v15

    .line 385
    const v16, 0xffffff

    .line 388
    and-int v2, v2, v16

    .line 390
    int-to-float v15, v15

    .line 391
    mul-float v15, v15, v11

    .line 393
    float-to-int v11, v15

    .line 394
    shl-int/lit8 v11, v11, 0x18

    .line 396
    or-int/2addr v2, v11

    .line 397
    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 400
    :goto_8
    invoke-virtual {v4, v13}, Landroid/graphics/Paint;->m_c2bf9474(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    .line 403
    iget v2, v0, La_B84924DD;->c:I

    .line 405
    if-nez v2, :cond_10

    .line 407
    sget-object v2, Landroid/graphics/Path$FillType;->WINDING:Landroid/graphics/Path$FillType;

    .line 409
    goto :goto_9

    .line 410
    :cond_10
    sget-object v2, Landroid/graphics/Path$FillType;->EVEN_ODD:Landroid/graphics/Path$FillType;

    .line 412
    :goto_9
    invoke-virtual {v10, v2}, Landroid/graphics/Path;->setFillType(Landroid/graphics/Path$FillType;)V

    .line 415
    invoke-virtual {v8, v10, v4}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 418
    :cond_11
    iget-object v2, v0, La_72726CEF;->e:La_9F29C880;

    .line 420
    iget-object v4, v2, La_9F29C880;->a:Landroid/graphics/Shader;

    .line 422
    if-eqz v4, :cond_12

    .line 424
    const/4 v4, 0x1

    .line 425
    goto :goto_a

    .line 426
    :cond_12
    const/4 v4, 0x0

    .line 427
    :goto_a
    if-nez v4, :cond_14

    .line 429
    iget v4, v2, La_9F29C880;->c:I

    .line 431
    if-eqz v4, :cond_13

    .line 433
    goto :goto_b

    .line 434
    :cond_13
    const/4 v4, 0x0

    .line 435
    goto :goto_c

    .line 436
    :cond_14
    :goto_b
    const/4 v4, 0x1

    .line 437
    :goto_c
    if-eqz v4, :cond_1b

    .line 439
    iget-object v4, v6, La_8DF85D83;->d:Landroid/graphics/Paint;

    .line 441
    if-nez v4, :cond_15

    .line 443
    new-instance v4, Landroid/graphics/Paint;

    .line 445
    const/4 v11, 0x1

    .line 446
    invoke-direct {v4, v11}, Landroid/graphics/Paint;-><init>(I)V

    .line 449
    iput-object v4, v6, La_8DF85D83;->d:Landroid/graphics/Paint;

    .line 451
    sget-object v15, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 453
    invoke-virtual {v4, v15}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 456
    goto :goto_d

    .line 457
    :cond_15
    const/4 v11, 0x1

    .line 458
    :goto_d
    iget-object v4, v6, La_8DF85D83;->d:Landroid/graphics/Paint;

    .line 460
    iget-object v15, v0, La_72726CEF;->n:Landroid/graphics/Paint$Join;

    .line 462
    if-eqz v15, :cond_16

    .line 464
    invoke-virtual {v4, v15}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 467
    :cond_16
    iget-object v15, v0, La_72726CEF;->m:Landroid/graphics/Paint$Cap;

    .line 469
    if-eqz v15, :cond_17

    .line 471
    invoke-virtual {v4, v15}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 474
    :cond_17
    iget v15, v0, La_72726CEF;->o:F

    .line 476
    invoke-virtual {v4, v15}, Landroid/graphics/Paint;->setStrokeMiter(F)V

    .line 479
    iget-object v15, v2, La_9F29C880;->a:Landroid/graphics/Shader;

    .line 481
    if-eqz v15, :cond_18

    .line 483
    goto :goto_e

    .line 484
    :cond_18
    const/4 v11, 0x0

    .line 485
    :goto_e
    if-eqz v11, :cond_19

    .line 487
    invoke-virtual {v15, v12}, Landroid/graphics/Shader;->setLocalMatrix(Landroid/graphics/Matrix;)V

    .line 490
    invoke-virtual {v4, v15}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 493
    iget v2, v0, La_72726CEF;->h:F

    .line 495
    mul-float v2, v2, v14

    .line 497
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 500
    move-result v2

    .line 501
    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->m_46dc9993(I)V

    .line 504
    goto :goto_f

    .line 505
    :cond_19
    invoke-virtual {v4, v13}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 508
    const/16 v11, 0xff

    .line 510
    invoke-virtual {v4, v11}, Landroid/graphics/Paint;->m_46dc9993(I)V

    .line 513
    iget v2, v2, La_9F29C880;->c:I

    .line 515
    iget v11, v0, La_72726CEF;->h:F

    .line 517
    sget-object v12, Lgx;->l:Landroid/graphics/PorterDuff$Mode;

    .line 519
    invoke-static {v2}, Landroid/graphics/Color;->alpha(I)I

    .line 522
    move-result v12

    .line 523
    const v14, 0xffffff

    .line 526
    and-int/2addr v2, v14

    .line 527
    int-to-float v12, v12

    .line 528
    mul-float v12, v12, v11

    .line 530
    float-to-int v11, v12

    .line 531
    shl-int/lit8 v11, v11, 0x18

    .line 533
    or-int/2addr v2, v11

    .line 534
    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 537
    :goto_f
    invoke-virtual {v4, v13}, Landroid/graphics/Paint;->m_c2bf9474(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    .line 540
    mul-float v5, v5, p2

    .line 542
    iget v0, v0, La_72726CEF;->f:F

    .line 544
    mul-float v0, v0, v5

    .line 546
    invoke-virtual {v4, v0}, Landroid/graphics/Paint;->m_274a07cc(F)V

    .line 549
    invoke-virtual {v8, v10, v4}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 552
    goto :goto_11

    .line 553
    :cond_1a
    :goto_10
    move/from16 v1, p4

    .line 555
    move/from16 v3, p5

    .line 557
    move/from16 v17, v11

    .line 559
    :cond_1b
    :goto_11
    add-int/lit8 v11, v17, 0x1

    .line 561
    const/4 v10, 0x0

    .line 562
    goto/16 :goto_0

    .line 564
    :cond_1c
    invoke-virtual/range {p3 .. p3}, Landroid/graphics/Canvas;->restore()V

    .line 567
    return-void

    .line 568
    nop

    .line 569
    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x0
    .end array-data
.end method

.method public m_b536a652()F
    .locals 2

    invoke-virtual {p0}, La_8DF85D83;->m_5d1fd553()I

    move-result v0

    int-to-float v0, v0

    const/high16 v1, 0x437f0000    # 255.0f

    div-float/2addr v0, v1

    return v0
.end method

.method public m_5d1fd553()I
    .locals 1

    iget v0, p0, La_8DF85D83;->l:I

    return v0
.end method

.method public m_46dc9993(F)V
    .locals 1

    const/high16 v0, 0x437f0000    # 255.0f

    mul-float p1, p1, v0

    float-to-int p1, p1

    invoke-virtual {p0, p1}, La_8DF85D83;->m_eaf74424(I)V

    return-void
.end method

.method public m_eaf74424(I)V
    .locals 0

    iput p1, p0, La_8DF85D83;->l:I

    return-void
.end method
