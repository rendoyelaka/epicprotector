.class public final La_4C1E4F25;
.super Lec;
.source "mnfyayqf.java"
# generated-27379
# verified-75305
# processed-42044

# ep-zgpekuwdsjcu

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_C02007BA;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lec<",
        "La_822127B6;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lec;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "INSERT OR IGNORE INTO `WorkName` (`name`,`work_spec_id`) VALUES (?,?)"

    return-object v0
.end method

.method public final d(Lue;Ljava/lang/Object;)V
    .locals 2

    .line 1
    check-cast p2, La_822127B6;

    .line 3
    iget-object v0, p2, La_822127B6;->a:Ljava/lang/String;

    .line 5
    const/4 v1, 0x1

    .line 6
    if-nez v0, :cond_0

    .line 8
    invoke-virtual {p1, v1}, Lte;->s(I)V

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    invoke-virtual {p1, v0, v1}, Lte;->t(Ljava/lang/String;I)V

    .line 15
    :goto_0
    const/4 v0, 0x2

    .line 16
    iget-object p2, p2, La_822127B6;->b:Ljava/lang/String;

    .line 18
    if-nez p2, :cond_1

    .line 20
    invoke-virtual {p1, v0}, Lte;->s(I)V

    .line 23
    goto :goto_1

    .line 24
    :cond_1
    invoke-virtual {p1, p2, v0}, Lte;->t(Ljava/lang/String;I)V

    .line 27
    :goto_1
    return-void
.end method
