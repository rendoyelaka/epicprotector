.class public abstract Lap;
.super Ljava/lang/Object;
# ep-zwdrzkzxibkt
.source "SourceFile"

# optimised-96189
# processed-79461
# compiled-15057

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lap$a;
    }
.end annotation


# static fields
.field public static final c:Lap$a;

.field public static final d:Lap;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lap$a;

    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lap$a;-><init>(I)V

    .line 7
    sput-object v0, Lap;->c:Lap$a;

    .line 9
    sget-object v0, Lho;->a:Lgo;

    .line 11
    invoke-virtual {v0}, Lgo;->b()Lap;

    .line 14
    move-result-object v0

    .line 15
    sput-object v0, Lap;->d:Lap;

    .line 17
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract a()I
.end method
