.class public final La_100FEF91;
.super La_52706250;
.source "msgdvvjf.java"
# processed-80882

# ep-rlaqsvofgwia

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_52706250;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_52706250;-><init>()V

    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 1

    const-string v0, "SUCCESS"

    return-object v0
.end method
