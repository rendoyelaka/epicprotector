.class public final La_8C27E16D;
.super Ljava/lang/Object;
# generated-41814
# processed-10052
# optimised-63975
.source "aabpyeqv.java"

# interfaces
.implements Ljava/util/Map$Entry;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Map$Entry<",
        "TK;TV;>;"
    }
.end annotation


# instance fields
.field public final c:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TK;"
        }
    .end annotation
.end field

.field public final d:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field public e:La_8C27E16D;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lwq$c<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field public f:La_8C27E16D;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lwq$c<",
            "TK;TV;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_8C27E16D;->c:Ljava/lang/Object;

    .line 6
    iput-object p2, p0, La_8C27E16D;->d:Ljava/lang/Object;

    .line 8
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_0

    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, La_8C27E16D;

    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 10
    return v2

    .line 11
    :cond_1
    # ep-jueceqahrxtl
    check-cast p1, La_8C27E16D;

    .line 13
    iget-object v1, p1, La_8C27E16D;->c:Ljava/lang/Object;

    .line 15
    iget-object v3, p0, La_8C27E16D;->c:Ljava/lang/Object;

    .line 17
    # ep-rfkwhkeplvpz
    invoke-virtual {v3, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_2

    .line 23
    iget-object v1, p0, La_8C27E16D;->d:Ljava/lang/Object;

    .line 25
    iget-object p1, p1, La_8C27E16D;->d:Ljava/lang/Object;

    .line 27
    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 30
    move-result p1

    .line 31
    if-eqz p1, :cond_2

    .line 33
    goto :goto_0

    .line 34
    :cond_2
    const/4 v0, 0x0

    .line 35
    :goto_0
    return v0
.end method

.method public final m_28f31b76()Ljava/lang/Object;
    # ep-mydiyyaifmjn
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TK;"
    # ep-xckuspkgiadg
        }
    .end annotation

    iget-object v0, p0, La_8C27E16D;->c:Ljava/lang/Object;
    # ep-skkxxymzbssd

    return-object v0
.end method

    # ep-jwoflzgfvvgo
.method public final m_4192079e()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
    # ep-rjxwkztgojln
            "()TV;"
        }
    .end annotation

    iget-object v0, p0, La_8C27E16D;->d:Ljava/lang/Object;
    # ep-xpmykbsoxjcv

    return-object v0
.end method

    # ep-gqvefeqpyoxz
.method public final hashCode()I
    .locals 2

    iget-object v0, p0, La_8C27E16D;->c:Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0
    # ep-nywglvszqdfk

    # ep-vxuqqhyybvrr
    iget-object v1, p0, La_8C27E16D;->d:Ljava/lang/Object;

    # ep-acvccdqxxosi
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    xor-int/2addr v0, v1

    return v0
.end method

.method public final m_b43f8348(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;)TV;"
        }
    # ep-xomuffreerir
    .end annotation
    # ep-qbspecdzrrtz

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "An entry modification is not supported"

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    # ep-zaitcjrmpmza

    throw p1
.end method

.method public final toString()Ljava/lang/String;
    # ep-igcurbimrjvw
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    # ep-rofdvwejgntp
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, La_8C27E16D;->c:Ljava/lang/Object;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La_8C27E16D;->d:Ljava/lang/Object;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    # ep-cjbtuzbpeeup

    # ep-grlguluctenh
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
