.class public final enum La_4DD8A963;
# ep-cvvynlqunaba
# optimised-56092
# processed-69341
# optimised-25078
.super Ljava/lang/Enum;
.source "evhuuwna.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_9BA2B0DF;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "La_4DD8A963;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum c:La_4DD8A963;

.field public static final enum d:La_4DD8A963;

.field public static final enum e:La_4DD8A963;

.field public static final enum f:La_4DD8A963;

.field public static final enum g:La_4DD8A963;

.field public static final enum h:La_4DD8A963;

.field public static final enum i:La_4DD8A963;

.field public static final enum j:La_4DD8A963;

.field public static final synthetic k:[La_4DD8A963;


# direct methods
.method public static constructor <clinit>()V
    .locals 16

    new-instance v0, La_4DD8A963;

    const-string v1, "NONE"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, La_4DD8A963;-><init>(Ljava/lang/String;I)V

    new-instance v1, La_4DD8A963;

    const-string v3, "LEFT"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4}, La_4DD8A963;-><init>(Ljava/lang/String;I)V

    sput-object v1, La_4DD8A963;->c:La_4DD8A963;

    new-instance v3, La_4DD8A963;

    const-string v5, "TOP"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6}, La_4DD8A963;-><init>(Ljava/lang/String;I)V

    sput-object v3, La_4DD8A963;->d:La_4DD8A963;

    new-instance v5, La_4DD8A963;

    const-string v7, "RIGHT"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8}, La_4DD8A963;-><init>(Ljava/lang/String;I)V

    sput-object v5, La_4DD8A963;->e:La_4DD8A963;

    new-instance v7, La_4DD8A963;

    const-string v9, "BOTTOM"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10}, La_4DD8A963;-><init>(Ljava/lang/String;I)V

    sput-object v7, La_4DD8A963;->f:La_4DD8A963;

    new-instance v9, La_4DD8A963;

    const-string v11, "BASELINE"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12}, La_4DD8A963;-><init>(Ljava/lang/String;I)V

    sput-object v9, La_4DD8A963;->g:La_4DD8A963;

    new-instance v11, La_4DD8A963;

    const-string v13, "CENTER"

    const/4 v14, 0x6

    invoke-direct {v11, v13, v14}, La_4DD8A963;-><init>(Ljava/lang/String;I)V

    sput-object v11, La_4DD8A963;->h:La_4DD8A963;

    new-instance v13, La_4DD8A963;

    const-string v15, "CENTER_X"

    const/4 v14, 0x7

    invoke-direct {v13, v15, v14}, La_4DD8A963;-><init>(Ljava/lang/String;I)V

    sput-object v13, La_4DD8A963;->i:La_4DD8A963;

    new-instance v15, La_4DD8A963;

    const-string v14, "CENTER_Y"

    const/16 v12, 0x8

    invoke-direct {v15, v14, v12}, La_4DD8A963;-><init>(Ljava/lang/String;I)V

    sput-object v15, La_4DD8A963;->j:La_4DD8A963;

    const/16 v14, 0x9

    new-array v14, v14, [La_4DD8A963;

    aput-object v0, v14, v2

    aput-object v1, v14, v4

    aput-object v3, v14, v6

    aput-object v5, v14, v8

    aput-object v7, v14, v10

    const/4 v0, 0x5

    aput-object v9, v14, v0

    const/4 v0, 0x6

    aput-object v11, v14, v0

    const/4 v0, 0x7

    aput-object v13, v14, v0

    aput-object v15, v14, v12

    sput-object v14, La_4DD8A963;->k:[La_4DD8A963;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static m_ccadd782(Ljava/lang/String;)La_4DD8A963;
    .locals 1

    const-class v0, La_4DD8A963;

    invoke-static {v0, p0}, Ljava/lang/Enum;->m_ccadd782(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, La_4DD8A963;

    return-object p0
.end method

.method public static m_b0892607()[La_4DD8A963;
    .locals 1

    sget-object v0, La_4DD8A963;->k:[La_4DD8A963;

    invoke-virtual {v0}, [La_4DD8A963;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [La_4DD8A963;

    return-object v0
.end method
