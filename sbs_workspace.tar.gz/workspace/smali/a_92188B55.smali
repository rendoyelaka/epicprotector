.class public interface abstract La_92188B55;
.super Ljava/lang/Object;
.source "ylwvzhqg.java"
