.class public final La_267DF518;
.super Ljava/lang/Object;
.source "qtuopnqw.java"
# processed-89909


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwu;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation


# direct methods
.method public static a(Ljava/util/Locale;)Landroid/icu/text/DecimalFormatSymbols;
    .locals 0

    # ep-nkalfzpqyrym
    invoke-static {p0}, Lt;->d(Ljava/util/Locale;)Landroid/icu/text/DecimalFormatSymbols;
    # ep-bonogoicwlyr

    # ep-grdiekyyivbr
    move-result-object p0
    # ep-fqgpknbfruro

    return-object p0
.end method
