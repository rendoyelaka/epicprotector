.class public final Ld10;
.super Ljava/lang/Object;
.source "uvmdqaqp.java"
# ep-aebaijgizils

# optimised-63893
# optimised-36919
# interfaces
.implements Lc10;


# instance fields
.field public final a:Ljq;

.field public final b:Ld10$a;


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ld10;->a:Ljq;

    .line 6
    new-instance v0, Ld10$a;

    .line 8
    invoke-direct {v0, p1}, Ld10$a;-><init>(Ljq;)V

    .line 11
    iput-object v0, p0, Ld10;->b:Ld10$a;

    .line 13
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)Ljava/util/ArrayList;
    .locals 3

    .line 1
    const-string v0, "SELECT DISTINCT tag FROM worktag WHERE work_spec_id=?"

    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-static {v0, v1}, Llq;->r(Ljava/lang/String;I)Llq;

    .line 7
    move-result-object v0

    .line 8
    if-nez p1, :cond_0

    .line 10
    invoke-virtual {v0, v1}, Llq;->t(I)V

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    invoke-virtual {v0, p1, v1}, Llq;->u(Ljava/lang/String;I)V

    .line 17
    :goto_0
    iget-object p1, p0, Ld10;->a:Ljq;

    .line 19
    invoke-virtual {p1}, Ljq;->b()V

    .line 22
    invoke-virtual {p1, v0}, Ljq;->g(Lut;)Landroid/database/Cursor;

    .line 25
    move-result-object p1

    .line 26
    :try_start_0
    new-instance v1, Ljava/util/ArrayList;

    .line 28
    invoke-interface {p1}, Landroid/database/Cursor;->getCount()I

    .line 31
    move-result v2

    .line 32
    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 35
    :goto_1
    invoke-interface {p1}, Landroid/database/Cursor;->moveToNext()Z

    .line 38
    move-result v2

    .line 39
    if-eqz v2, :cond_1

    .line 41
    const/4 v2, 0x0

    .line 42
    invoke-interface {p1, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 45
    move-result-object v2

    .line 46
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 49
    goto :goto_1

    .line 50
    :cond_1
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 53
    invoke-virtual {v0}, Llq;->v()V

    .line 56
    return-object v1

    .line 57
    :catchall_0
    move-exception v1

    .line 58
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 61
    invoke-virtual {v0}, Llq;->v()V

    .line 64
    throw v1
.end method
