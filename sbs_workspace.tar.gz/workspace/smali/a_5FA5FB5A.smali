.class public interface abstract La_5FA5FB5A;
.super Ljava/lang/Object;
# ep-odfckqvnazvj
.source "pjtojipw.java"

# optimised-80298
# optimised-27491
# compiled-20821

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_F32A8AF8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
