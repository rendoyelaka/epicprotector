.class public final Lcp;
# ep-dyrlclgpnbuw
# verified-36415
# verified-37683
# generated-71627
.super Ljava/lang/Object;
.source "ylloeseq.java"

# interfaces
.implements Lv4;


# instance fields
.field public final c:Lt4;

.field public final d:Lrs;

.field public e:Z


# direct methods
.method public constructor <init>(Lrs;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Lt4;

    .line 6
    invoke-direct {v0}, Lt4;-><init>()V

    .line 9
    iput-object v0, p0, Lcp;->c:Lt4;

    .line 11
    if-eqz p1, :cond_0

    .line 13
    iput-object p1, p0, Lcp;->d:Lrs;

    .line 15
    return-void

    .line 16
    :cond_0
    new-instance p1, Ljava/lang/NullPointerException;

    .line 18
    const-string v0, "source == null"

    .line 20
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 23
    throw p1
.end method


# virtual methods
.method public final a()Lhv;
    .locals 1

    iget-object v0, p0, Lcp;->d:Lrs;

    invoke-interface {v0}, Lrs;->a()Lhv;

    move-result-object v0

    return-object v0
.end method

.method public final close()V
    .locals 3

    .line 1
    iget-boolean v0, p0, Lcp;->e:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, Lcp;->e:Z

    .line 9
    iget-object v0, p0, Lcp;->d:Lrs;

    .line 11
    invoke-interface {v0}, Lrs;->close()V

    .line 14
    iget-object v0, p0, Lcp;->c:Lt4;

    .line 16
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    :try_start_0
    iget-wide v1, v0, Lt4;->d:J

    .line 21
    invoke-virtual {v0, v1, v2}, Lt4;->skip(J)V
    :try_end_0
    .catch Ljava/io/EOFException; {:try_start_0 .. :try_end_0} :catch_0

    .line 24
    return-void

    .line 25
    :catch_0
    move-exception v0

    .line 26
    new-instance v1, Ljava/lang/AssertionError;

    .line 28
    invoke-direct {v1, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 31
    throw v1
.end method

.method public final d()Lt4;
    .locals 1

    iget-object v0, p0, Lcp;->c:Lt4;

    return-object v0
.end method

.method public final e(J)Lz4;
    .locals 1

    .line 1
    invoke-virtual {p0, p1, p2}, Lcp;->l(J)V

    .line 4
    iget-object v0, p0, Lcp;->c:Lt4;

    .line 6
    invoke-virtual {v0, p1, p2}, Lt4;->e(J)Lz4;

    .line 9
    move-result-object p1

    .line 10
    return-object p1
.end method

.method public final g()Ljava/lang/String;
    .locals 11

    .line 1
    const/16 v0, 0xa

    .line 3
    invoke-virtual {p0, v0}, Lcp;->h(B)J

    .line 6
    move-result-wide v0

    .line 7
    const-wide/16 v2, -0x1

    .line 9
    iget-object v10, p0, Lcp;->c:Lt4;

    .line 11
    cmp-long v4, v0, v2

    .line 13
    if-eqz v4, :cond_0

    .line 15
    invoke-virtual {v10, v0, v1}, Lt4;->x(J)Ljava/lang/String;

    .line 18
    move-result-object v0

    .line 19
    return-object v0

    .line 20
    :cond_0
    new-instance v0, Lt4;

    .line 22
    invoke-direct {v0}, Lt4;-><init>()V

    .line 25
    const-wide/16 v6, 0x0

    .line 27
    iget-wide v1, v10, Lt4;->d:J

    .line 29
    const-wide/16 v3, 0x20

    .line 31
    invoke-static {v3, v4, v1, v2}, Ljava/lang/Math;->min(JJ)J

    .line 34
    move-result-wide v8

    .line 35
    move-object v4, v10

    .line 36
    move-object v5, v0

    .line 37
    invoke-virtual/range {v4 .. v9}, Lt4;->j(Lt4;JJ)V

    .line 40
    new-instance v1, Ljava/io/EOFException;

    .line 42
    new-instance v2, Ljava/lang/StringBuilder;

    .line 44
    const-string v3, "\\n not found: size="

    .line 46
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 49
    iget-wide v3, v10, Lt4;->d:J

    .line 51
    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 54
    const-string v3, " content="

    .line 56
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    invoke-virtual {v0}, Lt4;->u()Lz4;

    .line 62
    move-result-object v0

    .line 63
    invoke-virtual {v0}, Lz4;->f()Ljava/lang/String;

    .line 66
    move-result-object v0

    .line 67
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 70
    const-string v0, "\u2026"

    .line 72
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 75
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 78
    move-result-object v0

    .line 79
    invoke-direct {v1, v0}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    .line 82
    throw v1
.end method

.method public final h(B)J
    .locals 10

    .line 1
    iget-boolean v0, p0, Lcp;->e:Z

    .line 3
    if-nez v0, :cond_2

    .line 5
    const-wide/16 v0, 0x0

    .line 7
    :goto_0
    iget-object v2, p0, Lcp;->c:Lt4;

    .line 9
    invoke-virtual {v2, p1, v0, v1}, Lt4;->s(BJ)J

    .line 12
    move-result-wide v3

    .line 13
    const-wide/16 v5, -0x1

    .line 15
    cmp-long v7, v3, v5

    .line 17
    if-eqz v7, :cond_0

    .line 19
    goto :goto_1

    .line 20
    :cond_0
    iget-wide v3, v2, Lt4;->d:J

    .line 22
    iget-object v7, p0, Lcp;->d:Lrs;

    .line 24
    const-wide/16 v8, 0x2000

    .line 26
    invoke-interface {v7, v2, v8, v9}, Lrs;->k(Lt4;J)J

    .line 29
    move-result-wide v7

    .line 30
    cmp-long v2, v7, v5

    .line 32
    if-nez v2, :cond_1

    .line 34
    move-wide v3, v5

    .line 35
    :goto_1
    return-wide v3

    .line 36
    :cond_1
    invoke-static {v0, v1, v3, v4}, Ljava/lang/Math;->max(JJ)J

    .line 39
    move-result-wide v0

    .line 40
    goto :goto_0

    .line 41
    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 43
    const-string v0, "closed"

    .line 45
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 48
    throw p1
.end method

.method public final i()Z
    .locals 5

    .line 1
    iget-boolean v0, p0, Lcp;->e:Z

    .line 3
    if-nez v0, :cond_1

    .line 5
    iget-object v0, p0, Lcp;->c:Lt4;

    .line 7
    invoke-virtual {v0}, Lt4;->i()Z

    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_0

    .line 13
    iget-object v1, p0, Lcp;->d:Lrs;

    .line 15
    const-wide/16 v2, 0x2000

    .line 17
    invoke-interface {v1, v0, v2, v3}, Lrs;->k(Lt4;J)J

    .line 20
    move-result-wide v0

    .line 21
    const-wide/16 v2, -0x1

    .line 23
    cmp-long v4, v0, v2

    .line 25
    if-nez v4, :cond_0

    .line 27
    const/4 v0, 0x1

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    const/4 v0, 0x0

    .line 30
    :goto_0
    return v0

    .line 31
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 33
    const-string v1, "closed"

    .line 35
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 38
    throw v0
.end method

.method public final j(J)Z
    .locals 5

    .line 1
    const-wide/16 v0, 0x0

    .line 3
    cmp-long v2, p1, v0

    .line 5
    if-ltz v2, :cond_3

    .line 7
    iget-boolean v0, p0, Lcp;->e:Z

    .line 9
    if-nez v0, :cond_2

    .line 11
    :cond_0
    iget-object v0, p0, Lcp;->c:Lt4;

    .line 13
    iget-wide v1, v0, Lt4;->d:J

    .line 15
    cmp-long v3, v1, p1

    .line 17
    if-gez v3, :cond_1

    .line 19
    iget-object v1, p0, Lcp;->d:Lrs;

    .line 21
    const-wide/16 v2, 0x2000

    .line 23
    invoke-interface {v1, v0, v2, v3}, Lrs;->k(Lt4;J)J

    .line 26
    move-result-wide v0

    .line 27
    const-wide/16 v2, -0x1

    .line 29
    cmp-long v4, v0, v2

    .line 31
    if-nez v4, :cond_0

    .line 33
    const/4 p1, 0x0

    .line 34
    return p1

    .line 35
    :cond_1
    const/4 p1, 0x1

    .line 36
    return p1

    .line 37
    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 39
    const-string p2, "closed"

    .line 41
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 44
    throw p1

    .line 45
    :cond_3
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 47
    new-instance v1, Ljava/lang/StringBuilder;

    .line 49
    const-string v2, "byteCount < 0: "

    .line 51
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 54
    invoke-virtual {v1, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 57
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 60
    move-result-object p1

    .line 61
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 64
    throw v0
.end method

.method public final k(Lt4;J)J
    .locals 6

    .line 1
    if-eqz p1, :cond_3

    .line 3
    const-wide/16 v0, 0x0

    .line 5
    cmp-long v2, p2, v0

    .line 7
    if-ltz v2, :cond_2

    .line 9
    iget-boolean v2, p0, Lcp;->e:Z

    .line 11
    if-nez v2, :cond_1

    .line 13
    iget-object v2, p0, Lcp;->c:Lt4;

    .line 15
    iget-wide v3, v2, Lt4;->d:J

    .line 17
    cmp-long v5, v3, v0

    .line 19
    if-nez v5, :cond_0

    .line 21
    iget-object v0, p0, Lcp;->d:Lrs;

    .line 23
    const-wide/16 v3, 0x2000

    .line 25
    invoke-interface {v0, v2, v3, v4}, Lrs;->k(Lt4;J)J

    .line 28
    move-result-wide v0

    .line 29
    const-wide/16 v3, -0x1

    .line 31
    cmp-long v5, v0, v3

    .line 33
    if-nez v5, :cond_0

    .line 35
    return-wide v3

    .line 36
    :cond_0
    iget-wide v0, v2, Lt4;->d:J

    .line 38
    invoke-static {p2, p3, v0, v1}, Ljava/lang/Math;->min(JJ)J

    .line 41
    move-result-wide p2

    .line 42
    invoke-virtual {v2, p1, p2, p3}, Lt4;->k(Lt4;J)J

    .line 45
    move-result-wide p1

    .line 46
    return-wide p1

    .line 47
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 49
    const-string p2, "closed"

    .line 51
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 54
    throw p1

    .line 55
    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 57
    new-instance v0, Ljava/lang/StringBuilder;

    .line 59
    const-string v1, "byteCount < 0: "

    .line 61
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 64
    invoke-virtual {v0, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 67
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 70
    move-result-object p2

    .line 71
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 74
    throw p1

    .line 75
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 77
    const-string p2, "sink == null"

    .line 79
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 82
    throw p1
.end method

.method public final l(J)V
    .locals 0

    invoke-virtual {p0, p1, p2}, Lcp;->j(J)Z

    move-result p1

    if-eqz p1, :cond_0

    return-void

    :cond_0
    new-instance p1, Ljava/io/EOFException;

    invoke-direct {p1}, Ljava/io/EOFException;-><init>()V

    throw p1
.end method

.method public final o(Lt4;J)V
    .locals 5

    .line 1
    iget-object v0, p0, Lcp;->c:Lt4;

    .line 3
    :try_start_0
    invoke-virtual {p0, p2, p3}, Lcp;->l(J)V
    :try_end_0
    .catch Ljava/io/EOFException; {:try_start_0 .. :try_end_0} :catch_0

    .line 6
    invoke-virtual {v0, p1, p2, p3}, Lt4;->o(Lt4;J)V

    .line 9
    return-void

    .line 10
    :catch_0
    move-exception p2

    .line 11
    if-eqz v0, :cond_1

    .line 13
    :goto_0
    const-wide/16 v1, 0x2000

    .line 15
    invoke-virtual {v0, p1, v1, v2}, Lt4;->k(Lt4;J)J

    .line 18
    move-result-wide v1

    .line 19
    const-wide/16 v3, -0x1

    .line 21
    cmp-long p3, v1, v3

    .line 23
    if-eqz p3, :cond_0

    .line 25
    goto :goto_0

    .line 26
    :cond_0
    throw p2

    .line 27
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 29
    const-string p2, "source == null"

    .line 31
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 34
    throw p1
.end method

.method public final q()J
    .locals 7

    .line 1
    const-wide/16 v0, 0x1

    .line 3
    invoke-virtual {p0, v0, v1}, Lcp;->l(J)V

    .line 6
    const/4 v0, 0x0

    .line 7
    const/4 v1, 0x0

    .line 8
    :goto_0
    add-int/lit8 v2, v1, 0x1

    .line 10
    int-to-long v3, v2

    .line 11
    invoke-virtual {p0, v3, v4}, Lcp;->j(J)Z

    .line 14
    move-result v3

    .line 15
    iget-object v4, p0, Lcp;->c:Lt4;

    .line 17
    if-eqz v3, :cond_5

    .line 19
    int-to-long v5, v1

    .line 20
    invoke-virtual {v4, v5, v6}, Lt4;->r(J)B

    .line 23
    move-result v3

    .line 24
    const/16 v5, 0x30

    .line 26
    if-lt v3, v5, :cond_0

    .line 28
    const/16 v5, 0x39

    .line 30
    if-le v3, v5, :cond_2

    .line 32
    :cond_0
    const/16 v5, 0x61

    .line 34
    if-lt v3, v5, :cond_1

    .line 36
    const/16 v5, 0x66

    .line 38
    if-le v3, v5, :cond_2

    .line 40
    :cond_1
    const/16 v5, 0x41

    .line 42
    if-lt v3, v5, :cond_3

    .line 44
    const/16 v5, 0x46

    .line 46
    if-le v3, v5, :cond_2

    .line 48
    goto :goto_1

    .line 49
    :cond_2
    move v1, v2

    .line 50
    goto :goto_0

    .line 51
    :cond_3
    :goto_1
    if-eqz v1, :cond_4

    .line 53
    goto :goto_2

    .line 54
    :cond_4
    new-instance v1, Ljava/lang/NumberFormatException;

    .line 56
    const/4 v2, 0x1

    .line 57
    new-array v2, v2, [Ljava/lang/Object;

    .line 59
    invoke-static {v3}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 62
    move-result-object v3

    .line 63
    aput-object v3, v2, v0

    .line 65
    const-string v0, "Expected leading [0-9a-fA-F] character but was %#x"

    .line 67
    invoke-static {v0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 70
    move-result-object v0

    .line 71
    invoke-direct {v1, v0}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    .line 74
    throw v1

    .line 75
    :cond_5
    :goto_2
    invoke-virtual {v4}, Lt4;->q()J

    .line 78
    move-result-wide v0

    .line 79
    return-wide v0
.end method

.method public final read([BII)I
    .locals 8

    .line 1
    array-length p2, p1

    .line 2
    int-to-long v0, p2

    .line 3
    const/4 p2, 0x0

    .line 4
    int-to-long v2, p2

    .line 5
    int-to-long v6, p3

    .line 6
    move-wide v4, v6

    .line 7
    invoke-static/range {v0 .. v5}, Ldx;->a(JJJ)V

    .line 10
    iget-object p3, p0, Lcp;->c:Lt4;

    .line 12
    iget-wide v0, p3, Lt4;->d:J

    .line 14
    const-wide/16 v2, 0x0

    .line 16
    cmp-long v4, v0, v2

    .line 18
    if-nez v4, :cond_0

    .line 20
    iget-object v0, p0, Lcp;->d:Lrs;

    .line 22
    const-wide/16 v1, 0x2000

    .line 24
    invoke-interface {v0, p3, v1, v2}, Lrs;->k(Lt4;J)J

    .line 27
    move-result-wide v0

    .line 28
    const-wide/16 v2, -0x1

    .line 30
    cmp-long v4, v0, v2

    .line 32
    if-nez v4, :cond_0

    .line 34
    const/4 p1, -0x1

    .line 35
    return p1

    .line 36
    :cond_0
    iget-wide v0, p3, Lt4;->d:J

    .line 38
    invoke-static {v6, v7, v0, v1}, Ljava/lang/Math;->min(JJ)J

    .line 41
    move-result-wide v0

    .line 42
    long-to-int v1, v0

    .line 43
    invoke-virtual {p3, p1, p2, v1}, Lt4;->read([BII)I

    .line 46
    move-result p1

    .line 47
    return p1
.end method

.method public final readByte()B
    .locals 2

    .line 1
    const-wide/16 v0, 0x1

    .line 3
    invoke-virtual {p0, v0, v1}, Lcp;->l(J)V

    .line 6
    iget-object v0, p0, Lcp;->c:Lt4;

    .line 8
    invoke-virtual {v0}, Lt4;->readByte()B

    .line 11
    move-result v0

    .line 12
    return v0
.end method

.method public final readFully([B)V
    .locals 8

    .line 1
    iget-object v0, p0, Lcp;->c:Lt4;

    .line 3
    :try_start_0
    array-length v1, p1

    .line 4
    int-to-long v1, v1

    .line 5
    invoke-virtual {p0, v1, v2}, Lcp;->l(J)V
    :try_end_0
    .catch Ljava/io/EOFException; {:try_start_0 .. :try_end_0} :catch_0

    .line 8
    invoke-virtual {v0, p1}, Lt4;->readFully([B)V

    .line 11
    return-void

    .line 12
    :catch_0
    move-exception v1

    .line 13
    const/4 v2, 0x0

    .line 14
    :goto_0
    iget-wide v3, v0, Lt4;->d:J

    .line 16
    const-wide/16 v5, 0x0

    .line 18
    cmp-long v7, v3, v5

    .line 20
    if-lez v7, :cond_1

    .line 22
    long-to-int v4, v3

    .line 23
    invoke-virtual {v0, p1, v2, v4}, Lt4;->read([BII)I

    .line 26
    move-result v3

    .line 27
    const/4 v4, -0x1

    .line 28
    if-eq v3, v4, :cond_0

    .line 30
    add-int/2addr v2, v3

    .line 31
    goto :goto_0

    .line 32
    :cond_0
    new-instance p1, Ljava/lang/AssertionError;

    .line 34
    invoke-direct {p1}, Ljava/lang/AssertionError;-><init>()V

    .line 37
    throw p1

    .line 38
    :cond_1
    throw v1
.end method

.method public final readInt()I
    .locals 2

    .line 1
    const-wide/16 v0, 0x4

    .line 3
    invoke-virtual {p0, v0, v1}, Lcp;->l(J)V

    .line 6
    iget-object v0, p0, Lcp;->c:Lt4;

    .line 8
    invoke-virtual {v0}, Lt4;->readInt()I

    .line 11
    move-result v0

    .line 12
    return v0
.end method

.method public final readLong()J
    .locals 2

    .line 1
    const-wide/16 v0, 0x8

    .line 3
    invoke-virtual {p0, v0, v1}, Lcp;->l(J)V

    .line 6
    iget-object v0, p0, Lcp;->c:Lt4;

    .line 8
    invoke-virtual {v0}, Lt4;->readLong()J

    .line 11
    move-result-wide v0

    .line 12
    return-wide v0
.end method

.method public final readShort()S
    .locals 2

    .line 1
    const-wide/16 v0, 0x2

    .line 3
    invoke-virtual {p0, v0, v1}, Lcp;->l(J)V

    .line 6
    iget-object v0, p0, Lcp;->c:Lt4;

    .line 8
    invoke-virtual {v0}, Lt4;->readShort()S

    .line 11
    move-result v0

    .line 12
    return v0
.end method

.method public final skip(J)V
    .locals 6

    .line 1
    iget-boolean v0, p0, Lcp;->e:Z

    .line 3
    if-nez v0, :cond_3

    .line 5
    :goto_0
    const-wide/16 v0, 0x0

    .line 7
    cmp-long v2, p1, v0

    .line 9
    if-lez v2, :cond_2

    .line 11
    iget-object v2, p0, Lcp;->c:Lt4;

    .line 13
    iget-wide v3, v2, Lt4;->d:J

    .line 15
    cmp-long v5, v3, v0

    .line 17
    if-nez v5, :cond_1

    .line 19
    iget-object v0, p0, Lcp;->d:Lrs;

    .line 21
    const-wide/16 v3, 0x2000

    .line 23
    invoke-interface {v0, v2, v3, v4}, Lrs;->k(Lt4;J)J

    .line 26
    move-result-wide v0

    .line 27
    const-wide/16 v3, -0x1

    .line 29
    cmp-long v5, v0, v3

    .line 31
    if-eqz v5, :cond_0

    .line 33
    goto :goto_1

    .line 34
    :cond_0
    new-instance p1, Ljava/io/EOFException;

    .line 36
    invoke-direct {p1}, Ljava/io/EOFException;-><init>()V

    .line 39
    throw p1

    .line 40
    :cond_1
    :goto_1
    iget-wide v0, v2, Lt4;->d:J

    .line 42
    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->min(JJ)J

    .line 45
    move-result-wide v0

    .line 46
    invoke-virtual {v2, v0, v1}, Lt4;->skip(J)V

    .line 49
    sub-long/2addr p1, v0

    .line 50
    goto :goto_0

    .line 51
    :cond_2
    return-void

    .line 52
    :cond_3
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 54
    const-string p2, "closed"

    .line 56
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 59
    throw p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "buffer("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcp;->d:Lrs;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
