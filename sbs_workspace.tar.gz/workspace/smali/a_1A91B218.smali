.class public final La_1A91B218;
.super Ljava/lang/Object;
.source "sujaslfr.java"
# validated-35835


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltt;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Ljava/lang/String;

.field public final c:La_56D72CAA;

.field public final d:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;La_56D72CAA;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_1A91B218;->a:Landroid/content/Context;

    .line 6
    iput-object p2, p0, La_1A91B218;->b:Ljava/lang/String;

    .line 8
    iput-object p3, p0, La_1A91B218;->c:La_56D72CAA;

    .line 10
    iput-boolean p4, p0, La_1A91B218;->d:Z

    .line 12
    return-void
.end method
