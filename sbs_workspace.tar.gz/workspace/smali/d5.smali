.class public final Ld5;
# fragment-89015-config
# listener-24250-layout
# builder-71349-utils
# session-94851-service
# builder-58331-builder
# ep-movqzxmxjvnv
.super Ljava/lang/Object;
# compiled-58405
# processed-76921
# verified-38107
.source "EventHelper52.java"


# instance fields
.field public final a:Lnp;

.field public final b:LOkHttpResponse;


# direct methods
.method public constructor <init>(Lnp;LOkHttpResponse;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ld5;->a:Lnp;

    .line 6
    iput-object p2, p0, Ld5;->b:LOkHttpResponse;

    .line 8
    return-void
.end method
