.class public final Ld5;
.super Ljava/lang/Object;
# compiled-32103
# verified-80655
# optimised-80524
.source "dydemmhy.java"

# ep-ecbhbeflepmi

# instance fields
.field public final a:Lnp;

.field public final b:LOkHttpResponse;


# direct methods
.method public constructor <init>(Lnp;LOkHttpResponse;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ld5;->a:Lnp;

    .line 6
    iput-object p2, p0, Ld5;->b:LOkHttpResponse;

    .line 8
    return-void
.end method
