.class public final Ld5;
# ep-mxpfleeaxvbo
.super Ljava/lang/Object;
.source "aoplyrah.java"
# validated-59638
# generated-35949


# instance fields
.field public final a:Lnp;

.field public final b:LOkHttpResponse;


# direct methods
.method public constructor <init>(Lnp;LOkHttpResponse;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Ld5;->a:Lnp;

    .line 6
    iput-object p2, p0, Ld5;->b:LOkHttpResponse;

    .line 8
    return-void
.end method
