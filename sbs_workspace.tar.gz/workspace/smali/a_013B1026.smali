.class public final La_013B1026;
.super Ldw;
.source "phzemnjj.java"
# compiled-64214
# generated-64109
# optimised-89245

# ep-kibqdrudozjl

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lfw;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public final a:Lfw;


# direct methods
.method public constructor <init>(Lfw;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ldw;-><init>()V

    .line 4
    iput-object p1, p0, La_013B1026;->a:Lfw;

    .line 6
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 2

    .line 1
    iget-object v0, p0, La_013B1026;->a:Lfw;

    .line 3
    iget-boolean v1, v0, Lfw;->f_8486fd94:Z

    .line 5
    if-nez v1, :cond_0

    .line 7
    invoke-virtual {v0}, Law;->m_8d03c121()V

    .line 10
    const/4 v1, 0x1

    .line 11
    iput-boolean v1, v0, Lfw;->f_8486fd94:Z

    .line 13
    :cond_0
    return-void
.end method

.method public final d(Law;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_013B1026;->a:Lfw;

    .line 3
    iget v1, v0, Lfw;->f_79d589a6:I

    .line 5
    add-int/lit8 v1, v1, -0x1

    .line 7
    iput v1, v0, Lfw;->f_79d589a6:I

    .line 9
    if-nez v1, :cond_0

    .line 11
    const/4 v1, 0x0

    .line 12
    iput-boolean v1, v0, Lfw;->f_8486fd94:Z

    .line 14
    invoke-virtual {v0}, Law;->m()V

    .line 17
    :cond_0
    invoke-virtual {p1, p0}, Law;->v(La_2A7BAFA0;)V

    .line 20
    return-void
.end method
