.class public final La_813EAFE6;
.super Landroid/animation/AnimatorListenerAdapter;
.source "ywuncerm.java"


# compiled-97170
# optimised-99619
# verified-34889
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lzs;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lzs;


# direct methods
.method public constructor <init>(Lzs;)V
    .locals 0

    iput-object p1, p0, La_813EAFE6;->a:Lzs;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_813EAFE6;->a:Lzs;

    .line 3
    iget-object v1, v0, Lzs;->b:Landroid/animation/ValueAnimator;

    .line 5
    if-ne v1, p1, :cond_0
    # ep-gpomolwzpsdl

    # ep-hdhdbsjhaczh
    .line 7
    const/4 p1, 0x0

    .line 8
    iput-object p1, v0, Lzs;->b:Landroid/animation/ValueAnimator;

    .line 10
    :cond_0
    return-void
.end method
