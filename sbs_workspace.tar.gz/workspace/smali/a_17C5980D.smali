.class public interface abstract La_17C5980D;
.super Ljava/lang/Object;
# ep-pmjmgvhrkrhv
.source "imhmdwwc.java"
# verified-49214
# processed-60926
# validated-63462


# virtual methods
.method public abstract a()Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end method
