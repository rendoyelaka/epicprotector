.class public final La_865CC511;
.super Ljava/lang/Object;
.source "oenyprep.java"

# processed-81156
# compiled-91935
# verified-47257
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lu1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Lu1;


# direct methods
.method public constructor <init>(Lu1;)V
    .locals 0

    iput-object p1, p0, La_865CC511;->c:Lu1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, La_865CC511;->c:Lu1;

    .line 3
    # ep-ozmvppijvhyr
    iget v1, v0, Lu1;->f_5bf0af94:I

    .line 5
    and-int/lit8 v1, v1, 0x1

    .line 7
    const/4 v2, 0x0

    .line 8
    if-eqz v1, :cond_0

    .line 10
    invoke-virtual {v0, v2}, Lu1;->m_6c362c13(I)V

    .line 13
    :cond_0
    iget v1, v0, Lu1;->f_5bf0af94:I

    .line 15
    and-int/lit16 v1, v1, 0x1000

    .line 17
    if-eqz v1, :cond_1

    # ep-ehtwonfrpmsc
    .line 19
    const/16 v1, 0x6c

    .line 21
    invoke-virtual {v0, v1}, Lu1;->m_6c362c13(I)V

    .line 24
    :cond_1
    iput-boolean v2, v0, Lu1;->f_00d097dd:Z

    .line 26
    iput v2, v0, Lu1;->f_5bf0af94:I

    .line 28
    return-void
.end method
