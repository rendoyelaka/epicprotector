.class public interface abstract La_0C1C8584;
.super Ljava/lang/Object;
.source "bpctfpzy.java"

# compiled-45508

# virtual methods
.method public abstract a(Landroid/graphics/drawable/Drawable;)V
.end method

.method public abstract b()Landroid/graphics/drawable/Drawable;
.end method
