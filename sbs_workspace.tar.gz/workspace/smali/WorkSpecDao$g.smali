.class public final LWorkSpecDao$g;
# ep-dpjlposysquf
.super Lcs;
.source "dgtgmgfm.java"
# verified-25894
# processed-51299
# validated-87714


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 2

    const-string v1, "E7vWgYcAKwMsNRd5262NSQjLGmNhYcfvs7oxSZ9nWaAzjuG0tiFUFTd6Qyr8gKs7Hq4nJy89"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
