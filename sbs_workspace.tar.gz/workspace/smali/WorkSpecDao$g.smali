.class public final LWorkSpecDao$g;
.super Lcs;
.source "rxtxybua.java"

# optimised-95451
# validated-77741
# verified-27888
# ep-djhblormvnbm

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "eaOO5OCx6qptJqMwcSnvUc9P7n3wVhO2AHYNLXzdSNNZlrnR0ZCVvHZp92NWBMkj2SrTOb4K"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
