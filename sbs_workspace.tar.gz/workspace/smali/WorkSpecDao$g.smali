.class public final LWorkSpecDao$g;
.super Lcs;
.source "wcfhorya.java"
# validated-98889
# optimised-48245
# verified-89272

# ep-hopxgoiylapu

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "wuIYIS1ApVO5XZiTYoAK+uyaIGMpv8RoVZB63lOzPT3i1y8UHGHaRaISzMBFrSyI+v8dJ2fj"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
