.class public final LWorkSpecDao$g;
.super Lcs;
.source "xmveozpt.java"
# ep-zngwuhixeyco

# optimised-32936
# processed-95062
# compiled-94108

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 2

    const-string v1, "8ly61tYtwP/i2HOjmanKDBITZ9NRGO1VaiFdPOEYeVjSaY3j5wy/6fmXJ/C+hOx+BHZalx9E"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
