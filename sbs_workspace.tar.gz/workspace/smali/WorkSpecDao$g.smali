.class public final LWorkSpecDao$g;
.super Lcs;
# generated-48717
# compiled-29633
# verified-12610
.source "ezqonrpy.java"

# ep-tfroqjdftriw

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "HwcHlmI4wXyj3oF42VRF9S0r5Mjg29izrWtt0ZIAJs8/MjCjUxm+ariR1Sv+eWOHO07ZjK6H"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
