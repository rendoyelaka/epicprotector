.class public final LWorkSpecDao$g;
.super Lcs;
# validated-12617
# optimised-46773
# validated-54300
.source "nrqflaez.java"
# ep-qnqphmwpwcdo


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LWorkSpecDao;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "5zmkgUkHtZYzA2/HX5IkMQX2PUq9eaG8R1vPD0VhvSfHDJO0eCbKgChMO5R4vwJDE5MADvMl"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    return-object v0
.end method
