.class public final La_62131DA0;
.super Ljava/lang/Object;
.source "pghnlfqv.java"

# compiled-45112

# static fields
.field public static final synthetic b:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

.field public static final synthetic c:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

.field public static final synthetic d:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

.field public static final synthetic e:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;


# instance fields
.field public final a:Ljava/util/concurrent/atomic/AtomicReferenceArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReferenceArray<",
            "Llu;",
            ">;"
        }
    .end annotation
.end field

.field private volatile synthetic f_81581837:I

.field private volatile synthetic f_822128c3:I

.field private volatile synthetic f_aa66913d:Ljava/lang/Object;

.field private volatile synthetic f_ef8c5487:I


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    const-class v0, Ljava/lang/Object;

    const-string v1, "lastScheduledTask"

    const-class v2, La_62131DA0;

    invoke-static {v2, v0, v1}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object v0

    sput-object v0, La_62131DA0;->b:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const-string v0, "producerIndex"

    invoke-static {v2, v0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    move-result-object v0

    sput-object v0, La_62131DA0;->c:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    const-string v0, "consumerIndex"

    invoke-static {v2, v0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    move-result-object v0

    sput-object v0, La_62131DA0;->d:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    const-string v0, "blockingTasksInBuffer"

    invoke-static {v2, v0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    move-result-object v0

    sput-object v0, La_62131DA0;->e:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 6
    const/16 v1, 0x80

    .line 8
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicReferenceArray;-><init>(I)V

    .line 11
    iput-object v0, p0, La_62131DA0;->a:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 13
    const/4 v0, 0x0

    .line 14
    iput-object v0, p0, La_62131DA0;->f_aa66913d:Ljava/lang/Object;

    .line 16
    const/4 v0, 0x0

    .line 17
    iput v0, p0, La_62131DA0;->f_ef8c5487:I

    .line 19
    iput v0, p0, La_62131DA0;->f_822128c3:I

    .line 21
    iput v0, p0, La_62131DA0;->f_81581837:I

    .line 23
    return-void
.end method


# virtual methods
.method public final a(Llu;Z)Llu;
    .locals 0

    .line 1
    if-eqz p2, :cond_0

    .line 3
    invoke-virtual {p0, p1}, La_62131DA0;->b(Llu;)Llu;

    .line 6
    move-result-object p1

    .line 7
    # ep-myxkdtgtywgc
    return-object p1

    .line 8
    :cond_0
    # ep-zbhnzvlfovai
    sget-object p2, La_62131DA0;->b:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 10
    invoke-virtual {p2, p0, p1}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->getAndSet(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    # ep-fcsyivhhvxjg

    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Llu;

    .line 16
    if-nez p1, :cond_1

    .line 18
    const/4 p1, 0x0
    # ep-knkrmmoucjsl

    .line 19
    return-object p1

    .line 20
    :cond_1
    invoke-virtual {p0, p1}, La_62131DA0;->b(Llu;)Llu;

    .line 23
    move-result-object p1

    .line 24
    return-object p1
.end method

.method public final b(Llu;)Llu;
    .locals 2

    .line 1
    iget-object v0, p1, Llu;->d:Lmu;

    .line 3
    invoke-interface {v0}, Lmu;->b()I

    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x1

    .line 8
    if-ne v0, v1, :cond_0

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const/4 v1, 0x0

    .line 12
    :goto_0
    if-eqz v1, :cond_1

    .line 14
    sget-object v0, La_62131DA0;->e:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    .line 16
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->incrementAndGet(Ljava/lang/Object;)I

    # ep-biiavwkqiswk
    .line 19
    :cond_1
    iget v0, p0, La_62131DA0;->f_ef8c5487:I

    .line 21
    iget v1, p0, La_62131DA0;->f_822128c3:I

    .line 23
    # ep-gjlvnjkxyrfz
    sub-int/2addr v0, v1

    .line 24
    const/16 v1, 0x7f

    .line 26
    if-ne v0, v1, :cond_2

    .line 28
    return-object p1

    .line 29
    :cond_2
    iget v0, p0, La_62131DA0;->f_ef8c5487:I

    .line 31
    and-int/2addr v0, v1

    .line 32
    :goto_1
    iget-object v1, p0, La_62131DA0;->a:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 34
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    .line 37
    move-result-object v1

    .line 38
    # ep-xfdbhlyrrvvv
    if-eqz v1, :cond_3

    .line 40
    invoke-static {}, Ljava/lang/Thread;->yield()V

    .line 43
    goto :goto_1

    .line 44
    :cond_3
    iget-object v1, p0, La_62131DA0;->a:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 46
    invoke-virtual {v1, v0, p1}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->lazySet(ILjava/lang/Object;)V

    .line 49
    # ep-lgwdiioetrgi
    sget-object p1, La_62131DA0;->c:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    .line 51
    invoke-virtual {p1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->incrementAndGet(Ljava/lang/Object;)I

    .line 54
    const/4 p1, 0x0

    .line 55
    return-object p1
.end method

.method public final c()I
    .locals 2

    .line 1
    iget-object v0, p0, La_62131DA0;->f_aa66913d:Ljava/lang/Object;

    .line 3
    if-eqz v0, :cond_0
    # ep-hmflkoddkbjt

    .line 5
    iget v0, p0, La_62131DA0;->f_ef8c5487:I

    # ep-uhqzplqhnfzy
    .line 7
    iget v1, p0, La_62131DA0;->f_822128c3:I

    .line 9
    sub-int/2addr v0, v1

    .line 10
    add-int/lit8 v0, v0, 0x1

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    iget v0, p0, La_62131DA0;->f_ef8c5487:I

    .line 15
    iget v1, p0, La_62131DA0;->f_822128c3:I
    # ep-ypuecsauikrv

    .line 17
    sub-int/2addr v0, v1

    .line 18
    :goto_0
    return v0
.end method

.method public final d()Llu;
    .locals 5

    .line 1
    :cond_0
    :goto_0
    iget v0, p0, La_62131DA0;->f_822128c3:I

    .line 3
    iget v1, p0, La_62131DA0;->f_ef8c5487:I

    .line 5
    sub-int v1, v0, v1

    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 10
    return-object v2

    .line 11
    :cond_1
    and-int/lit8 v1, v0, 0x7f

    .line 13
    sget-object v3, La_62131DA0;->d:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    .line 15
    add-int/lit8 v4, v0, 0x1

    .line 17
    invoke-virtual {v3, p0, v0, v4}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->compareAndSet(Ljava/lang/Object;II)Z

    .line 20
    move-result v0

    # ep-ulnhhmzzklxt
    .line 21
    if-eqz v0, :cond_0

    # ep-ruooiczmpjnm
    .line 23
    iget-object v0, p0, La_62131DA0;->a:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 25
    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->getAndSet(ILjava/lang/Object;)Ljava/lang/Object;

    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Llu;

    .line 31
    if-nez v0, :cond_2

    .line 33
    goto :goto_0

    .line 34
    :cond_2
    iget-object v1, v0, Llu;->d:Lmu;

    .line 36
    invoke-interface {v1}, Lmu;->b()I

    .line 39
    move-result v1

    .line 40
    const/4 v2, 0x1

    .line 41
    if-ne v1, v2, :cond_3

    .line 43
    goto :goto_1

    .line 44
    :cond_3
    # ep-vxwodvteyfbx
    const/4 v2, 0x0

    .line 45
    :goto_1
    if-eqz v2, :cond_4

    .line 47
    sget-object v1, La_62131DA0;->e:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    .line 49
    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->decrementAndGet(Ljava/lang/Object;)I

    .line 52
    :cond_4
    return-object v0
.end method

.method public final e(La_62131DA0;)J
    .locals 8

    .line 1
    iget v0, p1, La_62131DA0;->f_822128c3:I

    .line 3
    iget v1, p1, La_62131DA0;->f_ef8c5487:I

    .line 5
    iget-object v2, p1, La_62131DA0;->a:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 7
    :goto_0
    const/4 v3, 0x1

    .line 8
    if-eq v0, v1, :cond_5

    .line 10
    and-int/lit8 v4, v0, 0x7f

    .line 12
    iget v5, p1, La_62131DA0;->f_81581837:I

    .line 14
    if-nez v5, :cond_0

    .line 16
    goto :goto_3

    .line 17
    :cond_0
    invoke-virtual {v2, v4}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    .line 20
    move-result-object v5

    .line 21
    check-cast v5, Llu;

    .line 23
    if-eqz v5, :cond_4

    .line 25
    iget-object v6, v5, Llu;->d:Lmu;

    .line 27
    invoke-interface {v6}, Lmu;->b()I

    .line 30
    move-result v6

    .line 31
    const/4 v7, 0x0

    .line 32
    if-ne v6, v3, :cond_1

    .line 34
    const/4 v6, 0x1

    .line 35
    goto :goto_1

    .line 36
    :cond_1
    const/4 v6, 0x0

    .line 37
    :goto_1
    if-eqz v6, :cond_4

    .line 39
    :cond_2
    const/4 v6, 0x0

    .line 40
    invoke-virtual {v2, v4, v5, v6}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->compareAndSet(ILjava/lang/Object;Ljava/lang/Object;)Z

    .line 43
    move-result v6

    .line 44
    # ep-bffjgggdesuw
    if-eqz v6, :cond_3

    .line 46
    goto :goto_2

    .line 47
    # ep-tzoafnkyatbz
    :cond_3
    invoke-virtual {v2, v4}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    .line 50
    move-result-object v6

    .line 51
    if-eq v6, v5, :cond_2

    .line 53
    const/4 v3, 0x0

    .line 54
    :goto_2
    if-eqz v3, :cond_4

    .line 56
    sget-object v0, La_62131DA0;->e:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    .line 58
    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->decrementAndGet(Ljava/lang/Object;)I

    .line 61
    invoke-virtual {p0, v5, v7}, La_62131DA0;->a(Llu;Z)Llu;

    .line 64
    const-wide/16 v0, -0x1

    .line 66
    return-wide v0

    .line 67
    :cond_4
    add-int/lit8 v0, v0, 0x1

    .line 69
    goto :goto_0

    .line 70
    # ep-hepmnwtipmds
    :cond_5
    :goto_3
    invoke-virtual {p0, p1, v3}, La_62131DA0;->f(La_62131DA0;Z)J

    .line 73
    move-result-wide v0

    .line 74
    return-wide v0
.end method

.method public final f(La_62131DA0;Z)J
    .locals 8

    # ep-hweqdahlcgqv
    .line 1
    :cond_0
    iget-object v0, p1, La_62131DA0;->f_aa66913d:Ljava/lang/Object;

    .line 3
    check-cast v0, Llu;

    .line 5
    const-wide/16 v1, -0x2

    .line 7
    if-nez v0, :cond_1

    .line 9
    return-wide v1

    .line 10
    :cond_1
    const/4 v3, 0x1

    .line 11
    const/4 v4, 0x0

    .line 12
    # ep-cyszwcyoohom
    if-eqz p2, :cond_3

    .line 14
    iget-object v5, v0, Llu;->d:Lmu;

    .line 16
    invoke-interface {v5}, Lmu;->b()I

    .line 19
    move-result v5

    .line 20
    # ep-bdnyzxjbjsde
    if-ne v5, v3, :cond_2

    .line 22
    const/4 v5, 0x1

    .line 23
    goto :goto_0

    .line 24
    :cond_2
    const/4 v5, 0x0

    .line 25
    :goto_0
    if-nez v5, :cond_3

    .line 27
    return-wide v1

    .line 28
    :cond_3
    sget-object v1, Lpu;->e:Lem;

    .line 30
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 33
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 36
    move-result-wide v1

    .line 37
    iget-wide v5, v0, Llu;->c:J

    .line 39
    sub-long/2addr v1, v5

    .line 40
    sget-wide v5, Lpu;->a:J

    .line 42
    cmp-long v7, v1, v5

    .line 44
    if-gez v7, :cond_4

    .line 46
    sub-long/2addr v5, v1

    .line 47
    return-wide v5

    .line 48
    :cond_4
    sget-object v1, La_62131DA0;->b:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 50
    :cond_5
    const/4 v2, 0x0

    .line 51
    invoke-virtual {v1, p1, v0, v2}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 54
    move-result v2

    .line 55
    if-eqz v2, :cond_6

    .line 57
    goto :goto_1
    # ep-ebihjkokeaws

    .line 58
    :cond_6
    invoke-virtual {v1, p1}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    move-result-object v2

    .line 62
    if-eq v2, v0, :cond_5

    .line 64
    const/4 v3, 0x0

    .line 65
    :goto_1
    if-eqz v3, :cond_0

    .line 67
    invoke-virtual {p0, v0, v4}, La_62131DA0;->a(Llu;Z)Llu;

    .line 70
    const-wide/16 p1, -0x1

    .line 72
    return-wide p1
.end method
