.class public final La_787EAA9B;
# ep-ivwlrwjgvtoh
.super La_2A2726CC;
.source "zixoxnui.java"
# processed-65295


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_E86E9D05;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "e"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_2A2726CC;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/text/StaticLayout$Builder;Landroid/widget/TextView;)V
    .locals 0

    invoke-static {p2}, Ls;->e(Landroid/widget/TextView;)Landroid/text/TextDirectionHeuristic;

    move-result-object p2

    invoke-static {p1, p2}, La_F79784E5;->w(Landroid/text/StaticLayout$Builder;Landroid/text/TextDirectionHeuristic;)V

    return-void
.end method

.method public b(Landroid/widget/TextView;)Z
    .locals 0

    invoke-static {p1}, Ls;->v(Landroid/widget/TextView;)Z

    move-result p1

    return p1
.end method
