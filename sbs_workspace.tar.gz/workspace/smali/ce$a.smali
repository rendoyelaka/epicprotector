.class public final Lce$a;
.super Ljava/lang/Object;
# ep-udtjhjmwfooh
.source "ImageHelper45.java"

# generated-37919

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lce;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation
