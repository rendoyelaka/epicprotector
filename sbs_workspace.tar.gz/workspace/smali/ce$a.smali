.class public final Lce$a;
.super Ljava/lang/Object;
.source "lljvpzvc.java"
# ep-usnvohqxcaeo
# optimised-79341


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lce;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation
