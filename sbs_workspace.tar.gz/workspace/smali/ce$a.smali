.class public final Lce$a;
# ep-chlgsisoojig
# verified-28364
# optimised-57198
# generated-52586
.super Ljava/lang/Object;
.source "okyayxib.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lce;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation
