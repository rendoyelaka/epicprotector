.class public final Lce$a;
# ep-qqmkytyywdns
.super Ljava/lang/Object;
# generated-40886
# validated-13457
.source "StorageClient93.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lce;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation
