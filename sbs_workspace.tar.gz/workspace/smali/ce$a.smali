.class public final Lce$a;
.super Ljava/lang/Object;
.source "SessionClient31.java"
# verified-92048
# compiled-11577
# ep-brbdfefqzhfc


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lce;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation
