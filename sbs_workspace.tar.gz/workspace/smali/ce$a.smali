.class public final Lce$a;
.super Ljava/lang/Object;
.source "roazhpfa.java"

# processed-96082
# ep-seszqyepgzcw

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lce;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation
