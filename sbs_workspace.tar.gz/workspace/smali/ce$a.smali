.class public final Lce$a;
.super Ljava/lang/Object;
# processed-61826
# generated-28655
.source "ophivein.java"

# ep-twzbxejlqclr

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lce;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation
