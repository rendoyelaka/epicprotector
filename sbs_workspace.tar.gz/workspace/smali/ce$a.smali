.class public final Lce$a;
# ep-hhsqyjffailc
.super Ljava/lang/Object;
.source "jfpixicf.java"

# optimised-92283
# verified-82136

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lce;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation
