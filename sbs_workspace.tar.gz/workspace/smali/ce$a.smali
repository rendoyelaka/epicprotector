.class public final Lce$a;
.super Ljava/lang/Object;
# optimised-83920
# processed-20877
.source "jkfpjwka.java"

# ep-lslazmqewvlf

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lce;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation
