.class public final Lan;
# ep-nvgtfniyybqf
# processed-94606
.super Ljava/lang/Object;
.source "iyddyjkq.java"

# interfaces
.implements Ljava/lang/Cloneable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lan$b;
    }
.end annotation


# static fields
.field public static final A:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lvo;",
            ">;"
        }
    .end annotation
.end field

.field public static final B:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LConnectionSpec;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final c:LOkHttpDispatcher;

.field public final d:Ljava/net/Proxy;

.field public final e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lvo;",
            ">;"
        }
    .end annotation
.end field

.field public final f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LConnectionSpec;",
            ">;"
        }
    .end annotation
.end field

.field public final g:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Loi;",
            ">;"
        }
    .end annotation
.end field

.field public final h:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Loi;",
            ">;"
        }
    .end annotation
.end field

.field public final i:Ljava/net/ProxySelector;

.field public final j:Ls8;

.field public final k:Ljavax/net/SocketFactory;

.field public final l:Ljavax/net/ssl/SSLSocketFactory;

.field public final m:Ln00;

.field public final n:Ljavax/net/ssl/HostnameVerifier;

.field public final o:Lw5;

.field public final p:Lr3;

.field public final q:Lr3;

.field public final r:LConnectionPool;

.field public final s:Lra;

.field public final t:Z

.field public final u:Z

.field public final v:Z

.field public final w:I

.field public final x:I

.field public final y:I

.field public final z:I


# direct methods
.method public static constructor <clinit>()V
    .locals 5

    .line 1
    const/4 v0, 0x2

    .line 2
    new-array v1, v0, [Lvo;

    .line 4
    sget-object v2, Lvo;->g:Lvo;

    .line 6
    const/4 v3, 0x0

    .line 7
    aput-object v2, v1, v3

    .line 9
    sget-object v2, Lvo;->e:Lvo;

    .line 11
    const/4 v4, 0x1

    .line 12
    aput-object v2, v1, v4

    .line 14
    invoke-static {v1}, Lex;->i([Ljava/lang/Object;)Ljava/util/List;

    .line 17
    move-result-object v1

    .line 18
    sput-object v1, Lan;->A:Ljava/util/List;

    .line 20
    const/4 v1, 0x3

    .line 21
    new-array v1, v1, [LConnectionSpec;

    .line 23
    sget-object v2, LConnectionSpec;->e:LConnectionSpec;

    .line 25
    aput-object v2, v1, v3

    .line 27
    sget-object v2, LConnectionSpec;->f:LConnectionSpec;

    .line 29
    aput-object v2, v1, v4

    .line 31
    sget-object v2, LConnectionSpec;->g:LConnectionSpec;

    .line 33
    aput-object v2, v1, v0

    .line 35
    invoke-static {v1}, Lex;->i([Ljava/lang/Object;)Ljava/util/List;

    .line 38
    move-result-object v0

    .line 39
    sput-object v0, Lan;->B:Ljava/util/List;

    .line 41
    new-instance v0, Lan$a;

    .line 43
    invoke-direct {v0}, Lan$a;-><init>()V

    .line 46
    sput-object v0, Lpi;->a:Lan$a;

    .line 48
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    new-instance v0, Lan$b;

    invoke-direct {v0}, Lan$b;-><init>()V

    invoke-direct {p0, v0}, Lan;-><init>(Lan$b;)V

    return-void
.end method

.method public constructor <init>(Lan$b;)V
    .locals 7

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iget-object v0, p1, Lan$b;->a:LOkHttpDispatcher;

    iput-object v0, p0, Lan;->c:LOkHttpDispatcher;

    .line 4
    iget-object v0, p1, Lan$b;->b:Ljava/net/Proxy;

    iput-object v0, p0, Lan;->d:Ljava/net/Proxy;

    .line 5
    iget-object v0, p1, Lan$b;->c:Ljava/util/List;

    iput-object v0, p0, Lan;->e:Ljava/util/List;

    .line 6
    iget-object v0, p1, Lan$b;->d:Ljava/util/List;

    iput-object v0, p0, Lan;->f:Ljava/util/List;

    .line 7
    iget-object v1, p1, Lan$b;->e:Ljava/util/ArrayList;

    .line 8
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {v2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    .line 9
    iput-object v1, p0, Lan;->g:Ljava/util/List;

    .line 10
    iget-object v1, p1, Lan$b;->f:Ljava/util/ArrayList;

    .line 11
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {v2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    .line 12
    iput-object v1, p0, Lan;->h:Ljava/util/List;

    .line 13
    iget-object v1, p1, Lan$b;->g:Ljava/net/ProxySelector;

    iput-object v1, p0, Lan;->i:Ljava/net/ProxySelector;

    .line 14
    iget-object v1, p1, Lan$b;->h:Ls8;

    iput-object v1, p0, Lan;->j:Ls8;

    .line 15
    iget-object v1, p1, Lan$b;->i:Ljavax/net/SocketFactory;

    iput-object v1, p0, Lan;->k:Ljavax/net/SocketFactory;

    .line 16
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v4, 0x1

    if-eqz v3, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LConnectionSpec;

    if-nez v2, :cond_1

    .line 17
    iget-boolean v2, v3, LConnectionSpec;->a:Z

    if-eqz v2, :cond_0

    :cond_1
    const/4 v2, 0x1

    goto :goto_0

    .line 18
    :cond_2
    iget-object v0, p1, Lan$b;->j:Ljavax/net/ssl/SSLSocketFactory;

    if-nez v0, :cond_5

    if-nez v2, :cond_3

    goto :goto_1

    :cond_3
    const-string v0, "Unexpected default trust managers:"

    .line 19
    :try_start_0
    invoke-static {}, Ljavax/net/ssl/TrustManagerFactory;->getDefaultAlgorithm()Ljava/lang/String;

    move-result-object v2

    .line 20
    invoke-static {v2}, Ljavax/net/ssl/TrustManagerFactory;->getInstance(Ljava/lang/String;)Ljavax/net/ssl/TrustManagerFactory;

    move-result-object v2

    const/4 v3, 0x0

    .line 21
    invoke-virtual {v2, v3}, Ljavax/net/ssl/TrustManagerFactory;->init(Ljava/security/KeyStore;)V

    .line 22
    invoke-virtual {v2}, Ljavax/net/ssl/TrustManagerFactory;->getTrustManagers()[Ljavax/net/ssl/TrustManager;

    move-result-object v2

    .line 23
    array-length v5, v2

    if-ne v5, v4, :cond_4

    aget-object v5, v2, v1

    instance-of v6, v5, Ljavax/net/ssl/X509TrustManager;

    if-eqz v6, :cond_4

    .line 24
    check-cast v5, Ljavax/net/ssl/X509TrustManager;
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    const-string v0, "TLS"

    .line 25
    invoke-static {v0}, Ljavax/net/ssl/SSLContext;->getInstance(Ljava/lang/String;)Ljavax/net/ssl/SSLContext;

    move-result-object v0

    new-array v2, v4, [Ljavax/net/ssl/TrustManager;

    aput-object v5, v2, v1

    .line 26
    invoke-virtual {v0, v3, v2, v3}, Ljavax/net/ssl/SSLContext;->init([Ljavax/net/ssl/KeyManager;[Ljavax/net/ssl/TrustManager;Ljava/security/SecureRandom;)V

    .line 27
    invoke-virtual {v0}, Ljavax/net/ssl/SSLContext;->getSocketFactory()Ljavax/net/ssl/SSLSocketFactory;

    move-result-object v0
    :try_end_1
    .catch Ljava/security/GeneralSecurityException; {:try_start_1 .. :try_end_1} :catch_0

    .line 28
    iput-object v0, p0, Lan;->l:Ljavax/net/ssl/SSLSocketFactory;

    .line 29
    sget-object v0, Lfo;->a:Lfo;

    .line 30
    invoke-virtual {v0, v5}, Lfo;->c(Ljavax/net/ssl/X509TrustManager;)Ln00;

    move-result-object v0

    .line 31
    iput-object v0, p0, Lan;->m:Ln00;

    goto :goto_2

    .line 32
    :catch_0
    new-instance p1, Ljava/lang/AssertionError;

    invoke-direct {p1}, Ljava/lang/AssertionError;-><init>()V

    throw p1

    .line 33
    :cond_4
    :try_start_2
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 34
    invoke-static {v2}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_2
    .catch Ljava/security/GeneralSecurityException; {:try_start_2 .. :try_end_2} :catch_1

    .line 35
    :catch_1
    new-instance p1, Ljava/lang/AssertionError;

    invoke-direct {p1}, Ljava/lang/AssertionError;-><init>()V

    throw p1

    .line 36
    :cond_5
    :goto_1
    iput-object v0, p0, Lan;->l:Ljavax/net/ssl/SSLSocketFactory;

    .line 37
    iget-object v0, p1, Lan$b;->k:Ln00;

    iput-object v0, p0, Lan;->m:Ln00;

    .line 38
    :goto_2
    iget-object v0, p1, Lan$b;->l:Ljavax/net/ssl/HostnameVerifier;

    iput-object v0, p0, Lan;->n:Ljavax/net/ssl/HostnameVerifier;

    .line 39
    iget-object v0, p0, Lan;->m:Ln00;

    .line 40
    iget-object v1, p1, Lan$b;->m:Lw5;

    iget-object v2, v1, Lw5;->b:Ln00;

    .line 41
    invoke-static {v2, v0}, Lex;->f(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6

    goto :goto_3

    :cond_6
    new-instance v2, Lw5;

    iget-object v1, v1, Lw5;->a:Ljava/util/Set;

    invoke-direct {v2, v1, v0}, Lw5;-><init>(Ljava/util/Set;Ln00;)V

    move-object v1, v2

    .line 42
    :goto_3
    iput-object v1, p0, Lan;->o:Lw5;

    .line 43
    iget-object v0, p1, Lan$b;->n:Lr3;

    iput-object v0, p0, Lan;->p:Lr3;

    .line 44
    iget-object v0, p1, Lan$b;->o:Lr3;

    iput-object v0, p0, Lan;->q:Lr3;

    .line 45
    iget-object v0, p1, Lan$b;->p:LConnectionPool;

    iput-object v0, p0, Lan;->r:LConnectionPool;

    .line 46
    iget-object v0, p1, Lan$b;->q:Lra;

    iput-object v0, p0, Lan;->s:Lra;

    .line 47
    iget-boolean v0, p1, Lan$b;->r:Z

    iput-boolean v0, p0, Lan;->t:Z

    .line 48
    iget-boolean v0, p1, Lan$b;->s:Z

    iput-boolean v0, p0, Lan;->u:Z

    .line 49
    iget-boolean v0, p1, Lan$b;->t:Z

    iput-boolean v0, p0, Lan;->v:Z

    .line 50
    iget v0, p1, Lan$b;->u:I

    iput v0, p0, Lan;->w:I

    .line 51
    iget v0, p1, Lan$b;->v:I

    iput v0, p0, Lan;->x:I

    .line 52
    iget v0, p1, Lan$b;->w:I

    iput v0, p0, Lan;->y:I

    .line 53
    iget p1, p1, Lan$b;->x:I

    iput p1, p0, Lan;->z:I

    return-void
.end method
