.class public final Lb00;
.super Lzy;
.source "jhxygsbj.java"
# optimised-34950
# validated-75435

# ep-ahilclqxgeiy

# instance fields
.field public final e:Landroid/view/WindowInsetsController;

.field public final f:Landroid/view/Window;


# direct methods
.method public constructor <init>(Landroid/view/Window;)V
    .locals 2

    .line 1
    invoke-static {p1}, Lxz;->b(Landroid/view/Window;)Landroid/view/WindowInsetsController;

    .line 4
    move-result-object v0

    .line 5
    invoke-direct {p0}, Lzy;-><init>()V

    .line 8
    new-instance v1, Lks;

    .line 10
    invoke-direct {v1}, Lks;-><init>()V

    .line 13
    iput-object v0, p0, Lb00;->e:Landroid/view/WindowInsetsController;

    .line 15
    iput-object p1, p0, Lb00;->f:Landroid/view/Window;

    .line 17
    return-void
.end method


# virtual methods
.method public final a(Z)V
    .locals 3

    .line 1
    iget-object v0, p0, Lb00;->e:Landroid/view/WindowInsetsController;

    .line 3
    iget-object v1, p0, Lb00;->f:Landroid/view/Window;

    .line 5
    if-eqz p1, :cond_1

    .line 7
    if-eqz v1, :cond_0

    .line 9
    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {p1}, Landroid/view/View;->getSystemUiVisibility()I

    .line 16
    move-result v1

    .line 17
    const/16 v2, 0x10

    .line 19
    or-int/2addr v1, v2

    .line 20
    invoke-virtual {p1, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 23
    :cond_0
    invoke-static {v0}, Lxz;->c(Landroid/view/WindowInsetsController;)V

    .line 26
    goto :goto_0

    .line 27
    :cond_1
    if-eqz v1, :cond_2

    .line 29
    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 32
    move-result-object p1

    .line 33
    invoke-virtual {p1}, Landroid/view/View;->getSystemUiVisibility()I

    .line 36
    move-result v1

    .line 37
    const/16 v2, -0x11

    .line 39
    and-int/2addr v1, v2

    .line 40
    invoke-virtual {p1, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 43
    :cond_2
    invoke-static {v0}, Lxz;->d(Landroid/view/WindowInsetsController;)V

    .line 46
    :goto_0
    return-void
.end method

.method public final b(Z)V
    .locals 3

    .line 1
    iget-object v0, p0, Lb00;->e:Landroid/view/WindowInsetsController;

    .line 3
    iget-object v1, p0, Lb00;->f:Landroid/view/Window;

    .line 5
    if-eqz p1, :cond_1

    .line 7
    if-eqz v1, :cond_0

    .line 9
    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {p1}, Landroid/view/View;->getSystemUiVisibility()I

    .line 16
    move-result v1

    .line 17
    const/16 v2, 0x2000

    .line 19
    or-int/2addr v1, v2

    .line 20
    invoke-virtual {p1, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 23
    :cond_0
    invoke-static {v0}, Lxz;->e(Landroid/view/WindowInsetsController;)V

    .line 26
    goto :goto_0

    .line 27
    :cond_1
    if-eqz v1, :cond_2

    .line 29
    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 32
    move-result-object p1

    .line 33
    invoke-virtual {p1}, Landroid/view/View;->getSystemUiVisibility()I

    .line 36
    move-result v1

    .line 37
    const/16 v2, -0x2001

    .line 39
    and-int/2addr v1, v2

    .line 40
    invoke-virtual {p1, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 43
    :cond_2
    invoke-static {v0}, Lxz;->f(Landroid/view/WindowInsetsController;)V

    .line 46
    :goto_0
    return-void
.end method
