.class public final La_44CD6018;
.super Ljava/lang/Object;
# ep-kwotbpnfaqwz
.source "cpujtqdw.java"
# generated-49874
# optimised-43085
# processed-88693

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "a"
.end annotation


# instance fields
.field public final synthetic c:Ljp;


# direct methods
.method public constructor <init>(Ljp;)V
    .locals 0

    iput-object p1, p0, La_44CD6018;->c:Ljp;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, La_44CD6018;->c:Ljp;

    invoke-virtual {v0}, Ljp;->a()V

    return-void
.end method
