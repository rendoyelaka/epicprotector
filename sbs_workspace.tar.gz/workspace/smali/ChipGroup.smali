.class public final LChipGroup;
.super Lad;
# ep-tgzzitebslnu
# optimised-98922
.source "uzhgpntu.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LChipGroup$b;,
        LChipGroup$d;,
        LChipGroup$c;
    }
.end annotation


# instance fields
.field public g:I

.field public h:I


# direct methods
.method private getVisibleChipCount()I
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x0

    .line 4
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 7
    move-result v3

    .line 8
    if-ge v1, v3, :cond_2

    .line 10
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 13
    move-result-object v3

    .line 14
    instance-of v3, v3, Lcom/google/android/material/chip/Chip;

    .line 16
    if-eqz v3, :cond_1

    .line 18
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 21
    move-result-object v3

    .line 22
    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    .line 25
    move-result v3

    .line 26
    if-nez v3, :cond_0

    .line 28
    const/4 v3, 0x1

    .line 29
    goto :goto_1

    .line 30
    :cond_0
    const/4 v3, 0x0

    .line 31
    :goto_1
    if-eqz v3, :cond_1

    .line 33
    add-int/lit8 v2, v2, 0x1

    .line 35
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 37
    goto :goto_0

    .line 38
    :cond_2
    return v2
.end method


# virtual methods
.method public final a()Z
    .locals 1

    iget-boolean v0, p0, Lad;->e:Z

    return v0
.end method

.method public final checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 1

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z

    move-result v0

    if-eqz v0, :cond_0

    instance-of p1, p1, LChipGroup$b;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_wrg0vup0
    goto :ep_s_wrg0vup0
    :ep_d_wrg0vup0
    nop
    :ep_s_wrg0vup0
    if-eqz p1, :cond_0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_obicd8kd
    goto :ep_s_obicd8kd
    :ep_d_obicd8kd
    nop
    :ep_s_obicd8kd
    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 1

    new-instance v0, LChipGroup$b;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_q9o0dvbf
    goto :ep_s_q9o0dvbf
    :ep_d_q9o0dvbf
    nop
    :ep_s_q9o0dvbf
    invoke-direct {v0}, LChipGroup$b;-><init>()V

    return-object v0
.end method

.method public final generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    .line 1
    new-instance v0, LChipGroup$b;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_0h2g988d
    goto :ep_s_0h2g988d
    :ep_d_0h2g988d
    nop
    :ep_s_0h2g988d
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_rf37oz1i
    goto :ep_s_rf37oz1i
    :ep_d_rf37oz1i
    nop
    :ep_s_rf37oz1i
    move-result-object v1

    invoke-direct {v0, v1, p1}, LChipGroup$b;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object v0
.end method

.method public final generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 1

    .line 2
    new-instance v0, LChipGroup$b;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_51v9qm0r
    goto :ep_s_51v9qm0r
    :ep_d_51v9qm0r
    nop
    :ep_s_51v9qm0r
    invoke-direct {v0, p1}, LChipGroup$b;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method public getCheckedChipId()I
    .locals 1

    const/4 v0, 0x0

    throw v0
.end method

.method public getCheckedChipIds()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v0, 0x0

    throw v0
.end method

.method public getChipSpacingHorizontal()I
    .locals 1

    iget v0, p0, LChipGroup;->g:I

    return v0
.end method

.method public getChipSpacingVertical()I
    .locals 1

    iget v0, p0, LChipGroup;->h:I

    return v0
.end method

.method public final onFinishInflate()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onFinishInflate()V

    .line 4
    const/4 v0, 0x0

    .line 5
    throw v0
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 4
    iget-boolean p1, p0, Lad;->e:Z

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-direct {p0}, LChipGroup;->getVisibleChipCount()I

    .line 11
    :cond_0
    invoke-virtual {p0}, Lad;->getRowCount()I

    .line 14
    const/4 p1, 0x0

    .line 15
    throw p1
.end method

.method public setChipSpacing(I)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, LChipGroup;->setChipSpacingHorizontal(I)V

    .line 4
    invoke-virtual {p0, p1}, LChipGroup;->setChipSpacingVertical(I)V

    .line 7
    return-void
.end method

.method public setChipSpacingHorizontal(I)V
    .locals 1

    .line 1
    iget v0, p0, LChipGroup;->g:I

    .line 3
    if-eq v0, p1, :cond_0

    .line 5
    iput p1, p0, LChipGroup;->g:I

    .line 7
    invoke-virtual {p0, p1}, Lad;->setItemSpacing(I)V

    .line 10
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 13
    :cond_0
    return-void
.end method

.method public setChipSpacingHorizontalResource(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_h8tm9ija
    goto :ep_s_h8tm9ija
    :ep_d_h8tm9ija
    nop
    :ep_s_h8tm9ija
    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_x356y3sm
    goto :ep_s_x356y3sm
    :ep_d_x356y3sm
    nop
    :ep_s_x356y3sm
    move-result p1

    invoke-virtual {p0, p1}, LChipGroup;->setChipSpacingHorizontal(I)V

    return-void
.end method

.method public setChipSpacingResource(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_9wiflryt
    goto :ep_s_9wiflryt
    :ep_d_9wiflryt
    nop
    :ep_s_9wiflryt
    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_6iat87ic
    goto :ep_s_6iat87ic
    :ep_d_6iat87ic
    nop
    :ep_s_6iat87ic
    invoke-virtual {p0, p1}, LChipGroup;->setChipSpacing(I)V

    return-void
.end method

.method public setChipSpacingVertical(I)V
    .locals 1

    .line 1
    iget v0, p0, LChipGroup;->h:I

    .line 3
    if-eq v0, p1, :cond_0

    .line 5
    iput p1, p0, LChipGroup;->h:I

    .line 7
    invoke-virtual {p0, p1}, Lad;->setLineSpacing(I)V

    .line 10
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 13
    :cond_0
    return-void
.end method

.method public setChipSpacingVerticalResource(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_5s2zqmd6
    goto :ep_s_5s2zqmd6
    :ep_d_5s2zqmd6
    nop
    :ep_s_5s2zqmd6
    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_7jdu6ehn
    goto :ep_s_7jdu6ehn
    :ep_d_7jdu6ehn
    nop
    :ep_s_7jdu6ehn
    move-result p1

    invoke-virtual {p0, p1}, LChipGroup;->setChipSpacingVertical(I)V

    return-void
.end method

.method public setDividerDrawableHorizontal(Landroid/graphics/drawable/Drawable;)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_c5j89bpl
    goto :ep_s_c5j89bpl
    :ep_d_c5j89bpl
    nop
    :ep_s_c5j89bpl
    const-string v0, "Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing."

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_fgaip6s1
    goto :ep_s_fgaip6s1
    :ep_d_fgaip6s1
    nop
    :ep_s_fgaip6s1
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public setDividerDrawableVertical(Landroid/graphics/drawable/Drawable;)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_yfphyi0i
    goto :ep_s_yfphyi0i
    :ep_d_yfphyi0i
    nop
    :ep_s_yfphyi0i
    const-string v0, "Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing."

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_kuk7t8kv
    goto :ep_s_kuk7t8kv
    :ep_d_kuk7t8kv
    nop
    :ep_s_kuk7t8kv
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public setFlexWrap(I)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_mxsis0sn
    goto :ep_s_mxsis0sn
    :ep_d_mxsis0sn
    nop
    :ep_s_mxsis0sn
    const-string v0, "Changing flex wrap not allowed. ChipGroup exposes a singleLine attribute instead."

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_bvbhl19i
    goto :ep_s_bvbhl19i
    :ep_d_bvbhl19i
    nop
    :ep_s_bvbhl19i
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public setOnCheckedChangeListener(LChipGroup$c;)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    if-nez p1, :cond_0

    .line 3
    const/4 p1, 0x0

    .line 4
    invoke-virtual {p0, p1}, LChipGroup;->setOnCheckedStateChangeListener(LChipGroup$d;)V

    .line 7
    return-void

    .line 8
    :cond_0
    new-instance p1, LChipGroup$a;

    .line 10
    invoke-direct {p1}, LChipGroup$a;-><init>()V

    .line 13
    invoke-virtual {p0, p1}, LChipGroup;->setOnCheckedStateChangeListener(LChipGroup$d;)V

    .line 16
    return-void
.end method

.method public setOnCheckedStateChangeListener(LChipGroup$d;)V
    .locals 0

    return-void
.end method

.method public setOnHierarchyChangeListener(Landroid/view/ViewGroup$OnHierarchyChangeListener;)V
    .locals 0

    const/4 p1, 0x0

    throw p1
.end method

.method public setSelectionRequired(Z)V
    .locals 0

    const/4 p1, 0x0

    throw p1
.end method

.method public setShowDividerHorizontal(I)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_ohwobpni
    goto :ep_s_ohwobpni
    :ep_d_ohwobpni
    nop
    :ep_s_ohwobpni
    const-string v0, "Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing."

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_r56qmezz
    goto :ep_s_r56qmezz
    :ep_d_r56qmezz
    nop
    :ep_s_r56qmezz
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public setShowDividerVertical(I)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_trcpr5bm
    goto :ep_s_trcpr5bm
    :ep_d_trcpr5bm
    nop
    :ep_s_trcpr5bm
    const-string v0, "Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing."

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_2kdg0p4j
    goto :ep_s_2kdg0p4j
    :ep_d_2kdg0p4j
    nop
    :ep_s_2kdg0p4j
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public setSingleLine(I)V
    .locals 1

    .line 2
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_abra1u74
    goto :ep_s_abra1u74
    :ep_d_abra1u74
    nop
    :ep_s_abra1u74
    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_t4end6ob
    goto :ep_s_t4end6ob
    :ep_d_t4end6ob
    nop
    :ep_s_t4end6ob
    invoke-virtual {p0, p1}, LChipGroup;->setSingleLine(Z)V

    return-void
.end method

.method public setSingleLine(Z)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lad;->setSingleLine(Z)V

    return-void
.end method

.method public setSingleSelection(I)V
    .locals 1

    .line 2
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_d2qttb41
    goto :ep_s_d2qttb41
    :ep_d_d2qttb41
    nop
    :ep_s_d2qttb41
    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_nmqzjkyw
    goto :ep_s_nmqzjkyw
    :ep_d_nmqzjkyw
    nop
    :ep_s_nmqzjkyw
    move-result p1

    invoke-virtual {p0, p1}, LChipGroup;->setSingleSelection(Z)V

    return-void
.end method

.method public setSingleSelection(Z)V
    .locals 0

    const/4 p1, 0x0

    .line 1
    throw p1
.end method
