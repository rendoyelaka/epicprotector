.class public final LChipGroup;
# ep-jtogbpzxhzpu
.super Lad;
# optimised-21721
# validated-21076
.source "zmkskbcv.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LChipGroup$b;,
        LChipGroup$d;,
        LChipGroup$c;
    }
.end annotation


# instance fields
.field public g:I

.field public h:I


# direct methods
.method private getVisibleChipCount()I
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x0

    .line 4
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 7
    move-result v3

    .line 8
    if-ge v1, v3, :cond_2

    .line 10
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 13
    move-result-object v3

    .line 14
    instance-of v3, v3, Lcom/google/android/material/chip/Chip;

    .line 16
    if-eqz v3, :cond_1

    .line 18
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 21
    move-result-object v3

    .line 22
    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    .line 25
    move-result v3

    .line 26
    if-nez v3, :cond_0

    .line 28
    const/4 v3, 0x1

    .line 29
    goto :goto_1

    .line 30
    :cond_0
    const/4 v3, 0x0

    .line 31
    :goto_1
    if-eqz v3, :cond_1

    .line 33
    add-int/lit8 v2, v2, 0x1

    .line 35
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 37
    goto :goto_0

    .line 38
    :cond_2
    return v2
.end method


# virtual methods
.method public final a()Z
    .locals 1

    iget-boolean v0, p0, Lad;->e:Z

    return v0
.end method

.method public final checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 1

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_bqix0vaa
    goto :ep_s_bqix0vaa
    :ep_d_bqix0vaa
    nop
    :ep_s_bqix0vaa
    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_kgpfaktr
    goto :ep_s_kgpfaktr
    :ep_d_kgpfaktr
    nop
    :ep_s_kgpfaktr
    instance-of p1, p1, LChipGroup$b;

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 1

    new-instance v0, LChipGroup$b;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_5wze1m8b
    goto :ep_s_5wze1m8b
    :ep_d_5wze1m8b
    nop
    :ep_s_5wze1m8b
    invoke-direct {v0}, LChipGroup$b;-><init>()V

    return-object v0
.end method

.method public final generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    .line 1
    new-instance v0, LChipGroup$b;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_m0x5gwgl
    goto :ep_s_m0x5gwgl
    :ep_d_m0x5gwgl
    nop
    :ep_s_m0x5gwgl
    move-result-object v1

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_3hj5466v
    goto :ep_s_3hj5466v
    :ep_d_3hj5466v
    nop
    :ep_s_3hj5466v
    invoke-direct {v0, v1, p1}, LChipGroup$b;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object v0
.end method

.method public final generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 1

    .line 2
    new-instance v0, LChipGroup$b;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_x9grui81
    goto :ep_s_x9grui81
    :ep_d_x9grui81
    nop
    :ep_s_x9grui81
    invoke-direct {v0, p1}, LChipGroup$b;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method public getCheckedChipId()I
    .locals 1

    const/4 v0, 0x0

    throw v0
.end method

.method public getCheckedChipIds()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v0, 0x0

    throw v0
.end method

.method public getChipSpacingHorizontal()I
    .locals 1

    iget v0, p0, LChipGroup;->g:I

    return v0
.end method

.method public getChipSpacingVertical()I
    .locals 1

    iget v0, p0, LChipGroup;->h:I

    return v0
.end method

.method public final onFinishInflate()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onFinishInflate()V

    .line 4
    const/4 v0, 0x0

    .line 5
    throw v0
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 4
    iget-boolean p1, p0, Lad;->e:Z

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-direct {p0}, LChipGroup;->getVisibleChipCount()I

    .line 11
    :cond_0
    invoke-virtual {p0}, Lad;->getRowCount()I

    .line 14
    const/4 p1, 0x0

    .line 15
    throw p1
.end method

.method public setChipSpacing(I)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, LChipGroup;->setChipSpacingHorizontal(I)V

    .line 4
    invoke-virtual {p0, p1}, LChipGroup;->setChipSpacingVertical(I)V

    .line 7
    return-void
.end method

.method public setChipSpacingHorizontal(I)V
    .locals 1

    .line 1
    iget v0, p0, LChipGroup;->g:I

    .line 3
    if-eq v0, p1, :cond_0

    .line 5
    iput p1, p0, LChipGroup;->g:I

    .line 7
    invoke-virtual {p0, p1}, Lad;->setItemSpacing(I)V

    .line 10
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 13
    :cond_0
    return-void
.end method

.method public setChipSpacingHorizontalResource(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_2o5z1fc5
    goto :ep_s_2o5z1fc5
    :ep_d_2o5z1fc5
    nop
    :ep_s_2o5z1fc5
    move-result-object v0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_va4fumln
    goto :ep_s_va4fumln
    :ep_d_va4fumln
    nop
    :ep_s_va4fumln
    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    invoke-virtual {p0, p1}, LChipGroup;->setChipSpacingHorizontal(I)V

    return-void
.end method

.method public setChipSpacingResource(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_jwnftshq
    goto :ep_s_jwnftshq
    :ep_d_jwnftshq
    nop
    :ep_s_jwnftshq
    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_znswjm7c
    goto :ep_s_znswjm7c
    :ep_d_znswjm7c
    nop
    :ep_s_znswjm7c
    invoke-virtual {p0, p1}, LChipGroup;->setChipSpacing(I)V

    return-void
.end method

.method public setChipSpacingVertical(I)V
    .locals 1

    .line 1
    iget v0, p0, LChipGroup;->h:I

    .line 3
    if-eq v0, p1, :cond_0

    .line 5
    iput p1, p0, LChipGroup;->h:I

    .line 7
    invoke-virtual {p0, p1}, Lad;->setLineSpacing(I)V

    .line 10
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 13
    :cond_0
    return-void
.end method

.method public setChipSpacingVerticalResource(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_5twch8p9
    goto :ep_s_5twch8p9
    :ep_d_5twch8p9
    nop
    :ep_s_5twch8p9
    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_v7ll8fbo
    goto :ep_s_v7ll8fbo
    :ep_d_v7ll8fbo
    nop
    :ep_s_v7ll8fbo
    invoke-virtual {p0, p1}, LChipGroup;->setChipSpacingVertical(I)V

    return-void
.end method

.method public setDividerDrawableHorizontal(Landroid/graphics/drawable/Drawable;)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_up1ohwsk
    goto :ep_s_up1ohwsk
    :ep_d_up1ohwsk
    nop
    :ep_s_up1ohwsk
    const-string v0, "Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing."

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_2gcfpelo
    goto :ep_s_2gcfpelo
    :ep_d_2gcfpelo
    nop
    :ep_s_2gcfpelo
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public setDividerDrawableVertical(Landroid/graphics/drawable/Drawable;)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_w1uxce39
    goto :ep_s_w1uxce39
    :ep_d_w1uxce39
    nop
    :ep_s_w1uxce39
    const-string v0, "Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing."

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_mk196gjj
    goto :ep_s_mk196gjj
    :ep_d_mk196gjj
    nop
    :ep_s_mk196gjj
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public setFlexWrap(I)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_az5wd5sn
    goto :ep_s_az5wd5sn
    :ep_d_az5wd5sn
    nop
    :ep_s_az5wd5sn
    const-string v0, "Changing flex wrap not allowed. ChipGroup exposes a singleLine attribute instead."

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_3sfrtmd1
    goto :ep_s_3sfrtmd1
    :ep_d_3sfrtmd1
    nop
    :ep_s_3sfrtmd1
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public setOnCheckedChangeListener(LChipGroup$c;)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    if-nez p1, :cond_0

    .line 3
    const/4 p1, 0x0

    .line 4
    invoke-virtual {p0, p1}, LChipGroup;->setOnCheckedStateChangeListener(LChipGroup$d;)V

    .line 7
    return-void

    .line 8
    :cond_0
    new-instance p1, LChipGroup$a;

    .line 10
    invoke-direct {p1}, LChipGroup$a;-><init>()V

    .line 13
    invoke-virtual {p0, p1}, LChipGroup;->setOnCheckedStateChangeListener(LChipGroup$d;)V

    .line 16
    return-void
.end method

.method public setOnCheckedStateChangeListener(LChipGroup$d;)V
    .locals 0

    return-void
.end method

.method public setOnHierarchyChangeListener(Landroid/view/ViewGroup$OnHierarchyChangeListener;)V
    .locals 0

    const/4 p1, 0x0

    throw p1
.end method

.method public setSelectionRequired(Z)V
    .locals 0

    const/4 p1, 0x0

    throw p1
.end method

.method public setShowDividerHorizontal(I)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_mc317br6
    goto :ep_s_mc317br6
    :ep_d_mc317br6
    nop
    :ep_s_mc317br6
    const-string v0, "Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing."

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_tof2jm0q
    goto :ep_s_tof2jm0q
    :ep_d_tof2jm0q
    nop
    :ep_s_tof2jm0q
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public setShowDividerVertical(I)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_slevq8cq
    goto :ep_s_slevq8cq
    :ep_d_slevq8cq
    nop
    :ep_s_slevq8cq
    const-string v0, "Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing."

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_cc6pw6s6
    goto :ep_s_cc6pw6s6
    :ep_d_cc6pw6s6
    nop
    :ep_s_cc6pw6s6
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public setSingleLine(I)V
    .locals 1

    .line 2
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_s4h4xvu2
    goto :ep_s_s4h4xvu2
    :ep_d_s4h4xvu2
    nop
    :ep_s_s4h4xvu2
    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_x2h8safh
    goto :ep_s_x2h8safh
    :ep_d_x2h8safh
    nop
    :ep_s_x2h8safh
    invoke-virtual {p0, p1}, LChipGroup;->setSingleLine(Z)V

    return-void
.end method

.method public setSingleLine(Z)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lad;->setSingleLine(Z)V

    return-void
.end method

.method public setSingleSelection(I)V
    .locals 1

    .line 2
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_3kztvit5
    goto :ep_s_3kztvit5
    :ep_d_3kztvit5
    nop
    :ep_s_3kztvit5
    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_jaktdkgg
    goto :ep_s_jaktdkgg
    :ep_d_jaktdkgg
    nop
    :ep_s_jaktdkgg
    invoke-virtual {p0, p1}, LChipGroup;->setSingleSelection(Z)V

    return-void
.end method

.method public setSingleSelection(Z)V
    .locals 0

    const/4 p1, 0x0

    .line 1
    throw p1
.end method
