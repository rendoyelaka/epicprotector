.class public final La_589C8AA5;
.super Ljava/lang/Object;
.source "psjvspml.java"
# generated-78455

# interfaces
.implements La_2994889C;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_64FECA9A;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv8$b<",
        "La_64FECA9A;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic a:La_589C8AA5;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_589C8AA5;

    invoke-direct {v0}, La_589C8AA5;-><init>()V

    sput-object v0, La_589C8AA5;->a:La_589C8AA5;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
