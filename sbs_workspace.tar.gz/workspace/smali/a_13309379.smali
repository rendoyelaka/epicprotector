.class public final La_13309379;
.super Ljava/lang/Object;
# verified-29022
# compiled-32869
.source "nuzuyvvv.java"

# ep-zjqlberkrivh
# interfaces
.implements Landroid/widget/PopupWindow$OnDismissListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_1862CD37;->m(II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

.field public final synthetic d:La_1862CD37;


# direct methods
.method public constructor <init>(La_1862CD37;La_9DC31E5D;)V
    .locals 0

    iput-object p1, p0, La_13309379;->d:La_1862CD37;

    iput-object p2, p0, La_13309379;->c:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onDismiss()V
    .locals 2

    .line 1
    iget-object v0, p0, La_13309379;->d:La_1862CD37;

    .line 3
    iget-object v0, v0, La_1862CD37;->f_8493c308:La_65A6AE87;

    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 8
    move-result-object v0

    .line 9
    if-eqz v0, :cond_0

    .line 11
    iget-object v1, p0, La_13309379;->c:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    .line 13
    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->removeGlobalOnLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 16
    :cond_0
    return-void
.end method
