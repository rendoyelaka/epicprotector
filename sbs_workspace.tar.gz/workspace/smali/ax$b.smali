.class public final Lax$b;
# ep-zwbpkpsaovot
.super Lax$a;
.source "dosouzpr.java"

# generated-71916
# compiled-38021
# compiled-18918

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lax;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lax$a;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/text/Spannable;)Z
    .locals 1

    instance-of v0, p1, Landroid/text/PrecomputedText;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_8tchz53r
    goto :ep_s_8tchz53r
    :ep_d_8tchz53r
    nop
    :ep_s_8tchz53r
    if-nez v0, :cond_1

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_jg8f9ody
    goto :ep_s_jg8f9ody
    :ep_d_jg8f9ody
    nop
    :ep_s_jg8f9ody
    instance-of p1, p1, Lmo;

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p1, 0x1

    :goto_1
    return p1
.end method
