.class public final La_5403E8F1;
.super Ljava/lang/Object;
# optimised-41617
# processed-14442
.source "hwlhvxqj.java"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_1C3E11C0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator<",
        "La_1C3E11C0;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    # ep-xlmpladsfpto
    .locals 1

    new-instance v0, La_1C3E11C0;
    # ep-zlborsyqvyzo

    # ep-nnratkhjgnkc
    invoke-direct {v0, p1}, La_1C3E11C0;-><init>(Landroid/os/Parcel;)V

    return-object v0
.end method

    # ep-iglrikibnlqg
.method public final newArray(I)[Ljava/lang/Object;
    .locals 0

    # ep-zzmzkqowzskf
    new-array p1, p1, [La_1C3E11C0;
    # ep-piwkphkhmvue

    # ep-btdzrsyvecga
    return-object p1
.end method
