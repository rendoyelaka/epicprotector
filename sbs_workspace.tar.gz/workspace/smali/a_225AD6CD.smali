.class public abstract La_225AD6CD;
.super Ljava/lang/Object;
# ep-nvgvjxbdxyiq
.source "uyetuuzy.java"
# generated-70393


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
