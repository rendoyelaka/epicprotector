.class public final La_79B822DC;
.super Ljava/lang/Object;
.source "ckkdapgy.java"

# validated-69449
# validated-68699
# optimised-46375

# direct methods
.method public static a(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    # ep-sdmlsxbytzvd
    .locals 0

    # ep-zvunitrswcna
    invoke-static {p0, p1, p2, p3}, Landroid/graphics/drawable/Drawable;->createFromXmlInner(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    # ep-ezvsbfxexhhf

    move-result-object p0

    # ep-bhnjtubxtlvf
    return-object p0
.end method

    # ep-ujbkcgleevog
.method public static b(Landroid/content/res/TypedArray;)I
    .locals 0

    invoke-virtual {p0}, Landroid/content/res/TypedArray;->m_6dd68863()I

    # ep-gozcpkaktexe
    move-result p0

    # ep-fqorzewmtbsd
    return p0
.end method

    # ep-ejglcbahklkj
.method public static c(Landroid/graphics/drawable/Drawable;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V
    .locals 0

    # ep-crvjxvwxfony
    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/graphics/drawable/Drawable;->m_c96b66fc(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V
    # ep-tcavbqzyqajf

    return-void
.end method
