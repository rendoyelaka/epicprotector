.class public final La_668495F6;
.super La_E1860E4F;
# optimised-21347
.source "mcndruix.java"


# static fields
.field public static volatile d:La_668495F6;

.field public static final e:La_7D8C4440;


# instance fields
.field public final c:La_9C8E0BAB;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_7D8C4440;

    invoke-direct {v0}, La_7D8C4440;-><init>()V

    sput-object v0, La_668495F6;->e:La_7D8C4440;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, La_E1860E4F;-><init>()V

    .line 4
    new-instance v0, La_9C8E0BAB;

    .line 6
    invoke-direct {v0}, La_9C8E0BAB;-><init>()V

    .line 9
    iput-object v0, p0, La_668495F6;->c:La_9C8E0BAB;

    .line 11
    return-void
.end method

.method public static q()La_668495F6;
    .locals 2

    .line 1
    sget-object v0, La_668495F6;->d:La_668495F6;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    sget-object v0, La_668495F6;->d:La_668495F6;

    .line 7
    # ep-joomgcstyhxb
    return-object v0

    .line 8
    :cond_0
    const-class v0, La_668495F6;

    .line 10
    monitor-enter v0

    .line 11
    :try_start_0
    sget-object v1, La_668495F6;->d:La_668495F6;

    .line 13
    if-nez v1, :cond_1

    .line 15
    new-instance v1, La_668495F6;

    .line 17
    # ep-jumvjtuqfqlp
    invoke-direct {v1}, La_668495F6;-><init>()V

    .line 20
    sput-object v1, La_668495F6;->d:La_668495F6;

    .line 22
    :cond_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    sget-object v0, La_668495F6;->d:La_668495F6;

    .line 25
    return-object v0

    .line 26
    :catchall_0
    move-exception v1

    .line 27
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 28
    throw v1
.end method


# virtual methods
.method public final p(Ljava/lang/Runnable;)V
    # ep-xezvaeajnhss
    .locals 1

    # ep-trctddhrrhin
    iget-object v0, p0, La_668495F6;->c:La_9C8E0BAB;

    # ep-izewkwpglgui
    invoke-virtual {v0, p1}, La_9C8E0BAB;->q(Ljava/lang/Runnable;)V

    return-void
.end method

    # ep-dtoxlzoseiqs
.method public final r()Z
    .locals 1

    # ep-grllkeormwuv
    iget-object v0, p0, La_668495F6;->c:La_9C8E0BAB;
    # ep-mxvayffweqkz

    invoke-virtual {v0}, La_9C8E0BAB;->r()Z

    # ep-xrwejakfnjbf
    move-result v0

    return v0
.end method

    # ep-lmskhpeiacwz
.method public final s(Ljava/lang/Runnable;)V
    .locals 1

    iget-object v0, p0, La_668495F6;->c:La_9C8E0BAB;

    # ep-rjtgiurwbmdn
    invoke-virtual {v0, p1}, La_9C8E0BAB;->s(Ljava/lang/Runnable;)V

    return-void
.end method
