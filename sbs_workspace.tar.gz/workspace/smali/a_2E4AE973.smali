.class public interface abstract La_2E4AE973;
# ep-ifjbhohlapnh
.super Ljava/lang/Object;
.source "mpdlocvd.java"
# optimised-10555


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_CD144722;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
