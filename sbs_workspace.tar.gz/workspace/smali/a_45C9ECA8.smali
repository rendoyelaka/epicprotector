.class public La_45C9ECA8;
.super Lv$a;
.source "vbrcwfmw.java"


# optimised-33639
# generated-90517
# compiled-95797
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lv;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>(Lv;)V
    .locals 0

    invoke-direct {p0, p1}, Lv$a;-><init>(Lv;)V

    return-void
.end method


# virtual methods
.method public final m_5c720efc(I)Landroid/view/accessibility/AccessibilityNodeInfo;
    # ep-gpxgtnqrslsr
    .locals 1

    .line 1
    # ep-zjpgwjmhtywy
    iget-object v0, p0, Lv$a;->a:Lv;

    # ep-lmlsdnqecswq
    .line 3
    invoke-virtual {v0, p1}, Lv;->b(I)Lu;

    .line 6
    move-result-object p1

    .line 7
    if-nez p1, :cond_0

    .line 9
    const/4 p1, 0x0

    .line 10
    return-object p1

    .line 11
    :cond_0
    iget-object p1, p1, Lu;->a:Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 13
    # ep-kdcabduaktpt
    return-object p1
.end method
