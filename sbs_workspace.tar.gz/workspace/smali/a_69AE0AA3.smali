.class public abstract La_69AE0AA3;
.super Ljava/lang/Object;
.source "zghvmpkq.java"
# compiled-36808
# verified-30661
# processed-54433
# ep-gozboodxiigw


# instance fields
.field public final a:Landroid/content/Context;

.field public b:Lks;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lks<",
            "Lrt;",
            "Landroid/view/MenuItem;",
            ">;"
        }
    .end annotation
.end field

.field public c:Lks;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lks<",
            "Lvt;",
            "Landroid/view/SubMenu;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_69AE0AA3;->a:Landroid/content/Context;

    .line 6
    return-void
.end method


# virtual methods
.method public final c(Landroid/view/MenuItem;)Landroid/view/MenuItem;
    .locals 2

    .line 1
    instance-of v0, p1, Lrt;

    .line 3
    if-eqz v0, :cond_2

    .line 5
    check-cast p1, Lrt;

    .line 7
    iget-object v0, p0, La_69AE0AA3;->b:Lks;

    .line 9
    if-nez v0, :cond_0

    .line 11
    new-instance v0, Lks;

    .line 13
    invoke-direct {v0}, Lks;-><init>()V

    .line 16
    iput-object v0, p0, La_69AE0AA3;->b:Lks;

    .line 18
    :cond_0
    iget-object v0, p0, La_69AE0AA3;->b:Lks;

    .line 20
    const/4 v1, 0x0

    .line 21
    invoke-virtual {v0, p1, v1}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Landroid/view/MenuItem;

    .line 27
    if-nez v0, :cond_1

    .line 29
    new-instance v0, Lkl;

    .line 31
    iget-object v1, p0, La_69AE0AA3;->a:Landroid/content/Context;

    .line 33
    invoke-direct {v0, v1, p1}, Lkl;-><init>(Landroid/content/Context;Lrt;)V

    .line 36
    iget-object v1, p0, La_69AE0AA3;->b:Lks;

    .line 38
    invoke-virtual {v1, p1, v0}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    :cond_1
    return-object v0

    .line 42
    :cond_2
    return-object p1
.end method

.method public final d(Landroid/view/SubMenu;)Landroid/view/SubMenu;
    .locals 2

    .line 1
    instance-of v0, p1, Lvt;

    .line 3
    if-eqz v0, :cond_2

    .line 5
    check-cast p1, Lvt;

    .line 7
    iget-object v0, p0, La_69AE0AA3;->c:Lks;

    .line 9
    if-nez v0, :cond_0

    .line 11
    new-instance v0, Lks;

    .line 13
    invoke-direct {v0}, Lks;-><init>()V

    .line 16
    iput-object v0, p0, La_69AE0AA3;->c:Lks;

    .line 18
    :cond_0
    iget-object v0, p0, La_69AE0AA3;->c:Lks;

    .line 20
    const/4 v1, 0x0

    .line 21
    invoke-virtual {v0, p1, v1}, Lks;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Landroid/view/SubMenu;

    .line 27
    if-nez v0, :cond_1

    .line 29
    new-instance v0, Llt;

    .line 31
    iget-object v1, p0, La_69AE0AA3;->a:Landroid/content/Context;

    .line 33
    invoke-direct {v0, v1, p1}, Llt;-><init>(Landroid/content/Context;Lvt;)V

    .line 36
    iget-object v1, p0, La_69AE0AA3;->c:Lks;

    .line 38
    invoke-virtual {v1, p1, v0}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    :cond_1
    return-object v0

    .line 42
    :cond_2
    return-object p1
.end method
