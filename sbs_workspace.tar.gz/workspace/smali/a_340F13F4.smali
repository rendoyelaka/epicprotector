.class public abstract La_340F13F4;
.super Ld;
# optimised-72726
# compiled-96659
# ep-hxtcxgsshikp
.source "oqyjwkoj.java"

# interfaces
.implements La_59F8C096;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_8A28183B;
    }
.end annotation


# static fields
.field public static final c:La_8A28183B;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La_8A28183B;

    invoke-direct {v0}, La_8A28183B;-><init>()V

    sput-object v0, La_340F13F4;->c:La_8A28183B;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    sget-object v0, La_5A57E973;->a:La_5A57E973;

    invoke-direct {p0, v0}, Ld;-><init>(La_33BEBC85;)V

    return-void
.end method


# virtual methods
.method public final get(La_33BEBC85;)La_5B913AA1;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E::",
            "La_5B913AA1;",
            ">(",
            "Lv8$b<",
            "TE;>;)TE;"
        }
    .end annotation

    .line 1
    const-string v0, "key"

    .line 3
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    instance-of v1, p1, Le;

    .line 8
    if-eqz v1, :cond_2

    .line 10
    check-cast p1, Le;

    .line 12
    invoke-virtual {p0}, Ld;->m_5f0274a8()La_33BEBC85;

    .line 15
    move-result-object v1

    .line 16
    invoke-static {v0, v1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 19
    if-eq v1, p1, :cond_1

    .line 21
    iget-object v0, p1, Le;->b:La_33BEBC85;

    .line 23
    if-ne v0, v1, :cond_0

    .line 25
    goto :goto_0

    .line 26
    :cond_0
    const/4 v0, 0x0

    .line 27
    goto :goto_1

    .line 28
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 29
    :goto_1
    if-eqz v0, :cond_3

    .line 31
    invoke-virtual {p1, p0}, Le;->a(La_5B913AA1;)La_5B913AA1;

    .line 34
    move-result-object p1

    .line 35
    instance-of v0, p1, La_5B913AA1;

    .line 37
    if-eqz v0, :cond_3

    .line 39
    goto :goto_2

    .line 40
    :cond_2
    sget-object v0, La_5A57E973;->a:La_5A57E973;

    .line 42
    if-ne v0, p1, :cond_3

    .line 44
    move-object p1, p0

    .line 45
    goto :goto_2

    .line 46
    :cond_3
    const/4 p1, 0x0

    .line 47
    :goto_2
    return-object p1
.end method

.method public abstract j(La_064EF12B;Ljava/lang/Runnable;)V
.end method

.method public final m_5a8467b9(La_33BEBC85;)La_064EF12B;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lv8$b<",
            "*>;)",
            "La_064EF12B;"
        }
    .end annotation

    .line 1
    const-string v0, "key"

    .line 3
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    instance-of v1, p1, Le;

    .line 8
    sget-object v2, Lxb;->c:Lxb;

    .line 10
    if-eqz v1, :cond_2

    .line 12
    check-cast p1, Le;

    .line 14
    invoke-virtual {p0}, Ld;->m_5f0274a8()La_33BEBC85;

    .line 17
    move-result-object v1

    .line 18
    invoke-static {v0, v1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 21
    if-eq v1, p1, :cond_1

    .line 23
    iget-object v0, p1, Le;->b:La_33BEBC85;

    .line 25
    if-ne v0, v1, :cond_0

    .line 27
    goto :goto_0

    .line 28
    :cond_0
    const/4 v0, 0x0

    .line 29
    goto :goto_1

    .line 30
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 31
    :goto_1
    if-eqz v0, :cond_3

    .line 33
    invoke-virtual {p1, p0}, Le;->a(La_5B913AA1;)La_5B913AA1;

    .line 36
    move-result-object p1

    .line 37
    if-eqz p1, :cond_3

    .line 39
    goto :goto_2

    .line 40
    :cond_2
    sget-object v0, La_5A57E973;->a:La_5A57E973;

    .line 42
    if-ne v0, p1, :cond_3

    .line 44
    goto :goto_2

    .line 45
    :cond_3
    move-object v2, p0

    .line 46
    :goto_2
    return-object v2
.end method

.method public r()Z
    .locals 1

    instance-of v0, p0, La_C55DB046;

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 6
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 13
    move-result-object v1

    .line 14
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 17
    const/16 v1, 0x40

    .line 19
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 22
    invoke-static {p0}, La_2C13166E;->m_61732c05(Ljava/lang/Object;)Ljava/lang/String;

    .line 25
    move-result-object v1

    .line 26
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 32
    move-result-object v0

    .line 33
    return-object v0
.end method
