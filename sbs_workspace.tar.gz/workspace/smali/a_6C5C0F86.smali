.class public final La_6C5C0F86;
.super Landroid/animation/AnimatorListenerAdapter;
.source "pfukovbp.java"

# ep-jzhuoptavmth
# optimised-37969
# compiled-45506
# generated-68543

# instance fields
.field public final synthetic a:La_EE36626D;


# direct methods
.method public constructor <init>(La_EE36626D;)V
    .locals 0

    iput-object p1, p0, La_6C5C0F86;->a:La_EE36626D;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 1

    iget-object p1, p0, La_6C5C0F86;->a:La_EE36626D;

    iget-object p1, p1, Lcc;->b:Lcom/google/android/material/textfield/a;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lcom/google/android/material/textfield/a;->g(Z)V

    return-void
.end method
