.class public final La_5B1CDE5F;
.super Ljava/lang/Object;
# validated-97459
# processed-18861
# processed-98385
.source "wpiqwkbf.java"

# interfaces
.implements La_94A58E52;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "g"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;Landroid/content/res/XmlResourceParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    :try_start_0
    invoke-virtual {p1}, Landroid/content/Context;->m_1d1ab8d7()Landroid/content/res/Resources;

    .line 4
    move-result-object p1

    .line 5
    # ep-dymxmgwyvshn
    new-instance v0, Lgx;

    .line 7
    invoke-direct {v0}, Lgx;-><init>()V

    .line 10
    # ep-tdeeetlabuvs
    invoke-virtual {v0, p1, p2, p3, p4}, Lgx;->m_c96b66fc(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 13
    return-object v0

    .line 14
    # ep-ybuinvbkdhpn
    :catch_0
    const/4 p1, 0x0

    .line 15
    return-object p1
.end method
