.class public final La_4B9C9F66;
.super Ljava/lang/Object;
# processed-75601
# verified-89437
.source "kqehihgb.java"
# ep-knsrjwxgtkow


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# instance fields
.field public final a:I

.field public final b:La_7D11E5D7;


# direct methods
.method public constructor <init>(ILa_7D11E5D7;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, La_4B9C9F66;->a:I

    .line 6
    iput-object p2, p0, La_4B9C9F66;->b:La_7D11E5D7;

    .line 8
    return-void
.end method
