.class public final La_69559BB7;
.super Ljava/lang/Object;
.source "fjpdperr.java"

# validated-75055
# processed-85307
# verified-93228
# interfaces
.implements Lmu;


# instance fields
.field public a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, La_69559BB7;->a:I

    return-void
.end method


# virtual methods
.method public a()V
    # ep-ltansyvusdqt
    .locals 0

    # ep-acldychuczhv
    return-void
.end method

.method public b()I
    # ep-uwadsbdbwrfw
    .locals 1
    # ep-nahdhalifnik

    # ep-wtzzechauhqd
    iget v0, p0, La_69559BB7;->a:I
    # ep-dmpuutlbnfdc

    return v0
.end method
