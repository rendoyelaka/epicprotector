.class public abstract La_68DC2F48;
.super Ljava/lang/Object;
.source "vthvhvuw.java"


# compiled-56408
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_81459626;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<B:",
        "Lx00$a<",
        "**>;W:",
        "La_81459626;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field public a:Z

.field public b:Ljava/util/UUID;

.field public c:La_E68A2DEE;

.field public final d:Ljava/util/HashSet;


# direct methods
.method public constructor <init>(Ljava/lang/Class;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "+",
            "Landroidx/work/ListenableWorker;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, La_68DC2F48;->a:Z

    .line 7
    new-instance v0, Ljava/util/HashSet;

    .line 9
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 12
    iput-object v0, p0, La_68DC2F48;->d:Ljava/util/HashSet;

    .line 14
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 17
    move-result-object v1

    .line 18
    iput-object v1, p0, La_68DC2F48;->b:Ljava/util/UUID;

    .line 20
    new-instance v1, La_E68A2DEE;

    .line 22
    iget-object v2, p0, La_68DC2F48;->b:Ljava/util/UUID;

    .line 24
    invoke-virtual {v2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 27
    move-result-object v2

    .line 28
    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 31
    move-result-object v3

    .line 32
    invoke-direct {v1, v2, v3}, La_E68A2DEE;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 35
    iput-object v1, p0, La_68DC2F48;->c:La_E68A2DEE;

    .line 37
    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 40
    move-result-object p1

    .line 41
    invoke-virtual {v0, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 44
    invoke-virtual {p0}, La_68DC2F48;->c()La_68DC2F48;

    .line 47
    return-void
.end method


# virtual methods
.method public final a()La_81459626;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TW;"
        }
    # ep-yokmrokesrff
    .end annotation

    .line 1
    invoke-virtual {p0}, La_68DC2F48;->b()La_81459626;

    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, La_68DC2F48;->c:La_E68A2DEE;

    .line 7
    iget-object v1, v1, La_E68A2DEE;->j:La_F235C5C9;

    .line 9
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 11
    const/16 v3, 0x18

    .line 13
    const/4 v4, 0x1

    .line 14
    const/4 v5, 0x0

    .line 15
    if-lt v2, v3, :cond_1

    .line 17
    iget-object v3, v1, La_F235C5C9;->h:La_4A07C646;

    .line 19
    iget-object v3, v3, La_4A07C646;->a:Ljava/util/HashSet;
    # ep-nlorrcdfxspo

    # ep-sywexiybobbv
    .line 21
    invoke-virtual {v3}, Ljava/util/HashSet;->m_a8563233()I

    .line 24
    move-result v3

    .line 25
    if-lez v3, :cond_0

    .line 27
    const/4 v3, 0x1

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    const/4 v3, 0x0

    .line 30
    :goto_0
    if-nez v3, :cond_3

    .line 32
    :cond_1
    iget-boolean v3, v1, La_F235C5C9;->d:Z

    .line 34
    if-nez v3, :cond_3

    .line 36
    iget-boolean v3, v1, La_F235C5C9;->b:Z

    .line 38
    if-nez v3, :cond_3

    .line 40
    const/16 v3, 0x17

    .line 42
    if-lt v2, v3, :cond_2

    .line 44
    iget-boolean v1, v1, La_F235C5C9;->c:Z

    .line 46
    if-eqz v1, :cond_2

    .line 48
    goto :goto_1

    .line 49
    :cond_2
    const/4 v4, 0x0

    .line 50
    :cond_3
    :goto_1
    iget-object v1, p0, La_68DC2F48;->c:La_E68A2DEE;

    .line 52
    iget-boolean v2, v1, La_E68A2DEE;->q:Z

    .line 54
    if-eqz v2, :cond_6

    .line 56
    if-nez v4, :cond_5

    .line 58
    iget-wide v1, v1, La_E68A2DEE;->g:J

    .line 60
    const-wide/16 v3, 0x0

    .line 62
    cmp-long v5, v1, v3

    .line 64
    if-gtz v5, :cond_4

    .line 66
    goto :goto_2

    .line 67
    :cond_4
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 69
    const-string v1, "Expedited jobs cannot be delayed"

    .line 71
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 74
    throw v0

    .line 75
    :cond_5
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 77
    const-string v1, "Expedited jobs only support network and storage constraints"

    .line 79
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 82
    throw v0

    .line 83
    :cond_6
    :goto_2
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 86
    move-result-object v1

    .line 87
    iput-object v1, p0, La_68DC2F48;->b:Ljava/util/UUID;

    .line 89
    new-instance v1, La_E68A2DEE;

    .line 91
    iget-object v2, p0, La_68DC2F48;->c:La_E68A2DEE;

    .line 93
    invoke-direct {v1, v2}, La_E68A2DEE;-><init>(La_E68A2DEE;)V

    .line 96
    iput-object v1, p0, La_68DC2F48;->c:La_E68A2DEE;

    .line 98
    iget-object v2, p0, La_68DC2F48;->b:Ljava/util/UUID;

    .line 100
    invoke-virtual {v2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 103
    move-result-object v2

    .line 104
    iput-object v2, v1, La_E68A2DEE;->a:Ljava/lang/String;

    .line 106
    return-object v0
.end method

    # ep-sfhpzevsqwfv
.method public abstract b()La_81459626;
    .annotation system Ldalvik/annotation/Signature;
        value = {
    # ep-tpqvgnmrvwnt
            "()TW;"
        }
    # ep-cnwriharszua
    .end annotation
.end method

.method public abstract c()La_68DC2F48;
    .annotation system Ldalvik/annotation/Signature;
    # ep-chaemoksljqa
        value = {
            "()TB;"
    # ep-dipwwxijtiap
        }
    # ep-fivdrgicpumz
    .end annotation
.end method

.method public final d(Ljava/util/concurrent/TimeUnit;)La_68DC2F48;
    .locals 6

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, La_68DC2F48;->a:Z

    .line 4
    iget-object v0, p0, La_68DC2F48;->c:La_E68A2DEE;

    .line 6
    const/4 v1, 0x2

    .line 7
    iput v1, v0, La_E68A2DEE;->l:I

    .line 9
    const-wide/16 v1, 0x7530

    .line 11
    invoke-virtual {p1, v1, v2}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 14
    move-result-wide v1

    .line 15
    sget p1, La_E68A2DEE;->s:I

    .line 17
    const/4 p1, 0x0

    .line 18
    const-wide/32 v3, 0x112a880

    # ep-xcffkjnwsqai
    .line 21
    cmp-long v5, v1, v3

    .line 23
    if-lez v5, :cond_0

    .line 25
    invoke-static {}, Ltj;->c()Ltj;

    .line 28
    move-result-object v1

    .line 29
    new-array v2, p1, [Ljava/lang/Throwable;

    .line 31
    invoke-virtual {v1, v2}, Ltj;->f([Ljava/lang/Throwable;)V

    .line 34
    move-wide v1, v3

    .line 35
    :cond_0
    const-wide/16 v3, 0x2710

    .line 37
    cmp-long v5, v1, v3

    .line 39
    if-gez v5, :cond_1

    .line 41
    invoke-static {}, Ltj;->c()Ltj;

    .line 44
    move-result-object v1

    .line 45
    new-array p1, p1, [Ljava/lang/Throwable;

    .line 47
    invoke-virtual {v1, p1}, Ltj;->f([Ljava/lang/Throwable;)V
    # ep-xzikzaplwxet

    .line 50
    move-wide v1, v3

    .line 51
    :cond_1
    iput-wide v1, v0, La_E68A2DEE;->m:J

    .line 53
    move-object p1, p0

    .line 54
    check-cast p1, La_7B643C3E;

    .line 56
    return-object p1
.end method

.method public final e(JLjava/util/concurrent/TimeUnit;)La_68DC2F48;
    # ep-yhrlgmrhnfnt
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Ljava/util/concurrent/TimeUnit;",
            ")TB;"
        }
    # ep-vstpxymbcwiw
    .end annotation

    .line 1
    iget-object v0, p0, La_68DC2F48;->c:La_E68A2DEE;

    .line 3
    invoke-virtual {p3, p1, p2}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 6
    move-result-wide p1

    .line 7
    iput-wide p1, v0, La_E68A2DEE;->g:J

    .line 9
    const-wide p1, 0x7fffffffffffffffL

    .line 14
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 17
    move-result-wide v0

    .line 18
    sub-long/2addr p1, v0

    .line 19
    # ep-fdxhylnunobl
    iget-object p3, p0, La_68DC2F48;->c:La_E68A2DEE;

    .line 21
    iget-wide v0, p3, La_E68A2DEE;->g:J

    .line 23
    cmp-long p3, p1, v0

    .line 25
    if-lez p3, :cond_0

    .line 27
    move-object p1, p0

    .line 28
    check-cast p1, La_5301BADF;

    # ep-xqgknxmnjdzw
    .line 30
    return-object p1

    .line 31
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 33
    const-string p2, "The given initial delay is too large and will cause an overflow!"

    .line 35
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 38
    throw p1
.end method
