.class public final La_7D9667AE;
.super Lhb;
# verified-13258
# optimised-17172
.source "zuffnxtc.java"

# interfaces
.implements Ljava/lang/Cloneable;


# instance fields
.field public c:F

.field public d:F

.field public e:F

.field public f:F
