.class public interface abstract La_442AD5D3;
.super Ljava/lang/Object;
.source "sgugozwd.java"


# processed-46197
# compiled-41555
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_6CAD33A3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
