.class public final La_23FDE5B1;
.super Ljava/lang/Object;
# processed-41378
.source "ygrjnvqn.java"

# ep-imapipntwmkk
# interfaces
.implements Loi;


# instance fields
.field public final a:La_EEE8F77D;


# direct methods
.method public constructor <init>(La_EEE8F77D;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_23FDE5B1;->a:La_EEE8F77D;

    .line 6
    return-void
.end method


# virtual methods
.method public final a(Lfp;)La_CF884759;
    .locals 13

    .line 1
    iget-object v0, p1, Lfp;->f:Lnp;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    new-instance v1, La_863BFCB6;

    .line 8
    invoke-direct {v1, v0}, La_863BFCB6;-><init>(Lnp;)V

    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    const/4 v2, 0x0

    .line 15
    const-string v3, "Content-Length"

    .line 17
    const-string v4, "Host"

    .line 19
    invoke-virtual {v0, v4}, Lnp;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 22
    move-result-object v5

    .line 23
    iget-object v6, v0, Lnp;->a:Lih;

    .line 25
    if-nez v5, :cond_0

    .line 27
    invoke-static {v6, v2}, Lex;->h(Lih;Z)Ljava/lang/String;

    .line 30
    move-result-object v5

    .line 31
    invoke-virtual {v1, v4, v5}, La_863BFCB6;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 34
    :cond_0
    const-string v4, "Connection"

    .line 36
    invoke-virtual {v0, v4}, Lnp;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 39
    move-result-object v5

    .line 40
    if-nez v5, :cond_1

    .line 42
    const-string v5, "Keep-Alive"

    .line 44
    invoke-virtual {v1, v4, v5}, La_863BFCB6;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 47
    :cond_1
    const-string v4, "Accept-Encoding"

    .line 49
    invoke-virtual {v0, v4}, Lnp;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 52
    move-result-object v5

    .line 53
    const-string v7, "gzip"

    .line 55
    if-nez v5, :cond_2

    .line 57
    invoke-virtual {v1, v4, v7}, La_863BFCB6;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 60
    const/4 v4, 0x1

    .line 61
    goto :goto_0

    .line 62
    :cond_2
    const/4 v4, 0x0

    .line 63
    :goto_0
    iget-object v5, p0, La_23FDE5B1;->a:La_EEE8F77D;

    .line 65
    move-object v8, v5

    .line 66
    check-cast v8, La_EB66AAF2;

    .line 68
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 71
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 74
    move-result-object v8

    .line 75
    invoke-interface {v8}, Ljava/util/List;->m_bcc1b243()Z

    .line 78
    move-result v9

    .line 79
    if-nez v9, :cond_5

    .line 81
    new-instance v9, Ljava/lang/StringBuilder;

    .line 83
    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    .line 86
    invoke-interface {v8}, Ljava/util/List;->m_414f6463()I

    .line 89
    move-result v10

    .line 90
    :goto_1
    if-ge v2, v10, :cond_4

    .line 92
    if-lez v2, :cond_3

    .line 94
    const-string v11, "; "

    .line 96
    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 99
    :cond_3
    invoke-interface {v8, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 102
    move-result-object v11

    .line 103
    check-cast v11, La_FB514E0B;

    .line 105
    iget-object v12, v11, La_FB514E0B;->a:Ljava/lang/String;

    .line 107
    invoke-virtual {v9, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    const/16 v12, 0x3d

    .line 112
    invoke-virtual {v9, v12}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 115
    iget-object v11, v11, La_FB514E0B;->b:Ljava/lang/String;

    .line 117
    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 120
    add-int/lit8 v2, v2, 0x1

    .line 122
    goto :goto_1

    .line 123
    :cond_4
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 126
    move-result-object v2

    .line 127
    const-string v8, "Cookie"

    .line 129
    invoke-virtual {v1, v8, v2}, La_863BFCB6;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 132
    :cond_5
    const-string v2, "User-Agent"

    .line 134
    invoke-virtual {v0, v2}, Lnp;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 137
    move-result-object v8

    .line 138
    if-nez v8, :cond_6

    .line 140
    const-string v8, "okhttp/3.5.0"

    .line 142
    invoke-virtual {v1, v2, v8}, La_863BFCB6;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 145
    :cond_6
    invoke-virtual {v1}, La_863BFCB6;->a()Lnp;

    .line 148
    move-result-object v1

    .line 149
    iget-object v2, p1, Lfp;->d:La_42CEF655;

    .line 151
    iget-object v8, p1, Lfp;->b:Lft;

    .line 153
    iget-object v9, p1, Lfp;->c:Lfh;

    .line 155
    invoke-virtual {p1, v1, v8, v9, v2}, Lfp;->a(Lnp;Lft;Lfh;La_42CEF655;)La_CF884759;

    .line 158
    move-result-object p1

    .line 159
    iget-object v1, p1, La_CF884759;->h:Ljg;

    .line 161
    invoke-static {v5, v6, v1}, Lhh;->d(La_EEE8F77D;Lih;Ljg;)V

    .line 164
    new-instance v1, La_2954BDC4;

    .line 166
    invoke-direct {v1, p1}, La_2954BDC4;-><init>(La_CF884759;)V

    .line 169
    iput-object v0, v1, La_2954BDC4;->a:Lnp;

    .line 171
    if-eqz v4, :cond_7

    .line 173
    const-string v0, "Content-Encoding"

    .line 175
    invoke-virtual {p1, v0}, La_CF884759;->h(Ljava/lang/String;)Ljava/lang/String;

    .line 178
    move-result-object v2

    .line 179
    invoke-virtual {v7, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 182
    move-result v2

    .line 183
    if-eqz v2, :cond_7

    .line 185
    invoke-static {p1}, Lhh;->b(La_CF884759;)Z

    .line 188
    move-result v2

    .line 189
    if-eqz v2, :cond_7

    .line 191
    new-instance v2, Lag;

    .line 193
    iget-object v4, p1, La_CF884759;->i:Ldq;

    .line 195
    invoke-virtual {v4}, Ldq;->j()La_05205363;

    .line 198
    move-result-object v4

    .line 199
    invoke-direct {v2, v4}, Lag;-><init>(La_05205363;)V

    .line 202
    iget-object p1, p1, La_CF884759;->h:Ljg;

    .line 204
    invoke-virtual {p1}, Ljg;->c()La_30C9629A;

    .line 207
    move-result-object p1

    .line 208
    invoke-virtual {p1, v0}, La_30C9629A;->c(Ljava/lang/String;)V

    .line 211
    invoke-virtual {p1, v3}, La_30C9629A;->c(Ljava/lang/String;)V

    .line 214
    new-instance v0, Ljg;

    .line 216
    invoke-direct {v0, p1}, Ljg;-><init>(La_30C9629A;)V

    .line 219
    invoke-virtual {v0}, Ljg;->c()La_30C9629A;

    .line 222
    move-result-object p1

    .line 223
    iput-object p1, v1, La_2954BDC4;->f:La_30C9629A;

    .line 225
    new-instance p1, Lgp;

    .line 227
    sget-object v3, Len;->a:Ljava/util/logging/Logger;

    .line 229
    new-instance v3, Lcp;

    .line 231
    invoke-direct {v3, v2}, Lcp;-><init>(Lrs;)V

    .line 234
    invoke-direct {p1, v0, v3}, Lgp;-><init>(Ljg;Lcp;)V

    .line 237
    iput-object p1, v1, La_2954BDC4;->g:Ldq;

    .line 239
    :cond_7
    invoke-virtual {v1}, La_2954BDC4;->a()La_CF884759;

    .line 242
    move-result-object p1

    .line 243
    return-object p1
.end method
