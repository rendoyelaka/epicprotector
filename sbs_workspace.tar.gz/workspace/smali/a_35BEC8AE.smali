.class public interface abstract La_35BEC8AE;
.super Ljava/lang/Object;
# compiled-27345
# processed-22772
# generated-85442
.source "knhvjmye.java"


# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
    # ep-jgklzritchmp
        value = {
    # ep-bezabmsrfvsd
            "(",
            "Ljava/util/List<",
    # ep-yjaenenzzcqm
            "Ljava/lang/String;",
            ">;)V"
    # ep-zuxjywwfzpby
        }
    .end annotation
.end method
