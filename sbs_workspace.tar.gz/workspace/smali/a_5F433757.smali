.class public final La_5F433757;
.super Ljava/lang/Object;
# ep-atizrrwycjwn
# compiled-22754
# processed-61891
# generated-40623
.source "nfiefsbb.java"

# interfaces
.implements La_5EF87ACB;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lzq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lb9$b<",
        "Ley;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
