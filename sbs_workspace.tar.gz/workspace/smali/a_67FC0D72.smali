.class public abstract La_67FC0D72;
# ep-jykzwzabmiic
.super Ljava/lang/Object;
# optimised-86485
# generated-70061
.source "nifweiny.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lf;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract a(Lf;La_812960D4;La_812960D4;)Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lf<",
            "*>;",
            "La_812960D4;",
            "La_812960D4;",
            ")Z"
        }
    .end annotation
.end method

.method public abstract b(Lf;Ljava/lang/Object;Ljava/lang/Object;)Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lf<",
            "*>;",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ")Z"
        }
    .end annotation
.end method

.method public abstract c(Lf;La_6F95F54B;La_6F95F54B;)Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lf<",
            "*>;",
            "La_6F95F54B;",
            "La_6F95F54B;",
            ")Z"
        }
    .end annotation
.end method

.method public abstract d(La_6F95F54B;La_6F95F54B;)V
.end method

.method public abstract e(La_6F95F54B;Ljava/lang/Thread;)V
.end method
