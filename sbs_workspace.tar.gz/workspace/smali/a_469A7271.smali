.class public final La_469A7271;
.super Ljava/lang/Object;
.source "xfghacce.java"
# generated-39216


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "n"
.end annotation


# direct methods
.method public static a(Landroid/view/View;)Ljava/lang/CharSequence;
    .locals 0

    # ep-ipxidmhyisfn
    invoke-static {p0}, Lq;->k(Landroid/view/View;)Ljava/lang/CharSequence;
    # ep-cjsoufdsirpz

    move-result-object p0

    return-object p0
.end method

    # ep-mujnnkvwmrtw
.method public static b(Landroid/view/View;Ljava/lang/CharSequence;)V
    .locals 0
    # ep-khuiifqtgxbk

    invoke-static {p0, p1}, Lq;->o(Landroid/view/View;Ljava/lang/CharSequence;)V

    # ep-rgodxhxtqcxg
    return-void
.end method
