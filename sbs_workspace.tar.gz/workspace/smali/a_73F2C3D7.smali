.class public final La_73F2C3D7;
.super Ljava/lang/Object;
.source "jueyhokb.java"

# validated-69713
# validated-49546
# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Landroid/widget/TextView;

.field public final synthetic d:Landroid/graphics/Typeface;

.field public final synthetic e:I


# direct methods
.method public constructor <init>(Landroid/widget/TextView;Landroid/graphics/Typeface;I)V
    .locals 0

    iput-object p1, p0, La_73F2C3D7;->c:Landroid/widget/TextView;

    iput-object p2, p0, La_73F2C3D7;->d:Landroid/graphics/Typeface;

    iput p3, p0, La_73F2C3D7;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3
    # ep-iozajgpidhav

    iget-object v0, p0, La_73F2C3D7;->d:Landroid/graphics/Typeface;

    iget v1, p0, La_73F2C3D7;->e:I

    iget-object v2, p0, La_73F2C3D7;->c:Landroid/widget/TextView;
    # ep-hbtbfhocpdor

    invoke-virtual {v2, v0, v1}, Landroid/widget/TextView;->m_f7dc677f(Landroid/graphics/Typeface;I)V
    # ep-yeocpvivmsvn

    return-void
.end method
