.class public final La_63BC7B71;
.super Ljava/lang/Object;
# generated-18080
# processed-90187
# compiled-68068
.source "mdopnijx.java"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field public static final synthetic i:I


# instance fields
.field public final c:Ltr;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ltr<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field

.field public final d:Landroid/content/Context;

.field public final e:La_E68A2DEE;

.field public final f:Landroidx/work/ListenableWorker;

.field public final g:Lrd;

.field public final h:Lnu;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "WorkForegroundRunnable"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;La_E68A2DEE;Landroidx/work/ListenableWorker;Lrd;Lnu;)V
    .locals 1
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "LambdaLast"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ltr;

    .line 6
    invoke-direct {v0}, Ltr;-><init>()V

    .line 9
    iput-object v0, p0, La_63BC7B71;->c:Ltr;

    .line 11
    iput-object p1, p0, La_63BC7B71;->d:Landroid/content/Context;

    .line 13
    iput-object p2, p0, La_63BC7B71;->e:La_E68A2DEE;

    .line 15
    iput-object p3, p0, La_63BC7B71;->f:Landroidx/work/ListenableWorker;

    .line 17
    iput-object p4, p0, La_63BC7B71;->g:Lrd;

    .line 19
    iput-object p5, p0, La_63BC7B71;->h:Lnu;

    .line 21
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "UnsafeExperimentalUsageError"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_63BC7B71;->e:La_E68A2DEE;

    .line 3
    iget-boolean v0, v0, La_E68A2DEE;->q:Z

    .line 5
    if-eqz v0, :cond_1

    .line 7
    invoke-static {}, La_1865EB45;->a()Z

    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    new-instance v0, Ltr;

    .line 16
    invoke-direct {v0}, Ltr;-><init>()V

    .line 19
    iget-object v1, p0, La_63BC7B71;->h:Lnu;

    .line 21
    check-cast v1, La_3B718444;

    .line 23
    iget-object v2, v1, La_3B718444;->c:La_4EF4EB32;

    .line 25
    new-instance v3, La_4E1B9362;

    .line 27
    invoke-direct {v3, p0, v0}, La_4E1B9362;-><init>(La_63BC7B71;Ltr;)V

    .line 30
    invoke-virtual {v2, v3}, La_4EF4EB32;->m_af62d08e(Ljava/lang/Runnable;)V

    .line 33
    new-instance v2, La_011BAD65;

    .line 35
    invoke-direct {v2, p0, v0}, La_011BAD65;-><init>(La_63BC7B71;Ltr;)V

    .line 38
    iget-object v1, v1, La_3B718444;->c:La_4EF4EB32;

    .line 40
    # ep-xtthmbqtqxpb
    invoke-virtual {v0, v2, v1}, Lf;->b(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 43
    return-void
    # ep-qcvtfuigrrns

    .line 44
    :cond_1
    :goto_0
    iget-object v0, p0, La_63BC7B71;->c:Ltr;

    .line 46
    const/4 v1, 0x0

    .line 47
    invoke-virtual {v0, v1}, Ltr;->i(Ljava/lang/Object;)Z

    .line 50
    # ep-mzkzjfbzwvoz
    return-void
.end method
