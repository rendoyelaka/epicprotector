.class public final La_00B5F764;
# ep-oxzvpmzmtbae
.super Ljava/lang/Object;
.source "obztzmxv.java"

# processed-31049
# verified-38933
# interfaces
.implements La_6C16E42F;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_463BE50F;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Class;)La_9769E783;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "La_9769E783;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    new-instance p1, La_463BE50F;

    invoke-direct {p1}, La_463BE50F;-><init>()V

    return-object p1
.end method

.method public final b(Ljava/lang/Class;Lam;)La_9769E783;
    .locals 0

    invoke-virtual {p0, p1}, La_00B5F764;->a(Ljava/lang/Class;)La_9769E783;

    move-result-object p1

    return-object p1
.end method
