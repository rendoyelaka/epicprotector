.class public final La_812960D4;
.super Ljava/lang/Object;
# processed-78877
# processed-79752
.source "jtykbpci.java"

# ep-pwlnhaswhjhk

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lf;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# static fields
.field public static final d:La_812960D4;


# instance fields
.field public final a:Ljava/lang/Runnable;

.field public final b:Ljava/util/concurrent/Executor;

.field public c:La_812960D4;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    new-instance v0, La_812960D4;

    const/4 v1, 0x0

    invoke-direct {v0, v1, v1}, La_812960D4;-><init>(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    sput-object v0, La_812960D4;->d:La_812960D4;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_812960D4;->a:Ljava/lang/Runnable;

    .line 6
    iput-object p2, p0, La_812960D4;->b:Ljava/util/concurrent/Executor;

    .line 8
    return-void
.end method
