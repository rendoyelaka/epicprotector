.class public final La_755AD028;
.super Ljava/lang/Object;
.source "yazbxonb.java"
# ep-djwgveothoaz
# optimised-42393
# validated-87998
# compiled-69008


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljg;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/ArrayList;

    .line 6
    const/16 v1, 0x14

    .line 8
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 11
    iput-object v0, p0, La_755AD028;->a:Ljava/util/ArrayList;

    .line 13
    return-void
.end method

.method public static b(Ljava/lang/String;Ljava/lang/String;)V
    .locals 10

    .line 1
    if-eqz p0, :cond_7

    .line 3
    invoke-virtual {p0}, Ljava/lang/String;->m_2bd5aeca()Z

    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_6

    .line 9
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 12
    move-result v0

    .line 13
    const/4 v1, 0x0

    .line 14
    const/4 v2, 0x0

    .line 15
    :goto_0
    const/4 v3, 0x1

    .line 16
    const/16 v4, 0x7f

    .line 18
    const/4 v5, 0x2

    .line 19
    const/4 v6, 0x3

    .line 20
    const/16 v7, 0x1f

    .line 22
    if-ge v2, v0, :cond_1

    .line 24
    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    .line 27
    move-result v8

    .line 28
    if-le v8, v7, :cond_0

    .line 30
    if-ge v8, v4, :cond_0

    .line 32
    add-int/lit8 v2, v2, 0x1

    .line 34
    goto :goto_0

    .line 35
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 37
    new-array v0, v6, [Ljava/lang/Object;

    .line 39
    invoke-static {v8}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 42
    move-result-object v4

    .line 43
    aput-object v4, v0, v1

    .line 45
    invoke-static {v2}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 48
    move-result-object v1

    .line 49
    aput-object v1, v0, v3

    .line 51
    aput-object p0, v0, v5

    .line 53
    const-string p0, "Unexpected char %#04x at %d in header name: %s"

    .line 55
    invoke-static {p0, v0}, Lex;->g(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 58
    move-result-object p0

    .line 59
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 62
    throw p1

    .line 63
    :cond_1
    if-eqz p1, :cond_5

    .line 65
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 68
    move-result v0

    .line 69
    const/4 v2, 0x0

    .line 70
    :goto_1
    if-ge v2, v0, :cond_4

    .line 72
    invoke-virtual {p1, v2}, Ljava/lang/String;->charAt(I)C

    .line 75
    move-result v8

    .line 76
    if-gt v8, v7, :cond_2

    .line 78
    const/16 v9, 0x9

    .line 80
    if-ne v8, v9, :cond_3

    .line 82
    :cond_2
    if-ge v8, v4, :cond_3

    .line 84
    add-int/lit8 v2, v2, 0x1

    .line 86
    goto :goto_1

    .line 87
    :cond_3
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 89
    const/4 v4, 0x4

    .line 90
    new-array v4, v4, [Ljava/lang/Object;

    .line 92
    invoke-static {v8}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 95
    move-result-object v7

    .line 96
    aput-object v7, v4, v1

    .line 98
    invoke-static {v2}, Ljava/lang/Integer;->m_446e0ad6(I)Ljava/lang/Integer;

    .line 101
    move-result-object v1

    .line 102
    aput-object v1, v4, v3

    .line 104
    aput-object p0, v4, v5

    .line 106
    aput-object p1, v4, v6

    .line 108
    const-string p0, "Unexpected char %#04x at %d in %s value: %s"

    .line 110
    invoke-static {p0, v4}, Lex;->g(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 113
    move-result-object p0

    .line 114
    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 117
    throw v0

    .line 118
    :cond_4
    return-void

    .line 119
    :cond_5
    new-instance p0, Ljava/lang/NullPointerException;

    .line 121
    const-string p1, "value == null"

    .line 123
    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 126
    throw p0

    .line 127
    :cond_6
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 129
    const-string p1, "name is empty"

    .line 131
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 134
    throw p0

    .line 135
    :cond_7
    new-instance p0, Ljava/lang/NullPointerException;

    .line 137
    const-string p1, "name == null"

    .line 139
    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 142
    throw p0
.end method


# virtual methods
.method public final a(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_755AD028;->a:Ljava/util/ArrayList;

    .line 3
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 6
    invoke-virtual {p2}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 9
    move-result-object p1

    .line 10
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 13
    return-void
.end method

.method public final c(Ljava/lang/String;)V
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_0
    iget-object v1, p0, La_755AD028;->a:Ljava/util/ArrayList;

    .line 4
    invoke-virtual {v1}, Ljava/util/ArrayList;->m_79017b7d()I

    .line 7
    move-result v2

    .line 8
    if-ge v0, v2, :cond_1

    .line 10
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 13
    move-result-object v2

    .line 14
    check-cast v2, Ljava/lang/String;

    .line 16
    invoke-virtual {p1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_0

    .line 22
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->m_8eb9dccd(I)Ljava/lang/Object;

    .line 25
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->m_8eb9dccd(I)Ljava/lang/Object;

    .line 28
    add-int/lit8 v0, v0, -0x2

    .line 30
    :cond_0
    add-int/lit8 v0, v0, 0x2

    .line 32
    goto :goto_0

    .line 33
    :cond_1
    return-void
.end method
