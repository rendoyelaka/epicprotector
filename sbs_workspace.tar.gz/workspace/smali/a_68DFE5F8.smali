.class public final La_68DFE5F8;
.super Ljava/lang/Object;
.source "zgyelkol.java"

# validated-65615
# processed-40742

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/view/ViewConfiguration;)I
    # ep-rezfcnetoepn
    .locals 0
    # ep-vbhjnfpbyekk

    # ep-hxnqxhszujtb
    invoke-static {p0}, Lso;->b(Landroid/view/ViewConfiguration;)I
    # ep-dtikiycqypvi

    move-result p0

    return p0
.end method

.method public static b(Landroid/view/ViewConfiguration;)Z
    .locals 0
    # ep-cqfdmdfzmslu

    # ep-ysphqdmwzwmz
    invoke-static {p0}, Lso;->s(Landroid/view/ViewConfiguration;)Z

    move-result p0

    return p0
.end method
