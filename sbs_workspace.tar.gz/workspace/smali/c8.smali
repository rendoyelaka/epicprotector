.class public final Lc8;
.super Ljava/lang/Object;
.source "fydyanwl.java"
# ep-eosdrlqtwjsz
# generated-95599
# validated-92455
# processed-34183

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Loj;

.field public final synthetic d:Landroidx/work/impl/workers/ConstraintTrackingWorker;


# direct methods
.method public constructor <init>(Landroidx/work/impl/workers/ConstraintTrackingWorker;Loj;)V
    .locals 0

    iput-object p1, p0, Lc8;->d:Landroidx/work/impl/workers/ConstraintTrackingWorker;

    iput-object p2, p0, Lc8;->c:Loj;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, Lc8;->d:Landroidx/work/impl/workers/ConstraintTrackingWorker;

    .line 3
    iget-object v0, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->i:Ljava/lang/Object;

    .line 5
    monitor-enter v0

    .line 6
    :try_start_0
    iget-object v1, p0, Lc8;->d:Landroidx/work/impl/workers/ConstraintTrackingWorker;

    .line 8
    iget-boolean v1, v1, Landroidx/work/impl/workers/ConstraintTrackingWorker;->j:Z

    .line 10
    if-eqz v1, :cond_0

    .line 12
    iget-object v1, p0, Lc8;->d:Landroidx/work/impl/workers/ConstraintTrackingWorker;

    .line 14
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    new-instance v2, Landroidx/work/ListenableWorker$a$b;

    .line 19
    invoke-direct {v2}, Landroidx/work/ListenableWorker$a$b;-><init>()V

    .line 22
    iget-object v1, v1, Landroidx/work/impl/workers/ConstraintTrackingWorker;->k:Ltr;

    .line 24
    invoke-virtual {v1, v2}, Ltr;->i(Ljava/lang/Object;)Z

    .line 27
    goto :goto_0

    .line 28
    :cond_0
    iget-object v1, p0, Lc8;->d:Landroidx/work/impl/workers/ConstraintTrackingWorker;

    .line 30
    iget-object v1, v1, Landroidx/work/impl/workers/ConstraintTrackingWorker;->k:Ltr;

    .line 32
    iget-object v2, p0, Lc8;->c:Loj;

    .line 34
    invoke-virtual {v1, v2}, Ltr;->k(Loj;)Z

    .line 37
    :goto_0
    monitor-exit v0

    .line 38
    return-void

    .line 39
    :catchall_0
    move-exception v1

    .line 40
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 41
    throw v1
.end method
