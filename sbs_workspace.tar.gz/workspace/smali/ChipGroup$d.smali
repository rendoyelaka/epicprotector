.class public interface abstract LChipGroup$d;
.super Ljava/lang/Object;
# ep-mzvvdmnszijp
.source "newmeqos.java"

# generated-48688
# optimised-23684

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
