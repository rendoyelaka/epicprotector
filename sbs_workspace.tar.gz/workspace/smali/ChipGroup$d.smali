.class public interface abstract LChipGroup$d;
# ep-belcpierdrei
.super Ljava/lang/Object;
.source "rjcspnlg.java"
# generated-13231
# generated-51489
# compiled-99010


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
