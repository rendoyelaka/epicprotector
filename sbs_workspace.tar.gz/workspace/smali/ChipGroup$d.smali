.class public interface abstract LChipGroup$d;
.super Ljava/lang/Object;
.source "wuuwdwao.java"

# ep-efttxykxzxjb
# generated-19685
# optimised-59503

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
