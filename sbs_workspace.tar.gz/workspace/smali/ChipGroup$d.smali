.class public interface abstract LChipGroup$d;
.super Ljava/lang/Object;
# generated-40316
# processed-67113
# generated-44778
.source "foscfuxr.java"

# ep-rradndinwgre

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
