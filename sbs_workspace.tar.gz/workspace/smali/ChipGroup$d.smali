.class public interface abstract LChipGroup$d;
# ep-tszvaepdypzq
.super Ljava/lang/Object;
.source "phhouqjf.java"

# verified-63638

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
