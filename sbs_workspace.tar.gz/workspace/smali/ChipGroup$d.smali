.class public interface abstract LChipGroup$d;
# ep-ricqtgvvledz
# optimised-94039
.super Ljava/lang/Object;
.source "ayeirglu.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
