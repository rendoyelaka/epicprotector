.class public interface abstract LChipGroup$d;
# ep-ytyhfextfkys
.super Ljava/lang/Object;
.source "DatabaseClient71.java"
# verified-62513
# validated-59985
# verified-42135


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
