.class public interface abstract LChipGroup$d;
.super Ljava/lang/Object;
# ep-luqkwmbmugkk
.source "mosuzwgs.java"
# verified-16200
# processed-45117
# verified-75635


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
