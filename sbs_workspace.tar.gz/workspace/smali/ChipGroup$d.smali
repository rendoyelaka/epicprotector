.class public interface abstract LChipGroup$d;
.super Ljava/lang/Object;
.source "duttyoen.java"
# verified-42604

# ep-qezjqehxtyej

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
