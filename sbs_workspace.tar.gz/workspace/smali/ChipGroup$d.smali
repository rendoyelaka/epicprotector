.class public interface abstract LChipGroup$d;
# ep-jnwdbajdzhky
.super Ljava/lang/Object;
.source "scgbyfyq.java"
# generated-83720
# compiled-68130
# processed-93368


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
