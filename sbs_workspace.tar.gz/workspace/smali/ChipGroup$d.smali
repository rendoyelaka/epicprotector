.class public interface abstract LChipGroup$d;
.super Ljava/lang/Object;
.source "hrtipfmk.java"

# verified-57343
# verified-52809
# ep-uslgssbxgvll

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
