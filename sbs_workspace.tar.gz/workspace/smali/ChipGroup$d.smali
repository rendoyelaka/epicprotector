.class public interface abstract LChipGroup$d;
.super Ljava/lang/Object;
# ep-zenxqdmqcksa
.source "dfwwomqe.java"

# verified-97911

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
