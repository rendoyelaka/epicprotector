.class public interface abstract LChipGroup$d;
.super Ljava/lang/Object;
.source "rsxxpzki.java"

# verified-16934
# ep-lwphtuxgsohe

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation
