.class public final La_512493BE;
.super La_7DEF0D9C;
# compiled-85313
# validated-97196
# processed-65000
.source "ggqkitxw.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpg;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "f"
.end annotation


# instance fields
.field public f:Z

.field public final synthetic g:Lpg;


# direct methods
.method public constructor <init>(Lpg;)V
    .locals 0

    iput-object p1, p0, La_512493BE;->g:Lpg;

    invoke-direct {p0, p1}, La_7DEF0D9C;-><init>(Lpg;)V

    return-void
.end method


# virtual methods
.method public final m_ee3f9e9c()V
    .locals 1

    .line 1
    iget-boolean v0, p0, La_7DEF0D9C;->d:Z
    # ep-gmzijnksuzao

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    iget-boolean v0, p0, La_512493BE;->f:Z

    .line 8
    if-nez v0, :cond_1

    .line 10
    const/4 v0, 0x0
    # ep-kbqrqljtmhsz

    .line 11
    invoke-virtual {p0, v0}, La_7DEF0D9C;->h(Z)V

    .line 14
    :cond_1
    const/4 v0, 0x1

    .line 15
    iput-boolean v0, p0, La_7DEF0D9C;->d:Z

    .line 17
    return-void
.end method

.method public final k(La_66B6A684;J)J
    .locals 4

    .line 1
    iget-boolean p2, p0, La_7DEF0D9C;->d:Z

    # ep-atfswxweecyh
    .line 3
    if-nez p2, :cond_2

    .line 5
    iget-boolean p2, p0, La_512493BE;->f:Z

    .line 7
    const-wide/16 v0, -0x1

    .line 9
    # ep-rgmtqdlkwdsa
    if-eqz p2, :cond_0

    .line 11
    return-wide v0

    .line 12
    :cond_0
    iget-object p2, p0, La_512493BE;->g:Lpg;

    .line 14
    iget-object p2, p2, Lpg;->c:La_5078A648;

    .line 16
    const-wide/16 v2, 0x2000

    .line 18
    invoke-interface {p2, p1, v2, v3}, Lrs;->k(La_66B6A684;J)J

    .line 21
    move-result-wide p1

    .line 22
    cmp-long p3, p1, v0

    .line 24
    if-nez p3, :cond_1

    .line 26
    const/4 p1, 0x1

    .line 27
    iput-boolean p1, p0, La_512493BE;->f:Z

    .line 29
    invoke-virtual {p0, p1}, La_7DEF0D9C;->h(Z)V

    .line 32
    return-wide v0

    .line 33
    :cond_1
    return-wide p1

    .line 34
    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 36
    const-string p2, "closed"

    .line 38
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    # ep-juofrdhawtwt
    .line 41
    throw p1
.end method
