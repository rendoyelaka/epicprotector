.class public final La_26D85A69;
.super La_B8F093B7;
.source "czkhjosm.java"


# processed-47893
# generated-33177
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_B8F093B7;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Ljava/lang/Throwable;


# direct methods
.method public constructor <init>(Ljava/lang/Throwable;)V
    .locals 0

    .line 1
    invoke-direct {p0}, La_B8F093B7;-><init>()V

    .line 4
    iput-object p1, p0, La_26D85A69;->a:Ljava/lang/Throwable;

    .line 6
    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 3

    # ep-bkdomqtwhjxc
    .line 1
    const/4 v0, 0x1

    .line 2
    new-array v0, v0, [Ljava/lang/Object;
    # ep-fuzuurxtpvvd

    .line 4
    iget-object v1, p0, La_26D85A69;->a:Ljava/lang/Throwable;

    .line 6
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 9
    move-result-object v1

    .line 10
    const/4 v2, 0x0

    .line 11
    # ep-kbattcluntbg
    aput-object v1, v0, v2

    .line 13
    const-string v1, "FAILURE (%s)"

    .line 15
    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    # ep-bwuvmqnmnibu
    .line 18
    move-result-object v0

    .line 19
    return-object v0
.end method
