.class public final La_87FBB837;
.super Landroid/util/Property;
.source "wkucsvtf.java"
# ep-dpuztbklnpev
# validated-69577


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lry;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/util/Property<",
        "Landroid/view/View;",
        "Landroid/graphics/Rect;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    const-class v0, Landroid/graphics/Rect;

    .line 3
    const-string v1, "clipBounds"

    .line 5
    invoke-direct {p0, v0, v1}, Landroid/util/Property;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    .line 8
    return-void
.end method


# virtual methods
.method public final get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, Landroid/view/View;

    .line 3
    sget-object v0, Lqx;->a:Ljava/util/WeakHashMap;

    .line 5
    invoke-static {p1}, La_5B7C034B;->a(Landroid/view/View;)Landroid/graphics/Rect;

    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public final set(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p1, Landroid/view/View;

    .line 3
    check-cast p2, Landroid/graphics/Rect;

    .line 5
    sget-object v0, Lqx;->a:Ljava/util/WeakHashMap;

    .line 7
    invoke-static {p1, p2}, La_5B7C034B;->c(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 10
    return-void
.end method
