.class public final Lb4;
.super Ls4;
.source "xrqpuptm.java"
# ep-vqwhrvjmzqol

# validated-21872
# verified-98069
# validated-39349

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ls4<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "CDY3o1MPmEik3o1f21BFvhsc"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lnu;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ls4;-><init>(Landroid/content/Context;Lnu;)V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 4

    .line 1
    new-instance v0, Landroid/content/IntentFilter;

    .line 3
    const-string v1, "KzknpVkUhSWlwp5ux0UItB0a2Yf9lvKXnUpE5pQtAPYLGQSScg=="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 5
    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    .line 8
    iget-object v1, p0, La8;->b:Landroid/content/Context;

    .line 10
    const/4 v2, 0x0

    .line 11
    invoke-virtual {v1, v2, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 14
    move-result-object v0

    .line 15
    const/4 v1, 0x0

    .line 16
    if-nez v0, :cond_0

    .line 18
    invoke-static {}, Ltj;->c()Ltj;

    .line 21
    move-result-object v0

    .line 22
    new-array v1, v1, [Ljava/lang/Throwable;

    .line 24
    invoke-virtual {v0, v1}, Ltj;->b([Ljava/lang/Throwable;)V

    .line 27
    goto :goto_1

    .line 28
    :cond_0
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 30
    const/16 v3, 0x17

    .line 32
    if-lt v2, v3, :cond_1

    .line 34
    const-string v2, "OSMio0MO"
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 36
    const/4 v3, -0x1

    .line 37
    invoke-virtual {v0, v2, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 40
    move-result v0

    .line 41
    const/4 v2, 0x2

    .line 42
    if-eq v0, v2, :cond_2

    .line 44
    const/4 v2, 0x5

    .line 45
    if-ne v0, v2, :cond_3

    .line 47
    goto :goto_0

    .line 48
    :cond_1
    const-string v2, "Ojs2sFEYhQ=="
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v2

    .line 50
    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_3

    .line 56
    :cond_2
    :goto_0
    const/4 v1, 0x1

    .line 57
    :cond_3
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 60
    move-result-object v2

    .line 61
    :goto_1
    return-object v2
.end method

.method public final f()Landroid/content/IntentFilter;
    .locals 3

    .line 1
    new-instance v0, Landroid/content/IntentFilter;

    .line 3
    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    .line 6
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 8
    const/16 v2, 0x17

    .line 10
    if-lt v1, v2, :cond_0

    .line 12
    const-string v1, "KzknpVkUhSWj38RqykVPuhBA86DS6vefh1k="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 14
    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 17
    const-string v1, "KzknpVkUhSWj38RqykVPuhBA9KHA+/iXm1lI+oo="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 19
    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const-string v1, "KzknpVkUhSWlwp5ux0UItB0a2Yf9lvGVnVdO+pIiDOkPBRyUeTOvTo/4r08="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 25
    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 28
    const-string v1, "KzknpVkUhSWlwp5ux0UItB0a2Yf9lvGVnVdO+pIiDOkPBRyTfy6iRILir0j9dGI="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 30
    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 33
    :goto_0
    return-object v0
.end method

.method public final g(Landroid/content/Intent;)V
    .locals 5

    .line 1
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 4
    move-result-object p1

    .line 5
    if-nez p1, :cond_0

    .line 7
    return-void

    .line 8
    :cond_0
    invoke-static {}, Ltj;->c()Ltj;

    .line 11
    move-result-object v0

    .line 12
    const/4 v1, 0x1

    .line 13
    new-array v2, v1, [Ljava/lang/Object;

    .line 15
    const/4 v3, 0x0

    .line 16
    aput-object p1, v2, v3

    .line 18
    const-string v4, "GDIgsl8LhG/siZk="
    invoke-static {v4}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v4

    .line 20
    invoke-static {v4, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 23
    new-array v2, v3, [Ljava/lang/Throwable;

    .line 25
    invoke-virtual {v0, v2}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 28
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    .line 31
    move-result v0

    .line 32
    const/4 v2, 0x3

    .line 33
    const/4 v4, 0x2

    .line 34
    sparse-switch v0, :sswitch_data_0

    .line 37
    goto :goto_0

    .line 38
    :sswitch_0
    const-string v0, "KzknpVkUhSWlwp5ux0UItB0a2Yf9lvGVnVdO+pIiDOkPBRyUeTOvTo/4r08="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 40
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 43
    move-result p1

    .line 44
    if-nez p1, :cond_1

    .line 46
    goto :goto_0

    .line 47
    :cond_1
    const/4 v3, 0x3

    .line 48
    goto :goto_1

    .line 49
    :sswitch_1
    const-string v0, "KzknpVkUhSWj38RqykVPuhBA86DS6vefh1k="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 51
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 54
    move-result p1

    .line 55
    if-nez p1, :cond_2

    .line 57
    goto :goto_0

    .line 58
    :cond_2
    const/4 v3, 0x2

    .line 59
    goto :goto_1

    .line 60
    :sswitch_2
    const-string v0, "KzknpVkUhSWj38RqykVPuhBA9KHA+/iXm1lI+oo="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 62
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 65
    move-result p1

    .line 66
    if-nez p1, :cond_3

    .line 68
    goto :goto_0

    .line 69
    :cond_3
    const/4 v3, 0x1

    .line 70
    goto :goto_1

    .line 71
    :sswitch_3
    const-string v0, "KzknpVkUhSWlwp5ux0UItB0a2Yf9lvGVnVdO+pIiDOkPBRyTfy6iRILir0j9dGI="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 73
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 76
    move-result p1

    .line 77
    if-nez p1, :cond_4

    .line 79
    :goto_0
    const/4 v3, -0x1

    .line 80
    :cond_4
    :goto_1
    if-eqz v3, :cond_8

    .line 82
    if-eq v3, v1, :cond_7

    .line 84
    if-eq v3, v4, :cond_6

    .line 86
    if-eq v3, v2, :cond_5

    .line 88
    goto :goto_2

    .line 89
    :cond_5
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 91
    invoke-virtual {p0, p1}, La8;->c(Ljava/lang/Object;)V

    .line 94
    goto :goto_2

    .line 95
    :cond_6
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 97
    invoke-virtual {p0, p1}, La8;->c(Ljava/lang/Object;)V

    .line 100
    goto :goto_2

    .line 101
    :cond_7
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 103
    invoke-virtual {p0, p1}, La8;->c(Ljava/lang/Object;)V

    .line 106
    goto :goto_2

    .line 107
    :cond_8
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 109
    invoke-virtual {p0, p1}, La8;->c(Ljava/lang/Object;)V

    .line 112
    :goto_2
    return-void

    .line 113
    :sswitch_data_0
    .sparse-switch
        -0x7073f927 -> :sswitch_3
        -0x3465cce -> :sswitch_2
        0x388694fe -> :sswitch_1
        0x3cbf870b -> :sswitch_0
    .end sparse-switch
.end method
