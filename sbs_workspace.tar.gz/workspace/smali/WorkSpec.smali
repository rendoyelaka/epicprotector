.class public final LWorkSpec;
.super Ljava/lang/Object;
# validated-64250
# compiled-65809
.source "jrdymbet.java"
# ep-ngrpgtkrznas


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LWorkSpec$a;
    }
.end annotation


# static fields
.field public static final synthetic s:I


# instance fields
.field public a:Ljava/lang/String;

.field public b:LWorkInfo_State;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Landroidx/work/b;

.field public f:Landroidx/work/b;

.field public g:J

.field public h:J

.field public i:J

.field public j:Lf8;

.field public k:I

.field public l:I

.field public m:J

.field public n:J

.field public o:J

.field public p:J

.field public q:Z

.field public r:I


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "eqgG00ytw7I="
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(LWorkSpec;)V
    .locals 3

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    sget-object v0, LWorkInfo_State;->c:LWorkInfo_State;

    iput-object v0, p0, LWorkSpec;->b:LWorkInfo_State;

    .line 14
    sget-object v0, Landroidx/work/b;->b:Landroidx/work/b;

    iput-object v0, p0, LWorkSpec;->e:Landroidx/work/b;

    .line 15
    iput-object v0, p0, LWorkSpec;->f:Landroidx/work/b;

    .line 16
    sget-object v0, Lf8;->i:Lf8;

    iput-object v0, p0, LWorkSpec;->j:Lf8;

    const/4 v0, 0x1

    .line 17
    iput v0, p0, LWorkSpec;->l:I

    const-wide/16 v1, 0x7530

    .line 18
    iput-wide v1, p0, LWorkSpec;->m:J

    const-wide/16 v1, -0x1

    .line 19
    iput-wide v1, p0, LWorkSpec;->p:J

    .line 20
    iput v0, p0, LWorkSpec;->r:I

    .line 21
    iget-object v0, p1, LWorkSpec;->a:Ljava/lang/String;

    iput-object v0, p0, LWorkSpec;->a:Ljava/lang/String;

    .line 22
    iget-object v0, p1, LWorkSpec;->c:Ljava/lang/String;

    iput-object v0, p0, LWorkSpec;->c:Ljava/lang/String;

    .line 23
    iget-object v0, p1, LWorkSpec;->b:LWorkInfo_State;

    iput-object v0, p0, LWorkSpec;->b:LWorkInfo_State;

    .line 24
    iget-object v0, p1, LWorkSpec;->d:Ljava/lang/String;

    iput-object v0, p0, LWorkSpec;->d:Ljava/lang/String;

    .line 25
    new-instance v0, Landroidx/work/b;

    iget-object v1, p1, LWorkSpec;->e:Landroidx/work/b;

    invoke-direct {v0, v1}, Landroidx/work/b;-><init>(Landroidx/work/b;)V

    iput-object v0, p0, LWorkSpec;->e:Landroidx/work/b;

    .line 26
    new-instance v0, Landroidx/work/b;

    iget-object v1, p1, LWorkSpec;->f:Landroidx/work/b;

    invoke-direct {v0, v1}, Landroidx/work/b;-><init>(Landroidx/work/b;)V

    iput-object v0, p0, LWorkSpec;->f:Landroidx/work/b;

    .line 27
    iget-wide v0, p1, LWorkSpec;->g:J

    iput-wide v0, p0, LWorkSpec;->g:J

    .line 28
    iget-wide v0, p1, LWorkSpec;->h:J

    iput-wide v0, p0, LWorkSpec;->h:J

    .line 29
    iget-wide v0, p1, LWorkSpec;->i:J

    iput-wide v0, p0, LWorkSpec;->i:J

    .line 30
    new-instance v0, Lf8;

    iget-object v1, p1, LWorkSpec;->j:Lf8;

    invoke-direct {v0, v1}, Lf8;-><init>(Lf8;)V

    iput-object v0, p0, LWorkSpec;->j:Lf8;

    .line 31
    iget v0, p1, LWorkSpec;->k:I

    iput v0, p0, LWorkSpec;->k:I

    .line 32
    iget v0, p1, LWorkSpec;->l:I

    iput v0, p0, LWorkSpec;->l:I

    .line 33
    iget-wide v0, p1, LWorkSpec;->m:J

    iput-wide v0, p0, LWorkSpec;->m:J

    .line 34
    iget-wide v0, p1, LWorkSpec;->n:J

    iput-wide v0, p0, LWorkSpec;->n:J

    .line 35
    iget-wide v0, p1, LWorkSpec;->o:J

    iput-wide v0, p0, LWorkSpec;->o:J

    .line 36
    iget-wide v0, p1, LWorkSpec;->p:J

    iput-wide v0, p0, LWorkSpec;->p:J

    .line 37
    iget-boolean v0, p1, LWorkSpec;->q:Z

    iput-boolean v0, p0, LWorkSpec;->q:Z

    .line 38
    iget p1, p1, LWorkSpec;->r:I

    iput p1, p0, LWorkSpec;->r:I

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    sget-object v0, LWorkInfo_State;->c:LWorkInfo_State;

    iput-object v0, p0, LWorkSpec;->b:LWorkInfo_State;

    .line 3
    sget-object v0, Landroidx/work/b;->b:Landroidx/work/b;

    iput-object v0, p0, LWorkSpec;->e:Landroidx/work/b;

    .line 4
    iput-object v0, p0, LWorkSpec;->f:Landroidx/work/b;

    .line 5
    sget-object v0, Lf8;->i:Lf8;

    iput-object v0, p0, LWorkSpec;->j:Lf8;

    const/4 v0, 0x1

    .line 6
    iput v0, p0, LWorkSpec;->l:I

    const-wide/16 v1, 0x7530

    .line 7
    iput-wide v1, p0, LWorkSpec;->m:J

    const-wide/16 v1, -0x1

    .line 8
    iput-wide v1, p0, LWorkSpec;->p:J

    .line 9
    iput v0, p0, LWorkSpec;->r:I

    .line 10
    iput-object p1, p0, LWorkSpec;->a:Ljava/lang/String;

    .line 11
    iput-object p2, p0, LWorkSpec;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a()J
    .locals 12

    .line 1
    iget-object v0, p0, LWorkSpec;->b:LWorkInfo_State;

    .line 3
    sget-object v1, LWorkInfo_State;->c:LWorkInfo_State;

    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    if-ne v0, v1, :cond_0

    .line 9
    iget v0, p0, LWorkSpec;->k:I

    .line 11
    if-lez v0, :cond_0

    .line 13
    const/4 v0, 0x1

    .line 14
    goto :goto_0

    .line 15
    :cond_0
    const/4 v0, 0x0

    .line 16
    :goto_0
    if-eqz v0, :cond_3

    .line 18
    iget v0, p0, LWorkSpec;->l:I

    .line 20
    const/4 v1, 0x2

    .line 21
    if-ne v0, v1, :cond_1

    .line 23
    const/4 v2, 0x1

    .line 24
    :cond_1
    if-eqz v2, :cond_2

    .line 26
    iget-wide v0, p0, LWorkSpec;->m:J

    .line 28
    iget v2, p0, LWorkSpec;->k:I

    .line 30
    int-to-long v2, v2

    .line 31
    mul-long v0, v0, v2

    .line 33
    goto :goto_1

    .line 34
    :cond_2
    iget-wide v0, p0, LWorkSpec;->m:J

    .line 36
    long-to-float v0, v0

    .line 37
    iget v1, p0, LWorkSpec;->k:I

    .line 39
    sub-int/2addr v1, v3

    .line 40
    invoke-static {v0, v1}, Ljava/lang/Math;->scalb(FI)F

    .line 43
    move-result v0

    .line 44
    float-to-long v0, v0

    .line 45
    :goto_1
    iget-wide v2, p0, LWorkSpec;->n:J

    .line 47
    const-wide/32 v4, 0x112a880

    .line 50
    invoke-static {v4, v5, v0, v1}, Ljava/lang/Math;->min(JJ)J

    .line 53
    move-result-wide v0

    .line 54
    goto :goto_3

    .line 55
    :cond_3
    invoke-virtual {p0}, LWorkSpec;->c()Z

    .line 58
    move-result v0

    .line 59
    const-wide/16 v4, 0x0

    .line 61
    if-eqz v0, :cond_9

    .line 63
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 66
    move-result-wide v0

    .line 67
    iget-wide v6, p0, LWorkSpec;->n:J

    .line 69
    cmp-long v8, v6, v4

    .line 71
    if-nez v8, :cond_4

    .line 73
    iget-wide v6, p0, LWorkSpec;->g:J

    .line 75
    add-long/2addr v6, v0

    .line 76
    :cond_4
    iget-wide v0, p0, LWorkSpec;->i:J

    .line 78
    iget-wide v9, p0, LWorkSpec;->h:J

    .line 80
    cmp-long v11, v0, v9

    .line 82
    if-eqz v11, :cond_5

    .line 84
    const/4 v2, 0x1

    .line 85
    :cond_5
    if-eqz v2, :cond_7

    .line 87
    if-nez v8, :cond_6

    .line 89
    const-wide/16 v2, -0x1

    .line 91
    mul-long v4, v0, v2

    .line 93
    :cond_6
    add-long/2addr v6, v9

    .line 94
    add-long/2addr v6, v4

    .line 95
    return-wide v6

    .line 96
    :cond_7
    if-nez v8, :cond_8

    .line 98
    goto :goto_2

    .line 99
    :cond_8
    move-wide v4, v9

    .line 100
    :goto_2
    add-long/2addr v6, v4

    .line 101
    return-wide v6

    .line 102
    :cond_9
    iget-wide v0, p0, LWorkSpec;->n:J

    .line 104
    cmp-long v2, v0, v4

    .line 106
    if-nez v2, :cond_a

    .line 108
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 111
    move-result-wide v0

    .line 112
    :cond_a
    iget-wide v2, p0, LWorkSpec;->g:J

    .line 114
    :goto_3
    add-long/2addr v0, v2

    .line 115
    return-wide v0
.end method

.method public final b()Z
    .locals 2

    sget-object v0, Lf8;->i:Lf8;

    iget-object v1, p0, LWorkSpec;->j:Lf8;

    invoke-virtual {v0, v1}, Lf8;->equals(Ljava/lang/Object;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method

.method public final c()Z
    .locals 5

    iget-wide v0, p0, LWorkSpec;->h:J

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    if-eqz v4, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 7

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 4
    return v0

    .line 5
    :cond_0
    const/4 v1, 0x0

    .line 6
    if-eqz p1, :cond_15

    .line 8
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    move-result-object v2

    .line 12
    const-class v3, LWorkSpec;

    .line 14
    if-eq v3, v2, :cond_1

    .line 16
    goto/16 :goto_2

    .line 18
    :cond_1
    check-cast p1, LWorkSpec;

    .line 20
    iget-wide v2, p0, LWorkSpec;->g:J

    .line 22
    iget-wide v4, p1, LWorkSpec;->g:J

    .line 24
    cmp-long v6, v2, v4

    .line 26
    if-eqz v6, :cond_2

    .line 28
    return v1

    .line 29
    :cond_2
    iget-wide v2, p0, LWorkSpec;->h:J

    .line 31
    iget-wide v4, p1, LWorkSpec;->h:J

    .line 33
    cmp-long v6, v2, v4

    .line 35
    if-eqz v6, :cond_3

    .line 37
    return v1

    .line 38
    :cond_3
    iget-wide v2, p0, LWorkSpec;->i:J

    .line 40
    iget-wide v4, p1, LWorkSpec;->i:J

    .line 42
    cmp-long v6, v2, v4

    .line 44
    if-eqz v6, :cond_4

    .line 46
    return v1

    .line 47
    :cond_4
    iget v2, p0, LWorkSpec;->k:I

    .line 49
    iget v3, p1, LWorkSpec;->k:I

    .line 51
    if-eq v2, v3, :cond_5

    .line 53
    return v1

    .line 54
    :cond_5
    iget-wide v2, p0, LWorkSpec;->m:J

    .line 56
    iget-wide v4, p1, LWorkSpec;->m:J

    .line 58
    cmp-long v6, v2, v4

    .line 60
    if-eqz v6, :cond_6

    .line 62
    return v1

    .line 63
    :cond_6
    iget-wide v2, p0, LWorkSpec;->n:J

    .line 65
    iget-wide v4, p1, LWorkSpec;->n:J

    .line 67
    cmp-long v6, v2, v4

    .line 69
    if-eqz v6, :cond_7

    .line 71
    return v1

    .line 72
    :cond_7
    iget-wide v2, p0, LWorkSpec;->o:J

    .line 74
    iget-wide v4, p1, LWorkSpec;->o:J

    .line 76
    cmp-long v6, v2, v4

    .line 78
    if-eqz v6, :cond_8

    .line 80
    return v1

    .line 81
    :cond_8
    iget-wide v2, p0, LWorkSpec;->p:J

    .line 83
    iget-wide v4, p1, LWorkSpec;->p:J

    .line 85
    cmp-long v6, v2, v4

    .line 87
    if-eqz v6, :cond_9

    .line 89
    return v1

    .line 90
    :cond_9
    iget-boolean v2, p0, LWorkSpec;->q:Z

    .line 92
    iget-boolean v3, p1, LWorkSpec;->q:Z

    .line 94
    if-eq v2, v3, :cond_a

    .line 96
    return v1

    .line 97
    :cond_a
    iget-object v2, p0, LWorkSpec;->a:Ljava/lang/String;

    .line 99
    iget-object v3, p1, LWorkSpec;->a:Ljava/lang/String;

    .line 101
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 104
    move-result v2

    .line 105
    if-nez v2, :cond_b

    .line 107
    return v1

    .line 108
    :cond_b
    iget-object v2, p0, LWorkSpec;->b:LWorkInfo_State;

    .line 110
    iget-object v3, p1, LWorkSpec;->b:LWorkInfo_State;

    .line 112
    if-eq v2, v3, :cond_c

    .line 114
    return v1

    .line 115
    :cond_c
    iget-object v2, p0, LWorkSpec;->c:Ljava/lang/String;

    .line 117
    iget-object v3, p1, LWorkSpec;->c:Ljava/lang/String;

    .line 119
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 122
    move-result v2

    .line 123
    if-nez v2, :cond_d

    .line 125
    return v1

    .line 126
    :cond_d
    iget-object v2, p0, LWorkSpec;->d:Ljava/lang/String;

    .line 128
    if-eqz v2, :cond_e

    .line 130
    iget-object v3, p1, LWorkSpec;->d:Ljava/lang/String;

    .line 132
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 135
    move-result v2

    .line 136
    if-nez v2, :cond_f

    .line 138
    goto :goto_0

    .line 139
    :cond_e
    iget-object v2, p1, LWorkSpec;->d:Ljava/lang/String;

    .line 141
    if-eqz v2, :cond_f

    .line 143
    :goto_0
    return v1

    .line 144
    :cond_f
    iget-object v2, p0, LWorkSpec;->e:Landroidx/work/b;

    .line 146
    iget-object v3, p1, LWorkSpec;->e:Landroidx/work/b;

    .line 148
    invoke-virtual {v2, v3}, Landroidx/work/b;->equals(Ljava/lang/Object;)Z

    .line 151
    move-result v2

    .line 152
    if-nez v2, :cond_10

    .line 154
    return v1

    .line 155
    :cond_10
    iget-object v2, p0, LWorkSpec;->f:Landroidx/work/b;

    .line 157
    iget-object v3, p1, LWorkSpec;->f:Landroidx/work/b;

    .line 159
    invoke-virtual {v2, v3}, Landroidx/work/b;->equals(Ljava/lang/Object;)Z

    .line 162
    move-result v2

    .line 163
    if-nez v2, :cond_11

    .line 165
    return v1

    .line 166
    :cond_11
    iget-object v2, p0, LWorkSpec;->j:Lf8;

    .line 168
    iget-object v3, p1, LWorkSpec;->j:Lf8;

    .line 170
    invoke-virtual {v2, v3}, Lf8;->equals(Ljava/lang/Object;)Z

    .line 173
    move-result v2

    .line 174
    if-nez v2, :cond_12

    .line 176
    return v1

    .line 177
    :cond_12
    iget v2, p0, LWorkSpec;->l:I

    .line 179
    iget v3, p1, LWorkSpec;->l:I

    .line 181
    if-eq v2, v3, :cond_13

    .line 183
    return v1

    .line 184
    :cond_13
    iget v2, p0, LWorkSpec;->r:I

    .line 186
    iget p1, p1, LWorkSpec;->r:I

    .line 188
    if-ne v2, p1, :cond_14

    .line 190
    goto :goto_1

    .line 191
    :cond_14
    const/4 v0, 0x0

    .line 192
    :goto_1
    return v0

    .line 193
    :cond_15
    :goto_2
    return v1
.end method

.method public final hashCode()I
    .locals 6

    .line 1
    iget-object v0, p0, LWorkSpec;->a:Ljava/lang/String;

    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 9
    iget-object v1, p0, LWorkSpec;->b:LWorkInfo_State;

    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 14
    move-result v1

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 18
    iget-object v0, p0, LWorkSpec;->c:Ljava/lang/String;

    .line 20
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 23
    move-result v0

    .line 24
    add-int/2addr v0, v1

    .line 25
    mul-int/lit8 v0, v0, 0x1f

    .line 27
    iget-object v1, p0, LWorkSpec;->d:Ljava/lang/String;

    .line 29
    if-eqz v1, :cond_0

    .line 31
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 34
    move-result v1

    .line 35
    goto :goto_0

    .line 36
    :cond_0
    const/4 v1, 0x0

    .line 37
    :goto_0
    add-int/2addr v0, v1

    .line 38
    mul-int/lit8 v0, v0, 0x1f

    .line 40
    iget-object v1, p0, LWorkSpec;->e:Landroidx/work/b;

    .line 42
    invoke-virtual {v1}, Landroidx/work/b;->hashCode()I

    .line 45
    move-result v1

    .line 46
    add-int/2addr v1, v0

    .line 47
    mul-int/lit8 v1, v1, 0x1f

    .line 49
    iget-object v0, p0, LWorkSpec;->f:Landroidx/work/b;

    .line 51
    invoke-virtual {v0}, Landroidx/work/b;->hashCode()I

    .line 54
    move-result v0

    .line 55
    add-int/2addr v0, v1

    .line 56
    mul-int/lit8 v0, v0, 0x1f

    .line 58
    iget-wide v1, p0, LWorkSpec;->g:J

    .line 60
    const/16 v3, 0x20

    .line 62
    ushr-long v4, v1, v3

    .line 64
    xor-long/2addr v1, v4

    .line 65
    long-to-int v2, v1

    .line 66
    add-int/2addr v0, v2

    .line 67
    mul-int/lit8 v0, v0, 0x1f

    .line 69
    iget-wide v1, p0, LWorkSpec;->h:J

    .line 71
    ushr-long v4, v1, v3

    .line 73
    xor-long/2addr v1, v4

    .line 74
    long-to-int v2, v1

    .line 75
    add-int/2addr v0, v2

    .line 76
    mul-int/lit8 v0, v0, 0x1f

    .line 78
    iget-wide v1, p0, LWorkSpec;->i:J

    .line 80
    ushr-long v4, v1, v3

    .line 82
    xor-long/2addr v1, v4

    .line 83
    long-to-int v2, v1

    .line 84
    add-int/2addr v0, v2

    .line 85
    mul-int/lit8 v0, v0, 0x1f

    .line 87
    iget-object v1, p0, LWorkSpec;->j:Lf8;

    .line 89
    invoke-virtual {v1}, Lf8;->hashCode()I

    .line 92
    move-result v1

    .line 93
    add-int/2addr v1, v0

    .line 94
    mul-int/lit8 v1, v1, 0x1f

    .line 96
    iget v0, p0, LWorkSpec;->k:I

    .line 98
    add-int/2addr v1, v0

    .line 99
    mul-int/lit8 v1, v1, 0x1f

    .line 101
    iget v0, p0, LWorkSpec;->l:I

    .line 103
    invoke-static {v0}, Lps;->k(I)I

    .line 106
    move-result v0

    .line 107
    add-int/2addr v0, v1

    .line 108
    mul-int/lit8 v0, v0, 0x1f

    .line 110
    iget-wide v1, p0, LWorkSpec;->m:J

    .line 112
    ushr-long v4, v1, v3

    .line 114
    xor-long/2addr v1, v4

    .line 115
    long-to-int v2, v1

    .line 116
    add-int/2addr v0, v2

    .line 117
    mul-int/lit8 v0, v0, 0x1f

    .line 119
    iget-wide v1, p0, LWorkSpec;->n:J

    .line 121
    ushr-long v4, v1, v3

    .line 123
    xor-long/2addr v1, v4

    .line 124
    long-to-int v2, v1

    .line 125
    add-int/2addr v0, v2

    .line 126
    mul-int/lit8 v0, v0, 0x1f

    .line 128
    iget-wide v1, p0, LWorkSpec;->o:J

    .line 130
    ushr-long v4, v1, v3

    .line 132
    xor-long/2addr v1, v4

    .line 133
    long-to-int v2, v1

    .line 134
    add-int/2addr v0, v2

    .line 135
    mul-int/lit8 v0, v0, 0x1f

    .line 137
    iget-wide v1, p0, LWorkSpec;->p:J

    .line 139
    ushr-long v3, v1, v3

    .line 141
    xor-long/2addr v1, v3

    .line 142
    long-to-int v2, v1

    .line 143
    add-int/2addr v0, v2

    .line 144
    mul-int/lit8 v0, v0, 0x1f

    .line 146
    iget-boolean v1, p0, LWorkSpec;->q:Z

    .line 148
    add-int/2addr v0, v1

    .line 149
    mul-int/lit8 v0, v0, 0x1f

    .line 151
    iget v1, p0, LWorkSpec;->r:I

    .line 153
    invoke-static {v1}, Lps;->k(I)I

    .line 156
    move-result v1

    .line 157
    add-int/2addr v1, v0

    .line 158
    return v1
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    const-string v1, "VpAbynSO1rTtNTY="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 8
    iget-object v1, p0, LWorkSpec;->a:Ljava/lang/String;

    .line 10
    const-string v2, "}"

    .line 12
    invoke-static {v0, v1, v2}, Lps;->e(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 15
    move-result-object v0

    .line 16
    return-object v0
.end method
