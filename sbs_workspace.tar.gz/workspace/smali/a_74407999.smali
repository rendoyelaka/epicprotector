.class public abstract La_74407999;
.super Ljava/lang/Object;
.source "zyjzlnnv.java"


# processed-11029
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# instance fields
.field public final a:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/16 v0, 0xc

    .line 6
    iput v0, p0, La_74407999;->a:I

    .line 8
    return-void
.end method


# virtual methods
.method public abstract a(Lqe;)V
.end method

.method public abstract b(Lqe;)La_6FA736A1;
.end method
