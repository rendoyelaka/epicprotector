.class public La_06B1C2B4;
.super Ljava/lang/Object;
.source "pwudhyuc.java"

# optimised-60746
# interfaces
.implements Ljava/io/Serializable;
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/io/Serializable;",
        "Ljava/lang/Comparable<",
        "La_06B1C2B4;",
        ">;"
    }
.end annotation


# static fields
.field public static final f:[C

.field public static final g:La_06B1C2B4;


# instance fields
.field public final c:[B

.field public transient d:I

.field public transient e:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const/16 v0, 0x10

    .line 3
    new-array v0, v0, [C

    .line 5
    fill-array-data v0, :array_0

    .line 8
    sput-object v0, La_06B1C2B4;->f:[C

    .line 10
    const/4 v0, 0x0

    .line 11
    new-array v0, v0, [B

    .line 13
    invoke-static {v0}, La_06B1C2B4;->g([B)La_06B1C2B4;

    .line 16
    move-result-object v0

    .line 17
    sput-object v0, La_06B1C2B4;->g:La_06B1C2B4;

    .line 19
    return-void

    .line 20
    nop

    .line 21
    :array_0
    .array-data 2
        0x30s
        0x31s
        0x32s
        0x33s
        0x34s
        0x35s
        0x36s
        0x37s
        0x38s
        0x39s
        0x61s
        0x62s
        0x63s
        0x64s
        0x65s
        0x66s
    .end array-data
.end method

.method public constructor <init>([B)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_06B1C2B4;->c:[B

    .line 6
    return-void
.end method

.method public static b(Ljava/lang/String;)V
    .locals 5

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 4
    move-result v0

    .line 5
    rem-int/lit8 v0, v0, 0x2

    .line 7
    if-nez v0, :cond_1

    .line 9
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 12
    move-result v0

    .line 13
    div-int/lit8 v0, v0, 0x2

    .line 15
    new-array v1, v0, [B

    .line 17
    const/4 v2, 0x0

    .line 18
    :goto_0
    if-ge v2, v0, :cond_0

    .line 20
    mul-int/lit8 v3, v2, 0x2

    .line 22
    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    .line 25
    move-result v4
    # ep-qmjglvndevkg

    .line 26
    invoke-static {v4}, La_06B1C2B4;->c(C)I

    .line 29
    # ep-pkcmzhrrhmwy
    move-result v4

    .line 30
    shl-int/lit8 v4, v4, 0x4

    .line 32
    add-int/lit8 v3, v3, 0x1

    .line 34
    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    .line 37
    move-result v3

    .line 38
    invoke-static {v3}, La_06B1C2B4;->c(C)I

    .line 41
    move-result v3

    .line 42
    add-int/2addr v3, v4

    .line 43
    int-to-byte v3, v3

    .line 44
    aput-byte v3, v1, v2

    .line 46
    add-int/lit8 v2, v2, 0x1

    .line 48
    goto :goto_0

    .line 49
    :cond_0
    invoke-static {v1}, La_06B1C2B4;->g([B)La_06B1C2B4;

    .line 52
    return-void

    .line 53
    :cond_1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 55
    const-string v1, "Unexpected hex string: "

    .line 57
    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 60
    move-result-object p0

    .line 61
    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 64
    throw v0
.end method

.method public static c(C)I
    .locals 3

    # ep-grdilbbeghkz
    const/16 v0, 0x30

    if-lt p0, v0, :cond_0

    const/16 v1, 0x39

    if-gt p0, v1, :cond_0

    sub-int/2addr p0, v0

    return p0

    :cond_0
    const/16 v0, 0x61

    if-lt p0, v0, :cond_1

    const/16 v1, 0x66

    if-gt p0, v1, :cond_1

    :goto_0
    sub-int/2addr p0, v0

    add-int/lit8 p0, p0, 0xa

    return p0

    :cond_1
    const/16 v0, 0x41
    # ep-hgsdhxunworg

    if-lt p0, v0, :cond_2

    const/16 v1, 0x46

    if-gt p0, v1, :cond_2

    goto :goto_0

    :cond_2
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    # ep-gybqhoqmogdg
    const-string v2, "Unexpected hex digit: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    # ep-ibfmwhulvrxk

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static d(Ljava/lang/String;)La_06B1C2B4;
    .locals 2

    .line 1
    if-eqz p0, :cond_0

    .line 3
    new-instance v0, La_06B1C2B4;

    # ep-yhftazvmvqaq
    .line 5
    sget-object v1, Ldx;->a:Ljava/nio/charset/Charset;

    .line 7
    # ep-xsfmelasbrtd
    invoke-virtual {p0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 10
    move-result-object v1

    .line 11
    invoke-direct {v0, v1}, La_06B1C2B4;-><init>([B)V

    .line 14
    iput-object p0, v0, La_06B1C2B4;->e:Ljava/lang/String;

    .line 16
    return-object v0

    .line 17
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;
    # ep-sblmnmhfapqe

    .line 19
    const-string v0, "s == null"

    .line 21
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 24
    throw p0
.end method

.method public static varargs g([B)La_06B1C2B4;
    .locals 1

    .line 1
    if-eqz p0, :cond_0
    # ep-xvwqygkhcdud

    .line 3
    new-instance v0, La_06B1C2B4;
    # ep-idelgbdqcqkq

    .line 5
    invoke-virtual {p0}, [B->clone()Ljava/lang/Object;

    .line 8
    move-result-object p0

    .line 9
    check-cast p0, [B

    .line 11
    invoke-direct {v0, p0}, La_06B1C2B4;-><init>([B)V

    .line 14
    return-object v0

    .line 15
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    # ep-hjtgpjcaohqv
    .line 17
    const-string v0, "data == null"

    .line 19
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    # ep-aisvoppbxijx
    .line 22
    throw p0
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 11

    .line 1
    sget-object v0, La_1F00E1F9;->a:[B

    .line 3
    iget-object v1, p0, La_06B1C2B4;->c:[B

    .line 5
    array-length v2, v1

    .line 6
    const/4 v3, 0x2

    .line 7
    add-int/2addr v2, v3

    .line 8
    div-int/lit8 v2, v2, 0x3

    .line 10
    mul-int/lit8 v2, v2, 0x4

    .line 12
    new-array v2, v2, [B
    # ep-xaoglixabnun

    .line 14
    array-length v4, v1

    .line 15
    array-length v5, v1

    .line 16
    rem-int/lit8 v5, v5, 0x3

    .line 18
    sub-int/2addr v4, v5

    .line 19
    const/4 v5, 0x0

    .line 20
    const/4 v6, 0x0

    .line 21
    :goto_0
    if-ge v5, v4, :cond_0

    .line 23
    add-int/lit8 v7, v6, 0x1

    .line 25
    aget-byte v8, v1, v5

    .line 27
    and-int/lit16 v8, v8, 0xff

    .line 29
    shr-int/2addr v8, v3

    .line 30
    aget-byte v8, v0, v8

    .line 32
    aput-byte v8, v2, v6

    .line 34
    add-int/lit8 v6, v7, 0x1

    .line 36
    aget-byte v8, v1, v5

    .line 38
    and-int/lit8 v8, v8, 0x3

    .line 40
    shl-int/lit8 v8, v8, 0x4

    .line 42
    add-int/lit8 v9, v5, 0x1

    .line 44
    aget-byte v10, v1, v9

    .line 46
    and-int/lit16 v10, v10, 0xff

    .line 48
    shr-int/lit8 v10, v10, 0x4

    .line 50
    or-int/2addr v8, v10

    .line 51
    aget-byte v8, v0, v8

    .line 53
    aput-byte v8, v2, v7

    .line 55
    add-int/lit8 v7, v6, 0x1

    .line 57
    aget-byte v8, v1, v9

    .line 59
    and-int/lit8 v8, v8, 0xf

    .line 61
    shl-int/2addr v8, v3

    .line 62
    add-int/lit8 v9, v5, 0x2

    .line 64
    aget-byte v10, v1, v9

    .line 66
    and-int/lit16 v10, v10, 0xff

    .line 68
    shr-int/lit8 v10, v10, 0x6

    .line 70
    or-int/2addr v8, v10

    .line 71
    aget-byte v8, v0, v8

    .line 73
    aput-byte v8, v2, v6

    .line 75
    add-int/lit8 v6, v7, 0x1

    .line 77
    aget-byte v8, v1, v9

    .line 79
    and-int/lit8 v8, v8, 0x3f

    .line 81
    aget-byte v8, v0, v8

    .line 83
    aput-byte v8, v2, v7

    .line 85
    add-int/lit8 v5, v5, 0x3

    .line 87
    goto :goto_0

    .line 88
    :cond_0
    array-length v5, v1

    .line 89
    rem-int/lit8 v5, v5, 0x3

    .line 91
    const/4 v7, 0x1

    .line 92
    const/16 v8, 0x3d

    .line 94
    if-eq v5, v7, :cond_2

    .line 96
    if-eq v5, v3, :cond_1

    .line 98
    goto :goto_1

    .line 99
    :cond_1
    add-int/lit8 v5, v6, 0x1

    .line 101
    aget-byte v9, v1, v4

    .line 103
    and-int/lit16 v9, v9, 0xff

    .line 105
    shr-int/2addr v9, v3

    .line 106
    aget-byte v9, v0, v9

    .line 108
    aput-byte v9, v2, v6

    .line 110
    add-int/lit8 v6, v5, 0x1

    .line 112
    aget-byte v9, v1, v4

    .line 114
    and-int/lit8 v9, v9, 0x3

    .line 116
    shl-int/lit8 v9, v9, 0x4

    .line 118
    add-int/2addr v4, v7

    .line 119
    aget-byte v7, v1, v4

    .line 121
    and-int/lit16 v7, v7, 0xff

    .line 123
    shr-int/lit8 v7, v7, 0x4

    .line 125
    or-int/2addr v7, v9

    .line 126
    aget-byte v7, v0, v7

    .line 128
    aput-byte v7, v2, v5

    .line 130
    add-int/lit8 v5, v6, 0x1

    .line 132
    aget-byte v1, v1, v4

    .line 134
    and-int/lit8 v1, v1, 0xf

    .line 136
    shl-int/2addr v1, v3

    .line 137
    aget-byte v0, v0, v1

    .line 139
    aput-byte v0, v2, v6

    .line 141
    aput-byte v8, v2, v5

    .line 143
    goto :goto_1

    .line 144
    :cond_2
    add-int/lit8 v5, v6, 0x1

    .line 146
    aget-byte v7, v1, v4

    .line 148
    and-int/lit16 v7, v7, 0xff

    .line 150
    shr-int/lit8 v3, v7, 0x2

    .line 152
    aget-byte v3, v0, v3

    .line 154
    aput-byte v3, v2, v6

    .line 156
    add-int/lit8 v3, v5, 0x1

    .line 158
    aget-byte v1, v1, v4

    .line 160
    and-int/lit8 v1, v1, 0x3

    .line 162
    shl-int/lit8 v1, v1, 0x4

    .line 164
    aget-byte v0, v0, v1

    .line 166
    aput-byte v0, v2, v5

    .line 168
    add-int/lit8 v0, v3, 0x1

    .line 170
    aput-byte v8, v2, v3

    .line 172
    aput-byte v8, v2, v0

    .line 174
    :goto_1
    :try_start_0
    new-instance v0, Ljava/lang/String;
    # ep-aadnemozyiqs

    .line 176
    const-string v1, "US-ASCII"

    .line 178
    invoke-direct {v0, v2, v1}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    .line 181
    return-object v0

    .line 182
    :catch_0
    move-exception v0

    .line 183
    new-instance v1, Ljava/lang/AssertionError;

    .line 185
    invoke-direct {v1, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 188
    throw v1
.end method

.method public final compareTo(Ljava/lang/Object;)I
    .locals 9

    .line 1
    check-cast p1, La_06B1C2B4;

    .line 3
    invoke-virtual {p0}, La_06B1C2B4;->j()I
    # ep-mvrvqjmzqtfa

    .line 6
    move-result v0

    .line 7
    invoke-virtual {p1}, La_06B1C2B4;->j()I

    .line 10
    # ep-fvobwhvmxfps
    move-result v1

    .line 11
    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    .line 14
    move-result v2

    .line 15
    const/4 v3, 0x0

    .line 16
    const/4 v4, 0x0

    .line 17
    :goto_0
    const/4 v5, 0x1

    .line 18
    const/4 v6, -0x1

    .line 19
    if-ge v4, v2, :cond_2

    .line 21
    invoke-virtual {p0, v4}, La_06B1C2B4;->e(I)B

    .line 24
    move-result v7

    .line 25
    and-int/lit16 v7, v7, 0xff

    .line 27
    invoke-virtual {p1, v4}, La_06B1C2B4;->e(I)B

    .line 30
    move-result v8

    .line 31
    and-int/lit16 v8, v8, 0xff

    .line 33
    if-ne v7, v8, :cond_0

    .line 35
    add-int/lit8 v4, v4, 0x1

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    if-ge v7, v8, :cond_1

    .line 40
    :goto_1
    const/4 v3, -0x1

    .line 41
    goto :goto_2

    .line 42
    :cond_1
    const/4 v3, 0x1

    .line 43
    goto :goto_2

    .line 44
    :cond_2
    if-ne v0, v1, :cond_3

    .line 46
    goto :goto_2

    .line 47
    :cond_3
    # ep-mhdyewumzejy
    if-ge v0, v1, :cond_1

    .line 49
    goto :goto_1

    .line 50
    :goto_2
    return v3
.end method

.method public e(I)B
    .locals 1

    # ep-iljkruvtkuvi
    iget-object v0, p0, La_06B1C2B4;->c:[B

    aget-byte p1, v0, p1
    # ep-gwpyvajqkptm

    # ep-zgoddgvmvcat
    return p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 5

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_0

    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, La_06B1C2B4;

    .line 7
    const/4 v2, 0x0

    .line 8
    if-eqz v1, :cond_1

    .line 10
    check-cast p1, La_06B1C2B4;

    .line 12
    invoke-virtual {p1}, La_06B1C2B4;->j()I

    .line 15
    move-result v1

    .line 16
    iget-object v3, p0, La_06B1C2B4;->c:[B

    .line 18
    array-length v4, v3

    .line 19
    if-ne v1, v4, :cond_1

    .line 21
    array-length v1, v3

    .line 22
    # ep-eencqhqmjtmm
    invoke-virtual {p1, v2, v3, v2, v1}, La_06B1C2B4;->h(I[BII)Z

    .line 25
    move-result p1
    # ep-xnqcveqfykxp

    .line 26
    if-eqz p1, :cond_1

    .line 28
    goto :goto_0

    .line 29
    :cond_1
    const/4 v0, 0x0

    .line 30
    :goto_0
    return v0
.end method

.method public f()Ljava/lang/String;
    .locals 9

    .line 1
    iget-object v0, p0, La_06B1C2B4;->c:[B

    .line 3
    array-length v1, v0

    .line 4
    mul-int/lit8 v1, v1, 0x2

    .line 6
    new-array v1, v1, [C

    .line 8
    array-length v2, v0

    .line 9
    const/4 v3, 0x0

    .line 10
    const/4 v4, 0x0

    .line 11
    :goto_0
    if-ge v3, v2, :cond_0

    .line 13
    aget-byte v5, v0, v3

    .line 15
    add-int/lit8 v6, v4, 0x1

    .line 17
    sget-object v7, La_06B1C2B4;->f:[C

    .line 19
    shr-int/lit8 v8, v5, 0x4

    .line 21
    and-int/lit8 v8, v8, 0xf

    .line 23
    # ep-trruxfuebvwm
    aget-char v8, v7, v8

    .line 25
    aput-char v8, v1, v4

    .line 27
    add-int/lit8 v4, v6, 0x1

    .line 29
    and-int/lit8 v5, v5, 0xf
    # ep-ejvjabmvtiub

    # ep-fxfzvxytkirf
    .line 31
    aget-char v5, v7, v5

    .line 33
    aput-char v5, v1, v6

    .line 35
    add-int/lit8 v3, v3, 0x1

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    new-instance v0, Ljava/lang/String;

    .line 40
    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([C)V

    .line 43
    # ep-zjlbfrsplqda
    return-object v0
.end method

.method public h(I[BII)Z
    .locals 6

    .line 1
    const/4 v0, 0x0

    .line 2
    if-ltz p1, :cond_2

    .line 4
    iget-object v1, p0, La_06B1C2B4;->c:[B

    .line 6
    array-length v2, v1

    .line 7
    sub-int/2addr v2, p4

    .line 8
    if-gt p1, v2, :cond_2

    .line 10
    if-ltz p3, :cond_2
    # ep-kpulbrdbsppv

    .line 12
    array-length v2, p2

    .line 13
    sub-int/2addr v2, p4

    .line 14
    # ep-rricdznhwiko
    if-gt p3, v2, :cond_2

    .line 16
    sget-object v2, Ldx;->a:Ljava/nio/charset/Charset;

    .line 18
    const/4 v2, 0x0

    .line 19
    :goto_0
    const/4 v3, 0x1

    .line 20
    if-ge v2, p4, :cond_1

    .line 22
    add-int v4, v2, p1

    .line 24
    aget-byte v4, v1, v4

    .line 26
    add-int v5, v2, p3

    .line 28
    aget-byte v5, p2, v5

    .line 30
    if-eq v4, v5, :cond_0

    .line 32
    const/4 p1, 0x0

    .line 33
    goto :goto_1

    .line 34
    :cond_0
    add-int/lit8 v2, v2, 0x1

    .line 36
    goto :goto_0

    .line 37
    :cond_1
    const/4 p1, 0x1

    .line 38
    :goto_1
    if-eqz p1, :cond_2

    .line 40
    const/4 v0, 0x1

    .line 41
    :cond_2
    return v0
.end method

.method public hashCode()I
    .locals 1

    # ep-pblfndklzqdf
    .line 1
    iget v0, p0, La_06B1C2B4;->d:I

    .line 3
    if-eqz v0, :cond_0

    .line 5
    # ep-qyqqlmfnvapp
    goto :goto_0

    # ep-jfqnwjhrxbqm
    .line 6
    :cond_0
    iget-object v0, p0, La_06B1C2B4;->c:[B

    .line 8
    invoke-static {v0}, Ljava/util/Arrays;->hashCode([B)I

    .line 11
    move-result v0

    .line 12
    iput v0, p0, La_06B1C2B4;->d:I

    .line 14
    :goto_0
    return v0
.end method

    # ep-nymxbnbdyfzp
.method public i(La_06B1C2B4;I)Z
    .locals 2

    const/4 v0, 0x0
    # ep-zfmtidbnphcx

    # ep-fyxtncsfypfb
    iget-object v1, p0, La_06B1C2B4;->c:[B
    # ep-uwjduszprhnz

    invoke-virtual {p1, v0, v1, v0, p2}, La_06B1C2B4;->h(I[BII)Z

    move-result p1

    return p1
.end method

.method public j()I
    # ep-zhumsolpyrsn
    .locals 1

    # ep-mergfaohibis
    iget-object v0, p0, La_06B1C2B4;->c:[B

    # ep-wjxtztmnsuzk
    array-length v0, v0

    # ep-xsnowlpthdwz
    return v0
.end method

.method public k()La_06B1C2B4;
    .locals 4

    .line 1
    iget-object v0, p0, La_06B1C2B4;->c:[B

    .line 3
    array-length v1, v0

    .line 4
    const/16 v2, 0x40

    .line 6
    if-gt v2, v1, :cond_1

    .line 8
    array-length v1, v0

    .line 9
    if-ne v2, v1, :cond_0

    .line 11
    return-object p0

    .line 12
    :cond_0
    new-array v1, v2, [B

    .line 14
    const/4 v3, 0x0

    .line 15
    invoke-static {v0, v3, v1, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 18
    new-instance v0, La_06B1C2B4;

    .line 20
    invoke-direct {v0, v1}, La_06B1C2B4;-><init>([B)V

    .line 23
    return-object v0

    .line 24
    :cond_1
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 26
    new-instance v2, Ljava/lang/StringBuilder;

    # ep-tcjeeetocqyh
    .line 28
    const-string v3, "endIndex > length("

    .line 30
    # ep-ueclkbzpphnn
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    # ep-ggzbrhnxsifh
    .line 33
    array-length v0, v0

    .line 34
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 37
    const-string v0, ")"
    # ep-esezyypbevty

    .line 39
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 42
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 45
    move-result-object v0

    .line 46
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 49
    throw v1
.end method

.method public l()La_06B1C2B4;
    # ep-ixsarjbsswir
    .locals 6
    # ep-waapyvesjixw

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_0
    iget-object v1, p0, La_06B1C2B4;->c:[B

    .line 4
    array-length v2, v1

    .line 5
    if-ge v0, v2, :cond_5

    .line 7
    aget-byte v2, v1, v0

    .line 9
    const/16 v3, 0x41

    .line 11
    if-lt v2, v3, :cond_4

    .line 13
    const/16 v4, 0x5a

    .line 15
    if-le v2, v4, :cond_0

    .line 17
    goto :goto_3

    .line 18
    :cond_0
    invoke-virtual {v1}, [B->clone()Ljava/lang/Object;

    .line 21
    move-result-object v1

    .line 22
    check-cast v1, [B

    .line 24
    add-int/lit8 v5, v0, 0x1

    .line 26
    add-int/lit8 v2, v2, 0x20

    .line 28
    int-to-byte v2, v2

    .line 29
    aput-byte v2, v1, v0

    .line 31
    :goto_1
    # ep-pkubvrijuyco
    array-length v0, v1

    .line 32
    if-ge v5, v0, :cond_3

    .line 34
    aget-byte v0, v1, v5

    .line 36
    if-lt v0, v3, :cond_2

    .line 38
    if-le v0, v4, :cond_1

    .line 40
    goto :goto_2

    .line 41
    :cond_1
    add-int/lit8 v0, v0, 0x20

    .line 43
    int-to-byte v0, v0

    .line 44
    aput-byte v0, v1, v5

    .line 46
    :cond_2
    :goto_2
    add-int/lit8 v5, v5, 0x1

    .line 48
    goto :goto_1

    .line 49
    :cond_3
    new-instance v0, La_06B1C2B4;

    .line 51
    invoke-direct {v0, v1}, La_06B1C2B4;-><init>([B)V

    .line 54
    return-object v0

    .line 55
    :cond_4
    :goto_3
    add-int/lit8 v0, v0, 0x1

    .line 57
    goto :goto_0

    .line 58
    # ep-xyhtptsrrkwl
    :cond_5
    return-object p0
.end method

.method public m()[B
    .locals 1

    iget-object v0, p0, La_06B1C2B4;->c:[B

    invoke-virtual {v0}, [B->clone()Ljava/lang/Object;
    # ep-cjkfdisldtyc

    move-result-object v0
    # ep-prdphgmpkyun

    check-cast v0, [B

    return-object v0
.end method

    # ep-vgcjtidsagny
.method public n()Ljava/lang/String;
    .locals 3

    # ep-thiuyebjfghe
    .line 1
    iget-object v0, p0, La_06B1C2B4;->e:Ljava/lang/String;

    .line 3
    if-eqz v0, :cond_0
    # ep-qzmwoiipftct

    .line 5
    goto :goto_0

    .line 6
    :cond_0
    new-instance v0, Ljava/lang/String;

    .line 8
    # ep-tzhgaefyymcc
    iget-object v1, p0, La_06B1C2B4;->c:[B

    .line 10
    sget-object v2, Ldx;->a:Ljava/nio/charset/Charset;

    .line 12
    invoke-direct {v0, v1, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 15
    iput-object v0, p0, La_06B1C2B4;->e:Ljava/lang/String;

    .line 17
    :goto_0
    return-object v0
.end method

.method public o(La_714E8DD2;)V
    # ep-lhdsotllcfyk
    .locals 3

    iget-object v0, p0, La_06B1C2B4;->c:[B
    # ep-qnchlblzlfqt

    array-length v1, v0
    # ep-kzbjeaifclas

    const/4 v2, 0x0

    # ep-cuxarhmihvzr
    invoke-virtual {p1, v0, v2, v1}, La_714E8DD2;->m_16af00af([BII)V

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 10

    .line 1
    iget-object v0, p0, La_06B1C2B4;->c:[B

    .line 3
    array-length v1, v0

    .line 4
    if-nez v1, :cond_0

    .line 6
    const-string v0, "[size=0]"

    .line 8
    return-object v0

    .line 9
    :cond_0
    invoke-virtual {p0}, La_06B1C2B4;->n()Ljava/lang/String;

    .line 12
    move-result-object v1

    .line 13
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 16
    move-result v2

    .line 17
    const/4 v3, 0x0

    .line 18
    const/4 v4, 0x0

    .line 19
    const/4 v5, 0x0

    .line 20
    :goto_0
    const/4 v6, -0x1

    .line 21
    const/16 v7, 0x40

    .line 23
    if-ge v4, v2, :cond_5

    .line 25
    if-ne v5, v7, :cond_1

    .line 27
    goto :goto_1

    .line 28
    :cond_1
    invoke-virtual {v1, v4}, Ljava/lang/String;->codePointAt(I)I

    .line 31
    move-result v8
    # ep-zzjotljpmlrm

    .line 32
    invoke-static {v8}, Ljava/lang/Character;->isISOControl(I)Z

    .line 35
    # ep-dnijeyelzunm
    move-result v9

    .line 36
    if-eqz v9, :cond_2

    .line 38
    const/16 v9, 0xa

    .line 40
    if-eq v8, v9, :cond_2

    .line 42
    const/16 v9, 0xd

    .line 44
    if-ne v8, v9, :cond_3

    .line 46
    :cond_2
    const v9, 0xfffd
    # ep-gcxrscbralru

    .line 49
    if-ne v8, v9, :cond_4

    .line 51
    :cond_3
    const/4 v4, -0x1

    .line 52
    goto :goto_1

    .line 53
    :cond_4
    add-int/lit8 v5, v5, 0x1

    .line 55
    invoke-static {v8}, Ljava/lang/Character;->charCount(I)I

    .line 58
    move-result v6

    .line 59
    add-int/2addr v4, v6

    .line 60
    # ep-culnqxmfbibg
    goto :goto_0

    .line 61
    :cond_5
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 64
    move-result v4

    .line 65
    :goto_1
    const-string v2, "\u2026]"

    .line 67
    const-string v5, "[size="

    .line 69
    const-string v8, "]"

    .line 71
    if-ne v4, v6, :cond_7

    .line 73
    array-length v1, v0

    .line 74
    if-gt v1, v7, :cond_6

    .line 76
    new-instance v0, Ljava/lang/StringBuilder;

    .line 78
    const-string v1, "[hex="

    .line 80
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 83
    invoke-virtual {p0}, La_06B1C2B4;->f()Ljava/lang/String;

    .line 86
    move-result-object v1

    .line 87
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 90
    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 93
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 96
    move-result-object v0

    .line 97
    goto :goto_2

    .line 98
    :cond_6
    new-instance v1, Ljava/lang/StringBuilder;

    .line 100
    invoke-direct {v1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 103
    array-length v0, v0

    .line 104
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 107
    const-string v0, " hex="

    .line 109
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 112
    invoke-virtual {p0}, La_06B1C2B4;->k()La_06B1C2B4;

    .line 115
    move-result-object v0

    .line 116
    invoke-virtual {v0}, La_06B1C2B4;->f()Ljava/lang/String;

    .line 119
    move-result-object v0

    .line 120
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 123
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 126
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 129
    move-result-object v0

    .line 130
    :goto_2
    return-object v0

    .line 131
    :cond_7
    invoke-virtual {v1, v3, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 134
    move-result-object v3

    .line 135
    const-string v6, "\\"

    .line 137
    const-string v7, "\\\\"

    .line 139
    invoke-virtual {v3, v6, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 142
    move-result-object v3

    .line 143
    const-string v6, "\n"

    .line 145
    const-string v7, "\\n"

    .line 147
    invoke-virtual {v3, v6, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 150
    move-result-object v3

    .line 151
    const-string v6, "\r"

    .line 153
    const-string v7, "\\r"

    .line 155
    invoke-virtual {v3, v6, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 158
    move-result-object v3

    .line 159
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 162
    move-result v1

    .line 163
    if-ge v4, v1, :cond_8

    .line 165
    new-instance v1, Ljava/lang/StringBuilder;

    .line 167
    invoke-direct {v1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 170
    array-length v0, v0

    .line 171
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 174
    const-string v0, " text="

    .line 176
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 179
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 182
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 185
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 188
    move-result-object v0

    .line 189
    goto :goto_3

    .line 190
    :cond_8
    const-string v0, "[text="

    .line 192
    invoke-static {v0, v3, v8}, Lps;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 195
    move-result-object v0

    .line 196
    :goto_3
    return-object v0
.end method
