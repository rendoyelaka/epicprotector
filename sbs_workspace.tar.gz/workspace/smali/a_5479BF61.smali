.class public final La_5479BF61;
# ep-wciihhoeweov
.super Ljava/lang/Object;
.source "hmvlzvzk.java"
# validated-17270

# interfaces
.implements Loi;


# instance fields
.field public final a:Z


# direct methods
.method public constructor <init>(Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p1, p0, La_5479BF61;->a:Z

    .line 6
    return-void
.end method


# virtual methods
.method public final a(Lfp;)La_CF884759;
    .locals 7

    .line 1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 4
    move-result-wide v0

    .line 5
    iget-object v2, p1, Lfp;->c:Lfh;

    .line 7
    iget-object v3, p1, Lfp;->f:Lnp;

    .line 9
    invoke-interface {v2, v3}, Lfh;->a(Lnp;)V

    .line 12
    iget-object v4, v3, Lnp;->b:Ljava/lang/String;

    .line 14
    invoke-static {v4}, La_F5C4F8D6;->m_63ada39f(Ljava/lang/String;)Z

    .line 17
    move-result v4

    .line 18
    const/4 v5, 0x0

    .line 19
    if-eqz v4, :cond_0

    .line 21
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    :cond_0
    invoke-interface {v2}, Lfh;->b()V

    .line 27
    invoke-interface {v2}, Lfh;->e()La_2954BDC4;

    .line 30
    move-result-object v4

    .line 31
    iput-object v3, v4, La_2954BDC4;->a:Lnp;

    .line 33
    iget-object p1, p1, Lfp;->b:Lft;

    .line 35
    invoke-virtual {p1}, Lft;->a()Lep;

    .line 38
    move-result-object v3

    .line 39
    iget-object v3, v3, Lep;->e:Leg;

    .line 41
    iput-object v3, v4, La_2954BDC4;->e:Leg;

    .line 43
    iput-wide v0, v4, La_2954BDC4;->k:J

    .line 45
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 48
    move-result-wide v0

    .line 49
    iput-wide v0, v4, La_2954BDC4;->l:J

    .line 51
    invoke-virtual {v4}, La_2954BDC4;->a()La_CF884759;

    .line 54
    move-result-object v0

    .line 55
    iget-boolean v1, p0, La_5479BF61;->a:Z

    .line 57
    iget v3, v0, La_CF884759;->e:I

    .line 59
    if-eqz v1, :cond_1

    .line 61
    const/16 v1, 0x65

    .line 63
    if-ne v3, v1, :cond_1

    .line 65
    new-instance v1, La_2954BDC4;

    .line 67
    invoke-direct {v1, v0}, La_2954BDC4;-><init>(La_CF884759;)V

    .line 70
    sget-object v0, Lex;->c:Lcq;

    .line 72
    iput-object v0, v1, La_2954BDC4;->g:Ldq;

    .line 74
    invoke-virtual {v1}, La_2954BDC4;->a()La_CF884759;

    .line 77
    move-result-object v0

    .line 78
    goto :goto_0

    .line 79
    :cond_1
    new-instance v1, La_2954BDC4;

    .line 81
    invoke-direct {v1, v0}, La_2954BDC4;-><init>(La_CF884759;)V

    .line 84
    invoke-interface {v2, v0}, Lfh;->d(La_CF884759;)Lgp;

    .line 87
    move-result-object v0

    .line 88
    iput-object v0, v1, La_2954BDC4;->g:Ldq;

    .line 90
    invoke-virtual {v1}, La_2954BDC4;->a()La_CF884759;

    .line 93
    move-result-object v0

    .line 94
    :goto_0
    iget-object v1, v0, La_CF884759;->c:Lnp;

    .line 96
    const-string v2, "Connection"

    .line 98
    invoke-virtual {v1, v2}, Lnp;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 101
    move-result-object v1

    .line 102
    const-string v4, "close"

    .line 104
    invoke-virtual {v4, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 107
    move-result v1

    .line 108
    if-nez v1, :cond_2

    .line 110
    invoke-virtual {v0, v2}, La_CF884759;->h(Ljava/lang/String;)Ljava/lang/String;

    .line 113
    move-result-object v1

    .line 114
    invoke-virtual {v4, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 117
    move-result v1

    .line 118
    if-eqz v1, :cond_3

    .line 120
    :cond_2
    const/4 v1, 0x1

    .line 121
    invoke-virtual {p1, v1, v5, v5}, Lft;->b(ZZZ)V

    .line 124
    :cond_3
    const/16 p1, 0xcc

    .line 126
    if-eq v3, p1, :cond_4

    .line 128
    const/16 p1, 0xcd

    .line 130
    if-ne v3, p1, :cond_5

    .line 132
    :cond_4
    iget-object p1, v0, La_CF884759;->i:Ldq;

    .line 134
    invoke-virtual {p1}, Ldq;->h()J

    .line 137
    move-result-wide v1

    .line 138
    const-wide/16 v4, 0x0

    .line 140
    cmp-long v6, v1, v4

    .line 142
    if-gtz v6, :cond_6

    .line 144
    :cond_5
    return-object v0

    .line 145
    :cond_6
    new-instance v0, Ljava/net/ProtocolException;

    .line 147
    new-instance v1, Ljava/lang/StringBuilder;

    .line 149
    const-string v2, "HTTP "

    .line 151
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 154
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 157
    const-string v2, " had non-zero Content-Length: "

    .line 159
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 162
    invoke-virtual {p1}, Ldq;->h()J

    .line 165
    move-result-wide v2

    .line 166
    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 169
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 172
    move-result-object p1

    .line 173
    invoke-direct {v0, p1}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 176
    throw v0
.end method
