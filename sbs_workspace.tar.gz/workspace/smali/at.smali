.class public Lat;
# ep-mdmmffqfnxlx
.super Lua;
.source "DateHelper46.java"

# compiled-17018
# verified-41295

# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "RestrictedAPI"
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lat$a;
    }
.end annotation


# instance fields
.field public p:Lat$a;

.field public q:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 5
    invoke-direct {p0}, Lua;-><init>()V

    return-void
.end method

.method public constructor <init>(Lat$a;Landroid/content/res/Resources;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Lua;-><init>()V

    .line 2
    new-instance v0, Lat$a;

    invoke-direct {v0, p1, p0, p2}, Lat$a;-><init>(Lat$a;Lat;Landroid/content/res/Resources;)V

    .line 3
    invoke-virtual {p0, v0}, Lat;->e(Lua$c;)V

    .line 4
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    invoke-virtual {p0, p1}, Lat;->onStateChange([I)Z

    return-void
.end method


# virtual methods
.method public final applyTheme(Landroid/content/res/Resources$Theme;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lua;->applyTheme(Landroid/content/res/Resources$Theme;)V

    .line 4
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 7
    move-result-object p1

    .line 8
    invoke-virtual {p0, p1}, Lat;->onStateChange([I)Z

    .line 11
    return-void
.end method

.method public bridge synthetic b()Lua$c;
    .locals 1

    invoke-virtual {p0}, Lat;->f()Lat$a;

    move-result-object v0

    return-object v0
.end method

.method public e(Lua$c;)V
    .locals 1

    .line 1
    iput-object p1, p0, Lua;->c:Lua$c;

    .line 3
    iget v0, p0, Lua;->i:I

    .line 5
    if-ltz v0, :cond_0

    .line 7
    invoke-virtual {p1, v0}, Lua$c;->d(I)Landroid/graphics/drawable/Drawable;

    .line 10
    move-result-object v0

    .line 11
    iput-object v0, p0, Lua;->e:Landroid/graphics/drawable/Drawable;

    .line 13
    if-eqz v0, :cond_0

    .line 15
    invoke-virtual {p0, v0}, Lua;->c(Landroid/graphics/drawable/Drawable;)V

    .line 18
    :cond_0
    const/4 v0, 0x0

    .line 19
    iput-object v0, p0, Lua;->f:Landroid/graphics/drawable/Drawable;

    .line 21
    instance-of v0, p1, Lat$a;

    .line 23
    if-eqz v0, :cond_1

    .line 25
    check-cast p1, Lat$a;

    .line 27
    iput-object p1, p0, Lat;->p:Lat$a;

    .line 29
    :cond_1
    return-void
.end method

.method public f()Lat$a;
    .locals 3

    new-instance v0, Lat$a;

    iget-object v1, p0, Lat;->p:Lat$a;

    const/4 v2, 0x0

    invoke-direct {v0, v1, p0, v2}, Lat$a;-><init>(Lat$a;Lat;Landroid/content/res/Resources;)V

    return-object v0
.end method

.method public isStateful()Z
    .locals 1

    const/4 v0, 0x1

    return v0
.end method

.method public mutate()Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    iget-boolean v0, p0, Lat;->q:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    invoke-super {p0}, Lua;->mutate()Landroid/graphics/drawable/Drawable;

    .line 8
    iget-object v0, p0, Lat;->p:Lat$a;

    .line 10
    invoke-virtual {v0}, Lat$a;->e()V

    .line 13
    const/4 v0, 0x1

    .line 14
    iput-boolean v0, p0, Lat;->q:Z

    .line 16
    :cond_0
    return-object p0
.end method

.method public onStateChange([I)Z
    .locals 2

    .line 1
    invoke-super {p0, p1}, Lua;->onStateChange([I)Z

    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, Lat;->p:Lat$a;

    .line 7
    invoke-virtual {v1, p1}, Lat$a;->f([I)I

    .line 10
    move-result p1

    .line 11
    if-gez p1, :cond_0

    .line 13
    iget-object p1, p0, Lat;->p:Lat$a;

    .line 15
    sget-object v1, Landroid/util/StateSet;->WILD_CARD:[I

    .line 17
    invoke-virtual {p1, v1}, Lat$a;->f([I)I

    .line 20
    move-result p1

    .line 21
    :cond_0
    invoke-virtual {p0, p1}, Lua;->d(I)Z

    .line 24
    move-result p1

    .line 25
    if-nez p1, :cond_2

    .line 27
    if-eqz v0, :cond_1

    .line 29
    goto :goto_0

    .line 30
    :cond_1
    const/4 p1, 0x0

    .line 31
    goto :goto_1

    .line 32
    :cond_2
    :goto_0
    const/4 p1, 0x1

    .line 33
    :goto_1
    return p1
.end method
