.class public final La_64FE3682;
.super Ljava/lang/Throwable;
.source "lpnjyrfh.java"

# processed-84164
# validated-22924
# optimised-30440

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_CCE46A6D;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    const-string v0, "Failure occurred while trying to finish a future."

    .line 3
    invoke-direct {p0, v0}, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V

    .line 6
    return-void
.end method


# virtual methods
.method public final declared-synchronized fillInStackTrace()Ljava/lang/Throwable;
    # ep-pvbgaggmbeqs
    .locals 0
    # ep-adhupkjupaqj

    # ep-lrrnbkgsedxi
    .line 1
    monitor-enter p0

    .line 2
    monitor-exit p0

    .line 3
    return-object p0
.end method
