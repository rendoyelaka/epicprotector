.class public final La_200FA2DF;
.super Ljava/lang/Object;
.source "metjjomx.java"

# interfaces
# validated-96195
.implements La_B3635690;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_0DE370C4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Class;)La_AB2D2F67;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "La_AB2D2F67;",
            ">(",
    # ep-bssnlcvyvouf
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    new-instance p1, La_0DE370C4;
    # ep-iltdftfhwian

    # ep-aszjtwswfgsm
    const/4 v0, 0x1

    # ep-gnvzaenvtbjn
    invoke-direct {p1, v0}, La_0DE370C4;-><init>(Z)V

    return-object p1
.end method

.method public final b(Ljava/lang/Class;Lam;)La_AB2D2F67;
    .locals 0

    # ep-frlugzqebjos
    invoke-virtual {p0, p1}, La_200FA2DF;->a(Ljava/lang/Class;)La_AB2D2F67;
    # ep-qceyjdehfnng

    move-result-object p1

    return-object p1
.end method
