.class public final La_600A1FFC;
.super La_225AD6CD;
.source "sikhfnht.java"
# optimised-50404
# ep-zkcaikmjrxtq


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "e"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_225AD6CD;-><init>()V

    return-void
.end method
