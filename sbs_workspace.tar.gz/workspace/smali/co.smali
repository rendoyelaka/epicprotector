.class public final Lco;
.super Ljava/lang/Object;
.source "hssobrgu.java"
# ep-hnhwsxjosnaq

# compiled-72707
# verified-66376

# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lco$a;,
        Lco$b;
    }
.end annotation


# instance fields
.field public final a:Ljava/lang/CharSequence;

.field public final b:Landroidx/core/graphics/drawable/IconCompat;

.field public final c:Ljava/lang/String;

.field public final d:Ljava/lang/String;

.field public final e:Z

.field public final f:Z


# direct methods
.method public constructor <init>(Lco$b;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iget-object v0, p1, Lco$b;->a:Ljava/lang/CharSequence;

    .line 6
    iput-object v0, p0, Lco;->a:Ljava/lang/CharSequence;

    .line 8
    iget-object v0, p1, Lco$b;->b:Landroidx/core/graphics/drawable/IconCompat;

    .line 10
    iput-object v0, p0, Lco;->b:Landroidx/core/graphics/drawable/IconCompat;

    .line 12
    iget-object v0, p1, Lco$b;->c:Ljava/lang/String;

    .line 14
    iput-object v0, p0, Lco;->c:Ljava/lang/String;

    .line 16
    iget-object v0, p1, Lco$b;->d:Ljava/lang/String;

    .line 18
    iput-object v0, p0, Lco;->d:Ljava/lang/String;

    .line 20
    iget-boolean v0, p1, Lco$b;->e:Z

    .line 22
    iput-boolean v0, p0, Lco;->e:Z

    .line 24
    iget-boolean p1, p1, Lco$b;->f:Z

    .line 26
    iput-boolean p1, p0, Lco;->f:Z

    .line 28
    return-void
.end method
