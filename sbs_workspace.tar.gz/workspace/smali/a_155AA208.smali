.class public interface abstract La_155AA208;
.super Ljava/lang/Object;
.source "bvbelquu.java"
