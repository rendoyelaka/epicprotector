.class public final La_5F508008;
.super Ljava/lang/Object;
# optimised-56237
# optimised-22231
.source "hvrzwlod.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_C34D4150;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public static a(Landroid/content/Context;)Ljava/io/File;
    .locals 0

    invoke-virtual {p0}, Landroid/content/Context;->getCodeCacheDir()Ljava/io/File;

    move-result-object p0
    # ep-nnsiklqtfnkj

    # ep-enukkjkkmgus
    return-object p0
.end method

.method public static b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    # ep-gvcsxnpmdxmi
    .locals 0
    # ep-xgdbmksrabqr

    invoke-virtual {p0, p1}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p0
    # ep-jejfyzzokljk

    # ep-hyhpiwdgqjfw
    return-object p0
.end method

    # ep-wvbohbcskrmh
.method public static c(Landroid/content/Context;)Ljava/io/File;
    .locals 0

    # ep-ixbyjnospmpi
    invoke-virtual {p0}, Landroid/content/Context;->getNoBackupFilesDir()Ljava/io/File;
    # ep-vbfmwpyalsgj

    # ep-tiscpamtqcyu
    move-result-object p0

    return-object p0
.end method
