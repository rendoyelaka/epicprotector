.class public final La_6FDEC91F;
.super Ljava/lang/Object;
.source "cywlizxd.java"

# interfaces
# processed-54885
# generated-62956
.implements Lny;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lsz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lsz;


# direct methods
.method public constructor <init>(Lsz;)V
    .locals 0

    iput-object p1, p0, La_6FDEC91F;->a:Lsz;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
