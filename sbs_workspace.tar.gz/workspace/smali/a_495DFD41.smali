.class public final La_495DFD41;
.super La_5761B2D0;
.source "cruvvslb.java"
# optimised-42756
# verified-31282
# optimised-97035

# ep-oyesimryedve

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "g"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_5761B2D0;-><init>()V

    return-void
.end method
