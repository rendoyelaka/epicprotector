.class public final La_8A673A7D;
.super Ljava/lang/Object;
# compiled-84524
.source "axzddavn.java"


# instance fields
.field public final a:La_331BBC50;

.field public b:La_331BBC50;

.field public c:La_331BBC50;

.field public d:La_331BBC50;

.field public e:La_331BBC50;

.field public f:La_331BBC50;

.field public g:La_331BBC50;

.field public h:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La_331BBC50;",
            ">;"
        }
    .end annotation
.end field

.field public i:I

.field public j:I

.field public k:F

.field public final l:I

.field public final m:Z

.field public n:Z

.field public o:Z

.field public p:Z

.field public q:Z


# direct methods
.method public constructor <init>(La_331BBC50;IZ)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, La_8A673A7D;->k:F

    .line 7
    const/4 v0, 0x0

    .line 8
    iput-boolean v0, p0, La_8A673A7D;->m:Z

    .line 10
    iput-object p1, p0, La_8A673A7D;->a:La_331BBC50;

    .line 12
    iput p2, p0, La_8A673A7D;->l:I

    .line 14
    iput-boolean p3, p0, La_8A673A7D;->m:Z

    .line 16
    return-void
.end method
