.class public final La_89046FF6;
.super Landroid/graphics/drawable/Animatable2$AnimationCallback;
.source "wzwgmmju.java"
# validated-57882

# ep-nztmkkkftvfd

# instance fields
.field public final synthetic a:La_D9FB09E7;


# direct methods
.method public constructor <init>(La_D9FB09E7;)V
    .locals 0

    iput-object p1, p0, La_89046FF6;->a:La_D9FB09E7;

    invoke-direct {p0}, Landroid/graphics/drawable/Animatable2$AnimationCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    iget-object v0, p0, La_89046FF6;->a:La_D9FB09E7;

    invoke-virtual {v0, p1}, La_D9FB09E7;->a(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public final onAnimationStart(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    iget-object v0, p0, La_89046FF6;->a:La_D9FB09E7;

    invoke-virtual {v0, p1}, La_D9FB09E7;->b(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method
