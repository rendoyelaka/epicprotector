.class public interface abstract La_46FB7064;
.super Ljava/lang/Object;
.source "paywazsq.java"
# processed-12602

# ep-ynqfzgrmbdoj

# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract m_5eaca647(Ljava/lang/Object;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation
.end method
