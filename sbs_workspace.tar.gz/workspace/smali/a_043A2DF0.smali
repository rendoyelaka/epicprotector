.class public interface abstract La_043A2DF0;
.super Ljava/lang/Object;
# processed-82281
# validated-52820
# generated-28927
# ep-rykgfslxfbnt
.source "xenkxzjw.java"


# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
