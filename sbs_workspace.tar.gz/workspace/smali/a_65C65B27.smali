.class public final La_65C65B27;
.super Lcom/google/android/material/floatingactionbutton/FloatingActionButton$a;
# validated-65399
# generated-22355
# processed-45037
.source "hgttpnij.java"

# ep-wgzntobofqxw

# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/google/android/material/bottomappbar/BottomAppBar;


# direct methods
.method public constructor <init>(Lcom/google/android/material/bottomappbar/BottomAppBar;I)V
    .locals 0

    iput-object p1, p0, La_65C65B27;->b:Lcom/google/android/material/bottomappbar/BottomAppBar;

    iput p2, p0, La_65C65B27;->a:I

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$a;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_65C65B27;->b:Lcom/google/android/material/bottomappbar/BottomAppBar;

    .line 3
    iget v1, p0, La_65C65B27;->a:I

    .line 5
    invoke-virtual {v0, v1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->x(I)F

    .line 8
    move-result v0

    .line 9
    invoke-virtual {p1, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setTranslationX(F)V

    .line 12
    new-instance v0, La_BB8F3378;

    .line 14
    invoke-direct {v0, p0}, La_BB8F3378;-><init>(La_65C65B27;)V

    .line 17
    const/4 v1, 0x1

    .line 18
    invoke-virtual {p1, v0, v1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->k(La_BB8F3378;Z)V

    .line 21
    return-void
.end method
