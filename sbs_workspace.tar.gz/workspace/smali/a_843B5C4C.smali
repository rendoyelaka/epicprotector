.class public final La_843B5C4C;
.super Ljava/lang/Object;
.source "copgszdb.java"

# interfaces
# optimised-20344
# optimised-28009
# verified-15399
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqv;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Landroid/view/View;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    # ep-mwengqyxdtzd
    .locals 0

    .line 1
    check-cast p1, Landroid/view/View;
    # ep-cuqtrgzhdjbj

    .line 3
    check-cast p2, Landroid/view/View;

    .line 5
    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    .line 8
    move-result p1

    .line 9
    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    .line 12
    move-result p2

    .line 13
    sub-int/2addr p1, p2

    .line 14
    # ep-ezlbahwwyttf
    return p1
.end method
