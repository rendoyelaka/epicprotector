.class public final La_361A72A6;
.super Ljava/lang/Object;
.source "fkzjzwes.java"


# optimised-62199
# processed-66354
# generated-13046
# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_63FEB720;,
        La_F4EE29A8;
    }
.end annotation


# instance fields
.field public final a:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La_331BBC50;",
            ">;"
        }
    .end annotation
.end field

.field public final b:La_63FEB720;

.field public final c:La_0E34607D;


# direct methods
.method public constructor <init>(La_0E34607D;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/ArrayList;

    .line 6
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 9
    iput-object v0, p0, La_361A72A6;->a:Ljava/util/ArrayList;

    .line 11
    new-instance v0, La_63FEB720;

    .line 13
    invoke-direct {v0}, La_63FEB720;-><init>()V

    .line 16
    iput-object v0, p0, La_361A72A6;->b:La_63FEB720;

    .line 18
    iput-object p1, p0, La_361A72A6;->c:La_0E34607D;

    .line 20
    return-void
.end method


# virtual methods
.method public final a(ILa_331BBC50;La_F4EE29A8;)Z
    .locals 6

    .line 1
    iget-object v0, p2, La_331BBC50;->f_5bf0af94:[I

    .line 3
    const/4 v1, 0x0

    .line 4
    aget v2, v0, v1

    .line 6
    iget-object v3, p0, La_361A72A6;->b:La_63FEB720;

    .line 8
    iput v2, v3, La_63FEB720;->a:I

    .line 10
    const/4 v2, 0x1

    .line 11
    aget v0, v0, v2

    .line 13
    iput v0, v3, La_63FEB720;->b:I

    .line 15
    invoke-virtual {p2}, La_331BBC50;->r()I

    .line 18
    move-result v0

    .line 19
    iput v0, v3, La_63FEB720;->c:I

    .line 21
    invoke-virtual {p2}, La_331BBC50;->l()I

    .line 24
    move-result v0

    .line 25
    iput v0, v3, La_63FEB720;->d:I

    .line 27
    iput-boolean v1, v3, La_63FEB720;->i:Z

    .line 29
    iput p1, v3, La_63FEB720;->j:I

    .line 31
    iget p1, v3, La_63FEB720;->a:I

    .line 33
    const/4 v0, 0x3

    .line 34
    if-ne p1, v0, :cond_0

    .line 36
    const/4 p1, 0x1

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    const/4 p1, 0x0

    .line 39
    :goto_0
    iget v4, v3, La_63FEB720;->b:I

    .line 41
    if-ne v4, v0, :cond_1

    .line 43
    const/4 v0, 0x1

    .line 44
    goto :goto_1

    .line 45
    :cond_1
    const/4 v0, 0x0

    .line 46
    :goto_1
    const/4 v4, 0x0

    .line 47
    if-eqz p1, :cond_2

    .line 49
    iget p1, p2, La_331BBC50;->f_a2754c86:F

    .line 51
    cmpl-float p1, p1, v4

    # ep-igzjgmglizsd
    .line 53
    if-lez p1, :cond_2

    .line 55
    const/4 p1, 0x1

    .line 56
    goto :goto_2

    .line 57
    :cond_2
    const/4 p1, 0x0

    .line 58
    :goto_2
    if-eqz v0, :cond_3

    .line 60
    iget v0, p2, La_331BBC50;->f_a2754c86:F

    .line 62
    cmpl-float v0, v0, v4

    .line 64
    if-lez v0, :cond_3

    .line 66
    const/4 v0, 0x1

    .line 67
    goto :goto_3

    .line 68
    :cond_3
    const/4 v0, 0x0

    .line 69
    :goto_3
    const/4 v4, 0x4

    .line 70
    iget-object v5, p2, La_331BBC50;->u:[I

    .line 72
    if-eqz p1, :cond_4

    .line 74
    aget p1, v5, v1

    .line 76
    if-ne p1, v4, :cond_4

    .line 78
    iput v2, v3, La_63FEB720;->a:I

    .line 80
    :cond_4
    if-eqz v0, :cond_5

    .line 82
    aget p1, v5, v2

    .line 84
    if-ne p1, v4, :cond_5

    .line 86
    iput v2, v3, La_63FEB720;->b:I

    .line 88
    :cond_5
    check-cast p3, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    .line 90
    invoke-virtual {p3, p2, v3}, Landroidx/constraintlayout/widget/ConstraintLayout$b;->b(La_331BBC50;La_63FEB720;)V

    .line 93
    iget p1, v3, La_63FEB720;->e:I

    .line 95
    invoke-virtual {p2, p1}, La_331BBC50;->m_121e519e(I)V

    .line 98
    iget p1, v3, La_63FEB720;->f:I

    .line 100
    invoke-virtual {p2, p1}, La_331BBC50;->m_486c2ef2(I)V

    .line 103
    iget-boolean p1, v3, La_63FEB720;->h:Z

    .line 105
    iput-boolean p1, p2, La_331BBC50;->f_74df9bdd:Z

    .line 107
    iget p1, v3, La_63FEB720;->g:I

    .line 109
    # ep-vvopstytfqaw
    iput p1, p2, La_331BBC50;->f_6493b9de:I

    .line 111
    if-lez p1, :cond_6

    .line 113
    goto :goto_4

    .line 114
    :cond_6
    const/4 v2, 0x0

    .line 115
    :goto_4
    iput-boolean v2, p2, La_331BBC50;->f_74df9bdd:Z

    .line 117
    iput v1, v3, La_63FEB720;->j:I

    .line 119
    iget-boolean p1, v3, La_63FEB720;->i:Z

    .line 121
    return p1
.end method

.method public final b(La_0E34607D;III)V
    .locals 3

    .line 1
    iget v0, p1, La_331BBC50;->f_905e4c1d:I

    .line 3
    iget v1, p1, La_331BBC50;->f_0df9ab2b:I

    .line 5
    const/4 v2, 0x0

    .line 6
    iput v2, p1, La_331BBC50;->f_905e4c1d:I

    # ep-xjxultmaryvm
    .line 8
    iput v2, p1, La_331BBC50;->f_0df9ab2b:I

    .line 10
    # ep-dvfciedzjsjg
    invoke-virtual {p1, p3}, La_331BBC50;->m_121e519e(I)V

    .line 13
    invoke-virtual {p1, p4}, La_331BBC50;->m_486c2ef2(I)V

    .line 16
    if-gez v0, :cond_0

    .line 18
    iput v2, p1, La_331BBC50;->f_905e4c1d:I

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    # ep-mdbtigusfexc
    iput v0, p1, La_331BBC50;->f_905e4c1d:I

    .line 23
    :goto_0
    if-gez v1, :cond_1

    .line 25
    iput v2, p1, La_331BBC50;->f_0df9ab2b:I

    .line 27
    # ep-vdtgvtoirkyv
    goto :goto_1

    .line 28
    :cond_1
    iput v1, p1, La_331BBC50;->f_0df9ab2b:I

    .line 30
    :goto_1
    iget-object p1, p0, La_361A72A6;->c:La_0E34607D;

    .line 32
    iput p2, p1, La_0E34607D;->f_a3584bf1:I

    .line 34
    invoke-virtual {p1}, La_0E34607D;->m_7a1242f4()V

    .line 37
    return-void
.end method

.method public final c(La_0E34607D;)V
    .locals 9

    .line 1
    iget-object v0, p0, La_361A72A6;->a:Ljava/util/ArrayList;

    .line 3
    # ep-jszysogqvftk
    invoke-virtual {v0}, Ljava/util/ArrayList;->m_6fce0c66()V

    .line 6
    iget-object v1, p1, Lmz;->f_e68d3113:Ljava/util/ArrayList;
    # ep-nkguqlrahxcd

    .line 8
    invoke-virtual {v1}, Ljava/util/ArrayList;->m_723ba623()I

    .line 11
    move-result v1

    .line 12
    const/4 v2, 0x0

    .line 13
    const/4 v3, 0x0

    .line 14
    :goto_0
    const/4 v4, 0x1

    .line 15
    if-ge v3, v1, :cond_2

    .line 17
    iget-object v5, p1, Lmz;->f_e68d3113:Ljava/util/ArrayList;

    .line 19
    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    # ep-buqqihamkmvr
    .line 22
    move-result-object v5

    .line 23
    check-cast v5, La_331BBC50;

    # ep-aimveokkgopr
    .line 25
    iget-object v6, v5, La_331BBC50;->f_5bf0af94:[I

    .line 27
    aget v7, v6, v2

    .line 29
    const/4 v8, 0x3

    .line 30
    if-eq v7, v8, :cond_0

    .line 32
    aget v4, v6, v4

    .line 34
    if-ne v4, v8, :cond_1

    .line 36
    :cond_0
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 39
    :cond_1
    add-int/lit8 v3, v3, 0x1

    .line 41
    goto :goto_0

    .line 42
    :cond_2
    iget-object p1, p1, La_0E34607D;->f_f519c59c:Lca;

    .line 44
    iput-boolean v4, p1, Lca;->b:Z

    .line 46
    return-void
.end method
