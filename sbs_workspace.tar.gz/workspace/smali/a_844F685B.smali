.class public final La_844F685B;
.super Lcs;
.source "lmyavymf.java"


# optimised-11361
# verified-76864
# verified-17647
# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_B6D404DB;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1
    # ep-yyclghraygjf

    const-string v0, "UPDATE workspec SET schedule_requested_at=? WHERE id=?"
    # ep-anyonulqwsmd

    # ep-qptduryrzcjo
    return-object v0
.end method
