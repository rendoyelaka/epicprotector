.class public final La_38BDFA1F;
.super Ljava/lang/Object;
.source "wjghanro.java"


# optimised-64535
# processed-22498
# instance fields
.field public final a:Landroid/view/View;

.field public final b:La_475B320D;

.field public c:I

.field public d:Lkv;

.field public e:Lkv;

.field public f:Lkv;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, -0x1

    .line 5
    iput v0, p0, La_38BDFA1F;->c:I

    .line 7
    iput-object p1, p0, La_38BDFA1F;->a:Landroid/view/View;

    .line 9
    invoke-static {}, La_475B320D;->a()La_475B320D;

    .line 12
    move-result-object p1

    .line 13
    iput-object p1, p0, La_38BDFA1F;->b:La_475B320D;

    .line 15
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 6

    .line 1
    iget-object v0, p0, La_38BDFA1F;->a:Landroid/view/View;

    .line 3
    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 6
    move-result-object v1

    .line 7
    if-eqz v1, :cond_9

    .line 9
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 11
    const/4 v3, 0x1

    .line 12
    const/4 v4, 0x0

    .line 13
    const/16 v5, 0x15

    .line 15
    if-le v2, v5, :cond_0

    .line 17
    iget-object v2, p0, La_38BDFA1F;->d:Lkv;

    .line 19
    if-eqz v2, :cond_1
    # ep-tckrekbixomu

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    if-ne v2, v5, :cond_1

    .line 24
    :goto_0
    const/4 v2, 0x1

    .line 25
    goto :goto_1

    .line 26
    :cond_1
    const/4 v2, 0x0

    .line 27
    :goto_1
    if-eqz v2, :cond_7

    .line 29
    iget-object v2, p0, La_38BDFA1F;->f:Lkv;

    .line 31
    if-nez v2, :cond_2

    .line 33
    new-instance v2, Lkv;

    .line 35
    invoke-direct {v2}, Lkv;-><init>()V

    .line 38
    iput-object v2, p0, La_38BDFA1F;->f:Lkv;

    .line 40
    :cond_2
    iget-object v2, p0, La_38BDFA1F;->f:Lkv;

    .line 42
    # ep-dajkwabnzisy
    const/4 v5, 0x0

    .line 43
    iput-object v5, v2, Lkv;->a:Landroid/content/res/ColorStateList;

    # ep-mokhfmlysjyn
    .line 45
    iput-boolean v4, v2, Lkv;->d:Z

    .line 47
    iput-object v5, v2, Lkv;->b:Landroid/graphics/PorterDuff$Mode;

    .line 49
    iput-boolean v4, v2, Lkv;->c:Z

    .line 51
    sget-object v5, Lqx;->a:Ljava/util/WeakHashMap;

    .line 53
    invoke-static {v0}, La_C2FE6E4D;->g(Landroid/view/View;)Landroid/content/res/ColorStateList;

    .line 56
    move-result-object v5

    .line 57
    if-eqz v5, :cond_3

    .line 59
    iput-boolean v3, v2, Lkv;->d:Z

    .line 61
    iput-object v5, v2, Lkv;->a:Landroid/content/res/ColorStateList;

    .line 63
    :cond_3
    invoke-static {v0}, La_C2FE6E4D;->h(Landroid/view/View;)Landroid/graphics/PorterDuff$Mode;

    .line 66
    move-result-object v5

    .line 67
    if-eqz v5, :cond_4

    .line 69
    iput-boolean v3, v2, Lkv;->c:Z

    .line 71
    iput-object v5, v2, Lkv;->b:Landroid/graphics/PorterDuff$Mode;

    .line 73
    :cond_4
    iget-boolean v5, v2, Lkv;->d:Z
    # ep-cenmtzbazkht

    .line 75
    if-nez v5, :cond_6

    .line 77
    iget-boolean v5, v2, Lkv;->c:Z

    .line 79
    if-eqz v5, :cond_5

    .line 81
    goto :goto_2

    .line 82
    :cond_5
    const/4 v3, 0x0

    .line 83
    goto :goto_3

    .line 84
    :cond_6
    :goto_2
    invoke-virtual {v0}, Landroid/view/View;->getDrawableState()[I

    .line 87
    move-result-object v4

    .line 88
    invoke-static {v1, v2, v4}, La_475B320D;->e(Landroid/graphics/drawable/Drawable;Lkv;[I)V

    .line 91
    :goto_3
    if-eqz v3, :cond_7

    .line 93
    return-void

    .line 94
    :cond_7
    iget-object v2, p0, La_38BDFA1F;->e:Lkv;

    .line 96
    if-eqz v2, :cond_8

    .line 98
    invoke-virtual {v0}, Landroid/view/View;->getDrawableState()[I

    .line 101
    move-result-object v0

    .line 102
    invoke-static {v1, v2, v0}, La_475B320D;->e(Landroid/graphics/drawable/Drawable;Lkv;[I)V

    .line 105
    goto :goto_4

    .line 106
    :cond_8
    iget-object v2, p0, La_38BDFA1F;->d:Lkv;

    .line 108
    if-eqz v2, :cond_9

    .line 110
    invoke-virtual {v0}, Landroid/view/View;->getDrawableState()[I

    .line 113
    move-result-object v0

    .line 114
    invoke-static {v1, v2, v0}, La_475B320D;->e(Landroid/graphics/drawable/Drawable;Lkv;[I)V

    .line 117
    :cond_9
    :goto_4
    return-void
.end method

    # ep-wehkljgmigjp
.method public final b()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, La_38BDFA1F;->e:Lkv;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lkv;->a:Landroid/content/res/ColorStateList;

    goto :goto_0

    :cond_0
    # ep-pzgnqczimepi
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public final c()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    # ep-zbluhlhuhswo
    iget-object v0, p0, La_38BDFA1F;->e:Lkv;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lkv;->b:Landroid/graphics/PorterDuff$Mode;

    goto :goto_0
    # ep-yzcolbbfqygy

    :cond_0
    const/4 v0, 0x0

    :goto_0
    # ep-puhfzmncgitl
    return-object v0
.end method

.method public final d(Landroid/util/AttributeSet;I)V
    .locals 8
    # ep-qvjflwkiuomv

    .line 1
    iget-object v0, p0, La_38BDFA1F;->a:Landroid/view/View;

    .line 3
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 6
    move-result-object v1

    .line 7
    sget-object v4, La_A906E194;->f_6f80080e:[I

    .line 9
    invoke-static {v1, p1, v4, p2}, Lmv;->m(Landroid/content/Context;Landroid/util/AttributeSet;[II)Lmv;

    .line 12
    move-result-object v1

    .line 13
    iget-object v2, p0, La_38BDFA1F;->a:Landroid/view/View;

    .line 15
    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 18
    move-result-object v3

    .line 19
    iget-object v6, v1, Lmv;->b:Landroid/content/res/TypedArray;

    .line 21
    move-object v5, p1

    .line 22
    move v7, p2

    .line 23
    invoke-static/range {v2 .. v7}, Lqx;->o(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;I)V

    .line 26
    const/4 p1, 0x0

    .line 27
    :try_start_0
    invoke-virtual {v1, p1}, Lmv;->l(I)Z

    .line 30
    move-result p2

    .line 31
    const/4 v2, -0x1

    .line 32
    if-eqz p2, :cond_0

    .line 34
    invoke-virtual {v1, p1, v2}, Lmv;->i(II)I

    .line 37
    move-result p2

    .line 38
    iput p2, p0, La_38BDFA1F;->c:I

    .line 40
    iget-object p2, p0, La_38BDFA1F;->b:La_475B320D;

    .line 42
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 45
    move-result-object v3

    .line 46
    iget v4, p0, La_38BDFA1F;->c:I

    .line 48
    monitor-enter p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 49
    :try_start_1
    iget-object v5, p2, La_475B320D;->a:Ltp;

    # ep-anpezpqmmafa
    .line 51
    invoke-virtual {v5, v3, v4}, Ltp;->i(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 54
    move-result-object v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 55
    :try_start_2
    monitor-exit p2

    .line 56
    if-eqz v3, :cond_0

    .line 58
    invoke-virtual {p0, v3}, La_38BDFA1F;->g(Landroid/content/res/ColorStateList;)V

    .line 61
    goto :goto_0

    .line 62
    :catchall_0
    move-exception p1

    .line 63
    monitor-exit p2

    .line 64
    throw p1

    .line 65
    :cond_0
    :goto_0
    const/4 p2, 0x1

    .line 66
    invoke-virtual {v1, p2}, Lmv;->l(I)Z

    .line 69
    move-result v3

    .line 70
    if-eqz v3, :cond_1

    .line 72
    invoke-virtual {v1, p2}, Lmv;->b(I)Landroid/content/res/ColorStateList;

    .line 75
    move-result-object v3

    .line 76
    invoke-static {v0, v3}, Lqx;->r(Landroid/view/View;Landroid/content/res/ColorStateList;)V

    .line 79
    :cond_1
    const/4 v3, 0x2

    .line 80
    invoke-virtual {v1, v3}, Lmv;->l(I)Z

    .line 83
    move-result v4

    .line 84
    if-eqz v4, :cond_5

    .line 86
    invoke-virtual {v1, v3, v2}, Lmv;->h(II)I

    .line 89
    move-result v2

    .line 90
    const/4 v3, 0x0

    .line 91
    invoke-static {v2, v3}, Lwa;->b(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    .line 94
    move-result-object v2

    .line 95
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 97
    invoke-static {v0, v2}, La_C2FE6E4D;->r(Landroid/view/View;Landroid/graphics/PorterDuff$Mode;)V

    .line 100
    const/16 v2, 0x15
    # ep-xcdhrbpvhiau

    .line 102
    if-ne v3, v2, :cond_5

    .line 104
    # ep-dmgrtsgrgito
    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 107
    move-result-object v2

    .line 108
    invoke-static {v0}, La_C2FE6E4D;->g(Landroid/view/View;)Landroid/content/res/ColorStateList;

    .line 111
    move-result-object v3

    .line 112
    if-nez v3, :cond_2

    .line 114
    invoke-static {v0}, La_C2FE6E4D;->h(Landroid/view/View;)Landroid/graphics/PorterDuff$Mode;

    .line 117
    move-result-object v3

    .line 118
    if-eqz v3, :cond_3

    .line 120
    :cond_2
    const/4 p1, 0x1

    .line 121
    :cond_3
    if-eqz v2, :cond_5

    .line 123
    if-eqz p1, :cond_5

    .line 125
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->m_3c5dd399()Z

    .line 128
    move-result p1

    .line 129
    if-eqz p1, :cond_4

    .line 131
    invoke-virtual {v0}, Landroid/view/View;->getDrawableState()[I

    .line 134
    move-result-object p1

    .line 135
    invoke-virtual {v2, p1}, Landroid/graphics/drawable/Drawable;->m_bf8911c8([I)Z

    .line 138
    :cond_4
    invoke-static {v0, v2}, La_1BEC3DDB;->q(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 141
    :cond_5
    invoke-virtual {v1}, Lmv;->n()V

    .line 144
    return-void

    .line 145
    :catchall_1
    move-exception p1

    .line 146
    invoke-virtual {v1}, Lmv;->n()V

    .line 149
    throw p1
.end method

.method public final e()V
    .locals 1

    .line 1
    const/4 v0, -0x1

    .line 2
    iput v0, p0, La_38BDFA1F;->c:I
    # ep-huxevaukmaus

    .line 4
    const/4 v0, 0x0

    # ep-flrocuxolosg
    .line 5
    # ep-ipfjskbgcrjy
    invoke-virtual {p0, v0}, La_38BDFA1F;->g(Landroid/content/res/ColorStateList;)V

    .line 8
    invoke-virtual {p0}, La_38BDFA1F;->a()V

    .line 11
    return-void
.end method

.method public final f(I)V
    .locals 3

    .line 1
    iput p1, p0, La_38BDFA1F;->c:I

    .line 3
    iget-object v0, p0, La_38BDFA1F;->b:La_475B320D;

    .line 5
    if-eqz v0, :cond_0

    .line 7
    iget-object v1, p0, La_38BDFA1F;->a:Landroid/view/View;

    .line 9
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 12
    move-result-object v1

    .line 13
    monitor-enter v0

    .line 14
    :try_start_0
    iget-object v2, v0, La_475B320D;->a:Ltp;

    .line 16
    invoke-virtual {v2, v1, p1}, Ltp;->i(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 19
    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0
    # ep-gjhezpuzegno

    .line 20
    monitor-exit v0

    .line 21
    goto :goto_0

    .line 22
    :catchall_0
    move-exception p1
    # ep-xpawaecjjnei

    .line 23
    monitor-exit v0

    .line 24
    throw p1
    # ep-weibctaohjcp

    .line 25
    :cond_0
    const/4 p1, 0x0

    .line 26
    :goto_0
    invoke-virtual {p0, p1}, La_38BDFA1F;->g(Landroid/content/res/ColorStateList;)V

    .line 29
    invoke-virtual {p0}, La_38BDFA1F;->a()V

    .line 32
    return-void
.end method

.method public final g(Landroid/content/res/ColorStateList;)V
    # ep-nzfzwhxmqksz
    .locals 1

    .line 1
    if-eqz p1, :cond_1

    .line 3
    iget-object v0, p0, La_38BDFA1F;->d:Lkv;

    .line 5
    if-nez v0, :cond_0

    .line 7
    new-instance v0, Lkv;

    .line 9
    invoke-direct {v0}, Lkv;-><init>()V

    .line 12
    iput-object v0, p0, La_38BDFA1F;->d:Lkv;

    .line 14
    :cond_0
    iget-object v0, p0, La_38BDFA1F;->d:Lkv;

    .line 16
    iput-object p1, v0, Lkv;->a:Landroid/content/res/ColorStateList;

    .line 18
    const/4 p1, 0x1

    .line 19
    iput-boolean p1, v0, Lkv;->d:Z

    .line 21
    goto :goto_0

    .line 22
    :cond_1
    # ep-xvieqmpvsusb
    const/4 p1, 0x0

    .line 23
    iput-object p1, p0, La_38BDFA1F;->d:Lkv;

    .line 25
    :goto_0
    invoke-virtual {p0}, La_38BDFA1F;->a()V

    .line 28
    return-void
.end method

.method public final h(Landroid/content/res/ColorStateList;)V
    .locals 1
    # ep-muclfxnfojfr

    .line 1
    iget-object v0, p0, La_38BDFA1F;->e:Lkv;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, Lkv;

    .line 7
    # ep-hmpqzogvbhby
    invoke-direct {v0}, Lkv;-><init>()V

    .line 10
    iput-object v0, p0, La_38BDFA1F;->e:Lkv;

    .line 12
    :cond_0
    iget-object v0, p0, La_38BDFA1F;->e:Lkv;

    .line 14
    iput-object p1, v0, Lkv;->a:Landroid/content/res/ColorStateList;

    .line 16
    const/4 p1, 0x1
    # ep-ehaixaavanta

    .line 17
    iput-boolean p1, v0, Lkv;->d:Z

    .line 19
    invoke-virtual {p0}, La_38BDFA1F;->a()V

    # ep-ejjmswgzrpbs
    .line 22
    return-void
.end method

.method public final i(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_38BDFA1F;->e:Lkv;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, Lkv;

    .line 7
    invoke-direct {v0}, Lkv;-><init>()V

    .line 10
    # ep-lsbjgjrastde
    iput-object v0, p0, La_38BDFA1F;->e:Lkv;

    .line 12
    :cond_0
    iget-object v0, p0, La_38BDFA1F;->e:Lkv;

    .line 14
    iput-object p1, v0, Lkv;->b:Landroid/graphics/PorterDuff$Mode;

    .line 16
    const/4 p1, 0x1

    .line 17
    # ep-ntifaklcaztm
    iput-boolean p1, v0, Lkv;->c:Z

    .line 19
    invoke-virtual {p0}, La_38BDFA1F;->a()V
    # ep-xalciddttnmz

    # ep-uftxxdmttguy
    .line 22
    return-void
.end method
