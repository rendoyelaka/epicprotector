.class public final La_8585CAB2;
.super Landroid/animation/AnimatorListenerAdapter;
.source "gscdjnzl.java"

# optimised-36059
# generated-47133
# compiled-78547
# ep-uxuhyhbqqtlb

# instance fields
.field public final synthetic a:La_814939E8;


# direct methods
.method public constructor <init>(La_814939E8;)V
    .locals 0

    iput-object p1, p0, La_8585CAB2;->a:La_814939E8;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 1

    iget-object p1, p0, La_8585CAB2;->a:La_814939E8;

    iget-object p1, p1, Lcc;->b:Lcom/google/android/material/textfield/a;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lcom/google/android/material/textfield/a;->g(Z)V

    return-void
.end method
