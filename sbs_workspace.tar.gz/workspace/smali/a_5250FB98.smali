.class public final La_5250FB98;
.super Ljava/lang/Object;
# ep-zbxtwhjfeaud
.source "lilziooz.java"
# generated-92325
# optimised-45482


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lan;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final a:La_288A4D2F;

.field public b:Ljava/net/Proxy;

.field public c:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lvo;",
            ">;"
        }
    .end annotation
.end field

.field public final d:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "La_D3507BAE;",
            ">;"
        }
    .end annotation
.end field

.field public final e:Ljava/util/ArrayList;

.field public final f:Ljava/util/ArrayList;

.field public final g:Ljava/net/ProxySelector;

.field public final h:La_AC88DDE5;

.field public final i:Ljavax/net/SocketFactory;

.field public j:Ljavax/net/ssl/SSLSocketFactory;

.field public k:La_07EFADCD;

.field public l:Ljavax/net/ssl/HostnameVerifier;

.field public final m:La_61B1C423;

.field public n:La_119635E9;

.field public final o:La_119635E9;

.field public final p:La_B93A0AB8;

.field public final q:Lra;

.field public final r:Z

.field public final s:Z

.field public final t:Z

.field public u:I

.field public v:I

.field public w:I

.field public final x:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La_5250FB98;->e:Ljava/util/ArrayList;

    .line 3
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La_5250FB98;->f:Ljava/util/ArrayList;

    .line 4
    new-instance v0, La_288A4D2F;

    invoke-direct {v0}, La_288A4D2F;-><init>()V

    iput-object v0, p0, La_5250FB98;->a:La_288A4D2F;

    .line 5
    sget-object v0, Lan;->f_818db6a8:Ljava/util/List;

    iput-object v0, p0, La_5250FB98;->c:Ljava/util/List;

    .line 6
    sget-object v0, Lan;->f_ed000f9c:Ljava/util/List;

    iput-object v0, p0, La_5250FB98;->d:Ljava/util/List;

    .line 7
    invoke-static {}, Ljava/net/ProxySelector;->getDefault()Ljava/net/ProxySelector;

    move-result-object v0

    iput-object v0, p0, La_5250FB98;->g:Ljava/net/ProxySelector;

    .line 8
    sget-object v0, La_AC88DDE5;->a:La_14CC034B;

    iput-object v0, p0, La_5250FB98;->h:La_AC88DDE5;

    .line 9
    invoke-static {}, Ljavax/net/SocketFactory;->getDefault()Ljavax/net/SocketFactory;

    move-result-object v0

    iput-object v0, p0, La_5250FB98;->i:Ljavax/net/SocketFactory;

    .line 10
    sget-object v0, Lzm;->a:Lzm;

    iput-object v0, p0, La_5250FB98;->l:Ljavax/net/ssl/HostnameVerifier;

    .line 11
    sget-object v0, La_61B1C423;->c:La_61B1C423;

    iput-object v0, p0, La_5250FB98;->m:La_61B1C423;

    .line 12
    sget-object v0, La_119635E9;->a:La_46205769;

    iput-object v0, p0, La_5250FB98;->n:La_119635E9;

    .line 13
    iput-object v0, p0, La_5250FB98;->o:La_119635E9;

    .line 14
    new-instance v0, La_B93A0AB8;

    invoke-direct {v0}, La_B93A0AB8;-><init>()V

    iput-object v0, p0, La_5250FB98;->p:La_B93A0AB8;

    .line 15
    sget-object v0, Lra;->a:La_C068C307;

    iput-object v0, p0, La_5250FB98;->q:Lra;

    const/4 v0, 0x1

    .line 16
    iput-boolean v0, p0, La_5250FB98;->r:Z

    .line 17
    iput-boolean v0, p0, La_5250FB98;->s:Z

    .line 18
    iput-boolean v0, p0, La_5250FB98;->t:Z

    const/16 v0, 0x2710

    .line 19
    iput v0, p0, La_5250FB98;->u:I

    .line 20
    iput v0, p0, La_5250FB98;->v:I

    .line 21
    iput v0, p0, La_5250FB98;->w:I

    const/4 v0, 0x0

    .line 22
    iput v0, p0, La_5250FB98;->x:I

    return-void
.end method

.method public constructor <init>(Lan;)V
    .locals 3

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La_5250FB98;->e:Ljava/util/ArrayList;

    .line 25
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La_5250FB98;->f:Ljava/util/ArrayList;

    .line 26
    iget-object v2, p1, Lan;->c:La_288A4D2F;

    iput-object v2, p0, La_5250FB98;->a:La_288A4D2F;

    .line 27
    iget-object v2, p1, Lan;->d:Ljava/net/Proxy;

    iput-object v2, p0, La_5250FB98;->b:Ljava/net/Proxy;

    .line 28
    iget-object v2, p1, Lan;->e:Ljava/util/List;

    iput-object v2, p0, La_5250FB98;->c:Ljava/util/List;

    .line 29
    iget-object v2, p1, Lan;->f:Ljava/util/List;

    iput-object v2, p0, La_5250FB98;->d:Ljava/util/List;

    .line 30
    iget-object v2, p1, Lan;->g:Ljava/util/List;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->m_4d6c5476(Ljava/util/Collection;)Z

    .line 31
    iget-object v0, p1, Lan;->h:Ljava/util/List;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->m_4d6c5476(Ljava/util/Collection;)Z

    .line 32
    iget-object v0, p1, Lan;->i:Ljava/net/ProxySelector;

    iput-object v0, p0, La_5250FB98;->g:Ljava/net/ProxySelector;

    .line 33
    iget-object v0, p1, Lan;->j:La_AC88DDE5;

    iput-object v0, p0, La_5250FB98;->h:La_AC88DDE5;

    .line 34
    iget-object v0, p1, Lan;->k:Ljavax/net/SocketFactory;

    iput-object v0, p0, La_5250FB98;->i:Ljavax/net/SocketFactory;

    .line 35
    iget-object v0, p1, Lan;->l:Ljavax/net/ssl/SSLSocketFactory;

    iput-object v0, p0, La_5250FB98;->j:Ljavax/net/ssl/SSLSocketFactory;

    .line 36
    iget-object v0, p1, Lan;->m:La_07EFADCD;

    iput-object v0, p0, La_5250FB98;->k:La_07EFADCD;

    .line 37
    iget-object v0, p1, Lan;->n:Ljavax/net/ssl/HostnameVerifier;

    iput-object v0, p0, La_5250FB98;->l:Ljavax/net/ssl/HostnameVerifier;

    .line 38
    iget-object v0, p1, Lan;->o:La_61B1C423;

    iput-object v0, p0, La_5250FB98;->m:La_61B1C423;

    .line 39
    iget-object v0, p1, Lan;->p:La_119635E9;

    iput-object v0, p0, La_5250FB98;->n:La_119635E9;

    .line 40
    iget-object v0, p1, Lan;->q:La_119635E9;

    iput-object v0, p0, La_5250FB98;->o:La_119635E9;

    .line 41
    iget-object v0, p1, Lan;->r:La_B93A0AB8;

    iput-object v0, p0, La_5250FB98;->p:La_B93A0AB8;

    .line 42
    iget-object v0, p1, Lan;->s:Lra;

    iput-object v0, p0, La_5250FB98;->q:Lra;

    .line 43
    iget-boolean v0, p1, Lan;->t:Z

    iput-boolean v0, p0, La_5250FB98;->r:Z

    .line 44
    iget-boolean v0, p1, Lan;->u:Z

    iput-boolean v0, p0, La_5250FB98;->s:Z

    .line 45
    iget-boolean v0, p1, Lan;->v:Z

    iput-boolean v0, p0, La_5250FB98;->t:Z

    .line 46
    iget v0, p1, Lan;->w:I

    iput v0, p0, La_5250FB98;->u:I

    .line 47
    iget v0, p1, Lan;->x:I

    iput v0, p0, La_5250FB98;->v:I

    .line 48
    iget v0, p1, Lan;->y:I

    iput v0, p0, La_5250FB98;->w:I

    .line 49
    iget p1, p1, Lan;->z:I

    iput p1, p0, La_5250FB98;->x:I

    return-void
.end method

.method public static a(Ljava/util/concurrent/TimeUnit;)I
    .locals 4

    .line 1
    if-eqz p0, :cond_1

    .line 3
    const-wide/16 v0, 0x0

    .line 5
    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 8
    move-result-wide v0

    .line 9
    const-wide/32 v2, 0x7fffffff

    .line 12
    cmp-long p0, v0, v2

    .line 14
    if-gtz p0, :cond_0

    .line 16
    long-to-int p0, v0

    .line 17
    return p0

    .line 18
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 20
    const-string v0, "timeout too large."

    .line 22
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 25
    throw p0

    .line 26
    :cond_1
    new-instance p0, Ljava/lang/NullPointerException;

    .line 28
    const-string v0, "unit == null"

    .line 30
    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 33
    throw p0
.end method
