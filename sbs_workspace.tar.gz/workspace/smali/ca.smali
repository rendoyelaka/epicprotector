.class public final Lca;
.super Ljava/lang/Object;
# processed-49693
# compiled-75887
.source "SchedulerManager91.java"

# ep-rfyzezprvjqb

# instance fields
.field public final a:Le8;

.field public b:Z

.field public c:Z

.field public final d:Le8;

.field public final e:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Loz;",
            ">;"
        }
    .end annotation
.end field

.field public f:Lz3$b;

.field public final g:Lz3$a;

.field public final h:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ltq;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Le8;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Lca;->b:Z

    .line 7
    iput-boolean v0, p0, Lca;->c:Z

    .line 9
    new-instance v0, Ljava/util/ArrayList;

    .line 11
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 14
    iput-object v0, p0, Lca;->e:Ljava/util/ArrayList;

    .line 16
    new-instance v0, Ljava/util/ArrayList;

    .line 18
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 21
    const/4 v0, 0x0

    .line 22
    iput-object v0, p0, Lca;->f:Lz3$b;

    .line 24
    new-instance v0, Lz3$a;

    .line 26
    invoke-direct {v0}, Lz3$a;-><init>()V

    .line 29
    iput-object v0, p0, Lca;->g:Lz3$a;

    .line 31
    new-instance v0, Ljava/util/ArrayList;

    .line 33
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 36
    iput-object v0, p0, Lca;->h:Ljava/util/ArrayList;

    .line 38
    iput-object p1, p0, Lca;->a:Le8;

    .line 40
    iput-object p1, p0, Lca;->d:Le8;

    .line 42
    return-void
.end method


# virtual methods
.method public final a(Lda;IILjava/util/ArrayList;Ltq;)V
    .locals 9

    .line 1
    iget-object p1, p1, Lda;->d:Loz;

    .line 3
    iget-object p3, p1, Loz;->c:Ltq;

    .line 5
    if-nez p3, :cond_a

    .line 7
    iget-object p3, p0, Lca;->a:Le8;

    .line 9
    iget-object v0, p3, Ld8;->d:Lng;

    .line 11
    if-eq p1, v0, :cond_a

    .line 13
    iget-object p3, p3, Ld8;->e:Llx;

    .line 15
    if-ne p1, p3, :cond_0

    .line 17
    goto/16 :goto_6

    .line 19
    :cond_0
    if-nez p5, :cond_1

    .line 21
    new-instance p5, Ltq;

    .line 23
    invoke-direct {p5, p1}, Ltq;-><init>(Loz;)V

    .line 26
    invoke-virtual {p4, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 29
    :cond_1
    iput-object p5, p1, Loz;->c:Ltq;

    .line 31
    iget-object p3, p5, Ltq;->b:Ljava/util/ArrayList;

    .line 33
    invoke-virtual {p3, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 36
    iget-object p3, p1, Loz;->h:Lda;

    .line 38
    iget-object v0, p3, Lda;->k:Ljava/util/ArrayList;

    .line 40
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 43
    move-result-object v6

    .line 44
    :cond_2
    :goto_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_3

    .line 50
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 53
    move-result-object v0

    .line 54
    check-cast v0, Lz9;

    .line 56
    instance-of v1, v0, Lda;

    .line 58
    if-eqz v1, :cond_2

    .line 60
    move-object v1, v0

    .line 61
    check-cast v1, Lda;

    .line 63
    const/4 v3, 0x0

    .line 64
    move-object v0, p0

    .line 65
    move v2, p2

    .line 66
    move-object v4, p4

    .line 67
    move-object v5, p5

    .line 68
    invoke-virtual/range {v0 .. v5}, Lca;->a(Lda;IILjava/util/ArrayList;Ltq;)V

    .line 71
    goto :goto_0

    .line 72
    :cond_3
    iget-object v6, p1, Loz;->i:Lda;

    .line 74
    iget-object v0, v6, Lda;->k:Ljava/util/ArrayList;

    .line 76
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 79
    move-result-object v7

    .line 80
    :cond_4
    :goto_1
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 83
    move-result v0

    .line 84
    if-eqz v0, :cond_5

    .line 86
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 89
    move-result-object v0

    .line 90
    check-cast v0, Lz9;

    .line 92
    instance-of v1, v0, Lda;

    .line 94
    if-eqz v1, :cond_4

    .line 96
    move-object v1, v0

    .line 97
    check-cast v1, Lda;

    .line 99
    const/4 v3, 0x1

    .line 100
    move-object v0, p0

    .line 101
    move v2, p2

    .line 102
    move-object v4, p4

    .line 103
    move-object v5, p5

    .line 104
    invoke-virtual/range {v0 .. v5}, Lca;->a(Lda;IILjava/util/ArrayList;Ltq;)V

    .line 107
    goto :goto_1

    .line 108
    :cond_5
    const/4 v7, 0x1

    .line 109
    if-ne p2, v7, :cond_7

    .line 111
    instance-of v0, p1, Llx;

    .line 113
    if-eqz v0, :cond_7

    .line 115
    move-object v0, p1

    .line 116
    check-cast v0, Llx;

    .line 118
    iget-object v0, v0, Llx;->k:Lda;

    .line 120
    iget-object v0, v0, Lda;->k:Ljava/util/ArrayList;

    .line 122
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 125
    move-result-object v8

    .line 126
    :cond_6
    :goto_2
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 129
    move-result v0

    .line 130
    if-eqz v0, :cond_7

    .line 132
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 135
    move-result-object v0

    .line 136
    check-cast v0, Lz9;

    .line 138
    instance-of v1, v0, Lda;

    .line 140
    if-eqz v1, :cond_6

    .line 142
    move-object v1, v0

    .line 143
    check-cast v1, Lda;

    .line 145
    const/4 v3, 0x2

    .line 146
    move-object v0, p0

    .line 147
    move v2, p2

    .line 148
    move-object v4, p4

    .line 149
    move-object v5, p5

    .line 150
    invoke-virtual/range {v0 .. v5}, Lca;->a(Lda;IILjava/util/ArrayList;Ltq;)V

    .line 153
    goto :goto_2

    .line 154
    :cond_7
    iget-object p3, p3, Lda;->l:Ljava/util/ArrayList;

    .line 156
    invoke-virtual {p3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 159
    move-result-object p3

    .line 160
    :goto_3
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    .line 163
    move-result v0

    .line 164
    if-eqz v0, :cond_8

    .line 166
    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 169
    move-result-object v0

    .line 170
    move-object v1, v0

    .line 171
    check-cast v1, Lda;

    .line 173
    const/4 v3, 0x0

    .line 174
    move-object v0, p0

    .line 175
    move v2, p2

    .line 176
    move-object v4, p4

    .line 177
    move-object v5, p5

    .line 178
    invoke-virtual/range {v0 .. v5}, Lca;->a(Lda;IILjava/util/ArrayList;Ltq;)V

    .line 181
    goto :goto_3

    .line 182
    :cond_8
    iget-object p3, v6, Lda;->l:Ljava/util/ArrayList;

    .line 184
    invoke-virtual {p3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 187
    move-result-object p3

    .line 188
    :goto_4
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    .line 191
    move-result v0

    .line 192
    if-eqz v0, :cond_9

    .line 194
    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 197
    move-result-object v0

    .line 198
    move-object v1, v0

    .line 199
    check-cast v1, Lda;

    .line 201
    const/4 v3, 0x1

    .line 202
    move-object v0, p0

    .line 203
    move v2, p2

    .line 204
    move-object v4, p4

    .line 205
    move-object v5, p5

    .line 206
    invoke-virtual/range {v0 .. v5}, Lca;->a(Lda;IILjava/util/ArrayList;Ltq;)V

    .line 209
    goto :goto_4

    .line 210
    :cond_9
    if-ne p2, v7, :cond_a

    .line 212
    instance-of p3, p1, Llx;

    .line 214
    if-eqz p3, :cond_a

    .line 216
    check-cast p1, Llx;

    .line 218
    iget-object p1, p1, Llx;->k:Lda;

    .line 220
    iget-object p1, p1, Lda;->l:Ljava/util/ArrayList;

    .line 222
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 225
    move-result-object p1

    .line 226
    :goto_5
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 229
    move-result p3

    .line 230
    if-eqz p3, :cond_a

    .line 232
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 235
    move-result-object p3

    .line 236
    move-object v1, p3

    .line 237
    check-cast v1, Lda;

    .line 239
    const/4 v3, 0x2

    .line 240
    move-object v0, p0

    .line 241
    move v2, p2

    .line 242
    move-object v4, p4

    .line 243
    move-object v5, p5

    .line 244
    :try_start_0
    invoke-virtual/range {v0 .. v5}, Lca;->a(Lda;IILjava/util/ArrayList;Ltq;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 247
    goto :goto_5

    .line 248
    :catchall_0
    move-exception p1

    .line 249
    throw p1

    .line 250
    :cond_a
    :goto_6
    return-void
.end method

.method public final b(Le8;)V
    .locals 16

    .line 1
    move-object/from16 v0, p1

    .line 3
    iget-object v1, v0, Lmz;->s0:Ljava/util/ArrayList;

    .line 5
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 8
    move-result-object v1

    .line 9
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 12
    move-result v2

    .line 13
    if-eqz v2, :cond_26

    .line 15
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 18
    move-result-object v2

    .line 19
    check-cast v2, Ld8;

    .line 21
    iget-object v3, v2, Ld8;->V:[I

    .line 23
    const/4 v4, 0x0

    .line 24
    aget v5, v3, v4

    .line 26
    const/4 v9, 0x1

    .line 27
    aget v3, v3, v9

    .line 29
    iget v6, v2, Ld8;->j0:I

    .line 31
    const/16 v7, 0x8

    .line 33
    if-ne v6, v7, :cond_1

    .line 35
    iput-boolean v9, v2, Ld8;->a:Z

    .line 37
    goto :goto_0

    .line 38
    :cond_1
    iget v6, v2, Ld8;->x:F

    .line 40
    const/high16 v10, 0x3f800000    # 1.0f

    .line 42
    const/4 v7, 0x3

    .line 43
    const/4 v8, 0x2

    .line 44
    cmpg-float v11, v6, v10

    .line 46
    if-gez v11, :cond_2

    .line 48
    if-ne v5, v7, :cond_2

    .line 50
    iput v8, v2, Ld8;->s:I

    .line 52
    :cond_2
    iget v11, v2, Ld8;->A:F

    .line 54
    cmpg-float v12, v11, v10

    .line 56
    if-gez v12, :cond_3

    .line 58
    if-ne v3, v7, :cond_3

    .line 60
    iput v8, v2, Ld8;->t:I

    .line 62
    :cond_3
    iget v12, v2, Ld8;->Z:F

    .line 64
    const/4 v13, 0x0

    .line 65
    cmpl-float v12, v12, v13

    .line 67
    if-lez v12, :cond_9

    .line 69
    if-ne v5, v7, :cond_5

    .line 71
    if-eq v3, v8, :cond_4

    .line 73
    if-ne v3, v9, :cond_5

    .line 75
    :cond_4
    iput v7, v2, Ld8;->s:I

    .line 77
    goto :goto_1

    .line 78
    :cond_5
    if-ne v3, v7, :cond_7

    .line 80
    if-eq v5, v8, :cond_6

    .line 82
    if-ne v5, v9, :cond_7

    .line 84
    :cond_6
    iput v7, v2, Ld8;->t:I

    .line 86
    goto :goto_1

    .line 87
    :cond_7
    if-ne v5, v7, :cond_9

    .line 89
    if-ne v3, v7, :cond_9

    .line 91
    iget v12, v2, Ld8;->s:I

    .line 93
    if-nez v12, :cond_8

    .line 95
    iput v7, v2, Ld8;->s:I

    .line 97
    :cond_8
    iget v12, v2, Ld8;->t:I

    .line 99
    if-nez v12, :cond_9

    .line 101
    iput v7, v2, Ld8;->t:I

    .line 103
    :cond_9
    :goto_1
    iget-object v12, v2, Ld8;->M:Lv7;

    .line 105
    iget-object v13, v2, Ld8;->K:Lv7;

    .line 107
    if-ne v5, v7, :cond_b

    .line 109
    iget v14, v2, Ld8;->s:I

    .line 111
    if-ne v14, v9, :cond_b

    .line 113
    iget-object v14, v13, Lv7;->f:Lv7;

    .line 115
    if-eqz v14, :cond_a

    .line 117
    iget-object v14, v12, Lv7;->f:Lv7;

    .line 119
    if-nez v14, :cond_b

    .line 121
    :cond_a
    const/4 v5, 0x2

    .line 122
    :cond_b
    iget-object v14, v2, Ld8;->N:Lv7;

    .line 124
    iget-object v15, v2, Ld8;->L:Lv7;

    .line 126
    if-ne v3, v7, :cond_d

    .line 128
    iget v10, v2, Ld8;->t:I

    .line 130
    if-ne v10, v9, :cond_d

    .line 132
    iget-object v10, v15, Lv7;->f:Lv7;

    .line 134
    if-eqz v10, :cond_c

    .line 136
    iget-object v10, v14, Lv7;->f:Lv7;

    .line 138
    if-nez v10, :cond_d

    .line 140
    :cond_c
    const/4 v10, 0x2

    .line 141
    goto :goto_2

    .line 142
    :cond_d
    move v10, v3

    .line 143
    :goto_2
    iget-object v3, v2, Ld8;->d:Lng;

    .line 145
    iput v5, v3, Loz;->d:I

    .line 147
    iget v4, v2, Ld8;->s:I

    .line 149
    iput v4, v3, Loz;->a:I

    .line 151
    iget-object v3, v2, Ld8;->e:Llx;

    .line 153
    iput v10, v3, Loz;->d:I

    .line 155
    iget v7, v2, Ld8;->t:I

    .line 157
    iput v7, v3, Loz;->a:I

    .line 159
    const/4 v3, 0x4

    .line 160
    if-eq v5, v3, :cond_e

    .line 162
    if-eq v5, v9, :cond_e

    .line 164
    if-ne v5, v8, :cond_f

    .line 166
    :cond_e
    if-eq v10, v3, :cond_23

    .line 168
    if-eq v10, v9, :cond_23

    .line 170
    if-ne v10, v8, :cond_f

    .line 172
    goto/16 :goto_4

    .line 174
    :cond_f
    const/high16 v12, 0x3f000000    # 0.5f

    .line 176
    iget-object v13, v0, Ld8;->V:[I

    .line 178
    iget-object v14, v2, Ld8;->S:[Lv7;

    .line 180
    const/4 v15, 0x3

    .line 181
    if-ne v5, v15, :cond_17

    .line 183
    if-eq v10, v8, :cond_10

    .line 185
    if-ne v10, v9, :cond_17

    .line 187
    :cond_10
    if-ne v4, v15, :cond_12

    .line 189
    if-ne v10, v8, :cond_11

    .line 191
    const/4 v6, 0x0

    .line 192
    const/4 v8, 0x0

    .line 193
    const/4 v7, 0x2

    .line 194
    move-object/from16 v3, p0

    .line 196
    move-object v4, v2

    .line 197
    move v5, v7

    .line 198
    invoke-virtual/range {v3 .. v8}, Lca;->f(Ld8;IIII)V

    .line 201
    :cond_11
    invoke-virtual {v2}, Ld8;->l()I

    .line 204
    move-result v8

    .line 205
    int-to-float v3, v8

    .line 206
    iget v4, v2, Ld8;->Z:F

    .line 208
    mul-float v3, v3, v4

    .line 210
    add-float/2addr v3, v12

    .line 211
    float-to-int v6, v3

    .line 212
    const/4 v7, 0x1

    .line 213
    move-object/from16 v3, p0

    .line 215
    move-object v4, v2

    .line 216
    move v5, v7

    .line 217
    invoke-virtual/range {v3 .. v8}, Lca;->f(Ld8;IIII)V

    .line 220
    iget-object v3, v2, Ld8;->d:Lng;

    .line 222
    iget-object v3, v3, Loz;->e:Lia;

    .line 224
    invoke-virtual {v2}, Ld8;->r()I

    .line 227
    move-result v4

    .line 228
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 231
    iget-object v3, v2, Ld8;->e:Llx;

    .line 233
    iget-object v3, v3, Loz;->e:Lia;

    .line 235
    invoke-virtual {v2}, Ld8;->l()I

    .line 238
    move-result v4

    .line 239
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 242
    iput-boolean v9, v2, Ld8;->a:Z

    .line 244
    goto/16 :goto_0

    .line 246
    :cond_12
    if-ne v4, v9, :cond_13

    .line 248
    const/4 v6, 0x0

    .line 249
    const/4 v8, 0x0

    .line 250
    const/4 v5, 0x2

    .line 251
    move-object/from16 v3, p0

    .line 253
    move-object v4, v2

    .line 254
    move v7, v10

    .line 255
    invoke-virtual/range {v3 .. v8}, Lca;->f(Ld8;IIII)V

    .line 258
    iget-object v3, v2, Ld8;->d:Lng;

    .line 260
    iget-object v3, v3, Loz;->e:Lia;

    .line 262
    invoke-virtual {v2}, Ld8;->r()I

    .line 265
    move-result v2

    .line 266
    iput v2, v3, Lia;->m:I

    .line 268
    goto/16 :goto_0

    .line 270
    :cond_13
    if-ne v4, v8, :cond_15

    .line 272
    const/4 v15, 0x0

    .line 273
    aget v8, v13, v15

    .line 275
    if-eq v8, v9, :cond_14

    .line 277
    if-ne v8, v3, :cond_17

    .line 279
    :cond_14
    invoke-virtual/range {p1 .. p1}, Ld8;->r()I

    .line 282
    move-result v3

    .line 283
    int-to-float v3, v3

    .line 284
    mul-float v6, v6, v3

    .line 286
    add-float/2addr v6, v12

    .line 287
    float-to-int v6, v6

    .line 288
    invoke-virtual {v2}, Ld8;->l()I

    .line 291
    move-result v8

    .line 292
    const/4 v5, 0x1

    .line 293
    move-object/from16 v3, p0

    .line 295
    move-object v4, v2

    .line 296
    move v7, v10

    .line 297
    invoke-virtual/range {v3 .. v8}, Lca;->f(Ld8;IIII)V

    .line 300
    iget-object v3, v2, Ld8;->d:Lng;

    .line 302
    iget-object v3, v3, Loz;->e:Lia;

    .line 304
    invoke-virtual {v2}, Ld8;->r()I

    .line 307
    move-result v4

    .line 308
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 311
    iget-object v3, v2, Ld8;->e:Llx;

    .line 313
    iget-object v3, v3, Loz;->e:Lia;

    .line 315
    invoke-virtual {v2}, Ld8;->l()I

    .line 318
    move-result v4

    .line 319
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 322
    iput-boolean v9, v2, Ld8;->a:Z

    .line 324
    goto/16 :goto_0

    .line 326
    :cond_15
    const/4 v8, 0x0

    .line 327
    aget-object v15, v14, v8

    .line 329
    iget-object v8, v15, Lv7;->f:Lv7;

    .line 331
    if-eqz v8, :cond_16

    .line 333
    aget-object v8, v14, v9

    .line 335
    iget-object v8, v8, Lv7;->f:Lv7;

    .line 337
    if-nez v8, :cond_17

    .line 339
    :cond_16
    const/4 v6, 0x0

    .line 340
    const/4 v8, 0x0

    .line 341
    const/4 v5, 0x2

    .line 342
    move-object/from16 v3, p0

    .line 344
    move-object v4, v2

    .line 345
    move v7, v10

    .line 346
    invoke-virtual/range {v3 .. v8}, Lca;->f(Ld8;IIII)V

    .line 349
    iget-object v3, v2, Ld8;->d:Lng;

    .line 351
    iget-object v3, v3, Loz;->e:Lia;

    .line 353
    invoke-virtual {v2}, Ld8;->r()I

    .line 356
    move-result v4

    .line 357
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 360
    iget-object v3, v2, Ld8;->e:Llx;

    .line 362
    iget-object v3, v3, Loz;->e:Lia;

    .line 364
    invoke-virtual {v2}, Ld8;->l()I

    .line 367
    move-result v4

    .line 368
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 371
    iput-boolean v9, v2, Ld8;->a:Z

    .line 373
    goto/16 :goto_0

    .line 375
    :cond_17
    const/4 v8, 0x3

    .line 376
    if-ne v10, v8, :cond_20

    .line 378
    const/4 v15, 0x2

    .line 379
    if-eq v5, v15, :cond_18

    .line 381
    if-ne v5, v9, :cond_20

    .line 383
    :cond_18
    if-ne v7, v8, :cond_1b

    .line 385
    if-ne v5, v15, :cond_19

    .line 387
    const/4 v6, 0x0

    .line 388
    const/4 v8, 0x0

    .line 389
    const/4 v7, 0x2

    .line 390
    move-object/from16 v3, p0

    .line 392
    move-object v4, v2

    .line 393
    move v5, v7

    .line 394
    invoke-virtual/range {v3 .. v8}, Lca;->f(Ld8;IIII)V

    .line 397
    :cond_19
    invoke-virtual {v2}, Ld8;->r()I

    .line 400
    move-result v6

    .line 401
    iget v3, v2, Ld8;->Z:F

    .line 403
    iget v4, v2, Ld8;->a0:I

    .line 405
    const/4 v5, -0x1

    .line 406
    if-ne v4, v5, :cond_1a

    .line 408
    const/high16 v4, 0x3f800000    # 1.0f

    .line 410
    div-float v3, v4, v3

    .line 412
    :cond_1a
    int-to-float v4, v6

    .line 413
    mul-float v4, v4, v3

    .line 415
    add-float/2addr v4, v12

    .line 416
    float-to-int v8, v4

    .line 417
    const/4 v7, 0x1

    .line 418
    move-object/from16 v3, p0

    .line 420
    move-object v4, v2

    .line 421
    move v5, v7

    .line 422
    invoke-virtual/range {v3 .. v8}, Lca;->f(Ld8;IIII)V

    .line 425
    iget-object v3, v2, Ld8;->d:Lng;

    .line 427
    iget-object v3, v3, Loz;->e:Lia;

    .line 429
    invoke-virtual {v2}, Ld8;->r()I

    .line 432
    move-result v4

    .line 433
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 436
    iget-object v3, v2, Ld8;->e:Llx;

    .line 438
    iget-object v3, v3, Loz;->e:Lia;

    .line 440
    invoke-virtual {v2}, Ld8;->l()I

    .line 443
    move-result v4

    .line 444
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 447
    iput-boolean v9, v2, Ld8;->a:Z

    .line 449
    goto/16 :goto_0

    .line 451
    :cond_1b
    if-ne v7, v9, :cond_1c

    .line 453
    const/4 v6, 0x0

    .line 454
    const/4 v8, 0x0

    .line 455
    const/4 v7, 0x2

    .line 456
    move-object/from16 v3, p0

    .line 458
    move-object v4, v2

    .line 459
    invoke-virtual/range {v3 .. v8}, Lca;->f(Ld8;IIII)V

    .line 462
    iget-object v3, v2, Ld8;->e:Llx;

    .line 464
    iget-object v3, v3, Loz;->e:Lia;

    .line 466
    invoke-virtual {v2}, Ld8;->l()I

    .line 469
    move-result v2

    .line 470
    iput v2, v3, Lia;->m:I

    .line 472
    goto/16 :goto_0

    .line 474
    :cond_1c
    const/4 v8, 0x2

    .line 475
    if-ne v7, v8, :cond_1e

    .line 477
    aget v8, v13, v9

    .line 479
    if-eq v8, v9, :cond_1d

    .line 481
    if-ne v8, v3, :cond_20

    .line 483
    :cond_1d
    invoke-virtual {v2}, Ld8;->r()I

    .line 486
    move-result v6

    .line 487
    invoke-virtual/range {p1 .. p1}, Ld8;->l()I

    .line 490
    move-result v3

    .line 491
    int-to-float v3, v3

    .line 492
    mul-float v11, v11, v3

    .line 494
    add-float/2addr v11, v12

    .line 495
    float-to-int v8, v11

    .line 496
    const/4 v7, 0x1

    .line 497
    move-object/from16 v3, p0

    .line 499
    move-object v4, v2

    .line 500
    invoke-virtual/range {v3 .. v8}, Lca;->f(Ld8;IIII)V

    .line 503
    iget-object v3, v2, Ld8;->d:Lng;

    .line 505
    iget-object v3, v3, Loz;->e:Lia;

    .line 507
    invoke-virtual {v2}, Ld8;->r()I

    .line 510
    move-result v4

    .line 511
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 514
    iget-object v3, v2, Ld8;->e:Llx;

    .line 516
    iget-object v3, v3, Loz;->e:Lia;

    .line 518
    invoke-virtual {v2}, Ld8;->l()I

    .line 521
    move-result v4

    .line 522
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 525
    iput-boolean v9, v2, Ld8;->a:Z

    .line 527
    goto/16 :goto_0

    .line 529
    :cond_1e
    const/4 v3, 0x2

    .line 530
    aget-object v8, v14, v3

    .line 532
    iget-object v3, v8, Lv7;->f:Lv7;

    .line 534
    if-eqz v3, :cond_1f

    .line 536
    const/4 v3, 0x3

    .line 537
    aget-object v8, v14, v3

    .line 539
    iget-object v3, v8, Lv7;->f:Lv7;

    .line 541
    if-nez v3, :cond_20

    .line 543
    :cond_1f
    const/4 v6, 0x0

    .line 544
    const/4 v8, 0x0

    .line 545
    const/4 v5, 0x2

    .line 546
    move-object/from16 v3, p0

    .line 548
    move-object v4, v2

    .line 549
    move v7, v10

    .line 550
    invoke-virtual/range {v3 .. v8}, Lca;->f(Ld8;IIII)V

    .line 553
    iget-object v3, v2, Ld8;->d:Lng;

    .line 555
    iget-object v3, v3, Loz;->e:Lia;

    .line 557
    invoke-virtual {v2}, Ld8;->r()I

    .line 560
    move-result v4

    .line 561
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 564
    iget-object v3, v2, Ld8;->e:Llx;

    .line 566
    iget-object v3, v3, Loz;->e:Lia;

    .line 568
    invoke-virtual {v2}, Ld8;->l()I

    .line 571
    move-result v4

    .line 572
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 575
    iput-boolean v9, v2, Ld8;->a:Z

    .line 577
    goto/16 :goto_0

    .line 579
    :cond_20
    const/4 v3, 0x3

    .line 580
    if-ne v5, v3, :cond_0

    .line 582
    if-ne v10, v3, :cond_0

    .line 584
    if-eq v4, v9, :cond_22

    .line 586
    if-ne v7, v9, :cond_21

    .line 588
    goto :goto_3

    .line 589
    :cond_21
    const/4 v3, 0x2

    .line 590
    if-ne v7, v3, :cond_0

    .line 592
    if-ne v4, v3, :cond_0

    .line 594
    const/4 v3, 0x0

    .line 595
    aget v3, v13, v3

    .line 597
    if-ne v3, v9, :cond_0

    .line 599
    aget v3, v13, v9

    .line 601
    if-ne v3, v9, :cond_0

    .line 603
    invoke-virtual/range {p1 .. p1}, Ld8;->r()I

    .line 606
    move-result v3

    .line 607
    int-to-float v3, v3

    .line 608
    mul-float v6, v6, v3

    .line 610
    add-float/2addr v6, v12

    .line 611
    float-to-int v6, v6

    .line 612
    invoke-virtual/range {p1 .. p1}, Ld8;->l()I

    .line 615
    move-result v3

    .line 616
    int-to-float v3, v3

    .line 617
    mul-float v11, v11, v3

    .line 619
    add-float/2addr v11, v12

    .line 620
    float-to-int v8, v11

    .line 621
    const/4 v7, 0x1

    .line 622
    move-object/from16 v3, p0

    .line 624
    move-object v4, v2

    .line 625
    move v5, v7

    .line 626
    invoke-virtual/range {v3 .. v8}, Lca;->f(Ld8;IIII)V

    .line 629
    iget-object v3, v2, Ld8;->d:Lng;

    .line 631
    iget-object v3, v3, Loz;->e:Lia;

    .line 633
    invoke-virtual {v2}, Ld8;->r()I

    .line 636
    move-result v4

    .line 637
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 640
    iget-object v3, v2, Ld8;->e:Llx;

    .line 642
    iget-object v3, v3, Loz;->e:Lia;

    .line 644
    invoke-virtual {v2}, Ld8;->l()I

    .line 647
    move-result v4

    .line 648
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 651
    iput-boolean v9, v2, Ld8;->a:Z

    .line 653
    goto/16 :goto_0

    .line 655
    :cond_22
    :goto_3
    const/4 v6, 0x0

    .line 656
    const/4 v8, 0x0

    .line 657
    const/4 v7, 0x2

    .line 658
    move-object/from16 v3, p0

    .line 660
    move-object v4, v2

    .line 661
    move v5, v7

    .line 662
    invoke-virtual/range {v3 .. v8}, Lca;->f(Ld8;IIII)V

    .line 665
    iget-object v3, v2, Ld8;->d:Lng;

    .line 667
    iget-object v3, v3, Loz;->e:Lia;

    .line 669
    invoke-virtual {v2}, Ld8;->r()I

    .line 672
    move-result v4

    .line 673
    iput v4, v3, Lia;->m:I

    .line 675
    iget-object v3, v2, Ld8;->e:Llx;

    .line 677
    iget-object v3, v3, Loz;->e:Lia;

    .line 679
    invoke-virtual {v2}, Ld8;->l()I

    .line 682
    move-result v2

    .line 683
    iput v2, v3, Lia;->m:I

    .line 685
    goto/16 :goto_0

    .line 687
    :cond_23
    :goto_4
    invoke-virtual {v2}, Ld8;->r()I

    .line 690
    move-result v4

    .line 691
    if-ne v5, v3, :cond_24

    .line 693
    invoke-virtual/range {p1 .. p1}, Ld8;->r()I

    .line 696
    move-result v4

    .line 697
    iget v5, v13, Lv7;->g:I

    .line 699
    sub-int/2addr v4, v5

    .line 700
    iget v5, v12, Lv7;->g:I

    .line 702
    sub-int/2addr v4, v5

    .line 703
    move v6, v4

    .line 704
    const/4 v5, 0x1

    .line 705
    goto :goto_5

    .line 706
    :cond_24
    move v6, v4

    .line 707
    :goto_5
    invoke-virtual {v2}, Ld8;->l()I

    .line 710
    move-result v4

    .line 711
    if-ne v10, v3, :cond_25

    .line 713
    invoke-virtual/range {p1 .. p1}, Ld8;->l()I

    .line 716
    move-result v3

    .line 717
    iget v4, v15, Lv7;->g:I

    .line 719
    sub-int/2addr v3, v4

    .line 720
    iget v4, v14, Lv7;->g:I

    .line 722
    sub-int/2addr v3, v4

    .line 723
    move v8, v3

    .line 724
    const/4 v7, 0x1

    .line 725
    goto :goto_6

    .line 726
    :cond_25
    move v8, v4

    .line 727
    move v7, v10

    .line 728
    :goto_6
    move-object/from16 v3, p0

    .line 730
    move-object v4, v2

    .line 731
    invoke-virtual/range {v3 .. v8}, Lca;->f(Ld8;IIII)V

    .line 734
    iget-object v3, v2, Ld8;->d:Lng;

    .line 736
    iget-object v3, v3, Loz;->e:Lia;

    .line 738
    invoke-virtual {v2}, Ld8;->r()I

    .line 741
    move-result v4

    .line 742
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 745
    iget-object v3, v2, Ld8;->e:Llx;

    .line 747
    iget-object v3, v3, Loz;->e:Lia;

    .line 749
    invoke-virtual {v2}, Ld8;->l()I

    .line 752
    move-result v4

    .line 753
    invoke-virtual {v3, v4}, Lia;->d(I)V

    .line 756
    iput-boolean v9, v2, Ld8;->a:Z

    .line 758
    goto/16 :goto_0

    .line 760
    :cond_26
    return-void
.end method

.method public final c()V
    .locals 8

    .line 1
    iget-object v0, p0, Lca;->e:Ljava/util/ArrayList;

    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 6
    iget-object v1, p0, Lca;->d:Le8;

    .line 8
    iget-object v2, v1, Ld8;->d:Lng;

    .line 10
    invoke-virtual {v2}, Lng;->f()V

    .line 13
    iget-object v2, v1, Ld8;->e:Llx;

    .line 15
    invoke-virtual {v2}, Llx;->f()V

    .line 18
    iget-object v2, v1, Ld8;->d:Lng;

    .line 20
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 23
    iget-object v2, v1, Ld8;->e:Llx;

    .line 25
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 28
    iget-object v2, v1, Lmz;->s0:Ljava/util/ArrayList;

    .line 30
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 33
    move-result-object v2

    .line 34
    const/4 v3, 0x0

    .line 35
    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 38
    move-result v4

    .line 39
    const/4 v5, 0x1

    .line 40
    const/4 v6, 0x0

    .line 41
    if-eqz v4, :cond_8

    .line 43
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 46
    move-result-object v4

    .line 47
    check-cast v4, Ld8;

    .line 49
    instance-of v7, v4, Lyf;

    .line 51
    if-eqz v7, :cond_1

    .line 53
    new-instance v5, Lzf;

    .line 55
    invoke-direct {v5, v4}, Lzf;-><init>(Ld8;)V

    .line 58
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 61
    goto :goto_0

    .line 62
    :cond_1
    invoke-virtual {v4}, Ld8;->y()Z

    .line 65
    move-result v7

    .line 66
    if-eqz v7, :cond_4

    .line 68
    iget-object v7, v4, Ld8;->b:Ly5;

    .line 70
    if-nez v7, :cond_2

    .line 72
    new-instance v7, Ly5;

    .line 74
    invoke-direct {v7, v6, v4}, Ly5;-><init>(ILd8;)V

    .line 77
    iput-object v7, v4, Ld8;->b:Ly5;

    .line 79
    :cond_2
    if-nez v3, :cond_3

    .line 81
    new-instance v3, Ljava/util/HashSet;

    .line 83
    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    .line 86
    :cond_3
    iget-object v6, v4, Ld8;->b:Ly5;

    .line 88
    invoke-virtual {v3, v6}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 91
    goto :goto_1

    .line 92
    :cond_4
    iget-object v6, v4, Ld8;->d:Lng;

    .line 94
    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 97
    :goto_1
    invoke-virtual {v4}, Ld8;->z()Z

    .line 100
    move-result v6

    .line 101
    if-eqz v6, :cond_7

    .line 103
    iget-object v6, v4, Ld8;->c:Ly5;

    .line 105
    if-nez v6, :cond_5

    .line 107
    new-instance v6, Ly5;

    .line 109
    invoke-direct {v6, v5, v4}, Ly5;-><init>(ILd8;)V

    .line 112
    iput-object v6, v4, Ld8;->c:Ly5;

    .line 114
    :cond_5
    if-nez v3, :cond_6

    .line 116
    new-instance v3, Ljava/util/HashSet;

    .line 118
    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    .line 121
    :cond_6
    iget-object v5, v4, Ld8;->c:Ly5;

    .line 123
    invoke-virtual {v3, v5}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 126
    goto :goto_2

    .line 127
    :cond_7
    iget-object v5, v4, Ld8;->e:Llx;

    .line 129
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 132
    :goto_2
    instance-of v5, v4, Lmg;

    .line 134
    if-eqz v5, :cond_0

    .line 136
    new-instance v5, Llg;

    .line 138
    invoke-direct {v5, v4}, Llg;-><init>(Ld8;)V

    .line 141
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 144
    goto :goto_0

    .line 145
    :cond_8
    if-eqz v3, :cond_9

    .line 147
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 150
    :cond_9
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 153
    move-result-object v2

    .line 154
    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 157
    move-result v3

    .line 158
    if-eqz v3, :cond_a

    .line 160
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 163
    move-result-object v3

    .line 164
    check-cast v3, Loz;

    .line 166
    invoke-virtual {v3}, Loz;->f()V

    .line 169
    goto :goto_3

    .line 170
    :cond_a
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 173
    move-result-object v0

    .line 174
    :goto_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 177
    move-result v2

    .line 178
    if-eqz v2, :cond_c

    .line 180
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 183
    move-result-object v2

    .line 184
    check-cast v2, Loz;

    .line 186
    iget-object v3, v2, Loz;->b:Ld8;

    .line 188
    if-ne v3, v1, :cond_b

    .line 190
    goto :goto_4

    .line 191
    :cond_b
    invoke-virtual {v2}, Loz;->d()V

    .line 194
    goto :goto_4

    .line 195
    :cond_c
    iget-object v0, p0, Lca;->h:Ljava/util/ArrayList;

    .line 197
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 200
    iget-object v1, p0, Lca;->a:Le8;

    .line 202
    iget-object v2, v1, Ld8;->d:Lng;

    .line 204
    invoke-virtual {p0, v2, v6, v0}, Lca;->e(Loz;ILjava/util/ArrayList;)V

    .line 207
    iget-object v1, v1, Ld8;->e:Llx;

    .line 209
    invoke-virtual {p0, v1, v5, v0}, Lca;->e(Loz;ILjava/util/ArrayList;)V

    .line 212
    iput-boolean v6, p0, Lca;->b:Z

    .line 214
    return-void
.end method

.method public final d(Le8;I)I
    .locals 19

    .line 1
    move-object/from16 v0, p1

    .line 3
    move-object/from16 v1, p0

    .line 5
    move/from16 v2, p2

    .line 7
    iget-object v3, v1, Lca;->h:Ljava/util/ArrayList;

    .line 9
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 12
    move-result v4

    .line 13
    const/4 v5, 0x0

    .line 14
    const-wide/16 v6, 0x0

    .line 16
    :goto_0
    if-ge v5, v4, :cond_d

    .line 18
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 21
    move-result-object v8

    .line 22
    check-cast v8, Ltq;

    .line 24
    iget-object v8, v8, Ltq;->a:Loz;

    .line 26
    instance-of v9, v8, Ly5;

    .line 28
    if-eqz v9, :cond_0

    .line 30
    move-object v9, v8

    .line 31
    check-cast v9, Ly5;

    .line 33
    iget v9, v9, Loz;->f:I

    .line 35
    if-eq v9, v2, :cond_2

    .line 37
    goto :goto_1

    .line 38
    :cond_0
    if-nez v2, :cond_1

    .line 40
    instance-of v9, v8, Lng;

    .line 42
    if-nez v9, :cond_2

    .line 44
    goto :goto_1

    .line 45
    :cond_1
    instance-of v9, v8, Llx;

    .line 47
    if-nez v9, :cond_2

    .line 49
    :goto_1
    const-wide/16 v8, 0x0

    .line 51
    move-object/from16 v17, v3

    .line 53
    move/from16 v18, v4

    .line 55
    goto/16 :goto_7

    .line 57
    :cond_2
    if-nez v2, :cond_3

    .line 59
    iget-object v9, v0, Ld8;->d:Lng;

    .line 61
    goto :goto_2

    .line 62
    :cond_3
    iget-object v9, v0, Ld8;->e:Llx;

    .line 64
    :goto_2
    iget-object v9, v9, Loz;->h:Lda;

    .line 66
    if-nez v2, :cond_4

    .line 68
    iget-object v10, v0, Ld8;->d:Lng;

    .line 70
    goto :goto_3

    .line 71
    :cond_4
    iget-object v10, v0, Ld8;->e:Llx;

    .line 73
    :goto_3
    iget-object v10, v10, Loz;->i:Lda;

    .line 75
    iget-object v11, v8, Loz;->h:Lda;

    .line 77
    iget-object v11, v11, Lda;->l:Ljava/util/ArrayList;

    .line 79
    invoke-virtual {v11, v9}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 82
    move-result v9

    .line 83
    iget-object v11, v8, Loz;->i:Lda;

    .line 85
    iget-object v12, v11, Lda;->l:Ljava/util/ArrayList;

    .line 87
    invoke-virtual {v12, v10}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 90
    move-result v10

    .line 91
    invoke-virtual {v8}, Loz;->j()J

    .line 94
    move-result-wide v12

    .line 95
    iget-object v14, v8, Loz;->h:Lda;

    .line 97
    if-eqz v9, :cond_a

    .line 99
    if-eqz v10, :cond_a

    .line 101
    const-wide/16 v9, 0x0

    .line 103
    invoke-static {v14, v9, v10}, Ltq;->b(Lda;J)J

    .line 106
    move-result-wide v15

    .line 107
    invoke-static {v11, v9, v10}, Ltq;->a(Lda;J)J

    .line 110
    move-result-wide v9

    .line 111
    sub-long/2addr v15, v12

    .line 112
    iget v0, v11, Lda;->f:I

    .line 114
    neg-int v1, v0

    .line 115
    move-object/from16 v17, v3

    .line 117
    move/from16 v18, v4

    .line 119
    int-to-long v3, v1

    .line 120
    cmp-long v1, v15, v3

    .line 122
    if-ltz v1, :cond_5

    .line 124
    int-to-long v0, v0

    .line 125
    add-long/2addr v15, v0

    .line 126
    :cond_5
    move-wide v0, v15

    .line 127
    neg-long v3, v9

    .line 128
    sub-long/2addr v3, v12

    .line 129
    iget v9, v14, Lda;->f:I

    .line 131
    int-to-long v9, v9

    .line 132
    sub-long/2addr v3, v9

    .line 133
    cmp-long v15, v3, v9

    .line 135
    if-ltz v15, :cond_6

    .line 137
    sub-long/2addr v3, v9

    .line 138
    :cond_6
    iget-object v8, v8, Loz;->b:Ld8;

    .line 140
    if-nez v2, :cond_7

    .line 142
    iget v8, v8, Ld8;->g0:F

    .line 144
    goto :goto_4

    .line 145
    :cond_7
    const/4 v9, 0x1

    .line 146
    if-ne v2, v9, :cond_8

    .line 148
    iget v8, v8, Ld8;->h0:F

    .line 150
    goto :goto_4

    .line 151
    :cond_8
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 154
    const/high16 v8, -0x40800000    # -1.0f

    .line 156
    :goto_4
    const/4 v9, 0x0

    .line 157
    const/high16 v10, 0x3f800000    # 1.0f

    .line 159
    cmpl-float v9, v8, v9

    .line 161
    if-lez v9, :cond_9

    .line 163
    long-to-float v3, v3

    .line 164
    div-float/2addr v3, v8

    .line 165
    long-to-float v0, v0

    .line 166
    sub-float v1, v10, v8

    .line 168
    div-float/2addr v0, v1

    .line 169
    add-float/2addr v0, v3

    .line 170
    float-to-long v0, v0

    .line 171
    goto :goto_5

    .line 172
    :cond_9
    const-wide/16 v0, 0x0

    .line 174
    :goto_5
    long-to-float v0, v0

    .line 175
    mul-float v1, v0, v8

    .line 177
    const/high16 v3, 0x3f000000    # 0.5f

    .line 179
    add-float/2addr v1, v3

    .line 180
    float-to-long v1, v1

    .line 181
    invoke-static {v10, v8, v0, v3}, Lps;->b(FFFF)F

    .line 184
    move-result v0

    .line 185
    float-to-long v3, v0

    .line 186
    add-long/2addr v1, v12

    .line 187
    add-long/2addr v1, v3

    .line 188
    iget v0, v14, Lda;->f:I

    .line 190
    int-to-long v3, v0

    .line 191
    add-long/2addr v3, v1

    .line 192
    iget v0, v11, Lda;->f:I

    .line 194
    int-to-long v0, v0

    .line 195
    sub-long/2addr v3, v0

    .line 196
    move-wide v8, v3

    .line 197
    goto :goto_7

    .line 198
    :cond_a
    move-object/from16 v17, v3

    .line 200
    move/from16 v18, v4

    .line 202
    if-eqz v9, :cond_b

    .line 204
    iget v0, v14, Lda;->f:I

    .line 206
    int-to-long v0, v0

    .line 207
    invoke-static {v14, v0, v1}, Ltq;->b(Lda;J)J

    .line 210
    move-result-wide v0

    .line 211
    iget v2, v14, Lda;->f:I

    .line 213
    int-to-long v2, v2

    .line 214
    add-long/2addr v2, v12

    .line 215
    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->max(JJ)J

    .line 218
    move-result-wide v0

    .line 219
    :goto_6
    move-wide v8, v0

    .line 220
    goto :goto_7

    .line 221
    :cond_b
    if-eqz v10, :cond_c

    .line 223
    iget v0, v11, Lda;->f:I

    .line 225
    int-to-long v0, v0

    .line 226
    invoke-static {v11, v0, v1}, Ltq;->a(Lda;J)J

    .line 229
    move-result-wide v0

    .line 230
    iget v2, v11, Lda;->f:I

    .line 232
    neg-int v2, v2

    .line 233
    int-to-long v2, v2

    .line 234
    add-long/2addr v2, v12

    .line 235
    neg-long v0, v0

    .line 236
    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->max(JJ)J

    .line 239
    move-result-wide v0

    .line 240
    goto :goto_6

    .line 241
    :cond_c
    iget v0, v14, Lda;->f:I

    .line 243
    int-to-long v0, v0

    .line 244
    invoke-virtual {v8}, Loz;->j()J

    .line 247
    move-result-wide v2

    .line 248
    add-long/2addr v2, v0

    .line 249
    iget v0, v11, Lda;->f:I

    .line 251
    int-to-long v0, v0

    .line 252
    sub-long/2addr v2, v0

    .line 253
    move-wide v8, v2

    .line 254
    :goto_7
    invoke-static {v6, v7, v8, v9}, Ljava/lang/Math;->max(JJ)J

    .line 257
    move-result-wide v6

    .line 258
    add-int/lit8 v5, v5, 0x1

    .line 260
    move-object/from16 v1, p0

    .line 262
    move-object/from16 v0, p1

    .line 264
    move/from16 v2, p2

    .line 266
    move-object/from16 v3, v17

    .line 268
    move/from16 v4, v18

    .line 270
    goto/16 :goto_0

    .line 272
    :cond_d
    long-to-int v0, v6

    .line 273
    return v0
.end method

.method public final e(Loz;ILjava/util/ArrayList;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Loz;",
            "I",
            "Ljava/util/ArrayList<",
            "Ltq;",
            ">;)V"
        }
    .end annotation

    .line 1
    iget-object v0, p1, Loz;->h:Lda;

    .line 3
    iget-object v0, v0, Lda;->k:Ljava/util/ArrayList;

    .line 5
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 8
    move-result-object v0

    .line 9
    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 12
    move-result v1

    .line 13
    iget-object v2, p1, Loz;->i:Lda;

    .line 15
    if-eqz v1, :cond_2

    .line 17
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 20
    move-result-object v1

    .line 21
    check-cast v1, Lz9;

    .line 23
    instance-of v2, v1, Lda;

    .line 25
    if-eqz v2, :cond_1

    .line 27
    move-object v4, v1

    .line 28
    check-cast v4, Lda;

    .line 30
    const/4 v6, 0x0

    .line 31
    const/4 v8, 0x0

    .line 32
    move-object v3, p0

    .line 33
    move v5, p2

    .line 34
    move-object v7, p3

    .line 35
    invoke-virtual/range {v3 .. v8}, Lca;->a(Lda;IILjava/util/ArrayList;Ltq;)V

    .line 38
    goto :goto_0

    .line 39
    :cond_1
    instance-of v2, v1, Loz;

    .line 41
    if-eqz v2, :cond_0

    .line 43
    check-cast v1, Loz;

    .line 45
    iget-object v3, v1, Loz;->h:Lda;

    .line 47
    const/4 v5, 0x0

    .line 48
    const/4 v7, 0x0

    .line 49
    move-object v2, p0

    .line 50
    move v4, p2

    .line 51
    move-object v6, p3

    .line 52
    invoke-virtual/range {v2 .. v7}, Lca;->a(Lda;IILjava/util/ArrayList;Ltq;)V

    .line 55
    goto :goto_0

    .line 56
    :cond_2
    iget-object v0, v2, Lda;->k:Ljava/util/ArrayList;

    .line 58
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 61
    move-result-object v0

    .line 62
    :cond_3
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 65
    move-result v1

    .line 66
    if-eqz v1, :cond_5

    .line 68
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 71
    move-result-object v1

    .line 72
    check-cast v1, Lz9;

    .line 74
    instance-of v2, v1, Lda;

    .line 76
    if-eqz v2, :cond_4

    .line 78
    move-object v4, v1

    .line 79
    check-cast v4, Lda;

    .line 81
    const/4 v6, 0x1

    .line 82
    const/4 v8, 0x0

    .line 83
    move-object v3, p0

    .line 84
    move v5, p2

    .line 85
    move-object v7, p3

    .line 86
    invoke-virtual/range {v3 .. v8}, Lca;->a(Lda;IILjava/util/ArrayList;Ltq;)V

    .line 89
    goto :goto_1

    .line 90
    :cond_4
    instance-of v2, v1, Loz;

    .line 92
    if-eqz v2, :cond_3

    .line 94
    check-cast v1, Loz;

    .line 96
    iget-object v3, v1, Loz;->i:Lda;

    .line 98
    const/4 v5, 0x1

    .line 99
    const/4 v7, 0x0

    .line 100
    move-object v2, p0

    .line 101
    move v4, p2

    .line 102
    move-object v6, p3

    .line 103
    invoke-virtual/range {v2 .. v7}, Lca;->a(Lda;IILjava/util/ArrayList;Ltq;)V

    .line 106
    goto :goto_1

    .line 107
    :cond_5
    const/4 v0, 0x1

    .line 108
    if-ne p2, v0, :cond_7

    .line 110
    check-cast p1, Llx;

    .line 112
    iget-object p1, p1, Llx;->k:Lda;

    .line 114
    iget-object p1, p1, Lda;->k:Ljava/util/ArrayList;

    .line 116
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 119
    move-result-object p1

    .line 120
    :cond_6
    :goto_2
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 123
    move-result v0

    .line 124
    if-eqz v0, :cond_7

    .line 126
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 129
    move-result-object v0

    .line 130
    check-cast v0, Lz9;

    .line 132
    instance-of v1, v0, Lda;

    .line 134
    if-eqz v1, :cond_6

    .line 136
    move-object v3, v0

    .line 137
    check-cast v3, Lda;

    .line 139
    const/4 v5, 0x2

    .line 140
    const/4 v7, 0x0

    .line 141
    move-object v2, p0

    .line 142
    move v4, p2

    .line 143
    move-object v6, p3

    .line 144
    invoke-virtual/range {v2 .. v7}, Lca;->a(Lda;IILjava/util/ArrayList;Ltq;)V

    .line 147
    goto :goto_2

    .line 148
    :cond_7
    return-void
.end method

.method public final f(Ld8;IIII)V
    .locals 1

    .line 1
    iget-object v0, p0, Lca;->g:Lz3$a;

    .line 3
    iput p2, v0, Lz3$a;->a:I

    .line 5
    iput p4, v0, Lz3$a;->b:I

    .line 7
    iput p3, v0, Lz3$a;->c:I

    .line 9
    iput p5, v0, Lz3$a;->d:I

    .line 11
    iget-object p2, p0, Lca;->f:Lz3$b;

    .line 13
    check-cast p2, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    .line 15
    invoke-virtual {p2, p1, v0}, Landroidx/constraintlayout/widget/ConstraintLayout$b;->b(Ld8;Lz3$a;)V

    .line 18
    iget p2, v0, Lz3$a;->e:I

    .line 20
    invoke-virtual {p1, p2}, Ld8;->O(I)V

    .line 23
    iget p2, v0, Lz3$a;->f:I

    .line 25
    invoke-virtual {p1, p2}, Ld8;->L(I)V

    .line 28
    iget-boolean p2, v0, Lz3$a;->h:Z

    .line 30
    iput-boolean p2, p1, Ld8;->F:Z

    .line 32
    iget p2, v0, Lz3$a;->g:I

    .line 34
    iput p2, p1, Ld8;->d0:I

    .line 36
    if-lez p2, :cond_0

    .line 38
    const/4 p2, 0x1

    .line 39
    goto :goto_0

    .line 40
    :cond_0
    const/4 p2, 0x0

    .line 41
    :goto_0
    iput-boolean p2, p1, Ld8;->F:Z

    .line 43
    return-void
.end method

.method public final g()V
    .locals 13

    .line 1
    iget-object v0, p0, Lca;->a:Le8;

    .line 3
    iget-object v0, v0, Lmz;->s0:Ljava/util/ArrayList;

    .line 5
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 8
    move-result-object v0

    .line 9
    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_b

    .line 15
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 18
    move-result-object v1

    .line 19
    check-cast v1, Ld8;

    .line 21
    iget-boolean v2, v1, Ld8;->a:Z

    .line 23
    if-eqz v2, :cond_1

    .line 25
    goto :goto_0

    .line 26
    :cond_1
    iget-object v2, v1, Ld8;->V:[I

    .line 28
    const/4 v3, 0x0

    .line 29
    aget v8, v2, v3

    .line 31
    const/4 v9, 0x1

    .line 32
    aget v10, v2, v9

    .line 34
    iget v2, v1, Ld8;->s:I

    .line 36
    iget v4, v1, Ld8;->t:I

    .line 38
    const/4 v5, 0x2

    .line 39
    const/4 v11, 0x3

    .line 40
    if-eq v8, v5, :cond_3

    .line 42
    if-ne v8, v11, :cond_2

    .line 44
    if-ne v2, v9, :cond_2

    .line 46
    goto :goto_1

    .line 47
    :cond_2
    const/4 v2, 0x0

    .line 48
    goto :goto_2

    .line 49
    :cond_3
    :goto_1
    const/4 v2, 0x1

    .line 50
    :goto_2
    if-eq v10, v5, :cond_4

    .line 52
    if-ne v10, v11, :cond_5

    .line 54
    if-ne v4, v9, :cond_5

    .line 56
    :cond_4
    const/4 v3, 0x1

    .line 57
    :cond_5
    iget-object v4, v1, Ld8;->d:Lng;

    .line 59
    iget-object v4, v4, Loz;->e:Lia;

    .line 61
    iget-boolean v5, v4, Lda;->j:Z

    .line 63
    iget-object v6, v1, Ld8;->e:Llx;

    .line 65
    iget-object v6, v6, Loz;->e:Lia;

    .line 67
    iget-boolean v7, v6, Lda;->j:Z

    .line 69
    const/4 v12, 0x1

    .line 70
    if-eqz v5, :cond_6

    .line 72
    if-eqz v7, :cond_6

    .line 74
    iget v5, v4, Lda;->g:I

    .line 76
    iget v7, v6, Lda;->g:I

    .line 78
    const/4 v6, 0x1

    .line 79
    move-object v2, p0

    .line 80
    move-object v3, v1

    .line 81
    move v4, v6

    .line 82
    invoke-virtual/range {v2 .. v7}, Lca;->f(Ld8;IIII)V

    .line 85
    iput-boolean v9, v1, Ld8;->a:Z

    .line 87
    goto :goto_3

    .line 88
    :cond_6
    if-eqz v5, :cond_8

    .line 90
    if-eqz v3, :cond_8

    .line 92
    iget v5, v4, Lda;->g:I

    .line 94
    iget v7, v6, Lda;->g:I

    .line 96
    const/4 v4, 0x1

    .line 97
    const/4 v6, 0x2

    .line 98
    move-object v2, p0

    .line 99
    move-object v3, v1

    .line 100
    invoke-virtual/range {v2 .. v7}, Lca;->f(Ld8;IIII)V

    .line 103
    if-ne v10, v11, :cond_7

    .line 105
    iget-object v2, v1, Ld8;->e:Llx;

    .line 107
    iget-object v2, v2, Loz;->e:Lia;

    .line 109
    invoke-virtual {v1}, Ld8;->l()I

    .line 112
    move-result v3

    .line 113
    iput v3, v2, Lia;->m:I

    .line 115
    goto :goto_3

    .line 116
    :cond_7
    iget-object v2, v1, Ld8;->e:Llx;

    .line 118
    iget-object v2, v2, Loz;->e:Lia;

    .line 120
    invoke-virtual {v1}, Ld8;->l()I

    .line 123
    move-result v3

    .line 124
    invoke-virtual {v2, v3}, Lia;->d(I)V

    .line 127
    iput-boolean v9, v1, Ld8;->a:Z

    .line 129
    goto :goto_3

    .line 130
    :cond_8
    if-eqz v7, :cond_a

    .line 132
    if-eqz v2, :cond_a

    .line 134
    iget v5, v4, Lda;->g:I

    .line 136
    iget v7, v6, Lda;->g:I

    .line 138
    const/4 v4, 0x2

    .line 139
    move-object v2, p0

    .line 140
    move-object v3, v1

    .line 141
    move v6, v12

    .line 142
    invoke-virtual/range {v2 .. v7}, Lca;->f(Ld8;IIII)V

    .line 145
    if-ne v8, v11, :cond_9

    .line 147
    iget-object v2, v1, Ld8;->d:Lng;

    .line 149
    iget-object v2, v2, Loz;->e:Lia;

    .line 151
    invoke-virtual {v1}, Ld8;->r()I

    .line 154
    move-result v3

    .line 155
    iput v3, v2, Lia;->m:I

    .line 157
    goto :goto_3

    .line 158
    :cond_9
    iget-object v2, v1, Ld8;->d:Lng;

    .line 160
    iget-object v2, v2, Loz;->e:Lia;

    .line 162
    invoke-virtual {v1}, Ld8;->r()I

    .line 165
    move-result v3

    .line 166
    invoke-virtual {v2, v3}, Lia;->d(I)V

    .line 169
    iput-boolean v9, v1, Ld8;->a:Z

    .line 171
    :cond_a
    :goto_3
    iget-boolean v2, v1, Ld8;->a:Z

    .line 173
    if-eqz v2, :cond_0

    .line 175
    iget-object v2, v1, Ld8;->e:Llx;

    .line 177
    iget-object v2, v2, Llx;->l:Lx3;

    .line 179
    if-eqz v2, :cond_0

    .line 181
    iget v1, v1, Ld8;->d0:I

    .line 183
    invoke-virtual {v2, v1}, Lia;->d(I)V

    .line 186
    goto/16 :goto_0

    .line 188
    :cond_b
    return-void
.end method
