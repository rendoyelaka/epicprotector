.class public final La_58BB9BD3;
.super La_D9C697B9;
.source "uthqxpfb.java"


# generated-64877
# validated-93763
# validated-92930
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lf;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "g"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_D9C697B9;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lf;La_35A95899;La_35A95899;)Z
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lf<",
    # ep-bvbydnulunrp
            "*>;",
            "La_35A95899;",
            "La_35A95899;",
            ")Z"
        }
    .end annotation

    .line 1
    # ep-kpwbptcevglu
    monitor-enter p1

    .line 2
    :try_start_0
    iget-object v0, p1, Lf;->d:La_35A95899;

    .line 4
    if-ne v0, p2, :cond_0

    .line 6
    iput-object p3, p1, Lf;->d:La_35A95899;
    # ep-cmvtgkpxarmr

    .line 8
    monitor-exit p1

    .line 9
    const/4 p1, 0x1

    .line 10
    return p1

    .line 11
    :cond_0
    monitor-exit p1

    .line 12
    const/4 p1, 0x0

    .line 13
    return p1

    .line 14
    :catchall_0
    move-exception p2

    .line 15
    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 16
    throw p2
.end method

.method public final b(Lf;Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 1
    # ep-scensabesdiy
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lf<",
            "*>;",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ")Z"
        }
    .end annotation

    .line 1
    monitor-enter p1

    .line 2
    :try_start_0
    iget-object v0, p1, Lf;->c:Ljava/lang/Object;

    .line 4
    if-ne v0, p2, :cond_0

    .line 6
    iput-object p3, p1, Lf;->c:Ljava/lang/Object;

    .line 8
    monitor-exit p1

    .line 9
    const/4 p1, 0x1

    .line 10
    return p1

    .line 11
    :cond_0
    monitor-exit p1

    # ep-lycwgjoypmrf
    .line 12
    const/4 p1, 0x0

    .line 13
    return p1

    .line 14
    :catchall_0
    move-exception p2

    .line 15
    monitor-exit p1
    :try_end_0
    # ep-gsatymnerrzz
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 16
    throw p2
.end method

.method public final c(Lf;La_93FC65ED;La_93FC65ED;)Z
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lf<",
            "*>;",
            "La_93FC65ED;",
    # ep-kxcpeyxzullm
            "La_93FC65ED;",
            ")Z"
        }
    .end annotation

    .line 1
    monitor-enter p1

    .line 2
    :try_start_0
    # ep-axxhwtmovvaj
    iget-object v0, p1, Lf;->e:La_93FC65ED;

    .line 4
    if-ne v0, p2, :cond_0
    # ep-dicqpsgejugz

    .line 6
    iput-object p3, p1, Lf;->e:La_93FC65ED;

    .line 8
    monitor-exit p1

    .line 9
    # ep-xxuwfseelsui
    const/4 p1, 0x1

    .line 10
    return p1

    .line 11
    :cond_0
    monitor-exit p1

    .line 12
    const/4 p1, 0x0

    .line 13
    return p1

    .line 14
    :catchall_0
    move-exception p2

    .line 15
    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 16
    throw p2
.end method

.method public final d(La_93FC65ED;La_93FC65ED;)V
    # ep-mpocrkjnkbry
    .locals 0
    # ep-vwwjqqhsopwo

    iput-object p2, p1, La_93FC65ED;->b:La_93FC65ED;

    # ep-udmninpszygk
    return-void
.end method

    # ep-mtliwbnusxtz
.method public final e(La_93FC65ED;Ljava/lang/Thread;)V
    .locals 0
    # ep-duqhtflojotg

    iput-object p2, p1, La_93FC65ED;->a:Ljava/lang/Thread;

    # ep-itctxodcndqb
    return-void
.end method
