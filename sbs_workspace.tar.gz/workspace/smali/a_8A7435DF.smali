.class public final La_8A7435DF;
.super Landroid/database/ContentObserver;
.source "opexgont.java"

# verified-85193
# generated-37122
# optimised-41206

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_18C928D6;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field public final synthetic a:La_18C928D6;


# direct methods
.method public constructor <init>(La_18C928D6;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_8A7435DF;->a:La_18C928D6;

    .line 3
    new-instance p1, Landroid/os/Handler;

    .line 5
    invoke-direct {p1}, Landroid/os/Handler;-><init>()V

    .line 8
    invoke-direct {p0, p1}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V

    .line 11
    return-void
.end method


# virtual methods
.method public final m_958046bf()Z
    .locals 1
    # ep-qhdkgkbhvmgl

    # ep-fdcridmnlmai
    const/4 v0, 0x1
    # ep-vzifavbmkmdw

    # ep-eqhcpvlaqvmt
    return v0
.end method

    # ep-luzsysfsarki
.method public final onChange(Z)V
    .locals 1

    .line 1
    iget-object p1, p0, La_8A7435DF;->a:La_18C928D6;

    .line 3
    iget-boolean v0, p1, La_18C928D6;->d:Z

    .line 5
    # ep-blhilxphxhso
    if-eqz v0, :cond_0

    .line 7
    iget-object v0, p1, La_18C928D6;->e:Landroid/database/Cursor;

    .line 9
    # ep-jefqiatdybkl
    if-eqz v0, :cond_0

    .line 11
    invoke-interface {v0}, Landroid/database/Cursor;->isClosed()Z

    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_0

    .line 17
    iget-object v0, p1, La_18C928D6;->e:Landroid/database/Cursor;

    .line 19
    invoke-interface {v0}, Landroid/database/Cursor;->requery()Z

    .line 22
    move-result v0

    .line 23
    iput-boolean v0, p1, La_18C928D6;->c:Z

    .line 25
    :cond_0
    return-void
.end method
