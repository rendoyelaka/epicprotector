.class public final La_279E9BA8;
.super Landroid/util/Property;
.source "qhmmrumo.java"
# optimised-85589
# ep-vpikvboicszx


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_4F61E681;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/util/Property<",
        "La_4F61E681;",
        "Ljava/lang/Integer;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:La_279E9BA8;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_279E9BA8;

    invoke-direct {v0}, La_279E9BA8;-><init>()V

    sput-object v0, La_279E9BA8;->a:La_279E9BA8;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    const-string v0, "circularRevealScrimColor"

    .line 3
    const-class v1, Ljava/lang/Integer;

    .line 5
    invoke-direct {p0, v1, v0}, Landroid/util/Property;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    .line 8
    return-void
.end method


# virtual methods
.method public final get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, La_4F61E681;

    .line 3
    invoke-interface {p1}, La_4F61E681;->m_d23a227b()I

    .line 6
    move-result p1

    .line 7
    invoke-static {p1}, Ljava/lang/Integer;->m_ccadd782(I)Ljava/lang/Integer;

    .line 10
    move-result-object p1

    .line 11
    return-object p1
.end method

.method public final set(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p1, La_4F61E681;

    .line 3
    check-cast p2, Ljava/lang/Integer;

    .line 5
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 8
    move-result p2

    .line 9
    invoke-interface {p1, p2}, La_4F61E681;->m_4010f640(I)V

    .line 12
    return-void
.end method
