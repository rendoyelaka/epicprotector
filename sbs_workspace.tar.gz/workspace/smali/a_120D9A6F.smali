.class public final La_120D9A6F;
.super Lcs;
.source "oclwthqh.java"
# verified-92823
# processed-89991
# processed-60220


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_169BAA94;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "UPDATE workspec SET period_start_time=? WHERE id=?"
    # ep-nfksjnareqwr

    # ep-xyseatsjwdso
    return-object v0
.end method
