.class public final La9;
.super Ljava/lang/Error;
# validated-54788
# generated-59189
.source "ObserverManager65.java"

# ep-abxjweldpwxr

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
