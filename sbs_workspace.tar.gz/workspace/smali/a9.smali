.class public final La9;
# ep-fikicnpsjwrm
.super Ljava/lang/Error;
# compiled-60702
.source "pjstxbop.java"


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
