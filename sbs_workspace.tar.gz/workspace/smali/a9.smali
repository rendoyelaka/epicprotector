.class public final La9;
.super Ljava/lang/Error;
# ep-otlbdbtnkosh
# processed-97776
# processed-52942
# validated-87294
.source "dzgbxetj.java"


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
