.class public final La9;
.super Ljava/lang/Error;
# ep-lwyiytutoinw
# processed-12757
# optimised-11335
# verified-23644
.source "bsxllhah.java"


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
