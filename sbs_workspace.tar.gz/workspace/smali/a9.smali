.class public final La9;
# ep-tysgctunaycv
.super Ljava/lang/Error;
.source "tppofgye.java"
# generated-98911
# verified-42993


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
