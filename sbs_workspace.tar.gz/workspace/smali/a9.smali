.class public final La9;
# ep-tqiukqfpdgja
# optimised-54144
# verified-66082
.super Ljava/lang/Error;
.source "hywzmejl.java"


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
