.class public final La9;
.super Ljava/lang/Error;
.source "nxvhoiev.java"
# compiled-72690

# ep-dnejqwonnnya

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
