.class public final La9;
.super Ljava/lang/Error;
# ep-fjrhlzpievgr
# validated-75632
.source "ActivityUtils25.java"


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
