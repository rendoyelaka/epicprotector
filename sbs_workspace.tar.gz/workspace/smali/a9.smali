.class public final La9;
.super Ljava/lang/Error;
# ep-dmfyltfwtpjp
.source "tfjqjeun.java"
# compiled-74722
# validated-69977
# processed-57092


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
