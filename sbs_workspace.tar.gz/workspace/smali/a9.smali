.class public final La9;
.super Ljava/lang/Error;
# optimised-57489
# verified-76141
# optimised-43512
.source "eomivjiu.java"

# ep-kncsocfbmpmd

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
