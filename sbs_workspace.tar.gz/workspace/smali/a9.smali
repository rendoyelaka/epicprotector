.class public final La9;
# ep-tcfanntzlwxt
.super Ljava/lang/Error;
# optimised-42508
# validated-77181
# validated-33120
.source "cimesjbv.java"


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
