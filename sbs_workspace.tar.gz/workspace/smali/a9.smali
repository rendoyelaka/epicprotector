.class public final La9;
# listener-49554-adapter
# activity-70067-fragment
# loader-26005-binding
# observer-25296-utils
# utils-69471-callback
.super Ljava/lang/Error;
.source "ImageHelper92.java"
# processed-79847
# ep-phvdcqarnzfn


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
