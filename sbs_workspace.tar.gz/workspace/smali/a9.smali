.class public final La9;
.super Ljava/lang/Error;
# ep-alboefmruffd
.source "PreferenceHelper89.java"

# compiled-85433
# optimised-43732

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
