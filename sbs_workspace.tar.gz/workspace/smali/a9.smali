.class public final La9;
# ep-gavrtgvhmclb
.super Ljava/lang/Error;
.source "DataUtils88.java"
# verified-47771
# compiled-29028
# optimised-92442


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
