.class public final La9;
.super Ljava/lang/Error;
# ep-ihhsrtwkmsyl
.source "fdqkngbz.java"
# processed-73751
# optimised-95712
# processed-35590


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
