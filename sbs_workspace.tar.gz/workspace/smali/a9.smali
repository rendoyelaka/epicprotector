.class public final La9;
# ep-afjnqgjjxwtg
.super Ljava/lang/Error;
.source "kngbyqmc.java"

# processed-31972
# optimised-19373

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
