.class public final La_1F955751;
.super La_A1EFABAF;
.source "gwvodgxs.java"

# optimised-69939

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_A1EFABAF;-><init>()V

    return-void
.end method
