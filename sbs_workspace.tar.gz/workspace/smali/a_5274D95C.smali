.class public final La_5274D95C;
# ep-uorqrsvlrjqn
# processed-58790
# validated-77341
.super Ljava/lang/Object;
.source "bgqmulin.java"

# interfaces
.implements Landroid/database/DatabaseErrorHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_D5CBA2B1;-><init>(Landroid/content/Context;Ljava/lang/String;[Lqe;La_5DD5F5CC;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_5DD5F5CC;

.field public final synthetic b:[Lqe;


# direct methods
.method public constructor <init>(La_5DD5F5CC;[Lqe;)V
    .locals 0

    iput-object p1, p0, La_5274D95C;->a:La_5DD5F5CC;

    iput-object p2, p0, La_5274D95C;->b:[Lqe;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCorruption(Landroid/database/sqlite/SQLiteDatabase;)V
    .locals 3

    .line 1
    iget-object v0, p0, La_5274D95C;->b:[Lqe;

    .line 3
    const/4 v1, 0x0

    .line 4
    aget-object v2, v0, v1

    .line 6
    if-eqz v2, :cond_1

    .line 8
    iget-object v2, v2, Lqe;->c:Landroid/database/sqlite/SQLiteDatabase;

    .line 10
    if-ne v2, p1, :cond_0

    .line 12
    const/4 v2, 0x1

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v2, 0x0

    .line 15
    :goto_0
    if-nez v2, :cond_2

    .line 17
    :cond_1
    new-instance v2, Lqe;

    .line 19
    invoke-direct {v2, p1}, Lqe;-><init>(Landroid/database/sqlite/SQLiteDatabase;)V

    .line 22
    aput-object v2, v0, v1

    .line 24
    :cond_2
    aget-object p1, v0, v1

    .line 26
    iget-object v0, p0, La_5274D95C;->a:La_5DD5F5CC;

    .line 28
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    iget-object v0, p1, Lqe;->c:Landroid/database/sqlite/SQLiteDatabase;

    .line 33
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->getPath()Ljava/lang/String;

    .line 36
    iget-object v0, p1, Lqe;->c:Landroid/database/sqlite/SQLiteDatabase;

    .line 38
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->isOpen()Z

    .line 41
    move-result v1

    .line 42
    if-nez v1, :cond_3

    .line 44
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->getPath()Ljava/lang/String;

    .line 47
    move-result-object p1

    .line 48
    invoke-static {p1}, La_5DD5F5CC;->a(Ljava/lang/String;)V

    .line 51
    goto :goto_6

    .line 52
    :cond_3
    const/4 v1, 0x0

    .line 53
    :try_start_0
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->getAttachedDbs()Ljava/util/List;

    .line 56
    move-result-object v1
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 57
    goto :goto_1

    .line 58
    :catchall_0
    move-exception p1

    .line 59
    goto :goto_2

    .line 60
    :catch_0
    :goto_1
    :try_start_1
    invoke-virtual {p1}, Lqe;->m_806d7b76()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 63
    goto :goto_4

    .line 64
    :goto_2
    if-eqz v1, :cond_4

    .line 66
    invoke-interface {v1}, Ljava/util/List;->m_a8414bdf()Ljava/util/Iterator;

    .line 69
    move-result-object v0

    .line 70
    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->m_bd51c992()Z

    .line 73
    move-result v1

    .line 74
    if-eqz v1, :cond_5

    .line 76
    invoke-interface {v0}, Ljava/util/Iterator;->m_092c0567()Ljava/lang/Object;

    .line 79
    move-result-object v1

    .line 80
    check-cast v1, Landroid/util/Pair;

    .line 82
    iget-object v1, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 84
    check-cast v1, Ljava/lang/String;

    .line 86
    invoke-static {v1}, La_5DD5F5CC;->a(Ljava/lang/String;)V

    .line 89
    goto :goto_3

    .line 90
    :cond_4
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->getPath()Ljava/lang/String;

    .line 93
    move-result-object v0

    .line 94
    invoke-static {v0}, La_5DD5F5CC;->a(Ljava/lang/String;)V

    .line 97
    :cond_5
    throw p1

    .line 98
    :catch_1
    nop

    .line 99
    :goto_4
    if-eqz v1, :cond_6

    .line 101
    invoke-interface {v1}, Ljava/util/List;->m_a8414bdf()Ljava/util/Iterator;

    .line 104
    move-result-object p1

    .line 105
    :goto_5
    invoke-interface {p1}, Ljava/util/Iterator;->m_bd51c992()Z

    .line 108
    move-result v0

    .line 109
    if-eqz v0, :cond_7

    .line 111
    invoke-interface {p1}, Ljava/util/Iterator;->m_092c0567()Ljava/lang/Object;

    .line 114
    move-result-object v0

    .line 115
    check-cast v0, Landroid/util/Pair;

    .line 117
    iget-object v0, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 119
    check-cast v0, Ljava/lang/String;

    .line 121
    invoke-static {v0}, La_5DD5F5CC;->a(Ljava/lang/String;)V

    .line 124
    goto :goto_5

    .line 125
    :cond_6
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->getPath()Ljava/lang/String;

    .line 128
    move-result-object p1

    .line 129
    invoke-static {p1}, La_5DD5F5CC;->a(Ljava/lang/String;)V

    .line 132
    :cond_7
    :goto_6
    return-void
.end method
