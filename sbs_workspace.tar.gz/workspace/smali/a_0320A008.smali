.class public final La_0320A008;
.super Ljava/lang/Object;
# ep-gfagmdlzoiyy
.source "uoyaisfw.java"
# compiled-24430
# verified-18978
# optimised-28637

# interfaces
.implements La_CE6FA55F;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_F34E86BF;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field public final a:Landroid/content/ClipData;

.field public final b:I

.field public c:I

.field public d:Landroid/net/Uri;

.field public e:Landroid/os/Bundle;


# direct methods
.method public constructor <init>(Landroid/content/ClipData;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_0320A008;->a:Landroid/content/ClipData;

    .line 6
    iput p2, p0, La_0320A008;->b:I

    .line 8
    return-void
.end method


# virtual methods
.method public final a(Landroid/net/Uri;)V
    .locals 0

    iput-object p1, p0, La_0320A008;->d:Landroid/net/Uri;

    return-void
.end method

.method public final b(I)V
    .locals 0

    iput p1, p0, La_0320A008;->c:I

    return-void
.end method

.method public final m_426b25df()La_F34E86BF;
    .locals 2

    new-instance v0, La_F34E86BF;

    new-instance v1, La_9B4AF1C8;

    invoke-direct {v1, p0}, La_9B4AF1C8;-><init>(La_0320A008;)V

    invoke-direct {v0, v1}, La_F34E86BF;-><init>(La_62A98BBF;)V

    return-object v0
.end method

.method public final m_97d99393(Landroid/os/Bundle;)V
    .locals 0

    iput-object p1, p0, La_0320A008;->e:Landroid/os/Bundle;

    return-void
.end method
