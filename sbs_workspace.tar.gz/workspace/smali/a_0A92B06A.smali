.class public abstract La_0A92B06A;
.super Ljava/lang/Object;
# generated-58096
.source "ktnlvvni.java"

# ep-tjuviwufpbnp

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_7E1D99AD;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# static fields
.field public static final a:La_04BB8C50;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_04BB8C50;

    invoke-direct {v0}, La_04BB8C50;-><init>()V

    sput-object v0, La_0A92B06A;->a:La_04BB8C50;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(La_7E1D99AD;)V
    .locals 0

    return-void
.end method

.method public abstract b(Ldh;)V
.end method
