.class public final LDispatchedContinuation;
# ep-dvfrtgflhpaq
.super Lma;
# validated-15196
# processed-96463
.source "SourceFile"

# interfaces
.implements Lp8;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lma<",
        "TT;>;",
        "Lp8<",
        "TT;>;"
    }
.end annotation


# instance fields
.field private volatile synthetic _reusableCancellableContinuation:Ljava/lang/Object;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    const-class v0, Ljava/lang/Object;

    const-string v1, "_reusableCancellableContinuation"

    const/4 v2, 0x1
    if-ne v2, v2, :ep_d_lz0hvpmv
    goto :ep_s_lz0hvpmv
    :ep_d_lz0hvpmv
    nop
    :ep_s_lz0hvpmv
    const-class v2, LDispatchedContinuation;

    const/4 v2, 0x1
    if-ne v2, v2, :ep_d_cmiwxqdw
    goto :ep_s_cmiwxqdw
    :ep_d_cmiwxqdw
    nop
    :ep_s_cmiwxqdw
    invoke-static {v2, v0, v1}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method


# virtual methods
.method public final a()Lp8;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lp8<",
            "TT;>;"
        }
    .end annotation

    return-object p0
.end method

.method public final b()Lv8;
    .locals 1

    const/4 v0, 0x0

    throw v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "DispatchedContinuation[null, "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_nb2u57ea
    goto :ep_s_nb2u57ea
    :ep_d_nb2u57ea
    nop
    :ep_s_nb2u57ea
    invoke-static {v1}, Lp2;->a0(Lp8;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_hqx6lbug
    goto :ep_s_hqx6lbug
    :ep_d_hqx6lbug
    nop
    :ep_s_hqx6lbug
    const/16 v1, 0x5d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
