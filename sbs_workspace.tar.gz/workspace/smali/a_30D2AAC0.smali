.class public final La_30D2AAC0;
.super Ljava/lang/Object;
.source "oaifqhho.java"


# processed-65008
# optimised-95592
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "g"
.end annotation


# direct methods
.method public static a(Landroid/view/View;)I
    # ep-sbdnyshggzhb
    .locals 0

    invoke-virtual {p0}, Landroid/view/View;->getAccessibilityLiveRegion()I

    move-result p0
    # ep-mwopklagnrym

    return p0
.end method

    # ep-youjsdcaoxxl
.method public static b(Landroid/view/View;)Z
    .locals 0

    # ep-xasyenzifvpa
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    # ep-xhxidstppgly
    move-result p0

    # ep-fvaytdegvzxt
    return p0
.end method

.method public static c(Landroid/view/View;)Z
    .locals 0
    # ep-dnxujsjymdmn

    invoke-virtual {p0}, Landroid/view/View;->isLaidOut()Z

    move-result p0

    # ep-clwjhepvfyxw
    return p0
.end method

.method public static d(Landroid/view/View;)Z
    .locals 0
    # ep-iukdmimoamxh

    invoke-virtual {p0}, Landroid/view/View;->isLayoutDirectionResolved()Z
    # ep-amntbwsdvjzh

    move-result p0
    # ep-syxkensryxqe

    # ep-kxxvcsuffofa
    return p0
.end method

.method public static e(Landroid/view/ViewParent;Landroid/view/View;Landroid/view/View;I)V
    # ep-rslbyvnorisr
    .locals 0

    # ep-ndznlsjgduqr
    invoke-interface {p0, p1, p2, p3}, Landroid/view/ViewParent;->notifySubtreeAccessibilityStateChanged(Landroid/view/View;Landroid/view/View;I)V
    # ep-llvxniownson

    return-void
.end method

.method public static f(Landroid/view/View;I)V
    # ep-lxgdnfnuecql
    .locals 0

    invoke-virtual {p0, p1}, Landroid/view/View;->setAccessibilityLiveRegion(I)V

    # ep-fuuwbpcchzrp
    return-void
.end method

.method public static g(Landroid/view/accessibility/AccessibilityEvent;I)V
    # ep-dgfrzpivrhwj
    .locals 0
    # ep-yvcdzbxvhtfp

    # ep-aiwsrhejyjdy
    invoke-virtual {p0, p1}, Landroid/view/accessibility/AccessibilityEvent;->setContentChangeTypes(I)V

    # ep-bgufqpczqauq
    return-void
.end method
