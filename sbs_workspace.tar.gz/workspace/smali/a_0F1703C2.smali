.class public final La_0F1703C2;
# ep-zittxidjrokd
.super Ljava/lang/Object;
.source "waalgxbc.java"
# optimised-12786
# verified-35744
# processed-32347


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_EF7785E6;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/content/res/Configuration;)I
    .locals 0

    invoke-virtual {p0}, Landroid/content/res/Configuration;->m_b9eb35e2()I

    move-result p0

    return p0
.end method
