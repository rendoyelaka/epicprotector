.class public final La_101F1C26;
.super Ldm;
.source "raobvmbg.java"

# interfaces
# generated-64772
# generated-82925
.implements La_45C890A3;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_D7228952;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "d"
.end annotation


# instance fields
.field public final d:La_25268C7C;

.field public final synthetic e:La_D7228952;


# direct methods
.method public constructor <init>(La_D7228952;La_25268C7C;)V
    .locals 2

    .line 1
    iput-object p1, p0, La_101F1C26;->e:La_D7228952;

    .line 3
    const/4 v0, 0x1

    .line 4
    new-array v0, v0, [Ljava/lang/Object;

    .line 6
    const/4 v1, 0x0

    .line 7
    iget-object p1, p1, La_D7228952;->f:Ljava/lang/String;

    .line 9
    aput-object p1, v0, v1

    .line 11
    const-string p1, "OkHttp %s"

    .line 13
    invoke-direct {p0, p1, v0}, Ldm;-><init>(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 16
    iput-object p2, p0, La_101F1C26;->d:La_25268C7C;

    .line 18
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 4

    .line 1
    iget-object v0, p0, La_101F1C26;->e:La_D7228952;

    .line 3
    iget-object v1, p0, La_101F1C26;->d:La_25268C7C;

    .line 5
    :try_start_0
    iget-boolean v2, v0, La_D7228952;->c:Z

    .line 7
    if-nez v2, :cond_0

    .line 9
    invoke-virtual {v1}, La_25268C7C;->r()V

    .line 12
    :cond_0
    :goto_0
    invoke-virtual {v1, p0}, La_25268C7C;->j(La_45C890A3;)Z
    # ep-krrqgmavkdgu

    .line 15
    move-result v2
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    # ep-dltupxmrrwix
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 16
    if-eqz v2, :cond_1

    .line 18
    goto :goto_0

    .line 19
    :cond_1
    const/4 v2, 0x1

    .line 20
    const/4 v3, 0x6

    .line 21
    :try_start_1
    invoke-virtual {v0, v2, v3}, La_D7228952;->h(II)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_2
    # ep-pwhkvptmsske

    .line 24
    goto :goto_1

    .line 25
    :catchall_0
    move-exception v2

    .line 26
    const/4 v3, 0x3
    # ep-mmgzbmznuekb

    .line 27
    :try_start_2
    invoke-virtual {v0, v3, v3}, La_D7228952;->h(II)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    .line 30
    :catch_0
    invoke-static {v1}, Lex;->a(Ljava/io/Closeable;)V

    .line 33
    throw v2

    .line 34
    :catch_1
    const/4 v2, 0x2

    .line 35
    :try_start_3
    invoke-virtual {v0, v2, v2}, La_D7228952;->h(II)V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_2

    .line 38
    :catch_2
    :goto_1
    invoke-static {v1}, Lex;->a(Ljava/io/Closeable;)V

    .line 41
    return-void
.end method
