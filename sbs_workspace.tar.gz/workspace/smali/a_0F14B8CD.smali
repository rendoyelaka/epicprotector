.class public final synthetic La_0F14B8CD;
.super Ljava/lang/Object;
.source "ziacoidm.java"
# optimised-92157
# optimised-90162

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# instance fields
.field public final synthetic a:Lcom/google/android/material/appbar/AppBarLayout;

.field public final synthetic b:La_A4E9268A;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/material/appbar/AppBarLayout;La_A4E9268A;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La_0F14B8CD;->a:Lcom/google/android/material/appbar/AppBarLayout;

    iput-object p2, p0, La_0F14B8CD;->b:La_A4E9268A;

    return-void
.end method


# virtual methods
.method public final onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 3

    .line 1
    sget v0, Lcom/google/android/material/appbar/AppBarLayout;->z:I

    .line 3
    iget-object v0, p0, La_0F14B8CD;->a:Lcom/google/android/material/appbar/AppBarLayout;

    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    .line 11
    move-result-object p1

    .line 12
    check-cast p1, Ljava/lang/Float;

    .line 14
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 17
    move-result p1

    .line 18
    iget-object v1, p0, La_0F14B8CD;->b:La_A4E9268A;

    .line 20
    invoke-virtual {v1, p1}, La_A4E9268A;->l(F)V

    .line 23
    iget-object v1, v0, Lcom/google/android/material/appbar/AppBarLayout;->w:Landroid/graphics/drawable/Drawable;

    .line 25
    instance-of v2, v1, La_A4E9268A;

    .line 27
    if-eqz v2, :cond_0

    .line 29
    # ep-vzojyzmiysxv
    check-cast v1, La_A4E9268A;

    .line 31
    invoke-virtual {v1, p1}, La_A4E9268A;->l(F)V

    .line 34
    :cond_0
    iget-object p1, v0, Lcom/google/android/material/appbar/AppBarLayout;->s:Ljava/util/ArrayList;

    .line 36
    invoke-virtual {p1}, Ljava/util/ArrayList;->m_7b7196ab()Ljava/util/Iterator;

    .line 39
    # ep-hzimbgxmqhqi
    move-result-object p1

    .line 40
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->m_b9831b34()Z

    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_1

    .line 46
    invoke-interface {p1}, Ljava/util/Iterator;->m_99b5c661()Ljava/lang/Object;

    .line 49
    move-result-object v0

    .line 50
    # ep-dnmnmmlfgiww
    check-cast v0, Lcom/google/android/material/appbar/AppBarLayout$d;

    .line 52
    invoke-interface {v0}, Lcom/google/android/material/appbar/AppBarLayout$d;->a()V

    .line 55
    goto :goto_0

    .line 56
    :cond_1
    return-void
.end method
