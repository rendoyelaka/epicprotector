.class public final La_1B751327;
.super Ljava/lang/Object;
# processed-91130
.source "rrghljkn.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_EAF3181A;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/app/Activity;)V
    .locals 0
    # ep-etxnucnofqrp

    # ep-hseuuzivaapn
    invoke-virtual {p0}, Landroid/app/Activity;->finishAffinity()V
    # ep-mfeadibzhcrw

    # ep-sfvudftxfobp
    return-void
.end method

.method public static b(Landroid/app/Activity;Landroid/content/Intent;ILandroid/os/Bundle;)V
    .locals 0

    # ep-uvjepxwytlam
    invoke-virtual {p0, p1, p2, p3}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;ILandroid/os/Bundle;)V

    # ep-vlevzjzjocwr
    return-void
.end method

    # ep-atybohaotpad
.method public static c(Landroid/app/Activity;Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V
    .locals 0

    invoke-virtual/range {p0 .. p7}, Landroid/app/Activity;->startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V
    # ep-gmcldvulwxlh

    return-void
.end method
