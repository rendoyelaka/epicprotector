.class public final La_3903F91B;
.super Ljava/lang/Object;
.source "rybncgpj.java"
# compiled-42139
# generated-53646

# ep-fvzvasqvbsdj
# interfaces
.implements Landroid/widget/ListAdapter;
.implements Landroid/widget/SpinnerAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_2F7A58B8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "f"
.end annotation


# instance fields
.field public final c:Landroid/widget/SpinnerAdapter;

.field public final d:Landroid/widget/ListAdapter;


# direct methods
.method public constructor <init>(Landroid/widget/SpinnerAdapter;Landroid/content/res/Resources$Theme;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_3903F91B;->c:Landroid/widget/SpinnerAdapter;

    .line 6
    instance-of v0, p1, Landroid/widget/ListAdapter;

    .line 8
    if-eqz v0, :cond_0

    .line 10
    move-object v0, p1

    .line 11
    check-cast v0, Landroid/widget/ListAdapter;

    .line 13
    iput-object v0, p0, La_3903F91B;->d:Landroid/widget/ListAdapter;

    .line 15
    :cond_0
    if-eqz p2, :cond_2

    .line 17
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 19
    const/16 v1, 0x17

    .line 21
    if-lt v0, v1, :cond_1

    .line 23
    instance-of v0, p1, Landroid/widget/ThemedSpinnerAdapter;

    .line 25
    if-eqz v0, :cond_1

    .line 27
    check-cast p1, Landroid/widget/ThemedSpinnerAdapter;

    .line 29
    invoke-static {p1, p2}, La_6F5987FB;->a(Landroid/widget/ThemedSpinnerAdapter;Landroid/content/res/Resources$Theme;)V

    .line 32
    goto :goto_0

    .line 33
    :cond_1
    instance-of p2, p1, Lbv;

    .line 35
    if-eqz p2, :cond_2

    .line 37
    check-cast p1, Lbv;

    .line 39
    invoke-interface {p1}, Lbv;->getDropDownViewTheme()Landroid/content/res/Resources$Theme;

    .line 42
    move-result-object p2

    .line 43
    if-nez p2, :cond_2

    .line 45
    invoke-interface {p1}, Lbv;->a()V

    .line 48
    :cond_2
    :goto_0
    return-void
.end method


# virtual methods
.method public final m_9aaeee32()Z
    .locals 1

    .line 1
    iget-object v0, p0, La_3903F91B;->d:Landroid/widget/ListAdapter;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-interface {v0}, Landroid/widget/ListAdapter;->m_9aaeee32()Z

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    const/4 v0, 0x1

    .line 11
    return v0
.end method

.method public final getCount()I
    .locals 1

    iget-object v0, p0, La_3903F91B;->c:Landroid/widget/SpinnerAdapter;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-interface {v0}, Landroid/widget/Adapter;->getCount()I

    move-result v0

    :goto_0
    return v0
.end method

.method public final m_09c2c240(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, La_3903F91B;->c:Landroid/widget/SpinnerAdapter;

    .line 3
    if-nez v0, :cond_0

    .line 5
    const/4 p1, 0x0

    .line 6
    goto :goto_0

    .line 7
    :cond_0
    invoke-interface {v0, p1, p2, p3}, Landroid/widget/SpinnerAdapter;->m_09c2c240(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    .line 10
    move-result-object p1

    .line 11
    :goto_0
    return-object p1
.end method

.method public final getItem(I)Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, La_3903F91B;->c:Landroid/widget/SpinnerAdapter;

    if-nez v0, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    invoke-interface {v0, p1}, Landroid/widget/Adapter;->getItem(I)Ljava/lang/Object;

    move-result-object p1

    :goto_0
    return-object p1
.end method

.method public final getItemId(I)J
    .locals 2

    iget-object v0, p0, La_3903F91B;->c:Landroid/widget/SpinnerAdapter;

    if-nez v0, :cond_0

    const-wide/16 v0, -0x1

    goto :goto_0

    :cond_0
    invoke-interface {v0, p1}, Landroid/widget/Adapter;->getItemId(I)J

    move-result-wide v0

    :goto_0
    return-wide v0
.end method

.method public final getItemViewType(I)I
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public final getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 0

    invoke-virtual {p0, p1, p2, p3}, La_3903F91B;->m_09c2c240(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

.method public final getViewTypeCount()I
    .locals 1

    const/4 v0, 0x1

    return v0
.end method

.method public final m_94ad2c13()Z
    .locals 1

    iget-object v0, p0, La_3903F91B;->c:Landroid/widget/SpinnerAdapter;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Landroid/widget/Adapter;->m_94ad2c13()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final m_bcc1b243()Z
    .locals 1

    invoke-virtual {p0}, La_3903F91B;->getCount()I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final m_4e57e965(I)Z
    .locals 1

    .line 1
    iget-object v0, p0, La_3903F91B;->d:Landroid/widget/ListAdapter;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-interface {v0, p1}, Landroid/widget/ListAdapter;->m_4e57e965(I)Z

    .line 8
    move-result p1

    .line 9
    return p1

    .line 10
    :cond_0
    const/4 p1, 0x1

    .line 11
    return p1
.end method

.method public final m_2dd779e3(Landroid/database/DataSetObserver;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_3903F91B;->c:Landroid/widget/SpinnerAdapter;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-interface {v0, p1}, Landroid/widget/Adapter;->m_2dd779e3(Landroid/database/DataSetObserver;)V

    .line 8
    :cond_0
    return-void
.end method

.method public final m_6fa52c51(Landroid/database/DataSetObserver;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_3903F91B;->c:Landroid/widget/SpinnerAdapter;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-interface {v0, p1}, Landroid/widget/Adapter;->m_6fa52c51(Landroid/database/DataSetObserver;)V

    .line 8
    :cond_0
    return-void
.end method
