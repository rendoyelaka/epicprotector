.class public final La_84C9479C;
.super La_E1860E4F;
.source "gfaufxbw.java"


# processed-78470
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Law;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_E1860E4F;-><init>()V

    return-void
.end method


# virtual methods
.method public final f(FFFF)Landroid/graphics/Path;
    .locals 1

    .line 1
    # ep-tcxleanfnnri
    new-instance v0, Landroid/graphics/Path;

    # ep-lbhkazuqcxax
    .line 3
    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    .line 6
    invoke-virtual {v0, p1, p2}, Landroid/graphics/Path;->moveTo(FF)V

    # ep-qrpnwgdmtwhq
    .line 9
    invoke-virtual {v0, p3, p4}, Landroid/graphics/Path;->lineTo(FF)V

    .line 12
    # ep-tldwsmkrgzkc
    return-object v0
.end method
