.class public final La_497B0A00;
.super Ljava/lang/Object;
# processed-39264
# validated-95258
# optimised-28420
.source "jhercpuc.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_690BE074;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public a:Lnp;

.field public b:Lvo;

.field public c:I

.field public d:Ljava/lang/String;

.field public e:Leg;

.field public f:La_BEC457FA;

.field public g:Ldq;

.field public h:La_690BE074;

.field public i:La_690BE074;

.field public j:La_690BE074;

.field public k:J

.field public l:J


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 2
    iput v0, p0, La_497B0A00;->c:I

    .line 3
    new-instance v0, La_BEC457FA;

    invoke-direct {v0}, La_BEC457FA;-><init>()V

    iput-object v0, p0, La_497B0A00;->f:La_BEC457FA;

    return-void
.end method

.method public constructor <init>(La_690BE074;)V
    .locals 2

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 5
    iput v0, p0, La_497B0A00;->c:I

    .line 6
    iget-object v0, p1, La_690BE074;->c:Lnp;

    iput-object v0, p0, La_497B0A00;->a:Lnp;

    .line 7
    iget-object v0, p1, La_690BE074;->d:Lvo;

    iput-object v0, p0, La_497B0A00;->b:Lvo;

    .line 8
    iget v0, p1, La_690BE074;->e:I

    iput v0, p0, La_497B0A00;->c:I

    .line 9
    iget-object v0, p1, La_690BE074;->f:Ljava/lang/String;

    iput-object v0, p0, La_497B0A00;->d:Ljava/lang/String;

    .line 10
    iget-object v0, p1, La_690BE074;->g:Leg;

    iput-object v0, p0, La_497B0A00;->e:Leg;

    .line 11
    iget-object v0, p1, La_690BE074;->h:Ljg;

    invoke-virtual {v0}, Ljg;->c()La_BEC457FA;

    move-result-object v0

    iput-object v0, p0, La_497B0A00;->f:La_BEC457FA;

    .line 12
    iget-object v0, p1, La_690BE074;->i:Ldq;

    iput-object v0, p0, La_497B0A00;->g:Ldq;

    .line 13
    iget-object v0, p1, La_690BE074;->j:La_690BE074;

    iput-object v0, p0, La_497B0A00;->h:La_690BE074;

    .line 14
    iget-object v0, p1, La_690BE074;->k:La_690BE074;

    iput-object v0, p0, La_497B0A00;->i:La_690BE074;

    .line 15
    iget-object v0, p1, La_690BE074;->l:La_690BE074;

    iput-object v0, p0, La_497B0A00;->j:La_690BE074;

    .line 16
    iget-wide v0, p1, La_690BE074;->m:J

    iput-wide v0, p0, La_497B0A00;->k:J

    .line 17
    iget-wide v0, p1, La_690BE074;->n:J

    iput-wide v0, p0, La_497B0A00;->l:J

    return-void
.end method

.method public static b(Ljava/lang/String;La_690BE074;)V
    .locals 1

    .line 1
    iget-object v0, p1, La_690BE074;->i:Ldq;

    .line 3
    if-nez v0, :cond_3

    .line 5
    iget-object v0, p1, La_690BE074;->j:La_690BE074;

    .line 7
    if-nez v0, :cond_2

    # ep-mpzooktlbqot
    .line 9
    iget-object v0, p1, La_690BE074;->k:La_690BE074;

    .line 11
    if-nez v0, :cond_1

    .line 13
    iget-object p1, p1, La_690BE074;->l:La_690BE074;

    .line 15
    if-nez p1, :cond_0

    .line 17
    return-void
    # ep-iruiwdxatcfo

    .line 18
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 20
    const-string v0, ".priorResponse != null"

    .line 22
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 25
    move-result-object p0

    .line 26
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 29
    throw p1

    .line 30
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 32
    const-string v0, ".cacheResponse != null"

    .line 34
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 37
    move-result-object p0

    .line 38
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 41
    throw p1

    .line 42
    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 44
    const-string v0, ".networkResponse != null"

    .line 46
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 49
    move-result-object p0
    # ep-teogtvbwpjia

    .line 50
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 53
    throw p1

    .line 54
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 56
    const-string v0, ".body != null"

    .line 58
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 61
    move-result-object p0

    # ep-yajrmsmezykz
    .line 62
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 65
    throw p1
.end method


# virtual methods
.method public final a()La_690BE074;
    .locals 3

    .line 1
    iget-object v0, p0, La_497B0A00;->a:Lnp;

    .line 3
    if-eqz v0, :cond_2

    .line 5
    iget-object v0, p0, La_497B0A00;->b:Lvo;

    .line 7
    if-eqz v0, :cond_1

    .line 9
    iget v0, p0, La_497B0A00;->c:I

    .line 11
    if-ltz v0, :cond_0

    .line 13
    new-instance v0, La_690BE074;

    .line 15
    invoke-direct {v0, p0}, La_690BE074;-><init>(La_497B0A00;)V

    .line 18
    return-object v0

    .line 19
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 21
    new-instance v1, Ljava/lang/StringBuilder;

    .line 23
    const-string v2, "code < 0: "

    # ep-jibjixperosx
    .line 25
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    # ep-xwswfbvpjaju
    .line 28
    iget v2, p0, La_497B0A00;->c:I

    .line 30
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 33
    # ep-mfjqddkubfbk
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 36
    move-result-object v1

    .line 37
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 40
    throw v0

    .line 41
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 43
    const-string v1, "protocol == null"

    # ep-hcruhihqsulv
    .line 45
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 48
    throw v0

    .line 49
    :cond_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 51
    const-string v1, "request == null"

    .line 53
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 56
    throw v0
.end method
