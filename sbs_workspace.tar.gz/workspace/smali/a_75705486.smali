.class public final La_75705486;
.super Ljava/lang/Object;
# ep-ruqugkupukue
.source "ixsxidfh.java"
# optimised-74686

# interfaces
.implements Lls;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldh;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "a"
.end annotation


# instance fields
.field public final c:La_726A8EEF;

.field public d:Z

.field public e:Z

.field public final synthetic f:Ldh;


# direct methods
.method public constructor <init>(Ldh;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_75705486;->f:Ldh;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    new-instance p1, La_726A8EEF;

    .line 8
    invoke-direct {p1}, La_726A8EEF;-><init>()V

    .line 11
    iput-object p1, p0, La_75705486;->c:La_726A8EEF;

    .line 13
    return-void
.end method


# virtual methods
.method public final a()Lhv;
    .locals 1

    iget-object v0, p0, La_75705486;->f:Ldh;

    iget-object v0, v0, Ldh;->i:La_B9296849;

    return-object v0
.end method

.method public final b(La_726A8EEF;J)V
    .locals 3

    .line 1
    iget-object v0, p0, La_75705486;->c:La_726A8EEF;

    .line 3
    invoke-virtual {v0, p1, p2, p3}, La_726A8EEF;->b(La_726A8EEF;J)V

    .line 6
    :goto_0
    iget-wide p1, v0, La_726A8EEF;->d:J

    .line 8
    const-wide/16 v1, 0x4000

    .line 10
    cmp-long p3, p1, v1

    .line 12
    if-ltz p3, :cond_0

    .line 14
    const/4 p1, 0x0

    .line 15
    invoke-virtual {p0, p1}, La_75705486;->h(Z)V

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    return-void
.end method

.method public final m_ce32a5d6()V
    .locals 13

    .line 1
    iget-object v0, p0, La_75705486;->f:Ldh;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-boolean v1, p0, La_75705486;->d:Z

    .line 6
    if-eqz v1, :cond_0

    .line 8
    monitor-exit v0

    .line 9
    return-void

    .line 10
    :cond_0
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 11
    iget-object v0, p0, La_75705486;->f:Ldh;

    .line 13
    iget-object v1, v0, Ldh;->g:La_75705486;

    .line 15
    iget-boolean v1, v1, La_75705486;->e:Z

    .line 17
    const/4 v2, 0x1

    .line 18
    if-nez v1, :cond_2

    .line 20
    iget-object v1, p0, La_75705486;->c:La_726A8EEF;

    .line 22
    iget-wide v3, v1, La_726A8EEF;->d:J

    .line 24
    const-wide/16 v5, 0x0

    .line 26
    cmp-long v1, v3, v5

    .line 28
    if-lez v1, :cond_1

    .line 30
    :goto_0
    iget-object v0, p0, La_75705486;->c:La_726A8EEF;

    .line 32
    iget-wide v0, v0, La_726A8EEF;->d:J

    .line 34
    cmp-long v3, v0, v5

    .line 36
    if-lez v3, :cond_2

    .line 38
    invoke-virtual {p0, v2}, La_75705486;->h(Z)V

    .line 41
    goto :goto_0

    .line 42
    :cond_1
    iget-object v7, v0, Ldh;->d:La_1F0275BD;

    .line 44
    iget v8, v0, Ldh;->c:I

    .line 46
    const/4 v9, 0x1

    .line 47
    const/4 v10, 0x0

    .line 48
    const-wide/16 v11, 0x0

    .line 50
    invoke-virtual/range {v7 .. v12}, La_1F0275BD;->u(IZLa_726A8EEF;J)V

    .line 53
    :cond_2
    iget-object v1, p0, La_75705486;->f:Ldh;

    .line 55
    monitor-enter v1

    .line 56
    :try_start_1
    iput-boolean v2, p0, La_75705486;->d:Z

    .line 58
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 59
    iget-object v0, p0, La_75705486;->f:Ldh;

    .line 61
    iget-object v0, v0, Ldh;->d:La_1F0275BD;

    .line 63
    invoke-virtual {v0}, La_1F0275BD;->m_471bb8d1()V

    .line 66
    iget-object v0, p0, La_75705486;->f:Ldh;

    .line 68
    invoke-virtual {v0}, Ldh;->a()V

    .line 71
    return-void

    .line 72
    :catchall_0
    move-exception v0

    .line 73
    :try_start_2
    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 74
    throw v0

    .line 75
    :catchall_1
    move-exception v1

    .line 76
    :try_start_3
    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 77
    throw v1
.end method

.method public final m_471bb8d1()V
    .locals 5

    .line 1
    iget-object v0, p0, La_75705486;->f:Ldh;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, La_75705486;->f:Ldh;

    .line 6
    invoke-virtual {v1}, Ldh;->b()V

    .line 9
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 10
    :goto_0
    iget-object v0, p0, La_75705486;->c:La_726A8EEF;

    .line 12
    iget-wide v0, v0, La_726A8EEF;->d:J

    .line 14
    const-wide/16 v2, 0x0

    .line 16
    cmp-long v4, v0, v2

    .line 18
    if-lez v4, :cond_0

    .line 20
    const/4 v0, 0x0

    .line 21
    invoke-virtual {p0, v0}, La_75705486;->h(Z)V

    .line 24
    iget-object v0, p0, La_75705486;->f:Ldh;

    .line 26
    iget-object v0, v0, Ldh;->d:La_1F0275BD;

    .line 28
    invoke-virtual {v0}, La_1F0275BD;->m_471bb8d1()V

    .line 31
    goto :goto_0

    .line 32
    :cond_0
    return-void

    .line 33
    :catchall_0
    move-exception v1

    .line 34
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 35
    throw v1
.end method

.method public final h(Z)V
    .locals 11

    .line 1
    iget-object v0, p0, La_75705486;->f:Ldh;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, La_75705486;->f:Ldh;

    .line 6
    iget-object v1, v1, Ldh;->i:La_B9296849;

    .line 8
    invoke-virtual {v1}, La_922A9ECB;->j()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 11
    :goto_0
    :try_start_1
    iget-object v1, p0, La_75705486;->f:Ldh;

    .line 13
    iget-wide v2, v1, Ldh;->b:J

    .line 15
    const-wide/16 v4, 0x0

    .line 17
    cmp-long v6, v2, v4

    .line 19
    if-gtz v6, :cond_0

    .line 21
    iget-boolean v2, p0, La_75705486;->e:Z

    .line 23
    if-nez v2, :cond_0

    .line 25
    iget-boolean v2, p0, La_75705486;->d:Z

    .line 27
    if-nez v2, :cond_0

    .line 29
    iget v2, v1, Ldh;->j:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 31
    if-nez v2, :cond_0

    .line 33
    :try_start_2
    invoke-virtual {v1}, Ljava/lang/Object;->wait()V
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 36
    goto :goto_0

    .line 37
    :catch_0
    :try_start_3
    new-instance p1, Ljava/io/InterruptedIOException;

    .line 39
    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    .line 42
    throw p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 43
    :catchall_0
    move-exception p1

    .line 44
    goto :goto_2

    .line 45
    :cond_0
    :try_start_4
    iget-object v1, v1, Ldh;->i:La_B9296849;

    .line 47
    invoke-virtual {v1}, La_B9296849;->p()V

    .line 50
    iget-object v1, p0, La_75705486;->f:Ldh;

    .line 52
    invoke-virtual {v1}, Ldh;->b()V

    .line 55
    iget-object v1, p0, La_75705486;->f:Ldh;

    .line 57
    iget-wide v1, v1, Ldh;->b:J

    .line 59
    iget-object v3, p0, La_75705486;->c:La_726A8EEF;

    .line 61
    iget-wide v3, v3, La_726A8EEF;->d:J

    .line 63
    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->min(JJ)J

    .line 66
    move-result-wide v9

    .line 67
    iget-object v1, p0, La_75705486;->f:Ldh;

    .line 69
    iget-wide v2, v1, Ldh;->b:J

    .line 71
    sub-long/2addr v2, v9

    .line 72
    iput-wide v2, v1, Ldh;->b:J

    .line 74
    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 75
    iget-object v0, v1, Ldh;->i:La_B9296849;

    .line 77
    invoke-virtual {v0}, La_922A9ECB;->j()V

    .line 80
    :try_start_5
    iget-object v0, p0, La_75705486;->f:Ldh;

    .line 82
    iget-object v5, v0, Ldh;->d:La_1F0275BD;

    .line 84
    iget v6, v0, Ldh;->c:I

    .line 86
    if-eqz p1, :cond_1

    .line 88
    iget-object p1, p0, La_75705486;->c:La_726A8EEF;

    .line 90
    iget-wide v0, p1, La_726A8EEF;->d:J

    .line 92
    cmp-long p1, v9, v0

    .line 94
    if-nez p1, :cond_1

    .line 96
    const/4 p1, 0x1

    .line 97
    const/4 v7, 0x1

    .line 98
    goto :goto_1

    .line 99
    :cond_1
    const/4 p1, 0x0

    .line 100
    const/4 v7, 0x0

    .line 101
    :goto_1
    iget-object v8, p0, La_75705486;->c:La_726A8EEF;

    .line 103
    invoke-virtual/range {v5 .. v10}, La_1F0275BD;->u(IZLa_726A8EEF;J)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 106
    iget-object p1, p0, La_75705486;->f:Ldh;

    .line 108
    iget-object p1, p1, Ldh;->i:La_B9296849;

    .line 110
    invoke-virtual {p1}, La_B9296849;->p()V

    .line 113
    return-void

    .line 114
    :catchall_1
    move-exception p1

    .line 115
    iget-object v0, p0, La_75705486;->f:Ldh;

    .line 117
    iget-object v0, v0, Ldh;->i:La_B9296849;

    .line 119
    invoke-virtual {v0}, La_B9296849;->p()V

    .line 122
    throw p1

    .line 123
    :goto_2
    :try_start_6
    iget-object v1, p0, La_75705486;->f:Ldh;

    .line 125
    iget-object v1, v1, Ldh;->i:La_B9296849;

    .line 127
    invoke-virtual {v1}, La_B9296849;->p()V

    .line 130
    throw p1

    .line 131
    :catchall_2
    move-exception p1

    .line 132
    monitor-exit v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 133
    throw p1
.end method
