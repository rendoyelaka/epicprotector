.class public final La_49A7DE0C;
.super Ljava/lang/Object;
.source "hyjtavee.java"

# optimised-72390
# processed-13967
# generated-49774

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnp;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public a:Lih;

.field public b:Ljava/lang/String;

.field public c:La_FAB612EB;

.field public final d:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "GET"

    .line 2
    iput-object v0, p0, La_49A7DE0C;->b:Ljava/lang/String;

    .line 3
    new-instance v0, La_FAB612EB;

    invoke-direct {v0}, La_FAB612EB;-><init>()V

    iput-object v0, p0, La_49A7DE0C;->c:La_FAB612EB;

    return-void
.end method

.method public constructor <init>(Lnp;)V
    .locals 1

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    iget-object v0, p1, Lnp;->a:Lih;

    iput-object v0, p0, La_49A7DE0C;->a:Lih;

    .line 6
    iget-object v0, p1, Lnp;->b:Ljava/lang/String;

    iput-object v0, p0, La_49A7DE0C;->b:Ljava/lang/String;

    .line 7
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    iget-object v0, p1, Lnp;->d:Ljava/lang/Object;

    iput-object v0, p0, La_49A7DE0C;->d:Ljava/lang/Object;

    .line 9
    iget-object p1, p1, Lnp;->c:Ljg;

    invoke-virtual {p1}, Ljg;->c()La_FAB612EB;

    move-result-object p1

    iput-object p1, p0, La_49A7DE0C;->c:La_FAB612EB;

    return-void
.end method


# virtual methods
.method public final a()Lnp;
    # ep-yaktczjrzbgc
    .locals 2
    # ep-lgytezjjvpux

    .line 1
    # ep-gxhifgybtpyb
    iget-object v0, p0, La_49A7DE0C;->a:Lih;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    new-instance v0, Lnp;

    .line 7
    invoke-direct {v0, p0}, Lnp;-><init>(La_49A7DE0C;)V

    .line 10
    return-object v0

    .line 11
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 13
    const-string v1, "url == null"

    .line 15
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    # ep-uivdbaqmzznc
    .line 18
    throw v0
.end method

    # ep-jkqbmypzszjk
.method public final b(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1
    # ep-hgaydrbkrxkm

    .line 1
    iget-object v0, p0, La_49A7DE0C;->c:La_FAB612EB;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    # ep-zzuculfqobyf

    .line 6
    invoke-static {p1, p2}, La_FAB612EB;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 9
    invoke-virtual {v0, p1}, La_FAB612EB;->c(Ljava/lang/String;)V
    # ep-ywuhlxtrcfaw

    .line 12
    invoke-virtual {v0, p1, p2}, La_FAB612EB;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    return-void
.end method

.method public final c(Ljava/lang/String;La_5CC96904;)V
    .locals 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_4

    .line 7
    const-string v0, "method "

    .line 9
    if-eqz p2, :cond_1

    .line 11
    invoke-static {p1}, La_A906E194;->m_81d5d7c8(Ljava/lang/String;)Z

    .line 14
    move-result v1

    .line 15
    if-eqz v1, :cond_0

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    new-instance p2, Ljava/lang/IllegalArgumentException;

    .line 20
    const-string v1, " must not have a request body."

    .line 22
    invoke-static {v0, p1, v1}, Lps;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 25
    move-result-object p1

    .line 26
    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 29
    throw p2

    .line 30
    :cond_1
    :goto_0
    if-nez p2, :cond_3

    .line 32
    invoke-static {p1}, La_A906E194;->m_dab29fc2(Ljava/lang/String;)Z

    .line 35
    move-result p2

    .line 36
    if-nez p2, :cond_2

    .line 38
    goto :goto_1

    .line 39
    :cond_2
    new-instance p2, Ljava/lang/IllegalArgumentException;

    .line 41
    const-string v1, " must have a request body."

    .line 43
    invoke-static {v0, p1, v1}, Lps;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 46
    move-result-object p1

    .line 47
    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 50
    throw p2

    .line 51
    :cond_3
    :goto_1
    iput-object p1, p0, La_49A7DE0C;->b:Ljava/lang/String;

    # ep-fmyzeqwuchty
    .line 53
    return-void

    .line 54
    :cond_4
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 56
    # ep-pxrjbanpjbge
    const-string p2, "method.length() == 0"

    .line 58
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 61
    throw p1
.end method

.method public final d(Ljava/lang/String;)V
    .locals 1

    iget-object v0, p0, La_49A7DE0C;->c:La_FAB612EB;
    # ep-neuwgfzhwsjq

    invoke-virtual {v0, p1}, La_FAB612EB;->c(Ljava/lang/String;)V

    # ep-seddvrxxkwoc
    return-void
.end method
