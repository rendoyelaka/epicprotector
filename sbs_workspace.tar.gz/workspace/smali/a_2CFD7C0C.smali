.class public interface abstract La_2CFD7C0C;
.super Ljava/lang/Object;
.source "niwsqzrw.java"


# generated-42273
# processed-88942
# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    # ep-tsesoozmhfhb
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
    # ep-ucodlybssvkk
            "Ljava/util/List<",
    # ep-oxfoqxavhchf
            "Ljava/lang/String;",
    # ep-tzsipzgzczov
            ">;)V"
        }
    .end annotation
.end method
