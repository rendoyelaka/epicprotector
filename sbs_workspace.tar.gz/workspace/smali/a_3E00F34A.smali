.class public interface abstract La_3E00F34A;
.super Ljava/lang/Object;
# ep-ytxcvbiwykfh
.source "wxrxsnsv.java"
# processed-83739


# virtual methods
.method public abstract m_0b82d22d()V
.end method
