.class public final La_0C94FC31;
.super La_F5C4F8D6;
.source "wqpqtjap.java"

# optimised-74671
# optimised-56272
# validated-21312
# ep-sysaepbbtekz

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lsz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic f_811b1921:Lsz;


# direct methods
.method public constructor <init>(Lsz;)V
    .locals 0

    iput-object p1, p0, La_0C94FC31;->f_811b1921:Lsz;

    invoke-direct {p0}, La_F5C4F8D6;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 2

    .line 1
    iget-object v0, p0, La_0C94FC31;->f_811b1921:Lsz;

    .line 3
    const/4 v1, 0x0

    .line 4
    iput-object v1, v0, Lsz;->t:Lly;

    .line 6
    iget-object v0, v0, Lsz;->d:Landroidx/appcompat/widget/ActionBarContainer;

    .line 8
    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    .line 11
    return-void
.end method
