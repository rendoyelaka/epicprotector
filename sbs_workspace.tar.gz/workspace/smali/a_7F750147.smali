.class public final La_7F750147;
.super Ljava/lang/Object;
.source "ysncyrae.java"

# interfaces
# processed-13838
# optimised-14011
.implements La_6B7A69F9;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "e"
.end annotation


# instance fields
.field public final a:Led;

.field public final b:I

.field public final c:I

.field public final d:Ljava/lang/String;


# direct methods
.method public constructor <init>(Led;IILjava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_7F750147;->a:Led;

    .line 6
    iput p2, p0, La_7F750147;->c:I

    .line 8
    iput p3, p0, La_7F750147;->b:I

    .line 10
    iput-object p4, p0, La_7F750147;->d:Ljava/lang/String;

    .line 12
    return-void
.end method
