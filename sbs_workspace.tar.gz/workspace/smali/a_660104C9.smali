.class public final La_660104C9;
.super La_747A2121;
# processed-15527
# verified-12259
# ep-qqwrxkbuotny
.source "ujeffsrl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpg;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "c"
.end annotation


# instance fields
.field public final f:Lih;

.field public g:J

.field public h:Z

.field public final synthetic i:Lpg;


# direct methods
.method public constructor <init>(Lpg;Lih;)V
    .locals 2

    .line 1
    iput-object p1, p0, La_660104C9;->i:Lpg;

    .line 3
    invoke-direct {p0, p1}, La_747A2121;-><init>(Lpg;)V

    .line 6
    const-wide/16 v0, -0x1

    .line 8
    iput-wide v0, p0, La_660104C9;->g:J

    .line 10
    const/4 p1, 0x1

    .line 11
    iput-boolean p1, p0, La_660104C9;->h:Z

    .line 13
    iput-object p2, p0, La_660104C9;->f:Lih;

    .line 15
    return-void
.end method


# virtual methods
.method public final m_ce32a5d6()V
    .locals 3

    .line 1
    iget-boolean v0, p0, La_747A2121;->d:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    iget-boolean v0, p0, La_660104C9;->h:Z

    .line 8
    if-eqz v0, :cond_1

    .line 10
    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 12
    const/4 v1, 0x0

    .line 13
    const/16 v2, 0x64

    .line 15
    :try_start_0
    invoke-static {p0, v2, v0}, Lex;->l(Lrs;ILjava/util/concurrent/TimeUnit;)Z

    .line 18
    move-result v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 19
    goto :goto_0

    .line 20
    :catch_0
    const/4 v0, 0x0

    .line 21
    :goto_0
    if-nez v0, :cond_1

    .line 23
    invoke-virtual {p0, v1}, La_747A2121;->h(Z)V

    .line 26
    :cond_1
    const/4 v0, 0x1

    .line 27
    iput-boolean v0, p0, La_747A2121;->d:Z

    .line 29
    return-void
.end method

.method public final k(La_726A8EEF;J)J
    .locals 9

    .line 1
    iget-boolean p2, p0, La_747A2121;->d:Z

    .line 3
    if-nez p2, :cond_8

    .line 5
    iget-boolean p2, p0, La_660104C9;->h:Z

    .line 7
    const-wide/16 v0, -0x1

    .line 9
    if-nez p2, :cond_0

    .line 11
    return-wide v0

    .line 12
    :cond_0
    iget-wide p2, p0, La_660104C9;->g:J

    .line 14
    const-wide/16 v2, 0x0

    .line 16
    const/4 v4, 0x0

    .line 17
    iget-object v5, p0, La_660104C9;->i:Lpg;

    .line 19
    cmp-long v6, p2, v2

    .line 21
    if-eqz v6, :cond_1

    .line 23
    cmp-long v6, p2, v0

    .line 25
    if-nez v6, :cond_5

    .line 27
    :cond_1
    const-string v6, "expected chunk size and optional extensions but was \""

    .line 29
    cmp-long v7, p2, v0

    .line 31
    if-eqz v7, :cond_2

    .line 33
    iget-object p2, v5, Lpg;->c:La_34230022;

    .line 35
    invoke-interface {p2}, La_34230022;->g()Ljava/lang/String;

    .line 38
    :cond_2
    :try_start_0
    iget-object p2, v5, Lpg;->c:La_34230022;

    .line 40
    invoke-interface {p2}, La_34230022;->q()J

    .line 43
    move-result-wide p2

    .line 44
    iput-wide p2, p0, La_660104C9;->g:J

    .line 46
    iget-object p2, v5, Lpg;->c:La_34230022;

    .line 48
    invoke-interface {p2}, La_34230022;->g()Ljava/lang/String;

    .line 51
    move-result-object p2

    .line 52
    invoke-virtual {p2}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 55
    move-result-object p2

    .line 56
    iget-wide v7, p0, La_660104C9;->g:J

    .line 58
    cmp-long p3, v7, v2

    .line 60
    if-ltz p3, :cond_7

    .line 62
    invoke-virtual {p2}, Ljava/lang/String;->m_2bd5aeca()Z

    .line 65
    move-result p3

    .line 66
    if-nez p3, :cond_3

    .line 68
    const-string p3, ";"

    .line 70
    invoke-virtual {p2, p3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 73
    move-result p3
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 74
    if-eqz p3, :cond_7

    .line 76
    :cond_3
    iget-wide p2, p0, La_660104C9;->g:J

    .line 78
    cmp-long v6, p2, v2

    .line 80
    if-nez v6, :cond_4

    .line 82
    iput-boolean v4, p0, La_660104C9;->h:Z

    .line 84
    iget-object p2, v5, Lpg;->a:Lan;

    .line 86
    iget-object p2, p2, Lan;->j:La_AC88DDE5;

    .line 88
    invoke-virtual {v5}, Lpg;->g()Ljg;

    .line 91
    move-result-object p3

    .line 92
    iget-object v2, p0, La_660104C9;->f:Lih;

    .line 94
    invoke-static {p2, v2, p3}, Lhh;->d(La_AC88DDE5;Lih;Ljg;)V

    .line 97
    const/4 p2, 0x1

    .line 98
    invoke-virtual {p0, p2}, La_747A2121;->h(Z)V

    .line 101
    :cond_4
    iget-boolean p2, p0, La_660104C9;->h:Z

    .line 103
    if-nez p2, :cond_5

    .line 105
    return-wide v0

    .line 106
    :cond_5
    iget-object p2, v5, Lpg;->c:La_34230022;

    .line 108
    iget-wide v2, p0, La_660104C9;->g:J

    .line 110
    const-wide/16 v5, 0x2000

    .line 112
    invoke-static {v5, v6, v2, v3}, Ljava/lang/Math;->min(JJ)J

    .line 115
    move-result-wide v2

    .line 116
    invoke-interface {p2, p1, v2, v3}, Lrs;->k(La_726A8EEF;J)J

    .line 119
    move-result-wide p1

    .line 120
    cmp-long p3, p1, v0

    .line 122
    if-eqz p3, :cond_6

    .line 124
    iget-wide v0, p0, La_660104C9;->g:J

    .line 126
    sub-long/2addr v0, p1

    .line 127
    iput-wide v0, p0, La_660104C9;->g:J

    .line 129
    return-wide p1

    .line 130
    :cond_6
    invoke-virtual {p0, v4}, La_747A2121;->h(Z)V

    .line 133
    new-instance p1, Ljava/net/ProtocolException;

    .line 135
    const-string p2, "unexpected end of stream"

    .line 137
    invoke-direct {p1, p2}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 140
    throw p1

    .line 141
    :cond_7
    :try_start_1
    new-instance p1, Ljava/net/ProtocolException;

    .line 143
    new-instance p3, Ljava/lang/StringBuilder;

    .line 145
    invoke-direct {p3, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 148
    iget-wide v0, p0, La_660104C9;->g:J

    .line 150
    invoke-virtual {p3, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 153
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 156
    const-string p2, "\""

    .line 158
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 161
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 164
    move-result-object p2

    .line 165
    invoke-direct {p1, p2}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 168
    throw p1
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_0

    .line 169
    :catch_0
    move-exception p1

    .line 170
    new-instance p2, Ljava/net/ProtocolException;

    .line 172
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 175
    move-result-object p1

    .line 176
    invoke-direct {p2, p1}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 179
    throw p2

    .line 180
    :cond_8
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 182
    const-string p2, "closed"

    .line 184
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 187
    throw p1
.end method
