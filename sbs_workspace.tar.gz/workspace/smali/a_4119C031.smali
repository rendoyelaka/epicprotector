.class public final La_4119C031;
.super Ljava/lang/Object;
# ep-ezyxwcpytily
# optimised-91334
.source "blnzpast.java"

# interfaces
.implements Lfn;


# instance fields
.field public final synthetic a:Lu1;


# direct methods
.method public constructor <init>(Lu1;)V
    .locals 0

    iput-object p1, p0, La_4119C031;->a:Lu1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;Lwz;)Lwz;
    .locals 17

    .line 1
    move-object/from16 v0, p1

    .line 3
    move-object/from16 v1, p2

    .line 5
    invoke-virtual/range {p2 .. p2}, Lwz;->e()I

    .line 8
    move-result v2

    .line 9
    move-object/from16 v3, p0

    .line 11
    iget-object v4, v3, La_4119C031;->a:Lu1;

    .line 13
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    invoke-virtual/range {p2 .. p2}, Lwz;->e()I

    .line 19
    move-result v5

    .line 20
    iget-object v6, v4, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 22
    const/4 v7, 0x0

    .line 23
    const/16 v8, 0x8

    .line 25
    if-eqz v6, :cond_10

    .line 27
    invoke-virtual {v6}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 30
    move-result-object v6

    .line 31
    instance-of v6, v6, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 33
    if-eqz v6, :cond_10

    .line 35
    iget-object v6, v4, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 37
    invoke-virtual {v6}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 40
    move-result-object v6

    .line 41
    check-cast v6, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 43
    iget-object v9, v4, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 45
    invoke-virtual {v9}, Landroid/view/View;->isShown()Z

    .line 48
    move-result v9

    .line 49
    const/4 v10, 0x1

    .line 50
    if-eqz v9, :cond_d

    .line 52
    iget-object v9, v4, Lu1;->f_290febd2:Landroid/graphics/Rect;

    .line 54
    if-nez v9, :cond_0

    .line 56
    new-instance v9, Landroid/graphics/Rect;

    .line 58
    invoke-direct {v9}, Landroid/graphics/Rect;-><init>()V

    .line 61
    iput-object v9, v4, Lu1;->f_290febd2:Landroid/graphics/Rect;

    .line 63
    new-instance v9, Landroid/graphics/Rect;

    .line 65
    invoke-direct {v9}, Landroid/graphics/Rect;-><init>()V

    .line 68
    iput-object v9, v4, Lu1;->f_c1956b13:Landroid/graphics/Rect;

    .line 70
    :cond_0
    iget-object v9, v4, Lu1;->f_290febd2:Landroid/graphics/Rect;

    .line 72
    iget-object v11, v4, Lu1;->f_c1956b13:Landroid/graphics/Rect;

    .line 74
    invoke-virtual/range {p2 .. p2}, Lwz;->c()I

    .line 77
    move-result v12

    .line 78
    invoke-virtual/range {p2 .. p2}, Lwz;->e()I

    .line 81
    move-result v13

    .line 82
    invoke-virtual/range {p2 .. p2}, Lwz;->d()I

    .line 85
    move-result v14

    .line 86
    invoke-virtual/range {p2 .. p2}, Lwz;->b()I

    .line 89
    move-result v15

    .line 90
    invoke-virtual {v9, v12, v13, v14, v15}, Landroid/graphics/Rect;->set(IIII)V

    .line 93
    iget-object v12, v4, Lu1;->w:Landroid/view/ViewGroup;

    .line 95
    sget-object v13, Lty;->a:Ljava/lang/reflect/Method;

    .line 97
    if-eqz v13, :cond_1

    .line 99
    const/4 v14, 0x2

    .line 100
    :try_start_0
    new-array v14, v14, [Ljava/lang/Object;

    .line 102
    aput-object v9, v14, v7

    .line 104
    aput-object v11, v14, v10

    .line 106
    invoke-virtual {v13, v12, v14}, Ljava/lang/reflect/Method;->m_fa56d4ad(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 109
    goto :goto_0

    .line 110
    :catch_0
    nop

    .line 111
    :cond_1
    :goto_0
    iget v11, v9, Landroid/graphics/Rect;->top:I

    .line 113
    iget v12, v9, Landroid/graphics/Rect;->left:I

    .line 115
    iget v9, v9, Landroid/graphics/Rect;->right:I

    .line 117
    iget-object v13, v4, Lu1;->w:Landroid/view/ViewGroup;

    .line 119
    invoke-static {v13}, Lqx;->h(Landroid/view/View;)Lwz;

    .line 122
    move-result-object v13

    .line 123
    if-nez v13, :cond_2

    .line 125
    const/4 v14, 0x0

    .line 126
    goto :goto_1

    .line 127
    :cond_2
    invoke-virtual {v13}, Lwz;->c()I

    .line 130
    move-result v14

    .line 131
    :goto_1
    if-nez v13, :cond_3

    .line 133
    const/4 v13, 0x0

    .line 134
    goto :goto_2

    .line 135
    :cond_3
    invoke-virtual {v13}, Lwz;->d()I

    .line 138
    move-result v13

    .line 139
    :goto_2
    iget v15, v6, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 141
    if-ne v15, v11, :cond_5

    .line 143
    iget v15, v6, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 145
    if-ne v15, v12, :cond_5

    .line 147
    iget v15, v6, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 149
    if-eq v15, v9, :cond_4

    .line 151
    goto :goto_3

    .line 152
    :cond_4
    const/4 v9, 0x0

    .line 153
    goto :goto_4

    .line 154
    :cond_5
    :goto_3
    iput v11, v6, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 156
    iput v12, v6, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 158
    iput v9, v6, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 160
    const/4 v9, 0x1

    .line 161
    :goto_4
    iget-object v12, v4, Lu1;->f:Landroid/content/Context;

    .line 163
    if-lez v11, :cond_6

    .line 165
    iget-object v11, v4, Lu1;->y:Landroid/view/View;

    .line 167
    if-nez v11, :cond_6

    .line 169
    new-instance v11, Landroid/view/View;

    .line 171
    invoke-direct {v11, v12}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 174
    iput-object v11, v4, Lu1;->y:Landroid/view/View;

    .line 176
    invoke-virtual {v11, v8}, Landroid/view/View;->setVisibility(I)V

    .line 179
    new-instance v11, Landroid/widget/FrameLayout$LayoutParams;

    .line 181
    iget v15, v6, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 183
    const/16 v8, 0x33

    .line 185
    const/4 v10, -0x1

    .line 186
    invoke-direct {v11, v10, v15, v8}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .line 189
    iput v14, v11, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 191
    iput v13, v11, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    .line 193
    iget-object v8, v4, Lu1;->w:Landroid/view/ViewGroup;

    .line 195
    iget-object v13, v4, Lu1;->y:Landroid/view/View;

    .line 197
    invoke-virtual {v8, v13, v10, v11}, Landroid/view/ViewGroup;->m_b48d6616(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 200
    goto :goto_5

    .line 201
    :cond_6
    iget-object v8, v4, Lu1;->y:Landroid/view/View;

    .line 203
    if-eqz v8, :cond_8

    .line 205
    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 208
    move-result-object v8

    .line 209
    check-cast v8, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 211
    iget v10, v8, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 213
    iget v11, v6, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 215
    if-ne v10, v11, :cond_7

    .line 217
    iget v10, v8, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 219
    if-ne v10, v14, :cond_7

    .line 221
    iget v10, v8, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 223
    if-eq v10, v13, :cond_8

    .line 225
    :cond_7
    iput v11, v8, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 227
    iput v14, v8, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 229
    iput v13, v8, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 231
    iget-object v10, v4, Lu1;->y:Landroid/view/View;

    .line 233
    invoke-virtual {v10, v8}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 236
    :cond_8
    :goto_5
    iget-object v8, v4, Lu1;->y:Landroid/view/View;

    .line 238
    if-eqz v8, :cond_9

    .line 240
    const/4 v10, 0x1

    .line 241
    goto :goto_6

    .line 242
    :cond_9
    const/4 v10, 0x0

    .line 243
    :goto_6
    if-eqz v10, :cond_c

    .line 245
    invoke-virtual {v8}, Landroid/view/View;->getVisibility()I

    .line 248
    move-result v8

    .line 249
    if-eqz v8, :cond_c

    .line 251
    iget-object v8, v4, Lu1;->y:Landroid/view/View;

    .line 253
    invoke-static {v8}, La_19221068;->g(Landroid/view/View;)I

    .line 256
    move-result v11

    .line 257
    and-int/lit16 v11, v11, 0x2000

    .line 259
    if-eqz v11, :cond_a

    .line 261
    const/16 v16, 0x1

    .line 263
    goto :goto_7

    .line 264
    :cond_a
    const/16 v16, 0x0

    .line 266
    :goto_7
    if-eqz v16, :cond_b

    .line 268
    const v11, 0x7f050006

    .line 271
    invoke-static {v12, v11}, La_F654953D;->b(Landroid/content/Context;I)I

    .line 274
    move-result v11

    .line 275
    goto :goto_8

    .line 276
    :cond_b
    const v11, 0x7f050005

    .line 279
    invoke-static {v12, v11}, La_F654953D;->b(Landroid/content/Context;I)I

    .line 282
    move-result v11

    .line 283
    :goto_8
    invoke-virtual {v8, v11}, Landroid/view/View;->m_f94fcee4(I)V

    .line 286
    :cond_c
    iget-boolean v8, v4, Lu1;->f_107c2377:Z

    .line 288
    if-nez v8, :cond_f

    .line 290
    if-eqz v10, :cond_f

    .line 292
    const/4 v5, 0x0

    .line 293
    goto :goto_a

    .line 294
    :cond_d
    iget v8, v6, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 296
    if-eqz v8, :cond_e

    .line 298
    iput v7, v6, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 300
    const/4 v10, 0x1

    .line 301
    goto :goto_9

    .line 302
    :cond_e
    const/4 v10, 0x0

    .line 303
    :goto_9
    move v9, v10

    .line 304
    const/4 v10, 0x0

    .line 305
    :cond_f
    :goto_a
    if-eqz v9, :cond_11

    .line 307
    iget-object v8, v4, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 309
    invoke-virtual {v8, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 312
    goto :goto_b

    .line 313
    :cond_10
    const/4 v10, 0x0

    .line 314
    :cond_11
    :goto_b
    iget-object v4, v4, Lu1;->y:Landroid/view/View;

    .line 316
    if-eqz v4, :cond_13

    .line 318
    if-eqz v10, :cond_12

    .line 320
    goto :goto_c

    .line 321
    :cond_12
    const/16 v7, 0x8

    .line 323
    :goto_c
    invoke-virtual {v4, v7}, Landroid/view/View;->setVisibility(I)V

    .line 326
    :cond_13
    if-eq v2, v5, :cond_16

    .line 328
    invoke-virtual/range {p2 .. p2}, Lwz;->c()I

    .line 331
    move-result v2

    .line 332
    invoke-virtual/range {p2 .. p2}, Lwz;->d()I

    .line 335
    move-result v4

    .line 336
    invoke-virtual/range {p2 .. p2}, Lwz;->b()I

    .line 339
    move-result v6

    .line 340
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 342
    const/16 v8, 0x1e

    .line 344
    if-lt v7, v8, :cond_14

    .line 346
    new-instance v7, La_5177E135;

    .line 348
    invoke-direct {v7, v1}, La_5177E135;-><init>(Lwz;)V

    .line 351
    goto :goto_d

    .line 352
    :cond_14
    const/16 v8, 0x1d

    .line 354
    if-lt v7, v8, :cond_15

    .line 356
    new-instance v7, La_3454C529;

    .line 358
    invoke-direct {v7, v1}, La_3454C529;-><init>(Lwz;)V

    .line 361
    goto :goto_d

    .line 362
    :cond_15
    new-instance v7, La_7DC107E4;

    .line 364
    invoke-direct {v7, v1}, La_7DC107E4;-><init>(Lwz;)V

    .line 367
    :goto_d
    invoke-static {v2, v5, v4, v6}, Lii;->b(IIII)Lii;

    .line 370
    move-result-object v1

    .line 371
    invoke-virtual {v7, v1}, La_B567B431;->g(Lii;)V

    .line 374
    invoke-virtual {v7}, La_B567B431;->b()Lwz;

    .line 377
    move-result-object v1

    .line 378
    :cond_16
    sget-object v2, Lqx;->a:Ljava/util/WeakHashMap;

    .line 380
    invoke-virtual {v1}, Lwz;->g()Landroid/view/WindowInsets;

    .line 383
    move-result-object v2

    .line 384
    if-eqz v2, :cond_17

    .line 386
    invoke-static {v0, v2}, La_09F7FDBC;->b(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    .line 389
    move-result-object v4

    .line 390
    invoke-virtual {v4, v2}, Landroid/view/WindowInsets;->equals(Ljava/lang/Object;)Z

    .line 393
    move-result v2

    .line 394
    if-nez v2, :cond_17

    .line 396
    invoke-static {v0, v4}, Lwz;->h(Landroid/view/View;Landroid/view/WindowInsets;)Lwz;

    .line 399
    move-result-object v1

    .line 400
    :cond_17
    return-object v1
.end method
