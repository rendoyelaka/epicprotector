.class public final La_167843F3;
.super Ldw;
# processed-30453
.source "sgcjbdue.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lfw;->y()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Law;


# direct methods
.method public constructor <init>(Law;)V
    .locals 0

    iput-object p1, p0, La_167843F3;->a:Law;

    invoke-direct {p0}, Ldw;-><init>()V

    return-void
.end method


# virtual methods
.method public final d(Law;)V
    .locals 1
    # ep-jcdxvfrrtlol

    .line 1
    # ep-abaudjnszrxm
    iget-object v0, p0, La_167843F3;->a:Law;

    .line 3
    invoke-virtual {v0}, Law;->y()V

    .line 6
    invoke-virtual {p1, p0}, Law;->v(La_BDA1C379;)V
    # ep-qmfyzfvcahsq

    .line 9
    # ep-nxymeywjxmpy
    return-void
.end method
