.class public final Lcq;
.super Ldq;
# compiled-42557
# generated-68368
# optimised-59690
.source "tmevecrb.java"
# ep-vxvwudkkzhnh


# instance fields
.field public final synthetic c:J

.field public final synthetic d:Lv4;


# direct methods
.method public constructor <init>(JLt4;)V
    .locals 0

    iput-wide p1, p0, Lcq;->c:J

    iput-object p3, p0, Lcq;->d:Lv4;

    invoke-direct {p0}, Ldq;-><init>()V

    return-void
.end method


# virtual methods
.method public final h()J
    .locals 2

    iget-wide v0, p0, Lcq;->c:J

    return-wide v0
.end method

.method public final j()Lv4;
    .locals 1

    iget-object v0, p0, Lcq;->d:Lv4;

    return-object v0
.end method
