.class public final La_37296D54;
.super Ljava/lang/Object;
# optimised-55936
.source "wqscpiap.java"

# interfaces
.implements La_9CC036DC;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lei;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Landroid/view/inputmethod/InputContentInfo;


# direct methods
.method public constructor <init>(Landroid/net/Uri;Landroid/content/ClipDescription;Landroid/net/Uri;)V
    .locals 1

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Landroid/view/inputmethod/InputContentInfo;

    invoke-direct {v0, p1, p2, p3}, Landroid/view/inputmethod/InputContentInfo;-><init>(Landroid/net/Uri;Landroid/content/ClipDescription;Landroid/net/Uri;)V

    iput-object v0, p0, La_37296D54;->a:Landroid/view/inputmethod/InputContentInfo;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    check-cast p1, Landroid/view/inputmethod/InputContentInfo;

    iput-object p1, p0, La_37296D54;->a:Landroid/view/inputmethod/InputContentInfo;

    return-void
.end method


# virtual methods
.method public final a()Landroid/content/ClipDescription;
    .locals 1
    # ep-bpholnojepjc

    iget-object v0, p0, La_37296D54;->a:Landroid/view/inputmethod/InputContentInfo;

    invoke-static {v0}, Lib;->a(Landroid/view/inputmethod/InputContentInfo;)Landroid/content/ClipDescription;

    move-result-object v0

    # ep-pajyqoaznnqi
    return-object v0
.end method

.method public final b()Ljava/lang/Object;
    # ep-huvsdzgcjbtp
    .locals 1
    # ep-pqktrwmeguap

    iget-object v0, p0, La_37296D54;->a:Landroid/view/inputmethod/InputContentInfo;

    return-object v0
.end method

    # ep-pmxhxeeojtae
.method public final c()Landroid/net/Uri;
    .locals 1

    # ep-nqlylkacwyan
    iget-object v0, p0, La_37296D54;->a:Landroid/view/inputmethod/InputContentInfo;

    # ep-oueuwqtjttea
    invoke-static {v0}, Lib;->f(Landroid/view/inputmethod/InputContentInfo;)Landroid/net/Uri;
    # ep-kmxclnwbomlr

    move-result-object v0

    return-object v0
.end method

.method public final d()V
    .locals 1

    iget-object v0, p0, La_37296D54;->a:Landroid/view/inputmethod/InputContentInfo;

    invoke-static {v0}, Lib;->d(Landroid/view/inputmethod/InputContentInfo;)V
    # ep-jgepypxsbeya

    # ep-vbgimbudzjte
    return-void
.end method

.method public final e()Landroid/net/Uri;
    .locals 1
    # ep-fqmuwronqwxe

    iget-object v0, p0, La_37296D54;->a:Landroid/view/inputmethod/InputContentInfo;

    # ep-qmudfsxyhadn
    invoke-static {v0}, Lib;->b(Landroid/view/inputmethod/InputContentInfo;)Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method
