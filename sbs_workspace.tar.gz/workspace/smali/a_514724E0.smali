.class public final La_514724E0;
.super La_B5CC035A;
.source "daaqurfj.java"
# optimised-75341
# compiled-91537


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lwq$e<",
        "TK;TV;>;"
    }
.end annotation


# direct methods
.method public constructor <init>(La_8C27E16D;La_8C27E16D;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;",
            "Lwq$c<",
            "TK;TV;>;)V"
        }
    .end annotation

    invoke-direct {p0, p1, p2}, La_B5CC035A;-><init>(La_8C27E16D;La_8C27E16D;)V

    return-void
.end method


# virtual methods
.method public final b(La_8C27E16D;)La_8C27E16D;
    .locals 0
    # ep-ezwsanuhdwas
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;)",
            "Lwq$c<",
    # ep-mtcvxrewazea
            "TK;TV;>;"
        }
    .end annotation
    # ep-bhrpligtwzsf

    # ep-imbnsqwgiqxg
    iget-object p1, p1, La_8C27E16D;->e:La_8C27E16D;

    return-object p1
.end method

.method public final c(La_8C27E16D;)La_8C27E16D;
    # ep-nmslhbqzxtwu
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
    # ep-iqnggyetkacx
            "Lwq$c<",
            "TK;TV;>;)",
            "Lwq$c<",
            "TK;TV;>;"
        }
    .end annotation
    # ep-gwgmamdviyif

    iget-object p1, p1, La_8C27E16D;->f:La_8C27E16D;
    # ep-ejqppdacbqco

    return-object p1
.end method
