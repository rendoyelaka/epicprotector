.class public final La_0649B0EC;
.super Laj;
.source "bfuqsmsv.java"

# processed-28169
# compiled-23822
# verified-65142
# ep-cytaockzkjwx
# interfaces
.implements Lhf;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_1BE7F6EB;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Laj;",
        "Lhf<",
        "La_0ED6D319;",
        "La_E7143AC8;",
        ">;"
    }
.end annotation


# static fields
.field public static final c:La_0649B0EC;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_0649B0EC;

    invoke-direct {v0}, La_0649B0EC;-><init>()V

    sput-object v0, La_0649B0EC;->c:La_0649B0EC;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Laj;-><init>()V

    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, La_0ED6D319;

    .line 3
    instance-of v0, p1, La_E7143AC8;

    .line 5
    if-eqz v0, :cond_0

    .line 7
    check-cast p1, La_E7143AC8;

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 p1, 0x0

    .line 11
    :goto_0
    return-object p1
.end method
