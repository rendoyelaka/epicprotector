.class public La_61D732A6;
.super Landroid/widget/AutoCompleteTextView;
# generated-88664
# generated-98865
# generated-40398
# ep-endpoouadvux
.source "lqjfjaoh.java"

# interfaces
.implements Lov;


# static fields
.field public static final f:[I


# instance fields
.field public final c:La_0D850CD8;

.field public final d:La_1CAFA37F;

.field public final e:La_9AC5F7FC;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    new-array v0, v0, [I

    .line 4
    const/4 v1, 0x0

    .line 5
    const v2, 0x1010176

    .line 8
    aput v2, v0, v1

    .line 10
    sput-object v0, La_61D732A6;->f:[I

    .line 12
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, p2, v0}, La_61D732A6;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 3

    .line 2
    invoke-static {p1}, Ljv;->a(Landroid/content/Context;)V

    const p3, 0x7f03003c

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/AutoCompleteTextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 3
    invoke-virtual {p0}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    move-result-object p1

    invoke-static {p0, p1}, Lav;->a(Landroid/view/View;Landroid/content/Context;)V

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    move-result-object p1

    sget-object v0, La_61D732A6;->f:[I

    invoke-static {p1, p2, v0, p3}, Lmv;->m(Landroid/content/Context;Landroid/util/AttributeSet;[II)Lmv;

    move-result-object p1

    const/4 v0, 0x0

    .line 5
    invoke-virtual {p1, v0}, Lmv;->l(I)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 6
    invoke-virtual {p1, v0}, Lmv;->e(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/widget/AutoCompleteTextView;->setDropDownBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 7
    :cond_0
    invoke-virtual {p1}, Lmv;->n()V

    .line 8
    new-instance p1, La_0D850CD8;

    invoke-direct {p1, p0}, La_0D850CD8;-><init>(Landroid/view/View;)V

    iput-object p1, p0, La_61D732A6;->c:La_0D850CD8;

    .line 9
    invoke-virtual {p1, p2, p3}, La_0D850CD8;->d(Landroid/util/AttributeSet;I)V

    .line 10
    new-instance p1, La_1CAFA37F;

    invoke-direct {p1, p0}, La_1CAFA37F;-><init>(Landroid/widget/TextView;)V

    iput-object p1, p0, La_61D732A6;->d:La_1CAFA37F;

    .line 11
    invoke-virtual {p1, p2, p3}, La_1CAFA37F;->f(Landroid/util/AttributeSet;I)V

    .line 12
    invoke-virtual {p1}, La_1CAFA37F;->b()V

    .line 13
    new-instance p1, La_9AC5F7FC;

    invoke-direct {p1, p0}, La_9AC5F7FC;-><init>(Landroid/widget/EditText;)V

    iput-object p1, p0, La_61D732A6;->e:La_9AC5F7FC;

    .line 14
    invoke-virtual {p1, p2, p3}, La_9AC5F7FC;->b(Landroid/util/AttributeSet;I)V

    .line 15
    invoke-virtual {p0}, Landroid/widget/TextView;->getKeyListener()Landroid/text/method/KeyListener;

    move-result-object p2

    .line 16
    instance-of p3, p2, Landroid/text/method/NumberKeyListener;

    xor-int/lit8 p3, p3, 0x1

    if-eqz p3, :cond_2

    .line 17
    invoke-super {p0}, Landroid/widget/AutoCompleteTextView;->isFocusable()Z

    move-result p3

    .line 18
    invoke-super {p0}, Landroid/widget/AutoCompleteTextView;->isClickable()Z

    move-result v0

    .line 19
    invoke-super {p0}, Landroid/widget/AutoCompleteTextView;->isLongClickable()Z

    move-result v1

    .line 20
    invoke-super {p0}, Landroid/widget/AutoCompleteTextView;->getInputType()I

    move-result v2

    .line 21
    invoke-virtual {p1, p2}, La_9AC5F7FC;->a(Landroid/text/method/KeyListener;)Landroid/text/method/KeyListener;

    move-result-object p1

    if-ne p1, p2, :cond_1

    goto :goto_0

    .line 22
    :cond_1
    invoke-super {p0, p1}, Landroid/widget/AutoCompleteTextView;->m_d92bd184(Landroid/text/method/KeyListener;)V

    .line 23
    invoke-super {p0, v2}, Landroid/widget/AutoCompleteTextView;->setRawInputType(I)V

    .line 24
    invoke-super {p0, p3}, Landroid/widget/AutoCompleteTextView;->setFocusable(Z)V

    .line 25
    invoke-super {p0, v0}, Landroid/widget/AutoCompleteTextView;->setClickable(Z)V

    .line 26
    invoke-super {p0, v1}, Landroid/widget/AutoCompleteTextView;->setLongClickable(Z)V

    :cond_2
    :goto_0
    return-void
.end method


# virtual methods
.method public final m_cb26974e()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/AutoCompleteTextView;->m_cb26974e()V

    .line 4
    iget-object v0, p0, La_61D732A6;->c:La_0D850CD8;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, La_0D850CD8;->a()V

    .line 11
    :cond_0
    iget-object v0, p0, La_61D732A6;->d:La_1CAFA37F;

    .line 13
    if-eqz v0, :cond_1

    .line 15
    invoke-virtual {v0}, La_1CAFA37F;->b()V

    .line 18
    :cond_1
    return-void
.end method

.method public m_d2f56bdd()Landroid/view/ActionMode$Callback;
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/AutoCompleteTextView;->m_d2f56bdd()Landroid/view/ActionMode$Callback;

    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Lwu;->f(Landroid/view/ActionMode$Callback;)Landroid/view/ActionMode$Callback;

    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public m_4eb19bca()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, La_61D732A6;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_0D850CD8;->b()Landroid/content/res/ColorStateList;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_c605babf()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, La_61D732A6;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_0D850CD8;->c()Landroid/graphics/PorterDuff$Mode;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_d7d2cbaa()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, La_61D732A6;->d:La_1CAFA37F;

    invoke-virtual {v0}, La_1CAFA37F;->d()Landroid/content/res/ColorStateList;

    move-result-object v0

    return-object v0
.end method

.method public m_93878187()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    iget-object v0, p0, La_61D732A6;->d:La_1CAFA37F;

    invoke-virtual {v0}, La_1CAFA37F;->e()Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    return-object v0
.end method

.method public onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .locals 2

    .line 1
    invoke-super {p0, p1}, Landroid/widget/AutoCompleteTextView;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    .line 4
    move-result-object v0

    .line 5
    invoke-static {p0, p1, v0}, La_F5C4F8D6;->m_fabc7ccf(Landroid/view/View;Landroid/view/inputmethod/EditorInfo;Landroid/view/inputmethod/InputConnection;)V

    .line 8
    iget-object v1, p0, La_61D732A6;->e:La_9AC5F7FC;

    .line 10
    invoke-virtual {v1, v0, p1}, La_9AC5F7FC;->c(Landroid/view/inputmethod/InputConnection;Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    .line 13
    move-result-object p1

    .line 14
    return-object p1
.end method

.method public m_08385e47(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/AutoCompleteTextView;->m_08385e47(Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_61D732A6;->c:La_0D850CD8;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_0D850CD8;->e()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_ee40bba3(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/AutoCompleteTextView;->m_ee40bba3(I)V

    .line 4
    iget-object v0, p0, La_61D732A6;->c:La_0D850CD8;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1}, La_0D850CD8;->f(I)V

    .line 11
    :cond_0
    return-void
.end method

.method public final m_4e411e88(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/AutoCompleteTextView;->m_4e411e88(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_61D732A6;->d:La_1CAFA37F;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_1CAFA37F;->b()V

    .line 11
    :cond_0
    return-void
.end method

.method public final m_26748812(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/AutoCompleteTextView;->m_26748812(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_61D732A6;->d:La_1CAFA37F;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_1CAFA37F;->b()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_43b91c56(Landroid/view/ActionMode$Callback;)V
    .locals 0

    .line 1
    invoke-static {p1, p0}, Lwu;->g(Landroid/view/ActionMode$Callback;Landroid/widget/TextView;)Landroid/view/ActionMode$Callback;

    .line 4
    move-result-object p1

    .line 5
    invoke-super {p0, p1}, Landroid/widget/AutoCompleteTextView;->m_43b91c56(Landroid/view/ActionMode$Callback;)V

    .line 8
    return-void
.end method

.method public m_ffe0d5f8(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, La_F5C4F8D6;->m_7bf4cde2(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/widget/AutoCompleteTextView;->setDropDownBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public m_63db9ddc(Z)V
    .locals 1

    iget-object v0, p0, La_61D732A6;->e:La_9AC5F7FC;

    invoke-virtual {v0, p1}, La_9AC5F7FC;->d(Z)V

    return-void
.end method

.method public m_d92bd184(Landroid/text/method/KeyListener;)V
    .locals 1

    iget-object v0, p0, La_61D732A6;->e:La_9AC5F7FC;

    invoke-virtual {v0, p1}, La_9AC5F7FC;->a(Landroid/text/method/KeyListener;)Landroid/text/method/KeyListener;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/widget/AutoCompleteTextView;->m_d92bd184(Landroid/text/method/KeyListener;)V

    return-void
.end method

.method public m_44b49f65(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_61D732A6;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_0D850CD8;->h(Landroid/content/res/ColorStateList;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_10b86d4b(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_61D732A6;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_0D850CD8;->i(Landroid/graphics/PorterDuff$Mode;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_30fdcbb6(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_61D732A6;->d:La_1CAFA37F;

    .line 3
    invoke-virtual {v0, p1}, La_1CAFA37F;->l(Landroid/content/res/ColorStateList;)V

    .line 6
    invoke-virtual {v0}, La_1CAFA37F;->b()V

    .line 9
    return-void
.end method

.method public m_ad713641(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_61D732A6;->d:La_1CAFA37F;

    .line 3
    invoke-virtual {v0, p1}, La_1CAFA37F;->m(Landroid/graphics/PorterDuff$Mode;)V

    .line 6
    invoke-virtual {v0}, La_1CAFA37F;->b()V

    .line 9
    return-void
.end method

.method public final m_f1267819(Landroid/content/Context;I)V
    .locals 1

    .line 1
    invoke-super {p0, p1, p2}, Landroid/widget/AutoCompleteTextView;->m_f1267819(Landroid/content/Context;I)V

    .line 4
    iget-object v0, p0, La_61D732A6;->d:La_1CAFA37F;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1, p2}, La_1CAFA37F;->g(Landroid/content/Context;I)V

    .line 11
    :cond_0
    return-void
.end method
