.class public abstract La_2D961EB8;
.super Ljava/lang/Object;
.source "rxiwsooi.java"


# optimised-62349
# verified-72531
# generated-32680
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lqe;)V
    # ep-fkmcqhkfzqhi
    .locals 0
    # ep-buquegqwhuvn

    return-void
.end method
