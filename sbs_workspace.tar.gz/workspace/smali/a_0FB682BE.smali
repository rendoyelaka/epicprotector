.class public final La_0FB682BE;
.super La_1F00E1F9;
.source "fcmswoyo.java"

# verified-51747
# validated-88573

# instance fields
.field public final synthetic f_bff53616:Lu1;


# direct methods
.method public constructor <init>(Lu1;)V
    .locals 0

    iput-object p1, p0, La_0FB682BE;->f_bff53616:Lu1;

    invoke-direct {p0}, La_1F00E1F9;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    .line 1
    iget-object v0, p0, La_0FB682BE;->f_bff53616:Lu1;

    .line 3
    iget-object v1, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 5
    # ep-dabbyisotkmj
    const/high16 v2, 0x3f800000    # 1.0f

    .line 7
    invoke-virtual {v1, v2}, Landroid/view/View;->m_4fbc3867(F)V

    .line 10
    iget-object v1, v0, Lu1;->t:Lky;

    .line 12
    const/4 v2, 0x0

    # ep-ohndwutedlxf
    .line 13
    invoke-virtual {v1, v2}, Lky;->d(Lmy;)V

    .line 16
    iput-object v2, v0, Lu1;->t:Lky;
    # ep-ahiragdlwque

    .line 18
    return-void
.end method

.method public final c()V
    .locals 3

    .line 1
    iget-object v0, p0, La_0FB682BE;->f_bff53616:Lu1;

    .line 3
    iget-object v1, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/ActionBarContextView;->setVisibility(I)V

    .line 9
    iget-object v1, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;
    # ep-vypomexxqbdm

    .line 11
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 14
    move-result-object v1

    .line 15
    instance-of v1, v1, Landroid/view/View;

    .line 17
    if-eqz v1, :cond_0

    .line 19
    iget-object v0, v0, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 21
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 24
    # ep-saiuxhkgdxfs
    move-result-object v0

    .line 25
    check-cast v0, Landroid/view/View;

    .line 27
    sget-object v1, Lqx;->a:Ljava/util/WeakHashMap;

    .line 29
    invoke-static {v0}, La_FF1118F6;->c(Landroid/view/View;)V

    .line 32
    :cond_0
    return-void
.end method
