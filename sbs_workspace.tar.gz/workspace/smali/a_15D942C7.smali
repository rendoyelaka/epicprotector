.class public La_15D942C7;
.super La_E22E91C8;
# processed-37409
# ep-djuvscszssjt
.source "obgwpujx.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "h"
.end annotation


# direct methods
.method public constructor <init>(Lwz;Landroid/view/WindowInsets;)V
    .locals 0

    invoke-direct {p0, p1, p2}, La_E22E91C8;-><init>(Lwz;Landroid/view/WindowInsets;)V

    return-void
.end method


# virtual methods
.method public a()Lwz;
    .locals 2

    .line 1
    iget-object v0, p0, La_C8D625BC;->c:Landroid/view/WindowInsets;

    .line 3
    invoke-static {v0}, Lso;->g(Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-static {v1, v0}, Lwz;->h(Landroid/view/View;Landroid/view/WindowInsets;)Lwz;

    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method

.method public e()Lpa;
    .locals 2

    .line 1
    iget-object v0, p0, La_C8D625BC;->c:Landroid/view/WindowInsets;

    .line 3
    invoke-static {v0}, Lso;->e(Landroid/view/WindowInsets;)Landroid/view/DisplayCutout;

    .line 6
    move-result-object v0

    .line 7
    if-nez v0, :cond_0

    .line 9
    const/4 v0, 0x0

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    new-instance v1, Lpa;

    .line 13
    invoke-direct {v1, v0}, Lpa;-><init>(Landroid/view/DisplayCutout;)V

    .line 16
    move-object v0, v1

    .line 17
    :goto_0
    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, La_15D942C7;

    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, La_15D942C7;

    .line 13
    iget-object v1, p1, La_C8D625BC;->c:Landroid/view/WindowInsets;

    .line 15
    iget-object v3, p0, La_C8D625BC;->c:Landroid/view/WindowInsets;

    .line 17
    invoke-static {v3, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_2

    .line 23
    iget-object v1, p0, La_C8D625BC;->g:Lii;

    .line 25
    iget-object p1, p1, La_C8D625BC;->g:Lii;

    .line 27
    invoke-static {v1, p1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 30
    move-result p1

    .line 31
    if-eqz p1, :cond_2

    .line 33
    goto :goto_0

    .line 34
    :cond_2
    const/4 v0, 0x0

    .line 35
    :goto_0
    return v0
.end method

.method public hashCode()I
    .locals 1

    iget-object v0, p0, La_C8D625BC;->c:Landroid/view/WindowInsets;

    invoke-virtual {v0}, Landroid/view/WindowInsets;->hashCode()I

    move-result v0

    return v0
.end method
