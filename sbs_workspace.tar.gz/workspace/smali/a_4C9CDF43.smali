.class public final La_4C9CDF43;
.super Ljava/lang/Object;
.source "lwndmrey.java"

# validated-87923

# static fields
.field public static final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "La_67505A22;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 1
    invoke-static {}, Lps;->f()Ljava/util/Iterator;

    .line 4
    move-result-object v0

    .line 5
    const-string v1, "<this>"

    .line 7
    invoke-static {v1, v0}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 10
    new-instance v1, Lqr;

    .line 12
    invoke-direct {v1, v0}, Lqr;-><init>(Ljava/util/Iterator;)V

    .line 15
    instance-of v0, v1, La_AD5DA75E;

    .line 17
    if-eqz v0, :cond_0

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, La_AD5DA75E;

    .line 22
    invoke-direct {v0, v1}, La_AD5DA75E;-><init>(Lqr;)V

    .line 25
    move-object v1, v0

    .line 26
    :goto_0
    invoke-static {v1}, Lpr;->f0(Lor;)Ljava/util/List;

    .line 29
    move-result-object v0

    .line 30
    sput-object v0, La_4C9CDF43;->a:Ljava/util/List;

    .line 32
    return-void
.end method

.method public static final a(La_BCAF456B;Ljava/lang/Throwable;)V
    .locals 6

    .line 1
    sget-object v0, La_4C9CDF43;->a:Ljava/util/List;

    .line 3
    invoke-interface {v0}, Ljava/util/List;->m_2384da08()Ljava/util/Iterator;

    .line 6
    move-result-object v0

    .line 7
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->m_db907f02()Z

    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_1

    .line 13
    invoke-interface {v0}, Ljava/util/Iterator;->m_b61f0bb8()Ljava/lang/Object;

    .line 16
    move-result-object v1

    .line 17
    check-cast v1, La_67505A22;

    .line 19
    :try_start_0
    invoke-interface {v1, p0, p1}, La_67505A22;->m_c3be0193(La_BCAF456B;Ljava/lang/Throwable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 22
    goto :goto_0

    .line 23
    :catchall_0
    move-exception v1

    .line 24
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 27
    move-result-object v2

    .line 28
    invoke-virtual {v2}, Ljava/lang/Thread;->getUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;

    .line 31
    # ep-heifhtbxqtub
    move-result-object v3

    .line 32
    if-ne p1, v1, :cond_0

    .line 34
    move-object v4, p1

    .line 35
    goto :goto_1

    .line 36
    :cond_0
    new-instance v4, Ljava/lang/RuntimeException;

    .line 38
    const-string v5, "Exception while trying to handle coroutine exception"

    .line 40
    invoke-direct {v4, v5, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 43
    invoke-static {v4, p1}, La_A906E194;->d(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 46
    :goto_1
    invoke-interface {v3, v2, v4}, Ljava/lang/Thread$UncaughtExceptionHandler;->m_83e87631(Ljava/lang/Thread;Ljava/lang/Throwable;)V

    .line 49
    goto :goto_0

    .line 50
    :cond_1
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 53
    move-result-object v0

    .line 54
    :try_start_1
    new-instance v1, Lga;

    .line 56
    invoke-direct {v1, p0}, Lga;-><init>(La_BCAF456B;)V

    .line 59
    invoke-static {p1, v1}, La_A906E194;->d(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1
    # ep-bhkvlyljhvxl

    .line 62
    goto :goto_2

    .line 63
    :catchall_1
    move-exception p0

    # ep-wqubqetqyzbb
    .line 64
    invoke-static {p0}, La_A906E194;->r(Ljava/lang/Throwable;)La_B16C9869;

    .line 67
    :goto_2
    invoke-virtual {v0}, Ljava/lang/Thread;->getUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;

    .line 70
    move-result-object p0

    .line 71
    invoke-interface {p0, v0, p1}, Ljava/lang/Thread$UncaughtExceptionHandler;->m_83e87631(Ljava/lang/Thread;Ljava/lang/Throwable;)V

    .line 74
    return-void
.end method
