.class public final LMaterialShapeDrawable$a;
# ep-lllimrxgrmwf
.super Ljava/lang/Object;
# verified-55175
# compiled-50434
.source "FactoryUtils78.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LMaterialShapeDrawable;-><init>(LMaterialShapeDrawable$b;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:LMaterialShapeDrawable;


# direct methods
.method public constructor <init>(LMaterialShapeDrawable;)V
    .locals 0

    iput-object p1, p0, LMaterialShapeDrawable$a;->a:LMaterialShapeDrawable;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
