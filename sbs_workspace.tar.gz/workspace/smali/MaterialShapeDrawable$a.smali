.class public final LMaterialShapeDrawable$a;
# listener-86125-binding
# dispatcher-69579-loader
# observer-52516-context
.super Ljava/lang/Object;
# validated-23503
# validated-50206
# generated-21922
.source "BackgroundHelper25.java"
# ep-umnpvugumymc


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LMaterialShapeDrawable;-><init>(LMaterialShapeDrawable$b;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:LMaterialShapeDrawable;


# direct methods
.method public constructor <init>(LMaterialShapeDrawable;)V
    .locals 0

    iput-object p1, p0, LMaterialShapeDrawable$a;->a:LMaterialShapeDrawable;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
