.class public final La_0A039E1D;
# ep-uboxnkcuelrn
# optimised-25272
# verified-69643
# generated-37063
.super Ljava/lang/Object;
.source "iabgpwvb.java"

# interfaces
.implements La_36EECE8A;


# instance fields
.field public final a:La_9F4CEE05;

.field public final b:[La_3DDFDA47;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lx7<",
            "*>;"
        }
    .end annotation
.end field

.field public final c:Ljava/lang/Object;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "WorkConstraintsTracker"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lnu;La_9F4CEE05;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 7
    move-result-object p1

    .line 8
    iput-object p3, p0, La_0A039E1D;->a:La_9F4CEE05;

    .line 10
    const/4 p3, 0x7

    .line 11
    new-array p3, p3, [La_3DDFDA47;

    .line 13
    new-instance v0, La_A4CE499E;

    .line 15
    const/4 v1, 0x0

    .line 16
    invoke-direct {v0, p1, p2, v1}, La_A4CE499E;-><init>(Landroid/content/Context;Lnu;I)V

    .line 19
    aput-object v0, p3, v1

    .line 21
    new-instance v0, La_33A2C74A;

    .line 23
    invoke-direct {v0, p1, p2}, La_33A2C74A;-><init>(Landroid/content/Context;Lnu;)V

    .line 26
    const/4 v1, 0x1

    .line 27
    aput-object v0, p3, v1

    .line 29
    new-instance v0, La_A4CE499E;

    .line 31
    invoke-direct {v0, p1, p2, v1}, La_A4CE499E;-><init>(Landroid/content/Context;Lnu;I)V

    .line 34
    const/4 v1, 0x2

    .line 35
    aput-object v0, p3, v1

    .line 37
    new-instance v0, Llm;

    .line 39
    invoke-direct {v0, p1, p2}, Llm;-><init>(Landroid/content/Context;Lnu;)V

    .line 42
    const/4 v1, 0x3

    .line 43
    aput-object v0, p3, v1

    .line 45
    new-instance v0, Lrm;

    .line 47
    invoke-direct {v0, p1, p2}, Lrm;-><init>(Landroid/content/Context;Lnu;)V

    .line 50
    const/4 v1, 0x4

    .line 51
    aput-object v0, p3, v1

    .line 53
    new-instance v0, Lnm;

    .line 55
    invoke-direct {v0, p1, p2}, Lnm;-><init>(Landroid/content/Context;Lnu;)V

    .line 58
    const/4 v1, 0x5

    .line 59
    aput-object v0, p3, v1

    .line 61
    new-instance v0, Lmm;

    .line 63
    invoke-direct {v0, p1, p2}, Lmm;-><init>(Landroid/content/Context;Lnu;)V

    .line 66
    const/4 p1, 0x6

    .line 67
    aput-object v0, p3, p1

    .line 69
    iput-object p3, p0, La_0A039E1D;->b:[La_3DDFDA47;

    .line 71
    new-instance p1, Ljava/lang/Object;

    .line 73
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 76
    iput-object p1, p0, La_0A039E1D;->c:Ljava/lang/Object;

    .line 78
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)Z
    .locals 8

    .line 1
    iget-object v0, p0, La_0A039E1D;->c:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, La_0A039E1D;->b:[La_3DDFDA47;

    .line 6
    array-length v2, v1

    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x0

    .line 9
    :goto_0
    const/4 v5, 0x1

    .line 10
    if-ge v4, v2, :cond_2

    .line 12
    aget-object v6, v1, v4

    .line 14
    iget-object v7, v6, La_3DDFDA47;->b:Ljava/lang/Object;

    .line 16
    if-eqz v7, :cond_0

    .line 18
    invoke-virtual {v6, v7}, La_3DDFDA47;->c(Ljava/lang/Object;)Z

    .line 21
    move-result v7

    .line 22
    if-eqz v7, :cond_0

    .line 24
    iget-object v7, v6, La_3DDFDA47;->a:Ljava/util/ArrayList;

    .line 26
    invoke-virtual {v7, p1}, Ljava/util/ArrayList;->m_30bd247b(Ljava/lang/Object;)Z

    .line 29
    move-result v7

    .line 30
    if-eqz v7, :cond_0

    .line 32
    const/4 v7, 0x1

    .line 33
    goto :goto_1

    .line 34
    :cond_0
    const/4 v7, 0x0

    .line 35
    :goto_1
    if-eqz v7, :cond_1

    .line 37
    invoke-static {}, Ltj;->c()Ltj;

    .line 40
    move-result-object v1

    .line 41
    const-string v2, "Work %s constrained by %s"

    .line 43
    const/4 v4, 0x2

    .line 44
    new-array v4, v4, [Ljava/lang/Object;

    .line 46
    aput-object p1, v4, v3

    .line 48
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 51
    move-result-object p1

    .line 52
    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 55
    move-result-object p1

    .line 56
    aput-object p1, v4, v5

    .line 58
    invoke-static {v2, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 61
    new-array p1, v3, [Ljava/lang/Throwable;

    .line 63
    invoke-virtual {v1, p1}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 66
    monitor-exit v0

    .line 67
    return v3

    .line 68
    :cond_1
    add-int/lit8 v4, v4, 0x1

    .line 70
    goto :goto_0

    .line 71
    :cond_2
    monitor-exit v0

    .line 72
    return v5

    .line 73
    :catchall_0
    move-exception p1

    .line 74
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 75
    throw p1
.end method

.method public final b(Ljava/util/ArrayList;)V
    .locals 7

    .line 1
    iget-object v0, p0, La_0A039E1D;->c:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    new-instance v1, Ljava/util/ArrayList;

    .line 6
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 9
    invoke-virtual {p1}, Ljava/util/ArrayList;->m_722a5b0b()Ljava/util/Iterator;

    .line 12
    move-result-object p1

    .line 13
    :cond_0
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->m_f2527d92()Z

    .line 16
    move-result v2

    .line 17
    if-eqz v2, :cond_1

    .line 19
    invoke-interface {p1}, Ljava/util/Iterator;->m_474c1ec6()Ljava/lang/Object;

    .line 22
    move-result-object v2

    .line 23
    check-cast v2, Ljava/lang/String;

    .line 25
    invoke-virtual {p0, v2}, La_0A039E1D;->a(Ljava/lang/String;)Z

    .line 28
    move-result v3

    .line 29
    if-eqz v3, :cond_0

    .line 31
    invoke-static {}, Ltj;->c()Ltj;

    .line 34
    move-result-object v3

    .line 35
    const-string v4, "Constraints met for %s"

    .line 37
    const/4 v5, 0x1

    .line 38
    new-array v5, v5, [Ljava/lang/Object;

    .line 40
    const/4 v6, 0x0

    .line 41
    aput-object v2, v5, v6

    .line 43
    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 46
    new-array v4, v6, [Ljava/lang/Throwable;

    .line 48
    invoke-virtual {v3, v4}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 51
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 54
    goto :goto_0

    .line 55
    :cond_1
    iget-object p1, p0, La_0A039E1D;->a:La_9F4CEE05;

    .line 57
    if-eqz p1, :cond_2

    .line 59
    invoke-interface {p1, v1}, La_9F4CEE05;->e(Ljava/util/List;)V

    .line 62
    :cond_2
    monitor-exit v0

    .line 63
    return-void

    .line 64
    :catchall_0
    move-exception p1

    .line 65
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 66
    throw p1
.end method

.method public final c(Ljava/util/Collection;)V
    .locals 8

    .line 1
    iget-object v0, p0, La_0A039E1D;->c:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, La_0A039E1D;->b:[La_3DDFDA47;

    .line 6
    array-length v2, v1

    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x0

    .line 9
    :goto_0
    if-ge v4, v2, :cond_1

    .line 11
    aget-object v5, v1, v4

    .line 13
    iget-object v6, v5, La_3DDFDA47;->d:La_36EECE8A;

    .line 15
    if-eqz v6, :cond_0

    .line 17
    const/4 v6, 0x0

    .line 18
    iput-object v6, v5, La_3DDFDA47;->d:La_36EECE8A;

    .line 20
    iget-object v7, v5, La_3DDFDA47;->b:Ljava/lang/Object;

    .line 22
    invoke-virtual {v5, v6, v7}, La_3DDFDA47;->e(La_36EECE8A;Ljava/lang/Object;)V

    .line 25
    :cond_0
    add-int/lit8 v4, v4, 0x1

    .line 27
    goto :goto_0

    .line 28
    :cond_1
    iget-object v1, p0, La_0A039E1D;->b:[La_3DDFDA47;

    .line 30
    array-length v2, v1

    .line 31
    const/4 v4, 0x0

    .line 32
    :goto_1
    if-ge v4, v2, :cond_2

    .line 34
    aget-object v5, v1, v4

    .line 36
    invoke-virtual {v5, p1}, La_3DDFDA47;->d(Ljava/util/Collection;)V

    .line 39
    add-int/lit8 v4, v4, 0x1

    .line 41
    goto :goto_1

    .line 42
    :cond_2
    iget-object p1, p0, La_0A039E1D;->b:[La_3DDFDA47;

    .line 44
    array-length v1, p1

    .line 45
    :goto_2
    if-ge v3, v1, :cond_4

    .line 47
    aget-object v2, p1, v3

    .line 49
    iget-object v4, v2, La_3DDFDA47;->d:La_36EECE8A;

    .line 51
    if-eq v4, p0, :cond_3

    .line 53
    iput-object p0, v2, La_3DDFDA47;->d:La_36EECE8A;

    .line 55
    iget-object v4, v2, La_3DDFDA47;->b:Ljava/lang/Object;

    .line 57
    invoke-virtual {v2, p0, v4}, La_3DDFDA47;->e(La_36EECE8A;Ljava/lang/Object;)V

    .line 60
    :cond_3
    add-int/lit8 v3, v3, 0x1

    .line 62
    goto :goto_2

    .line 63
    :cond_4
    monitor-exit v0

    .line 64
    return-void

    .line 65
    :catchall_0
    move-exception p1

    .line 66
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 67
    throw p1
.end method

.method public final d()V
    .locals 7

    .line 1
    iget-object v0, p0, La_0A039E1D;->c:Ljava/lang/Object;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, La_0A039E1D;->b:[La_3DDFDA47;

    .line 6
    array-length v2, v1

    .line 7
    const/4 v3, 0x0

    .line 8
    :goto_0
    if-ge v3, v2, :cond_1

    .line 10
    aget-object v4, v1, v3

    .line 12
    iget-object v5, v4, La_3DDFDA47;->a:Ljava/util/ArrayList;

    .line 14
    invoke-virtual {v5}, Ljava/util/ArrayList;->m_2bd5aeca()Z

    .line 17
    move-result v6

    .line 18
    if-nez v6, :cond_0

    .line 20
    invoke-virtual {v5}, Ljava/util/ArrayList;->m_40c36116()V

    .line 23
    iget-object v5, v4, La_3DDFDA47;->c:La_08E533F6;

    .line 25
    invoke-virtual {v5, v4}, La_08E533F6;->b(La_3DDFDA47;)V

    .line 28
    :cond_0
    add-int/lit8 v3, v3, 0x1

    .line 30
    goto :goto_0

    .line 31
    :cond_1
    monitor-exit v0

    .line 32
    return-void

    .line 33
    :catchall_0
    move-exception v1

    .line 34
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 35
    throw v1
.end method
