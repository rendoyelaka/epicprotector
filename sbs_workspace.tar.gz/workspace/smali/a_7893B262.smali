.class public final La_7893B262;
.super Ljava/lang/Object;
.source "vcmrdfrl.java"
# ep-perpfsomhyqj

# verified-70269
# processed-24813
# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    iput-object p1, p0, La_7893B262;->c:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, La_7893B262;->c:Landroid/content/Context;

    invoke-static {v0}, La_87239DF2;->a(Landroid/content/Context;)V

    return-void
.end method
