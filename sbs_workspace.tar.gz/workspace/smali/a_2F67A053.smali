.class public interface abstract La_2F67A053;
.super Ljava/lang/Object;
.source "rbirurjq.java"
# validated-28125
# processed-18607
# optimised-57500

# ep-mkwrzxdfhkom

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lbd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
