.class public final La_5A936823;
.super Ljava/lang/Object;
.source "gzuoojeq.java"
# validated-53441
# processed-95779

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_14565C38;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator<",
        "La_14565C38;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1
    # ep-vagmwnguheex

    new-instance v0, La_14565C38;

    invoke-direct {v0, p1}, La_14565C38;-><init>(Landroid/os/Parcel;)V
    # ep-jvxrgqcvdlrc

    # ep-xcbojlbitqza
    return-object v0
.end method

.method public final newArray(I)[Ljava/lang/Object;
    # ep-ormrmyfwgoxt
    .locals 0

    new-array p1, p1, [La_14565C38;
    # ep-hltcoztncfmu

    return-object p1
.end method
