.class public final La_46205769;
.super Ljava/lang/Object;
# processed-27708
.source "feobvehi.java"

# ep-modmpahrktfy
# interfaces
.implements La_119635E9;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_119635E9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_dff952ff(Lpq;La_4C1B04CF;)Lnp;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method
