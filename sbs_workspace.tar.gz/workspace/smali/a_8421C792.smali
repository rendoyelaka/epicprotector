.class public final La_8421C792;
.super Ljava/lang/Object;
# ep-wgrxpdkeqepl
.source "csnakpbk.java"
# generated-13825

# interfaces
.implements Lrs;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldh;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "b"
.end annotation


# instance fields
.field public final c:La_A2F8F8F5;

.field public final d:La_A2F8F8F5;

.field public final e:J

.field public f:Z

.field public g:Z

.field public final synthetic h:Ldh;


# direct methods
.method public constructor <init>(Ldh;J)V
    .locals 0

    .line 1
    iput-object p1, p0, La_8421C792;->h:Ldh;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    new-instance p1, La_A2F8F8F5;

    .line 8
    invoke-direct {p1}, La_A2F8F8F5;-><init>()V

    .line 11
    iput-object p1, p0, La_8421C792;->c:La_A2F8F8F5;

    .line 13
    new-instance p1, La_A2F8F8F5;

    .line 15
    invoke-direct {p1}, La_A2F8F8F5;-><init>()V

    .line 18
    iput-object p1, p0, La_8421C792;->d:La_A2F8F8F5;

    .line 20
    iput-wide p2, p0, La_8421C792;->e:J

    .line 22
    return-void
.end method


# virtual methods
.method public final a()Lhv;
    .locals 1

    iget-object v0, p0, La_8421C792;->h:Ldh;

    iget-object v0, v0, Ldh;->h:La_EE0FE900;

    return-object v0
.end method

.method public final m_806d7b76()V
    .locals 4

    .line 1
    iget-object v0, p0, La_8421C792;->h:Ldh;

    .line 3
    monitor-enter v0

    .line 4
    const/4 v1, 0x1

    .line 5
    :try_start_0
    iput-boolean v1, p0, La_8421C792;->f:Z

    .line 7
    iget-object v1, p0, La_8421C792;->d:La_A2F8F8F5;

    .line 9
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 12
    :try_start_1
    iget-wide v2, v1, La_A2F8F8F5;->d:J

    .line 14
    invoke-virtual {v1, v2, v3}, La_A2F8F8F5;->m_d24d36c5(J)V
    :try_end_1
    .catch Ljava/io/EOFException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 17
    :try_start_2
    iget-object v1, p0, La_8421C792;->h:Ldh;

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V

    .line 22
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 23
    iget-object v0, p0, La_8421C792;->h:Ldh;

    .line 25
    invoke-virtual {v0}, Ldh;->a()V

    .line 28
    return-void

    .line 29
    :catch_0
    move-exception v1

    .line 30
    :try_start_3
    new-instance v2, Ljava/lang/AssertionError;

    .line 32
    invoke-direct {v2, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 35
    throw v2

    .line 36
    :catchall_0
    move-exception v1

    .line 37
    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 38
    throw v1
.end method

.method public final k(La_A2F8F8F5;J)J
    .locals 8

    .line 1
    iget-object p2, p0, La_8421C792;->h:Ldh;

    .line 3
    monitor-enter p2

    .line 4
    :try_start_0
    iget-object p3, p0, La_8421C792;->h:Ldh;

    .line 6
    iget-object v0, p3, Ldh;->h:La_EE0FE900;

    .line 8
    invoke-virtual {v0}, La_FD057980;->j()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 11
    :goto_0
    :try_start_1
    iget-object v0, p0, La_8421C792;->d:La_A2F8F8F5;

    .line 13
    iget-wide v0, v0, La_A2F8F8F5;->d:J

    .line 15
    const-wide/16 v2, 0x0

    .line 17
    cmp-long v4, v0, v2

    .line 19
    if-nez v4, :cond_0

    .line 21
    iget-boolean v0, p0, La_8421C792;->g:Z

    .line 23
    if-nez v0, :cond_0

    .line 25
    iget-boolean v0, p0, La_8421C792;->f:Z

    .line 27
    if-nez v0, :cond_0

    .line 29
    iget v0, p3, Ldh;->j:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 31
    if-nez v0, :cond_0

    .line 33
    :try_start_2
    invoke-virtual {p3}, Ljava/lang/Object;->wait()V
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 36
    goto :goto_0

    .line 37
    :catch_0
    :try_start_3
    new-instance p1, Ljava/io/InterruptedIOException;

    .line 39
    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    .line 42
    throw p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 43
    :cond_0
    :try_start_4
    iget-object p3, p3, Ldh;->h:La_EE0FE900;

    .line 45
    invoke-virtual {p3}, La_EE0FE900;->p()V

    .line 48
    iget-boolean p3, p0, La_8421C792;->f:Z

    .line 50
    if-nez p3, :cond_5

    .line 52
    iget-object p3, p0, La_8421C792;->h:Ldh;

    .line 54
    iget v0, p3, Ldh;->j:I

    .line 56
    if-nez v0, :cond_4

    .line 58
    iget-object p3, p0, La_8421C792;->d:La_A2F8F8F5;

    .line 60
    iget-wide v0, p3, La_A2F8F8F5;->d:J

    .line 62
    cmp-long v4, v0, v2

    .line 64
    if-nez v4, :cond_1

    .line 66
    monitor-exit p2

    .line 67
    const-wide/16 p1, -0x1

    .line 69
    return-wide p1

    .line 70
    :cond_1
    const-wide/16 v4, 0x2000

    .line 72
    invoke-static {v4, v5, v0, v1}, Ljava/lang/Math;->min(JJ)J

    .line 75
    move-result-wide v0

    .line 76
    invoke-virtual {p3, p1, v0, v1}, La_A2F8F8F5;->k(La_A2F8F8F5;J)J

    .line 79
    move-result-wide v0

    .line 80
    iget-object p1, p0, La_8421C792;->h:Ldh;

    .line 82
    iget-wide v4, p1, Ldh;->a:J

    .line 84
    add-long/2addr v4, v0

    .line 85
    iput-wide v4, p1, Ldh;->a:J

    .line 87
    iget-object p1, p1, Ldh;->d:La_7E1D99AD;

    .line 89
    iget-object p1, p1, La_7E1D99AD;->n:Lur;

    .line 91
    invoke-virtual {p1}, Lur;->a()I

    .line 94
    move-result p1

    .line 95
    div-int/lit8 p1, p1, 0x2

    .line 97
    int-to-long v6, p1

    .line 98
    cmp-long p1, v4, v6

    .line 100
    if-ltz p1, :cond_2

    .line 102
    iget-object p1, p0, La_8421C792;->h:Ldh;

    .line 104
    iget-object p3, p1, Ldh;->d:La_7E1D99AD;

    .line 106
    iget v4, p1, Ldh;->c:I

    .line 108
    iget-wide v5, p1, Ldh;->a:J

    .line 110
    invoke-virtual {p3, v4, v5, v6}, La_7E1D99AD;->w(IJ)V

    .line 113
    iget-object p1, p0, La_8421C792;->h:Ldh;

    .line 115
    iput-wide v2, p1, Ldh;->a:J

    .line 117
    :cond_2
    monitor-exit p2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 118
    iget-object p1, p0, La_8421C792;->h:Ldh;

    .line 120
    iget-object p1, p1, Ldh;->d:La_7E1D99AD;

    .line 122
    monitor-enter p1

    .line 123
    :try_start_5
    iget-object p2, p0, La_8421C792;->h:Ldh;

    .line 125
    iget-object p2, p2, Ldh;->d:La_7E1D99AD;

    .line 127
    iget-wide v4, p2, La_7E1D99AD;->l:J

    .line 129
    add-long/2addr v4, v0

    .line 130
    iput-wide v4, p2, La_7E1D99AD;->l:J

    .line 132
    iget-object p2, p2, La_7E1D99AD;->n:Lur;

    .line 134
    invoke-virtual {p2}, Lur;->a()I

    .line 137
    move-result p2

    .line 138
    div-int/lit8 p2, p2, 0x2

    .line 140
    int-to-long p2, p2

    .line 141
    cmp-long v6, v4, p2

    .line 143
    if-ltz v6, :cond_3

    .line 145
    iget-object p2, p0, La_8421C792;->h:Ldh;

    .line 147
    iget-object p2, p2, Ldh;->d:La_7E1D99AD;

    .line 149
    iget-wide v4, p2, La_7E1D99AD;->l:J

    .line 151
    const/4 p3, 0x0

    .line 152
    invoke-virtual {p2, p3, v4, v5}, La_7E1D99AD;->w(IJ)V

    .line 155
    iget-object p2, p0, La_8421C792;->h:Ldh;

    .line 157
    iget-object p2, p2, Ldh;->d:La_7E1D99AD;

    .line 159
    iput-wide v2, p2, La_7E1D99AD;->l:J

    .line 161
    :cond_3
    monitor-exit p1

    .line 162
    return-wide v0

    .line 163
    :catchall_0
    move-exception p2

    .line 164
    monitor-exit p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 165
    throw p2

    .line 166
    :cond_4
    :try_start_6
    new-instance p1, Lgt;

    .line 168
    iget p3, p3, Ldh;->j:I

    .line 170
    invoke-direct {p1, p3}, Lgt;-><init>(I)V

    .line 173
    throw p1

    .line 174
    :cond_5
    new-instance p1, Ljava/io/IOException;

    .line 176
    const-string p3, "stream closed"

    .line 178
    invoke-direct {p1, p3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 181
    throw p1

    .line 182
    :catchall_1
    move-exception p1

    .line 183
    iget-object p3, p3, Ldh;->h:La_EE0FE900;

    .line 185
    invoke-virtual {p3}, La_EE0FE900;->p()V

    .line 188
    throw p1

    .line 189
    :catchall_2
    move-exception p1

    .line 190
    monitor-exit p2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 191
    throw p1
.end method
