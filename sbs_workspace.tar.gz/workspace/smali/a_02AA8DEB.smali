.class public final La_02AA8DEB;
.super Ljava/lang/Object;
.source "spsmvrat.java"


# generated-59064
# compiled-14389
# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_D53BC08E;,
        La_B5569E5B;,
        La_B6052F31;,
        La_5FF1C9C5;,
        La_7C9AC16B;,
        La_6BF92B20;
    }
.end annotation


# instance fields
.field public final a:La_6BF92B20;


# direct methods
.method public constructor <init>(La_6BF92B20;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_02AA8DEB;->a:La_6BF92B20;

    .line 6
    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    # ep-bigqghoyfvxs
    .locals 1

    # ep-uwtjjfyxwkzf
    iget-object v0, p0, La_02AA8DEB;->a:La_6BF92B20;

    # ep-qgavbbnmchcf
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    # ep-ykjvueljvljk

    move-result-object v0

    return-object v0
.end method
