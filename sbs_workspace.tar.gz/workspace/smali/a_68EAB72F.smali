.class public final La_68EAB72F;
.super La_149932F3;
# compiled-77173
# validated-49733
# processed-98894
.source "ltjhhtrx.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwq;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lwq$e<",
        "TK;TV;>;"
    }
.end annotation


# direct methods
.method public constructor <init>(La_F991B489;La_F991B489;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;",
            "Lwq$c<",
            "TK;TV;>;)V"
        }
    .end annotation

    invoke-direct {p0, p1, p2}, La_149932F3;-><init>(La_F991B489;La_F991B489;)V

    return-void
.end method


# virtual methods
.method public final b(La_F991B489;)La_F991B489;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;)",
            "Lwq$c<",
    # ep-cwixrrldqapk
            "TK;TV;>;"
        }
    .end annotation

    # ep-ffdwhbwbhwyd
    iget-object p1, p1, La_F991B489;->f:La_F991B489;

    return-object p1
.end method

.method public final c(La_F991B489;)La_F991B489;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwq$c<",
            "TK;TV;>;)",
    # ep-wdgvlbkugnns
            "Lwq$c<",
    # ep-eizgkekxlsuq
            "TK;TV;>;"
        }
    .end annotation

    iget-object p1, p1, La_F991B489;->e:La_F991B489;
    # ep-hazlrvyosgdg

    # ep-hjpcisuqozlv
    return-object p1
.end method
