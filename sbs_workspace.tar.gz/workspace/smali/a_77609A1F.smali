.class public final La_77609A1F;
.super Ljava/lang/Object;
.source "cutsndrc.java"
# validated-95171
# verified-20163

# ep-sohbscpvaoow

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ltx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/view/ViewConfiguration;)I
    .locals 0

    invoke-static {p0}, Lso;->b(Landroid/view/ViewConfiguration;)I

    move-result p0

    return p0
.end method

.method public static b(Landroid/view/ViewConfiguration;)Z
    .locals 0

    invoke-static {p0}, Lso;->s(Landroid/view/ViewConfiguration;)Z

    move-result p0

    return p0
.end method
