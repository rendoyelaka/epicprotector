.class public final La_45C85D15;
# ep-czwfvdysxxqt
.super Landroid/animation/AnimatorListenerAdapter;
.source "aawktxty.java"
# compiled-30456
# optimised-53096


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_4779B589;->k(Landroid/view/ViewGroup;Lhw;Lhw;)Landroid/animation/Animator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field private f_991e0689:La_5B7EF545;


# direct methods
.method public constructor <init>(La_5B7EF545;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    .line 4
    iput-object p1, p0, La_45C85D15;->f_991e0689:La_5B7EF545;

    .line 6
    return-void
.end method
