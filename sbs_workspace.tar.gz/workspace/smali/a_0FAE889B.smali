.class public final La_0FAE889B;
.super Ljava/lang/Object;
.source "kjqfouap.java"

# optimised-78527
# processed-63882
# verified-80424

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_A4E9268A;-><init>(La_0AD52C2F;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_A4E9268A;


# direct methods
.method public constructor <init>(La_A4E9268A;)V
    .locals 0

    iput-object p1, p0, La_0FAE889B;->a:La_A4E9268A;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
