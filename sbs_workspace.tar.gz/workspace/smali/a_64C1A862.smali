.class public final La_64C1A862;
.super Ljava/lang/Object;
.source "ouubdyhn.java"

# ep-jqgaoymlxglj
# verified-40815
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lux;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Lux;


# direct methods
.method public constructor <init>(Lux;)V
    .locals 0

    iput-object p1, p0, La_64C1A862;->c:Lux;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, La_64C1A862;->c:Lux;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lux;->o(I)V

    return-void
.end method
