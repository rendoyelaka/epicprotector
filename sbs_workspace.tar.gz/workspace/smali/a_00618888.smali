.class public interface abstract La_00618888;
.super Ljava/lang/Object;
.source "aazeoous.java"

# compiled-93623

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_EAF3181A;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract f()V
.end method
