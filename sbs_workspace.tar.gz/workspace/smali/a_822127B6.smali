.class public final La_822127B6;
# ep-qjdmosqscfso
.super Ljava/lang/Object;
.source "noyswepr.java"

# verified-55042
# verified-36249

# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_822127B6;->a:Ljava/lang/String;

    .line 6
    iput-object p2, p0, La_822127B6;->b:Ljava/lang/String;

    .line 8
    return-void
.end method
