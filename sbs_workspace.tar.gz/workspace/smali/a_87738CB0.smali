.class public final La_87738CB0;
.super Ljava/lang/Object;
.source "viwissxm.java"
# validated-43773
# optimised-32971
# validated-71625

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lux;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Lux;


# direct methods
.method public constructor <init>(Lux;)V
    .locals 0

    iput-object p1, p0, La_87738CB0;->c:Lux;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, La_87738CB0;->c:Lux;

    # ep-sfetjebudjem
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lux;->o(I)V

    # ep-puctncoyhfcn
    return-void
.end method
