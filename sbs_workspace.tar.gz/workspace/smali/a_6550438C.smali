.class public interface abstract La_6550438C;
.super Ljava/lang/Object;
# ep-msbdwfcgvplg
.source "ghlxbyvn.java"
# optimised-91019


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lqx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "q"
.end annotation


# virtual methods
.method public abstract a()Z
.end method
