.class public final La_1DAFBBFA;
.super Ljava/lang/Object;
# validated-87316
# processed-11307
# validated-72595
.source "iprnrvgl.java"
# ep-hjpipklowukb


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_43AC2462;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/widget/CompoundButton;)Landroid/graphics/drawable/Drawable;
    .locals 0

    invoke-static {p0}, La_F79784E5;->g(Landroid/widget/CompoundButton;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method
