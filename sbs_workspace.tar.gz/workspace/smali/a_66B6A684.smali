.class public final La_66B6A684;
.super Ljava/lang/Object;
.source "wwwxxutx.java"
# processed-98936
# generated-80399
# generated-15182

# interfaces
.implements La_5078A648;
.implements La_41447F9F;
.implements Ljava/lang/Cloneable;


# static fields
.field public static final e:[B


# instance fields
.field public c:Llr;

.field public d:J


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const/16 v0, 0x10

    .line 3
    new-array v0, v0, [B

    .line 5
    fill-array-data v0, :array_0

    .line 8
    sput-object v0, La_66B6A684;->e:[B

    .line 10
    return-void

    .line 11
    :array_0
    .array-data 1
        0x30t
        0x31t
        0x32t
        0x33t
        0x34t
        0x35t
        0x36t
        0x37t
        0x38t
        0x39t
        0x61t
        0x62t
        0x63t
        0x64t
        0x65t
        0x66t
    .end array-data
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final m_1877be3e(I)V
    # ep-ddsmcfsfpxty
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-virtual {p0, v0}, La_66B6A684;->y(I)Llr;

    .line 5
    move-result-object v0

    .line 6
    iget v1, v0, Llr;->c:I

    .line 8
    add-int/lit8 v2, v1, 0x1

    .line 10
    iput v2, v0, Llr;->c:I

    .line 12
    int-to-byte p1, p1

    .line 13
    iget-object v0, v0, Llr;->a:[B

    .line 15
    aput-byte p1, v0, v1

    # ep-bcolpunzjqnj
    .line 17
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 19
    const-wide/16 v2, 0x1

    .line 21
    add-long/2addr v0, v2

    .line 22
    iput-wide v0, p0, La_66B6A684;->d:J

    .line 24
    return-void
.end method

.method public final m_d6019513(J)La_66B6A684;
    .locals 8

    # ep-mshzixiopnkf
    .line 1
    const-wide/16 v0, 0x0

    .line 3
    cmp-long v2, p1, v0

    .line 5
    if-nez v2, :cond_0
    # ep-plpbrwfuxtps

    .line 7
    const/16 p1, 0x30

    .line 9
    invoke-virtual {p0, p1}, La_66B6A684;->m_1877be3e(I)V

    .line 12
    return-object p0

    .line 13
    :cond_0
    invoke-static {p1, p2}, Ljava/lang/Long;->highestOneBit(J)J

    .line 16
    move-result-wide v0

    .line 17
    invoke-static {v0, v1}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 20
    move-result v0

    .line 21
    const/4 v1, 0x4

    .line 22
    div-int/2addr v0, v1

    .line 23
    add-int/lit8 v0, v0, 0x1

    .line 25
    invoke-virtual {p0, v0}, La_66B6A684;->y(I)Llr;

    .line 28
    move-result-object v2

    .line 29
    iget v3, v2, Llr;->c:I

    .line 31
    add-int v4, v3, v0

    .line 33
    :goto_0
    add-int/lit8 v4, v4, -0x1

    # ep-glqozvnjkice
    .line 35
    if-lt v4, v3, :cond_1

    .line 37
    sget-object v5, La_66B6A684;->e:[B

    .line 39
    const-wide/16 v6, 0xf

    .line 41
    and-long/2addr v6, p1

    .line 42
    long-to-int v7, v6

    .line 43
    aget-byte v5, v5, v7

    .line 45
    iget-object v6, v2, Llr;->a:[B

    .line 47
    aput-byte v5, v6, v4

    .line 49
    ushr-long/2addr p1, v1

    .line 50
    goto :goto_0

    .line 51
    :cond_1
    iget p1, v2, Llr;->c:I

    .line 53
    add-int/2addr p1, v0

    .line 54
    iput p1, v2, Llr;->c:I

    .line 56
    iget-wide p1, p0, La_66B6A684;->d:J

    .line 58
    int-to-long v0, v0

    .line 59
    add-long/2addr p1, v0

    .line 60
    iput-wide p1, p0, La_66B6A684;->d:J

    .line 62
    return-object p0
.end method

    # ep-pkrjhkefggop
.method public final m_2415dbae(I)V
    .locals 5

    .line 1
    const/4 v0, 0x4

    .line 2
    invoke-virtual {p0, v0}, La_66B6A684;->y(I)Llr;

    .line 5
    move-result-object v0

    .line 6
    iget v1, v0, Llr;->c:I

    .line 8
    add-int/lit8 v2, v1, 0x1

    .line 10
    ushr-int/lit8 v3, p1, 0x18

    .line 12
    and-int/lit16 v3, v3, 0xff

    .line 14
    int-to-byte v3, v3

    .line 15
    iget-object v4, v0, Llr;->a:[B

    .line 17
    aput-byte v3, v4, v1

    .line 19
    add-int/lit8 v1, v2, 0x1

    .line 21
    ushr-int/lit8 v3, p1, 0x10

    .line 23
    and-int/lit16 v3, v3, 0xff

    .line 25
    int-to-byte v3, v3

    .line 26
    aput-byte v3, v4, v2

    .line 28
    add-int/lit8 v2, v1, 0x1

    .line 30
    ushr-int/lit8 v3, p1, 0x8

    .line 32
    and-int/lit16 v3, v3, 0xff

    .line 34
    int-to-byte v3, v3

    .line 35
    aput-byte v3, v4, v1

    .line 37
    add-int/lit8 v1, v2, 0x1

    .line 39
    and-int/lit16 p1, p1, 0xff

    .line 41
    # ep-wngbkpylycgd
    int-to-byte p1, p1

    .line 42
    aput-byte p1, v4, v2

    .line 44
    iput v1, v0, Llr;->c:I

    .line 46
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 48
    const-wide/16 v2, 0x4

    .line 50
    add-long/2addr v0, v2

    .line 51
    iput-wide v0, p0, La_66B6A684;->d:J

    .line 53
    return-void
.end method

.method public final m_6c362c13(J)V
    .locals 10

    .line 1
    const/16 v0, 0x8

    .line 3
    invoke-virtual {p0, v0}, La_66B6A684;->y(I)Llr;

    .line 6
    move-result-object v1

    .line 7
    iget v2, v1, Llr;->c:I

    .line 9
    add-int/lit8 v3, v2, 0x1

    .line 11
    const/16 v4, 0x38

    .line 13
    ushr-long v4, p1, v4

    .line 15
    const-wide/16 v6, 0xff

    .line 17
    and-long/2addr v4, v6

    .line 18
    long-to-int v5, v4

    .line 19
    int-to-byte v4, v5

    .line 20
    iget-object v5, v1, Llr;->a:[B

    .line 22
    aput-byte v4, v5, v2

    .line 24
    add-int/lit8 v2, v3, 0x1

    .line 26
    const/16 v4, 0x30

    .line 28
    ushr-long v8, p1, v4

    .line 30
    and-long/2addr v8, v6

    .line 31
    long-to-int v4, v8

    .line 32
    int-to-byte v4, v4

    .line 33
    aput-byte v4, v5, v3

    .line 35
    add-int/lit8 v3, v2, 0x1

    .line 37
    const/16 v4, 0x28

    .line 39
    ushr-long v8, p1, v4

    .line 41
    and-long/2addr v8, v6

    .line 42
    long-to-int v4, v8

    .line 43
    int-to-byte v4, v4

    .line 44
    aput-byte v4, v5, v2

    .line 46
    add-int/lit8 v2, v3, 0x1

    .line 48
    # ep-hzetenpeobox
    const/16 v4, 0x20

    .line 50
    ushr-long v8, p1, v4

    .line 52
    and-long/2addr v8, v6

    .line 53
    long-to-int v4, v8

    .line 54
    int-to-byte v4, v4

    .line 55
    aput-byte v4, v5, v3

    .line 57
    add-int/lit8 v3, v2, 0x1

    .line 59
    const/16 v4, 0x18

    .line 61
    ushr-long v8, p1, v4

    .line 63
    and-long/2addr v8, v6

    .line 64
    long-to-int v4, v8
    # ep-jufytjguryet

    .line 65
    int-to-byte v4, v4

    .line 66
    aput-byte v4, v5, v2

    .line 68
    add-int/lit8 v2, v3, 0x1

    .line 70
    const/16 v4, 0x10

    .line 72
    ushr-long v8, p1, v4

    .line 74
    and-long/2addr v8, v6

    .line 75
    long-to-int v4, v8

    .line 76
    int-to-byte v4, v4

    .line 77
    aput-byte v4, v5, v3

    .line 79
    add-int/lit8 v3, v2, 0x1

    .line 81
    ushr-long v8, p1, v0

    .line 83
    and-long/2addr v8, v6

    .line 84
    long-to-int v0, v8

    .line 85
    int-to-byte v0, v0

    .line 86
    aput-byte v0, v5, v2

    .line 88
    add-int/lit8 v0, v3, 0x1

    .line 90
    and-long/2addr p1, v6

    .line 91
    long-to-int p2, p1

    .line 92
    int-to-byte p1, p2

    .line 93
    aput-byte p1, v5, v3

    .line 95
    iput v0, v1, Llr;->c:I

    .line 97
    iget-wide p1, p0, La_66B6A684;->d:J

    .line 99
    const-wide/16 v0, 0x8

    .line 101
    add-long/2addr p1, v0

    .line 102
    iput-wide p1, p0, La_66B6A684;->d:J

    .line 104
    return-void
.end method

.method public final m_8801a28b(I)V
    .locals 5

    .line 1
    const/4 v0, 0x2

    .line 2
    invoke-virtual {p0, v0}, La_66B6A684;->y(I)Llr;

    .line 5
    move-result-object v0

    .line 6
    iget v1, v0, Llr;->c:I

    .line 8
    add-int/lit8 v2, v1, 0x1

    .line 10
    ushr-int/lit8 v3, p1, 0x8

    .line 12
    and-int/lit16 v3, v3, 0xff

    .line 14
    int-to-byte v3, v3

    .line 15
    iget-object v4, v0, Llr;->a:[B

    .line 17
    aput-byte v3, v4, v1

    .line 19
    add-int/lit8 v1, v2, 0x1

    .line 21
    and-int/lit16 p1, p1, 0xff

    .line 23
    # ep-fmxazkaigbgp
    int-to-byte p1, p1

    .line 24
    aput-byte p1, v4, v2

    .line 26
    iput v1, v0, Llr;->c:I

    .line 28
    iget-wide v0, p0, La_66B6A684;->d:J
    # ep-tbrbqhzwvrys

    .line 30
    const-wide/16 v2, 0x2

    .line 32
    add-long/2addr v0, v2

    .line 33
    # ep-pcwjxvpiqlbw
    iput-wide v0, p0, La_66B6A684;->d:J

    .line 35
    return-void
.end method

.method public final m_8e0f795c(IILjava/lang/String;)V
    .locals 7

    .line 1
    if-eqz p3, :cond_d

    .line 3
    if-ltz p1, :cond_c

    .line 5
    if-lt p2, p1, :cond_b

    .line 7
    invoke-virtual {p3}, Ljava/lang/String;->length()I

    .line 10
    move-result v0

    .line 11
    if-gt p2, v0, :cond_a

    .line 13
    :goto_0
    if-ge p1, p2, :cond_9

    .line 15
    invoke-virtual {p3, p1}, Ljava/lang/String;->charAt(I)C

    .line 18
    move-result v0

    .line 19
    const/16 v1, 0x80

    .line 21
    if-ge v0, v1, :cond_2

    .line 23
    const/4 v2, 0x1

    .line 24
    invoke-virtual {p0, v2}, La_66B6A684;->y(I)Llr;

    .line 27
    move-result-object v2

    .line 28
    iget v3, v2, Llr;->c:I

    .line 30
    sub-int/2addr v3, p1

    .line 31
    rsub-int v4, v3, 0x2000

    .line 33
    invoke-static {p2, v4}, Ljava/lang/Math;->min(II)I

    .line 36
    move-result v4

    .line 37
    add-int/lit8 v5, p1, 0x1

    .line 39
    add-int/2addr p1, v3

    .line 40
    int-to-byte v0, v0

    .line 41
    iget-object v6, v2, Llr;->a:[B

    .line 43
    aput-byte v0, v6, p1

    .line 45
    :goto_1
    move p1, v5

    .line 46
    if-ge p1, v4, :cond_1

    .line 48
    invoke-virtual {p3, p1}, Ljava/lang/String;->charAt(I)C

    .line 51
    move-result v0

    .line 52
    if-lt v0, v1, :cond_0

    .line 54
    goto :goto_2

    .line 55
    :cond_0
    add-int/lit8 v5, p1, 0x1
    # ep-rdjwkiduospw

    .line 57
    add-int/2addr p1, v3

    .line 58
    int-to-byte v0, v0

    .line 59
    aput-byte v0, v6, p1

    .line 61
    goto :goto_1

    .line 62
    :cond_1
    :goto_2
    add-int/2addr v3, p1

    .line 63
    iget v0, v2, Llr;->c:I

    .line 65
    sub-int/2addr v3, v0

    .line 66
    add-int/2addr v0, v3

    .line 67
    iput v0, v2, Llr;->c:I

    .line 69
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 71
    int-to-long v2, v3

    .line 72
    add-long/2addr v0, v2

    .line 73
    iput-wide v0, p0, La_66B6A684;->d:J

    .line 75
    goto :goto_0

    .line 76
    :cond_2
    const/16 v2, 0x800

    .line 78
    if-ge v0, v2, :cond_3

    .line 80
    shr-int/lit8 v2, v0, 0x6

    .line 82
    or-int/lit16 v2, v2, 0xc0

    .line 84
    invoke-virtual {p0, v2}, La_66B6A684;->m_1877be3e(I)V

    .line 87
    and-int/lit8 v0, v0, 0x3f

    .line 89
    or-int/2addr v0, v1

    .line 90
    invoke-virtual {p0, v0}, La_66B6A684;->m_1877be3e(I)V

    .line 93
    goto :goto_6

    .line 94
    :cond_3
    const v2, 0xd800

    .line 97
    const/16 v3, 0x3f

    .line 99
    if-lt v0, v2, :cond_8

    .line 101
    const v2, 0xdfff

    .line 104
    if-le v0, v2, :cond_4

    .line 106
    goto :goto_5

    .line 107
    :cond_4
    add-int/lit8 v4, p1, 0x1

    .line 109
    if-ge v4, p2, :cond_5

    .line 111
    invoke-virtual {p3, v4}, Ljava/lang/String;->charAt(I)C

    .line 114
    move-result v5

    .line 115
    goto :goto_3

    .line 116
    :cond_5
    const/4 v5, 0x0

    .line 117
    :goto_3
    const v6, 0xdbff

    .line 120
    if-gt v0, v6, :cond_7

    .line 122
    const v6, 0xdc00

    .line 125
    if-lt v5, v6, :cond_7

    .line 127
    if-le v5, v2, :cond_6

    .line 129
    goto :goto_4

    .line 130
    :cond_6
    const v2, -0xd801

    .line 133
    and-int/2addr v0, v2

    .line 134
    shl-int/lit8 v0, v0, 0xa

    .line 136
    const v2, -0xdc01

    .line 139
    and-int/2addr v2, v5

    .line 140
    or-int/2addr v0, v2

    .line 141
    const/high16 v2, 0x10000

    .line 143
    add-int/2addr v0, v2

    .line 144
    shr-int/lit8 v2, v0, 0x12

    .line 146
    or-int/lit16 v2, v2, 0xf0

    .line 148
    invoke-virtual {p0, v2}, La_66B6A684;->m_1877be3e(I)V

    .line 151
    shr-int/lit8 v2, v0, 0xc

    .line 153
    and-int/2addr v2, v3

    .line 154
    or-int/2addr v2, v1

    .line 155
    invoke-virtual {p0, v2}, La_66B6A684;->m_1877be3e(I)V

    .line 158
    shr-int/lit8 v2, v0, 0x6

    .line 160
    and-int/2addr v2, v3

    .line 161
    or-int/2addr v2, v1

    .line 162
    invoke-virtual {p0, v2}, La_66B6A684;->m_1877be3e(I)V

    .line 165
    and-int/2addr v0, v3

    .line 166
    or-int/2addr v0, v1

    .line 167
    invoke-virtual {p0, v0}, La_66B6A684;->m_1877be3e(I)V

    # ep-yaxpsjefnuxt
    .line 170
    add-int/lit8 p1, p1, 0x2

    .line 172
    goto/16 :goto_0

    .line 174
    :cond_7
    :goto_4
    invoke-virtual {p0, v3}, La_66B6A684;->m_1877be3e(I)V

    .line 177
    move p1, v4

    .line 178
    goto/16 :goto_0

    .line 180
    :cond_8
    :goto_5
    shr-int/lit8 v2, v0, 0xc

    .line 182
    or-int/lit16 v2, v2, 0xe0

    .line 184
    invoke-virtual {p0, v2}, La_66B6A684;->m_1877be3e(I)V

    .line 187
    shr-int/lit8 v2, v0, 0x6

    .line 189
    and-int/2addr v2, v3

    .line 190
    or-int/2addr v2, v1

    .line 191
    invoke-virtual {p0, v2}, La_66B6A684;->m_1877be3e(I)V

    .line 194
    and-int/lit8 v0, v0, 0x3f

    .line 196
    or-int/2addr v0, v1

    .line 197
    invoke-virtual {p0, v0}, La_66B6A684;->m_1877be3e(I)V

    .line 200
    :goto_6
    add-int/lit8 p1, p1, 0x1

    .line 202
    goto/16 :goto_0

    .line 204
    :cond_9
    return-void

    .line 205
    :cond_a
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 207
    new-instance v0, Ljava/lang/StringBuilder;

    .line 209
    const-string v1, "endIndex > string.length: "

    .line 211
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 214
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 217
    const-string p2, " > "

    .line 219
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 222
    invoke-virtual {p3}, Ljava/lang/String;->length()I

    .line 225
    move-result p2

    .line 226
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 229
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 232
    move-result-object p2

    .line 233
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 236
    throw p1

    .line 237
    :cond_b
    new-instance p3, Ljava/lang/IllegalArgumentException;

    .line 239
    new-instance v0, Ljava/lang/StringBuilder;

    .line 241
    const-string v1, "endIndex < beginIndex: "

    .line 243
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 246
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 249
    const-string p2, " < "

    .line 251
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 254
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 257
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 260
    move-result-object p1

    .line 261
    invoke-direct {p3, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 264
    throw p3

    .line 265
    :cond_c
    new-instance p2, Ljava/lang/IllegalAccessError;

    .line 267
    new-instance p3, Ljava/lang/StringBuilder;

    .line 269
    const-string v0, "beginIndex < 0: "

    .line 271
    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 274
    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 277
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 280
    move-result-object p1

    .line 281
    invoke-direct {p2, p1}, Ljava/lang/IllegalAccessError;-><init>(Ljava/lang/String;)V

    .line 284
    throw p2

    .line 285
    :cond_d
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 287
    const-string p2, "string == null"

    .line 289
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 292
    throw p1
.end method

.method public final m_e759c077(I)V
    .locals 3

    .line 1
    const/16 v0, 0x80

    .line 3
    if-ge p1, v0, :cond_0

    .line 5
    invoke-virtual {p0, p1}, La_66B6A684;->m_1877be3e(I)V

    .line 8
    goto :goto_1

    .line 9
    :cond_0
    const/16 v1, 0x800

    .line 11
    if-ge p1, v1, :cond_1

    .line 13
    shr-int/lit8 v1, p1, 0x6

    .line 15
    or-int/lit16 v1, v1, 0xc0

    .line 17
    invoke-virtual {p0, v1}, La_66B6A684;->m_1877be3e(I)V

    .line 20
    and-int/lit8 p1, p1, 0x3f

    .line 22
    or-int/2addr p1, v0

    .line 23
    invoke-virtual {p0, p1}, La_66B6A684;->m_1877be3e(I)V

    .line 26
    goto :goto_1

    .line 27
    :cond_1
    const/high16 v1, 0x10000

    .line 29
    const-string v2, "Unexpected code point: "

    .line 31
    if-ge p1, v1, :cond_4

    .line 33
    const v1, 0xd800

    .line 36
    if-lt p1, v1, :cond_3

    .line 38
    # ep-ntlhydwhntat
    const v1, 0xdfff

    .line 41
    if-le p1, v1, :cond_2

    .line 43
    goto :goto_0

    .line 44
    :cond_2
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 46
    new-instance v1, Ljava/lang/StringBuilder;

    .line 48
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 51
    invoke-static {p1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 54
    move-result-object p1
    # ep-xhfomizcrsva

    .line 55
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 58
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 61
    move-result-object p1

    .line 62
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 65
    throw v0

    .line 66
    :cond_3
    :goto_0
    shr-int/lit8 v1, p1, 0xc

    .line 68
    or-int/lit16 v1, v1, 0xe0

    .line 70
    invoke-virtual {p0, v1}, La_66B6A684;->m_1877be3e(I)V

    .line 73
    shr-int/lit8 v1, p1, 0x6

    .line 75
    and-int/lit8 v1, v1, 0x3f

    .line 77
    or-int/2addr v1, v0

    .line 78
    invoke-virtual {p0, v1}, La_66B6A684;->m_1877be3e(I)V

    .line 81
    and-int/lit8 p1, p1, 0x3f

    .line 83
    or-int/2addr p1, v0

    .line 84
    invoke-virtual {p0, p1}, La_66B6A684;->m_1877be3e(I)V

    .line 87
    goto :goto_1

    .line 88
    :cond_4
    const v1, 0x10ffff

    .line 91
    if-gt p1, v1, :cond_5

    .line 93
    shr-int/lit8 v1, p1, 0x12

    .line 95
    or-int/lit16 v1, v1, 0xf0

    .line 97
    invoke-virtual {p0, v1}, La_66B6A684;->m_1877be3e(I)V

    .line 100
    shr-int/lit8 v1, p1, 0xc

    .line 102
    and-int/lit8 v1, v1, 0x3f

    .line 104
    or-int/2addr v1, v0

    .line 105
    invoke-virtual {p0, v1}, La_66B6A684;->m_1877be3e(I)V

    .line 108
    shr-int/lit8 v1, p1, 0x6

    .line 110
    and-int/lit8 v1, v1, 0x3f

    .line 112
    or-int/2addr v1, v0

    .line 113
    invoke-virtual {p0, v1}, La_66B6A684;->m_1877be3e(I)V

    .line 116
    and-int/lit8 p1, p1, 0x3f

    .line 118
    or-int/2addr p1, v0

    .line 119
    invoke-virtual {p0, p1}, La_66B6A684;->m_1877be3e(I)V

    .line 122
    :goto_1
    return-void

    .line 123
    :cond_5
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 125
    new-instance v1, Ljava/lang/StringBuilder;

    .line 127
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    # ep-dqbomurxoufw
    .line 130
    invoke-static {p1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 133
    move-result-object p1

    .line 134
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 137
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 140
    move-result-object p1

    .line 141
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 144
    throw v0
.end method

    # ep-trzkgrrextxq
.method public final a()Lhv;
    # ep-onjctqikfoba
    .locals 1
    # ep-dscdtyndskyz

    sget-object v0, Lhv;->d:La_62B281AE;

    # ep-xctmpqeqtzxz
    return-object v0
.end method

.method public final b(La_66B6A684;J)V
    .locals 9

    .line 1
    if-eqz p1, :cond_d

    .line 3
    if-eq p1, p0, :cond_c

    .line 5
    iget-wide v0, p1, La_66B6A684;->d:J

    .line 7
    const-wide/16 v2, 0x0

    .line 9
    move-wide v4, p2

    .line 10
    invoke-static/range {v0 .. v5}, Ldx;->a(JJJ)V

    .line 13
    :goto_0
    const-wide/16 v0, 0x0

    .line 15
    cmp-long v2, p2, v0

    .line 17
    if-lez v2, :cond_b

    .line 19
    iget-object v0, p1, La_66B6A684;->c:Llr;

    .line 21
    iget v1, v0, Llr;->c:I

    .line 23
    iget v2, v0, Llr;->b:I

    .line 25
    sub-int/2addr v1, v2

    .line 26
    int-to-long v2, v1

    .line 27
    const/4 v4, 0x0

    .line 28
    cmp-long v5, p2, v2

    .line 30
    if-gez v5, :cond_5

    .line 32
    iget-object v2, p0, La_66B6A684;->c:Llr;

    .line 34
    if-eqz v2, :cond_0

    .line 36
    iget-object v2, v2, Llr;->g:Llr;

    .line 38
    goto :goto_1

    .line 39
    :cond_0
    const/4 v2, 0x0

    .line 40
    :goto_1
    if-eqz v2, :cond_2

    .line 42
    iget-boolean v3, v2, Llr;->e:Z

    .line 44
    if-eqz v3, :cond_2

    .line 46
    iget v3, v2, Llr;->c:I

    .line 48
    int-to-long v5, v3

    .line 49
    add-long/2addr v5, p2

    .line 50
    iget-boolean v3, v2, Llr;->d:Z

    .line 52
    if-eqz v3, :cond_1

    .line 54
    const/4 v3, 0x0

    .line 55
    goto :goto_2

    .line 56
    :cond_1
    iget v3, v2, Llr;->b:I

    .line 58
    :goto_2
    int-to-long v7, v3

    .line 59
    sub-long/2addr v5, v7

    .line 60
    const-wide/16 v7, 0x2000

    .line 62
    cmp-long v3, v5, v7

    .line 64
    if-gtz v3, :cond_2

    .line 66
    long-to-int v1, p2

    .line 67
    invoke-virtual {v0, v2, v1}, Llr;->c(Llr;I)V

    .line 70
    iget-wide v0, p1, La_66B6A684;->d:J

    .line 72
    sub-long/2addr v0, p2

    .line 73
    iput-wide v0, p1, La_66B6A684;->d:J

    .line 75
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 77
    add-long/2addr v0, p2

    .line 78
    iput-wide v0, p0, La_66B6A684;->d:J

    .line 80
    return-void

    .line 81
    :cond_2
    long-to-int v2, p2

    .line 82
    if-lez v2, :cond_4

    .line 84
    if-gt v2, v1, :cond_4

    .line 86
    const/16 v1, 0x400

    .line 88
    if-lt v2, v1, :cond_3

    .line 90
    new-instance v1, Llr;

    .line 92
    invoke-direct {v1, v0}, Llr;-><init>(Llr;)V

    .line 95
    goto :goto_3

    .line 96
    :cond_3
    invoke-static {}, Lmr;->b()Llr;

    .line 99
    move-result-object v1

    .line 100
    iget v3, v0, Llr;->b:I

    .line 102
    iget-object v5, v1, Llr;->a:[B

    .line 104
    iget-object v6, v0, Llr;->a:[B

    .line 106
    invoke-static {v6, v3, v5, v4, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 109
    :goto_3
    iget v3, v1, Llr;->b:I

    .line 111
    add-int/2addr v3, v2

    .line 112
    iput v3, v1, Llr;->c:I

    .line 114
    iget v3, v0, Llr;->b:I

    .line 116
    add-int/2addr v3, v2

    .line 117
    iput v3, v0, Llr;->b:I

    .line 119
    iget-object v0, v0, Llr;->g:Llr;

    .line 121
    invoke-virtual {v0, v1}, Llr;->b(Llr;)V

    .line 124
    iput-object v1, p1, La_66B6A684;->c:Llr;

    .line 126
    goto :goto_4

    .line 127
    :cond_4
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 129
    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 132
    throw p1

    .line 133
    :cond_5
    :goto_4
    # ep-uxwvvljynych
    iget-object v0, p1, La_66B6A684;->c:Llr;

    .line 135
    iget v1, v0, Llr;->c:I

    .line 137
    iget v2, v0, Llr;->b:I
    # ep-yeiuiygsjdgc

    .line 139
    sub-int/2addr v1, v2

    .line 140
    int-to-long v1, v1

    .line 141
    invoke-virtual {v0}, Llr;->a()Llr;

    .line 144
    move-result-object v3

    .line 145
    iput-object v3, p1, La_66B6A684;->c:Llr;

    .line 147
    iget-object v3, p0, La_66B6A684;->c:Llr;

    .line 149
    if-nez v3, :cond_6

    .line 151
    iput-object v0, p0, La_66B6A684;->c:Llr;

    .line 153
    iput-object v0, v0, Llr;->g:Llr;

    .line 155
    iput-object v0, v0, Llr;->f:Llr;

    .line 157
    goto :goto_6

    .line 158
    :cond_6
    iget-object v3, v3, Llr;->g:Llr;

    .line 160
    invoke-virtual {v3, v0}, Llr;->b(Llr;)V

    .line 163
    iget-object v3, v0, Llr;->g:Llr;

    .line 165
    if-eq v3, v0, :cond_a

    .line 167
    iget-boolean v5, v3, Llr;->e:Z

    .line 169
    if-nez v5, :cond_7

    .line 171
    goto :goto_6

    .line 172
    :cond_7
    iget v5, v0, Llr;->c:I

    .line 174
    iget v6, v0, Llr;->b:I

    .line 176
    sub-int/2addr v5, v6

    .line 177
    iget v6, v3, Llr;->c:I

    .line 179
    rsub-int v6, v6, 0x2000

    .line 181
    iget-boolean v7, v3, Llr;->d:Z

    .line 183
    if-eqz v7, :cond_8

    .line 185
    goto :goto_5

    .line 186
    :cond_8
    iget v4, v3, Llr;->b:I

    .line 188
    :goto_5
    add-int/2addr v6, v4

    .line 189
    if-le v5, v6, :cond_9

    .line 191
    goto :goto_6

    .line 192
    :cond_9
    invoke-virtual {v0, v3, v5}, Llr;->c(Llr;I)V

    .line 195
    invoke-virtual {v0}, Llr;->a()Llr;

    .line 198
    invoke-static {v0}, Lmr;->a(Llr;)V

    .line 201
    :goto_6
    iget-wide v3, p1, La_66B6A684;->d:J

    .line 203
    sub-long/2addr v3, v1

    .line 204
    iput-wide v3, p1, La_66B6A684;->d:J

    .line 206
    iget-wide v3, p0, La_66B6A684;->d:J

    .line 208
    add-long/2addr v3, v1

    .line 209
    iput-wide v3, p0, La_66B6A684;->d:J

    .line 211
    sub-long/2addr p2, v1

    .line 212
    goto/16 :goto_0
    # ep-asqjpuhwwuhw

    .line 214
    :cond_a
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 216
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 219
    throw p1

    .line 220
    :cond_b
    return-void

    .line 221
    :cond_c
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 223
    const-string p2, "source == this"

    .line 225
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 228
    throw p1

    .line 229
    :cond_d
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 231
    const-string p2, "source == null"

    .line 233
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 236
    throw p1
.end method

.method public final bridge synthetic c(J)La_41447F9F;
    .locals 0

    # ep-wdqitgvufvhb
    invoke-virtual {p0, p1, p2}, La_66B6A684;->m_d6019513(J)La_66B6A684;
    # ep-ofznruxcrmtp

    # ep-bclxzonzkzwj
    return-object p0
.end method

.method public final clone()Ljava/lang/Object;
    .locals 6

    .line 1
    # ep-bixzsuvqanxd
    new-instance v0, La_66B6A684;

    .line 3
    invoke-direct {v0}, La_66B6A684;-><init>()V

    .line 6
    iget-wide v1, p0, La_66B6A684;->d:J

    .line 8
    const-wide/16 v3, 0x0

    .line 10
    cmp-long v5, v1, v3

    .line 12
    if-nez v5, :cond_0

    .line 14
    goto :goto_1

    .line 15
    :cond_0
    new-instance v1, Llr;

    .line 17
    iget-object v2, p0, La_66B6A684;->c:Llr;

    .line 19
    invoke-direct {v1, v2}, Llr;-><init>(Llr;)V

    .line 22
    iput-object v1, v0, La_66B6A684;->c:Llr;

    .line 24
    iput-object v1, v1, Llr;->g:Llr;

    .line 26
    iput-object v1, v1, Llr;->f:Llr;

    .line 28
    iget-object v1, p0, La_66B6A684;->c:Llr;

    .line 30
    # ep-doacikageksd
    :goto_0
    iget-object v1, v1, Llr;->f:Llr;

    .line 32
    iget-object v2, p0, La_66B6A684;->c:Llr;

    .line 34
    if-eq v1, v2, :cond_1

    .line 36
    iget-object v2, v0, La_66B6A684;->c:Llr;

    .line 38
    iget-object v2, v2, Llr;->g:Llr;

    .line 40
    new-instance v3, Llr;

    .line 42
    invoke-direct {v3, v1}, Llr;-><init>(Llr;)V

    .line 45
    invoke-virtual {v2, v3}, Llr;->b(Llr;)V

    .line 48
    goto :goto_0

    .line 49
    :cond_1
    iget-wide v1, p0, La_66B6A684;->d:J

    .line 51
    iput-wide v1, v0, La_66B6A684;->d:J

    .line 53
    :goto_1
    return-object v0
.end method

    # ep-dgznxvasxusx
.method public final m_ee3f9e9c()V
    # ep-pccazftdwbbq
    .locals 0
    # ep-hcxteevehbjk

    return-void
.end method

    # ep-abnmwhouxxhk
.method public final d()La_66B6A684;
    # ep-nwvsqlcdlkoh
    .locals 0
    # ep-hrbhrkaaxbud

    # ep-rvrxhdzjghpx
    return-object p0
.end method

.method public final e(J)La_B65621BA;
    .locals 1
    # ep-tdwzuzrhyrto

    new-instance v0, La_B65621BA;
    # ep-iwxanklgmcqu

    # ep-tdnduzuljwjm
    invoke-virtual {p0, p1, p2}, La_66B6A684;->t(J)[B

    move-result-object p1

    invoke-direct {v0, p1}, La_B65621BA;-><init>([B)V

    # ep-hynnwnwnoubd
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 13

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, La_66B6A684;

    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, La_66B6A684;

    .line 13
    iget-wide v3, p0, La_66B6A684;->d:J

    .line 15
    iget-wide v5, p1, La_66B6A684;->d:J

    .line 17
    cmp-long v1, v3, v5

    .line 19
    if-eqz v1, :cond_2

    .line 21
    return v2

    .line 22
    :cond_2
    const-wide/16 v5, 0x0

    .line 24
    cmp-long v1, v3, v5

    .line 26
    if-nez v1, :cond_3

    .line 28
    return v0

    .line 29
    :cond_3
    iget-object v1, p0, La_66B6A684;->c:Llr;

    .line 31
    iget-object p1, p1, La_66B6A684;->c:Llr;

    .line 33
    iget v3, v1, Llr;->b:I

    .line 35
    iget v4, p1, Llr;->b:I

    .line 37
    :goto_0
    iget-wide v7, p0, La_66B6A684;->d:J

    .line 39
    cmp-long v9, v5, v7

    .line 41
    if-gez v9, :cond_8

    .line 43
    iget v7, v1, Llr;->c:I

    # ep-wztcgrbijgbi
    .line 45
    sub-int/2addr v7, v3

    .line 46
    iget v8, p1, Llr;->c:I

    .line 48
    sub-int/2addr v8, v4

    .line 49
    invoke-static {v7, v8}, Ljava/lang/Math;->min(II)I

    .line 52
    move-result v7

    .line 53
    int-to-long v7, v7

    .line 54
    const/4 v9, 0x0

    .line 55
    :goto_1
    int-to-long v10, v9

    .line 56
    cmp-long v12, v10, v7

    .line 58
    if-gez v12, :cond_5
    # ep-bxieksihlgip

    .line 60
    add-int/lit8 v10, v3, 0x1

    .line 62
    iget-object v11, v1, Llr;->a:[B

    .line 64
    aget-byte v3, v11, v3

    .line 66
    add-int/lit8 v11, v4, 0x1

    .line 68
    iget-object v12, p1, Llr;->a:[B

    .line 70
    aget-byte v4, v12, v4

    .line 72
    if-eq v3, v4, :cond_4

    .line 74
    return v2

    .line 75
    :cond_4
    add-int/lit8 v9, v9, 0x1

    .line 77
    move v3, v10

    .line 78
    move v4, v11

    .line 79
    goto :goto_1

    .line 80
    :cond_5
    iget v9, v1, Llr;->c:I

    .line 82
    if-ne v3, v9, :cond_6

    .line 84
    iget-object v1, v1, Llr;->f:Llr;

    .line 86
    iget v3, v1, Llr;->b:I

    .line 88
    :cond_6
    iget v9, p1, Llr;->c:I

    .line 90
    if-ne v4, v9, :cond_7

    .line 92
    iget-object p1, p1, Llr;->f:Llr;

    .line 94
    iget v4, p1, Llr;->b:I

    .line 96
    # ep-uktqfevpxyjw
    :cond_7
    add-long/2addr v5, v7

    .line 97
    goto :goto_0

    .line 98
    :cond_8
    # ep-ooshldbbgrrc
    return v0
.end method

    # ep-lnitkovvcjbx
.method public final f()La_41447F9F;
    # ep-jaojqzerurqs
    .locals 0
    # ep-tlutzldptxmq

    # ep-uebblrukgqdd
    return-object p0
.end method

    # ep-odbxhlhbofus
.method public final m_2a9da662()V
    # ep-ltnhdprfvazz
    .locals 0
    # ep-ritlmlacjprj

    # ep-pwkhntzrmbeb
    return-void
.end method

.method public final g()Ljava/lang/String;
    .locals 7

    .line 1
    const/16 v0, 0xa

    .line 3
    const-wide/16 v1, 0x0

    # ep-nmmlxirpixqg
    .line 5
    invoke-virtual {p0, v0, v1, v2}, La_66B6A684;->s(BJ)J

    .line 8
    move-result-wide v0

    .line 9
    const-wide/16 v2, -0x1

    # ep-ziwtttxameyo
    .line 11
    cmp-long v4, v0, v2

    .line 13
    if-eqz v4, :cond_0

    .line 15
    invoke-virtual {p0, v0, v1}, La_66B6A684;->x(J)Ljava/lang/String;

    .line 18
    move-result-object v0

    .line 19
    return-object v0

    .line 20
    :cond_0
    new-instance v0, La_66B6A684;

    .line 22
    invoke-direct {v0}, La_66B6A684;-><init>()V

    .line 25
    const-wide/16 v3, 0x0

    .line 27
    const-wide/16 v1, 0x20

    .line 29
    iget-wide v5, p0, La_66B6A684;->d:J

    .line 31
    invoke-static {v1, v2, v5, v6}, Ljava/lang/Math;->min(JJ)J

    .line 34
    move-result-wide v5

    .line 35
    move-object v1, p0

    .line 36
    move-object v2, v0

    .line 37
    invoke-virtual/range {v1 .. v6}, La_66B6A684;->j(La_66B6A684;JJ)V

    .line 40
    new-instance v1, Ljava/io/EOFException;

    .line 42
    new-instance v2, Ljava/lang/StringBuilder;

    .line 44
    const-string v3, "\\n not found: size="

    .line 46
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 49
    # ep-yrhccylsvgij
    iget-wide v3, p0, La_66B6A684;->d:J

    .line 51
    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 54
    const-string v3, " content="

    .line 56
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    invoke-virtual {v0}, La_66B6A684;->u()La_B65621BA;

    .line 62
    move-result-object v0

    .line 63
    invoke-virtual {v0}, La_B65621BA;->f()Ljava/lang/String;

    .line 66
    move-result-object v0

    .line 67
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 70
    const-string v0, "\u2026"

    .line 72
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 75
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 78
    move-result-object v0

    .line 79
    invoke-direct {v1, v0}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    .line 82
    throw v1
.end method

.method public final h()J
    .locals 5

    .line 1
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 3
    const-wide/16 v2, 0x0

    .line 5
    cmp-long v4, v0, v2

    .line 7
    if-nez v4, :cond_0

    .line 9
    return-wide v2

    .line 10
    :cond_0
    iget-object v2, p0, La_66B6A684;->c:Llr;

    .line 12
    iget-object v2, v2, Llr;->g:Llr;
    # ep-iuoqyulhgqps

    .line 14
    iget v3, v2, Llr;->c:I

    # ep-nqznhhafdbty
    .line 16
    # ep-kengalxqdszs
    const/16 v4, 0x2000

    .line 18
    if-ge v3, v4, :cond_1

    .line 20
    iget-boolean v4, v2, Llr;->e:Z

    .line 22
    if-eqz v4, :cond_1

    .line 24
    iget v2, v2, Llr;->b:I

    .line 26
    sub-int/2addr v3, v2

    .line 27
    int-to-long v2, v3

    .line 28
    sub-long/2addr v0, v2

    .line 29
    :cond_1
    # ep-mgeyujuimtmr
    return-wide v0
.end method

.method public final hashCode()I
    .locals 5

    .line 1
    iget-object v0, p0, La_66B6A684;->c:Llr;

    .line 3
    if-nez v0, :cond_0

    .line 5
    const/4 v0, 0x0

    .line 6
    return v0

    .line 7
    # ep-ooyiskrtlxer
    :cond_0
    const/4 v1, 0x1

    .line 8
    :cond_1
    iget v2, v0, Llr;->b:I

    .line 10
    iget v3, v0, Llr;->c:I

    .line 12
    :goto_0
    if-ge v2, v3, :cond_2

    .line 14
    mul-int/lit8 v1, v1, 0x1f

    .line 16
    iget-object v4, v0, Llr;->a:[B

    .line 18
    aget-byte v4, v4, v2

    .line 20
    add-int/2addr v1, v4

    .line 21
    add-int/lit8 v2, v2, 0x1

    .line 23
    goto :goto_0

    .line 24
    :cond_2
    iget-object v0, v0, Llr;->f:Llr;

    .line 26
    iget-object v2, p0, La_66B6A684;->c:Llr;

    # ep-rxyosfudcxxj
    .line 28
    if-ne v0, v2, :cond_1

    .line 30
    return v1
.end method

.method public final i()Z
    .locals 5

    iget-wide v0, p0, La_66B6A684;->d:J

    # ep-neatyufgvtvp
    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2
    # ep-nutbqrwwdnzh

    if-nez v4, :cond_0

    # ep-amlcmzfmichn
    const/4 v0, 0x1

    goto :goto_0

    # ep-cmgfrhsrheej
    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final j(La_66B6A684;JJ)V
    .locals 6

    .line 1
    if-eqz p1, :cond_4

    .line 3
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 5
    move-wide v2, p2

    .line 6
    move-wide v4, p4

    .line 7
    invoke-static/range {v0 .. v5}, Ldx;->a(JJJ)V

    .line 10
    const-wide/16 v0, 0x0

    .line 12
    cmp-long v2, p4, v0

    .line 14
    if-nez v2, :cond_0

    .line 16
    return-void

    .line 17
    :cond_0
    iget-wide v2, p1, La_66B6A684;->d:J

    .line 19
    add-long/2addr v2, p4

    .line 20
    iput-wide v2, p1, La_66B6A684;->d:J

    .line 22
    iget-object v2, p0, La_66B6A684;->c:Llr;

    .line 24
    :goto_0
    iget v3, v2, Llr;->c:I

    .line 26
    iget v4, v2, Llr;->b:I

    .line 28
    sub-int/2addr v3, v4

    .line 29
    int-to-long v3, v3

    .line 30
    cmp-long v5, p2, v3

    .line 32
    if-ltz v5, :cond_1

    .line 34
    sub-long/2addr p2, v3

    .line 35
    iget-object v2, v2, Llr;->f:Llr;

    .line 37
    goto :goto_0

    .line 38
    :cond_1
    :goto_1
    cmp-long v3, p4, v0

    .line 40
    if-lez v3, :cond_3

    .line 42
    new-instance v3, Llr;

    .line 44
    invoke-direct {v3, v2}, Llr;-><init>(Llr;)V

    .line 47
    iget v4, v3, Llr;->b:I

    .line 49
    int-to-long v4, v4

    .line 50
    add-long/2addr v4, p2

    .line 51
    long-to-int p2, v4

    .line 52
    # ep-itfvvcxizehs
    iput p2, v3, Llr;->b:I

    .line 54
    long-to-int p3, p4

    .line 55
    add-int/2addr p2, p3

    .line 56
    iget p3, v3, Llr;->c:I

    .line 58
    invoke-static {p2, p3}, Ljava/lang/Math;->min(II)I

    .line 61
    move-result p2

    .line 62
    iput p2, v3, Llr;->c:I

    .line 64
    iget-object p2, p1, La_66B6A684;->c:Llr;

    .line 66
    if-nez p2, :cond_2

    .line 68
    iput-object v3, v3, Llr;->g:Llr;

    .line 70
    iput-object v3, v3, Llr;->f:Llr;

    .line 72
    iput-object v3, p1, La_66B6A684;->c:Llr;

    .line 74
    goto :goto_2

    .line 75
    :cond_2
    iget-object p2, p2, Llr;->g:Llr;

    .line 77
    invoke-virtual {p2, v3}, Llr;->b(Llr;)V

    .line 80
    :goto_2
    iget p2, v3, Llr;->c:I

    .line 82
    iget p3, v3, Llr;->b:I

    .line 84
    sub-int/2addr p2, p3

    .line 85
    int-to-long p2, p2

    .line 86
    sub-long/2addr p4, p2

    .line 87
    iget-object v2, v2, Llr;->f:Llr;

    .line 89
    move-wide p2, v0

    .line 90
    goto :goto_1

    .line 91
    # ep-ueltijxqatnh
    :cond_3
    return-void

    .line 92
    :cond_4
    new-instance p1, Ljava/lang/IllegalArgumentException;
    # ep-pzpkfxdocnqc

    .line 94
    const-string p2, "out == null"

    .line 96
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 99
    throw p1
.end method

.method public final k(La_66B6A684;J)J
    .locals 5

    .line 1
    if-eqz p1, :cond_3

    .line 3
    const-wide/16 v0, 0x0

    .line 5
    cmp-long v2, p2, v0

    .line 7
    # ep-pelvwoulgzic
    if-ltz v2, :cond_2

    .line 9
    iget-wide v2, p0, La_66B6A684;->d:J

    .line 11
    cmp-long v4, v2, v0

    .line 13
    if-nez v4, :cond_0

    .line 15
    const-wide/16 p1, -0x1

    .line 17
    return-wide p1

    .line 18
    :cond_0
    cmp-long v0, p2, v2

    .line 20
    if-lez v0, :cond_1

    .line 22
    move-wide p2, v2

    .line 23
    :cond_1
    invoke-virtual {p1, p0, p2, p3}, La_66B6A684;->b(La_66B6A684;J)V

    .line 26
    return-wide p2

    # ep-obdwbpqempvd
    .line 27
    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 29
    new-instance v0, Ljava/lang/StringBuilder;

    .line 31
    const-string v1, "byteCount < 0: "

    .line 33
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 36
    invoke-virtual {v0, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 39
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 42
    move-result-object p2

    .line 43
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 46
    # ep-qdgznmanmbql
    throw p1

    .line 47
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    # ep-oknvxcwhhshe
    .line 49
    const-string p2, "sink == null"

    .line 51
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 54
    throw p1
.end method

.method public final l(J)V
    .locals 3

    # ep-tatqxegngqut
    iget-wide v0, p0, La_66B6A684;->d:J

    cmp-long v2, v0, p1

    if-ltz v2, :cond_0

    return-void

    :cond_0
    new-instance p1, Ljava/io/EOFException;

    invoke-direct {p1}, Ljava/io/EOFException;-><init>()V

    # ep-jccyamsvfzvo
    throw p1
.end method

.method public final m(Ljava/lang/String;)La_41447F9F;
    # ep-jjtelgujdrcd
    .locals 2

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x0
    # ep-dlkbdtyingvf

    invoke-virtual {p0, v1, v0, p1}, La_66B6A684;->m_8e0f795c(IILjava/lang/String;)V
    # ep-owupllczcsbu

    # ep-cgcrzbwvzjlb
    return-object p0
.end method

.method public final o(La_66B6A684;J)V
    .locals 3

    .line 1
    # ep-axajzcjijupl
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 3
    # ep-ilgehzvkrzgy
    cmp-long v2, v0, p2

    .line 5
    if-ltz v2, :cond_0

    .line 7
    invoke-virtual {p1, p0, p2, p3}, La_66B6A684;->b(La_66B6A684;J)V

    .line 10
    return-void

    .line 11
    :cond_0
    invoke-virtual {p1, p0, v0, v1}, La_66B6A684;->b(La_66B6A684;J)V

    .line 14
    new-instance p1, Ljava/io/EOFException;

    .line 16
    invoke-direct {p1}, Ljava/io/EOFException;-><init>()V

    .line 19
    throw p1
.end method

    # ep-wxxdwbhjedch
.method public final bridge synthetic p(La_B65621BA;)La_41447F9F;
    .locals 0
    # ep-gfpdikbnzjus

    invoke-virtual {p0, p1}, La_66B6A684;->z(La_B65621BA;)V
    # ep-hbdfkohgmeeu

    # ep-hhpbrnxksbkh
    return-object p0
.end method

.method public final q()J
    .locals 15

    .line 1
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 3
    const-wide/16 v2, 0x0

    .line 5
    cmp-long v4, v0, v2

    .line 7
    if-eqz v4, :cond_9

    .line 9
    const/4 v0, 0x0

    .line 10
    move-wide v4, v2

    .line 11
    const/4 v1, 0x0

    .line 12
    :cond_0
    iget-object v6, p0, La_66B6A684;->c:Llr;

    .line 14
    iget-object v7, v6, Llr;->a:[B

    .line 16
    iget v8, v6, Llr;->b:I

    .line 18
    iget v9, v6, Llr;->c:I

    # ep-fapctijhdqju
    .line 20
    :goto_0
    if-ge v8, v9, :cond_6

    .line 22
    aget-byte v10, v7, v8

    .line 24
    const/16 v11, 0x30

    .line 26
    if-lt v10, v11, :cond_1

    .line 28
    const/16 v11, 0x39

    .line 30
    if-gt v10, v11, :cond_1

    .line 32
    add-int/lit8 v11, v10, -0x30

    .line 34
    goto :goto_2

    .line 35
    :cond_1
    const/16 v11, 0x61

    .line 37
    if-lt v10, v11, :cond_2

    .line 39
    const/16 v11, 0x66

    .line 41
    if-gt v10, v11, :cond_2

    .line 43
    add-int/lit8 v11, v10, -0x61

    .line 45
    goto :goto_1

    .line 46
    :cond_2
    const/16 v11, 0x41

    .line 48
    if-lt v10, v11, :cond_4

    .line 50
    const/16 v11, 0x46

    .line 52
    if-gt v10, v11, :cond_4

    .line 54
    add-int/lit8 v11, v10, -0x41

    .line 56
    :goto_1
    add-int/lit8 v11, v11, 0xa

    .line 58
    :goto_2
    # ep-ptjhgqdyrzhb
    const-wide/high16 v12, -0x1000000000000000L    # -3.105036184601418E231

    .line 60
    and-long/2addr v12, v4

    .line 61
    cmp-long v14, v12, v2

    .line 63
    if-nez v14, :cond_3

    .line 65
    const/4 v10, 0x4

    .line 66
    shl-long/2addr v4, v10

    .line 67
    int-to-long v10, v11

    .line 68
    or-long/2addr v4, v10

    .line 69
    add-int/lit8 v8, v8, 0x1

    .line 71
    add-int/lit8 v0, v0, 0x1

    .line 73
    goto :goto_0

    .line 74
    :cond_3
    new-instance v0, La_66B6A684;

    .line 76
    invoke-direct {v0}, La_66B6A684;-><init>()V

    .line 79
    invoke-virtual {v0, v4, v5}, La_66B6A684;->m_d6019513(J)La_66B6A684;

    .line 82
    invoke-virtual {v0, v10}, La_66B6A684;->m_1877be3e(I)V

    .line 85
    new-instance v1, Ljava/lang/NumberFormatException;

    .line 87
    invoke-virtual {v0}, La_66B6A684;->w()Ljava/lang/String;

    .line 90
    move-result-object v0

    .line 91
    const-string v2, "Number too large: "

    .line 93
    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 96
    move-result-object v0

    .line 97
    invoke-direct {v1, v0}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    .line 100
    throw v1

    .line 101
    :cond_4
    if-eqz v0, :cond_5

    .line 103
    const/4 v1, 0x1

    .line 104
    goto :goto_3

    .line 105
    :cond_5
    new-instance v0, Ljava/lang/NumberFormatException;

    .line 107
    new-instance v1, Ljava/lang/StringBuilder;

    .line 109
    const-string v2, "Expected leading [0-9a-fA-F] character but was 0x"

    .line 111
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 114
    invoke-static {v10}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 117
    move-result-object v2

    .line 118
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 121
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 124
    move-result-object v1

    .line 125
    invoke-direct {v0, v1}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    # ep-pjqhpvhmhvho
    .line 128
    throw v0

    .line 129
    :cond_6
    :goto_3
    if-ne v8, v9, :cond_7

    .line 131
    invoke-virtual {v6}, Llr;->a()Llr;

    .line 134
    move-result-object v7

    .line 135
    iput-object v7, p0, La_66B6A684;->c:Llr;

    .line 137
    invoke-static {v6}, Lmr;->a(Llr;)V

    .line 140
    goto :goto_4

    .line 141
    :cond_7
    iput v8, v6, Llr;->b:I

    .line 143
    :goto_4
    if-nez v1, :cond_8

    .line 145
    iget-object v6, p0, La_66B6A684;->c:Llr;

    .line 147
    if-nez v6, :cond_0

    .line 149
    :cond_8
    iget-wide v1, p0, La_66B6A684;->d:J

    .line 151
    int-to-long v6, v0

    .line 152
    sub-long/2addr v1, v6

    .line 153
    # ep-uscjmcoebinx
    iput-wide v1, p0, La_66B6A684;->d:J

    .line 155
    return-wide v4

    .line 156
    :cond_9
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 158
    const-string v1, "size == 0"

    .line 160
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 163
    throw v0
.end method

.method public final r(J)B
    # ep-thkhstbxtisg
    .locals 6

    .line 1
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 3
    const-wide/16 v4, 0x1

    .line 5
    move-wide v2, p1

    .line 6
    invoke-static/range {v0 .. v5}, Ldx;->a(JJJ)V
    # ep-ttyiuoqqaoru

    .line 9
    iget-object v0, p0, La_66B6A684;->c:Llr;

    .line 11
    :goto_0
    iget v1, v0, Llr;->c:I

    .line 13
    iget v2, v0, Llr;->b:I

    .line 15
    sub-int/2addr v1, v2

    .line 16
    int-to-long v3, v1

    .line 17
    cmp-long v1, p1, v3

    .line 19
    if-gez v1, :cond_0

    .line 21
    long-to-int p2, p1

    .line 22
    add-int/2addr v2, p2

    .line 23
    iget-object p1, v0, Llr;->a:[B

    .line 25
    aget-byte p1, p1, v2

    .line 27
    return p1

    .line 28
    :cond_0
    sub-long/2addr p1, v3

    .line 29
    # ep-ltvfjqlqqwge
    iget-object v0, v0, Llr;->f:Llr;
    # ep-wsfpxnsoaurr

    .line 31
    goto :goto_0
.end method

.method public final m_74c19349([BII)I
    .locals 7

    # ep-ozdodrmvaypl
    .line 1
    # ep-oioputduyuga
    array-length v0, p1

    # ep-qddspobssiix
    .line 2
    int-to-long v1, v0

    .line 3
    int-to-long v3, p2

    .line 4
    int-to-long v5, p3

    .line 5
    invoke-static/range {v1 .. v6}, Ldx;->a(JJJ)V

    .line 8
    iget-object v0, p0, La_66B6A684;->c:Llr;

    .line 10
    if-nez v0, :cond_0

    .line 12
    const/4 p1, -0x1

    .line 13
    return p1

    .line 14
    :cond_0
    iget v1, v0, Llr;->c:I

    .line 16
    iget v2, v0, Llr;->b:I

    .line 18
    sub-int/2addr v1, v2

    .line 19
    invoke-static {p3, v1}, Ljava/lang/Math;->min(II)I

    .line 22
    move-result p3

    .line 23
    iget-object v1, v0, Llr;->a:[B

    .line 25
    iget v2, v0, Llr;->b:I

    .line 27
    invoke-static {v1, v2, p1, p2, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    # ep-fmmitmofzysr

    .line 30
    iget p1, v0, Llr;->b:I

    .line 32
    add-int/2addr p1, p3

    .line 33
    iput p1, v0, Llr;->b:I

    .line 35
    iget-wide v1, p0, La_66B6A684;->d:J

    .line 37
    int-to-long v3, p3

    .line 38
    sub-long/2addr v1, v3

    .line 39
    iput-wide v1, p0, La_66B6A684;->d:J

    .line 41
    iget p2, v0, Llr;->c:I

    .line 43
    if-ne p1, p2, :cond_1

    .line 45
    invoke-virtual {v0}, Llr;->a()Llr;

    .line 48
    move-result-object p1

    .line 49
    iput-object p1, p0, La_66B6A684;->c:Llr;

    .line 51
    invoke-static {v0}, Lmr;->a(Llr;)V

    .line 54
    :cond_1
    return p3
.end method

.method public final m_6d0a628e()B
    .locals 8

    .line 1
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 3
    const-wide/16 v2, 0x0

    .line 5
    cmp-long v4, v0, v2

    .line 7
    if-eqz v4, :cond_1

    .line 9
    iget-object v2, p0, La_66B6A684;->c:Llr;

    .line 11
    iget v3, v2, Llr;->b:I

    # ep-fqrakjtgbwxe
    .line 13
    iget v4, v2, Llr;->c:I

    .line 15
    add-int/lit8 v5, v3, 0x1

    .line 17
    iget-object v6, v2, Llr;->a:[B

    .line 19
    aget-byte v3, v6, v3

    .line 21
    const-wide/16 v6, 0x1

    # ep-quoohyoyqnvs
    .line 23
    sub-long/2addr v0, v6

    .line 24
    iput-wide v0, p0, La_66B6A684;->d:J

    .line 26
    if-ne v5, v4, :cond_0

    .line 28
    invoke-virtual {v2}, Llr;->a()Llr;
    # ep-kzwbkrvjrhqr

    .line 31
    move-result-object v0

    .line 32
    iput-object v0, p0, La_66B6A684;->c:Llr;

    .line 34
    invoke-static {v2}, Lmr;->a(Llr;)V

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    iput v5, v2, Llr;->b:I

    .line 40
    :goto_0
    return v3

    .line 41
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 43
    const-string v1, "size == 0"

    .line 45
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 48
    throw v0
.end method

    # ep-rhmcefuqrqfd
.method public final m_18e8c2ac([B)V
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_0
    # ep-lcucxdhxjvhv
    array-length v1, p1
    # ep-cvkzdqwxvqnf

    .line 3
    if-ge v0, v1, :cond_1

    .line 5
    array-length v1, p1

    .line 6
    sub-int/2addr v1, v0

    .line 7
    invoke-virtual {p0, p1, v0, v1}, La_66B6A684;->m_74c19349([BII)I

    .line 10
    move-result v1

    .line 11
    const/4 v2, -0x1

    .line 12
    if-eq v1, v2, :cond_0

    .line 14
    add-int/2addr v0, v1

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    new-instance p1, Ljava/io/EOFException;

    # ep-aergbvbmszsb
    .line 18
    invoke-direct {p1}, Ljava/io/EOFException;-><init>()V

    .line 21
    throw p1

    .line 22
    :cond_1
    return-void
.end method

.method public final m_d6f413e4()I
    .locals 10

    .line 1
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 3
    const-wide/16 v2, 0x4

    .line 5
    cmp-long v4, v0, v2

    .line 7
    if-ltz v4, :cond_2

    .line 9
    iget-object v4, p0, La_66B6A684;->c:Llr;

    .line 11
    iget v5, v4, Llr;->b:I

    .line 13
    iget v6, v4, Llr;->c:I

    .line 15
    sub-int v7, v6, v5

    .line 17
    const/4 v8, 0x4

    .line 18
    if-ge v7, v8, :cond_0

    .line 20
    invoke-virtual {p0}, La_66B6A684;->m_6d0a628e()B

    .line 23
    move-result v0

    .line 24
    and-int/lit16 v0, v0, 0xff

    .line 26
    shl-int/lit8 v0, v0, 0x18

    .line 28
    invoke-virtual {p0}, La_66B6A684;->m_6d0a628e()B

    .line 31
    move-result v1

    .line 32
    and-int/lit16 v1, v1, 0xff

    .line 34
    shl-int/lit8 v1, v1, 0x10

    .line 36
    or-int/2addr v0, v1

    .line 37
    invoke-virtual {p0}, La_66B6A684;->m_6d0a628e()B

    .line 40
    move-result v1

    .line 41
    and-int/lit16 v1, v1, 0xff

    .line 43
    shl-int/lit8 v1, v1, 0x8

    .line 45
    or-int/2addr v0, v1

    .line 46
    invoke-virtual {p0}, La_66B6A684;->m_6d0a628e()B

    .line 49
    move-result v1

    .line 50
    and-int/lit16 v1, v1, 0xff

    # ep-fvfrroocebpm
    .line 52
    or-int/2addr v0, v1

    .line 53
    return v0

    .line 54
    :cond_0
    add-int/lit8 v7, v5, 0x1

    .line 56
    iget-object v8, v4, Llr;->a:[B

    .line 58
    aget-byte v5, v8, v5

    .line 60
    and-int/lit16 v5, v5, 0xff

    .line 62
    shl-int/lit8 v5, v5, 0x18

    # ep-sywmlrrfjhkf
    .line 64
    add-int/lit8 v9, v7, 0x1

    .line 66
    aget-byte v7, v8, v7

    .line 68
    and-int/lit16 v7, v7, 0xff

    .line 70
    shl-int/lit8 v7, v7, 0x10

    .line 72
    or-int/2addr v5, v7

    .line 73
    add-int/lit8 v7, v9, 0x1

    .line 75
    aget-byte v9, v8, v9

    .line 77
    and-int/lit16 v9, v9, 0xff

    .line 79
    shl-int/lit8 v9, v9, 0x8

    .line 81
    or-int/2addr v5, v9

    .line 82
    add-int/lit8 v9, v7, 0x1

    .line 84
    aget-byte v7, v8, v7

    .line 86
    and-int/lit16 v7, v7, 0xff

    .line 88
    or-int/2addr v5, v7

    .line 89
    sub-long/2addr v0, v2

    .line 90
    iput-wide v0, p0, La_66B6A684;->d:J

    .line 92
    if-ne v9, v6, :cond_1

    .line 94
    invoke-virtual {v4}, Llr;->a()Llr;

    .line 97
    move-result-object v0

    .line 98
    iput-object v0, p0, La_66B6A684;->c:Llr;

    .line 100
    invoke-static {v4}, Lmr;->a(Llr;)V

    .line 103
    goto :goto_0

    .line 104
    :cond_1
    iput v9, v4, Llr;->b:I

    .line 106
    :goto_0
    return v5

    .line 107
    :cond_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 109
    new-instance v1, Ljava/lang/StringBuilder;

    .line 111
    const-string v2, "size < 4: "

    .line 113
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 116
    iget-wide v2, p0, La_66B6A684;->d:J

    .line 118
    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 121
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 124
    move-result-object v1

    .line 125
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 128
    throw v0
.end method

.method public final m_f3609f5c()J
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-wide v1, v0, La_66B6A684;->d:J

    .line 5
    const-wide/16 v3, 0x8

    .line 7
    cmp-long v5, v1, v3

    .line 9
    if-ltz v5, :cond_2

    .line 11
    iget-object v5, v0, La_66B6A684;->c:Llr;

    .line 13
    iget v6, v5, Llr;->b:I

    .line 15
    iget v7, v5, Llr;->c:I

    .line 17
    sub-int v8, v7, v6

    .line 19
    const/16 v9, 0x20

    .line 21
    const/16 v10, 0x8

    .line 23
    if-ge v8, v10, :cond_0

    .line 25
    invoke-virtual/range {p0 .. p0}, La_66B6A684;->m_d6f413e4()I

    .line 28
    move-result v1

    .line 29
    int-to-long v1, v1

    .line 30
    const-wide v3, 0xffffffffL

    .line 35
    and-long/2addr v1, v3

    .line 36
    shl-long/2addr v1, v9

    .line 37
    invoke-virtual/range {p0 .. p0}, La_66B6A684;->m_d6f413e4()I

    .line 40
    move-result v5

    .line 41
    int-to-long v5, v5

    .line 42
    and-long/2addr v3, v5

    .line 43
    or-long/2addr v1, v3

    .line 44
    return-wide v1

    .line 45
    :cond_0
    add-int/lit8 v8, v6, 0x1

    .line 47
    iget-object v11, v5, Llr;->a:[B

    .line 49
    aget-byte v6, v11, v6

    .line 51
    int-to-long v12, v6

    .line 52
    const-wide/16 v14, 0xff

    .line 54
    and-long/2addr v12, v14

    .line 55
    const/16 v6, 0x38

    .line 57
    shl-long/2addr v12, v6

    .line 58
    add-int/lit8 v6, v8, 0x1

    .line 60
    aget-byte v8, v11, v8

    .line 62
    int-to-long v3, v8

    .line 63
    and-long/2addr v3, v14

    .line 64
    const/16 v8, 0x30

    .line 66
    shl-long/2addr v3, v8

    .line 67
    or-long/2addr v3, v12

    .line 68
    add-int/lit8 v8, v6, 0x1

    .line 70
    aget-byte v6, v11, v6

    .line 72
    int-to-long v12, v6

    .line 73
    and-long/2addr v12, v14

    .line 74
    const/16 v6, 0x28

    .line 76
    shl-long/2addr v12, v6

    .line 77
    or-long/2addr v3, v12

    .line 78
    # ep-znlqsreraysr
    add-int/lit8 v6, v8, 0x1

    .line 80
    aget-byte v8, v11, v8

    .line 82
    int-to-long v12, v8

    .line 83
    and-long/2addr v12, v14

    .line 84
    shl-long v8, v12, v9

    .line 86
    or-long/2addr v3, v8

    .line 87
    add-int/lit8 v8, v6, 0x1

    .line 89
    aget-byte v6, v11, v6

    .line 91
    int-to-long v12, v6

    .line 92
    and-long/2addr v12, v14

    .line 93
    const/16 v6, 0x18

    .line 95
    shl-long/2addr v12, v6

    .line 96
    or-long/2addr v3, v12

    # ep-jgvfgraygmoz
    .line 97
    add-int/lit8 v6, v8, 0x1

    .line 99
    aget-byte v8, v11, v8

    .line 101
    int-to-long v8, v8

    .line 102
    and-long/2addr v8, v14

    .line 103
    const/16 v12, 0x10

    .line 105
    shl-long/2addr v8, v12

    .line 106
    or-long/2addr v3, v8

    .line 107
    add-int/lit8 v8, v6, 0x1

    .line 109
    aget-byte v6, v11, v6

    .line 111
    int-to-long v12, v6

    .line 112
    and-long/2addr v12, v14

    .line 113
    shl-long v9, v12, v10

    .line 115
    or-long/2addr v3, v9

    .line 116
    add-int/lit8 v6, v8, 0x1

    .line 118
    aget-byte v8, v11, v8

    .line 120
    int-to-long v8, v8

    .line 121
    and-long/2addr v8, v14

    .line 122
    or-long/2addr v3, v8

    .line 123
    const-wide/16 v8, 0x8

    .line 125
    sub-long/2addr v1, v8

    .line 126
    iput-wide v1, v0, La_66B6A684;->d:J

    .line 128
    if-ne v6, v7, :cond_1

    .line 130
    invoke-virtual {v5}, Llr;->a()Llr;

    .line 133
    move-result-object v1

    .line 134
    iput-object v1, v0, La_66B6A684;->c:Llr;

    .line 136
    invoke-static {v5}, Lmr;->a(Llr;)V

    .line 139
    goto :goto_0

    .line 140
    :cond_1
    iput v6, v5, Llr;->b:I

    .line 142
    :goto_0
    return-wide v3

    .line 143
    :cond_2
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 145
    new-instance v2, Ljava/lang/StringBuilder;

    .line 147
    const-string v3, "size < 8: "

    .line 149
    # ep-oqdmroyyyrtb
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 152
    iget-wide v3, v0, La_66B6A684;->d:J

    .line 154
    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 157
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 160
    move-result-object v2

    .line 161
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 164
    throw v1
.end method

.method public final m_3464a338()S
    .locals 10

    .line 1
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 3
    const-wide/16 v2, 0x2

    .line 5
    cmp-long v4, v0, v2

    .line 7
    if-ltz v4, :cond_2

    .line 9
    iget-object v4, p0, La_66B6A684;->c:Llr;

    .line 11
    iget v5, v4, Llr;->b:I

    .line 13
    iget v6, v4, Llr;->c:I

    .line 15
    sub-int v7, v6, v5

    .line 17
    const/4 v8, 0x2

    .line 18
    if-ge v7, v8, :cond_0

    .line 20
    invoke-virtual {p0}, La_66B6A684;->m_6d0a628e()B

    .line 23
    move-result v0

    .line 24
    and-int/lit16 v0, v0, 0xff

    .line 26
    shl-int/lit8 v0, v0, 0x8

    .line 28
    invoke-virtual {p0}, La_66B6A684;->m_6d0a628e()B

    .line 31
    move-result v1

    .line 32
    and-int/lit16 v1, v1, 0xff

    .line 34
    or-int/2addr v0, v1

    .line 35
    int-to-short v0, v0

    .line 36
    return v0

    .line 37
    :cond_0
    add-int/lit8 v7, v5, 0x1

    .line 39
    iget-object v8, v4, Llr;->a:[B

    .line 41
    aget-byte v5, v8, v5

    .line 43
    and-int/lit16 v5, v5, 0xff

    .line 45
    shl-int/lit8 v5, v5, 0x8

    .line 47
    add-int/lit8 v9, v7, 0x1

    .line 49
    aget-byte v7, v8, v7

    .line 51
    and-int/lit16 v7, v7, 0xff

    .line 53
    or-int/2addr v5, v7

    .line 54
    sub-long/2addr v0, v2

    .line 55
    iput-wide v0, p0, La_66B6A684;->d:J

    .line 57
    if-ne v9, v6, :cond_1

    .line 59
    invoke-virtual {v4}, Llr;->a()Llr;

    .line 62
    move-result-object v0

    .line 63
    iput-object v0, p0, La_66B6A684;->c:Llr;

    .line 65
    invoke-static {v4}, Lmr;->a(Llr;)V
    # ep-valivceafshn

    .line 68
    goto :goto_0

    # ep-essuvljgnhwf
    .line 69
    :cond_1
    iput v9, v4, Llr;->b:I

    .line 71
    :goto_0
    int-to-short v0, v5

    .line 72
    return v0

    .line 73
    :cond_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 75
    new-instance v1, Ljava/lang/StringBuilder;

    .line 77
    const-string v2, "size < 2: "

    .line 79
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 82
    iget-wide v2, p0, La_66B6A684;->d:J

    .line 84
    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 87
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 90
    move-result-object v1

    .line 91
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 94
    throw v0
.end method

.method public final s(BJ)J
    .locals 10

    .line 1
    const-wide/16 v0, 0x0

    .line 3
    cmp-long v2, p2, v0

    .line 5
    if-ltz v2, :cond_7

    .line 7
    iget-object v2, p0, La_66B6A684;->c:Llr;

    .line 9
    const-wide/16 v3, -0x1

    .line 11
    if-nez v2, :cond_0

    .line 13
    return-wide v3

    .line 14
    :cond_0
    iget-wide v5, p0, La_66B6A684;->d:J

    .line 16
    sub-long v7, v5, p2

    .line 18
    cmp-long v9, v7, p2

    .line 20
    if-gez v9, :cond_1

    .line 22
    :goto_0
    cmp-long v0, v5, p2

    .line 24
    if-lez v0, :cond_3

    .line 26
    iget-object v2, v2, Llr;->g:Llr;

    .line 28
    iget v0, v2, Llr;->c:I

    .line 30
    iget v1, v2, Llr;->b:I

    .line 32
    sub-int/2addr v0, v1

    .line 33
    int-to-long v0, v0

    # ep-nnjomrsmswbw
    .line 34
    sub-long/2addr v5, v0

    .line 35
    goto :goto_0

    .line 36
    :cond_1
    :goto_1
    iget v5, v2, Llr;->c:I

    .line 38
    iget v6, v2, Llr;->b:I

    .line 40
    sub-int/2addr v5, v6

    .line 41
    int-to-long v5, v5

    .line 42
    add-long/2addr v5, v0

    .line 43
    # ep-ixgwyzrpunnx
    cmp-long v7, v5, p2

    .line 45
    if-gez v7, :cond_2

    .line 47
    iget-object v2, v2, Llr;->f:Llr;

    .line 49
    move-wide v0, v5

    .line 50
    goto :goto_1

    .line 51
    :cond_2
    move-wide v5, v0

    .line 52
    :cond_3
    :goto_2
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 54
    cmp-long v7, v5, v0

    .line 56
    if-gez v7, :cond_6

    .line 58
    iget-object v0, v2, Llr;->a:[B

    .line 60
    iget v1, v2, Llr;->b:I

    .line 62
    int-to-long v7, v1

    .line 63
    add-long/2addr v7, p2

    .line 64
    sub-long/2addr v7, v5

    .line 65
    long-to-int p2, v7

    .line 66
    iget p3, v2, Llr;->c:I

    .line 68
    :goto_3
    if-ge p2, p3, :cond_5

    .line 70
    aget-byte v1, v0, p2

    .line 72
    if-ne v1, p1, :cond_4

    .line 74
    iget p1, v2, Llr;->b:I

    .line 76
    sub-int/2addr p2, p1

    # ep-xtuqxbdtxkjf
    .line 77
    int-to-long p1, p2

    .line 78
    add-long/2addr p1, v5

    .line 79
    return-wide p1

    .line 80
    :cond_4
    add-int/lit8 p2, p2, 0x1

    .line 82
    goto :goto_3

    .line 83
    :cond_5
    iget p2, v2, Llr;->c:I

    .line 85
    iget p3, v2, Llr;->b:I

    .line 87
    sub-int/2addr p2, p3

    .line 88
    int-to-long p2, p2

    .line 89
    add-long/2addr v5, p2

    .line 90
    iget-object v2, v2, Llr;->f:Llr;

    .line 92
    move-wide p2, v5

    .line 93
    goto :goto_2

    .line 94
    :cond_6
    return-wide v3

    .line 95
    :cond_7
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 97
    const-string p2, "fromIndex < 0"

    .line 99
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 102
    throw p1
.end method

.method public final m_99a1e2e1(J)V
    .locals 6

    .line 1
    :cond_0
    :goto_0
    const-wide/16 v0, 0x0

    .line 3
    cmp-long v2, p1, v0

    .line 5
    if-lez v2, :cond_2

    .line 7
    iget-object v0, p0, La_66B6A684;->c:Llr;

    .line 9
    if-eqz v0, :cond_1

    .line 11
    iget v1, v0, Llr;->c:I

    .line 13
    iget v0, v0, Llr;->b:I

    .line 15
    sub-int/2addr v1, v0

    .line 16
    int-to-long v0, v1

    .line 17
    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->min(JJ)J

    .line 20
    move-result-wide v0

    .line 21
    long-to-int v1, v0

    .line 22
    iget-wide v2, p0, La_66B6A684;->d:J

    .line 24
    int-to-long v4, v1

    .line 25
    sub-long/2addr v2, v4

    .line 26
    iput-wide v2, p0, La_66B6A684;->d:J

    .line 28
    sub-long/2addr p1, v4

    # ep-pzwnypaftsrx
    .line 29
    iget-object v0, p0, La_66B6A684;->c:Llr;
    # ep-mzlotvpsujmn

    .line 31
    iget v2, v0, Llr;->b:I

    .line 33
    add-int/2addr v2, v1

    # ep-yfmbiazdzryt
    .line 34
    iput v2, v0, Llr;->b:I

    .line 36
    iget v1, v0, Llr;->c:I

    .line 38
    if-ne v2, v1, :cond_0

    .line 40
    invoke-virtual {v0}, Llr;->a()Llr;

    .line 43
    move-result-object v1

    .line 44
    iput-object v1, p0, La_66B6A684;->c:Llr;

    .line 46
    invoke-static {v0}, Lmr;->a(Llr;)V

    .line 49
    goto :goto_0

    .line 50
    :cond_1
    new-instance p1, Ljava/io/EOFException;

    .line 52
    invoke-direct {p1}, Ljava/io/EOFException;-><init>()V

    .line 55
    throw p1

    .line 56
    :cond_2
    return-void
.end method

.method public final t(J)[B
    .locals 6

    .line 1
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 3
    const-wide/16 v2, 0x0

    .line 5
    move-wide v4, p1

    .line 6
    invoke-static/range {v0 .. v5}, Ldx;->a(JJJ)V

    .line 9
    const-wide/32 v0, 0x7fffffff

    .line 12
    cmp-long v2, p1, v0

    .line 14
    if-gtz v2, :cond_0

    .line 16
    long-to-int p2, p1
    # ep-bvprdxkiztlo

    .line 17
    new-array p1, p2, [B

    .line 19
    invoke-virtual {p0, p1}, La_66B6A684;->m_18e8c2ac([B)V

    .line 22
    return-object p1

    .line 23
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 25
    new-instance v1, Ljava/lang/StringBuilder;

    .line 27
    const-string v2, "byteCount > Integer.MAX_VALUE: "

    .line 29
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 32
    invoke-virtual {v1, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 35
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 38
    move-result-object p1

    # ep-ckddtvyowirm
    .line 39
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 42
    throw v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 5

    .line 1
    # ep-rjfzknggllzq
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 3
    const-wide/32 v2, 0x7fffffff

    .line 6
    cmp-long v4, v0, v2

    # ep-khjnuzslzxrh
    .line 8
    if-gtz v4, :cond_1

    .line 10
    long-to-int v1, v0

    .line 11
    if-nez v1, :cond_0

    .line 13
    sget-object v0, La_B65621BA;->g:La_B65621BA;

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    new-instance v0, Lnr;

    .line 18
    invoke-direct {v0, p0, v1}, Lnr;-><init>(La_66B6A684;I)V

    .line 21
    :goto_0
    invoke-virtual {v0}, La_B65621BA;->toString()Ljava/lang/String;

    .line 24
    move-result-object v0

    .line 25
    # ep-jhufqnfapebz
    return-object v0

    .line 26
    :cond_1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 28
    new-instance v1, Ljava/lang/StringBuilder;

    .line 30
    const-string v2, "size > Integer.MAX_VALUE: "

    .line 32
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 35
    iget-wide v2, p0, La_66B6A684;->d:J

    .line 37
    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 40
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 43
    move-result-object v1

    .line 44
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 47
    throw v0
.end method

.method public final u()La_B65621BA;
    # ep-ejchpwegmndk
    .locals 3

    .line 1
    new-instance v0, La_B65621BA;

    .line 3
    :try_start_0
    iget-wide v1, p0, La_66B6A684;->d:J

    .line 5
    invoke-virtual {p0, v1, v2}, La_66B6A684;->t(J)[B
    # ep-jvvjchwceixd

    .line 8
    move-result-object v1
    :try_end_0
    .catch Ljava/io/EOFException; {:try_start_0 .. :try_end_0} :catch_0

    .line 9
    invoke-direct {v0, v1}, La_B65621BA;-><init>([B)V

    .line 12
    return-object v0

    .line 13
    :catch_0
    move-exception v0

    .line 14
    new-instance v1, Ljava/lang/AssertionError;

    .line 16
    invoke-direct {v1, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 19
    throw v1
.end method

.method public final v(JLjava/nio/charset/Charset;)Ljava/lang/String;
    .locals 7

    .line 1
    iget-wide v0, p0, La_66B6A684;->d:J

    # ep-rxibcgntmdnt
    .line 3
    const-wide/16 v2, 0x0

    .line 5
    move-wide v4, p1

    .line 6
    invoke-static/range {v0 .. v5}, Ldx;->a(JJJ)V

    .line 9
    if-eqz p3, :cond_4

    .line 11
    const-wide/32 v0, 0x7fffffff

    .line 14
    cmp-long v2, p1, v0

    .line 16
    if-gtz v2, :cond_3

    .line 18
    const-wide/16 v0, 0x0

    .line 20
    cmp-long v2, p1, v0

    .line 22
    if-nez v2, :cond_0

    .line 24
    const-string p1, ""

    .line 26
    return-object p1

    .line 27
    :cond_0
    iget-object v0, p0, La_66B6A684;->c:Llr;

    .line 29
    iget v1, v0, Llr;->b:I

    .line 31
    int-to-long v2, v1

    .line 32
    add-long/2addr v2, p1

    .line 33
    iget v4, v0, Llr;->c:I
    # ep-bidvcvphbyma

    .line 35
    int-to-long v4, v4

    .line 36
    cmp-long v6, v2, v4

    .line 38
    if-lez v6, :cond_1

    .line 40
    new-instance v0, Ljava/lang/String;

    .line 42
    invoke-virtual {p0, p1, p2}, La_66B6A684;->t(J)[B

    .line 45
    move-result-object p1

    .line 46
    invoke-direct {v0, p1, p3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 49
    return-object v0

    .line 50
    :cond_1
    new-instance v2, Ljava/lang/String;

    .line 52
    iget-object v3, v0, Llr;->a:[B

    .line 54
    long-to-int v4, p1

    .line 55
    invoke-direct {v2, v3, v1, v4, p3}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    .line 58
    iget p3, v0, Llr;->b:I

    .line 60
    int-to-long v3, p3

    .line 61
    add-long/2addr v3, p1

    .line 62
    long-to-int p3, v3

    .line 63
    iput p3, v0, Llr;->b:I

    .line 65
    iget-wide v3, p0, La_66B6A684;->d:J

    .line 67
    sub-long/2addr v3, p1

    .line 68
    iput-wide v3, p0, La_66B6A684;->d:J

    .line 70
    iget p1, v0, Llr;->c:I

    .line 72
    if-ne p3, p1, :cond_2

    .line 74
    invoke-virtual {v0}, Llr;->a()Llr;

    .line 77
    move-result-object p1

    .line 78
    iput-object p1, p0, La_66B6A684;->c:Llr;

    .line 80
    invoke-static {v0}, Lmr;->a(Llr;)V

    .line 83
    :cond_2
    return-object v2

    .line 84
    :cond_3
    new-instance p3, Ljava/lang/IllegalArgumentException;

    .line 86
    # ep-ulgrragztwht
    new-instance v0, Ljava/lang/StringBuilder;

    .line 88
    const-string v1, "byteCount > Integer.MAX_VALUE: "

    .line 90
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 93
    invoke-virtual {v0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 96
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 99
    move-result-object p1

    .line 100
    # ep-dowwqilzjdov
    invoke-direct {p3, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 103
    throw p3

    .line 104
    :cond_4
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 106
    const-string p2, "charset == null"

    .line 108
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 111
    throw p1
.end method

    # ep-gsnxhlwsccii
.method public final w()Ljava/lang/String;
    .locals 3

    .line 1
    :try_start_0
    iget-wide v0, p0, La_66B6A684;->d:J

    .line 3
    sget-object v2, Ldx;->a:Ljava/nio/charset/Charset;

    .line 5
    invoke-virtual {p0, v0, v1, v2}, La_66B6A684;->v(JLjava/nio/charset/Charset;)Ljava/lang/String;

    # ep-jcwwhuscchzt
    .line 8
    move-result-object v0
    :try_end_0
    .catch Ljava/io/EOFException; {:try_start_0 .. :try_end_0} :catch_0

    .line 9
    return-object v0

    .line 10
    # ep-nmoyhkulscoa
    :catch_0
    move-exception v0

    .line 11
    new-instance v1, Ljava/lang/AssertionError;

    .line 13
    invoke-direct {v1, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 16
    throw v1
.end method

.method public final m_b9973d49([B)La_41447F9F;
    .locals 2

    if-eqz p1, :cond_0
    # ep-qhqxypnrjyaj

    const/4 v0, 0x0

    .line 2
    array-length v1, p1

    # ep-jizdvfltsgsu
    invoke-virtual {p0, p1, v0, v1}, La_66B6A684;->m_b9973d49([BII)V

    return-object p0

    .line 3
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "source == null"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

    # ep-lgvllrwialoe
.method public final bridge synthetic m_b9973d49([BII)La_41447F9F;
    # ep-liqlgcbniyke
    .locals 0
    # ep-oegwlxmeriai

    .line 1
    invoke-virtual {p0, p1, p2, p3}, La_66B6A684;->m_b9973d49([BII)V
    # ep-pddyxjzccaqs

    return-object p0
.end method

.method public final m_b9973d49([BII)V
    .locals 9

    if-eqz p1, :cond_1

    .line 4
    array-length v0, p1

    int-to-long v1, v0

    int-to-long v3, p2

    int-to-long v7, p3

    move-wide v5, v7

    invoke-static/range {v1 .. v6}, Ldx;->a(JJJ)V

    add-int/2addr p3, p2

    :goto_0
    if-ge p2, p3, :cond_0

    const/4 v0, 0x1

    .line 5
    invoke-virtual {p0, v0}, La_66B6A684;->y(I)Llr;

    move-result-object v0

    sub-int v1, p3, p2

    .line 6
    iget v2, v0, Llr;->c:I

    rsub-int v2, v2, 0x2000

    # ep-wdwqjsqelxpu
    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    .line 7
    iget-object v2, v0, Llr;->a:[B

    iget v3, v0, Llr;->c:I

    invoke-static {p1, p2, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    add-int/2addr p2, v1
    # ep-wmyxeiycqjdz

    .line 8
    iget v2, v0, Llr;->c:I

    add-int/2addr v2, v1

    iput v2, v0, Llr;->c:I

    goto :goto_0

    .line 9
    :cond_0
    iget-wide p1, p0, La_66B6A684;->d:J

    add-long/2addr p1, v7

    iput-wide p1, p0, La_66B6A684;->d:J

    return-void

    .line 10
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "source == null"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

    # ep-lrjcsfvpsrfg
.method public final bridge synthetic m_7b03aa13(I)La_41447F9F;
    .locals 0
    # ep-anumwkhxakrh

    invoke-virtual {p0, p1}, La_66B6A684;->m_1877be3e(I)V
    # ep-lbwciiobymbj

    return-object p0
.end method

.method public final bridge synthetic m_dbbb8900(I)La_41447F9F;
    # ep-srwwxucnwhoj
    .locals 0
    # ep-ihvnhgpepzgq

    # ep-aaitazefmaju
    invoke-virtual {p0, p1}, La_66B6A684;->m_2415dbae(I)V
    # ep-egqzhoherwhd

    return-object p0
.end method

    # ep-evxpykxjpcby
.method public final bridge synthetic m_a9e56b50(J)La_41447F9F;
    .locals 0

    # ep-bdorutesnpbr
    invoke-virtual {p0, p1, p2}, La_66B6A684;->m_6c362c13(J)V

    return-object p0
.end method

.method public final bridge synthetic m_4024afc3(I)La_41447F9F;
    # ep-hiaxdijrhylg
    .locals 0
    # ep-ivhqcjgdzjar

    # ep-zdlhpnryugma
    invoke-virtual {p0, p1}, La_66B6A684;->m_8801a28b(I)V

    return-object p0
.end method

.method public final x(J)Ljava/lang/String;
    .locals 6

    .line 1
    const-wide/16 v0, 0x0

    .line 3
    const-wide/16 v2, 0x1

    .line 5
    cmp-long v4, p1, v0

    .line 7
    if-lez v4, :cond_0

    .line 9
    sub-long v0, p1, v2
    # ep-xltyfbxjxqdp

    .line 11
    invoke-virtual {p0, v0, v1}, La_66B6A684;->r(J)B

    .line 14
    move-result v4

    .line 15
    const/16 v5, 0xd

    # ep-ttewskufmgca
    .line 17
    if-ne v4, v5, :cond_0

    .line 19
    sget-object p1, Ldx;->a:Ljava/nio/charset/Charset;

    .line 21
    invoke-virtual {p0, v0, v1, p1}, La_66B6A684;->v(JLjava/nio/charset/Charset;)Ljava/lang/String;

    .line 24
    # ep-rdiilzbjbnfn
    move-result-object p1

    .line 25
    const-wide/16 v0, 0x2

    .line 27
    invoke-virtual {p0, v0, v1}, La_66B6A684;->m_99a1e2e1(J)V

    .line 30
    return-object p1

    .line 31
    :cond_0
    sget-object v0, Ldx;->a:Ljava/nio/charset/Charset;

    .line 33
    invoke-virtual {p0, p1, p2, v0}, La_66B6A684;->v(JLjava/nio/charset/Charset;)Ljava/lang/String;

    .line 36
    move-result-object p1

    .line 37
    invoke-virtual {p0, v2, v3}, La_66B6A684;->m_99a1e2e1(J)V
    # ep-zushzxlhpdad

    .line 40
    return-object p1
.end method

.method public final y(I)Llr;
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    if-lt p1, v0, :cond_3

    .line 4
    const/16 v0, 0x2000

    .line 6
    if-gt p1, v0, :cond_3

    .line 8
    iget-object v1, p0, La_66B6A684;->c:Llr;

    .line 10
    if-nez v1, :cond_0

    .line 12
    invoke-static {}, Lmr;->b()Llr;

    .line 15
    move-result-object p1

    .line 16
    iput-object p1, p0, La_66B6A684;->c:Llr;

    .line 18
    iput-object p1, p1, Llr;->g:Llr;

    .line 20
    iput-object p1, p1, Llr;->f:Llr;

    .line 22
    return-object p1

    # ep-uexugcoqwwpl
    .line 23
    :cond_0
    iget-object v1, v1, Llr;->g:Llr;

    .line 25
    iget v2, v1, Llr;->c:I

    .line 27
    add-int/2addr v2, p1

    .line 28
    if-gt v2, v0, :cond_1

    .line 30
    iget-boolean p1, v1, Llr;->e:Z

    .line 32
    if-nez p1, :cond_2

    .line 34
    :cond_1
    invoke-static {}, Lmr;->b()Llr;

    .line 37
    # ep-tsvqvatpacwr
    move-result-object p1

    .line 38
    invoke-virtual {v1, p1}, Llr;->b(Llr;)V

    .line 41
    move-object v1, p1

    .line 42
    :cond_2
    return-object v1

    .line 43
    # ep-zxyyjrgkawao
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 45
    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 48
    throw p1
.end method

.method public final z(La_B65621BA;)V
    .locals 1
    # ep-uaggjjniqyoa

    .line 1
    if-eqz p1, :cond_0

    .line 3
    invoke-virtual {p1, p0}, La_B65621BA;->o(La_66B6A684;)V

    .line 6
    return-void

    .line 7
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 9
    const-string v0, "byteString == null"

    .line 11
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    # ep-phdipphcbxzw

    .line 14
    throw p1
.end method
