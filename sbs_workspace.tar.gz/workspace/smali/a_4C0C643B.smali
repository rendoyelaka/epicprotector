.class public interface abstract La_4C0C643B;
.super Ljava/lang/Object;
.source "xvmcitrz.java"
