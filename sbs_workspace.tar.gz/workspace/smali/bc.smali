.class public final Lbc;
.super Ljava/lang/Object;
# ep-eeiqjpemjzhy
# optimised-50897
.source "SourceFile"

# interfaces
.implements Ljava/util/Set;
.implements Ljava/io/Serializable;


# static fields
.field public static final c:Lbc;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Lbc;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_6ijvl444
    goto :ep_s_6ijvl444
    :ep_d_6ijvl444
    nop
    :ep_s_6ijvl444
    invoke-direct {v0}, Lbc;-><init>()V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_6edg98jo
    goto :ep_s_6edg98jo
    :ep_d_6edg98jo
    nop
    :ep_s_6edg98jo
    sput-object v0, Lbc;->c:Lbc;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final bridge synthetic add(Ljava/lang/Object;)Z
    .locals 1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_5ij3q5zi
    goto :ep_s_5ij3q5zi
    :ep_d_5ij3q5zi
    nop
    :ep_s_5ij3q5zi
    const-string v0, "Operation is not supported for read-only collection"

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_5is7z0jg
    goto :ep_s_5is7z0jg
    :ep_d_5is7z0jg
    nop
    :ep_s_5is7z0jg
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final addAll(Ljava/util/Collection;)Z
    .locals 1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_x88276tw
    goto :ep_s_x88276tw
    :ep_d_x88276tw
    nop
    :ep_s_x88276tw
    const-string v0, "Operation is not supported for read-only collection"

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_ilgz6lry
    goto :ep_s_ilgz6lry
    :ep_d_ilgz6lry
    nop
    :ep_s_ilgz6lry
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final clear()V
    .locals 2

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_v25u0kri
    goto :ep_s_v25u0kri
    :ep_d_v25u0kri
    nop
    :ep_s_v25u0kri
    const-string v1, "Operation is not supported for read-only collection"

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_dytzxdyh
    goto :ep_s_dytzxdyh
    :ep_d_dytzxdyh
    nop
    :ep_s_dytzxdyh
    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final contains(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    instance-of v0, p1, Ljava/lang/Void;

    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 6
    return v1

    .line 7
    :cond_0
    check-cast p1, Ljava/lang/Void;

    .line 9
    const-string v0, "element"

    .line 11
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 14
    return v1
.end method

.method public final containsAll(Ljava/util/Collection;)Z
    .locals 1

    .line 1
    const-string v0, "elements"

    .line 3
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 9
    move-result p1

    .line 10
    return p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    instance-of v0, p1, Ljava/util/Set;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_bs4cpn1r
    goto :ep_s_bs4cpn1r
    :ep_d_bs4cpn1r
    nop
    :ep_s_bs4cpn1r
    if-eqz v0, :cond_0

    check-cast p1, Ljava/util/Set;

    invoke-interface {p1}, Ljava/util/Set;->isEmpty()Z

    move-result p1

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_rdv29u11
    goto :ep_s_rdv29u11
    :ep_d_rdv29u11
    nop
    :ep_s_rdv29u11
    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final hashCode()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final isEmpty()Z
    .locals 1

    const/4 v0, 0x1

    return v0
.end method

.method public final iterator()Ljava/util/Iterator;
    .locals 1

    sget-object v0, Lyb;->c:Lyb;

    return-object v0
.end method

.method public final remove(Ljava/lang/Object;)Z
    .locals 1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_tmpmfxby
    goto :ep_s_tmpmfxby
    :ep_d_tmpmfxby
    nop
    :ep_s_tmpmfxby
    const-string v0, "Operation is not supported for read-only collection"

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_70d1w0cj
    goto :ep_s_70d1w0cj
    :ep_d_70d1w0cj
    nop
    :ep_s_70d1w0cj
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final removeAll(Ljava/util/Collection;)Z
    .locals 1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_vdw6iypp
    goto :ep_s_vdw6iypp
    :ep_d_vdw6iypp
    nop
    :ep_s_vdw6iypp
    const-string v0, "Operation is not supported for read-only collection"

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_qhbui38p
    goto :ep_s_qhbui38p
    :ep_d_qhbui38p
    nop
    :ep_s_qhbui38p
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final retainAll(Ljava/util/Collection;)Z
    .locals 1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_yi7qfadl
    goto :ep_s_yi7qfadl
    :ep_d_yi7qfadl
    nop
    :ep_s_yi7qfadl
    const-string v0, "Operation is not supported for read-only collection"

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_svv0a33f
    goto :ep_s_svv0a33f
    :ep_d_svv0a33f
    nop
    :ep_s_svv0a33f
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final bridge size()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final toArray()[Ljava/lang/Object;
    .locals 1

    invoke-static {p0}, Lp2;->Y(Ljava/util/Collection;)[Ljava/lang/Object;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_cfskxvlw
    goto :ep_s_cfskxvlw
    :ep_d_cfskxvlw
    nop
    :ep_s_cfskxvlw
    move-result-object v0

    return-object v0
.end method

.method public final toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)[TT;"
        }
    .end annotation

    const-string v0, "array"

    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_wmkw5mvv
    goto :ep_s_wmkw5mvv
    :ep_d_wmkw5mvv
    nop
    :ep_s_wmkw5mvv
    invoke-static {p0, p1}, Lp2;->Z(Ljava/util/Collection;[Ljava/lang/Object;)[Ljava/lang/Object;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_kodyywrm
    goto :ep_s_kodyywrm
    :ep_d_kodyywrm
    nop
    :ep_s_kodyywrm
    move-result-object p1

    return-object p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    const-string v0, "[]"

    return-object v0
.end method
