.class public final Lbc;
.super Ljava/lang/Object;
# compiled-93222
# compiled-19945
# validated-94333
.source "SourceFile"

# ep-toxxbeupgdnm
# interfaces
.implements Ljava/util/Set;
.implements Ljava/io/Serializable;


# static fields
.field public static final c:Lbc;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Lbc;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_vn1vhxnh
    goto :ep_s_vn1vhxnh
    :ep_d_vn1vhxnh
    nop
    :ep_s_vn1vhxnh
    invoke-direct {v0}, Lbc;-><init>()V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_hhmqblbi
    goto :ep_s_hhmqblbi
    :ep_d_hhmqblbi
    nop
    :ep_s_hhmqblbi
    sput-object v0, Lbc;->c:Lbc;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final bridge synthetic add(Ljava/lang/Object;)Z
    .locals 1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_8hk9u7xc
    goto :ep_s_8hk9u7xc
    :ep_d_8hk9u7xc
    nop
    :ep_s_8hk9u7xc
    const-string v0, "Operation is not supported for read-only collection"

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_dqcz75z5
    goto :ep_s_dqcz75z5
    :ep_d_dqcz75z5
    nop
    :ep_s_dqcz75z5
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final addAll(Ljava/util/Collection;)Z
    .locals 1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_ku4zejwr
    goto :ep_s_ku4zejwr
    :ep_d_ku4zejwr
    nop
    :ep_s_ku4zejwr
    const-string v0, "Operation is not supported for read-only collection"

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_h9xr350g
    goto :ep_s_h9xr350g
    :ep_d_h9xr350g
    nop
    :ep_s_h9xr350g
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final clear()V
    .locals 2

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_n43i9t1i
    goto :ep_s_n43i9t1i
    :ep_d_n43i9t1i
    nop
    :ep_s_n43i9t1i
    const-string v1, "Operation is not supported for read-only collection"

    const/4 v1, 0x1
    if-ne v1, v1, :ep_d_thp9wa3w
    goto :ep_s_thp9wa3w
    :ep_d_thp9wa3w
    nop
    :ep_s_thp9wa3w
    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final contains(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    instance-of v0, p1, Ljava/lang/Void;

    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 6
    return v1

    .line 7
    :cond_0
    check-cast p1, Ljava/lang/Void;

    .line 9
    const-string v0, "element"

    .line 11
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 14
    return v1
.end method

.method public final containsAll(Ljava/util/Collection;)Z
    .locals 1

    .line 1
    const-string v0, "elements"

    .line 3
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 9
    move-result p1

    .line 10
    return p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    instance-of v0, p1, Ljava/util/Set;

    if-eqz v0, :cond_0

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_uxqkjt6n
    goto :ep_s_uxqkjt6n
    :ep_d_uxqkjt6n
    nop
    :ep_s_uxqkjt6n
    check-cast p1, Ljava/util/Set;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_4oy875dr
    goto :ep_s_4oy875dr
    :ep_d_4oy875dr
    nop
    :ep_s_4oy875dr
    invoke-interface {p1}, Ljava/util/Set;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final hashCode()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final isEmpty()Z
    .locals 1

    const/4 v0, 0x1

    return v0
.end method

.method public final iterator()Ljava/util/Iterator;
    .locals 1

    sget-object v0, Lyb;->c:Lyb;

    return-object v0
.end method

.method public final remove(Ljava/lang/Object;)Z
    .locals 1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_sfa68jj7
    goto :ep_s_sfa68jj7
    :ep_d_sfa68jj7
    nop
    :ep_s_sfa68jj7
    const-string v0, "Operation is not supported for read-only collection"

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_hx91t6l3
    goto :ep_s_hx91t6l3
    :ep_d_hx91t6l3
    nop
    :ep_s_hx91t6l3
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final removeAll(Ljava/util/Collection;)Z
    .locals 1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_cf8q5abv
    goto :ep_s_cf8q5abv
    :ep_d_cf8q5abv
    nop
    :ep_s_cf8q5abv
    const-string v0, "Operation is not supported for read-only collection"

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_7mf6bnrk
    goto :ep_s_7mf6bnrk
    :ep_d_7mf6bnrk
    nop
    :ep_s_7mf6bnrk
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final retainAll(Ljava/util/Collection;)Z
    .locals 1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_jvtlzfeb
    goto :ep_s_jvtlzfeb
    :ep_d_jvtlzfeb
    nop
    :ep_s_jvtlzfeb
    const-string v0, "Operation is not supported for read-only collection"

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_96bbr13p
    goto :ep_s_96bbr13p
    :ep_d_96bbr13p
    nop
    :ep_s_96bbr13p
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final bridge size()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final toArray()[Ljava/lang/Object;
    .locals 1

    invoke-static {p0}, Lp2;->Y(Ljava/util/Collection;)[Ljava/lang/Object;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_gdazknri
    goto :ep_s_gdazknri
    :ep_d_gdazknri
    nop
    :ep_s_gdazknri
    move-result-object v0

    return-object v0
.end method

.method public final toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)[TT;"
        }
    .end annotation

    const-string v0, "array"

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_ykvuqgu5
    goto :ep_s_ykvuqgu5
    :ep_d_ykvuqgu5
    nop
    :ep_s_ykvuqgu5
    invoke-static {v0, p1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    invoke-static {p0, p1}, Lp2;->Z(Ljava/util/Collection;[Ljava/lang/Object;)[Ljava/lang/Object;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_zvn48qov
    goto :ep_s_zvn48qov
    :ep_d_zvn48qov
    nop
    :ep_s_zvn48qov
    move-result-object p1

    return-object p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    const-string v0, "[]"

    return-object v0
.end method
