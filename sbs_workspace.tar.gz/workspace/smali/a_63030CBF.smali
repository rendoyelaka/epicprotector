.class public final La_63030CBF;
.super Ljava/lang/Object;
.source "silhxvnn.java"
# ep-iequvlplebhu
# compiled-50995
# optimised-94133
# optimised-63474

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    iput-object p1, p0, La_63030CBF;->c:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, La_63030CBF;->c:Landroid/content/Context;

    invoke-static {v0}, La_01B3E3DB;->a(Landroid/content/Context;)V

    return-void
.end method
