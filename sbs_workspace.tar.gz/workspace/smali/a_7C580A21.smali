.class public final La_7C580A21;
.super Ljava/lang/Object;
# ep-qrgcgjufmnxn
# compiled-26941
.source "lhguubhr.java"

# interfaces
.implements La_BDF6D1F0;


# instance fields
.field public final synthetic a:Landroid/animation/Animator;


# direct methods
.method public constructor <init>(Landroid/animation/Animator;)V
    .locals 0

    iput-object p1, p0, La_7C580A21;->a:Landroid/animation/Animator;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCancel()V
    .locals 1

    iget-object v0, p0, La_7C580A21;->a:Landroid/animation/Animator;

    invoke-virtual {v0}, Landroid/animation/Animator;->end()V

    return-void
.end method
