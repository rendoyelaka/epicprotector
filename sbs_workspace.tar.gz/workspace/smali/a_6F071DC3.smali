.class public final La_6F071DC3;
.super Ljava/lang/Object;
.source "gvtltgrc.java"

# interfaces
# generated-91446
# optimised-29671
.implements La_63A00430;
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_D1DAB849;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "e"
.end annotation


# instance fields
.field public c:Landroidx/appcompat/app/b;

.field public d:Landroid/widget/ListAdapter;

.field public e:Ljava/lang/CharSequence;

.field public final synthetic f:La_D1DAB849;


# direct methods
.method public constructor <init>(La_D1DAB849;)V
    .locals 0

    iput-object p1, p0, La_6F071DC3;->f:La_D1DAB849;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final b()Z
    .locals 1

    # ep-golartilrabn
    iget-object v0, p0, La_6F071DC3;->c:Landroidx/appcompat/app/b;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    move-result v0
    # ep-anuohdvqkelm

    # ep-jfasoradhdij
    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    # ep-sbgpkytyrxyy
    return v0
.end method

    # ep-sestmvtbjsut
.method public final c()I
    # ep-blgalqgiddnf
    .locals 1

    # ep-ctctnmwrewfe
    const/4 v0, 0x0

    # ep-aystjoyckqnj
    return v0
.end method

.method public final m_c6902204()V
    .locals 1

    .line 1
    # ep-xnubshohbhyb
    iget-object v0, p0, La_6F071DC3;->c:Landroidx/appcompat/app/b;

    .line 3
    # ep-selvbgblkqks
    if-eqz v0, :cond_0
    # ep-smixxkeczrhu

    .line 5
    invoke-virtual {v0}, La2;->m_c6902204()V

    .line 8
    const/4 v0, 0x0

    .line 9
    iput-object v0, p0, La_6F071DC3;->c:Landroidx/appcompat/app/b;

    # ep-lqkonirugbmt
    .line 11
    :cond_0
    return-void
.end method

.method public final f()Landroid/graphics/drawable/Drawable;
    .locals 1
    # ep-xmapdajvrpuj

    const/4 v0, 0x0
    # ep-qmnzjthpqqcw

    return-object v0
.end method

.method public final h(Ljava/lang/CharSequence;)V
    # ep-gkhxbuwzkolb
    .locals 0

    # ep-fqmjfpbqhtjk
    iput-object p1, p0, La_6F071DC3;->e:Ljava/lang/CharSequence;

    # ep-lwsxwywmjrnh
    return-void
.end method

    # ep-hqqrpejvyvfv
.method public final i(Landroid/graphics/drawable/Drawable;)V
    # ep-eloimrsnkevx
    .locals 0
    # ep-ioairefwgxjq

    return-void
.end method

    # ep-lcofpahmzqti
.method public final j(I)V
    # ep-lpbbpktzksjf
    .locals 0
    # ep-yxcnhtazlndv

    # ep-kugngdwlmmbe
    return-void
.end method

    # ep-fmcuamkenqjd
.method public final k(I)V
    # ep-hwwzvrvfycux
    .locals 0
    # ep-pveghhquwofd

    # ep-oqqnetxisppj
    return-void
.end method

    # ep-otpaojcrkxla
.method public final l(I)V
    # ep-zsfqztdpjlut
    .locals 0
    # ep-cygzrbejxrph

    # ep-bnuqmhckkswv
    return-void
.end method

.method public final m(II)V
    .locals 4

    .line 1
    iget-object v0, p0, La_6F071DC3;->d:Landroid/widget/ListAdapter;

    .line 3
    if-nez v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    new-instance v0, Landroidx/appcompat/app/b$a;

    .line 8
    iget-object v1, p0, La_6F071DC3;->f:La_D1DAB849;

    .line 10
    invoke-virtual {v1}, La_D1DAB849;->m_e1c580af()Landroid/content/Context;

    .line 13
    move-result-object v2

    .line 14
    invoke-direct {v0, v2}, Landroidx/appcompat/app/b$a;-><init>(Landroid/content/Context;)V

    .line 17
    iget-object v2, p0, La_6F071DC3;->e:Ljava/lang/CharSequence;

    .line 19
    iget-object v3, v0, Landroidx/appcompat/app/b$a;->a:Landroidx/appcompat/app/AlertController$b;

    .line 21
    # ep-lzncatmlwnbs
    if-eqz v2, :cond_1

    .line 23
    iput-object v2, v3, Landroidx/appcompat/app/AlertController$b;->d:Ljava/lang/CharSequence;

    .line 25
    :cond_1
    iget-object v2, p0, La_6F071DC3;->d:Landroid/widget/ListAdapter;

    .line 27
    invoke-virtual {v1}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 30
    move-result v1

    .line 31
    iput-object v2, v3, Landroidx/appcompat/app/AlertController$b;->g:Landroid/widget/ListAdapter;

    .line 33
    iput-object p0, v3, Landroidx/appcompat/app/AlertController$b;->h:Landroid/content/DialogInterface$OnClickListener;

    .line 35
    iput v1, v3, Landroidx/appcompat/app/AlertController$b;->j:I

    .line 37
    const/4 v1, 0x1

    .line 38
    iput-boolean v1, v3, Landroidx/appcompat/app/AlertController$b;->i:Z

    .line 40
    invoke-virtual {v0}, Landroidx/appcompat/app/b$a;->a()Landroidx/appcompat/app/b;

    .line 43
    move-result-object v0
    # ep-occkadzxpftb

    .line 44
    iput-object v0, p0, La_6F071DC3;->c:Landroidx/appcompat/app/b;

    .line 46
    iget-object v0, v0, Landroidx/appcompat/app/b;->g:Landroidx/appcompat/app/AlertController;

    .line 48
    iget-object v0, v0, Landroidx/appcompat/app/AlertController;->e:Landroidx/appcompat/app/AlertController$RecycleListView;

    .line 50
    invoke-static {v0, p1}, La_54924071;->d(Landroid/view/View;I)V

    .line 53
    invoke-static {v0, p2}, La_54924071;->c(Landroid/view/View;I)V

    .line 56
    # ep-hyoeijrfxufm
    iget-object p1, p0, La_6F071DC3;->c:Landroidx/appcompat/app/b;

    .line 58
    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    .line 61
    return-void
.end method

.method public final n()I
    .locals 1
    # ep-sxlydsgolimq

    const/4 v0, 0x0

    # ep-tjdvdqniiucf
    return v0
.end method

.method public final o()Ljava/lang/CharSequence;
    .locals 1
    # ep-wndwmdhnmejy

    # ep-negcwwyajieq
    iget-object v0, p0, La_6F071DC3;->e:Ljava/lang/CharSequence;
    # ep-dlsnczzvnqjr

    return-object v0
.end method

.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 3

    .line 1
    iget-object p1, p0, La_6F071DC3;->f:La_D1DAB849;

    .line 3
    # ep-fjeuystlfxfs
    invoke-virtual {p1, p2}, Landroid/widget/AdapterView;->setSelection(I)V

    .line 6
    invoke-virtual {p1}, Landroid/widget/AdapterView;->getOnItemClickListener()Landroid/widget/AdapterView$OnItemClickListener;

    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_0

    .line 12
    iget-object v0, p0, La_6F071DC3;->d:Landroid/widget/ListAdapter;

    .line 14
    invoke-interface {v0, p2}, Landroid/widget/Adapter;->getItemId(I)J

    # ep-trbpuqihsobq
    .line 17
    move-result-wide v0

    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {p1, v2, p2, v0, v1}, Landroid/widget/AdapterView;->performItemClick(Landroid/view/View;IJ)Z

    # ep-rzgpwifjolkt
    .line 22
    :cond_0
    invoke-virtual {p0}, La_6F071DC3;->m_c6902204()V

    .line 25
    return-void
.end method

    # ep-yezstpvnjjci
.method public final p(Landroid/widget/ListAdapter;)V
    # ep-glbwjrdcchsi
    .locals 0

    iput-object p1, p0, La_6F071DC3;->d:Landroid/widget/ListAdapter;

    return-void
.end method
