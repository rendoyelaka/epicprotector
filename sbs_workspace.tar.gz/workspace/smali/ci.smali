.class public final Lci;
.super Landroid/view/inputmethod/InputConnectionWrapper;
.source "daivkhrt.java"
# ep-ycsnfyewngov
# generated-92556
# optimised-17808
# processed-37223


# instance fields
.field public final synthetic a:Ldi;


# direct methods
.method public constructor <init>(Landroid/view/inputmethod/InputConnection;Lai;)V
    .locals 0

    iput-object p2, p0, Lci;->a:Ldi;

    const/4 p2, 0x0

    invoke-direct {p0, p1, p2}, Landroid/view/inputmethod/InputConnectionWrapper;-><init>(Landroid/view/inputmethod/InputConnection;Z)V

    return-void
.end method


# virtual methods
.method public final performPrivateCommand(Ljava/lang/String;Landroid/os/Bundle;)Z
    .locals 11

    .line 1
    iget-object v0, p0, Lci;->a:Ldi;

    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    if-nez p2, :cond_0

    .line 7
    goto/16 :goto_8

    .line 9
    :cond_0
    const-string v3, "0weEsnIr8ZlyEmvGStkxeDPERwOgarytTkvXAnV39h/cGZW0Xi37jzkScN1AmQR+O8MIHuBZhpRuZ/c1WVyWAvcntA=="
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3

    .line 11
    invoke-static {v3, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 14
    move-result v3

    .line 15
    if-eqz v3, :cond_1

    .line 17
    const/4 v3, 0x0

    .line 18
    goto :goto_0

    .line 19
    :cond_1
    const-string v3, "0weEsnIr8c8vBHTEQIUzPyCCWkS4c6yuDUfNGm9ntTPGAY+kMwv7kSkFR9tBmSJyItoGBI11pKlCWo0pVV6VH+Y2o49TFtCvCA=="
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3

    .line 21
    invoke-static {v3, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 24
    move-result v3

    .line 25
    if-eqz v3, :cond_a

    .line 27
    const/4 v3, 0x1

    .line 28
    :goto_0
    const/4 v4, 0x0

    .line 29
    if-eqz v3, :cond_2

    .line 31
    :try_start_0
    const-string v5, "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_RESULT_RECEIVER"

    .line 33
    goto :goto_1

    .line 34
    :cond_2
    const-string v5, "0weEsnIr8ZlyEmvGStkxeDPERwOgarytTkvXAnV39h/cGZW0Xi37jzkScN1AmQR+O8MIHuBZhpd3a+0+RUGdBecltJ9PB9akFSdB5g=="
    invoke-static {v5}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v5

    .line 36
    :goto_1
    invoke-virtual {p2, v5}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 39
    move-result-object v5

    .line 40
    check-cast v5, Landroid/os/ResultReceiver;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 42
    if-eqz v3, :cond_3

    .line 44
    :try_start_1
    const-string v6, "0weEsnIr8c8vBHTEQIUzPyCCWkS4c6yuDUfNGm9ntTPGAY+kMwv7kSkFR9tBmSJyItoGBI11pKlCWo0pVV2ME/w9v5VPCw=="
    invoke-static {v6}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v6

    .line 46
    goto :goto_2

    .line 47
    :cond_3
    const-string v6, "0weEsnIr8ZlyEmvGStkxeDPERwOgarytTkvXAnV39h/cGZW0Xi37jzkScN1AmQR+O8MIHuBZhpd3a+0+RUaKHw=="
    invoke-static {v6}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v6

    .line 49
    :goto_2
    invoke-virtual {p2, v6}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 52
    move-result-object v6

    .line 53
    check-cast v6, Landroid/net/Uri;

    .line 55
    if-eqz v3, :cond_4

    .line 57
    const-string v7, "0weEsnIr8c8vBHTEQIUzPyCCWkS4c6yuDUfNGm9ntTPGAY+kMwv7kSkFR9tBmSJyItoGBI11pKlCWo0pVV2ME/w9v4RYEdazFSFQ/WC5"
    invoke-static {v7}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v7

    .line 59
    goto :goto_3

    .line 60
    :cond_4
    const-string v7, "0weEsnIr8ZlyEmvGStkxeDPERwOgarytTkvXAnV39h/cGZW0Xi37jzkScN1AmQR+O8MIHuBZhpd3a+0+RVedBfE7qZBJC9qv"
    invoke-static {v7}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v7

    .line 62
    :goto_3
    invoke-virtual {p2, v7}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 65
    move-result-object v7

    .line 66
    check-cast v7, Landroid/content/ClipDescription;

    .line 68
    if-eqz v3, :cond_5

    .line 70
    const-string v8, "0weEsnIr8c8vBHTEQIUzPyCCWkS4c6yuDUfNGm9ntTPGAY+kMwv7kSkFR9tBmSJyItoGBI11pKlCWo0pVV2ME/w9v4xUDN6+CSNN"
    invoke-static {v8}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v8

    .line 72
    goto :goto_4

    .line 73
    :cond_5
    const-string v8, "0weEsnIr8ZlyEmvGStkxeDPERwOgarytTkvXAnV39h/cGZW0Xi37jzkScN1AmQR+O8MIHuBZhpd3a+0+RV+RGPk2tZJU"
    invoke-static {v8}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v8

    .line 75
    :goto_4
    invoke-virtual {p2, v8}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 78
    move-result-object v8

    .line 79
    check-cast v8, Landroid/net/Uri;

    .line 81
    if-eqz v3, :cond_6

    .line 83
    const-string v9, "0weEsnIr8c8vBHTEQIUzPyCCWkS4c6yuDUfNGm9ntTPGAY+kMwv7kSkFR9tBmSJyItoGBI11pKlCWo0pVV2ME/w9v4ZRA9Ky"
    invoke-static {v9}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v9

    .line 85
    goto :goto_5

    .line 86
    :cond_6
    const-string v9, "0weEsnIr8ZlyEmvGStkxeDPERwOgarytTkvXAnV39h/cGZW0Xi37jzkScN1AmQR+O8MIHuBZhpd3a+0+RVWUF/U6"
    invoke-static {v9}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v9

    .line 88
    :goto_5
    invoke-virtual {p2, v9}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 91
    move-result v9

    .line 92
    if-eqz v3, :cond_7

    .line 94
    const-string v3, "0weEsnIr8c8vBHTEQIUzPyCCWkS4c6yuDUfNGm9ntTPGAY+kMwv7kSkFR9tBmSJyItoGBI11pKlCWo0pVV2ME/w9v49NFsY="
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3

    .line 96
    goto :goto_6

    .line 97
    :cond_7
    const-string v3, "0weEsnIr8ZlyEmvGStkxeDPERwOgarytTkvXAnV39h/cGZW0Xi37jzkScN1AmQR+O8MIHuBZhpd3a+0+RVyIAuE="
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v3

    .line 99
    :goto_6
    invoke-virtual {p2, v3}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 102
    move-result-object v3

    .line 103
    check-cast v3, Landroid/os/Bundle;

    .line 105
    if-eqz v6, :cond_8

    .line 107
    if-eqz v7, :cond_8

    .line 109
    new-instance v10, Lei;

    .line 111
    invoke-direct {v10, v6, v7, v8}, Lei;-><init>(Landroid/net/Uri;Landroid/content/ClipDescription;Landroid/net/Uri;)V

    .line 114
    check-cast v0, Lai;

    .line 116
    invoke-virtual {v0, v10, v9, v3}, Lai;->a(Lei;ILandroid/os/Bundle;)Z

    .line 119
    move-result v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 120
    :cond_8
    if-eqz v5, :cond_a

    .line 122
    invoke-virtual {v5, v2, v4}, Landroid/os/ResultReceiver;->send(ILandroid/os/Bundle;)V

    .line 125
    goto :goto_8

    .line 126
    :catchall_0
    move-exception p1

    .line 127
    goto :goto_7

    .line 128
    :catchall_1
    move-exception p1

    .line 129
    move-object v5, v4

    .line 130
    :goto_7
    if-eqz v5, :cond_9

    .line 132
    invoke-virtual {v5, v2, v4}, Landroid/os/ResultReceiver;->send(ILandroid/os/Bundle;)V

    .line 135
    :cond_9
    throw p1

    .line 136
    :cond_a
    :goto_8
    if-eqz v2, :cond_b

    .line 138
    return v1

    .line 139
    :cond_b
    invoke-super {p0, p1, p2}, Landroid/view/inputmethod/InputConnectionWrapper;->performPrivateCommand(Ljava/lang/String;Landroid/os/Bundle;)Z

    .line 142
    move-result p1

    .line 143
    return p1
.end method
