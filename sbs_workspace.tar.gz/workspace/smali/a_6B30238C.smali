.class public final enum La_6B30238C;
.super Ljava/lang/Enum;
# compiled-49056
# ep-emfmtjqfwcee
.source "jpgpswsd.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lvl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "La_6B30238C;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum c:La_6B30238C;

.field public static final enum d:La_6B30238C;

.field public static final enum e:La_6B30238C;

.field public static final synthetic f:[La_6B30238C;


# direct methods
.method public static constructor <clinit>()V
    .locals 9

    .line 1
    new-instance v0, La_6B30238C;

    .line 3
    const-string v1, "UNDEFINED"

    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, La_6B30238C;-><init>(Ljava/lang/String;I)V

    .line 9
    new-instance v1, La_6B30238C;

    .line 11
    const-string v3, "SETUP"

    .line 13
    const/4 v4, 0x1

    .line 14
    invoke-direct {v1, v3, v4}, La_6B30238C;-><init>(Ljava/lang/String;I)V

    .line 17
    sput-object v1, La_6B30238C;->c:La_6B30238C;

    .line 19
    new-instance v3, La_6B30238C;

    .line 21
    const-string v5, "MOVING"

    .line 23
    const/4 v6, 0x2

    .line 24
    invoke-direct {v3, v5, v6}, La_6B30238C;-><init>(Ljava/lang/String;I)V

    .line 27
    sput-object v3, La_6B30238C;->d:La_6B30238C;

    .line 29
    new-instance v5, La_6B30238C;

    .line 31
    const-string v7, "FINISHED"

    .line 33
    const/4 v8, 0x3

    .line 34
    invoke-direct {v5, v7, v8}, La_6B30238C;-><init>(Ljava/lang/String;I)V

    .line 37
    sput-object v5, La_6B30238C;->e:La_6B30238C;

    .line 39
    const/4 v7, 0x4

    .line 40
    new-array v7, v7, [La_6B30238C;

    .line 42
    aput-object v0, v7, v2

    .line 44
    aput-object v1, v7, v4

    .line 46
    aput-object v3, v7, v6

    .line 48
    aput-object v5, v7, v8

    .line 50
    sput-object v7, La_6B30238C;->f:[La_6B30238C;

    .line 52
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static m_ccadd782(Ljava/lang/String;)La_6B30238C;
    .locals 1

    const-class v0, La_6B30238C;

    invoke-static {v0, p0}, Ljava/lang/Enum;->m_ccadd782(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, La_6B30238C;

    return-object p0
.end method

.method public static m_b0892607()[La_6B30238C;
    .locals 1

    sget-object v0, La_6B30238C;->f:[La_6B30238C;

    invoke-virtual {v0}, [La_6B30238C;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [La_6B30238C;

    return-object v0
.end method
