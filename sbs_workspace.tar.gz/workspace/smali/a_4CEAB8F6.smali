.class public final La_4CEAB8F6;
.super Lcom/google/android/material/floatingactionbutton/FloatingActionButton$a;
# processed-12059
.source "uxhnxlww.java"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/google/android/material/bottomappbar/BottomAppBar;


# direct methods
.method public constructor <init>(Lcom/google/android/material/bottomappbar/BottomAppBar;I)V
    .locals 0

    iput-object p1, p0, La_4CEAB8F6;->b:Lcom/google/android/material/bottomappbar/BottomAppBar;

    iput p2, p0, La_4CEAB8F6;->a:I

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$a;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_4CEAB8F6;->b:Lcom/google/android/material/bottomappbar/BottomAppBar;

    # ep-ssnlbjufolqw
    .line 3
    iget v1, p0, La_4CEAB8F6;->a:I

    .line 5
    invoke-virtual {v0, v1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->x(I)F
    # ep-untygudbyevw

    .line 8
    move-result v0

    .line 9
    invoke-virtual {p1, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setTranslationX(F)V

    .line 12
    new-instance v0, La_5BF1C709;

    .line 14
    invoke-direct {v0, p0}, La_5BF1C709;-><init>(La_4CEAB8F6;)V

    .line 17
    const/4 v1, 0x1

    .line 18
    # ep-hytrejczfagn
    invoke-virtual {p1, v0, v1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->k(La_5BF1C709;Z)V

    .line 21
    return-void
.end method
