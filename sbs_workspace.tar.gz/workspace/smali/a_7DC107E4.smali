.class public final La_7DC107E4;
.super La_B567B431;
.source "zjaepupv.java"

# ep-wyoaykfdylzu
# processed-48676
# processed-67714
# optimised-52980

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lwz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# static fields
.field public static e:Ljava/lang/reflect/Field;

.field public static f:Z

.field public static g:Ljava/lang/reflect/Constructor;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/reflect/Constructor<",
            "Landroid/view/WindowInsets;",
            ">;"
        }
    .end annotation
.end field

.field public static h:Z


# instance fields
.field public c:Landroid/view/WindowInsets;

.field public d:Lii;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, La_B567B431;-><init>()V

    .line 2
    invoke-static {}, La_7DC107E4;->i()Landroid/view/WindowInsets;

    move-result-object v0

    iput-object v0, p0, La_7DC107E4;->c:Landroid/view/WindowInsets;

    return-void
.end method

.method public constructor <init>(Lwz;)V
    .locals 0

    .line 3
    invoke-direct {p0, p1}, La_B567B431;-><init>(Lwz;)V

    .line 4
    invoke-virtual {p1}, Lwz;->g()Landroid/view/WindowInsets;

    move-result-object p1

    iput-object p1, p0, La_7DC107E4;->c:Landroid/view/WindowInsets;

    return-void
.end method

.method private static i()Landroid/view/WindowInsets;
    .locals 6

    .line 1
    sget-boolean v0, La_7DC107E4;->f:Z

    .line 3
    const-class v1, Landroid/view/WindowInsets;

    .line 5
    const/4 v2, 0x1

    .line 6
    if-nez v0, :cond_0

    .line 8
    :try_start_0
    const-string v0, "CONSUMED"

    .line 10
    invoke-virtual {v1, v0}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 13
    move-result-object v0

    .line 14
    sput-object v0, La_7DC107E4;->e:Ljava/lang/reflect/Field;
    :try_end_0
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_0 .. :try_end_0} :catch_0

    .line 16
    :catch_0
    sput-boolean v2, La_7DC107E4;->f:Z

    .line 18
    :cond_0
    sget-object v0, La_7DC107E4;->e:Ljava/lang/reflect/Field;

    .line 20
    const/4 v3, 0x0

    .line 21
    if-eqz v0, :cond_1

    .line 23
    :try_start_1
    invoke-virtual {v0, v3}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Landroid/view/WindowInsets;

    .line 29
    if-eqz v0, :cond_1

    .line 31
    new-instance v4, Landroid/view/WindowInsets;

    .line 33
    invoke-direct {v4, v0}, Landroid/view/WindowInsets;-><init>(Landroid/view/WindowInsets;)V
    :try_end_1
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_1 .. :try_end_1} :catch_1

    .line 36
    return-object v4

    .line 37
    :catch_1
    nop

    .line 38
    :cond_1
    sget-boolean v0, La_7DC107E4;->h:Z

    .line 40
    const/4 v4, 0x0

    .line 41
    if-nez v0, :cond_2

    .line 43
    :try_start_2
    new-array v0, v2, [Ljava/lang/Class;

    .line 45
    const-class v5, Landroid/graphics/Rect;

    .line 47
    aput-object v5, v0, v4

    .line 49
    invoke-virtual {v1, v0}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 52
    move-result-object v0

    .line 53
    sput-object v0, La_7DC107E4;->g:Ljava/lang/reflect/Constructor;
    :try_end_2
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_2 .. :try_end_2} :catch_2

    .line 55
    :catch_2
    sput-boolean v2, La_7DC107E4;->h:Z

    .line 57
    :cond_2
    sget-object v0, La_7DC107E4;->g:Ljava/lang/reflect/Constructor;

    .line 59
    if-eqz v0, :cond_3

    .line 61
    :try_start_3
    new-array v1, v2, [Ljava/lang/Object;

    .line 63
    new-instance v2, Landroid/graphics/Rect;

    .line 65
    invoke-direct {v2}, Landroid/graphics/Rect;-><init>()V

    .line 68
    aput-object v2, v1, v4

    .line 70
    invoke-virtual {v0, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 73
    move-result-object v0

    .line 74
    check-cast v0, Landroid/view/WindowInsets;
    :try_end_3
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_3 .. :try_end_3} :catch_3

    .line 76
    return-object v0

    .line 77
    :catch_3
    :cond_3
    return-object v3
.end method


# virtual methods
.method public b()Lwz;
    .locals 3

    .line 1
    invoke-virtual {p0}, La_B567B431;->a()V

    .line 4
    iget-object v0, p0, La_7DC107E4;->c:Landroid/view/WindowInsets;

    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-static {v1, v0}, Lwz;->h(Landroid/view/View;Landroid/view/WindowInsets;)Lwz;

    .line 10
    move-result-object v0

    .line 11
    iget-object v1, p0, La_B567B431;->b:[Lii;

    .line 13
    iget-object v2, v0, Lwz;->a:La_A4B4F578;

    .line 15
    invoke-virtual {v2, v1}, La_A4B4F578;->o([Lii;)V

    .line 18
    iget-object v1, p0, La_7DC107E4;->d:Lii;

    .line 20
    invoke-virtual {v2, v1}, La_A4B4F578;->q(Lii;)V

    .line 23
    return-object v0
.end method

.method public e(Lii;)V
    .locals 0

    iput-object p1, p0, La_7DC107E4;->d:Lii;

    return-void
.end method

.method public g(Lii;)V
    .locals 4

    .line 1
    iget-object v0, p0, La_7DC107E4;->c:Landroid/view/WindowInsets;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget v1, p1, Lii;->a:I

    .line 7
    iget v2, p1, Lii;->c:I

    .line 9
    iget v3, p1, Lii;->d:I

    .line 11
    iget p1, p1, Lii;->b:I

    .line 13
    invoke-virtual {v0, v1, p1, v2, v3}, Landroid/view/WindowInsets;->replaceSystemWindowInsets(IIII)Landroid/view/WindowInsets;

    .line 16
    move-result-object p1

    .line 17
    iput-object p1, p0, La_7DC107E4;->c:Landroid/view/WindowInsets;

    .line 19
    :cond_0
    return-void
.end method
