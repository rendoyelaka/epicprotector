.class public abstract La_81459626;
.super Ljava/lang/Object;
.source "ojunabzn.java"
# optimised-17083
# generated-81995
# generated-92409


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_68DC2F48;
    }
.end annotation


# instance fields
.field public final a:Ljava/util/UUID;

.field public final b:La_E68A2DEE;

.field public final c:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/UUID;La_E68A2DEE;Ljava/util/HashSet;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_81459626;->a:Ljava/util/UUID;

    .line 6
    iput-object p2, p0, La_81459626;->b:La_E68A2DEE;

    .line 8
    iput-object p3, p0, La_81459626;->c:Ljava/util/Set;

    .line 10
    return-void
.end method
