.class public final La_4677B5FE;
.super Landroid/content/BroadcastReceiver;
.source "hhqavxrs.java"


# compiled-12785
# optimised-25463
# validated-69751
# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_62C040A3;->e()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_62C040A3;


# direct methods
.method public constructor <init>(La_62C040A3;)V
    .locals 0

    iput-object p1, p0, La_4677B5FE;->a:La_62C040A3;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0

    iget-object p1, p0, La_4677B5FE;->a:La_62C040A3;
    # ep-waulnmjlkyal

    # ep-gadebyumswng
    invoke-virtual {p1}, La_62C040A3;->d()V

    return-void
.end method
