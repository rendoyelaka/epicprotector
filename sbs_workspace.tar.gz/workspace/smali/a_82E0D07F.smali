.class public final La_82E0D07F;
.super Landroid/animation/AnimatorListenerAdapter;
.source "dzqmxatx.java"
# ep-txizibhbkmxm

# compiled-27500
# generated-85215
# compiled-28540

# instance fields
.field public final synthetic a:La_814939E8;


# direct methods
.method public constructor <init>(La_814939E8;)V
    .locals 0

    iput-object p1, p0, La_82E0D07F;->a:La_814939E8;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationStart(Landroid/animation/Animator;)V
    .locals 1

    iget-object p1, p0, La_82E0D07F;->a:La_814939E8;

    iget-object p1, p1, Lcc;->b:Lcom/google/android/material/textfield/a;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Lcom/google/android/material/textfield/a;->g(Z)V

    return-void
.end method
