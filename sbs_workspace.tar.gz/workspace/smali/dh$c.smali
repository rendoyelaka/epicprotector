.class public final Ldh$c;
.super Lq3;
.source "touiqcnj.java"
# generated-50601
# verified-30176
# optimised-42838

# ep-sdbflsxrmyjh

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ldh;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "c"
.end annotation


# instance fields
.field public final synthetic k:Ldh;


# direct methods
.method public constructor <init>(Ldh;)V
    .locals 0

    iput-object p1, p0, Ldh$c;->k:Ldh;

    invoke-direct {p0}, Lq3;-><init>()V

    return-void
.end method


# virtual methods
.method public final n(Ljava/io/IOException;)Ljava/io/IOException;
    .locals 2

    .line 1
    new-instance v0, Ljava/net/SocketTimeoutException;

    .line 3
    const-string v1, "WQiobY4j9Q=="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 5
    invoke-direct {v0, v1}, Ljava/net/SocketTimeoutException;-><init>(Ljava/lang/String;)V

    .line 8
    if-eqz p1, :cond_0

    .line 10
    invoke-virtual {v0, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 13
    :cond_0
    return-object v0
.end method

.method public final o()V
    .locals 3

    .line 1
    iget-object v0, p0, Ldh$c;->k:Ldh;

    .line 3
    const/4 v1, 0x6

    .line 4
    invoke-virtual {v0, v1}, Ldh;->d(I)Z

    .line 7
    move-result v2

    .line 8
    if-nez v2, :cond_0

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-object v2, v0, Ldh;->d:LHttp2Connection;

    .line 13
    iget v0, v0, Ldh;->c:I

    .line 15
    invoke-virtual {v2, v0, v1}, LHttp2Connection;->v(II)V

    .line 18
    :goto_0
    return-void
.end method

.method public final p()V
    .locals 1

    invoke-virtual {p0}, Lq3;->m()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ldh$c;->n(Ljava/io/IOException;)Ljava/io/IOException;

    move-result-object v0

    throw v0
.end method
