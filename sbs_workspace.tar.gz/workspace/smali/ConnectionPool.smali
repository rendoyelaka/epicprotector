.class public final LConnectionPool;
.super Ljava/lang/Object;
.source "rxjfkumj.java"
# ep-jlmfhfdqtskl
# generated-18589
# verified-96202
# compiled-87225


# static fields
.field public static final g:Ljava/util/concurrent/ThreadPoolExecutor;


# instance fields
.field public final a:I

.field public final b:J

.field public final c:LConnectionPool$a;

.field public final d:Ljava/util/ArrayDeque;

.field public final e:Lbj;

.field public f:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 10

    .line 1
    new-instance v8, Ljava/util/concurrent/ThreadPoolExecutor;

    .line 3
    const/4 v1, 0x0

    .line 4
    const v2, 0x7fffffff

    .line 7
    const-wide/16 v3, 0x3c

    .line 9
    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 11
    new-instance v6, Ljava/util/concurrent/SynchronousQueue;

    .line 13
    invoke-direct {v6}, Ljava/util/concurrent/SynchronousQueue;-><init>()V

    .line 16
    sget-object v0, Lex;->a:[B

    .line 18
    new-instance v7, Lcx;

    .line 20
    const-string v0, "OkHttp ConnectionPool"

    .line 22
    const/4 v9, 0x1

    .line 23
    invoke-direct {v7, v0, v9}, Lcx;-><init>(Ljava/lang/String;Z)V

    .line 26
    move-object v0, v8

    .line 27
    invoke-direct/range {v0 .. v7}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    .line 30
    sput-object v8, LConnectionPool;->g:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 32
    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .line 1
    sget-object v0, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    new-instance v1, LConnectionPool$a;

    .line 8
    invoke-direct {v1, p0}, LConnectionPool$a;-><init>(LConnectionPool;)V

    .line 11
    iput-object v1, p0, LConnectionPool;->c:LConnectionPool$a;

    .line 13
    new-instance v1, Ljava/util/ArrayDeque;

    .line 15
    invoke-direct {v1}, Ljava/util/ArrayDeque;-><init>()V

    .line 18
    iput-object v1, p0, LConnectionPool;->d:Ljava/util/ArrayDeque;

    .line 20
    new-instance v1, Lbj;

    .line 22
    const/4 v2, 0x5

    .line 23
    invoke-direct {v1, v2}, Lbj;-><init>(I)V

    .line 26
    iput-object v1, p0, LConnectionPool;->e:Lbj;

    .line 28
    iput v2, p0, LConnectionPool;->a:I

    .line 30
    const-wide/16 v1, 0x5

    .line 32
    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    .line 35
    move-result-wide v0

    .line 36
    iput-wide v0, p0, LConnectionPool;->b:J

    .line 38
    return-void
.end method


# virtual methods
.method public final a(J)J
    .locals 11

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, LConnectionPool;->d:Ljava/util/ArrayDeque;

    .line 4
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->iterator()Ljava/util/Iterator;

    .line 7
    move-result-object v0

    .line 8
    const/4 v1, 0x0

    .line 9
    const/4 v2, 0x0

    .line 10
    const-wide/high16 v3, -0x8000000000000000L

    .line 12
    const/4 v5, 0x0

    .line 13
    const/4 v6, 0x0

    .line 14
    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    move-result v7

    .line 18
    if-eqz v7, :cond_2

    .line 20
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    move-result-object v7

    .line 24
    check-cast v7, Lep;

    .line 26
    invoke-virtual {p0, v7, p1, p2}, LConnectionPool;->b(Lep;J)I

    .line 29
    move-result v8

    .line 30
    if-lez v8, :cond_1

    .line 32
    add-int/lit8 v6, v6, 0x1

    .line 34
    goto :goto_0

    .line 35
    :cond_1
    add-int/lit8 v5, v5, 0x1

    .line 37
    iget-wide v8, v7, Lep;->n:J

    .line 39
    sub-long v8, p1, v8

    .line 41
    cmp-long v10, v8, v3

    .line 43
    if-lez v10, :cond_0

    .line 45
    move-object v2, v7

    .line 46
    move-wide v3, v8

    .line 47
    goto :goto_0

    .line 48
    :cond_2
    iget-wide p1, p0, LConnectionPool;->b:J

    .line 50
    cmp-long v0, v3, p1

    .line 52
    if-gez v0, :cond_6

    .line 54
    iget v0, p0, LConnectionPool;->a:I

    .line 56
    if-le v5, v0, :cond_3

    .line 58
    goto :goto_1

    .line 59
    :cond_3
    if-lez v5, :cond_4

    .line 61
    sub-long/2addr p1, v3

    .line 62
    monitor-exit p0

    .line 63
    return-wide p1

    .line 64
    :cond_4
    if-lez v6, :cond_5

    .line 66
    monitor-exit p0

    .line 67
    return-wide p1

    .line 68
    :cond_5
    iput-boolean v1, p0, LConnectionPool;->f:Z

    .line 70
    monitor-exit p0

    .line 71
    const-wide/16 p1, -0x1

    .line 73
    return-wide p1

    .line 74
    :cond_6
    :goto_1
    iget-object p1, p0, LConnectionPool;->d:Ljava/util/ArrayDeque;

    .line 76
    invoke-virtual {p1, v2}, Ljava/util/ArrayDeque;->remove(Ljava/lang/Object;)Z

    .line 79
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 80
    iget-object p1, v2, Lep;->d:Ljava/net/Socket;

    .line 82
    invoke-static {p1}, Lex;->b(Ljava/net/Socket;)V

    .line 85
    const-wide/16 p1, 0x0

    .line 87
    return-wide p1

    .line 88
    :catchall_0
    move-exception p1

    .line 89
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 90
    throw p1
.end method

.method public final b(Lep;J)I
    .locals 6

    .line 1
    iget-object v0, p1, Lep;->l:Ljava/util/ArrayList;

    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    :cond_0
    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 8
    move-result v3

    .line 9
    if-ge v2, v3, :cond_2

    .line 11
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 14
    move-result-object v3

    .line 15
    check-cast v3, Ljava/lang/ref/Reference;

    .line 17
    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 20
    move-result-object v4

    .line 21
    if-eqz v4, :cond_1

    .line 23
    add-int/lit8 v2, v2, 0x1

    .line 25
    goto :goto_0

    .line 26
    :cond_1
    check-cast v3, Lft$a;

    .line 28
    new-instance v4, Ljava/lang/StringBuilder;

    .line 30
    const-string v5, "A connection to "

    .line 32
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 35
    iget-object v5, p1, Lep;->b:Lpq;

    .line 37
    iget-object v5, v5, Lpq;->a:Lq0;

    .line 39
    iget-object v5, v5, Lq0;->a:Lih;

    .line 41
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 44
    const-string v5, " was leaked. Did you forget to close a response body?"

    .line 46
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 52
    move-result-object v4

    .line 53
    sget-object v5, Lfo;->a:Lfo;

    .line 55
    iget-object v3, v3, Lft$a;->a:Ljava/lang/Object;

    .line 57
    invoke-virtual {v5, v4, v3}, Lfo;->j(Ljava/lang/String;Ljava/lang/Object;)V

    .line 60
    invoke-interface {v0, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 63
    const/4 v3, 0x1

    .line 64
    iput-boolean v3, p1, Lep;->m:Z

    .line 66
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 69
    move-result v3

    .line 70
    if-eqz v3, :cond_0

    .line 72
    iget-wide v2, p0, LConnectionPool;->b:J

    .line 74
    sub-long/2addr p2, v2

    .line 75
    iput-wide p2, p1, Lep;->n:J

    .line 77
    return v1

    .line 78
    :cond_2
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 81
    move-result p1

    .line 82
    return p1
.end method
