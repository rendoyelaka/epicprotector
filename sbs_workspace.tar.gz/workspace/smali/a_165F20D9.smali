.class public final La_165F20D9;
.super Ljava/lang/Object;
# generated-42000
# optimised-71224
# verified-75187
.source "ojqizbvs.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_FF9541AC;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/view/ViewTreeObserver;Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V
    # ep-nevleysnjrqj
    .locals 0
    # ep-ijihjttdctro

    invoke-virtual {p0, p1}, Landroid/view/ViewTreeObserver;->removeOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V
    # ep-hxyghpqcjzjn

    # ep-dzlnuyzddusj
    return-void
.end method
