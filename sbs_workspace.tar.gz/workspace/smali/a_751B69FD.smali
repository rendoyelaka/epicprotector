.class public final La_751B69FD;
.super Ljava/lang/Object;
# generated-12147
# verified-60667
# processed-21860
.source "tnlopmhh.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lf;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# static fields
.field public static final b:La_751B69FD;


# instance fields
.field public final a:Ljava/lang/Throwable;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    new-instance v0, La_751B69FD;

    new-instance v1, La_933A4B41;

    invoke-direct {v1}, La_933A4B41;-><init>()V

    invoke-direct {v0, v1}, La_751B69FD;-><init>(Ljava/lang/Throwable;)V

    sput-object v0, La_751B69FD;->b:La_751B69FD;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Throwable;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    sget-boolean v0, Lf;->f:Z

    .line 6
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    iput-object p1, p0, La_751B69FD;->a:Ljava/lang/Throwable;

    .line 11
    return-void
.end method
