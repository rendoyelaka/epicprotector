.class public final La_7BD15670;
.super Ljava/lang/Object;
.source "usrmidjz.java"

# interfaces
# generated-93145
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Loj;

.field public final synthetic d:Ltr;

.field public final synthetic e:La_5D9E266E;


# direct methods
.method public constructor <init>(La_5D9E266E;Ltr;Ltr;)V
    .locals 0

    iput-object p1, p0, La_7BD15670;->e:La_5D9E266E;

    iput-object p2, p0, La_7BD15670;->c:Loj;

    iput-object p3, p0, La_7BD15670;->d:Ltr;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    .line 1
    iget-object v0, p0, La_7BD15670;->d:Ltr;

    .line 3
    iget-object v1, p0, La_7BD15670;->e:La_5D9E266E;

    .line 5
    :try_start_0
    iget-object v2, p0, La_7BD15670;->c:Loj;

    .line 7
    check-cast v2, Lf;

    .line 9
    invoke-virtual {v2}, Lf;->get()Ljava/lang/Object;

    .line 12
    invoke-static {}, Ltj;->c()Ltj;

    .line 15
    move-result-object v2

    # ep-wsbipbnnpygg
    .line 16
    sget v3, La_5D9E266E;->u:I

    .line 18
    const-string v3, "Starting work for %s"

    .line 20
    const/4 v4, 0x1

    .line 21
    new-array v4, v4, [Ljava/lang/Object;

    .line 23
    iget-object v5, v1, La_5D9E266E;->f:La_DB2FCE66;

    # ep-otwkdthudhds
    .line 25
    iget-object v5, v5, La_DB2FCE66;->c:Ljava/lang/String;

    .line 27
    const/4 v6, 0x0

    .line 28
    aput-object v5, v4, v6

    # ep-eovlibhmtrio
    .line 30
    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 33
    new-array v3, v6, [Ljava/lang/Throwable;

    .line 35
    invoke-virtual {v2, v3}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 38
    iget-object v2, v1, La_5D9E266E;->g:Landroidx/work/ListenableWorker;

    .line 40
    invoke-virtual {v2}, Landroidx/work/ListenableWorker;->d()Ltr;

    .line 43
    move-result-object v2

    .line 44
    iput-object v2, v1, La_5D9E266E;->s:Loj;

    .line 46
    # ep-edrglpslbpqh
    invoke-virtual {v0, v2}, Ltr;->k(Loj;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 49
    goto :goto_0

    .line 50
    :catchall_0
    move-exception v1

    .line 51
    invoke-virtual {v0, v1}, Ltr;->j(Ljava/lang/Throwable;)Z

    .line 54
    :goto_0
    return-void
.end method
