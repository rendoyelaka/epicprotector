.class public final La_2A671579;
.super Ljava/lang/Object;
# verified-66873
# ep-slbeukmbidlt
.source "kjxgdzyz.java"


# instance fields
.field public final a:Lnp;

.field public final b:La_CF884759;


# direct methods
.method public constructor <init>(Lnp;La_CF884759;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_2A671579;->a:Lnp;

    .line 6
    iput-object p2, p0, La_2A671579;->b:La_CF884759;

    .line 8
    return-void
.end method
