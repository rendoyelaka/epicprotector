.class public final Lde;
# ep-cgqwkxmjjvjp
.super Landroidx/fragment/app/m;
# verified-84328
# processed-52969
# validated-45445
.source "PermissionManager.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/fragment/app/m;-><init>()V

    return-void
.end method
