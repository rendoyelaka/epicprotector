.class public final La_0D507467;
.super Ljava/lang/Object;
# ep-ddogsifwgcxv
.source "rvzrubnh.java"

# optimised-60109
# interfaces
.implements La_0678B093;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lu1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "c"
.end annotation


# instance fields
.field public final a:La_0678B093;

.field public final synthetic b:Lu1;


# direct methods
.method public constructor <init>(Lu1;La_A84D5446;)V
    .locals 0

    .line 1
    iput-object p1, p0, La_0D507467;->b:Lu1;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p2, p0, La_0D507467;->a:La_0678B093;

    .line 8
    return-void
.end method


# virtual methods
.method public final a(La_E1261EED;Landroid/view/MenuItem;)Z
    .locals 1

    iget-object v0, p0, La_0D507467;->a:La_0678B093;

    invoke-interface {v0, p1, p2}, La_0678B093;->a(La_E1261EED;Landroid/view/MenuItem;)Z

    move-result p1

    return p1
.end method

.method public final b(La_E1261EED;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_0D507467;->a:La_0678B093;

    .line 3
    invoke-interface {v0, p1}, La_0678B093;->b(La_E1261EED;)V

    .line 6
    iget-object p1, p0, La_0D507467;->b:Lu1;

    .line 8
    iget-object v0, p1, Lu1;->r:Landroid/widget/PopupWindow;

    .line 10
    if-eqz v0, :cond_0

    .line 12
    iget-object v0, p1, Lu1;->g:Landroid/view/Window;

    .line 14
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 17
    move-result-object v0

    .line 18
    iget-object v1, p1, Lu1;->s:La_2914A712;

    .line 20
    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 23
    :cond_0
    iget-object v0, p1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 25
    if-eqz v0, :cond_2

    .line 27
    iget-object v0, p1, Lu1;->t:Lky;

    .line 29
    if-eqz v0, :cond_1

    .line 31
    invoke-virtual {v0}, Lky;->b()V

    .line 34
    :cond_1
    iget-object v0, p1, Lu1;->q:Landroidx/appcompat/widget/ActionBarContextView;

    .line 36
    invoke-static {v0}, Lqx;->a(Landroid/view/View;)Lky;

    .line 39
    move-result-object v0

    .line 40
    const/4 v1, 0x0

    .line 41
    invoke-virtual {v0, v1}, Lky;->a(F)V

    .line 44
    iput-object v0, p1, Lu1;->t:Lky;

    .line 46
    new-instance v1, La_BB2FCEF2;

    .line 48
    invoke-direct {v1, p0}, La_BB2FCEF2;-><init>(La_0D507467;)V

    .line 51
    invoke-virtual {v0, v1}, Lky;->d(Lmy;)V

    .line 54
    :cond_2
    iget-object v0, p1, Lu1;->i:La_9668AE1D;

    .line 56
    if-eqz v0, :cond_3

    .line 58
    invoke-interface {v0}, La_9668AE1D;->e()V

    .line 61
    :cond_3
    const/4 v0, 0x0

    .line 62
    iput-object v0, p1, Lu1;->p:La_E1261EED;

    .line 64
    iget-object p1, p1, Lu1;->w:Landroid/view/ViewGroup;

    .line 66
    sget-object v0, Lqx;->a:Ljava/util/WeakHashMap;

    .line 68
    invoke-static {p1}, La_0449D4C3;->c(Landroid/view/View;)V

    .line 71
    return-void
.end method

.method public final c(La_E1261EED;Landroidx/appcompat/view/menu/f;)Z
    .locals 2

    .line 1
    iget-object v0, p0, La_0D507467;->b:Lu1;

    .line 3
    iget-object v0, v0, Lu1;->w:Landroid/view/ViewGroup;

    .line 5
    sget-object v1, Lqx;->a:Ljava/util/WeakHashMap;

    .line 7
    invoke-static {v0}, La_0449D4C3;->c(Landroid/view/View;)V

    .line 10
    iget-object v0, p0, La_0D507467;->a:La_0678B093;

    .line 12
    invoke-interface {v0, p1, p2}, La_0678B093;->c(La_E1261EED;Landroidx/appcompat/view/menu/f;)Z

    .line 15
    move-result p1

    .line 16
    return p1
.end method

.method public final d(La_E1261EED;Landroidx/appcompat/view/menu/f;)Z
    .locals 1

    iget-object v0, p0, La_0D507467;->a:La_0678B093;

    invoke-interface {v0, p1, p2}, La_0678B093;->d(La_E1261EED;Landroidx/appcompat/view/menu/f;)Z

    move-result p1

    return p1
.end method
