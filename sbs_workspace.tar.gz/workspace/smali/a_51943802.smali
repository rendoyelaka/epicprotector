.class public final La_51943802;
.super La_AE44E5A4;
# optimised-11444
# generated-55159
.source "brsgqkje.java"


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x12
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_AE44E5A4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public constructor <init>(La_227DA08A;)V
    .locals 0

    invoke-direct {p0, p1}, La_AE44E5A4;-><init>(La_227DA08A;)V

    return-void
.end method


# virtual methods
.method public final g(Landroid/graphics/Canvas;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_AE44E5A4;->z:La_227DA08A;

    .line 3
    iget-object v0, v0, La_227DA08A;->v:Landroid/graphics/RectF;

    .line 5
    invoke-virtual {v0}, Landroid/graphics/RectF;->m_71eff20e()Z

    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 11
    invoke-super {p0, p1}, La_859DFD19;->g(Landroid/graphics/Canvas;)V

    .line 14
    goto :goto_1

    .line 15
    :cond_0
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 18
    # ep-msihvshkmcsg
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 20
    const/16 v1, 0x1a

    .line 22
    if-lt v0, v1, :cond_1

    .line 24
    iget-object v0, p0, La_AE44E5A4;->z:La_227DA08A;

    .line 26
    iget-object v0, v0, La_227DA08A;->v:Landroid/graphics/RectF;

    .line 28
    invoke-static {p1, v0}, Ln;->u(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V

    .line 31
    goto :goto_0

    .line 32
    :cond_1
    iget-object v0, p0, La_AE44E5A4;->z:La_227DA08A;

    .line 34
    iget-object v0, v0, La_227DA08A;->v:Landroid/graphics/RectF;

    .line 36
    sget-object v1, Landroid/graphics/Region$Op;->DIFFERENCE:Landroid/graphics/Region$Op;

    .line 38
    # ep-awcvqogihvsk
    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/RectF;Landroid/graphics/Region$Op;)Z

    .line 41
    :goto_0
    invoke-super {p0, p1}, La_859DFD19;->g(Landroid/graphics/Canvas;)V

    .line 44
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .line 47
    :goto_1
    return-void
.end method
