.class public La_18EF3B18;
.super Landroid/widget/TextView;
# validated-28313
# validated-21542
# ep-rbawdahddodz
.source "qxjjrjwp.java"

# interfaces
.implements Lov;
.implements La_AB6A81EE;


# instance fields
.field public final c:La_0D850CD8;

.field public final d:La_1CAFA37F;

.field public final e:La_BC92C3B9;

.field public f:La_BB55952C;

.field public g:Z

.field public h:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "Lmo;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    const v0, 0x1010084

    .line 1
    invoke-direct {p0, p1, p2, v0}, La_18EF3B18;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    .line 2
    invoke-static {p1}, Ljv;->a(Landroid/content/Context;)V

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 p1, 0x0

    .line 3
    iput-boolean p1, p0, La_18EF3B18;->g:Z

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    move-result-object p1

    invoke-static {p0, p1}, Lav;->a(Landroid/view/View;Landroid/content/Context;)V

    .line 5
    new-instance p1, La_0D850CD8;

    invoke-direct {p1, p0}, La_0D850CD8;-><init>(Landroid/view/View;)V

    iput-object p1, p0, La_18EF3B18;->c:La_0D850CD8;

    .line 6
    invoke-virtual {p1, p2, p3}, La_0D850CD8;->d(Landroid/util/AttributeSet;I)V

    .line 7
    new-instance p1, La_1CAFA37F;

    invoke-direct {p1, p0}, La_1CAFA37F;-><init>(Landroid/widget/TextView;)V

    iput-object p1, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 8
    invoke-virtual {p1, p2, p3}, La_1CAFA37F;->f(Landroid/util/AttributeSet;I)V

    .line 9
    invoke-virtual {p1}, La_1CAFA37F;->b()V

    .line 10
    new-instance p1, La_BC92C3B9;

    invoke-direct {p1, p0}, La_BC92C3B9;-><init>(Landroid/widget/TextView;)V

    iput-object p1, p0, La_18EF3B18;->e:La_BC92C3B9;

    .line 11
    invoke-direct {p0}, La_18EF3B18;->m_c85256e9()La_BB55952C;

    move-result-object p1

    .line 12
    invoke-virtual {p1, p2, p3}, La_BB55952C;->a(Landroid/util/AttributeSet;I)V

    return-void
.end method

.method private m_c85256e9()La_BB55952C;
    .locals 1

    .line 1
    iget-object v0, p0, La_18EF3B18;->f:La_BB55952C;

    .line 3
    if-nez v0, :cond_0

    .line 5
    new-instance v0, La_BB55952C;

    .line 7
    invoke-direct {v0, p0}, La_BB55952C;-><init>(Landroid/widget/TextView;)V

    .line 10
    iput-object v0, p0, La_18EF3B18;->f:La_BB55952C;

    .line 12
    :cond_0
    iget-object v0, p0, La_18EF3B18;->f:La_BB55952C;

    .line 14
    return-object v0
.end method


# virtual methods
.method public final m_cb26974e()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/TextView;->m_cb26974e()V

    .line 4
    iget-object v0, p0, La_18EF3B18;->c:La_0D850CD8;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, La_0D850CD8;->a()V

    .line 11
    :cond_0
    iget-object v0, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 13
    if-eqz v0, :cond_1

    .line 15
    invoke-virtual {v0}, La_1CAFA37F;->b()V

    .line 18
    :cond_1
    return-void
.end method

.method public m_b47f15c0()I
    .locals 1

    .line 1
    sget-boolean v0, La_AB6A81EE;->a:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0}, Landroid/widget/TextView;->m_b47f15c0()I

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    iget-object v0, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 12
    if-eqz v0, :cond_1

    .line 14
    iget-object v0, v0, La_1CAFA37F;->i:La_7D97F68F;

    .line 16
    iget v0, v0, La_7D97F68F;->e:F

    .line 18
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    .line 21
    move-result v0

    .line 22
    return v0

    .line 23
    :cond_1
    const/4 v0, -0x1

    .line 24
    return v0
.end method

.method public m_0a21f157()I
    .locals 1

    .line 1
    sget-boolean v0, La_AB6A81EE;->a:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0}, Landroid/widget/TextView;->m_0a21f157()I

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    iget-object v0, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 12
    if-eqz v0, :cond_1

    .line 14
    iget-object v0, v0, La_1CAFA37F;->i:La_7D97F68F;

    .line 16
    iget v0, v0, La_7D97F68F;->d:F

    .line 18
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    .line 21
    move-result v0

    .line 22
    return v0

    .line 23
    :cond_1
    const/4 v0, -0x1

    .line 24
    return v0
.end method

.method public m_d388d1f7()I
    .locals 1

    .line 1
    sget-boolean v0, La_AB6A81EE;->a:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0}, Landroid/widget/TextView;->m_d388d1f7()I

    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    iget-object v0, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 12
    if-eqz v0, :cond_1

    .line 14
    iget-object v0, v0, La_1CAFA37F;->i:La_7D97F68F;

    .line 16
    iget v0, v0, La_7D97F68F;->c:F

    .line 18
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    .line 21
    move-result v0

    .line 22
    return v0

    .line 23
    :cond_1
    const/4 v0, -0x1

    .line 24
    return v0
.end method

.method public m_2b43b45c()[I
    .locals 1

    .line 1
    sget-boolean v0, La_AB6A81EE;->a:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0}, Landroid/widget/TextView;->m_2b43b45c()[I

    .line 8
    move-result-object v0

    .line 9
    return-object v0

    .line 10
    :cond_0
    iget-object v0, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 12
    if-eqz v0, :cond_1

    .line 14
    iget-object v0, v0, La_1CAFA37F;->i:La_7D97F68F;

    .line 16
    iget-object v0, v0, La_7D97F68F;->f:[I

    .line 18
    return-object v0

    .line 19
    :cond_1
    const/4 v0, 0x0

    .line 20
    new-array v0, v0, [I

    .line 22
    return-object v0
.end method

.method public m_0d8ee99c()I
    .locals 3
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "WrongConstant"
        }
    .end annotation

    .line 1
    sget-boolean v0, La_AB6A81EE;->a:Z

    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_1

    .line 6
    invoke-super {p0}, Landroid/widget/TextView;->m_0d8ee99c()I

    .line 9
    move-result v0

    .line 10
    const/4 v2, 0x1

    .line 11
    if-ne v0, v2, :cond_0

    .line 13
    const/4 v1, 0x1

    .line 14
    :cond_0
    return v1

    .line 15
    :cond_1
    iget-object v0, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 17
    if-eqz v0, :cond_2

    .line 19
    iget-object v0, v0, La_1CAFA37F;->i:La_7D97F68F;

    .line 21
    iget v0, v0, La_7D97F68F;->a:I

    .line 23
    return v0

    .line 24
    :cond_2
    return v1
.end method

.method public m_d2f56bdd()Landroid/view/ActionMode$Callback;
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/TextView;->m_d2f56bdd()Landroid/view/ActionMode$Callback;

    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Lwu;->f(Landroid/view/ActionMode$Callback;)Landroid/view/ActionMode$Callback;

    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public m_d696c1ae()I
    .locals 2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v0

    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/Paint;->getFontMetricsInt()Landroid/graphics/Paint$FontMetricsInt;

    move-result-object v1

    iget v1, v1, Landroid/graphics/Paint$FontMetricsInt;->top:I

    sub-int/2addr v0, v1

    return v0
.end method

.method public m_fb53fea6()I
    .locals 2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v0

    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/Paint;->getFontMetricsInt()Landroid/graphics/Paint$FontMetricsInt;

    move-result-object v1

    iget v1, v1, Landroid/graphics/Paint$FontMetricsInt;->bottom:I

    add-int/2addr v0, v1

    return v0
.end method

.method public m_4eb19bca()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, La_18EF3B18;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_0D850CD8;->b()Landroid/content/res/ColorStateList;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_c605babf()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, La_18EF3B18;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_0D850CD8;->c()Landroid/graphics/PorterDuff$Mode;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_d7d2cbaa()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, La_18EF3B18;->d:La_1CAFA37F;

    invoke-virtual {v0}, La_1CAFA37F;->d()Landroid/content/res/ColorStateList;

    move-result-object v0

    return-object v0
.end method

.method public m_93878187()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    iget-object v0, p0, La_18EF3B18;->d:La_1CAFA37F;

    invoke-virtual {v0}, La_1CAFA37F;->e()Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    return-object v0
.end method

.method public m_8956cb8d()Ljava/lang/CharSequence;
    .locals 2

    .line 1
    iget-object v0, p0, La_18EF3B18;->h:Ljava/util/concurrent/Future;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    const/4 v1, 0x0

    .line 6
    :try_start_0
    iput-object v1, p0, La_18EF3B18;->h:Ljava/util/concurrent/Future;

    .line 8
    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Lmo;

    .line 14
    invoke-static {p0, v0}, Lwu;->d(Landroid/widget/TextView;Lmo;)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    :catch_0
    :cond_0
    invoke-super {p0}, Landroid/widget/TextView;->m_8956cb8d()Ljava/lang/CharSequence;

    .line 20
    move-result-object v0

    .line 21
    return-object v0
.end method

.method public m_1ebf30c0()Landroid/view/textclassifier/TextClassifier;
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1c

    .line 5
    if-ge v0, v1, :cond_2

    .line 7
    iget-object v0, p0, La_18EF3B18;->e:La_BC92C3B9;

    .line 9
    if-nez v0, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iget-object v1, v0, La_BC92C3B9;->b:Landroid/view/textclassifier/TextClassifier;

    .line 14
    if-nez v1, :cond_1

    .line 16
    iget-object v0, v0, La_BC92C3B9;->a:Landroid/widget/TextView;

    .line 18
    invoke-static {v0}, La_00ABB2DA;->a(Landroid/widget/TextView;)Landroid/view/textclassifier/TextClassifier;

    .line 21
    move-result-object v1

    .line 22
    :cond_1
    return-object v1

    .line 23
    :cond_2
    :goto_0
    invoke-super {p0}, Landroid/widget/TextView;->m_1ebf30c0()Landroid/view/textclassifier/TextClassifier;

    .line 26
    move-result-object v0

    .line 27
    return-object v0
.end method

.method public m_a71ef9ff()La_14004D53;
    .locals 1

    invoke-static {p0}, Lwu;->a(Landroid/widget/TextView;)La_14004D53;

    move-result-object v0

    return-object v0
.end method

.method public final onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .locals 2

    .line 1
    invoke-super {p0, p1}, Landroid/widget/TextView;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 7
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    invoke-static {p0, v0, p1}, La_1CAFA37F;->h(Landroid/widget/TextView;Landroid/view/inputmethod/InputConnection;Landroid/view/inputmethod/EditorInfo;)V

    .line 13
    invoke-static {p0, p1, v0}, La_F5C4F8D6;->m_fabc7ccf(Landroid/view/View;Landroid/view/inputmethod/EditorInfo;Landroid/view/inputmethod/InputConnection;)V

    .line 16
    return-object v0
.end method

.method public final onLayout(ZIIII)V
    .locals 0

    .line 1
    invoke-super/range {p0 .. p5}, Landroid/widget/TextView;->onLayout(ZIIII)V

    .line 4
    iget-object p1, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    sget-boolean p2, La_AB6A81EE;->a:Z

    .line 10
    if-nez p2, :cond_0

    .line 12
    iget-object p1, p1, La_1CAFA37F;->i:La_7D97F68F;

    .line 14
    invoke-virtual {p1}, La_7D97F68F;->a()V

    .line 17
    :cond_0
    return-void
.end method

.method public onMeasure(II)V
    .locals 2

    .line 1
    iget-object v0, p0, La_18EF3B18;->h:Ljava/util/concurrent/Future;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    const/4 v1, 0x0

    .line 6
    :try_start_0
    iput-object v1, p0, La_18EF3B18;->h:Ljava/util/concurrent/Future;

    .line 8
    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Lmo;

    .line 14
    invoke-static {p0, v0}, Lwu;->d(Landroid/widget/TextView;Lmo;)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    :catch_0
    :cond_0
    invoke-super {p0, p1, p2}, Landroid/widget/TextView;->onMeasure(II)V

    .line 20
    return-void
.end method

.method public final onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->onTextChanged(Ljava/lang/CharSequence;III)V

    .line 4
    iget-object p1, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 6
    if-eqz p1, :cond_1

    .line 8
    sget-boolean p2, La_AB6A81EE;->a:Z

    .line 10
    if-nez p2, :cond_1

    .line 12
    iget-object p1, p1, La_1CAFA37F;->i:La_7D97F68F;

    .line 14
    invoke-virtual {p1}, La_7D97F68F;->h()Z

    .line 17
    move-result p2

    .line 18
    if-eqz p2, :cond_0

    .line 20
    iget p2, p1, La_7D97F68F;->a:I

    .line 22
    if-eqz p2, :cond_0

    .line 24
    const/4 p2, 0x1

    .line 25
    goto :goto_0

    .line 26
    :cond_0
    const/4 p2, 0x0

    .line 27
    :goto_0
    if-eqz p2, :cond_1

    .line 29
    invoke-virtual {p1}, La_7D97F68F;->a()V

    .line 32
    :cond_1
    return-void
.end method

.method public m_c6d542c7(Z)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_c6d542c7(Z)V

    .line 4
    invoke-direct {p0}, La_18EF3B18;->m_c85256e9()La_BB55952C;

    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0, p1}, La_BB55952C;->b(Z)V

    .line 11
    return-void
.end method

.method public final m_c78f8fac(IIII)V
    .locals 1

    .line 1
    sget-boolean v0, La_AB6A81EE;->a:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->m_c78f8fac(IIII)V

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    iget-object v0, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 11
    if-eqz v0, :cond_1

    .line 13
    invoke-virtual {v0, p1, p2, p3, p4}, La_1CAFA37F;->i(IIII)V

    .line 16
    :cond_1
    :goto_0
    return-void
.end method

.method public final m_868b6728([II)V
    .locals 1

    .line 1
    sget-boolean v0, La_AB6A81EE;->a:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1, p2}, Landroid/widget/TextView;->m_868b6728([II)V

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    iget-object v0, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 11
    if-eqz v0, :cond_1

    .line 13
    invoke-virtual {v0, p1, p2}, La_1CAFA37F;->j([II)V

    .line 16
    :cond_1
    :goto_0
    return-void
.end method

.method public m_aad47efc(I)V
    .locals 1

    .line 1
    sget-boolean v0, La_AB6A81EE;->a:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_aad47efc(I)V

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    iget-object v0, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 11
    if-eqz v0, :cond_1

    .line 13
    invoke-virtual {v0, p1}, La_1CAFA37F;->k(I)V

    .line 16
    :cond_1
    :goto_0
    return-void
.end method

.method public m_08385e47(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_08385e47(Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_18EF3B18;->c:La_0D850CD8;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_0D850CD8;->e()V

    .line 11
    :cond_0
    return-void
.end method

.method public m_ee40bba3(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_ee40bba3(I)V

    .line 4
    iget-object v0, p0, La_18EF3B18;->c:La_0D850CD8;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1}, La_0D850CD8;->f(I)V

    .line 11
    :cond_0
    return-void
.end method

.method public final m_4e411e88(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->m_4e411e88(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_1CAFA37F;->b()V

    .line 11
    :cond_0
    return-void
.end method

.method public final m_26748812(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->m_26748812(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_1CAFA37F;->b()V

    .line 11
    :cond_0
    return-void
.end method

.method public final m_cebad1c7(IIII)V
    .locals 2

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    .line 5
    invoke-static {v0, p1}, La_F5C4F8D6;->m_7bf4cde2(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    goto :goto_0

    :cond_0
    move-object p1, v1

    :goto_0
    if-eqz p2, :cond_1

    .line 6
    invoke-static {v0, p2}, La_F5C4F8D6;->m_7bf4cde2(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    goto :goto_1

    :cond_1
    move-object p2, v1

    :goto_1
    if-eqz p3, :cond_2

    .line 7
    invoke-static {v0, p3}, La_F5C4F8D6;->m_7bf4cde2(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p3

    goto :goto_2

    :cond_2
    move-object p3, v1

    :goto_2
    if-eqz p4, :cond_3

    .line 8
    invoke-static {v0, p4}, La_F5C4F8D6;->m_7bf4cde2(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    .line 9
    :cond_3
    invoke-virtual {p0, p1, p2, p3, v1}, La_18EF3B18;->m_cebad1c7(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 10
    iget-object p1, p0, La_18EF3B18;->d:La_1CAFA37F;

    if-eqz p1, :cond_4

    .line 11
    invoke-virtual {p1}, La_1CAFA37F;->b()V

    :cond_4
    return-void
.end method

.method public final m_cebad1c7(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->m_cebad1c7(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 2
    iget-object p1, p0, La_18EF3B18;->d:La_1CAFA37F;

    if-eqz p1, :cond_0

    .line 3
    invoke-virtual {p1}, La_1CAFA37F;->b()V

    :cond_0
    return-void
.end method

.method public final m_dfbe7d90(IIII)V
    .locals 2

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    .line 5
    invoke-static {v0, p1}, La_F5C4F8D6;->m_7bf4cde2(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    goto :goto_0

    :cond_0
    move-object p1, v1

    :goto_0
    if-eqz p2, :cond_1

    .line 6
    invoke-static {v0, p2}, La_F5C4F8D6;->m_7bf4cde2(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    goto :goto_1

    :cond_1
    move-object p2, v1

    :goto_1
    if-eqz p3, :cond_2

    .line 7
    invoke-static {v0, p3}, La_F5C4F8D6;->m_7bf4cde2(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p3

    goto :goto_2

    :cond_2
    move-object p3, v1

    :goto_2
    if-eqz p4, :cond_3

    .line 8
    invoke-static {v0, p4}, La_F5C4F8D6;->m_7bf4cde2(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    .line 9
    :cond_3
    invoke-virtual {p0, p1, p2, p3, v1}, La_18EF3B18;->m_dfbe7d90(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 10
    iget-object p1, p0, La_18EF3B18;->d:La_1CAFA37F;

    if-eqz p1, :cond_4

    .line 11
    invoke-virtual {p1}, La_1CAFA37F;->b()V

    :cond_4
    return-void
.end method

.method public final m_dfbe7d90(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->m_dfbe7d90(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 2
    iget-object p1, p0, La_18EF3B18;->d:La_1CAFA37F;

    if-eqz p1, :cond_0

    .line 3
    invoke-virtual {p1}, La_1CAFA37F;->b()V

    :cond_0
    return-void
.end method

.method public m_43b91c56(Landroid/view/ActionMode$Callback;)V
    .locals 0

    .line 1
    invoke-static {p1, p0}, Lwu;->g(Landroid/view/ActionMode$Callback;Landroid/widget/TextView;)Landroid/view/ActionMode$Callback;

    .line 4
    move-result-object p1

    .line 5
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_43b91c56(Landroid/view/ActionMode$Callback;)V

    .line 8
    return-void
.end method

.method public m_63db9ddc(Z)V
    .locals 1

    invoke-direct {p0}, La_18EF3B18;->m_c85256e9()La_BB55952C;

    move-result-object v0

    invoke-virtual {v0, p1}, La_BB55952C;->c(Z)V

    return-void
.end method

.method public m_ccb56b93([Landroid/text/InputFilter;)V
    .locals 1

    .line 1
    invoke-direct {p0}, La_18EF3B18;->m_c85256e9()La_BB55952C;

    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, La_BB55952C;->b:Ltb;

    .line 7
    iget-object v0, v0, Ltb;->a:La_15BE5240;

    .line 9
    invoke-virtual {v0, p1}, La_15BE5240;->a([Landroid/text/InputFilter;)[Landroid/text/InputFilter;

    .line 12
    move-result-object p1

    .line 13
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_ccb56b93([Landroid/text/InputFilter;)V

    .line 16
    return-void
.end method

.method public m_5e962bc4(I)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1c

    .line 5
    if-lt v0, v1, :cond_0

    .line 7
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_5e962bc4(I)V

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    invoke-static {p0, p1}, Lwu;->b(Landroid/widget/TextView;I)V

    .line 14
    :goto_0
    return-void
.end method

.method public m_d57820bd(I)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1c

    .line 5
    if-lt v0, v1, :cond_0

    .line 7
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_d57820bd(I)V

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    invoke-static {p0, p1}, Lwu;->c(Landroid/widget/TextView;I)V

    .line 14
    :goto_0
    return-void
.end method

.method public m_a8655c20(I)V
    .locals 2

    .line 1
    invoke-static {p1}, La_F5C4F8D6;->j(I)V

    .line 4
    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    .line 7
    move-result-object v0

    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->getFontMetricsInt(Landroid/graphics/Paint$FontMetricsInt;)I

    .line 12
    move-result v0

    .line 13
    if-eq p1, v0, :cond_0

    .line 15
    sub-int/2addr p1, v0

    .line 16
    int-to-float p1, p1

    .line 17
    const/high16 v0, 0x3f800000    # 1.0f

    .line 19
    invoke-virtual {p0, p1, v0}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 22
    :cond_0
    return-void
.end method

.method public m_8cda92b0(Lmo;)V
    .locals 0

    invoke-static {p0, p1}, Lwu;->d(Landroid/widget/TextView;Lmo;)V

    return-void
.end method

.method public m_44b49f65(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_18EF3B18;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_0D850CD8;->h(Landroid/content/res/ColorStateList;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_10b86d4b(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_18EF3B18;->c:La_0D850CD8;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_0D850CD8;->i(Landroid/graphics/PorterDuff$Mode;)V

    .line 8
    :cond_0
    return-void
.end method

.method public m_30fdcbb6(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 3
    invoke-virtual {v0, p1}, La_1CAFA37F;->l(Landroid/content/res/ColorStateList;)V

    .line 6
    invoke-virtual {v0}, La_1CAFA37F;->b()V

    .line 9
    return-void
.end method

.method public m_ad713641(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 3
    invoke-virtual {v0, p1}, La_1CAFA37F;->m(Landroid/graphics/PorterDuff$Mode;)V

    .line 6
    invoke-virtual {v0}, La_1CAFA37F;->b()V

    .line 9
    return-void
.end method

.method public m_f1267819(Landroid/content/Context;I)V
    .locals 1

    .line 1
    invoke-super {p0, p1, p2}, Landroid/widget/TextView;->m_f1267819(Landroid/content/Context;I)V

    .line 4
    iget-object v0, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1, p2}, La_1CAFA37F;->g(Landroid/content/Context;I)V

    .line 11
    :cond_0
    return-void
.end method

.method public m_62fd6b61(Landroid/view/textclassifier/TextClassifier;)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1c

    .line 5
    if-ge v0, v1, :cond_1

    .line 7
    iget-object v0, p0, La_18EF3B18;->e:La_BC92C3B9;

    .line 9
    if-nez v0, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iput-object p1, v0, La_BC92C3B9;->b:Landroid/view/textclassifier/TextClassifier;

    .line 14
    return-void

    .line 15
    :cond_1
    :goto_0
    invoke-super {p0, p1}, Landroid/widget/TextView;->m_62fd6b61(Landroid/view/textclassifier/TextClassifier;)V

    .line 18
    return-void
.end method

.method public m_3f1f1c86(Ljava/util/concurrent/Future;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Future<",
            "Lmo;",
            ">;)V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, La_18EF3B18;->h:Ljava/util/concurrent/Future;

    .line 3
    if-eqz p1, :cond_0

    .line 5
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 8
    :cond_0
    return-void
.end method

.method public m_5e7b2dc5(La_14004D53;)V
    .locals 3

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    iget-object v1, p1, La_14004D53;->b:Landroid/text/TextDirectionHeuristic;

    .line 5
    sget-object v2, Landroid/text/TextDirectionHeuristics;->FIRSTSTRONG_RTL:Landroid/text/TextDirectionHeuristic;

    .line 7
    if-ne v1, v2, :cond_0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    sget-object v2, Landroid/text/TextDirectionHeuristics;->FIRSTSTRONG_LTR:Landroid/text/TextDirectionHeuristic;

    .line 12
    if-ne v1, v2, :cond_1

    .line 14
    goto :goto_0

    .line 15
    :cond_1
    sget-object v2, Landroid/text/TextDirectionHeuristics;->ANYRTL_LTR:Landroid/text/TextDirectionHeuristic;

    .line 17
    if-ne v1, v2, :cond_2

    .line 19
    const/4 v1, 0x2

    .line 20
    goto :goto_1

    .line 21
    :cond_2
    sget-object v2, Landroid/text/TextDirectionHeuristics;->LTR:Landroid/text/TextDirectionHeuristic;

    .line 23
    if-ne v1, v2, :cond_3

    .line 25
    const/4 v1, 0x3

    .line 26
    goto :goto_1

    .line 27
    :cond_3
    sget-object v2, Landroid/text/TextDirectionHeuristics;->RTL:Landroid/text/TextDirectionHeuristic;

    .line 29
    if-ne v1, v2, :cond_4

    .line 31
    const/4 v1, 0x4

    .line 32
    goto :goto_1

    .line 33
    :cond_4
    sget-object v2, Landroid/text/TextDirectionHeuristics;->LOCALE:Landroid/text/TextDirectionHeuristic;

    .line 35
    if-ne v1, v2, :cond_5

    .line 37
    const/4 v1, 0x5

    .line 38
    goto :goto_1

    .line 39
    :cond_5
    sget-object v2, Landroid/text/TextDirectionHeuristics;->FIRSTSTRONG_LTR:Landroid/text/TextDirectionHeuristic;

    .line 41
    if-ne v1, v2, :cond_6

    .line 43
    const/4 v1, 0x6

    .line 44
    goto :goto_1

    .line 45
    :cond_6
    sget-object v2, Landroid/text/TextDirectionHeuristics;->FIRSTSTRONG_RTL:Landroid/text/TextDirectionHeuristic;

    .line 47
    if-ne v1, v2, :cond_7

    .line 49
    const/4 v1, 0x7

    .line 50
    goto :goto_1

    .line 51
    :cond_7
    :goto_0
    const/4 v1, 0x1

    .line 52
    :goto_1
    invoke-static {p0, v1}, La_451100C5;->h(Landroid/view/View;I)V

    .line 55
    const/16 v1, 0x17

    .line 57
    iget-object v2, p1, La_14004D53;->a:Landroid/text/TextPaint;

    .line 59
    if-ge v0, v1, :cond_9

    .line 61
    invoke-virtual {v2}, Landroid/graphics/Paint;->getTextScaleX()F

    .line 64
    move-result p1

    .line 65
    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    .line 68
    move-result-object v0

    .line 69
    invoke-virtual {v0, v2}, Landroid/text/TextPaint;->set(Landroid/text/TextPaint;)V

    .line 72
    invoke-virtual {p0}, Landroid/widget/TextView;->getTextScaleX()F

    .line 75
    move-result v0

    .line 76
    cmpl-float v0, p1, v0

    .line 78
    if-nez v0, :cond_8

    .line 80
    const/high16 v0, 0x40000000    # 2.0f

    .line 82
    div-float v0, p1, v0

    .line 84
    const/high16 v1, 0x3f800000    # 1.0f

    .line 86
    add-float/2addr v0, v1

    .line 87
    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setTextScaleX(F)V

    .line 90
    :cond_8
    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setTextScaleX(F)V

    .line 93
    goto :goto_2

    .line 94
    :cond_9
    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    .line 97
    move-result-object v0

    .line 98
    invoke-virtual {v0, v2}, Landroid/text/TextPaint;->set(Landroid/text/TextPaint;)V

    .line 101
    iget v0, p1, La_14004D53;->c:I

    .line 103
    invoke-static {p0, v0}, La_CE975A27;->e(Landroid/widget/TextView;I)V

    .line 106
    iget p1, p1, La_14004D53;->d:I

    .line 108
    invoke-static {p0, p1}, La_CE975A27;->h(Landroid/widget/TextView;I)V

    .line 111
    :goto_2
    return-void
.end method

.method public final m_baef72f2(IF)V
    .locals 2

    .line 1
    sget-boolean v0, La_AB6A81EE;->a:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1, p2}, Landroid/widget/TextView;->m_baef72f2(IF)V

    .line 8
    goto :goto_1

    .line 9
    :cond_0
    iget-object v1, p0, La_18EF3B18;->d:La_1CAFA37F;

    .line 11
    if-eqz v1, :cond_2

    .line 13
    if-nez v0, :cond_2

    .line 15
    iget-object v0, v1, La_1CAFA37F;->i:La_7D97F68F;

    .line 17
    invoke-virtual {v0}, La_7D97F68F;->h()Z

    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_1

    .line 23
    iget v1, v0, La_7D97F68F;->a:I

    .line 25
    if-eqz v1, :cond_1

    .line 27
    const/4 v1, 0x1

    .line 28
    goto :goto_0

    .line 29
    :cond_1
    const/4 v1, 0x0

    .line 30
    :goto_0
    if-nez v1, :cond_2

    .line 32
    invoke-virtual {v0, p1, p2}, La_7D97F68F;->e(IF)V

    .line 35
    :cond_2
    :goto_1
    return-void
.end method

.method public final m_ded7c3e0(Landroid/graphics/Typeface;I)V
    .locals 2

    .line 1
    iget-boolean v0, p0, La_18EF3B18;->g:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    return-void

    .line 6
    :cond_0
    if-eqz p1, :cond_2

    .line 8
    if-lez p2, :cond_2

    .line 10
    invoke-virtual {p0}, Landroid/view/View;->m_a14d8ca8()Landroid/content/Context;

    .line 13
    move-result-object v0

    .line 14
    sget-object v1, Lmw;->a:Ltw;

    .line 16
    if-eqz v0, :cond_1

    .line 18
    invoke-static {p1, p2}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    .line 21
    move-result-object v0

    .line 22
    goto :goto_0

    .line 23
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 25
    const-string p2, "Context cannot be null"

    .line 27
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 30
    throw p1

    .line 31
    :cond_2
    const/4 v0, 0x0

    .line 32
    :goto_0
    const/4 v1, 0x1

    .line 33
    iput-boolean v1, p0, La_18EF3B18;->g:Z

    .line 35
    if-eqz v0, :cond_3

    .line 37
    move-object p1, v0

    .line 38
    :cond_3
    const/4 v0, 0x0

    .line 39
    :try_start_0
    invoke-super {p0, p1, p2}, Landroid/widget/TextView;->m_ded7c3e0(Landroid/graphics/Typeface;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 42
    iput-boolean v0, p0, La_18EF3B18;->g:Z

    .line 44
    return-void

    .line 45
    :catchall_0
    move-exception p1

    .line 46
    iput-boolean v0, p0, La_18EF3B18;->g:Z

    .line 48
    throw p1
.end method
