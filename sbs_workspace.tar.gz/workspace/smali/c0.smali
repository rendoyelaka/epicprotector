.class public abstract Lc0;
.super Ljava/lang/Object;
# compiled-64097
# ep-yluwgnvppwjz
.source "GestureHelper96.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc0$a;
    }
.end annotation


# instance fields
.field public c:Ljava/lang/Object;

.field public d:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract c()V
.end method

.method public abstract d()Landroid/view/View;
.end method

.method public abstract e()Landroidx/appcompat/view/menu/f;
.end method

.method public abstract f()Landroid/view/MenuInflater;
.end method

.method public abstract g()Ljava/lang/CharSequence;
.end method

.method public abstract h()Ljava/lang/CharSequence;
.end method

.method public abstract i()V
.end method

.method public abstract j()Z
.end method

.method public abstract k(Landroid/view/View;)V
.end method

.method public abstract l(I)V
.end method

.method public abstract m(Ljava/lang/CharSequence;)V
.end method

.method public abstract n(I)V
.end method

.method public abstract o(Ljava/lang/CharSequence;)V
.end method

.method public abstract p(Z)V
.end method
