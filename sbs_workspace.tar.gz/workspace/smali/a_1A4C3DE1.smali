.class public final La_1A4C3DE1;
# ep-xrdmwbfyqfng
.super Landroid/animation/AnimatorListenerAdapter;
.source "lgitsgzw.java"
# compiled-17833
# compiled-95902
# verified-59240


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_9A3C71D5;->onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lvz;

.field public final synthetic b:Landroid/view/View;


# direct methods
.method public constructor <init>(Lvz;Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, La_1A4C3DE1;->a:Lvz;

    iput-object p2, p0, La_1A4C3DE1;->b:Landroid/view/View;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 2

    .line 1
    iget-object p1, p0, La_1A4C3DE1;->a:Lvz;

    .line 3
    iget-object v0, p1, Lvz;->a:La_8CD43299;

    .line 5
    const/high16 v1, 0x3f800000    # 1.0f

    .line 7
    invoke-virtual {v0, v1}, La_8CD43299;->d(F)V

    .line 10
    iget-object v0, p0, La_1A4C3DE1;->b:Landroid/view/View;

    .line 12
    invoke-static {v0, p1}, La_167641C3;->e(Landroid/view/View;Lvz;)V

    .line 15
    return-void
.end method
