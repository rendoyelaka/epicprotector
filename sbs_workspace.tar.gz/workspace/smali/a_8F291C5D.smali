.class public final La_8F291C5D;
.super La_AD33B00A;
.source "uwtjcipu.java"
# processed-10396
# compiled-89648
# generated-65010
# ep-skgntzyjgmdj


# static fields
.field public static volatile d:La_8F291C5D;

.field public static final e:La_FB42E5D5;


# instance fields
.field public final c:La_231768D7;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_FB42E5D5;

    invoke-direct {v0}, La_FB42E5D5;-><init>()V

    sput-object v0, La_8F291C5D;->e:La_FB42E5D5;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, La_AD33B00A;-><init>()V

    .line 4
    new-instance v0, La_231768D7;

    .line 6
    invoke-direct {v0}, La_231768D7;-><init>()V

    .line 9
    iput-object v0, p0, La_8F291C5D;->c:La_231768D7;

    .line 11
    return-void
.end method

.method public static q()La_8F291C5D;
    .locals 2

    .line 1
    sget-object v0, La_8F291C5D;->d:La_8F291C5D;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    sget-object v0, La_8F291C5D;->d:La_8F291C5D;

    .line 7
    return-object v0

    .line 8
    :cond_0
    const-class v0, La_8F291C5D;

    .line 10
    monitor-enter v0

    .line 11
    :try_start_0
    sget-object v1, La_8F291C5D;->d:La_8F291C5D;

    .line 13
    if-nez v1, :cond_1

    .line 15
    new-instance v1, La_8F291C5D;

    .line 17
    invoke-direct {v1}, La_8F291C5D;-><init>()V

    .line 20
    sput-object v1, La_8F291C5D;->d:La_8F291C5D;

    .line 22
    :cond_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    sget-object v0, La_8F291C5D;->d:La_8F291C5D;

    .line 25
    return-object v0

    .line 26
    :catchall_0
    move-exception v1

    .line 27
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 28
    throw v1
.end method


# virtual methods
.method public final p(Ljava/lang/Runnable;)V
    .locals 1

    iget-object v0, p0, La_8F291C5D;->c:La_231768D7;

    invoke-virtual {v0, p1}, La_231768D7;->q(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final r()Z
    .locals 1

    iget-object v0, p0, La_8F291C5D;->c:La_231768D7;

    invoke-virtual {v0}, La_231768D7;->r()Z

    move-result v0

    return v0
.end method

.method public final s(Ljava/lang/Runnable;)V
    .locals 1

    iget-object v0, p0, La_8F291C5D;->c:La_231768D7;

    invoke-virtual {v0, p1}, La_231768D7;->s(Ljava/lang/Runnable;)V

    return-void
.end method
