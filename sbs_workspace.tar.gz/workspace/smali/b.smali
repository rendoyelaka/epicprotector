.class public abstract Lb;
# ep-vwsuzsijpawi
# validated-90852
# validated-51295
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "BanParcelableUsage"
    }
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lb;",
            ">;"
        }
    .end annotation
.end field

.field public static final d:Lb$a;


# instance fields
.field public final c:Landroid/os/Parcelable;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lb$a;

    .line 3
    invoke-direct {v0}, Lb$a;-><init>()V

    .line 6
    sput-object v0, Lb;->d:Lb$a;

    .line 8
    new-instance v0, Lb$b;

    .line 10
    invoke-direct {v0}, Lb$b;-><init>()V

    .line 13
    sput-object v0, Lb;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 15
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_ltc7c9z0
    goto :ep_s_ltc7c9z0
    :ep_d_ltc7c9z0
    nop
    :ep_s_ltc7c9z0
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lb;->c:Landroid/os/Parcelable;

    return-void
.end method

.method public constructor <init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V
    .locals 0

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    invoke-virtual {p1, p2}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object p1

    if-eqz p1, :cond_0

    goto :goto_0

    .line 8
    :cond_0
    sget-object p1, Lb;->d:Lb$a;

    :goto_0
    iput-object p1, p0, Lb;->c:Landroid/os/Parcelable;

    return-void
.end method

.method public constructor <init>(Landroid/os/Parcelable;)V
    .locals 1

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p1, :cond_1

    .line 4
    sget-object v0, Lb;->d:Lb$a;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_gcz02izj
    goto :ep_s_gcz02izj
    :ep_d_gcz02izj
    nop
    :ep_s_gcz02izj
    if-eq p1, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iput-object p1, p0, Lb;->c:Landroid/os/Parcelable;

    return-void

    .line 5
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_eupj790p
    goto :ep_s_eupj790p
    :ep_d_eupj790p
    nop
    :ep_s_eupj790p
    const-string v0, "superState must not be null"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    iget-object v0, p0, Lb;->c:Landroid/os/Parcelable;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_d6plsrud
    goto :ep_s_d6plsrud
    :ep_d_d6plsrud
    nop
    :ep_s_d6plsrud
    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    return-void
.end method
