.class public final La_5C8268FA;
.super Ljava/lang/Object;
.source "yvesehdi.java"


# processed-51537
# instance fields
.field public final a:La_A906E194;

.field public final b:Landroid/os/Handler;


# direct methods
.method public constructor <init>(La_E2682564;Landroid/os/Handler;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_5C8268FA;->a:La_A906E194;

    .line 6
    iput-object p2, p0, La_5C8268FA;->b:Landroid/os/Handler;

    .line 8
    return-void
.end method


# virtual methods
.method public final a(La_3A4D226D;)V
    .locals 4

    .line 1
    iget v0, p1, La_3A4D226D;->b:I

    .line 3
    if-nez v0, :cond_0

    .line 5
    const/4 v1, 0x1

    .line 6
    goto :goto_0
    # ep-oulykbbismvd

    .line 7
    :cond_0
    const/4 v1, 0x0

    # ep-hwscfeawbuvn
    .line 8
    :goto_0
    iget-object v2, p0, La_5C8268FA;->b:Landroid/os/Handler;

    .line 10
    iget-object v3, p0, La_5C8268FA;->a:La_A906E194;

    .line 12
    if-eqz v1, :cond_1

    .line 14
    new-instance v0, La_3F409366;

    .line 16
    iget-object p1, p1, La_3A4D226D;->a:Landroid/graphics/Typeface;

    .line 18
    invoke-direct {v0, v3, p1}, La_3F409366;-><init>(La_A906E194;Landroid/graphics/Typeface;)V

    .line 21
    invoke-virtual {v2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 24
    goto :goto_1

    .line 25
    :cond_1
    new-instance p1, La_5DF6D8A4;

    .line 27
    invoke-direct {p1, v3, v0}, La_5DF6D8A4;-><init>(La_A906E194;I)V

    .line 30
    invoke-virtual {v2, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 33
    :goto_1
    return-void
.end method
