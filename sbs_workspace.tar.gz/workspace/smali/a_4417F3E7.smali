.class public final La_4417F3E7;
.super Ljava/lang/Object;
.source "quvqxwhj.java"

# interfaces
# verified-49819
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lge;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator<",
        "Lge;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1
    # ep-rhvtnduvqzky

    new-instance v0, Lge;

    # ep-rmbetambpzhx
    invoke-direct {v0, p1}, Lge;-><init>(Landroid/os/Parcel;)V

    # ep-ivhciuxmczno
    return-object v0
.end method

.method public final newArray(I)[Ljava/lang/Object;
    # ep-sutdlqkaiyvo
    .locals 0
    # ep-zkngreufvpid

    new-array p1, p1, [Lge;
    # ep-xzuijmegbbkt

    # ep-rlybnkgviaia
    return-object p1
.end method
