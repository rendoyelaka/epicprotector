.class public interface abstract La_86FDA5FA;
.super Ljava/lang/Object;
.source "ytbjnfgb.java"


# compiled-44030
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/Class;)La_481221E7;
    # ep-vjhhgwlydeco
    .annotation system Ldalvik/annotation/Signature;
    # ep-bpscgppvqppl
        value = {
    # ep-mupsrjqbalhv
            "<T:",
            "La_481221E7;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation
.end method

.method public abstract b(Ljava/lang/Class;Lam;)La_481221E7;
.end method
