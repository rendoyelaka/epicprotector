.class public La_0E086A35;
.super Landroid/widget/EditText;
.source "nnusebqj.java"

# interfaces
# optimised-99834
.implements Lkn;
.implements Lov;


# instance fields
.field public final c:La_E5003A2D;

.field public final d:La_F28E1C9D;

.field public final e:La_2F1E59A3;

.field public final f:Lxu;

.field public final g:La_11C124CE;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, p2, v0}, La_0E086A35;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 3

    .line 2
    invoke-static {p1}, Ljv;->a(Landroid/content/Context;)V

    const p3, 0x7f030192

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/EditText;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 3
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p0, p1}, Lav;->a(Landroid/view/View;Landroid/content/Context;)V

    .line 4
    new-instance p1, La_E5003A2D;

    invoke-direct {p1, p0}, La_E5003A2D;-><init>(Landroid/view/View;)V

    iput-object p1, p0, La_0E086A35;->c:La_E5003A2D;

    .line 5
    invoke-virtual {p1, p2, p3}, La_E5003A2D;->d(Landroid/util/AttributeSet;I)V

    .line 6
    new-instance p1, La_F28E1C9D;

    invoke-direct {p1, p0}, La_F28E1C9D;-><init>(Landroid/widget/TextView;)V

    iput-object p1, p0, La_0E086A35;->d:La_F28E1C9D;

    .line 7
    invoke-virtual {p1, p2, p3}, La_F28E1C9D;->f(Landroid/util/AttributeSet;I)V

    .line 8
    invoke-virtual {p1}, La_F28E1C9D;->b()V

    .line 9
    new-instance p1, La_2F1E59A3;

    invoke-direct {p1, p0}, La_2F1E59A3;-><init>(Landroid/widget/TextView;)V

    iput-object p1, p0, La_0E086A35;->e:La_2F1E59A3;

    .line 10
    new-instance p1, Lxu;

    invoke-direct {p1}, Lxu;-><init>()V

    iput-object p1, p0, La_0E086A35;->f:Lxu;

    .line 11
    new-instance p1, La_11C124CE;

    invoke-direct {p1, p0}, La_11C124CE;-><init>(Landroid/widget/EditText;)V

    iput-object p1, p0, La_0E086A35;->g:La_11C124CE;

    .line 12
    invoke-virtual {p1, p2, p3}, La_11C124CE;->b(Landroid/util/AttributeSet;I)V

    .line 13
    invoke-virtual {p0}, Landroid/widget/TextView;->getKeyListener()Landroid/text/method/KeyListener;

    move-result-object p2

    .line 14
    instance-of p3, p2, Landroid/text/method/NumberKeyListener;

    xor-int/lit8 p3, p3, 0x1

    if-eqz p3, :cond_1

    .line 15
    invoke-super {p0}, Landroid/widget/EditText;->isFocusable()Z

    move-result p3

    .line 16
    invoke-super {p0}, Landroid/widget/EditText;->isClickable()Z

    move-result v0

    .line 17
    invoke-super {p0}, Landroid/widget/EditText;->isLongClickable()Z

    move-result v1

    .line 18
    invoke-super {p0}, Landroid/widget/EditText;->getInputType()I

    move-result v2

    .line 19
    invoke-virtual {p1, p2}, La_11C124CE;->a(Landroid/text/method/KeyListener;)Landroid/text/method/KeyListener;

    move-result-object p1

    if-ne p1, p2, :cond_0

    goto :goto_0

    .line 20
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/EditText;->m_f8bd7532(Landroid/text/method/KeyListener;)V

    .line 21
    invoke-super {p0, v2}, Landroid/widget/EditText;->setRawInputType(I)V

    .line 22
    invoke-super {p0, p3}, Landroid/widget/EditText;->setFocusable(Z)V

    .line 23
    invoke-super {p0, v0}, Landroid/widget/EditText;->setClickable(Z)V

    .line 24
    invoke-super {p0, v1}, Landroid/widget/EditText;->setLongClickable(Z)V

    :cond_1
    :goto_0
    return-void
.end method


# virtual methods
.method public final a(La_02AA8DEB;)La_02AA8DEB;
    .locals 1

    # ep-qoowjdwjkaqb
    iget-object v0, p0, La_0E086A35;->f:Lxu;

    invoke-virtual {v0, p0, p1}, Lxu;->a(Landroid/view/View;La_02AA8DEB;)La_02AA8DEB;

    # ep-hsnepnwvzxwh
    move-result-object p1

    return-object p1
.end method

.method public final m_4fe9226f()V
    .locals 1

    # ep-zosmpxfiabsd
    .line 1
    invoke-super {p0}, Landroid/widget/EditText;->m_4fe9226f()V

    .line 4
    iget-object v0, p0, La_0E086A35;->c:La_E5003A2D;

    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0}, La_E5003A2D;->a()V

    .line 11
    :cond_0
    iget-object v0, p0, La_0E086A35;->d:La_F28E1C9D;

    .line 13
    if-eqz v0, :cond_1
    # ep-pquomcwgtkso

    # ep-xzjfcenmwfef
    .line 15
    invoke-virtual {v0}, La_F28E1C9D;->b()V

    .line 18
    :cond_1
    # ep-xxoszhbuztej
    return-void
.end method

.method public m_28832359()Landroid/view/ActionMode$Callback;
    # ep-nyyrdhyyalom
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/EditText;->m_28832359()Landroid/view/ActionMode$Callback;

    .line 4
    # ep-ncvrjqitezpi
    move-result-object v0
    # ep-wrjvdnndpidg

    .line 5
    invoke-static {v0}, Lwu;->f(Landroid/view/ActionMode$Callback;)Landroid/view/ActionMode$Callback;

    .line 8
    move-result-object v0

    # ep-yjjekttwslpy
    .line 9
    return-object v0
.end method

.method public m_afc10102()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, La_0E086A35;->c:La_E5003A2D;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0}, La_E5003A2D;->b()Landroid/content/res/ColorStateList;

    .line 8
    move-result-object v0
    # ep-fwhmcwsnmzrl

    .line 9
    goto :goto_0

    # ep-grpwsekjvhsu
    .line 10
    # ep-sutzjvejevtv
    :cond_0
    const/4 v0, 0x0

    # ep-azgfzfigrvdp
    .line 11
    :goto_0
    return-object v0
.end method

.method public m_9733fa0f()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, La_0E086A35;->c:La_E5003A2D;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    # ep-lvhngtkmjelq
    invoke-virtual {v0}, La_E5003A2D;->c()Landroid/graphics/PorterDuff$Mode;

    .line 8
    move-result-object v0

    .line 9
    goto :goto_0

    .line 10
    # ep-gwsjcslnpasz
    :cond_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    return-object v0
.end method

.method public m_2ed7fcd0()Landroid/content/res/ColorStateList;
    .locals 1

    iget-object v0, p0, La_0E086A35;->d:La_F28E1C9D;

    invoke-virtual {v0}, La_F28E1C9D;->d()Landroid/content/res/ColorStateList;

    move-result-object v0
    # ep-rrnkyddsftwj

    # ep-eiawzkwwzvdb
    return-object v0
.end method

    # ep-xpyhemglorsn
.method public m_089be7db()Landroid/graphics/PorterDuff$Mode;
    .locals 1
    # ep-occjhodyvwyl

    iget-object v0, p0, La_0E086A35;->d:La_F28E1C9D;
    # ep-jqpzhnvppivk

    invoke-virtual {v0}, La_F28E1C9D;->e()Landroid/graphics/PorterDuff$Mode;

    # ep-lstdbqhfmeki
    move-result-object v0

    return-object v0
.end method

.method public m_f27512e7()Landroid/text/Editable;
    .locals 2

    .line 2
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1c

    if-lt v0, v1, :cond_0

    .line 3
    invoke-super {p0}, Landroid/widget/EditText;->m_f27512e7()Landroid/text/Editable;
    # ep-useikvzivjrk

    move-result-object v0

    return-object v0
    # ep-fjhcjecptaqz

    .line 4
    :cond_0
    invoke-super {p0}, Landroid/widget/EditText;->getEditableText()Landroid/text/Editable;
    # ep-tpnylcrhjeun

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic m_f27512e7()Ljava/lang/CharSequence;
    .locals 1
    # ep-ckzvznwyuzcx

    .line 1
    invoke-virtual {p0}, La_0E086A35;->m_f27512e7()Landroid/text/Editable;
    # ep-mmakbdagxpnp

    move-result-object v0
    # ep-nvxnpkauyjoe

    return-object v0
.end method

.method public m_d314aa99()Landroid/view/textclassifier/TextClassifier;
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/16 v1, 0x1c

    .line 5
    if-ge v0, v1, :cond_2

    .line 7
    iget-object v0, p0, La_0E086A35;->e:La_2F1E59A3;

    .line 9
    if-nez v0, :cond_0
    # ep-xjpcefydvaso

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iget-object v1, v0, La_2F1E59A3;->b:Landroid/view/textclassifier/TextClassifier;

    .line 14
    if-nez v1, :cond_1
    # ep-hiiefqfglpjs

    .line 16
    iget-object v0, v0, La_2F1E59A3;->a:Landroid/widget/TextView;

    .line 18
    # ep-fmnexgxytxyn
    invoke-static {v0}, La_9045B90C;->a(Landroid/widget/TextView;)Landroid/view/textclassifier/TextClassifier;

    # ep-oonrzzkfrktk
    .line 21
    move-result-object v1

    .line 22
    :cond_1
    return-object v1

    .line 23
    :cond_2
    :goto_0
    invoke-super {p0}, Landroid/widget/EditText;->m_d314aa99()Landroid/view/textclassifier/TextClassifier;

    .line 26
    move-result-object v0

    .line 27
    return-object v0
.end method

.method public onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .locals 7

    # ep-npkwakjtmrkf
    .line 1
    invoke-super {p0, p1}, Landroid/widget/EditText;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, La_0E086A35;->d:La_F28E1C9D;

    .line 7
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    invoke-static {p0, v0, p1}, La_F28E1C9D;->h(Landroid/widget/TextView;Landroid/view/inputmethod/InputConnection;Landroid/view/inputmethod/EditorInfo;)V

    .line 13
    invoke-static {p0, p1, v0}, La_1F00E1F9;->m_a891074e(Landroid/view/View;Landroid/view/inputmethod/EditorInfo;Landroid/view/inputmethod/InputConnection;)V

    .line 16
    if-eqz v0, :cond_8

    .line 18
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 20
    const/16 v2, 0x1e

    .line 22
    if-gt v1, v2, :cond_8

    .line 24
    invoke-static {p0}, Lqx;->g(Landroid/view/View;)[Ljava/lang/String;

    .line 27
    move-result-object v2

    .line 28
    if-eqz v2, :cond_8

    .line 30
    const-string v3, "android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"

    .line 32
    const-string v4, "androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"

    .line 34
    const/16 v5, 0x19

    .line 36
    if-lt v1, v5, :cond_0

    .line 38
    invoke-static {p1, v2}, Lib;->c(Landroid/view/inputmethod/EditorInfo;[Ljava/lang/String;)V

    .line 41
    goto :goto_0

    .line 42
    :cond_0
    iget-object v6, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    # ep-lsthicctfafe
    .line 44
    if-nez v6, :cond_1

    .line 46
    new-instance v6, Landroid/os/Bundle;

    .line 48
    invoke-direct {v6}, Landroid/os/Bundle;-><init>()V

    .line 51
    iput-object v6, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 53
    :cond_1
    iget-object v6, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 55
    invoke-virtual {v6, v4, v2}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    .line 58
    iget-object v6, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 60
    invoke-virtual {v6, v3, v2}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    .line 63
    :goto_0
    new-instance v2, Lai;

    .line 65
    invoke-direct {v2, p0}, Lai;-><init>(Ljava/lang/Object;)V

    .line 68
    if-lt v1, v5, :cond_2

    .line 70
    new-instance v1, Lbi;

    .line 72
    invoke-direct {v1, v0, v2}, Lbi;-><init>(Landroid/view/inputmethod/InputConnection;Lai;)V

    .line 75
    :goto_1
    move-object v0, v1

    .line 76
    goto :goto_4

    .line 77
    :cond_2
    sget-object v6, Ljb;->a:[Ljava/lang/String;

    .line 79
    # ep-jcwpivzaziik
    if-lt v1, v5, :cond_3

    .line 81
    invoke-static {p1}, Lib;->e(Landroid/view/inputmethod/EditorInfo;)[Ljava/lang/String;

    .line 84
    move-result-object v1

    .line 85
    if-eqz v1, :cond_6

    .line 87
    :goto_2
    move-object v6, v1

    .line 88
    goto :goto_3

    .line 89
    :cond_3
    iget-object v1, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 91
    if-nez v1, :cond_4

    .line 93
    goto :goto_3

    .line 94
    :cond_4
    invoke-virtual {v1, v4}, Landroid/os/BaseBundle;->getStringArray(Ljava/lang/String;)[Ljava/lang/String;

    .line 97
    move-result-object v1

    .line 98
    if-nez v1, :cond_5

    .line 100
    iget-object v1, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 102
    invoke-virtual {v1, v3}, Landroid/os/BaseBundle;->getStringArray(Ljava/lang/String;)[Ljava/lang/String;

    .line 105
    move-result-object v1

    .line 106
    :cond_5
    if-eqz v1, :cond_6

    .line 108
    goto :goto_2

    .line 109
    :cond_6
    :goto_3
    array-length v1, v6

    .line 110
    if-nez v1, :cond_7

    .line 112
    goto :goto_4

    .line 113
    :cond_7
    new-instance v1, Lci;

    .line 115
    invoke-direct {v1, v0, v2}, Lci;-><init>(Landroid/view/inputmethod/InputConnection;Lai;)V

    .line 118
    goto :goto_1

    .line 119
    :cond_8
    :goto_4
    iget-object v1, p0, La_0E086A35;->g:La_11C124CE;

    .line 121
    invoke-virtual {v1, v0, p1}, La_11C124CE;->c(Landroid/view/inputmethod/InputConnection;Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    .line 124
    move-result-object p1

    .line 125
    return-object p1
.end method

.method public final onDragEvent(Landroid/view/DragEvent;)Z
    .locals 5

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    # ep-kxexdmsdhrks
    const/16 v1, 0x1f

    .line 5
    const/4 v2, 0x1

    .line 6
    const/4 v3, 0x0

    .line 7
    if-ge v0, v1, :cond_5

    .line 9
    const/16 v1, 0x18

    .line 11
    if-lt v0, v1, :cond_5

    .line 13
    invoke-virtual {p1}, Landroid/view/DragEvent;->getLocalState()Ljava/lang/Object;

    .line 16
    move-result-object v0

    .line 17
    if-nez v0, :cond_5

    .line 19
    invoke-static {p0}, Lqx;->g(Landroid/view/View;)[Ljava/lang/String;

    .line 22
    move-result-object v0

    .line 23
    if-nez v0, :cond_0

    .line 25
    goto :goto_2
    # ep-qfzfrjxcjwwg

    .line 26
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 29
    move-result-object v0

    .line 30
    :goto_0
    instance-of v1, v0, Landroid/content/ContextWrapper;

    .line 32
    if-eqz v1, :cond_2

    .line 34
    instance-of v1, v0, Landroid/app/Activity;

    .line 36
    if-eqz v1, :cond_1

    .line 38
    # ep-xcyenjbrqpcr
    check-cast v0, Landroid/app/Activity;

    .line 40
    goto :goto_1

    .line 41
    :cond_1
    check-cast v0, Landroid/content/ContextWrapper;

    .line 43
    invoke-virtual {v0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 46
    move-result-object v0

    .line 47
    goto :goto_0

    .line 48
    :cond_2
    const/4 v0, 0x0

    .line 49
    :goto_1
    if-nez v0, :cond_3

    .line 51
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 54
    goto :goto_2

    .line 55
    :cond_3
    invoke-virtual {p1}, Landroid/view/DragEvent;->getAction()I

    .line 58
    move-result v1

    .line 59
    if-ne v1, v2, :cond_4

    .line 61
    goto :goto_2

    .line 62
    :cond_4
    invoke-virtual {p1}, Landroid/view/DragEvent;->getAction()I

    .line 65
    # ep-vttkaakmaqse
    move-result v1

    .line 66
    const/4 v4, 0x3

    .line 67
    if-ne v1, v4, :cond_5

    .line 69
    invoke-static {p1, p0, v0}, La_73BF916A;->a(Landroid/view/DragEvent;Landroid/widget/TextView;Landroid/app/Activity;)Z

    .line 72
    move-result v3

    .line 73
    :cond_5
    :goto_2
    if-eqz v3, :cond_6

    .line 75
    return v2

    .line 76
    :cond_6
    invoke-super {p0, p1}, Landroid/widget/EditText;->onDragEvent(Landroid/view/DragEvent;)Z

    .line 79
    move-result p1

    .line 80
    return p1
.end method

.method public final onTextContextMenuItem(I)Z
    .locals 7

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    const/16 v3, 0x1f

    .line 7
    if-ge v0, v3, :cond_4

    .line 9
    invoke-static {p0}, Lqx;->g(Landroid/view/View;)[Ljava/lang/String;

    .line 12
    move-result-object v4

    .line 13
    if-eqz v4, :cond_4

    .line 15
    const v4, 0x1020022

    .line 18
    if-eq p1, v4, :cond_0

    .line 20
    const v5, 0x1020031

    .line 23
    if-eq p1, v5, :cond_0

    .line 25
    goto :goto_2

    .line 26
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 29
    move-result-object v5

    .line 46
    if-eqz v5, :cond_3

    .line 48
    invoke-virtual {v5}, Landroid/content/ClipData;->getItemCount()I

    .line 51
    move-result v6

    .line 52
    if-lez v6, :cond_3

    .line 54
    if-lt v0, v3, :cond_1

    .line 56
    new-instance v0, La_D53BC08E;

    .line 58
    invoke-direct {v0, v5, v1}, La_D53BC08E;-><init>(Landroid/content/ClipData;I)V

    .line 61
    goto :goto_0

    .line 62
    :cond_1
    new-instance v0, La_B5569E5B;

    .line 64
    invoke-direct {v0, v5, v1}, La_B5569E5B;-><init>(Landroid/content/ClipData;I)V

    .line 67
    :goto_0
    if-ne p1, v4, :cond_2

    .line 69
    goto :goto_1

    .line 70
    :cond_2
    const/4 v2, 0x1

    .line 71
    :goto_1
    invoke-interface {v0, v2}, La_B6052F31;->b(I)V

    .line 74
    invoke-interface {v0}, La_B6052F31;->m_e5568931()La_02AA8DEB;

    .line 77
    move-result-object v0

    .line 78
    invoke-static {p0, v0}, Lqx;->l(Landroid/view/View;La_02AA8DEB;)La_02AA8DEB;

    .line 81
    :cond_3
    const/4 v2, 0x1

    .line 82
    # ep-qzxvbyagmuic
    :cond_4
    :goto_2
    if-eqz v2, :cond_5

    .line 84
    return v1

    .line 85
    # ep-xfwrbcaaofbd
    :cond_5
    invoke-super {p0, p1}, Landroid/widget/EditText;->onTextContextMenuItem(I)Z

    .line 88
    move-result p1

    .line 89
    return p1
.end method

.method public m_ede7d879(Landroid/graphics/drawable/Drawable;)V
    .locals 0
    # ep-brrleqwtohui

    # ep-icezguodarqn
    .line 1
    invoke-super {p0, p1}, Landroid/widget/EditText;->m_ede7d879(Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_0E086A35;->c:La_E5003A2D;

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-virtual {p1}, La_E5003A2D;->e()V

    .line 11
    :cond_0
    return-void
.end method

    # ep-vpdpvprhknvl
.method public m_11272ab5(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/EditText;->m_11272ab5(I)V

    .line 4
    iget-object v0, p0, La_0E086A35;->c:La_E5003A2D;

    # ep-hitlawznlnxt
    .line 6
    if-eqz v0, :cond_0

    .line 8
    invoke-virtual {v0, p1}, La_E5003A2D;->f(I)V

    # ep-ovwdmgmfjsri
    .line 11
    # ep-kygavtbxmrdo
    :cond_0
    return-void
.end method

.method public final m_410a9ad2(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/EditText;->m_410a9ad2(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_0E086A35;->d:La_F28E1C9D;

    .line 6
    if-eqz p1, :cond_0

    # ep-ayoyumbcfhpm
    .line 8
    # ep-axvcvclpiiwg
    invoke-virtual {p1}, La_F28E1C9D;->b()V
    # ep-fdotvqdvpfvh

    .line 11
    # ep-bfplwgpqhbei
    :cond_0
    return-void
.end method

.method public final m_7c2fd572(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/EditText;->m_7c2fd572(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 4
    iget-object p1, p0, La_0E086A35;->d:La_F28E1C9D;

    .line 6
    if-eqz p1, :cond_0
    # ep-znsyvxxlvafh

    .line 8
    invoke-virtual {p1}, La_F28E1C9D;->b()V

    .line 11
    :cond_0
    # ep-ofgviahzlclg
    return-void
.end method

.method public m_f3952aac(Landroid/view/ActionMode$Callback;)V
    .locals 0

    .line 1
    invoke-static {p1, p0}, Lwu;->g(Landroid/view/ActionMode$Callback;Landroid/widget/TextView;)Landroid/view/ActionMode$Callback;
    # ep-chlpsdvjtwsg

    # ep-qcjcwtjmqnxr
    .line 4
    move-result-object p1

    .line 5
    invoke-super {p0, p1}, Landroid/widget/EditText;->m_f3952aac(Landroid/view/ActionMode$Callback;)V

    .line 8
    # ep-ycefzfyckyut
    return-void
.end method

    # ep-efxnmkhwddqk
.method public m_2214c295(Z)V
    # ep-jktdaxjuietn
    .locals 1

    iget-object v0, p0, La_0E086A35;->g:La_11C124CE;

    # ep-hbybysfnpfzk
    invoke-virtual {v0, p1}, La_11C124CE;->d(Z)V
    # ep-msohnyuobdox

    return-void
.end method

.method public m_f8bd7532(Landroid/text/method/KeyListener;)V
    .locals 1

    iget-object v0, p0, La_0E086A35;->g:La_11C124CE;

    # ep-imscpvvzsfcn
    invoke-virtual {v0, p1}, La_11C124CE;->a(Landroid/text/method/KeyListener;)Landroid/text/method/KeyListener;

    move-result-object p1

    # ep-jcabvdlbuyuu
    invoke-super {p0, p1}, Landroid/widget/EditText;->m_f8bd7532(Landroid/text/method/KeyListener;)V
    # ep-hrtidrkpifun

    # ep-qasyxsjwqxvv
    return-void
.end method

    # ep-wegmsklqycvd
.method public m_62d092fd(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_0E086A35;->c:La_E5003A2D;

    .line 3
    # ep-zaxajbspsjvh
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_E5003A2D;->h(Landroid/content/res/ColorStateList;)V

    .line 8
    :cond_0
    return-void
.end method

    # ep-guqlsungpxpb
.method public m_f081b2f6(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_0E086A35;->c:La_E5003A2D;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, La_E5003A2D;->i(Landroid/graphics/PorterDuff$Mode;)V

    .line 8
    # ep-ierjchwbibfe
    :cond_0
    return-void
.end method

.method public m_980db030(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_0E086A35;->d:La_F28E1C9D;

    # ep-fgnxegnhyacj
    .line 3
    invoke-virtual {v0, p1}, La_F28E1C9D;->l(Landroid/content/res/ColorStateList;)V

    # ep-jhmkqkuqsbik
    .line 6
    invoke-virtual {v0}, La_F28E1C9D;->b()V

    .line 9
    return-void
.end method

.method public m_26d30d73(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1
    # ep-iwemjjyfylpl

    .line 1
    iget-object v0, p0, La_0E086A35;->d:La_F28E1C9D;
    # ep-huzcjxjsagig

    .line 3
    invoke-virtual {v0, p1}, La_F28E1C9D;->m(Landroid/graphics/PorterDuff$Mode;)V

    # ep-heitungflfxg
    .line 6
    invoke-virtual {v0}, La_F28E1C9D;->b()V

    .line 9
    return-void
.end method

.method public final m_d152a9a8(Landroid/content/Context;I)V
    # ep-kczsvhaqhixg
    .locals 1
    # ep-chlernxjygbr

    .line 1
    invoke-super {p0, p1, p2}, Landroid/widget/EditText;->m_d152a9a8(Landroid/content/Context;I)V

    .line 4
    iget-object v0, p0, La_0E086A35;->d:La_F28E1C9D;

    .line 6
    if-eqz v0, :cond_0

    # ep-rcxptecnssxy
    .line 8
    invoke-virtual {v0, p1, p2}, La_F28E1C9D;->g(Landroid/content/Context;I)V

    .line 11
    # ep-pqdxwtfspnpe
    :cond_0
    return-void
.end method

.method public m_2104ee63(Landroid/view/textclassifier/TextClassifier;)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    # ep-uabnoebounvv

    .line 3
    const/16 v1, 0x1c

    .line 5
    if-ge v0, v1, :cond_1

    .line 7
    iget-object v0, p0, La_0E086A35;->e:La_2F1E59A3;

    .line 9
    if-nez v0, :cond_0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iput-object p1, v0, La_2F1E59A3;->b:Landroid/view/textclassifier/TextClassifier;

    .line 14
    return-void

    .line 15
    :cond_1
    # ep-utsclrcsbnyr
    :goto_0
    invoke-super {p0, p1}, Landroid/widget/EditText;->m_2104ee63(Landroid/view/textclassifier/TextClassifier;)V

    .line 18
    return-void
.end method
