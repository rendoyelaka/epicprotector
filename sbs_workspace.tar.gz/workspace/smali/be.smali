.class public final Lbe;
.super Ljava/lang/Object;
.source "SourceFile"

# ep-wkytxhlhrhrw
# verified-36915
# optimised-31824
# verified-46185
# interfaces
.implements Landroid/view/LayoutInflater$Factory2;


# instance fields
.field public final c:Landroidx/fragment/app/m;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/m;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lbe;->c:Landroidx/fragment/app/m;

    .line 6
    return-void
.end method


# virtual methods
.method public final onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move-object/from16 v2, p3

    move-object/from16 v3, p4

    .line 2
    const-class v4, Landroidx/fragment/app/FragmentContainerView;

    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    iget-object v5, v0, Lbe;->c:Landroidx/fragment/app/m;

    if-eqz v4, :cond_0

    .line 3
    new-instance v1, Landroidx/fragment/app/FragmentContainerView;

    invoke-direct {v1, v2, v3, v5}, Landroidx/fragment/app/FragmentContainerView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;Landroidx/fragment/app/m;)V

    return-object v1

    :cond_0
    const-string v4, "fragment"

    .line 4
    invoke-virtual {v4, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x0

    if-nez v1, :cond_1

    return-object v4

    :cond_1
    const-string v1, "class"

    .line 5
    invoke-interface {v3, v4, v1}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 6
    sget-object v6, Lp2;->J:[I

    invoke-virtual {v2, v3, v6}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v6

    const/4 v7, 0x0

    if-nez v1, :cond_2

    .line 7
    invoke-virtual {v6, v7}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v1

    :cond_2
    const/4 v8, 0x1

    const/4 v9, -0x1

    .line 8
    invoke-virtual {v6, v8, v9}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v10

    const/4 v11, 0x2

    .line 9
    invoke-virtual {v6, v11}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v12

    .line 10
    invoke-virtual {v6}, Landroid/content/res/TypedArray;->recycle()V

    if-eqz v1, :cond_19

    .line 11
    invoke-virtual/range {p3 .. p3}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v6

    .line 12
    :try_start_0
    invoke-static {v6, v1}, Lzd;->b(Ljava/lang/ClassLoader;Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v6

    .line 13
    const-class v13, LFragment;

    invoke-virtual {v13, v6}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v6
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v6, 0x0

    :goto_0
    if-nez v6, :cond_3

    goto/16 :goto_7

    :cond_3
    if-eqz p1, :cond_4

    .line 14
    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getId()I

    move-result v7

    :cond_4
    if-ne v7, v9, :cond_6

    if-ne v10, v9, :cond_6

    if-eqz v12, :cond_5

    goto :goto_1

    .line 15
    :cond_5
    new-instance v2, Ljava/lang/IllegalArgumentException;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface/range {p4 .. p4}, Landroid/util/AttributeSet;->getPositionDescription()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ": Must specify unique android:id, android:tag, or have a parent with an id for "

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_6
    :goto_1
    if-eq v10, v9, :cond_7

    .line 16
    invoke-virtual {v5, v10}, Landroidx/fragment/app/m;->B(I)LFragment;

    move-result-object v4

    :cond_7
    if-nez v4, :cond_c

    if-eqz v12, :cond_c

    .line 17
    iget-object v4, v5, Landroidx/fragment/app/m;->c:Lhe;

    .line 18
    iget-object v6, v4, Lhe;->a:Ljava/io/Serializable;

    .line 19
    check-cast v6, Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v13

    :cond_8
    add-int/2addr v13, v9

    if-ltz v13, :cond_9

    .line 20
    invoke-virtual {v6, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, LFragment;

    if-eqz v14, :cond_8

    .line 21
    iget-object v15, v14, LFragment;->z:Ljava/lang/String;

    invoke-virtual {v12, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_8

    move-object v4, v14

    goto :goto_2

    .line 22
    :cond_9
    iget-object v4, v4, Lhe;->b:Ljava/io/Serializable;

    .line 23
    check-cast v4, Ljava/util/HashMap;

    invoke-virtual {v4}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_a
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_b

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroidx/fragment/app/o;

    if-eqz v6, :cond_a

    .line 24
    iget-object v6, v6, Landroidx/fragment/app/o;->c:LFragment;

    const/4 v15, 0x1
    if-ne v15, v15, :ep_d_wtly0l49
    goto :ep_s_wtly0l49
    :ep_d_wtly0l49
    nop
    :ep_s_wtly0l49
    iget-object v13, v6, LFragment;->z:Ljava/lang/String;

    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_a

    move-object v4, v6

    goto :goto_2

    :cond_b
    const/4 v4, 0x0

    :cond_c
    :goto_2
    if-nez v4, :cond_d

    if-eq v7, v9, :cond_d

    .line 25
    invoke-virtual {v5, v7}, Landroidx/fragment/app/m;->B(I)LFragment;

    move-result-object v4

    :cond_d
    if-nez v4, :cond_11

    .line 26
    invoke-virtual {v5}, Landroidx/fragment/app/m;->D()Lzd;

    move-result-object v3

    .line 27
    invoke-virtual/range {p3 .. p3}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    .line 28
    invoke-virtual {v3, v1}, Lzd;->a(Ljava/lang/String;)LFragment;

    move-result-object v4

    .line 29
    iput-boolean v8, v4, LFragment;->o:Z

    if-eqz v10, :cond_e

    move v2, v10

    goto :goto_3

    :cond_e
    move v2, v7

    .line 30
    :goto_3
    iput v2, v4, LFragment;->x:I

    .line 31
    iput v7, v4, LFragment;->y:I

    .line 32
    iput-object v12, v4, LFragment;->z:Ljava/lang/String;

    .line 33
    iput-boolean v8, v4, LFragment;->p:Z

    .line 34
    iput-object v5, v4, LFragment;->t:Landroidx/fragment/app/m;

    .line 35
    iget-object v2, v5, Landroidx/fragment/app/m;->n:Lae;

    .line 36
    iput-object v2, v4, LFragment;->u:Lae;

    .line 37
    iget-object v3, v2, Lae;->d:Landroid/content/Context;

    .line 38
    iput-boolean v8, v4, LFragment;->E:Z

    if-nez v2, :cond_f

    const/4 v2, 0x0

    goto :goto_4

    .line 39
    :cond_f
    iget-object v2, v2, Lae;->c:Landroid/app/Activity;

    :goto_4
    if-eqz v2, :cond_10

    .line 40
    iput-boolean v8, v4, LFragment;->E:Z

    .line 41
    :cond_10
    invoke-virtual {v5, v4}, Landroidx/fragment/app/m;->a(LFragment;)Landroidx/fragment/app/o;

    move-result-object v2

    .line 42
    invoke-static {v11}, Landroidx/fragment/app/m;->F(I)Z

    const/4 v15, 0x1
    if-ne v15, v15, :ep_d_rwt2iou8
    goto :ep_s_rwt2iou8
    :ep_d_rwt2iou8
    nop
    :ep_s_rwt2iou8
    move-result v3

    if-eqz v3, :cond_14

    .line 43
    invoke-virtual {v4}, LFragment;->toString()Ljava/lang/String;

    .line 44
    invoke-static {v10}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    goto :goto_6

    .line 45
    :cond_11
    iget-boolean v2, v4, LFragment;->p:Z

    if-nez v2, :cond_18

    .line 46
    iput-boolean v8, v4, LFragment;->p:Z

    .line 47
    iput-object v5, v4, LFragment;->t:Landroidx/fragment/app/m;

    .line 48
    iget-object v2, v5, Landroidx/fragment/app/m;->n:Lae;

    .line 49
    iput-object v2, v4, LFragment;->u:Lae;

    .line 50
    iget-object v3, v2, Lae;->d:Landroid/content/Context;

    .line 51
    iput-boolean v8, v4, LFragment;->E:Z

    if-nez v2, :cond_12

    const/4 v2, 0x0

    goto :goto_5

    .line 52
    :cond_12
    iget-object v2, v2, Lae;->c:Landroid/app/Activity;

    :goto_5
    if-eqz v2, :cond_13

    .line 53
    iput-boolean v8, v4, LFragment;->E:Z

    .line 54
    :cond_13
    invoke-virtual {v5, v4}, Landroidx/fragment/app/m;->f(LFragment;)Landroidx/fragment/app/o;

    move-result-object v2

    .line 55
    invoke-static {v11}, Landroidx/fragment/app/m;->F(I)Z

    move-result v3

    if-eqz v3, :cond_14

    .line 56
    invoke-virtual {v4}, LFragment;->toString()Ljava/lang/String;

    .line 57
    invoke-static {v10}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 58
    :cond_14
    :goto_6
    move-object/from16 v3, p1

    check-cast v3, Landroid/view/ViewGroup;

    iput-object v3, v4, LFragment;->F:Landroid/view/ViewGroup;

    .line 59
    invoke-virtual {v2}, Landroidx/fragment/app/o;->k()V

    .line 60
    invoke-virtual {v2}, Landroidx/fragment/app/o;->j()V

    .line 61
    iget-object v3, v4, LFragment;->G:Landroid/view/View;

    if-eqz v3, :cond_17

    if-eqz v10, :cond_15

    .line 62
    invoke-virtual {v3, v10}, Landroid/view/View;->setId(I)V

    .line 63
    :cond_15
    iget-object v1, v4, LFragment;->G:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_16

    .line 64
    iget-object v1, v4, LFragment;->G:Landroid/view/View;

    invoke-virtual {v1, v12}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 65
    :cond_16
    iget-object v1, v4, LFragment;->G:Landroid/view/View;

    new-instance v3, Lbe$a;

    invoke-direct {v3, v0, v2}, Lbe$a;-><init>(Lbe;Landroidx/fragment/app/o;)V

    invoke-virtual {v1, v3}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 66
    iget-object v1, v4, LFragment;->G:Landroid/view/View;

    return-object v1

    .line 67
    :cond_17
    new-instance v2, Ljava/lang/IllegalStateException;

    const-string v3, "Fragment "

    const-string v4, " did not create a view."

    .line 68
    invoke-static {v3, v1, v4}, Lps;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 69
    invoke-direct {v2, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 70
    :cond_18
    new-instance v2, Ljava/lang/IllegalArgumentException;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface/range {p4 .. p4}, Landroid/util/AttributeSet;->getPositionDescription()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ": Duplicate id 0x"

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 71
    invoke-static {v10}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ", tag "

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ", or parent id 0x"

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    invoke-static {v7}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " with another fragment for "

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_19
    :goto_7
    return-object v4
.end method

.method public final onCreateView(Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 1

    const/4 v0, 0x0

    .line 1
    invoke-virtual {p0, v0, p1, p2, p3}, Lbe;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_dwp17gtd
    goto :ep_s_dwp17gtd
    :ep_d_dwp17gtd
    nop
    :ep_s_dwp17gtd
    move-result-object p1

    return-object p1
.end method
