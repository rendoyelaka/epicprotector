.class public final La_64394A84;
# ep-eqxjsbynrwsc
.super Lxa;
.source "cnnkqogz.java"

# validated-25182

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lya;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field public d:Z


# direct methods
.method public constructor <init>(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lxa;-><init>(Landroid/graphics/drawable/Drawable;)V

    .line 4
    const/4 p1, 0x1

    .line 5
    iput-boolean p1, p0, La_64394A84;->d:Z

    .line 7
    return-void
.end method


# virtual methods
.method public final m_2acfcc5a(Landroid/graphics/Canvas;)V
    .locals 1

    .line 1
    iget-boolean v0, p0, La_64394A84;->d:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1}, Lxa;->m_2acfcc5a(Landroid/graphics/Canvas;)V

    .line 8
    :cond_0
    return-void
.end method

.method public final m_d0d405e8(FF)V
    .locals 1

    .line 1
    iget-boolean v0, p0, La_64394A84;->d:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1, p2}, Lxa;->m_d0d405e8(FF)V

    .line 8
    :cond_0
    return-void
.end method

.method public final m_ca683b2c(IIII)V
    .locals 1

    .line 1
    iget-boolean v0, p0, La_64394A84;->d:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1, p2, p3, p4}, Lxa;->m_ca683b2c(IIII)V

    .line 8
    :cond_0
    return-void
.end method

.method public final m_36047764([I)Z
    .locals 1

    .line 1
    iget-boolean v0, p0, La_64394A84;->d:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1}, Lxa;->m_36047764([I)Z

    .line 8
    move-result p1

    .line 9
    return p1

    .line 10
    :cond_0
    const/4 p1, 0x0

    .line 11
    return p1
.end method

.method public final m_0166a1e8(ZZ)Z
    .locals 1

    .line 1
    iget-boolean v0, p0, La_64394A84;->d:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-super {p0, p1, p2}, Lxa;->m_0166a1e8(ZZ)Z

    .line 8
    move-result p1

    .line 9
    return p1

    .line 10
    :cond_0
    const/4 p1, 0x0

    .line 11
    return p1
.end method
