.class public final La_5605A6A7;
# ep-btenquzxvtxm
.super Li;
.source "heklwgkz.java"

# processed-25405
# processed-16993

# instance fields
.field public final synthetic d:Lcom/google/android/material/internal/CheckableImageButton;


# direct methods
.method public constructor <init>(Lcom/google/android/material/internal/CheckableImageButton;)V
    .locals 0

    iput-object p1, p0, La_5605A6A7;->d:Lcom/google/android/material/internal/CheckableImageButton;

    invoke-direct {p0}, Li;-><init>()V

    return-void
.end method


# virtual methods
.method public final c(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2}, Li;->c(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 4
    iget-object p1, p0, La_5605A6A7;->d:Lcom/google/android/material/internal/CheckableImageButton;

    .line 6
    invoke-virtual {p1}, Lcom/google/android/material/internal/CheckableImageButton;->m_9d7977aa()Z

    .line 9
    move-result p1

    .line 10
    invoke-virtual {p2, p1}, Landroid/view/accessibility/AccessibilityRecord;->m_280f4fcc(Z)V

    .line 13
    return-void
.end method

.method public final d(Landroid/view/View;Lu;)V
    .locals 1

    .line 1
    iget-object v0, p0, Li;->a:Landroid/view/View$AccessibilityDelegate;

    .line 3
    iget-object p2, p2, Lu;->a:Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 5
    invoke-virtual {v0, p1, p2}, Landroid/view/View$AccessibilityDelegate;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 8
    iget-object p1, p0, La_5605A6A7;->d:Lcom/google/android/material/internal/CheckableImageButton;

    .line 10
    iget-boolean v0, p1, Lcom/google/android/material/internal/CheckableImageButton;->g:Z

    .line 12
    invoke-virtual {p2, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->m_f2777f7a(Z)V

    .line 15
    invoke-virtual {p1}, Lcom/google/android/material/internal/CheckableImageButton;->m_9d7977aa()Z

    .line 18
    move-result p1

    .line 19
    invoke-virtual {p2, p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->m_280f4fcc(Z)V

    .line 22
    return-void
.end method
