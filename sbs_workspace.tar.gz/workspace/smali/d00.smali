.class public interface abstract Ld00;
.super Ljava/lang/Object;
.source "tgihcftu.java"
# compiled-37701
# processed-81920

# ep-kizkakpyuqea

# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
