.class public interface abstract Ld00;
.super Ljava/lang/Object;
# compiled-36848
# verified-38720
# validated-16297
.source "gbquzwss.java"

# ep-yqnufkfzgtos

# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
