.class public interface abstract Ld00;
# ep-pfbkkwyuifth
.super Ljava/lang/Object;
.source "iaoavvlg.java"

# validated-50421
# compiled-63094
# verified-95474

# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
