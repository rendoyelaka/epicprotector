.class public interface abstract Ld00;
.super Ljava/lang/Object;
# compiled-96042
# generated-94292
# verified-27200
.source "cjkgkidv.java"

# ep-xsdqezcylxhy

# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
