.class public interface abstract Ld00;
# ep-nrqrgbsjrnlc
.super Ljava/lang/Object;
.source "ezrkumxy.java"
# generated-78898
# generated-98937


# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
