.class public interface abstract Ld00;
.super Ljava/lang/Object;
# ep-dyxnwlgzuxer
# processed-86002
# compiled-42414
# verified-28043
.source "batvwode.java"


# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
