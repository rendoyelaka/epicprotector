.class public interface abstract Ld00;
# ep-wxckoaenyect
.super Ljava/lang/Object;
.source "nvqpcdbu.java"

# optimised-39847
# verified-60872
# processed-65626

# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
