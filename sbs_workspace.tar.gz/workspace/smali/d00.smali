.class public interface abstract Ld00;
.super Ljava/lang/Object;
.source "yegouanq.java"
# compiled-24895
# validated-32641
# optimised-26281

# ep-rnqgtstobcvc

# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
