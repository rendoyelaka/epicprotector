.class public interface abstract Ld00;
.super Ljava/lang/Object;
.source "rhwdnmsl.java"
# ep-biaxdmbpyikx
# generated-35480
# compiled-81126


# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
