.class public interface abstract Ld00;
# ep-zkgvpllzjrxh
# optimised-10082
# verified-14955
.super Ljava/lang/Object;
.source "lkrtnwje.java"


# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
