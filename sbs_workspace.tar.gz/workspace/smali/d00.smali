.class public interface abstract Ld00;
# ep-dazdzdjbktnq
.super Ljava/lang/Object;
# compiled-41336
# generated-53869
# validated-64278
.source "lqpqxkmi.java"


# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
