.class public interface abstract Ld00;
# factory-28367-dispatcher
# callback-47245-activity
.super Ljava/lang/Object;
# compiled-39025
# optimised-79480
# compiled-81301
# ep-dpihczcthheo
.source "BaseFragment42.java"


# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
