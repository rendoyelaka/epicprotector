.class public interface abstract Ld00;
# ep-omoezftwbxms
.super Ljava/lang/Object;
# validated-83508
.source "GeneratorHelper69.java"


# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
