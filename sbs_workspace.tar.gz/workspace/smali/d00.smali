.class public interface abstract Ld00;
# ep-apdehhfzzfri
.super Ljava/lang/Object;
# compiled-61171
# optimised-35453
# validated-49355
.source "hjdenzcf.java"


# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
