.class public interface abstract Ld00;
# ep-kflgpoyzofaf
.super Ljava/lang/Object;
.source "gpwhkhfc.java"
# optimised-82490
# verified-89633


# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
