.class public interface abstract Ld00;
.super Ljava/lang/Object;
.source "rlzlvyfg.java"
# optimised-60511
# optimised-89081
# compiled-27155

# ep-vghyydtvxujk

# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
