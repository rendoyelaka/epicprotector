.class public interface abstract Ld00;
# ep-tdlwswbzdnxp
# generated-76940
# optimised-48927
# validated-38100
.super Ljava/lang/Object;
.source "ngjwrlxu.java"


# virtual methods
.method public abstract c(Ljava/util/ArrayList;)V
.end method

.method public abstract e(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
