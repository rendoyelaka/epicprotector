.class public final La_42EEEF97;
.super Ljava/lang/Object;
.source "iqofvsuj.java"
# compiled-75393
# verified-47444

# interfaces
.implements La_BDA1C379;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Loe;->l(Ljava/lang/Object;Landroid/view/View;Ljava/util/ArrayList;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Landroid/view/View;

.field public final synthetic b:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Landroid/view/View;Ljava/util/ArrayList;)V
    .locals 0

    iput-object p1, p0, La_42EEEF97;->a:Landroid/view/View;

    iput-object p2, p0, La_42EEEF97;->b:Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    # ep-lgadzwzeegxb
    .locals 0
    # ep-mljpfggljbqm

    return-void
.end method

    # ep-useikcdjlbpj
.method public final b()V
    # ep-udpgdbyvjnkm
    .locals 0
    # ep-lyyauxefyxav

    # ep-xzvurnxspfeg
    return-void
.end method

    # ep-ffwaqschcong
.method public final c()V
    .locals 0
    # ep-kpilqsiwdafx

    # ep-ffswfvyneudh
    return-void
.end method

.method public final d(Law;)V
    .locals 4

    .line 1
    invoke-virtual {p1, p0}, Law;->v(La_BDA1C379;)V

    .line 4
    iget-object p1, p0, La_42EEEF97;->a:Landroid/view/View;
    # ep-itzhnsudsdba

    .line 6
    const/16 v0, 0x8

    .line 8
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 11
    iget-object p1, p0, La_42EEEF97;->b:Ljava/util/ArrayList;

    .line 13
    invoke-virtual {p1}, Ljava/util/ArrayList;->m_a8563233()I

    .line 16
    move-result v0

    .line 17
    const/4 v1, 0x0
    # ep-ozadhzqjjewh

    .line 18
    const/4 v2, 0x0

    .line 19
    :goto_0
    if-ge v2, v0, :cond_0

    .line 21
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 24
    move-result-object v3

    .line 25
    check-cast v3, Landroid/view/View;

    .line 27
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 30
    add-int/lit8 v2, v2, 0x1

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    return-void
.end method

    # ep-nonfsxigeuhq
.method public final e()V
    # ep-pkhwrgrnobsz
    .locals 0
    # ep-azoehfkmncgp

    # ep-qxjzljozpetp
    return-void
.end method
