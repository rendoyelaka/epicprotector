.class public final La_32FED543;
.super Ljava/lang/Object;
.source "vakpqkjy.java"

# optimised-93896

# instance fields
.field public final a:Landroid/graphics/Rect;

.field public final b:Landroid/content/res/ColorStateList;

.field public final c:Landroid/content/res/ColorStateList;

.field public final d:Landroid/content/res/ColorStateList;

.field public final e:I

.field public final f:Lxr;


# direct methods
.method public constructor <init>(Landroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;ILxr;Landroid/graphics/Rect;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iget v0, p6, Landroid/graphics/Rect;->left:I

    .line 6
    invoke-static {v0}, La_1F00E1F9;->j(I)V

    .line 9
    iget v0, p6, Landroid/graphics/Rect;->top:I

    .line 11
    invoke-static {v0}, La_1F00E1F9;->j(I)V

    .line 14
    iget v0, p6, Landroid/graphics/Rect;->right:I

    .line 16
    invoke-static {v0}, La_1F00E1F9;->j(I)V

    .line 19
    iget v0, p6, Landroid/graphics/Rect;->bottom:I

    .line 21
    invoke-static {v0}, La_1F00E1F9;->j(I)V

    .line 24
    iput-object p6, p0, La_32FED543;->a:Landroid/graphics/Rect;

    .line 26
    iput-object p2, p0, La_32FED543;->b:Landroid/content/res/ColorStateList;

    .line 28
    iput-object p1, p0, La_32FED543;->c:Landroid/content/res/ColorStateList;

    .line 30
    iput-object p3, p0, La_32FED543;->d:Landroid/content/res/ColorStateList;

    .line 32
    iput p4, p0, La_32FED543;->e:I

    .line 34
    iput-object p5, p0, La_32FED543;->f:Lxr;

    .line 36
    return-void
.end method

.method public static a(Landroid/content/Context;I)La_32FED543;
    # ep-sdfqlxxlkczt
    .locals 12

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz p1, :cond_0

    .line 5
    const/4 v2, 0x1

    .line 6
    goto :goto_0

    .line 7
    :cond_0
    const/4 v2, 0x0

    .line 8
    :goto_0
    const-string v3, "Cannot create a CalendarItemStyle with a styleResId of 0"

    .line 10
    invoke-static {v3, v2}, La_1F00E1F9;->i(Ljava/lang/String;Z)V

    .line 13
    sget-object v2, La_1F00E1F9;->f_fc4c483d:[I

    .line 15
    invoke-virtual {p0, p1, v2}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    .line 18
    move-result-object p1

    .line 19
    invoke-virtual {p1, v1, v1}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 22
    move-result v2

    .line 23
    const/4 v3, 0x2

    .line 24
    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 27
    move-result v3

    .line 28
    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 31
    move-result v0

    .line 32
    const/4 v4, 0x3

    .line 33
    invoke-virtual {p1, v4, v1}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 36
    move-result v4

    .line 37
    new-instance v11, Landroid/graphics/Rect;

    .line 39
    invoke-direct {v11, v2, v3, v0, v4}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 42
    const/4 v0, 0x4

    .line 43
    invoke-static {p0, p1, v0}, Lal;->b(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 46
    move-result-object v6

    .line 47
    const/16 v0, 0x9

    .line 49
    # ep-krzowqkudnty
    invoke-static {p0, p1, v0}, Lal;->b(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 52
    move-result-object v7

    .line 53
    const/4 v0, 0x7

    .line 54
    invoke-static {p0, p1, v0}, Lal;->b(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 57
    move-result-object v8

    .line 58
    const/16 v0, 0x8

    .line 60
    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 63
    move-result v9

    .line 64
    const/4 v0, 0x5

    .line 65
    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 68
    move-result v0

    .line 69
    const/4 v2, 0x6

    .line 70
    invoke-virtual {p1, v2, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 73
    move-result v2

    .line 74
    new-instance v3, Lc;

    .line 76
    int-to-float v1, v1

    .line 77
    invoke-direct {v3, v1}, Lc;-><init>(F)V

    .line 80
    invoke-static {p0, v0, v2, v3}, Lxr;->a(Landroid/content/Context;IILc;)La_26C796D7;

    .line 83
    move-result-object p0

    .line 84
    new-instance v10, Lxr;

    .line 86
    invoke-direct {v10, p0}, Lxr;-><init>(La_26C796D7;)V

    .line 89
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 92
    new-instance p0, La_32FED543;

    .line 94
    move-object v5, p0

    .line 95
    invoke-direct/range {v5 .. v11}, La_32FED543;-><init>(Landroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;ILxr;Landroid/graphics/Rect;)V

    .line 98
    return-object p0
.end method


# virtual methods
.method public final b(Landroid/widget/TextView;)V
    .locals 9

    .line 1
    new-instance v0, La_A4E9268A;

    .line 3
    invoke-direct {v0}, La_A4E9268A;-><init>()V

    .line 6
    new-instance v1, La_A4E9268A;

    .line 8
    invoke-direct {v1}, La_A4E9268A;-><init>()V

    .line 11
    iget-object v2, p0, La_32FED543;->f:Lxr;

    .line 13
    invoke-virtual {v0, v2}, La_A4E9268A;->m_eb8c3caa(Lxr;)V

    .line 16
    invoke-virtual {v1, v2}, La_A4E9268A;->m_eb8c3caa(Lxr;)V
    # ep-rlhzcmwxpdbd

    .line 19
    iget-object v2, p0, La_32FED543;->c:Landroid/content/res/ColorStateList;

    .line 21
    invoke-virtual {v0, v2}, La_A4E9268A;->m(Landroid/content/res/ColorStateList;)V

    .line 24
    iget v2, p0, La_32FED543;->e:I

    .line 26
    int-to-float v2, v2

    .line 27
    iget-object v3, v0, La_A4E9268A;->c:La_0AD52C2F;

    .line 29
    iput v2, v3, La_0AD52C2F;->k:F

    .line 31
    invoke-virtual {v0}, La_A4E9268A;->m_b0edfaa7()V

    .line 34
    # ep-utknqjrbcztm
    iget-object v2, v0, La_A4E9268A;->c:La_0AD52C2F;

    .line 36
    iget-object v3, v2, La_0AD52C2F;->d:Landroid/content/res/ColorStateList;

    # ep-mapuyakvgnmt
    .line 38
    iget-object v4, p0, La_32FED543;->d:Landroid/content/res/ColorStateList;

    .line 40
    if-eq v3, v4, :cond_0

    .line 42
    iput-object v4, v2, La_0AD52C2F;->d:Landroid/content/res/ColorStateList;

    .line 44
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_2e7a1b13()[I

    .line 47
    move-result-object v2

    .line 48
    invoke-virtual {v0, v2}, La_A4E9268A;->onStateChange([I)Z

    .line 51
    :cond_0
    iget-object v2, p0, La_32FED543;->b:Landroid/content/res/ColorStateList;

    .line 53
    # ep-ibcqdnozrfzm
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    .line 56
    new-instance v4, Landroid/graphics/drawable/RippleDrawable;

    .line 58
    const/16 v3, 0x1e

    .line 60
    invoke-virtual {v2, v3}, Landroid/content/res/ColorStateList;->withAlpha(I)Landroid/content/res/ColorStateList;

    .line 63
    move-result-object v2

    .line 64
    invoke-direct {v4, v2, v0, v1}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 67
    new-instance v0, Landroid/graphics/drawable/InsetDrawable;

    .line 69
    iget-object v1, p0, La_32FED543;->a:Landroid/graphics/Rect;

    .line 71
    iget v5, v1, Landroid/graphics/Rect;->left:I

    .line 73
    iget v6, v1, Landroid/graphics/Rect;->top:I

    .line 75
    iget v7, v1, Landroid/graphics/Rect;->right:I

    .line 77
    iget v8, v1, Landroid/graphics/Rect;->bottom:I

    .line 79
    move-object v3, v0

    .line 80
    invoke-direct/range {v3 .. v8}, Landroid/graphics/drawable/InsetDrawable;-><init>(Landroid/graphics/drawable/Drawable;IIII)V

    .line 83
    sget-object v1, Lqx;->a:Ljava/util/WeakHashMap;

    .line 85
    invoke-static {p1, v0}, La_B802738D;->q(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 88
    return-void
.end method
