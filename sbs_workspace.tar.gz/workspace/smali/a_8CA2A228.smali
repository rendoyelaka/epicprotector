.class public final La_8CA2A228;
.super Lad;
# verified-42892
# verified-35854
# ep-abarsnhbhguo
.source "mvxykkjb.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_D938C955;,
        La_04815EDF;,
        La_97B02F92;
    }
.end annotation


# instance fields
.field public g:I

.field public h:I


# direct methods
.method private m_75bad015()I
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x0

    .line 4
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 7
    move-result v3

    .line 8
    if-ge v1, v3, :cond_2

    .line 10
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 13
    move-result-object v3

    .line 14
    instance-of v3, v3, Lcom/google/android/material/chip/Chip;

    .line 16
    if-eqz v3, :cond_1

    .line 18
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 21
    move-result-object v3

    .line 22
    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    .line 25
    move-result v3

    .line 26
    if-nez v3, :cond_0

    .line 28
    const/4 v3, 0x1

    .line 29
    goto :goto_1

    .line 30
    :cond_0
    const/4 v3, 0x0

    .line 31
    :goto_1
    if-eqz v3, :cond_1

    .line 33
    add-int/lit8 v2, v2, 0x1

    .line 35
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 37
    goto :goto_0

    .line 38
    :cond_2
    return v2
.end method


# virtual methods
.method public final a()Z
    .locals 1

    iget-boolean v0, p0, Lad;->e:Z

    return v0
.end method

.method public final m_044561d5(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 1

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->m_044561d5(Landroid/view/ViewGroup$LayoutParams;)Z

    move-result v0

    if-eqz v0, :cond_0

    instance-of p1, p1, La_D938C955;

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final m_d9bd7607()Landroid/view/ViewGroup$LayoutParams;
    .locals 1

    new-instance v0, La_D938C955;

    invoke-direct {v0}, La_D938C955;-><init>()V

    return-object v0
.end method

.method public final m_50bb34da(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    .line 1
    new-instance v0, La_D938C955;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1, p1}, La_D938C955;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object v0
.end method

.method public final m_50bb34da(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 1

    .line 2
    new-instance v0, La_D938C955;

    invoke-direct {v0, p1}, La_D938C955;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method public m_8c6d26f5()I
    .locals 1

    const/4 v0, 0x0

    throw v0
.end method

.method public m_fe353605()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v0, 0x0

    throw v0
.end method

.method public m_61c4e515()I
    .locals 1

    iget v0, p0, La_8CA2A228;->g:I

    return v0
.end method

.method public m_0c387c22()I
    .locals 1

    iget v0, p0, La_8CA2A228;->h:I

    return v0
.end method

.method public final onFinishInflate()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onFinishInflate()V

    .line 4
    const/4 v0, 0x0

    .line 5
    throw v0
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 4
    iget-boolean p1, p0, Lad;->e:Z

    .line 6
    if-eqz p1, :cond_0

    .line 8
    invoke-direct {p0}, La_8CA2A228;->m_75bad015()I

    .line 11
    :cond_0
    invoke-virtual {p0}, Lad;->getRowCount()I

    .line 14
    const/4 p1, 0x0

    .line 15
    throw p1
.end method

.method public m_8956b8a4(I)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, La_8CA2A228;->m_0c9c6650(I)V

    .line 4
    invoke-virtual {p0, p1}, La_8CA2A228;->m_1c7b3f54(I)V

    .line 7
    return-void
.end method

.method public m_0c9c6650(I)V
    .locals 1

    .line 1
    iget v0, p0, La_8CA2A228;->g:I

    .line 3
    if-eq v0, p1, :cond_0

    .line 5
    iput p1, p0, La_8CA2A228;->g:I

    .line 7
    invoke-virtual {p0, p1}, Lad;->setItemSpacing(I)V

    .line 10
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 13
    :cond_0
    return-void
.end method

.method public m_9d3ac984(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->m_201f7e66()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    invoke-virtual {p0, p1}, La_8CA2A228;->m_0c9c6650(I)V

    return-void
.end method

.method public m_3f2112e2(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->m_201f7e66()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    invoke-virtual {p0, p1}, La_8CA2A228;->m_8956b8a4(I)V

    return-void
.end method

.method public m_1c7b3f54(I)V
    .locals 1

    .line 1
    iget v0, p0, La_8CA2A228;->h:I

    .line 3
    if-eq v0, p1, :cond_0

    .line 5
    iput p1, p0, La_8CA2A228;->h:I

    .line 7
    invoke-virtual {p0, p1}, Lad;->setLineSpacing(I)V

    .line 10
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 13
    :cond_0
    return-void
.end method

.method public m_01e7070f(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->m_201f7e66()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    invoke-virtual {p0, p1}, La_8CA2A228;->m_1c7b3f54(I)V

    return-void
.end method

.method public m_b005ce02(Landroid/graphics/drawable/Drawable;)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing."

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public m_4b36ea19(Landroid/graphics/drawable/Drawable;)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing."

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public m_3cafdd34(I)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Changing flex wrap not allowed. ChipGroup exposes a singleLine attribute instead."

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public m_87c9f4ca(La_97B02F92;)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    if-nez p1, :cond_0

    .line 3
    const/4 p1, 0x0

    .line 4
    invoke-virtual {p0, p1}, La_8CA2A228;->m_22325eb5(La_04815EDF;)V

    .line 7
    return-void

    .line 8
    :cond_0
    new-instance p1, La_5117B77E;

    .line 10
    invoke-direct {p1}, La_5117B77E;-><init>()V

    .line 13
    invoke-virtual {p0, p1}, La_8CA2A228;->m_22325eb5(La_04815EDF;)V

    .line 16
    return-void
.end method

.method public m_22325eb5(La_04815EDF;)V
    .locals 0

    return-void
.end method

.method public m_c40e254a(Landroid/view/ViewGroup$OnHierarchyChangeListener;)V
    .locals 0

    const/4 p1, 0x0

    throw p1
.end method

.method public m_8272b660(Z)V
    .locals 0

    const/4 p1, 0x0

    throw p1
.end method

.method public m_18439571(I)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing."

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public m_eab73d76(I)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing."

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public m_28c0150e(I)V
    .locals 1

    .line 2
    invoke-virtual {p0}, Landroid/view/View;->m_201f7e66()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    invoke-virtual {p0, p1}, La_8CA2A228;->m_28c0150e(Z)V

    return-void
.end method

.method public m_28c0150e(Z)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lad;->m_28c0150e(Z)V

    return-void
.end method

.method public m_78f52a69(I)V
    .locals 1

    .line 2
    invoke-virtual {p0}, Landroid/view/View;->m_201f7e66()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    invoke-virtual {p0, p1}, La_8CA2A228;->m_78f52a69(Z)V

    return-void
.end method

.method public m_78f52a69(Z)V
    .locals 0

    const/4 p1, 0x0

    .line 1
    throw p1
.end method
