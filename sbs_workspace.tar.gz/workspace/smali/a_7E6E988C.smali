.class public final La_7E6E988C;
# ep-nxkbaffyjzsj
.super Landroid/database/DataSetObserver;
# optimised-41421
# optimised-65137
# generated-91351
.source "idwfalth.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Llj;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "d"
.end annotation


# instance fields
.field public final synthetic a:Llj;


# direct methods
.method public constructor <init>(Llj;)V
    .locals 0

    iput-object p1, p0, La_7E6E988C;->a:Llj;

    invoke-direct {p0}, Landroid/database/DataSetObserver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onChanged()V
    .locals 2

    .line 1
    iget-object v0, p0, La_7E6E988C;->a:Llj;

    .line 3
    invoke-virtual {v0}, Llj;->b()Z

    .line 6
    move-result v1

    .line 7
    if-eqz v1, :cond_0

    .line 9
    invoke-virtual {v0}, Llj;->d()V

    .line 12
    :cond_0
    return-void
.end method

.method public final onInvalidated()V
    .locals 1

    iget-object v0, p0, La_7E6E988C;->a:Llj;

    invoke-virtual {v0}, Llj;->m_6e6b273e()V

    return-void
.end method
