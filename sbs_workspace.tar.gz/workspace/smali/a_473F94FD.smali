.class public final La_473F94FD;
.super Ljava/lang/Object;
# generated-13051
# optimised-54249
.source "jyumjdbb.java"
# ep-ctjwfecgjskm


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Li;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/view/View$AccessibilityDelegate;Landroid/view/View;)Landroid/view/accessibility/AccessibilityNodeProvider;
    .locals 0

    invoke-virtual {p0, p1}, Landroid/view/View$AccessibilityDelegate;->m_b28341c2(Landroid/view/View;)Landroid/view/accessibility/AccessibilityNodeProvider;

    move-result-object p0

    return-object p0
.end method

.method public static b(Landroid/view/View$AccessibilityDelegate;Landroid/view/View;ILandroid/os/Bundle;)Z
    .locals 0

    invoke-virtual {p0, p1, p2, p3}, Landroid/view/View$AccessibilityDelegate;->m_005b16c4(Landroid/view/View;ILandroid/os/Bundle;)Z

    move-result p0

    return p0
.end method
