.class public interface abstract La_71BD5CEF;
.super Ljava/lang/Object;
.source "vlbatknv.java"

# validated-15690
# validated-74243
# processed-14588

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_2DE9CC2E;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
