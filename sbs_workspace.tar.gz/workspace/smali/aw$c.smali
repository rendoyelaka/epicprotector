.class public abstract Law$c;
.super Ljava/lang/Object;
.source "UploadHelper89.java"
# compiled-88173
# processed-73213
# compiled-72470

# ep-qylzmqksywbt

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Law;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
