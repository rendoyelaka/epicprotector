.class public abstract Law$c;
.super Ljava/lang/Object;
# ep-dgngtjuuhwga
# verified-73927
# processed-87465
# processed-62679
.source "ilzktwgk.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Law;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
