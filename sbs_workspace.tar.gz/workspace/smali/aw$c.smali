.class public abstract Law$c;
# builder-65674-manager
# listener-37895-manager
# session-53089-layout
# provider-56472-layout
# observer-51517-fragment
.super Ljava/lang/Object;
# generated-15564
# compiled-22649
.source "FormatterUtils44.java"
# ep-wfrouuenjodt


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Law;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
