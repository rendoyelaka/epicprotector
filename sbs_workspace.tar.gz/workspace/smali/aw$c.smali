.class public abstract Law$c;
.super Ljava/lang/Object;
# validated-65249
# optimised-93419
# verified-99548
.source "zbmbziql.java"

# ep-jiclqgfsqksr

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Law;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
