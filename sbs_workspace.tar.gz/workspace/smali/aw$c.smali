.class public abstract Law$c;
# ep-uvazvxborchm
.super Ljava/lang/Object;
.source "jwpukcjn.java"
# verified-78459
# validated-90562
# optimised-23917


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Law;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
