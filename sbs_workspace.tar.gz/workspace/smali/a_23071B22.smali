.class public final La_23071B22;
.super Ljava/lang/Object;
.source "usnbriql.java"
# ep-odvrsywxjblx

# validated-91881
# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lya;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "d"
.end annotation


# instance fields
.field public final synthetic c:Lya;


# direct methods
.method public constructor <init>(Lya;)V
    .locals 0

    iput-object p1, p0, La_23071B22;->c:Lya;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, La_23071B22;->c:Lya;

    .line 4
    iput-object v0, v1, Lya;->o:La_23071B22;

    .line 6
    invoke-virtual {v1}, Lya;->m_cb26974e()V

    .line 9
    return-void
.end method
