.class public La_5D99D9E9;
.super Landroid/graphics/drawable/Drawable;
# ep-rwvluwkrhfpb
.source "eaecnzfk.java"

# validated-15845
# interfaces
.implements Landroid/graphics/drawable/Drawable$Callback;
.implements La_69E5AF55;
.implements Liv;


# static fields
.field public static final i:Landroid/graphics/PorterDuff$Mode;


# instance fields
.field public c:I

.field public d:Landroid/graphics/PorterDuff$Mode;

.field public e:Z

.field public f:La_226788AB;

.field public g:Z

.field public h:Landroid/graphics/drawable/Drawable;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    sget-object v0, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    sput-object v0, La_5D99D9E9;->i:Landroid/graphics/PorterDuff$Mode;

    return-void
.end method

.method public constructor <init>(Landroid/graphics/drawable/Drawable;)V
    .locals 2

    .line 5
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 6
    new-instance v0, La_226788AB;

    iget-object v1, p0, La_5D99D9E9;->f:La_226788AB;

    invoke-direct {v0, v1}, La_226788AB;-><init>(La_226788AB;)V

    .line 7
    iput-object v0, p0, La_5D99D9E9;->f:La_226788AB;

    .line 8
    invoke-virtual {p0, p1}, La_5D99D9E9;->a(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public constructor <init>(La_226788AB;Landroid/content/res/Resources;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 2
    iput-object p1, p0, La_5D99D9E9;->f:La_226788AB;

    if-eqz p1, :cond_0

    .line 3
    iget-object p1, p1, La_226788AB;->b:Landroid/graphics/drawable/Drawable$ConstantState;

    if-eqz p1, :cond_0

    .line 4
    invoke-virtual {p1, p2}, Landroid/graphics/drawable/Drawable$ConstantState;->m_48aae3f6(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {p0, p1}, La_5D99D9E9;->a(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/drawable/Drawable;)V
    .locals 2

    .line 1
    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    .line 9
    :cond_0
    iput-object p1, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    .line 11
    if-eqz p1, :cond_1

    .line 13
    invoke-virtual {p1, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    .line 16
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->m_f0135d0f()Z

    .line 19
    move-result v0

    .line 20
    const/4 v1, 0x1

    .line 21
    invoke-virtual {p0, v0, v1}, La_5D99D9E9;->m_0166a1e8(ZZ)Z

    .line 24
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->m_a4bf0ce9()[I

    .line 27
    move-result-object v0

    .line 28
    invoke-virtual {p0, v0}, La_5D99D9E9;->m_36047764([I)Z

    .line 31
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getLevel()I

    .line 34
    move-result v0

    .line 35
    invoke-virtual {p0, v0}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 38
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 41
    move-result-object v0

    .line 42
    invoke-virtual {p0, v0}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    .line 45
    iget-object v0, p0, La_5D99D9E9;->f:La_226788AB;

    .line 47
    if-eqz v0, :cond_1

    .line 49
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->m_3a533835()Landroid/graphics/drawable/Drawable$ConstantState;

    .line 52
    move-result-object p1

    .line 53
    iput-object p1, v0, La_226788AB;->b:Landroid/graphics/drawable/Drawable$ConstantState;

    .line 55
    :cond_1
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->m_4fb22408()V

    .line 58
    return-void
.end method

.method public final b()Landroid/graphics/drawable/Drawable;
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method public c()Z
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method

.method public final d([I)Z
    .locals 4

    .line 1
    invoke-virtual {p0}, La_5D99D9E9;->c()Z

    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-nez v0, :cond_0

    .line 8
    return v1

    .line 9
    :cond_0
    iget-object v0, p0, La_5D99D9E9;->f:La_226788AB;

    .line 11
    iget-object v2, v0, La_226788AB;->c:Landroid/content/res/ColorStateList;

    .line 13
    iget-object v0, v0, La_226788AB;->d:Landroid/graphics/PorterDuff$Mode;

    .line 15
    if-eqz v2, :cond_2

    .line 17
    if-eqz v0, :cond_2

    .line 19
    invoke-virtual {v2}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    .line 22
    move-result v3

    .line 23
    invoke-virtual {v2, p1, v3}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 26
    move-result p1

    .line 27
    iget-boolean v2, p0, La_5D99D9E9;->e:Z

    .line 29
    if-eqz v2, :cond_1

    .line 31
    iget v2, p0, La_5D99D9E9;->c:I

    .line 33
    if-ne p1, v2, :cond_1

    .line 35
    iget-object v2, p0, La_5D99D9E9;->d:Landroid/graphics/PorterDuff$Mode;

    .line 37
    if-eq v0, v2, :cond_3

    .line 39
    :cond_1
    invoke-virtual {p0, p1, v0}, Landroid/graphics/drawable/Drawable;->m_c2bf9474(ILandroid/graphics/PorterDuff$Mode;)V

    .line 42
    iput p1, p0, La_5D99D9E9;->c:I

    .line 44
    iput-object v0, p0, La_5D99D9E9;->d:Landroid/graphics/PorterDuff$Mode;

    .line 46
    const/4 p1, 0x1

    .line 47
    iput-boolean p1, p0, La_5D99D9E9;->e:Z

    .line 49
    return p1

    .line 50
    :cond_2
    iput-boolean v1, p0, La_5D99D9E9;->e:Z

    .line 52
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->clearColorFilter()V

    .line 55
    :cond_3
    return v1
.end method

.method public final m_2acfcc5a(Landroid/graphics/Canvas;)V
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_2acfcc5a(Landroid/graphics/Canvas;)V

    return-void
.end method

.method public final m_fbdebb97()I
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->m_fbdebb97()I

    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, La_5D99D9E9;->f:La_226788AB;

    .line 7
    if-eqz v1, :cond_0

    .line 9
    invoke-virtual {v1}, La_226788AB;->m_fbdebb97()I

    .line 12
    move-result v1

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v1, 0x0

    .line 15
    :goto_0
    or-int/2addr v0, v1

    .line 16
    iget-object v1, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    .line 18
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->m_fbdebb97()I

    .line 21
    move-result v1

    .line 22
    or-int/2addr v0, v1

    .line 23
    return v0
.end method

.method public final m_3a533835()Landroid/graphics/drawable/Drawable$ConstantState;
    .locals 2

    .line 1
    iget-object v0, p0, La_5D99D9E9;->f:La_226788AB;

    .line 3
    if-eqz v0, :cond_1

    .line 5
    iget-object v1, v0, La_226788AB;->b:Landroid/graphics/drawable/Drawable$ConstantState;

    .line 7
    if-eqz v1, :cond_0

    .line 9
    const/4 v1, 0x1

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const/4 v1, 0x0

    .line 12
    :goto_0
    if-eqz v1, :cond_1

    .line 14
    invoke-virtual {p0}, La_5D99D9E9;->m_fbdebb97()I

    .line 17
    move-result v1

    .line 18
    iput v1, v0, La_226788AB;->a:I

    .line 20
    iget-object v0, p0, La_5D99D9E9;->f:La_226788AB;

    .line 22
    return-object v0

    .line 23
    :cond_1
    const/4 v0, 0x0

    .line 24
    return-object v0
.end method

.method public final m_d8012211()Landroid/graphics/drawable/Drawable;
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_d8012211()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    return-object v0
.end method

.method public final m_ea5408ef()I
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_ea5408ef()I

    move-result v0

    return v0
.end method

.method public final m_27fe2d09()I
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_27fe2d09()I

    move-result v0

    return v0
.end method

.method public final m_af1392f9()I
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-static {v0}, Lta;->b(Landroid/graphics/drawable/Drawable;)I

    move-result v0

    return v0
.end method

.method public final m_a0942db6()I
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_a0942db6()I

    move-result v0

    return v0
.end method

.method public final m_864d560d()I
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_864d560d()I

    move-result v0

    return v0
.end method

.method public final m_2965c51e()I
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_2965c51e()I

    move-result v0

    return v0
.end method

.method public final m_5a16927a(Landroid/graphics/Rect;)Z
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_5a16927a(Landroid/graphics/Rect;)Z

    move-result p1

    return p1
.end method

.method public final m_a4bf0ce9()[I
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_a4bf0ce9()[I

    move-result-object v0

    return-object v0
.end method

.method public final m_9858d313()Landroid/graphics/Region;
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_9858d313()Landroid/graphics/Region;

    move-result-object v0

    return-object v0
.end method

.method public final m_f1b8b4e4(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->m_4fb22408()V

    return-void
.end method

.method public final m_83219999()Z
    .locals 1

    .line 1
    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    .line 3
    invoke-static {v0}, La_FD524361;->d(Landroid/graphics/drawable/Drawable;)Z

    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public final m_46259b2f()Z
    .locals 1

    .line 1
    invoke-virtual {p0}, La_5D99D9E9;->c()Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    iget-object v0, p0, La_5D99D9E9;->f:La_226788AB;

    .line 9
    if-eqz v0, :cond_0

    .line 11
    iget-object v0, v0, La_226788AB;->c:Landroid/content/res/ColorStateList;

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v0, 0x0

    .line 15
    :goto_0
    if-eqz v0, :cond_1

    .line 17
    invoke-virtual {v0}, Landroid/content/res/ColorStateList;->m_46259b2f()Z

    .line 20
    move-result v0

    .line 21
    if-nez v0, :cond_2

    .line 23
    :cond_1
    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    .line 25
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_46259b2f()Z

    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_3

    .line 31
    :cond_2
    const/4 v0, 0x1

    .line 32
    goto :goto_1

    .line 33
    :cond_3
    const/4 v0, 0x0

    .line 34
    :goto_1
    return v0
.end method

.method public final m_749b42e8()V
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_749b42e8()V

    return-void
.end method

.method public final m_e416d128()Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 1
    iget-boolean v0, p0, La_5D99D9E9;->g:Z

    .line 3
    if-nez v0, :cond_3

    .line 5
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->m_e416d128()Landroid/graphics/drawable/Drawable;

    .line 8
    move-result-object v0

    .line 9
    if-ne v0, p0, :cond_3

    .line 11
    new-instance v0, La_226788AB;

    .line 13
    iget-object v1, p0, La_5D99D9E9;->f:La_226788AB;

    .line 15
    invoke-direct {v0, v1}, La_226788AB;-><init>(La_226788AB;)V

    .line 18
    iput-object v0, p0, La_5D99D9E9;->f:La_226788AB;

    .line 20
    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    .line 22
    if-eqz v0, :cond_0

    .line 24
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->m_e416d128()Landroid/graphics/drawable/Drawable;

    .line 27
    :cond_0
    iget-object v0, p0, La_5D99D9E9;->f:La_226788AB;

    .line 29
    if-eqz v0, :cond_2

    .line 31
    iget-object v1, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    .line 33
    if-eqz v1, :cond_1

    .line 35
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->m_3a533835()Landroid/graphics/drawable/Drawable$ConstantState;

    .line 38
    move-result-object v1

    .line 39
    goto :goto_0

    .line 40
    :cond_1
    const/4 v1, 0x0

    .line 41
    :goto_0
    iput-object v1, v0, La_226788AB;->b:Landroid/graphics/drawable/Drawable$ConstantState;

    .line 43
    :cond_2
    const/4 v0, 0x1

    .line 44
    iput-boolean v0, p0, La_5D99D9E9;->g:Z

    .line 46
    :cond_3
    return-object p0
.end method

.method public final onBoundsChange(Landroid/graphics/Rect;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    .line 3
    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    .line 8
    :cond_0
    return-void
.end method

.method public final onLayoutDirectionChanged(I)Z
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-static {v0, p1}, Lta;->c(Landroid/graphics/drawable/Drawable;I)Z

    move-result p1

    return p1
.end method

.method public final onLevelChange(I)Z
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    move-result p1

    return p1
.end method

.method public final m_1262e5a0(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V
    .locals 0

    invoke-virtual {p0, p2, p3, p4}, Landroid/graphics/drawable/Drawable;->scheduleSelf(Ljava/lang/Runnable;J)V

    return-void
.end method

.method public final m_46dc9993(I)V
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_46dc9993(I)V

    return-void
.end method

.method public final m_77c9e5e2(Z)V
    .locals 1

    .line 1
    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    .line 3
    invoke-static {v0, p1}, La_FD524361;->e(Landroid/graphics/drawable/Drawable;Z)V

    .line 6
    return-void
.end method

.method public final m_989ee8e4(I)V
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_989ee8e4(I)V

    return-void
.end method

.method public final m_c2bf9474(Landroid/graphics/ColorFilter;)V
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_c2bf9474(Landroid/graphics/ColorFilter;)V

    return-void
.end method

.method public final m_267e83c1(Z)V
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_267e83c1(Z)V

    return-void
.end method

.method public final m_006d7f49(Z)V
    .locals 1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_006d7f49(Z)V

    return-void
.end method

.method public m_36047764([I)Z
    .locals 1

    .line 1
    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    .line 3
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->m_36047764([I)Z

    .line 6
    move-result v0

    .line 7
    invoke-virtual {p0, p1}, La_5D99D9E9;->d([I)Z

    .line 10
    move-result p1

    .line 11
    if-nez p1, :cond_1

    .line 13
    if-eqz v0, :cond_0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    const/4 p1, 0x0

    .line 17
    goto :goto_1

    .line 18
    :cond_1
    :goto_0
    const/4 p1, 0x1

    .line 19
    :goto_1
    return p1
.end method

.method public m_fd5fb1da(I)V
    .locals 0

    invoke-static {p1}, Landroid/content/res/ColorStateList;->m_446e0ad6(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    invoke-virtual {p0, p1}, La_5D99D9E9;->m_fafedc67(Landroid/content/res/ColorStateList;)V

    return-void
.end method

.method public m_fafedc67(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_5D99D9E9;->f:La_226788AB;

    .line 3
    iput-object p1, v0, La_226788AB;->c:Landroid/content/res/ColorStateList;

    .line 5
    invoke-virtual {p0}, La_5D99D9E9;->m_a4bf0ce9()[I

    .line 8
    move-result-object p1

    .line 9
    invoke-virtual {p0, p1}, La_5D99D9E9;->d([I)Z

    .line 12
    return-void
.end method

.method public m_b2ffc8df(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, La_5D99D9E9;->f:La_226788AB;

    .line 3
    iput-object p1, v0, La_226788AB;->d:Landroid/graphics/PorterDuff$Mode;

    .line 5
    invoke-virtual {p0}, La_5D99D9E9;->m_a4bf0ce9()[I

    .line 8
    move-result-object p1

    .line 9
    invoke-virtual {p0, p1}, La_5D99D9E9;->d([I)Z

    .line 12
    return-void
.end method

.method public final m_0166a1e8(ZZ)Z
    .locals 1

    invoke-super {p0, p1, p2}, Landroid/graphics/drawable/Drawable;->m_0166a1e8(ZZ)Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, La_5D99D9E9;->h:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1, p2}, Landroid/graphics/drawable/Drawable;->m_0166a1e8(ZZ)Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p1, 0x1

    :goto_1
    return p1
.end method

.method public final m_e72378a4(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V
    .locals 0

    invoke-virtual {p0, p2}, Landroid/graphics/drawable/Drawable;->unscheduleSelf(Ljava/lang/Runnable;)V

    return-void
.end method
