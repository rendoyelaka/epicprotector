.class public final LConnectionSpec;
.super Ljava/lang/Object;
# processed-50977
# verified-66220
.source "qwtkowhb.java"
# ep-fymxjygpkoml


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LConnectionSpec$a;
    }
.end annotation


# static fields
.field public static final e:LConnectionSpec;

.field public static final f:LConnectionSpec;

.field public static final g:LConnectionSpec;


# instance fields
.field public final a:Z

.field public final b:Z

.field public final c:[Ljava/lang/String;

.field public final d:[Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 11

    .line 1
    const/16 v0, 0xf

    .line 3
    new-array v1, v0, [Lf6;

    .line 5
    sget-object v2, Lf6;->l:Lf6;

    .line 7
    const/4 v3, 0x0

    .line 8
    aput-object v2, v1, v3

    .line 10
    sget-object v2, Lf6;->n:Lf6;

    .line 12
    const/4 v4, 0x1

    .line 13
    aput-object v2, v1, v4

    .line 15
    sget-object v2, Lf6;->m:Lf6;

    .line 17
    const/4 v5, 0x2

    .line 18
    aput-object v2, v1, v5

    .line 20
    sget-object v2, Lf6;->o:Lf6;

    .line 22
    const/4 v6, 0x3

    .line 23
    aput-object v2, v1, v6

    .line 25
    sget-object v2, Lf6;->q:Lf6;

    .line 27
    const/4 v7, 0x4

    .line 28
    aput-object v2, v1, v7

    .line 30
    const/4 v2, 0x5

    .line 31
    sget-object v8, Lf6;->p:Lf6;

    .line 33
    aput-object v8, v1, v2

    .line 35
    const/4 v2, 0x6

    .line 36
    sget-object v8, Lf6;->h:Lf6;

    .line 38
    aput-object v8, v1, v2

    .line 40
    const/4 v2, 0x7

    .line 41
    sget-object v8, Lf6;->j:Lf6;

    .line 43
    aput-object v8, v1, v2

    .line 45
    const/16 v2, 0x8

    .line 47
    sget-object v8, Lf6;->i:Lf6;

    .line 49
    aput-object v8, v1, v2

    .line 51
    const/16 v2, 0x9

    .line 53
    sget-object v8, Lf6;->k:Lf6;

    .line 55
    aput-object v8, v1, v2

    .line 57
    const/16 v2, 0xa

    .line 59
    sget-object v8, Lf6;->f:Lf6;

    .line 61
    aput-object v8, v1, v2

    .line 63
    const/16 v2, 0xb

    .line 65
    sget-object v8, Lf6;->g:Lf6;

    .line 67
    aput-object v8, v1, v2

    .line 69
    const/16 v2, 0xc

    .line 71
    sget-object v8, Lf6;->d:Lf6;

    .line 73
    aput-object v8, v1, v2

    .line 75
    const/16 v2, 0xd

    .line 77
    sget-object v8, Lf6;->e:Lf6;

    .line 79
    aput-object v8, v1, v2

    .line 81
    const/16 v2, 0xe

    .line 83
    sget-object v8, Lf6;->c:Lf6;

    .line 85
    aput-object v8, v1, v2

    .line 87
    new-instance v2, LConnectionSpec$a;

    .line 89
    invoke-direct {v2, v4}, LConnectionSpec$a;-><init>(Z)V

    .line 92
    new-array v8, v0, [Ljava/lang/String;

    .line 94
    const/4 v9, 0x0

    .line 95
    :goto_0
    if-ge v9, v0, :cond_0

    .line 97
    aget-object v10, v1, v9

    .line 99
    iget-object v10, v10, Lf6;->a:Ljava/lang/String;

    .line 101
    aput-object v10, v8, v9

    .line 103
    add-int/lit8 v9, v9, 0x1

    .line 105
    goto :goto_0

    .line 106
    :cond_0
    invoke-virtual {v2, v8}, LConnectionSpec$a;->a([Ljava/lang/String;)V

    .line 109
    new-array v0, v7, [LTlsVersion;

    .line 111
    sget-object v1, LTlsVersion;->d:LTlsVersion;

    .line 113
    aput-object v1, v0, v3

    .line 115
    sget-object v1, LTlsVersion;->e:LTlsVersion;

    .line 117
    aput-object v1, v0, v4

    .line 119
    sget-object v1, LTlsVersion;->f:LTlsVersion;

    .line 121
    aput-object v1, v0, v5

    .line 123
    sget-object v1, LTlsVersion;->g:LTlsVersion;

    .line 125
    aput-object v1, v0, v6

    .line 127
    invoke-virtual {v2, v0}, LConnectionSpec$a;->b([LTlsVersion;)V

    .line 130
    iget-boolean v0, v2, LConnectionSpec$a;->a:Z

    .line 132
    const-string v5, "no TLS extensions for cleartext connections"

    .line 134
    if-eqz v0, :cond_2

    .line 136
    iput-boolean v4, v2, LConnectionSpec$a;->d:Z

    .line 138
    new-instance v0, LConnectionSpec;

    .line 140
    invoke-direct {v0, v2}, LConnectionSpec;-><init>(LConnectionSpec$a;)V

    .line 143
    sput-object v0, LConnectionSpec;->e:LConnectionSpec;

    .line 145
    new-instance v2, LConnectionSpec$a;

    .line 147
    invoke-direct {v2, v0}, LConnectionSpec$a;-><init>(LConnectionSpec;)V

    .line 150
    new-array v0, v4, [LTlsVersion;

    .line 152
    aput-object v1, v0, v3

    .line 154
    invoke-virtual {v2, v0}, LConnectionSpec$a;->b([LTlsVersion;)V

    .line 157
    iget-boolean v0, v2, LConnectionSpec$a;->a:Z

    .line 159
    if-eqz v0, :cond_1

    .line 161
    iput-boolean v4, v2, LConnectionSpec$a;->d:Z

    .line 163
    new-instance v0, LConnectionSpec;

    .line 165
    invoke-direct {v0, v2}, LConnectionSpec;-><init>(LConnectionSpec$a;)V

    .line 168
    sput-object v0, LConnectionSpec;->f:LConnectionSpec;

    .line 170
    new-instance v0, LConnectionSpec$a;

    .line 172
    invoke-direct {v0, v3}, LConnectionSpec$a;-><init>(Z)V

    .line 175
    new-instance v1, LConnectionSpec;

    .line 177
    invoke-direct {v1, v0}, LConnectionSpec;-><init>(LConnectionSpec$a;)V

    .line 180
    sput-object v1, LConnectionSpec;->g:LConnectionSpec;

    .line 182
    return-void

    .line 183
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 185
    invoke-direct {v0, v5}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 188
    throw v0

    .line 189
    :cond_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 191
    invoke-direct {v0, v5}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 194
    throw v0
.end method

.method public constructor <init>(LConnectionSpec$a;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iget-boolean v0, p1, LConnectionSpec$a;->a:Z

    .line 6
    iput-boolean v0, p0, LConnectionSpec;->a:Z

    .line 8
    iget-object v0, p1, LConnectionSpec$a;->b:[Ljava/lang/String;

    .line 10
    iput-object v0, p0, LConnectionSpec;->c:[Ljava/lang/String;

    .line 12
    iget-object v0, p1, LConnectionSpec$a;->c:[Ljava/lang/String;

    .line 14
    iput-object v0, p0, LConnectionSpec;->d:[Ljava/lang/String;

    .line 16
    iget-boolean p1, p1, LConnectionSpec$a;->d:Z

    .line 18
    iput-boolean p1, p0, LConnectionSpec;->b:Z

    .line 20
    return-void
.end method

.method public static b([Ljava/lang/String;[Ljava/lang/String;)Z
    .locals 8

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p0, :cond_4

    .line 4
    if-eqz p1, :cond_4

    .line 6
    array-length v1, p0

    .line 7
    if-eqz v1, :cond_4

    .line 9
    array-length v1, p1

    .line 10
    if-nez v1, :cond_0

    .line 12
    goto :goto_3

    .line 13
    :cond_0
    array-length v1, p0

    .line 14
    const/4 v2, 0x0

    .line 15
    :goto_0
    if-ge v2, v1, :cond_4

    .line 17
    aget-object v3, p0, v2

    .line 19
    sget-object v4, Lex;->a:[B

    .line 21
    array-length v4, p1

    .line 22
    const/4 v5, 0x0

    .line 23
    :goto_1
    const/4 v6, -0x1

    .line 24
    if-ge v5, v4, :cond_2

    .line 26
    aget-object v7, p1, v5

    .line 28
    invoke-static {v7, v3}, Lex;->f(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    move-result v7

    .line 32
    if-eqz v7, :cond_1

    .line 34
    goto :goto_2

    .line 35
    :cond_1
    add-int/lit8 v5, v5, 0x1

    .line 37
    goto :goto_1

    .line 38
    :cond_2
    const/4 v5, -0x1

    .line 39
    :goto_2
    if-eq v5, v6, :cond_3

    .line 41
    const/4 p0, 0x1

    .line 42
    return p0

    .line 43
    :cond_3
    add-int/lit8 v2, v2, 0x1

    .line 45
    goto :goto_0

    .line 46
    :cond_4
    :goto_3
    return v0
.end method


# virtual methods
.method public final a(Ljavax/net/ssl/SSLSocket;)Z
    .locals 3

    .line 1
    iget-boolean v0, p0, LConnectionSpec;->a:Z

    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 6
    return v1

    .line 7
    :cond_0
    iget-object v0, p0, LConnectionSpec;->d:[Ljava/lang/String;

    .line 9
    if-eqz v0, :cond_1

    .line 11
    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getEnabledProtocols()[Ljava/lang/String;

    .line 14
    move-result-object v2

    .line 15
    invoke-static {v0, v2}, LConnectionSpec;->b([Ljava/lang/String;[Ljava/lang/String;)Z

    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_1

    .line 21
    return v1

    .line 22
    :cond_1
    iget-object v0, p0, LConnectionSpec;->c:[Ljava/lang/String;

    .line 24
    if-eqz v0, :cond_2

    .line 26
    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getEnabledCipherSuites()[Ljava/lang/String;

    .line 29
    move-result-object p1

    .line 30
    invoke-static {v0, p1}, LConnectionSpec;->b([Ljava/lang/String;[Ljava/lang/String;)Z

    .line 33
    move-result p1

    .line 34
    if-nez p1, :cond_2

    .line 36
    return v1

    .line 37
    :cond_2
    const/4 p1, 0x1

    .line 38
    return p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    instance-of v0, p1, LConnectionSpec;

    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 6
    return v1

    .line 7
    :cond_0
    const/4 v0, 0x1

    .line 8
    if-ne p1, p0, :cond_1

    .line 10
    return v0

    .line 11
    :cond_1
    check-cast p1, LConnectionSpec;

    .line 13
    iget-boolean v2, p1, LConnectionSpec;->a:Z

    .line 15
    iget-boolean v3, p0, LConnectionSpec;->a:Z

    .line 17
    if-eq v3, v2, :cond_2

    .line 19
    return v1

    .line 20
    :cond_2
    if-eqz v3, :cond_5

    .line 22
    iget-object v2, p0, LConnectionSpec;->c:[Ljava/lang/String;

    .line 24
    iget-object v3, p1, LConnectionSpec;->c:[Ljava/lang/String;

    .line 26
    invoke-static {v2, v3}, Ljava/util/Arrays;->equals([Ljava/lang/Object;[Ljava/lang/Object;)Z

    .line 29
    move-result v2

    .line 30
    if-nez v2, :cond_3

    .line 32
    return v1

    .line 33
    :cond_3
    iget-object v2, p0, LConnectionSpec;->d:[Ljava/lang/String;

    .line 35
    iget-object v3, p1, LConnectionSpec;->d:[Ljava/lang/String;

    .line 37
    invoke-static {v2, v3}, Ljava/util/Arrays;->equals([Ljava/lang/Object;[Ljava/lang/Object;)Z

    .line 40
    move-result v2

    .line 41
    if-nez v2, :cond_4

    .line 43
    return v1

    .line 44
    :cond_4
    iget-boolean v2, p0, LConnectionSpec;->b:Z

    .line 46
    iget-boolean p1, p1, LConnectionSpec;->b:Z

    .line 48
    if-eq v2, p1, :cond_5

    .line 50
    return v1

    .line 51
    :cond_5
    return v0
.end method

.method public final hashCode()I
    .locals 2

    .line 1
    iget-boolean v0, p0, LConnectionSpec;->a:Z

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, LConnectionSpec;->c:[Ljava/lang/String;

    .line 7
    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    .line 10
    move-result v0

    .line 11
    const/16 v1, 0x20f

    .line 13
    add-int/2addr v1, v0

    .line 14
    mul-int/lit8 v1, v1, 0x1f

    .line 16
    iget-object v0, p0, LConnectionSpec;->d:[Ljava/lang/String;

    .line 18
    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    .line 21
    move-result v0

    .line 22
    add-int/2addr v1, v0

    .line 23
    mul-int/lit8 v1, v1, 0x1f

    .line 25
    iget-boolean v0, p0, LConnectionSpec;->b:Z

    .line 27
    xor-int/lit8 v0, v0, 0x1

    .line 29
    add-int/2addr v1, v0

    .line 30
    goto :goto_0

    .line 31
    :cond_0
    const/16 v1, 0x11

    .line 33
    :goto_0
    return v1
.end method

.method public final toString()Ljava/lang/String;
    .locals 8

    .line 1
    iget-boolean v0, p0, LConnectionSpec;->a:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    const-string v0, "ConnectionSpec()"

    .line 7
    return-object v0

    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    const/4 v1, 0x0

    .line 10
    const-string v2, "[all enabled]"

    .line 12
    iget-object v3, p0, LConnectionSpec;->c:[Ljava/lang/String;

    .line 14
    if-eqz v3, :cond_3

    .line 16
    if-nez v3, :cond_1

    .line 18
    move-object v3, v0

    .line 19
    goto :goto_1

    .line 20
    :cond_1
    new-instance v4, Ljava/util/ArrayList;

    .line 22
    array-length v5, v3

    .line 23
    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 26
    array-length v5, v3

    .line 27
    const/4 v6, 0x0

    .line 28
    :goto_0
    if-ge v6, v5, :cond_2

    .line 30
    aget-object v7, v3, v6

    .line 32
    invoke-static {v7}, Lf6;->a(Ljava/lang/String;)Lf6;

    .line 35
    move-result-object v7

    .line 36
    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 39
    add-int/lit8 v6, v6, 0x1

    .line 41
    goto :goto_0

    .line 42
    :cond_2
    invoke-static {v4}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 45
    move-result-object v3

    .line 46
    :goto_1
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 49
    move-result-object v3

    .line 50
    goto :goto_2

    .line 51
    :cond_3
    move-object v3, v2

    .line 52
    :goto_2
    iget-object v4, p0, LConnectionSpec;->d:[Ljava/lang/String;

    .line 54
    if-eqz v4, :cond_6

    .line 56
    if-nez v4, :cond_4

    .line 58
    goto :goto_4

    .line 59
    :cond_4
    new-instance v0, Ljava/util/ArrayList;

    .line 61
    array-length v2, v4

    .line 62
    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 65
    array-length v2, v4

    .line 66
    :goto_3
    if-ge v1, v2, :cond_5

    .line 68
    aget-object v5, v4, v1

    .line 70
    invoke-static {v5}, LTlsVersion;->a(Ljava/lang/String;)LTlsVersion;

    .line 73
    move-result-object v5

    .line 74
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 77
    add-int/lit8 v1, v1, 0x1

    .line 79
    goto :goto_3

    .line 80
    :cond_5
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 83
    move-result-object v0

    .line 84
    :goto_4
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 87
    move-result-object v2

    .line 88
    :cond_6
    new-instance v0, Ljava/lang/StringBuilder;

    .line 90
    const-string v1, "ConnectionSpec(cipherSuites="

    .line 92
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 95
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    const-string v1, ", tlsVersions="

    .line 100
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 103
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 106
    const-string v1, ", supportsTlsExtensions="

    .line 108
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 111
    iget-boolean v1, p0, LConnectionSpec;->b:Z

    .line 113
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 116
    const-string v1, ")"

    .line 118
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 121
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 124
    move-result-object v0

    .line 125
    return-object v0
.end method
