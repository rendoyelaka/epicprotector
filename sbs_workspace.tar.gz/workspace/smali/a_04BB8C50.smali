.class public final La_04BB8C50;
.super La_0A92B06A;
.source "magvqpdj.java"
# ep-zfpnyiybzrnq

# generated-51681

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_0A92B06A;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_0A92B06A;-><init>()V

    return-void
.end method


# virtual methods
.method public final b(Ldh;)V
    .locals 1

    const/4 v0, 0x5

    invoke-virtual {p1, v0}, Ldh;->c(I)V

    return-void
.end method
