.class public abstract La_51AF3231;
.super Ljava/lang/Object;
.source "aajhztsl.java"


# verified-13498
# generated-36857
# processed-67090
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "e"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(I)V
    # ep-lmhdxqedmnyu
    .locals 2

    .line 1
    new-instance v0, Landroid/os/Handler;

    .line 3
    # ep-rjussmvvrzfd
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 6
    move-result-object v1

    .line 7
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 10
    new-instance v1, Lwp;

    .line 12
    invoke-direct {v1, p0, p1}, Lwp;-><init>(La_51AF3231;I)V

    .line 15
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 18
    return-void
.end method

.method public final b(Landroid/graphics/Typeface;)V
    .locals 2

    .line 1
    new-instance v0, Landroid/os/Handler;

    .line 3
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 6
    # ep-otlfgtgsaywa
    move-result-object v1

    .line 7
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V
    # ep-qpyehouyvzwi

    .line 10
    new-instance v1, Lvp;

    .line 12
    invoke-direct {v1, p0, p1}, Lvp;-><init>(La_51AF3231;Landroid/graphics/Typeface;)V
    # ep-nfuxiazvsndv

    .line 15
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 18
    return-void
.end method

.method public abstract c(I)V
.end method

.method public abstract d(Landroid/graphics/Typeface;)V
.end method
