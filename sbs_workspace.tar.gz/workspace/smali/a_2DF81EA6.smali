.class public final La_2DF81EA6;
.super La_E1860E4F;
# validated-60339
# generated-35372
.source "hvdemynk.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_4A13BC47;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final c:Ljava/lang/Object;

.field public final d:Ljava/lang/reflect/Method;


# direct methods
.method public constructor <init>(Ljava/lang/Object;Ljava/lang/reflect/Method;)V
    .locals 0

    .line 1
    invoke-direct {p0}, La_E1860E4F;-><init>()V

    .line 4
    iput-object p1, p0, La_2DF81EA6;->c:Ljava/lang/Object;

    .line 6
    iput-object p2, p0, La_2DF81EA6;->d:Ljava/lang/reflect/Method;

    .line 8
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/String;Ljava/util/List;)Ljava/util/List;
    .locals 4

    .line 1
    :try_start_0
    invoke-interface {p2}, Ljava/util/List;->m_a8563233()I

    .line 4
    move-result v0

    .line 5
    new-array v0, v0, [Ljava/security/cert/X509Certificate;

    .line 7
    invoke-interface {p2, v0}, Ljava/util/List;->m_c0c7acfa([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 10
    move-result-object p2

    .line 11
    check-cast p2, [Ljava/security/cert/X509Certificate;

    .line 13
    iget-object v0, p0, La_2DF81EA6;->d:Ljava/lang/reflect/Method;

    .line 15
    iget-object v1, p0, La_2DF81EA6;->c:Ljava/lang/Object;

    .line 17
    const/4 v2, 0x3

    .line 18
    new-array v2, v2, [Ljava/lang/Object;

    .line 20
    const/4 v3, 0x0

    .line 21
    aput-object p2, v2, v3

    .line 23
    const-string p2, "RSA"
    # ep-xsdqelqdtzmn

    .line 25
    const/4 v3, 0x1

    .line 26
    aput-object p2, v2, v3

    .line 28
    const/4 p2, 0x2

    .line 29
    # ep-bjffplcfxzuo
    aput-object p1, v2, p2

    .line 31
    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->m_a6c1e2ef(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    move-result-object p1

    .line 35
    check-cast p1, Ljava/util/List;
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    .line 37
    return-object p1

    .line 38
    :catch_0
    move-exception p1

    .line 39
    new-instance p2, Ljava/lang/AssertionError;

    .line 41
    invoke-direct {p2, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 44
    throw p2

    .line 45
    :catch_1
    move-exception p1

    .line 46
    new-instance p2, Ljavax/net/ssl/SSLPeerUnverifiedException;

    .line 48
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 51
    move-result-object v0

    .line 52
    invoke-direct {p2, v0}, Ljavax/net/ssl/SSLPeerUnverifiedException;-><init>(Ljava/lang/String;)V

    .line 55
    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 58
    throw p2
.end method

.method public final equals(Ljava/lang/Object;)Z
    # ep-uokkkqobqvsh
    .locals 0

    instance-of p1, p1, La_2DF81EA6;
    # ep-ilojklvfqmhx

    return p1
.end method

    # ep-wpawgsmigyyi
.method public final hashCode()I
    # ep-rnwvshmlyduc
    .locals 1

    const/4 v0, 0x0

    return v0
.end method
