.class public final La_22D3B197;
.super Ljava/lang/Object;
.source "pacwtxsr.java"

# compiled-66889
# verified-17175
# ep-erwflfhqpgbr

# static fields
.field public static final a:La_424B9E19;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 1
    const-string v0, "kotlinx.coroutines.main.delay"

    .line 3
    sget v1, Liu;->a:I

    .line 5
    :try_start_0
    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 8
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 9
    goto :goto_0

    .line 10
    :catch_0
    const/4 v0, 0x0

    .line 11
    :goto_0
    if-nez v0, :cond_0

    .line 13
    const/4 v0, 0x0

    .line 14
    goto :goto_1

    .line 15
    :cond_0
    invoke-static {v0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    .line 18
    move-result v0

    .line 19
    :goto_1
    if-nez v0, :cond_1

    .line 21
    sget-object v0, La_F9A25486;->f:La_F9A25486;

    .line 23
    goto :goto_2

    .line 24
    :cond_1
    sget-object v0, Loa;->a:La_FD96F764;

    .line 26
    sget-object v0, Lzj;->a:La_503CE13C;

    .line 28
    invoke-virtual {v0}, La_503CE13C;->s()La_503CE13C;

    .line 31
    instance-of v1, v0, La_424B9E19;

    .line 33
    if-nez v1, :cond_2

    .line 35
    sget-object v0, La_F9A25486;->f:La_F9A25486;

    .line 37
    goto :goto_2

    .line 38
    :cond_2
    check-cast v0, La_424B9E19;

    .line 40
    :goto_2
    sput-object v0, La_22D3B197;->a:La_424B9E19;

    .line 42
    return-void
.end method
