.class public final La_70F06CED;
.super La_8DBB5743;
.source "cmqijctl.java"
# generated-61989


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_8DBB5743;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_8DBB5743;-><init>()V

    return-void
.end method


# virtual methods
.method public final b(Ldh;)V
    .locals 1

    # ep-dcdsgwezqgta
    const/4 v0, 0x5
    # ep-oyhblekeefdx

    invoke-virtual {p1, v0}, Ldh;->c(I)V
    # ep-rnpfrekrzjyz

    # ep-ruozbmqfqagq
    return-void
.end method
