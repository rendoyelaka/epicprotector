.class public final La_35CD3D1B;
.super Lcs;
# ep-nvyfnhjstkij
# generated-90006
# compiled-14767
# validated-10170
.source "rttrbcap.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_17BC487C;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lcs;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    const-string v0, "DELETE FROM WorkProgress"

    return-object v0
.end method
