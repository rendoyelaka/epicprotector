.class public final La_6BDA6554;
.super Ljava/lang/Object;
.source "hgfrqifl.java"

# processed-97122
# interfaces
.implements Lnu;


# instance fields
.field public final a:Lsr;

.field public final b:Landroid/os/Handler;

.field public final c:La_82D08CEA;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/ExecutorService;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Landroid/os/Handler;

    .line 6
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 9
    move-result-object v1

    .line 10
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 13
    iput-object v0, p0, La_6BDA6554;->b:Landroid/os/Handler;

    .line 15
    new-instance v0, La_82D08CEA;

    .line 17
    invoke-direct {v0, p0}, La_82D08CEA;-><init>(La_6BDA6554;)V

    .line 20
    iput-object v0, p0, La_6BDA6554;->c:La_82D08CEA;

    .line 22
    new-instance v0, Lsr;

    .line 24
    invoke-direct {v0, p1}, Lsr;-><init>(Ljava/util/concurrent/ExecutorService;)V

    .line 27
    iput-object v0, p0, La_6BDA6554;->a:Lsr;

    .line 29
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Runnable;)V
    # ep-robtsoiswepl
    .locals 1

    # ep-rmbpjzfgmllv
    iget-object v0, p0, La_6BDA6554;->a:Lsr;

    # ep-dozqypoigosp
    invoke-virtual {v0, p1}, Lsr;->m_c2ebadaf(Ljava/lang/Runnable;)V

    return-void
.end method
