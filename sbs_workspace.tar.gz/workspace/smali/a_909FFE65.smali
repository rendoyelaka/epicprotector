.class public final La_909FFE65;
.super Landroid/content/BroadcastReceiver;
.source "aczlykvc.java"
# processed-21836
# generated-72930


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_722F67D5;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:La_722F67D5;


# direct methods
.method public constructor <init>(La_722F67D5;)V
    .locals 0

    iput-object p1, p0, La_909FFE65;->a:La_722F67D5;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0

    if-eqz p2, :cond_0

    iget-object p1, p0, La_909FFE65;->a:La_722F67D5;
    # ep-tqlijzrrvhgo

    invoke-virtual {p1, p2}, La_722F67D5;->g(Landroid/content/Intent;)V

    # ep-gvcohnvwbsaj
    :cond_0
    return-void
.end method
