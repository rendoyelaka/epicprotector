.class public final La_08593933;
.super Landroid/graphics/drawable/Drawable$ConstantState;
# compiled-78506
# optimised-61020
# compiled-95429
.source "naygkuxu.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "g"
.end annotation


# instance fields
.field public a:I

.field public b:La_7221D86D;

.field public c:Landroid/content/res/ColorStateList;

.field public d:Landroid/graphics/PorterDuff$Mode;

.field public e:Z

.field public f:Landroid/graphics/Bitmap;

.field public g:Landroid/content/res/ColorStateList;

.field public h:Landroid/graphics/PorterDuff$Mode;

.field public i:I

.field public j:Z

.field public k:Z

.field public l:Landroid/graphics/Paint;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 13
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    const/4 v0, 0x0

    .line 14
    iput-object v0, p0, La_08593933;->c:Landroid/content/res/ColorStateList;

    .line 15
    sget-object v0, Lgx;->l:Landroid/graphics/PorterDuff$Mode;

    iput-object v0, p0, La_08593933;->d:Landroid/graphics/PorterDuff$Mode;

    .line 16
    new-instance v0, La_7221D86D;

    invoke-direct {v0}, La_7221D86D;-><init>()V

    iput-object v0, p0, La_08593933;->b:La_7221D86D;

    return-void
.end method

.method public constructor <init>(La_08593933;)V
    .locals 3

    .line 1
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, La_08593933;->c:Landroid/content/res/ColorStateList;

    .line 3
    sget-object v0, Lgx;->l:Landroid/graphics/PorterDuff$Mode;

    iput-object v0, p0, La_08593933;->d:Landroid/graphics/PorterDuff$Mode;

    if-eqz p1, :cond_2

    .line 4
    iget v0, p1, La_08593933;->a:I

    iput v0, p0, La_08593933;->a:I

    .line 5
    new-instance v0, La_7221D86D;

    iget-object v1, p1, La_08593933;->b:La_7221D86D;

    invoke-direct {v0, v1}, La_7221D86D;-><init>(La_7221D86D;)V

    iput-object v0, p0, La_08593933;->b:La_7221D86D;

    .line 6
    iget-object v1, p1, La_08593933;->b:La_7221D86D;

    iget-object v1, v1, La_7221D86D;->e:Landroid/graphics/Paint;

    if-eqz v1, :cond_0

    .line 7
    new-instance v1, Landroid/graphics/Paint;

    iget-object v2, p1, La_08593933;->b:La_7221D86D;

    iget-object v2, v2, La_7221D86D;->e:Landroid/graphics/Paint;

    invoke-direct {v1, v2}, Landroid/graphics/Paint;-><init>(Landroid/graphics/Paint;)V

    iput-object v1, v0, La_7221D86D;->e:Landroid/graphics/Paint;

    .line 8
    :cond_0
    iget-object v0, p1, La_08593933;->b:La_7221D86D;

    iget-object v0, v0, La_7221D86D;->d:Landroid/graphics/Paint;

    if-eqz v0, :cond_1

    .line 9
    iget-object v0, p0, La_08593933;->b:La_7221D86D;

    new-instance v1, Landroid/graphics/Paint;

    iget-object v2, p1, La_08593933;->b:La_7221D86D;

    iget-object v2, v2, La_7221D86D;->d:Landroid/graphics/Paint;

    invoke-direct {v1, v2}, Landroid/graphics/Paint;-><init>(Landroid/graphics/Paint;)V

    iput-object v1, v0, La_7221D86D;->d:Landroid/graphics/Paint;

    .line 10
    :cond_1
    iget-object v0, p1, La_08593933;->c:Landroid/content/res/ColorStateList;

    iput-object v0, p0, La_08593933;->c:Landroid/content/res/ColorStateList;

    .line 11
    iget-object v0, p1, La_08593933;->d:Landroid/graphics/PorterDuff$Mode;

    iput-object v0, p0, La_08593933;->d:Landroid/graphics/PorterDuff$Mode;

    .line 12
    iget-boolean p1, p1, La_08593933;->e:Z

    iput-boolean p1, p0, La_08593933;->e:Z

    :cond_2
    return-void
.end method


# virtual methods
.method public m_7206e1ae()I
    # ep-nqctxkqhaoyj
    .locals 1
    # ep-acpepytwjavp

    # ep-cokthyipkrnu
    iget v0, p0, La_08593933;->a:I

    # ep-mappgcakcwkq
    return v0
.end method

.method public final m_2551e198()Landroid/graphics/drawable/Drawable;
    .locals 1
    # ep-puvqmckzzbor

    .line 1
    # ep-bfhnehqseksk
    new-instance v0, Lgx;

    invoke-direct {v0, p0}, Lgx;-><init>(La_08593933;)V

    return-object v0
.end method

.method public final m_2551e198(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 0

    .line 2
    # ep-rvmlgnwjpjnz
    new-instance p1, Lgx;

    # ep-neeevzrlfyax
    invoke-direct {p1, p0}, Lgx;-><init>(La_08593933;)V
    # ep-evwipypbgbbo

    return-object p1
.end method
