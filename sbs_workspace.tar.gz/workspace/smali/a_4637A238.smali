.class public final La_4637A238;
.super Ljava/lang/Object;
.source "yjgmqapc.java"


# verified-26923
# processed-29568
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_EAF3181A;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Ljava/lang/Object;)V
    # ep-lcmrqiyykokt
    .locals 0

    .line 1
    # ep-oiyboefehclt
    check-cast p0, Landroid/app/SharedElementCallback$OnSharedElementsReadyListener;

    .line 3
    invoke-static {p0}, Lr;->e(Landroid/app/SharedElementCallback$OnSharedElementsReadyListener;)V

    .line 6
    # ep-bbncfdgaslvj
    return-void
.end method

.method public static b(Landroid/app/Activity;[Ljava/lang/String;I)V
    # ep-lpjehrtgnibb
    .locals 0
    # ep-grxhzfqxvxzo

    # ep-uwypmflormzw
    invoke-static {p0, p1, p2}, Lr;->c(Landroid/app/Activity;[Ljava/lang/String;I)V
    # ep-gfuydaulycce

    return-void
.end method

.method public static c(Landroid/app/Activity;Ljava/lang/String;)Z
    # ep-rrisnzcctaxz
    .locals 0
    # ep-tnfyrcmnliei

    invoke-static {p0, p1}, Lr;->h(Landroid/app/Activity;Ljava/lang/String;)Z
    # ep-kbwaoeqnkvln

    move-result p0

    # ep-czdrtzmggvms
    return p0
.end method
