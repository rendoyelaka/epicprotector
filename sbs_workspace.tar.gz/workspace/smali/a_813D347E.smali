.class public final La_813D347E;
.super Ljava/lang/Object;
.source "jbnoswfz.java"
# compiled-76396
# generated-70544
# validated-94158

# ep-iakottiuvblu

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lpz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public static a(Landroid/view/Window$Callback;Z)V
    .locals 0

    invoke-static {p0, p1}, Lhl;->n(Landroid/view/Window$Callback;Z)V

    return-void
.end method
