.class public La_55FC5DDC;
.super La_527D832B;
.source "jyihvepl.java"
# ep-nqjwyjyhkeij

# optimised-47261
# verified-44564
# processed-51058

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public f_4fd05212:[[I


# direct methods
.method public constructor <init>(La_55FC5DDC;Lat;Landroid/content/res/Resources;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2, p3}, La_527D832B;-><init>(La_527D832B;Lua;Landroid/content/res/Resources;)V

    .line 4
    if-eqz p1, :cond_0

    .line 6
    iget-object p1, p1, La_55FC5DDC;->f_4fd05212:[[I

    .line 8
    iput-object p1, p0, La_55FC5DDC;->f_4fd05212:[[I

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-object p1, p0, La_527D832B;->g:[Landroid/graphics/drawable/Drawable;

    .line 13
    array-length p1, p1

    .line 14
    new-array p1, p1, [[I

    .line 16
    iput-object p1, p0, La_55FC5DDC;->f_4fd05212:[[I

    .line 18
    :goto_0
    return-void
.end method


# virtual methods
.method public e()V
    .locals 3

    .line 1
    iget-object v0, p0, La_55FC5DDC;->f_4fd05212:[[I

    .line 3
    array-length v1, v0

    .line 4
    new-array v1, v1, [[I

    .line 6
    array-length v0, v0

    .line 7
    add-int/lit8 v0, v0, -0x1

    .line 9
    :goto_0
    if-ltz v0, :cond_1

    .line 11
    iget-object v2, p0, La_55FC5DDC;->f_4fd05212:[[I

    .line 13
    aget-object v2, v2, v0

    .line 15
    if-eqz v2, :cond_0

    .line 17
    invoke-virtual {v2}, [I->clone()Ljava/lang/Object;

    .line 20
    move-result-object v2

    .line 21
    check-cast v2, [I

    .line 23
    goto :goto_1

    .line 24
    :cond_0
    const/4 v2, 0x0

    .line 25
    :goto_1
    aput-object v2, v1, v0

    .line 27
    add-int/lit8 v0, v0, -0x1

    .line 29
    goto :goto_0

    .line 30
    :cond_1
    iput-object v1, p0, La_55FC5DDC;->f_4fd05212:[[I

    .line 32
    return-void
.end method

.method public final f([I)I
    .locals 4

    .line 1
    iget-object v0, p0, La_55FC5DDC;->f_4fd05212:[[I

    .line 3
    iget v1, p0, La_527D832B;->h:I

    .line 5
    const/4 v2, 0x0

    .line 6
    :goto_0
    if-ge v2, v1, :cond_1

    .line 8
    aget-object v3, v0, v2

    .line 10
    invoke-static {v3, p1}, Landroid/util/StateSet;->stateSetMatches([I[I)Z

    .line 13
    move-result v3

    .line 14
    if-eqz v3, :cond_0

    .line 16
    return v2

    .line 17
    :cond_0
    add-int/lit8 v2, v2, 0x1

    .line 19
    goto :goto_0

    .line 20
    :cond_1
    const/4 p1, -0x1

    .line 21
    return p1
.end method

.method public m_afd718b8()Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 1
    new-instance v0, Lat;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lat;-><init>(La_55FC5DDC;Landroid/content/res/Resources;)V

    return-object v0
.end method

.method public m_afd718b8(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 2
    new-instance v0, Lat;

    invoke-direct {v0, p0, p1}, Lat;-><init>(La_55FC5DDC;Landroid/content/res/Resources;)V

    return-object v0
.end method
