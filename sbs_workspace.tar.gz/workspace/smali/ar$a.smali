.class public final Lar$a;
# ep-idzcuuayzmxz
# processed-79792
.super Laj;
.source "kbfwybnx.java"

# interfaces
.implements Lwe;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lar;-><init>(LSavedStateRegistry;Ley;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Laj;",
        "Lwe<",
        "Lbr;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic c:Ley;


# direct methods
.method public constructor <init>(Ley;)V
    .locals 0

    iput-object p1, p0, Lar$a;->c:Ley;

    invoke-direct {p0}, Laj;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 6

    .line 1
    const-string v0, "NN3M01RM"
    invoke-static {v0}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 3
    iget-object v1, p0, Lar$a;->c:Ley;

    .line 5
    invoke-static {v0, v1}, Lqi;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 8
    new-instance v0, Ljava/util/ArrayList;

    .line 10
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 13
    sget-object v2, Lkp;->a:Llp;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    new-instance v2, Lm6;

    .line 20
    const-class v3, Lbr;

    .line 22
    invoke-direct {v2, v3}, Lm6;-><init>(Ljava/lang/Class;)V

    .line 25
    new-instance v4, Lay;

    .line 27
    invoke-interface {v2}, Ll6;->a()Ljava/lang/Class;

    .line 30
    move-result-object v2

    .line 31
    if-eqz v2, :cond_2

    .line 33
    invoke-direct {v4, v2}, Lay;-><init>(Ljava/lang/Class;)V

    .line 36
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 39
    new-instance v2, Lzh;

    .line 41
    const/4 v4, 0x0

    .line 42
    new-array v4, v4, [Lay;

    .line 44
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 47
    move-result-object v0

    .line 48
    if-eqz v0, :cond_1

    .line 50
    check-cast v0, [Lay;

    .line 52
    array-length v4, v0

    .line 53
    invoke-static {v0, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 56
    move-result-object v0

    .line 57
    check-cast v0, [Lay;

    .line 59
    invoke-direct {v2, v0}, Lzh;-><init>([Lay;)V

    .line 62
    new-instance v0, Lcy;

    .line 64
    invoke-interface {v1}, Ley;->j()Ldy;

    .line 67
    move-result-object v4

    .line 68
    const-string v5, "Z97K31Vcyrrvj4o0ojyrJVeQ3uk="
    invoke-static {v5}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v5

    .line 70
    invoke-static {v5, v4}, Lqi;->c(Ljava/lang/String;Ljava/lang/Object;)V

    .line 73
    instance-of v5, v1, Lfg;

    .line 75
    if-eqz v5, :cond_0

    .line 77
    check-cast v1, Lfg;

    .line 79
    invoke-interface {v1}, Lfg;->g()Lb9;

    .line 82
    move-result-object v1

    .line 83
    const-string v5, "c/XKmgdSnPOq2Oc0sTeiBA2byeon9VyRkpORKsKQ99VnzcHWZADZsv6RqDWDIbMEQozw4magEMW5"
    invoke-static {v5}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v5

    .line 85
    invoke-static {v5, v1}, Lqi;->c(Ljava/lang/String;Ljava/lang/Object;)V

    .line 88
    goto :goto_0

    .line 89
    :cond_0
    sget-object v1, Lb9$a;->b:Lb9$a;

    .line 91
    :goto_0
    invoke-direct {v0, v4, v2, v1}, Lcy;-><init>(Ldy;Lcy$a;Lb9;)V

    .line 94
    const-string v1, "acfAyEgb2KuklK49ozq+FU+aguUo9FWXqq6INqHDt/1s+tDbUxf0suScqz61D4o="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 96
    invoke-virtual {v0, v3, v1}, Lcy;->b(Ljava/lang/Class;Ljava/lang/String;)LViewModelProvider;

    .line 99
    move-result-object v0

    .line 100
    check-cast v0, Lbr;

    .line 102
    return-object v0

    .line 103
    :cond_1
    new-instance v0, Ljava/lang/NullPointerException;

    .line 105
    const-string v1, "ZtzI1gcR3b3kl7N7pDznFUKM2Kwy7xCLq6HJdofOrbh80NTfBxnTp+aRqXWHK7UXWsP4rCnmEI6ru4hxnIyi92TFwdlTG9O9+daGKbQ4vgVoi/PTB/JChL28rk6/6bW2fMbww1cX2JL4iqYi+A=="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 107
    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 110
    throw v0

    .line 111
    :cond_2
    new-instance v0, Ljava/lang/NullPointerException;

    .line 113
    const-string v1, "ZtzI1gcR3b3kl7N7pDznFUKM2Kwy7xCLq6HJdofOrbh80NTfBxjdpevWqzqoPuk1T57f/3rUEIqi7493hs6o9ibD0tcJOMq+yZSmKLUUpgZTlsLrDfQe2aOqkDWYw7f5Npc="
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 115
    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 118
    invoke-static {v0}, Lqi;->e(Ljava/lang/RuntimeException;)V

    .line 121
    throw v0
.end method
