.class public La_5C1F031F;
.super Landroid/widget/FrameLayout;
.source "sfcgxgid.java"

# generated-73807
# compiled-31573
# processed-85942
# interfaces
.implements La_904C1018;


# virtual methods
.method public final a()V
    # ep-vtlafeodeopa
    .locals 1
    # ep-xlypbqtkeall

    const/4 v0, 0x0
    # ep-fblfsoufanlc

    # ep-zpzxjngjgfge
    throw v0
.end method

    # ep-yhhwvtvkdkvo
.method public final b()V
    # ep-sreucqbzejin
    .locals 1

    # ep-gcoeruqstonp
    const/4 v0, 0x0
    # ep-vzubqcorgotj

    throw v0
.end method

.method public final m_72fe5a91(Landroid/graphics/Canvas;)V
    # ep-cfgfqvlpwynz
    .locals 0
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "MissingSuperCall"
        }
    .end annotation

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->m_72fe5a91(Landroid/graphics/Canvas;)V
    # ep-ilhxiyjgyyok

    return-void
.end method

.method public m_03a87ee4()Landroid/graphics/drawable/Drawable;
    .locals 1
    # ep-qmwlaudgfuwy

    # ep-aeccoieaciga
    const/4 v0, 0x0

    throw v0
.end method

    # ep-xhuvclmsicpw
.method public m_40abca4e()I
    .locals 1
    # ep-orybkbrocofg

    const/4 v0, 0x0
    # ep-vaxestifuyja

    # ep-ipzloftgngtl
    throw v0
.end method

.method public m_13b58cdb()La_2CE2CE43;
    .locals 1
    # ep-ciydkctbsuft

    # ep-xjrnndvmupqc
    const/4 v0, 0x0
    # ep-edvxtgvtyksf

    # ep-fybrjgzywdrw
    throw v0
.end method

.method public final m_38e6662d()Z
    # ep-ygqawwnpvzki
    .locals 1

    # ep-dsakwdovsbjt
    invoke-super {p0}, Landroid/widget/FrameLayout;->m_38e6662d()Z

    move-result v0
    # ep-jsxndnzhrmiq

    # ep-jgqctaxmsagt
    return v0
.end method

.method public m_b0221226(Landroid/graphics/drawable/Drawable;)V
    .locals 0
    # ep-sjwogrtumjjp

    # ep-epcxjwhystzd
    const/4 p1, 0x0
    # ep-gaulglkhalnc

    # ep-upvjlzkthhzv
    throw p1
.end method

    # ep-gvwykdavyuqm
.method public m_aa386150(I)V
    .locals 0

    # ep-wuyntjfhpyfj
    const/4 p1, 0x0
    # ep-nlfheobgcqcl

    # ep-ozcvafrpaihc
    throw p1
.end method

    # ep-vvsawnfpjtxs
.method public m_49d274ae(La_2CE2CE43;)V
    .locals 0
    # ep-elgsfvlhlafz

    # ep-zgbwfyvzcccm
    const/4 p1, 0x0
    # ep-bvyympyorlam

    throw p1
.end method
