.class public final La_8AE2D906;
.super La_4D1064AD;
.source "bcweenuk.java"

# compiled-30975
# ep-kixnsrmuvozl

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field public final a:Landroid/graphics/Matrix;

.field public final b:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "La_4D1064AD;",
            ">;"
        }
    .end annotation
.end field

.field public c:F

.field public d:F

.field public e:F

.field public f:F

.field public g:F

.field public h:F

.field public i:F

.field public final j:Landroid/graphics/Matrix;

.field public final k:I

.field public l:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, La_4D1064AD;-><init>()V

    .line 2
    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La_8AE2D906;->a:Landroid/graphics/Matrix;

    .line 3
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La_8AE2D906;->b:Ljava/util/ArrayList;

    const/4 v0, 0x0

    .line 4
    iput v0, p0, La_8AE2D906;->c:F

    .line 5
    iput v0, p0, La_8AE2D906;->d:F

    .line 6
    iput v0, p0, La_8AE2D906;->e:F

    const/high16 v1, 0x3f800000    # 1.0f

    .line 7
    iput v1, p0, La_8AE2D906;->f:F

    .line 8
    iput v1, p0, La_8AE2D906;->g:F

    .line 9
    iput v0, p0, La_8AE2D906;->h:F

    .line 10
    iput v0, p0, La_8AE2D906;->i:F

    .line 11
    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La_8AE2D906;->j:Landroid/graphics/Matrix;

    const/4 v0, 0x0

    .line 12
    iput-object v0, p0, La_8AE2D906;->l:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(La_8AE2D906;La_517C27AD;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La_8AE2D906;",
            "Lj3<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    .line 13
    invoke-direct {p0}, La_4D1064AD;-><init>()V

    .line 14
    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La_8AE2D906;->a:Landroid/graphics/Matrix;

    .line 15
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La_8AE2D906;->b:Ljava/util/ArrayList;

    const/4 v0, 0x0

    .line 16
    iput v0, p0, La_8AE2D906;->c:F

    .line 17
    iput v0, p0, La_8AE2D906;->d:F

    .line 18
    iput v0, p0, La_8AE2D906;->e:F

    const/high16 v1, 0x3f800000    # 1.0f

    .line 19
    iput v1, p0, La_8AE2D906;->f:F

    .line 20
    iput v1, p0, La_8AE2D906;->g:F

    .line 21
    iput v0, p0, La_8AE2D906;->h:F

    .line 22
    iput v0, p0, La_8AE2D906;->i:F

    .line 23
    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La_8AE2D906;->j:Landroid/graphics/Matrix;

    const/4 v1, 0x0

    .line 24
    iput-object v1, p0, La_8AE2D906;->l:Ljava/lang/String;

    .line 25
    iget v1, p1, La_8AE2D906;->c:F

    iput v1, p0, La_8AE2D906;->c:F

    .line 26
    iget v1, p1, La_8AE2D906;->d:F

    iput v1, p0, La_8AE2D906;->d:F

    .line 27
    iget v1, p1, La_8AE2D906;->e:F

    iput v1, p0, La_8AE2D906;->e:F

    .line 28
    iget v1, p1, La_8AE2D906;->f:F

    iput v1, p0, La_8AE2D906;->f:F

    .line 29
    iget v1, p1, La_8AE2D906;->g:F

    iput v1, p0, La_8AE2D906;->g:F

    .line 30
    iget v1, p1, La_8AE2D906;->h:F

    iput v1, p0, La_8AE2D906;->h:F

    .line 31
    iget v1, p1, La_8AE2D906;->i:F

    iput v1, p0, La_8AE2D906;->i:F

    .line 32
    iget-object v1, p1, La_8AE2D906;->l:Ljava/lang/String;

    iput-object v1, p0, La_8AE2D906;->l:Ljava/lang/String;

    .line 33
    iget v2, p1, La_8AE2D906;->k:I

    iput v2, p0, La_8AE2D906;->k:I

    if-eqz v1, :cond_0

    .line 34
    invoke-virtual {p2, v1, p0}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    :cond_0
    iget-object v1, p1, La_8AE2D906;->j:Landroid/graphics/Matrix;

    invoke-virtual {v0, v1}, Landroid/graphics/Matrix;->set(Landroid/graphics/Matrix;)V

    .line 36
    iget-object p1, p1, La_8AE2D906;->b:Ljava/util/ArrayList;

    const/4 v0, 0x0

    .line 37
    :goto_0
    invoke-virtual {p1}, Ljava/util/ArrayList;->m_79017b7d()I

    move-result v1

    if-ge v0, v1, :cond_5

    .line 38
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    .line 39
    instance-of v2, v1, La_8AE2D906;

    if-eqz v2, :cond_1

    .line 40
    check-cast v1, La_8AE2D906;

    .line 41
    iget-object v2, p0, La_8AE2D906;->b:Ljava/util/ArrayList;

    new-instance v3, La_8AE2D906;

    invoke-direct {v3, v1, p2}, La_8AE2D906;-><init>(La_8AE2D906;La_517C27AD;)V

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 42
    :cond_1
    instance-of v2, v1, La_72726CEF;

    if-eqz v2, :cond_2

    .line 43
    new-instance v2, La_72726CEF;

    check-cast v1, La_72726CEF;

    invoke-direct {v2, v1}, La_72726CEF;-><init>(La_72726CEF;)V

    goto :goto_1

    .line 44
    :cond_2
    instance-of v2, v1, La_DFC72DBB;

    if-eqz v2, :cond_4

    .line 45
    new-instance v2, La_DFC72DBB;

    check-cast v1, La_DFC72DBB;

    invoke-direct {v2, v1}, La_DFC72DBB;-><init>(La_DFC72DBB;)V

    .line 46
    :goto_1
    iget-object v1, p0, La_8AE2D906;->b:Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 47
    iget-object v1, v2, La_B84924DD;->b:Ljava/lang/String;

    if-eqz v1, :cond_3

    .line 48
    invoke-virtual {p2, v1, v2}, Lks;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3
    :goto_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 49
    :cond_4
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Unknown object in the tree!"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5
    return-void
.end method


# virtual methods
.method public final a()Z
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    :goto_0
    iget-object v2, p0, La_8AE2D906;->b:Ljava/util/ArrayList;

    .line 5
    invoke-virtual {v2}, Ljava/util/ArrayList;->m_79017b7d()I

    .line 8
    move-result v3

    .line 9
    if-ge v1, v3, :cond_1

    .line 11
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 14
    move-result-object v2

    .line 15
    check-cast v2, La_4D1064AD;

    .line 17
    invoke-virtual {v2}, La_4D1064AD;->a()Z

    .line 20
    move-result v2

    .line 21
    if-eqz v2, :cond_0

    .line 23
    const/4 v0, 0x1

    .line 24
    return v0

    .line 25
    :cond_0
    add-int/lit8 v1, v1, 0x1

    .line 27
    goto :goto_0

    .line 28
    :cond_1
    return v0
.end method

.method public final b([I)Z
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    :goto_0
    iget-object v2, p0, La_8AE2D906;->b:Ljava/util/ArrayList;

    .line 5
    invoke-virtual {v2}, Ljava/util/ArrayList;->m_79017b7d()I

    .line 8
    move-result v3

    .line 9
    if-ge v0, v3, :cond_0

    .line 11
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 14
    move-result-object v2

    .line 15
    check-cast v2, La_4D1064AD;

    .line 17
    invoke-virtual {v2, p1}, La_4D1064AD;->b([I)Z

    .line 20
    move-result v2

    .line 21
    or-int/2addr v1, v2

    .line 22
    add-int/lit8 v0, v0, 0x1

    .line 24
    goto :goto_0

    .line 25
    :cond_0
    return v1
.end method

.method public final c()V
    .locals 4

    .line 1
    iget-object v0, p0, La_8AE2D906;->j:Landroid/graphics/Matrix;

    .line 3
    invoke-virtual {v0}, Landroid/graphics/Matrix;->reset()V

    .line 6
    iget v1, p0, La_8AE2D906;->d:F

    .line 8
    neg-float v1, v1

    .line 9
    iget v2, p0, La_8AE2D906;->e:F

    .line 11
    neg-float v2, v2

    .line 12
    invoke-virtual {v0, v1, v2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 15
    iget v1, p0, La_8AE2D906;->f:F

    .line 17
    iget v2, p0, La_8AE2D906;->g:F

    .line 19
    invoke-virtual {v0, v1, v2}, Landroid/graphics/Matrix;->postScale(FF)Z

    .line 22
    iget v1, p0, La_8AE2D906;->c:F

    .line 24
    const/4 v2, 0x0

    .line 25
    invoke-virtual {v0, v1, v2, v2}, Landroid/graphics/Matrix;->postRotate(FFF)Z

    .line 28
    iget v1, p0, La_8AE2D906;->h:F

    .line 30
    iget v2, p0, La_8AE2D906;->d:F

    .line 32
    add-float/2addr v1, v2

    .line 33
    iget v2, p0, La_8AE2D906;->i:F

    .line 35
    iget v3, p0, La_8AE2D906;->e:F

    .line 37
    add-float/2addr v2, v3

    .line 38
    invoke-virtual {v0, v1, v2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 41
    return-void
.end method

.method public m_c69bc182()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La_8AE2D906;->l:Ljava/lang/String;

    return-object v0
.end method

.method public m_49145938()Landroid/graphics/Matrix;
    .locals 1

    iget-object v0, p0, La_8AE2D906;->j:Landroid/graphics/Matrix;

    return-object v0
.end method

.method public m_a2eb42b9()F
    .locals 1

    iget v0, p0, La_8AE2D906;->d:F

    return v0
.end method

.method public m_12362fac()F
    .locals 1

    iget v0, p0, La_8AE2D906;->e:F

    return v0
.end method

.method public m_8abd294f()F
    .locals 1

    iget v0, p0, La_8AE2D906;->c:F

    return v0
.end method

.method public m_b248be20()F
    .locals 1

    iget v0, p0, La_8AE2D906;->f:F

    return v0
.end method

.method public m_87c5f1bc()F
    .locals 1

    iget v0, p0, La_8AE2D906;->g:F

    return v0
.end method

.method public m_5d3ca095()F
    .locals 1

    iget v0, p0, La_8AE2D906;->h:F

    return v0
.end method

.method public m_a4152e59()F
    .locals 1

    iget v0, p0, La_8AE2D906;->i:F

    return v0
.end method

.method public m_feb796f3(F)V
    .locals 1

    .line 1
    iget v0, p0, La_8AE2D906;->d:F

    .line 3
    cmpl-float v0, p1, v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    iput p1, p0, La_8AE2D906;->d:F

    .line 9
    invoke-virtual {p0}, La_8AE2D906;->c()V

    .line 12
    :cond_0
    return-void
.end method

.method public m_722ff938(F)V
    .locals 1

    .line 1
    iget v0, p0, La_8AE2D906;->e:F

    .line 3
    cmpl-float v0, p1, v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    iput p1, p0, La_8AE2D906;->e:F

    .line 9
    invoke-virtual {p0}, La_8AE2D906;->c()V

    .line 12
    :cond_0
    return-void
.end method

.method public m_78862b38(F)V
    .locals 1

    .line 1
    iget v0, p0, La_8AE2D906;->c:F

    .line 3
    cmpl-float v0, p1, v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    iput p1, p0, La_8AE2D906;->c:F

    .line 9
    invoke-virtual {p0}, La_8AE2D906;->c()V

    .line 12
    :cond_0
    return-void
.end method

.method public m_42865609(F)V
    .locals 1

    .line 1
    iget v0, p0, La_8AE2D906;->f:F

    .line 3
    cmpl-float v0, p1, v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    iput p1, p0, La_8AE2D906;->f:F

    .line 9
    invoke-virtual {p0}, La_8AE2D906;->c()V

    .line 12
    :cond_0
    return-void
.end method

.method public m_1e9129a9(F)V
    .locals 1

    .line 1
    iget v0, p0, La_8AE2D906;->g:F

    .line 3
    cmpl-float v0, p1, v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    iput p1, p0, La_8AE2D906;->g:F

    .line 9
    invoke-virtual {p0}, La_8AE2D906;->c()V

    .line 12
    :cond_0
    return-void
.end method

.method public m_8ffde38d(F)V
    .locals 1

    .line 1
    iget v0, p0, La_8AE2D906;->h:F

    .line 3
    cmpl-float v0, p1, v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    iput p1, p0, La_8AE2D906;->h:F

    .line 9
    invoke-virtual {p0}, La_8AE2D906;->c()V

    .line 12
    :cond_0
    return-void
.end method

.method public m_4e05b3fa(F)V
    .locals 1

    .line 1
    iget v0, p0, La_8AE2D906;->i:F

    .line 3
    cmpl-float v0, p1, v0

    .line 5
    if-eqz v0, :cond_0

    .line 7
    iput p1, p0, La_8AE2D906;->i:F

    .line 9
    invoke-virtual {p0}, La_8AE2D906;->c()V

    .line 12
    :cond_0
    return-void
.end method
