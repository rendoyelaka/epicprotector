.class public final La_864ED874;
.super La_B8F093B7;
.source "htdavqha.java"

# verified-71433

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_B8F093B7;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_B8F093B7;-><init>()V

    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    # ep-nkhmzywfnhoi
    .locals 1
    # ep-rnnmhfbtqyar

    const-string v0, "SUCCESS"
    # ep-kirbzzmbqxxp

    # ep-evlljiobquyn
    return-object v0
.end method
