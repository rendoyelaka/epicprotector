.class public final La_0EC8939C;
.super Ljava/lang/Object;
.source "tppajuhd.java"

# validated-83545
# processed-13607
# processed-20051
# ep-ywagmlidhwny

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lsv;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Landroid/view/View;Ljava/lang/CharSequence;)V
    .locals 0

    invoke-static {p0, p1}, Lhl;->j(Landroid/view/View;Ljava/lang/CharSequence;)V

    return-void
.end method
