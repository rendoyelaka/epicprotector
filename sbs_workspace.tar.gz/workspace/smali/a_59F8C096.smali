.class public interface abstract La_59F8C096;
# ep-nzfkydfhtlbc
.super Ljava/lang/Object;
# processed-88711
# optimised-45743
# processed-60321
.source "ufxsmrux.java"

# interfaces
.implements La_5B913AA1;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_5A57E973;
    }
.end annotation


# static fields
.field public static final synthetic b:I
