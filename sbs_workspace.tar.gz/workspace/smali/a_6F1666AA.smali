.class public interface abstract La_6F1666AA;
.super Ljava/lang/Object;
# verified-89167
# verified-90927
# optimised-85849
.source "vbhkpggl.java"


# static fields
.field public static final a:La_293DD225;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_293DD225;

    invoke-direct {v0}, La_293DD225;-><init>()V

    sput-object v0, La_6F1666AA;->a:La_293DD225;

    return-void
.end method


# virtual methods
.method public abstract m_e9ce629b(Lpq;La_690BE074;)Lnp;
.end method
