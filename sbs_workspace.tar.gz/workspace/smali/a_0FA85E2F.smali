.class public final La_0FA85E2F;
.super Lsd;
# processed-75525
# processed-61578
.source "sgubthhz.java"

# ep-ddeboclgorvy

# instance fields
.field public final synthetic l:La_1862CD37;

.field public final synthetic m:La_65A6AE87;


# direct methods
.method public constructor <init>(La_65A6AE87;Landroid/view/View;La_1862CD37;)V
    .locals 0

    iput-object p1, p0, La_0FA85E2F;->m:La_65A6AE87;

    iput-object p3, p0, La_0FA85E2F;->l:La_1862CD37;

    invoke-direct {p0, p2}, Lsd;-><init>(Landroid/view/View;)V

    return-void
.end method


# virtual methods
.method public final b()Lgs;
    .locals 1

    iget-object v0, p0, La_0FA85E2F;->l:La_1862CD37;

    return-object v0
.end method

.method public final c()Z
    .locals 3
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SyntheticAccessor"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_0FA85E2F;->m:La_65A6AE87;

    .line 3
    invoke-virtual {v0}, La_65A6AE87;->m_eb64fd61()La_87E2DDC0;

    .line 6
    move-result-object v1

    .line 7
    invoke-interface {v1}, La_87E2DDC0;->b()Z

    .line 10
    move-result v1

    .line 11
    if-nez v1, :cond_0

    .line 13
    invoke-static {v0}, La_E13CED78;->b(Landroid/view/View;)I

    .line 16
    move-result v1

    .line 17
    invoke-static {v0}, La_E13CED78;->a(Landroid/view/View;)I

    .line 20
    move-result v2

    .line 21
    iget-object v0, v0, La_65A6AE87;->h:La_87E2DDC0;

    .line 23
    invoke-interface {v0, v1, v2}, La_87E2DDC0;->m(II)V

    .line 26
    :cond_0
    const/4 v0, 0x1

    .line 27
    return v0
.end method
