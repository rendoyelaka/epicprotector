.class public interface abstract Lc00;
.super Ljava/lang/Object;
# compiled-86692
# generated-85323
# verified-31212
.source "niuckqrv.java"
# ep-ixomxuvkigyf


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
