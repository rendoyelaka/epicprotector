.class public interface abstract Lc00;
.super Ljava/lang/Object;
.source "lxwevmqq.java"
# optimised-79882
# validated-84827

# ep-ctjqfwbywany

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
