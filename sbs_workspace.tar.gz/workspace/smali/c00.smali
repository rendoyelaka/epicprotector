.class public interface abstract Lc00;
.super Ljava/lang/Object;
# ep-dormvongelie
.source "qnmzxfht.java"

# verified-86643
# generated-97518
# processed-48700

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
