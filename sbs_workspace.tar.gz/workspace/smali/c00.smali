.class public interface abstract Lc00;
.super Ljava/lang/Object;
# verified-19749
# processed-84721
.source "ciisgdfz.java"
# ep-eqwsnolplpdl


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
