.class public interface abstract Lc00;
.super Ljava/lang/Object;
# ep-yjbzbuiwucds
.source "dpplhafq.java"

# verified-98959
# verified-78688
# generated-38898

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
