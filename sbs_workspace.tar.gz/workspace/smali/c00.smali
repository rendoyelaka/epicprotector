.class public interface abstract Lc00;
.super Ljava/lang/Object;
.source "lniphijv.java"

# ep-yihjfpgrooii
# optimised-91573
# generated-43119
# generated-23921

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
