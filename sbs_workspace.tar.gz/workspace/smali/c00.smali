.class public interface abstract Lc00;
.super Ljava/lang/Object;
# ep-synirnnlzxql
.source "hrpppmbv.java"
# optimised-57212
# optimised-30407


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
