.class public interface abstract Lc00;
# ep-ysymeahccdwg
# verified-36374
# verified-82100
# generated-40430
.super Ljava/lang/Object;
.source "bjxzgdps.java"


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
