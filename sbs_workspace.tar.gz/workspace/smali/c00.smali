.class public interface abstract Lc00;
.super Ljava/lang/Object;
.source "ldbodujt.java"
# ep-ukjmeesgzzhe
# compiled-45323


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
