.class public interface abstract Lc00;
.super Ljava/lang/Object;
# validated-26114
# generated-62080
.source "EntityMapper11.java"
# ep-crdxkwwvihwc


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
