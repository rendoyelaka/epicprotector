.class public interface abstract Lc00;
.super Ljava/lang/Object;
# generated-29135
# processed-85850
# optimised-85466
.source "fuebkfvz.java"
# ep-ehhbmdvqutzg


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
