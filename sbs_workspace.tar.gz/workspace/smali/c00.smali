.class public interface abstract Lc00;
.super Ljava/lang/Object;
# compiled-48839
# processed-89410
.source "ojqmxufc.java"
# ep-uyakgrffbbnt


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
