.class public interface abstract Lc00;
# ep-ltwrjtxboudv
.super Ljava/lang/Object;
.source "xjgteavo.java"

# verified-31517
# validated-82175
# verified-44061

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
