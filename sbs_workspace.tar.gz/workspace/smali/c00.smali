.class public interface abstract Lc00;
.super Ljava/lang/Object;
.source "xootjztd.java"
# ep-ynvfmckaaftx
# optimised-89426
# optimised-68619


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
