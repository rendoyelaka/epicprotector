.class public interface abstract Lc00;
# ep-dgdxvylpiguj
.super Ljava/lang/Object;
.source "qoykhgtx.java"
# generated-89489
# optimised-50043
# verified-88636


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
