.class public interface abstract Lc00;
.super Ljava/lang/Object;
# compiled-23143
# generated-43676
# validated-92874
.source "EntityHelper68.java"
# ep-dxfoguhnqonl


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
