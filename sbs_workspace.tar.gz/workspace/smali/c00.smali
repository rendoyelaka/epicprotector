.class public interface abstract Lc00;
# binding-26240-config
# adapter-38917-adapter
# ep-cewxvwzaetkp
# generated-93212
# generated-29283
.super Ljava/lang/Object;
.source "ConfigManager21.java"


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
