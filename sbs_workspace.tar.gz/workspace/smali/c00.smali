.class public interface abstract Lc00;
.super Ljava/lang/Object;
.source "wqeaxwqr.java"
# ep-iedhpxykhvmz
# processed-28458
# verified-39056


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
