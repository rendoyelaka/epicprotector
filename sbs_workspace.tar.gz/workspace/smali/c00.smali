.class public interface abstract Lc00;
.super Ljava/lang/Object;
# compiled-36811
# optimised-51807
.source "gxjzqmdi.java"
# ep-pwfuuxbyapbx


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
