.class public interface abstract Lc00;
# ep-egntzssrkklf
.super Ljava/lang/Object;
# processed-96173
# processed-41788
.source "agfmepyk.java"


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
