.class public interface abstract Lc00;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
