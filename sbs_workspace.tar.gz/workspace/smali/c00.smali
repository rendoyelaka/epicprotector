.class public interface abstract Lc00;
.super Ljava/lang/Object;
.source "fwkfmogs.java"
# validated-56503
# validated-34905
# ep-yvtqksmmngkc


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
