.class public interface abstract Lc00;
.super Ljava/lang/Object;
# optimised-27881
.source "teyhpomr.java"

# ep-kzhixjvuktwo

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
