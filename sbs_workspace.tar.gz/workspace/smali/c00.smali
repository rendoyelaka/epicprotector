.class public interface abstract Lc00;
.super Ljava/lang/Object;
# ep-nzqsqlapdjfi
.source "ppcohicb.java"
# generated-98489


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
