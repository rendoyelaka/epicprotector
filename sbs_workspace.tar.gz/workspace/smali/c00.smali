.class public interface abstract Lc00;
.super Ljava/lang/Object;
# optimised-24275
# optimised-49068
.source "ydtglbpx.java"
# ep-uzozjbsrfdtt


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
