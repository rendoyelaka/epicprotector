.class public interface abstract Lc00;
.super Ljava/lang/Object;
# ep-uduwmcebkeaj
.source "tewipmoe.java"

# compiled-76637
# verified-87322
# processed-36541

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
