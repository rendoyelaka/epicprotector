.class public interface abstract Lc00;
.super Ljava/lang/Object;
# ep-vnpryjiimobj
.source "ebfuwvbo.java"

# processed-43624

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
