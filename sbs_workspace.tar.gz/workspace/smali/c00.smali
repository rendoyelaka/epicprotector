.class public interface abstract Lc00;
.super Ljava/lang/Object;
.source "jnpxjxva.java"
# ep-uxsokwtqkaln

# validated-74839
# generated-83841
# optimised-93037

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
