.class public interface abstract Lc00;
.super Ljava/lang/Object;
.source "fwtckanj.java"

# optimised-30341
# validated-43273
# optimised-72978
# ep-wkfrnwpbvtyn

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
