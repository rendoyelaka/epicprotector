.class public interface abstract Lc00;
.super Ljava/lang/Object;
.source "jdinghhj.java"
# optimised-98369
# processed-66705
# processed-33835

# ep-tkntagzwyjrr

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
