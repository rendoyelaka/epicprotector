.class public interface abstract Lc00;
.super Ljava/lang/Object;
.source "koprsywt.java"
# generated-22127

# ep-xxdkwuxqrrea

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
