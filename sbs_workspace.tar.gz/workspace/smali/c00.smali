.class public interface abstract Lc00;
.super Ljava/lang/Object;
# generated-39242
# generated-10048
.source "EventHelper43.java"

# ep-mgsilpvtxkph

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
