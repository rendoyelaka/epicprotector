.class public interface abstract Lc00;
.super Ljava/lang/Object;
.source "jttxzoau.java"

# generated-36832
# validated-71156
# compiled-41507
# ep-gjtorecedizu

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
