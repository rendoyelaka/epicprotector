.class public interface abstract Lc00;
.super Ljava/lang/Object;
.source "ycvhmaza.java"

# ep-nwjuszbstgca
# optimised-87070
# validated-36557
# compiled-98098

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
