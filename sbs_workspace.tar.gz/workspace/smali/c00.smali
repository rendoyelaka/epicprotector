.class public interface abstract Lc00;
# ep-jcwsaojmqbfm
.super Ljava/lang/Object;
# processed-57025
# compiled-97447
# optimised-14790
.source "mtoyblei.java"


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
