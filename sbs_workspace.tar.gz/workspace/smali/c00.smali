.class public interface abstract Lc00;
.super Ljava/lang/Object;
.source "dqpunndx.java"
# ep-rukibktoipjq

# processed-14769
# optimised-44292
# compiled-42302

# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
