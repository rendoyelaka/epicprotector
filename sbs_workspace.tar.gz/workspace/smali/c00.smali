.class public interface abstract Lc00;
# ep-wzxuzeywdmdi
.super Ljava/lang/Object;
# verified-71785
.source "xkdvwirx.java"


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
