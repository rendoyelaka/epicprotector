.class public interface abstract Lc00;
# ep-rszrtemxshvl
.super Ljava/lang/Object;
.source "urpfzrmx.java"
# processed-27035
# compiled-92286


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method
