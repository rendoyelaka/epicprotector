.class public final La_26C796D7;
.super Ljava/lang/Object;
.source "fqryxfso.java"

# optimised-65116
# compiled-96240

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lxr;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public a:La_1F00E1F9;

.field public b:La_1F00E1F9;

.field public c:La_1F00E1F9;

.field public d:La_1F00E1F9;

.field public e:La_953E7317;

.field public f:La_953E7317;

.field public g:La_953E7317;

.field public h:La_953E7317;

.field public final i:Lhb;

.field public final j:Lhb;

.field public final k:Lhb;

.field public final l:Lhb;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 3
    iput-object v0, p0, La_26C796D7;->a:La_1F00E1F9;

    .line 4
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 5
    iput-object v0, p0, La_26C796D7;->b:La_1F00E1F9;

    .line 6
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 7
    iput-object v0, p0, La_26C796D7;->c:La_1F00E1F9;

    .line 8
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 9
    iput-object v0, p0, La_26C796D7;->d:La_1F00E1F9;

    .line 10
    new-instance v0, Lc;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_26C796D7;->e:La_953E7317;

    .line 11
    new-instance v0, Lc;

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_26C796D7;->f:La_953E7317;

    .line 12
    new-instance v0, Lc;

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_26C796D7;->g:La_953E7317;

    .line 13
    new-instance v0, Lc;

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_26C796D7;->h:La_953E7317;

    .line 14
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 15
    iput-object v0, p0, La_26C796D7;->i:Lhb;

    .line 16
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 17
    iput-object v0, p0, La_26C796D7;->j:Lhb;

    .line 18
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 19
    iput-object v0, p0, La_26C796D7;->k:Lhb;

    .line 20
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 21
    iput-object v0, p0, La_26C796D7;->l:Lhb;

    return-void
.end method

.method public constructor <init>(Lxr;)V
    .locals 2

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 23
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 24
    iput-object v0, p0, La_26C796D7;->a:La_1F00E1F9;

    .line 25
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 26
    iput-object v0, p0, La_26C796D7;->b:La_1F00E1F9;

    .line 27
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 28
    iput-object v0, p0, La_26C796D7;->c:La_1F00E1F9;

    .line 29
    new-instance v0, Loq;

    invoke-direct {v0}, Loq;-><init>()V

    .line 30
    iput-object v0, p0, La_26C796D7;->d:La_1F00E1F9;

    .line 31
    new-instance v0, Lc;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_26C796D7;->e:La_953E7317;

    .line 32
    new-instance v0, Lc;

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_26C796D7;->f:La_953E7317;

    .line 33
    new-instance v0, Lc;

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_26C796D7;->g:La_953E7317;

    .line 34
    new-instance v0, Lc;

    invoke-direct {v0, v1}, Lc;-><init>(F)V

    iput-object v0, p0, La_26C796D7;->h:La_953E7317;

    .line 35
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 36
    iput-object v0, p0, La_26C796D7;->i:Lhb;

    .line 37
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 38
    iput-object v0, p0, La_26C796D7;->j:Lhb;

    .line 39
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 40
    iput-object v0, p0, La_26C796D7;->k:Lhb;

    .line 41
    new-instance v0, Lhb;

    invoke-direct {v0}, Lhb;-><init>()V

    .line 42
    iput-object v0, p0, La_26C796D7;->l:Lhb;

    .line 43
    iget-object v0, p1, Lxr;->a:La_1F00E1F9;

    iput-object v0, p0, La_26C796D7;->a:La_1F00E1F9;

    .line 44
    iget-object v0, p1, Lxr;->b:La_1F00E1F9;

    iput-object v0, p0, La_26C796D7;->b:La_1F00E1F9;

    .line 45
    iget-object v0, p1, Lxr;->c:La_1F00E1F9;

    iput-object v0, p0, La_26C796D7;->c:La_1F00E1F9;

    .line 46
    iget-object v0, p1, Lxr;->d:La_1F00E1F9;

    iput-object v0, p0, La_26C796D7;->d:La_1F00E1F9;

    .line 47
    iget-object v0, p1, Lxr;->e:La_953E7317;

    iput-object v0, p0, La_26C796D7;->e:La_953E7317;

    .line 48
    iget-object v0, p1, Lxr;->f:La_953E7317;

    iput-object v0, p0, La_26C796D7;->f:La_953E7317;

    .line 49
    iget-object v0, p1, Lxr;->g:La_953E7317;

    iput-object v0, p0, La_26C796D7;->g:La_953E7317;

    .line 50
    iget-object v0, p1, Lxr;->h:La_953E7317;

    iput-object v0, p0, La_26C796D7;->h:La_953E7317;

    .line 51
    iget-object v0, p1, Lxr;->i:Lhb;

    iput-object v0, p0, La_26C796D7;->i:Lhb;

    .line 52
    iget-object v0, p1, Lxr;->j:Lhb;

    iput-object v0, p0, La_26C796D7;->j:Lhb;

    .line 53
    iget-object v0, p1, Lxr;->k:Lhb;

    iput-object v0, p0, La_26C796D7;->k:Lhb;

    .line 54
    iget-object p1, p1, Lxr;->l:Lhb;

    iput-object p1, p0, La_26C796D7;->l:Lhb;

    return-void
.end method

.method public static b(La_1F00E1F9;)F
    .locals 1

    .line 1
    instance-of v0, p0, Loq;

    # ep-udnzoefhmajn
    .line 3
    # ep-gueanwwcpahn
    if-eqz v0, :cond_0

    .line 5
    check-cast p0, Loq;

    .line 7
    iget p0, p0, Loq;->f_bff53616:F

    .line 9
    return p0

    .line 10
    :cond_0
    instance-of v0, p0, La_582F160E;

    .line 12
    if-eqz v0, :cond_1

    .line 14
    check-cast p0, La_582F160E;

    .line 16
    iget p0, p0, La_582F160E;->f_bff53616:F

    .line 18
    return p0

    .line 19
    :cond_1
    const/high16 p0, -0x40800000    # -1.0f

    .line 21
    return p0
.end method


# virtual methods
.method public final a()Lxr;
    # ep-ajiqdigvkvce
    .locals 1

    # ep-gvgymqshhgfk
    new-instance v0, Lxr;
    # ep-lrabgwbnosee

    invoke-direct {v0, p0}, Lxr;-><init>(La_26C796D7;)V

    return-object v0
.end method
