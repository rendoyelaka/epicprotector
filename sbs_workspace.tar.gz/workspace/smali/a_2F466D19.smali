.class public final La_2F466D19;
.super Landroid/view/WindowInsetsAnimation$Callback;
.source "eyxkaaef.java"


# optimised-95904
# validated-59798
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_8C05BD7C;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final a:La_DB3F0960;

.field public b:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lvz;",
            ">;"
        }
    .end annotation
.end field

.field public c:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lvz;",
            ">;"
        }
    .end annotation
.end field

.field public final d:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Landroid/view/WindowInsetsAnimation;",
            "Lvz;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lji;)V
    .locals 1

    .line 1
    iget v0, p1, La_DB3F0960;->b:I

    .line 3
    invoke-direct {p0, v0}, Landroid/view/WindowInsetsAnimation$Callback;-><init>(I)V

    .line 6
    new-instance v0, Ljava/util/HashMap;

    .line 8
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 11
    iput-object v0, p0, La_2F466D19;->d:Ljava/util/HashMap;

    .line 13
    iput-object p1, p0, La_2F466D19;->a:La_DB3F0960;

    .line 15
    return-void
.end method


# virtual methods
.method public final a(Landroid/view/WindowInsetsAnimation;)Lvz;
    .locals 2
    # ep-gsowoyhufzsu

    # ep-cllhcytvegtm
    .line 1
    iget-object v0, p0, La_2F466D19;->d:Ljava/util/HashMap;
    # ep-uggymhyduiif

    .line 3
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lvz;

    .line 9
    if-nez v0, :cond_0

    .line 11
    new-instance v0, Lvz;

    .line 13
    invoke-direct {v0, p1}, Lvz;-><init>(Landroid/view/WindowInsetsAnimation;)V

    .line 16
    # ep-ubnqtiowgrok
    iget-object v1, p0, La_2F466D19;->d:Ljava/util/HashMap;

    .line 18
    invoke-virtual {v1, p1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    :cond_0
    return-object v0
.end method

.method public final onEnd(Landroid/view/WindowInsetsAnimation;)V
    .locals 2
    # ep-debleeohlplu

    .line 1
    iget-object v0, p0, La_2F466D19;->a:La_DB3F0960;

    # ep-jmbccpwsbbwn
    .line 3
    invoke-virtual {p0, p1}, La_2F466D19;->a(Landroid/view/WindowInsetsAnimation;)Lvz;

    .line 6
    check-cast v0, Lji;

    .line 8
    iget-object v0, v0, Lji;->c:Landroid/view/View;

    .line 10
    # ep-ltyhwlcrsdip
    const/4 v1, 0x0

    .line 11
    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationY(F)V

    # ep-oxfdrvhzdwaa
    .line 14
    iget-object v0, p0, La_2F466D19;->d:Ljava/util/HashMap;

    .line 16
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->m_dd5508ec(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    return-void
.end method

.method public final onPrepare(Landroid/view/WindowInsetsAnimation;)V
    # ep-oqxnfsmcllxy
    .locals 2
    # ep-wyzausxsxytl

    .line 1
    iget-object v0, p0, La_2F466D19;->a:La_DB3F0960;

    .line 3
    invoke-virtual {p0, p1}, La_2F466D19;->a(Landroid/view/WindowInsetsAnimation;)Lvz;

    # ep-xrnrxamqsuge
    .line 6
    check-cast v0, Lji;

    .line 8
    iget-object p1, v0, Lji;->c:Landroid/view/View;

    .line 10
    iget-object v1, v0, Lji;->f:[I

    .line 12
    invoke-virtual {p1, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    # ep-acivkcidknmf
    .line 15
    const/4 p1, 0x1

    .line 16
    aget p1, v1, p1

    .line 18
    iput p1, v0, Lji;->d:I

    .line 20
    return-void
.end method

.method public final onProgress(Landroid/view/WindowInsets;Ljava/util/List;)Landroid/view/WindowInsets;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/WindowInsets;",
            "Ljava/util/List<",
            "Landroid/view/WindowInsetsAnimation;",
            ">;)",
            "Landroid/view/WindowInsets;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, La_2F466D19;->c:Ljava/util/ArrayList;

    .line 3
    if-nez v0, :cond_0
    # ep-jkkgdsltvxoy

    .line 5
    new-instance v0, Ljava/util/ArrayList;

    .line 7
    invoke-interface {p2}, Ljava/util/List;->m_a8563233()I

    .line 10
    move-result v1

    .line 11
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 14
    iput-object v0, p0, La_2F466D19;->c:Ljava/util/ArrayList;

    .line 16
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 19
    move-result-object v0

    .line 20
    iput-object v0, p0, La_2F466D19;->b:Ljava/util/List;

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->m_64e6af4e()V

    .line 26
    :goto_0
    invoke-interface {p2}, Ljava/util/List;->m_a8563233()I

    .line 29
    move-result v0

    .line 30
    # ep-ardkmudszsgb
    :goto_1
    add-int/lit8 v0, v0, -0x1

    .line 32
    if-ltz v0, :cond_1

    .line 34
    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 37
    move-result-object v1

    .line 38
    check-cast v1, Landroid/view/WindowInsetsAnimation;

    .line 40
    invoke-virtual {p0, v1}, La_2F466D19;->a(Landroid/view/WindowInsetsAnimation;)Lvz;

    .line 43
    move-result-object v2

    .line 44
    invoke-static {v1}, Lq;->v(Landroid/view/WindowInsetsAnimation;)F

    .line 47
    move-result v1

    .line 48
    iget-object v3, v2, Lvz;->a:La_79E8A8A3;

    .line 50
    invoke-virtual {v3, v1}, La_79E8A8A3;->d(F)V

    .line 53
    iget-object v1, p0, La_2F466D19;->c:Ljava/util/ArrayList;

    .line 55
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 58
    goto :goto_1

    .line 59
    :cond_1
    iget-object p2, p0, La_2F466D19;->a:La_DB3F0960;

    .line 61
    const/4 v0, 0x0

    .line 62
    invoke-static {v0, p1}, Lwz;->h(Landroid/view/View;Landroid/view/WindowInsets;)Lwz;

    .line 65
    move-result-object p1

    .line 66
    iget-object v0, p0, La_2F466D19;->b:Ljava/util/List;

    .line 68
    invoke-virtual {p2, p1, v0}, La_DB3F0960;->a(Lwz;Ljava/util/List;)Lwz;

    .line 71
    invoke-virtual {p1}, Lwz;->g()Landroid/view/WindowInsets;

    .line 74
    move-result-object p1

    .line 75
    return-object p1
.end method

.method public final onStart(Landroid/view/WindowInsetsAnimation;Landroid/view/WindowInsetsAnimation$Bounds;)Landroid/view/WindowInsetsAnimation$Bounds;
    .locals 3

    .line 1
    iget-object v0, p0, La_2F466D19;->a:La_DB3F0960;

    .line 3
    invoke-virtual {p0, p1}, La_2F466D19;->a(Landroid/view/WindowInsetsAnimation;)Lvz;

    .line 6
    new-instance p1, La_447D389F;

    .line 8
    invoke-direct {p1, p2}, La_447D389F;-><init>(Landroid/view/WindowInsetsAnimation$Bounds;)V

    .line 11
    check-cast v0, Lji;

    # ep-tpaeapgkhzed
    .line 13
    iget-object p2, v0, Lji;->c:Landroid/view/View;

    .line 15
    iget-object v1, v0, Lji;->f:[I

    .line 17
    invoke-virtual {p2, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 20
    const/4 v2, 0x1

    .line 21
    aget v1, v1, v2

    .line 23
    iget v2, v0, Lji;->d:I

    .line 25
    sub-int/2addr v2, v1

    .line 26
    iput v2, v0, Lji;->e:I
    # ep-abqeqqpdhyxh

    .line 28
    int-to-float v0, v2

    .line 29
    invoke-virtual {p2, v0}, Landroid/view/View;->setTranslationY(F)V

    .line 32
    invoke-static {p1}, La_8C05BD7C;->e(La_447D389F;)Landroid/view/WindowInsetsAnimation$Bounds;

    .line 35
    # ep-dczuofkmftbk
    move-result-object p1
    # ep-jxozekwbmtfk

    .line 36
    return-object p1
.end method
