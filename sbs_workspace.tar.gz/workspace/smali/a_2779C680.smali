.class public final La_2779C680;
# ep-eiflggpswnhl
.super Ljava/lang/Object;
# validated-92483
# validated-20133
.source "bgswvuvm.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Log;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Ljava/util/ArrayList;

.field public final b:Lcp;

.field public final c:I

.field public d:I

.field public e:[Lgg;

.field public f:I

.field public g:I

.field public h:I


# direct methods
.method public constructor <init>(La_782D8D19;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/ArrayList;

    .line 6
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 9
    iput-object v0, p0, La_2779C680;->a:Ljava/util/ArrayList;

    .line 11
    const/16 v0, 0x8

    .line 13
    new-array v0, v0, [Lgg;

    .line 15
    iput-object v0, p0, La_2779C680;->e:[Lgg;

    .line 17
    const/4 v0, 0x7

    .line 18
    iput v0, p0, La_2779C680;->f:I

    .line 20
    const/4 v0, 0x0

    .line 21
    iput v0, p0, La_2779C680;->g:I

    .line 23
    iput v0, p0, La_2779C680;->h:I

    .line 25
    const/16 v0, 0x1000

    .line 27
    iput v0, p0, La_2779C680;->c:I

    .line 29
    iput v0, p0, La_2779C680;->d:I

    .line 31
    sget-object v0, Len;->a:Ljava/util/logging/Logger;

    .line 33
    new-instance v0, Lcp;

    .line 35
    invoke-direct {v0, p1}, Lcp;-><init>(Lrs;)V

    .line 38
    iput-object v0, p0, La_2779C680;->b:Lcp;

    .line 40
    return-void
.end method


# virtual methods
.method public final a(I)I
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    if-lez p1, :cond_1

    .line 4
    iget-object v1, p0, La_2779C680;->e:[Lgg;

    .line 6
    array-length v1, v1

    .line 7
    add-int/lit8 v1, v1, -0x1

    .line 9
    :goto_0
    iget v2, p0, La_2779C680;->f:I

    .line 11
    if-lt v1, v2, :cond_0

    .line 13
    if-lez p1, :cond_0

    .line 15
    iget-object v2, p0, La_2779C680;->e:[Lgg;

    .line 17
    aget-object v2, v2, v1

    .line 19
    iget v2, v2, Lgg;->c:I

    .line 21
    sub-int/2addr p1, v2

    .line 22
    iget v3, p0, La_2779C680;->h:I

    .line 24
    sub-int/2addr v3, v2

    .line 25
    iput v3, p0, La_2779C680;->h:I

    .line 27
    iget v2, p0, La_2779C680;->g:I

    .line 29
    add-int/lit8 v2, v2, -0x1

    .line 31
    iput v2, p0, La_2779C680;->g:I

    .line 33
    add-int/lit8 v0, v0, 0x1

    .line 35
    add-int/lit8 v1, v1, -0x1

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    iget-object p1, p0, La_2779C680;->e:[Lgg;

    .line 40
    add-int/lit8 v1, v2, 0x1

    .line 42
    add-int/lit8 v2, v2, 0x1

    .line 44
    add-int/2addr v2, v0

    .line 45
    iget v3, p0, La_2779C680;->g:I

    .line 47
    invoke-static {p1, v1, p1, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 50
    iget p1, p0, La_2779C680;->f:I

    .line 52
    add-int/2addr p1, v0

    .line 53
    iput p1, p0, La_2779C680;->f:I

    .line 55
    :cond_1
    return v0
.end method

.method public final b(I)La_889D3FD0;
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ltz p1, :cond_0

    .line 4
    sget-object v1, Log;->a:[Lgg;

    .line 6
    array-length v1, v1

    .line 7
    sub-int/2addr v1, v0

    .line 8
    if-gt p1, v1, :cond_0

    .line 10
    const/4 v1, 0x1

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/4 v1, 0x0

    .line 13
    :goto_0
    if-eqz v1, :cond_1

    .line 15
    sget-object v0, Log;->a:[Lgg;

    .line 17
    aget-object p1, v0, p1

    .line 19
    iget-object p1, p1, Lgg;->a:La_889D3FD0;

    .line 21
    return-object p1

    .line 22
    :cond_1
    iget-object v1, p0, La_2779C680;->e:[Lgg;

    .line 24
    sget-object v2, Log;->a:[Lgg;

    .line 26
    array-length v2, v2

    .line 27
    sub-int/2addr p1, v2

    .line 28
    iget v2, p0, La_2779C680;->f:I

    .line 30
    add-int/2addr v2, v0

    .line 31
    add-int/2addr v2, p1

    .line 32
    aget-object p1, v1, v2

    .line 34
    iget-object p1, p1, Lgg;->a:La_889D3FD0;

    .line 36
    return-object p1
.end method

.method public final c(Lgg;)V
    .locals 6

    .line 1
    iget-object v0, p0, La_2779C680;->a:Ljava/util/ArrayList;

    .line 3
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 6
    iget v0, p0, La_2779C680;->d:I

    .line 8
    const/4 v1, 0x0

    .line 9
    iget v2, p1, Lgg;->c:I

    .line 11
    if-le v2, v0, :cond_0

    .line 13
    iget-object p1, p0, La_2779C680;->e:[Lgg;

    .line 15
    const/4 v0, 0x0

    .line 16
    invoke-static {p1, v0}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    .line 19
    iget-object p1, p0, La_2779C680;->e:[Lgg;

    .line 21
    array-length p1, p1

    .line 22
    add-int/lit8 p1, p1, -0x1

    .line 24
    iput p1, p0, La_2779C680;->f:I

    .line 26
    iput v1, p0, La_2779C680;->g:I

    .line 28
    iput v1, p0, La_2779C680;->h:I

    .line 30
    return-void

    .line 31
    :cond_0
    iget v3, p0, La_2779C680;->h:I

    .line 33
    add-int/2addr v3, v2

    .line 34
    sub-int/2addr v3, v0

    .line 35
    invoke-virtual {p0, v3}, La_2779C680;->a(I)I

    .line 38
    iget v0, p0, La_2779C680;->g:I

    .line 40
    add-int/lit8 v0, v0, 0x1

    .line 42
    iget-object v3, p0, La_2779C680;->e:[Lgg;

    .line 44
    array-length v4, v3

    .line 45
    if-le v0, v4, :cond_1

    .line 47
    array-length v0, v3

    .line 48
    mul-int/lit8 v0, v0, 0x2

    .line 50
    new-array v0, v0, [Lgg;

    .line 52
    array-length v4, v3

    .line 53
    array-length v5, v3

    .line 54
    invoke-static {v3, v1, v0, v4, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 57
    iget-object v1, p0, La_2779C680;->e:[Lgg;

    .line 59
    array-length v1, v1

    .line 60
    add-int/lit8 v1, v1, -0x1

    .line 62
    iput v1, p0, La_2779C680;->f:I

    .line 64
    iput-object v0, p0, La_2779C680;->e:[Lgg;

    .line 66
    :cond_1
    iget v0, p0, La_2779C680;->f:I

    .line 68
    add-int/lit8 v1, v0, -0x1

    .line 70
    iput v1, p0, La_2779C680;->f:I

    .line 72
    iget-object v1, p0, La_2779C680;->e:[Lgg;

    .line 74
    aput-object p1, v1, v0

    .line 76
    iget p1, p0, La_2779C680;->g:I

    .line 78
    add-int/lit8 p1, p1, 0x1

    .line 80
    iput p1, p0, La_2779C680;->g:I

    .line 82
    iget p1, p0, La_2779C680;->h:I

    .line 84
    add-int/2addr p1, v2

    .line 85
    iput p1, p0, La_2779C680;->h:I

    .line 87
    return-void
.end method

.method public final d()La_889D3FD0;
    .locals 9

    .line 1
    iget-object v0, p0, La_2779C680;->b:Lcp;

    .line 3
    invoke-virtual {v0}, Lcp;->m_c2b234ca()B

    .line 6
    move-result v1

    .line 7
    and-int/lit16 v1, v1, 0xff

    .line 9
    and-int/lit16 v2, v1, 0x80

    .line 11
    const/16 v3, 0x80

    .line 13
    const/4 v4, 0x0

    .line 14
    if-ne v2, v3, :cond_0

    .line 16
    const/4 v2, 0x1

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const/4 v2, 0x0

    .line 19
    :goto_0
    const/16 v3, 0x7f

    .line 21
    invoke-virtual {p0, v1, v3}, La_2779C680;->e(II)I

    .line 24
    move-result v1

    .line 25
    if-eqz v2, :cond_6

    .line 27
    sget-object v2, Ljh;->d:Ljh;

    .line 29
    int-to-long v5, v1

    .line 30
    invoke-virtual {v0, v5, v6}, Lcp;->l(J)V

    .line 33
    iget-object v0, v0, Lcp;->c:La_A2F8F8F5;

    .line 35
    invoke-virtual {v0, v5, v6}, La_A2F8F8F5;->t(J)[B

    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    new-instance v1, Ljava/io/ByteArrayOutputStream;

    .line 44
    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 47
    iget-object v2, v2, Ljh;->a:La_83689796;

    .line 49
    move-object v6, v2

    .line 50
    const/4 v3, 0x0

    .line 51
    const/4 v5, 0x0

    .line 52
    :goto_1
    array-length v7, v0

    .line 53
    if-ge v4, v7, :cond_3

    .line 55
    aget-byte v7, v0, v4

    .line 57
    and-int/lit16 v7, v7, 0xff

    .line 59
    shl-int/lit8 v3, v3, 0x8

    .line 61
    or-int/2addr v3, v7

    .line 62
    add-int/lit8 v5, v5, 0x8

    .line 64
    :goto_2
    const/16 v7, 0x8

    .line 66
    if-lt v5, v7, :cond_2

    .line 68
    add-int/lit8 v7, v5, -0x8

    .line 70
    ushr-int v8, v3, v7

    .line 72
    and-int/lit16 v8, v8, 0xff

    .line 74
    iget-object v6, v6, La_83689796;->a:[La_83689796;

    .line 76
    aget-object v6, v6, v8

    .line 78
    iget-object v8, v6, La_83689796;->a:[La_83689796;

    .line 80
    if-nez v8, :cond_1

    .line 82
    iget v7, v6, La_83689796;->b:I

    .line 84
    invoke-virtual {v1, v7}, Ljava/io/ByteArrayOutputStream;->m_7cd2a61e(I)V

    .line 87
    iget v6, v6, La_83689796;->c:I

    .line 89
    sub-int/2addr v5, v6

    .line 90
    move-object v6, v2

    .line 91
    goto :goto_2

    .line 92
    :cond_1
    move v5, v7

    .line 93
    goto :goto_2

    .line 94
    :cond_2
    add-int/lit8 v4, v4, 0x1

    .line 96
    goto :goto_1

    .line 97
    :cond_3
    :goto_3
    if-lez v5, :cond_5

    .line 99
    rsub-int/lit8 v0, v5, 0x8

    .line 101
    shl-int v0, v3, v0

    .line 103
    and-int/lit16 v0, v0, 0xff

    .line 105
    iget-object v4, v6, La_83689796;->a:[La_83689796;

    .line 107
    aget-object v0, v4, v0

    .line 109
    iget-object v4, v0, La_83689796;->a:[La_83689796;

    .line 111
    if-nez v4, :cond_5

    .line 113
    iget v4, v0, La_83689796;->c:I

    .line 115
    if-le v4, v5, :cond_4

    .line 117
    goto :goto_4

    .line 118
    :cond_4
    iget v0, v0, La_83689796;->b:I

    .line 120
    invoke-virtual {v1, v0}, Ljava/io/ByteArrayOutputStream;->m_7cd2a61e(I)V

    .line 123
    sub-int/2addr v5, v4

    .line 124
    move-object v6, v2

    .line 125
    goto :goto_3

    .line 126
    :cond_5
    :goto_4
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 129
    move-result-object v0

    .line 130
    invoke-static {v0}, La_889D3FD0;->g([B)La_889D3FD0;

    .line 133
    move-result-object v0

    .line 134
    return-object v0

    .line 135
    :cond_6
    int-to-long v1, v1

    .line 136
    invoke-virtual {v0, v1, v2}, Lcp;->e(J)La_889D3FD0;

    .line 139
    move-result-object v0

    .line 140
    return-object v0
.end method

.method public final e(II)I
    .locals 2

    and-int/2addr p1, p2

    if-ge p1, p2, :cond_0

    return p1

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iget-object v0, p0, La_2779C680;->b:Lcp;

    invoke-virtual {v0}, Lcp;->m_c2b234ca()B

    move-result v0

    and-int/lit16 v0, v0, 0xff

    and-int/lit16 v1, v0, 0x80

    if-eqz v1, :cond_1

    and-int/lit8 v0, v0, 0x7f

    shl-int/2addr v0, p1

    add-int/2addr p2, v0

    add-int/lit8 p1, p1, 0x7

    goto :goto_0

    :cond_1
    shl-int p1, v0, p1

    add-int/2addr p2, p1

    return p2
.end method
