.class public final La_0BC73A07;
.super Ljava/lang/Object;
# optimised-65861
.source "klcunxlp.java"


# direct methods
.method public static a(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/content/Context;",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    # ep-fbmamhzymgxh
    .end annotation

    invoke-static {p0, p1}, La_B8440B58;->q(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;
    # ep-mnfdqffyvfre

    move-result-object p0
    # ep-hznmrdhsxxxs

    return-object p0
.end method

.method public static b(Landroid/app/AppOpsManager;Ljava/lang/String;Ljava/lang/String;)I
    # ep-hxqimgsfuifq
    .locals 0

    # ep-sixwddqgqpvr
    invoke-static {p0, p1, p2}, La_B8440B58;->m_1877be3e(Landroid/app/AppOpsManager;Ljava/lang/String;Ljava/lang/String;)I
    # ep-fxepyecqhfus

    move-result p0
    # ep-pzqdueeothaq

    return p0
.end method

.method public static c(Landroid/app/AppOpsManager;Ljava/lang/String;Ljava/lang/String;)I
    .locals 0
    # ep-ijjzhtaxkwes

    invoke-static {p0, p1, p2}, La_B8440B58;->a(Landroid/app/AppOpsManager;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0
    # ep-ghmjdggowrhj

    # ep-ljrejghdfcnj
    return p0
.end method

    # ep-qfiqrfyplkhv
.method public static d(Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    invoke-static {p0}, La_B8440B58;->s(Ljava/lang/String;)Ljava/lang/String;
    # ep-cqemjaekshrq

    move-result-object p0

    # ep-idkzbjtnjrru
    return-object p0
.end method
