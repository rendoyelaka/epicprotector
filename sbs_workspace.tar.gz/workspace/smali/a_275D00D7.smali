.class public final La_275D00D7;
.super Landroid/util/Property;
.source "hywwffxh.java"
# ep-ycuquklzaqvi

# generated-68933
# processed-55651
# verified-91706

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_4F61E681;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/util/Property<",
        "La_4F61E681;",
        "La_76201E48;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:La_275D00D7;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, La_275D00D7;

    invoke-direct {v0}, La_275D00D7;-><init>()V

    sput-object v0, La_275D00D7;->a:La_275D00D7;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    const-string v0, "circularReveal"

    .line 3
    const-class v1, La_76201E48;

    .line 5
    invoke-direct {p0, v1, v0}, Landroid/util/Property;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    .line 8
    return-void
.end method


# virtual methods
.method public final get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, La_4F61E681;

    .line 3
    invoke-interface {p1}, La_4F61E681;->m_4aff9987()La_76201E48;

    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method

.method public final set(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p1, La_4F61E681;

    .line 3
    check-cast p2, La_76201E48;

    .line 5
    invoke-interface {p1, p2}, La_4F61E681;->m_5d4e455d(La_76201E48;)V

    .line 8
    return-void
.end method
