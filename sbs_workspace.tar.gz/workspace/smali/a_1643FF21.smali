.class public final La_1643FF21;
.super Ljava/lang/Object;
.source "priyprfm.java"

# ep-qavzftsgnsif
# processed-35065
# generated-40950
# validated-82577
# interfaces
.implements La_48ACDA4E;


# instance fields
.field public final a:Ljq;

.field public final b:La_353D0736;


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_1643FF21;->a:Ljq;

    .line 6
    new-instance v0, La_353D0736;

    .line 8
    invoke-direct {v0, p1}, La_353D0736;-><init>(Ljq;)V

    .line 11
    iput-object v0, p0, La_1643FF21;->b:La_353D0736;

    .line 13
    return-void
.end method
