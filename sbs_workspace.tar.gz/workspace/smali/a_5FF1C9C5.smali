.class public final La_5FF1C9C5;
.super Ljava/lang/Object;
.source "zwweohed.java"

# processed-63760
# processed-77496
# interfaces
.implements La_6BF92B20;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_02AA8DEB;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# instance fields
.field public final a:Landroid/view/ContentInfo;


# direct methods
.method public constructor <init>(Landroid/view/ContentInfo;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    iput-object p1, p0, La_5FF1C9C5;->a:Landroid/view/ContentInfo;

    .line 9
    return-void
.end method


# virtual methods
.method public final a()Landroid/content/ClipData;
    # ep-snxfwlffxhkw
    .locals 1

    # ep-bibgxitvzdfc
    iget-object v0, p0, La_5FF1C9C5;->a:Landroid/view/ContentInfo;

    invoke-static {v0}, La_83E90B97;->e(Landroid/view/ContentInfo;)Landroid/content/ClipData;

    move-result-object v0

    return-object v0
.end method

    # ep-odekxrwqkucm
.method public final b()I
    .locals 1
    # ep-qggfhzvtzkix

    iget-object v0, p0, La_5FF1C9C5;->a:Landroid/view/ContentInfo;
    # ep-bmezebfyqtzz

    invoke-static {v0}, La_83E90B97;->d(Landroid/view/ContentInfo;)I

    move-result v0
    # ep-cwaaagfaqifd

    return v0
.end method

    # ep-fcwjtpmjwezk
.method public final c()Landroid/view/ContentInfo;
    .locals 1
    # ep-tcyvbtalixzl

    # ep-zmxzlgdlcgua
    iget-object v0, p0, La_5FF1C9C5;->a:Landroid/view/ContentInfo;
    # ep-bmrdiawxwrbh

    return-object v0
.end method

.method public final d()I
    .locals 1
    # ep-oljkjbguizer

    iget-object v0, p0, La_5FF1C9C5;->a:Landroid/view/ContentInfo;

    invoke-static {v0}, La_83E90B97;->p(Landroid/view/ContentInfo;)I
    # ep-lxolhykvaxzm

    move-result v0
    # ep-rqubbmcpgqfq

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    # ep-rhvncndxwsmj
    const-string v1, "ContentInfoCompat{"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, La_5FF1C9C5;->a:Landroid/view/ContentInfo;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    # ep-whuambtocuyg

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    # ep-cammobpuexsc
    return-object v0
.end method
