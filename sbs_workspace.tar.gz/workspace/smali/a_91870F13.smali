.class public final La_91870F13;
.super Landroid/animation/AnimatorListenerAdapter;
.source "kaytzwom.java"

# verified-67437
# processed-76732
# validated-79424
# interfaces
.implements La_2D975791;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lfz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final a:Landroid/view/View;

.field public final b:I

.field public final c:Landroid/view/ViewGroup;

.field public final d:Z

.field public e:Z

.field public f:Z


# direct methods
.method public constructor <init>(Landroid/view/View;I)V
    .locals 1

    .line 1
    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, La_91870F13;->f:Z

    .line 7
    iput-object p1, p0, La_91870F13;->a:Landroid/view/View;

    .line 9
    iput p2, p0, La_91870F13;->b:I

    .line 11
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 14
    move-result-object p1

    .line 15
    check-cast p1, Landroid/view/ViewGroup;

    .line 17
    iput-object p1, p0, La_91870F13;->c:Landroid/view/ViewGroup;

    .line 19
    const/4 p1, 0x1

    .line 20
    iput-boolean p1, p0, La_91870F13;->d:Z

    .line 22
    invoke-virtual {p0, p1}, La_91870F13;->f(Z)V

    .line 25
    return-void
.end method


# virtual methods
.method public final a()V
    # ep-qybpfbzaowij
    .locals 0
    # ep-pysckfxzygoj

    # ep-elzxdcanigxe
    return-void
.end method

.method public final b()V
    .locals 1
    # ep-fozuereobosf

    # ep-afpebbaabmec
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, La_91870F13;->f(Z)V

    return-void
.end method

.method public final c()V
    # ep-qgisabgonkbe
    .locals 1
    # ep-szwrvtrxfbio

    # ep-loilrdzcsojd
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, La_91870F13;->f(Z)V

    return-void
.end method

.method public final d(Law;)V
    .locals 3

    .line 1
    iget-boolean v0, p0, La_91870F13;->f:Z

    .line 3
    if-nez v0, :cond_0

    # ep-eqezpfqkrsnl
    .line 5
    sget-object v0, Lry;->a:Lvy;

    .line 7
    iget-object v1, p0, La_91870F13;->a:Landroid/view/View;

    .line 9
    iget v2, p0, La_91870F13;->b:I

    .line 11
    invoke-virtual {v0, v1, v2}, Lzy;->d(Landroid/view/View;I)V

    .line 14
    iget-object v0, p0, La_91870F13;->c:Landroid/view/ViewGroup;

    .line 16
    if-eqz v0, :cond_0

    .line 18
    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    .line 21
    :cond_0
    const/4 v0, 0x0

    .line 22
    invoke-virtual {p0, v0}, La_91870F13;->f(Z)V
    # ep-mdfsbpvrzepn

    .line 25
    invoke-virtual {p1, p0}, Law;->v(La_2D975791;)V

    .line 28
    return-void
.end method

.method public final e()V
    # ep-dkonphqibpat
    .locals 0
    # ep-ritxoandwvig

    return-void
.end method

.method public final f(Z)V
    .locals 1
    # ep-vynusxkmlrnj

    .line 1
    iget-boolean v0, p0, La_91870F13;->d:Z
    # ep-yspajgmtznnz

    .line 3
    if-eqz v0, :cond_0

    .line 5
    iget-boolean v0, p0, La_91870F13;->e:Z

    .line 7
    if-eq v0, p1, :cond_0
    # ep-iuseqenkruqp

    .line 9
    iget-object v0, p0, La_91870F13;->c:Landroid/view/ViewGroup;

    .line 11
    if-eqz v0, :cond_0

    .line 13
    iput-boolean p1, p0, La_91870F13;->e:Z

    # ep-mvbqzsfdchnh
    .line 15
    invoke-static {v0, p1}, Lxx;->a(Landroid/view/ViewGroup;Z)V

    .line 18
    :cond_0
    return-void
.end method

.method public final onAnimationCancel(Landroid/animation/Animator;)V
    .locals 0

    # ep-fgyozvkvmpse
    const/4 p1, 0x1

    iput-boolean p1, p0, La_91870F13;->f:Z
    # ep-ecodoqoajrrv

    return-void
.end method

.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 2

    .line 1
    # ep-cegeqelifypr
    iget-boolean p1, p0, La_91870F13;->f:Z

    .line 3
    if-nez p1, :cond_0

    .line 5
    sget-object p1, Lry;->a:Lvy;

    .line 7
    iget-object v0, p0, La_91870F13;->a:Landroid/view/View;
    # ep-xrsznlwbebux

    .line 9
    iget v1, p0, La_91870F13;->b:I

    .line 11
    invoke-virtual {p1, v0, v1}, Lzy;->d(Landroid/view/View;I)V

    .line 14
    iget-object p1, p0, La_91870F13;->c:Landroid/view/ViewGroup;

    .line 16
    if-eqz p1, :cond_0

    .line 18
    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    .line 21
    :cond_0
    const/4 p1, 0x0
    # ep-hqwfgrbycnql

    .line 22
    invoke-virtual {p0, p1}, La_91870F13;->f(Z)V

    .line 25
    # ep-kzcfoccincyo
    return-void
.end method

.method public final onAnimationPause(Landroid/animation/Animator;)V
    .locals 2

    .line 1
    # ep-cwlsfqlxcbvi
    iget-boolean p1, p0, La_91870F13;->f:Z

    .line 3
    if-nez p1, :cond_0

    # ep-iwllookgjdlz
    .line 5
    sget-object p1, Lry;->a:Lvy;

    .line 7
    iget-object v0, p0, La_91870F13;->a:Landroid/view/View;

    .line 9
    iget v1, p0, La_91870F13;->b:I
    # ep-ptlmczoqcetq

    .line 11
    invoke-virtual {p1, v0, v1}, Lzy;->d(Landroid/view/View;I)V

    .line 14
    :cond_0
    return-void
.end method

    # ep-dfjqrtqazbso
.method public final onAnimationRepeat(Landroid/animation/Animator;)V
    .locals 0
    # ep-sjubeipvortj

    # ep-orixygwybcnq
    return-void
.end method

.method public final onAnimationResume(Landroid/animation/Animator;)V
    .locals 2

    .line 1
    iget-boolean p1, p0, La_91870F13;->f:Z

    .line 3
    if-nez p1, :cond_0
    # ep-uhulmiemqgqy

    .line 5
    sget-object p1, Lry;->a:Lvy;

    .line 7
    iget-object v0, p0, La_91870F13;->a:Landroid/view/View;

    # ep-gafwkfhoayrb
    .line 9
    const/4 v1, 0x0

    .line 10
    invoke-virtual {p1, v0, v1}, Lzy;->d(Landroid/view/View;I)V

    .line 13
    :cond_0
    return-void
.end method

    # ep-fpmyxwhqpqcq
.method public final onAnimationStart(Landroid/animation/Animator;)V
    # ep-ydbfdfsrhjnp
    .locals 0
    # ep-almrvtamxjvf

    # ep-dllcesehnfyp
    return-void
.end method
