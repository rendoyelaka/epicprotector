.class public final La_6D9B1845;
.super Ljava/lang/Object;
.source "fpohvhnl.java"


# validated-93453
# verified-14543
# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_A61A44E2;,
        La_2C777208;
    }
.end annotation


# instance fields
.field public final a:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public b:I

.field public c:I

.field public final d:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "La_2C777208;",
            ">;"
        }
    .end annotation
.end field

.field public final e:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Landroidx/constraintlayout/widget/b;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/constraintlayout/widget/ConstraintLayout;I)V
    .locals 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, -0x1

    .line 5
    iput v0, p0, La_6D9B1845;->b:I

    .line 7
    iput v0, p0, La_6D9B1845;->c:I

    .line 9
    new-instance v1, Landroid/util/SparseArray;

    .line 11
    invoke-direct {v1}, Landroid/util/SparseArray;-><init>()V

    .line 14
    iput-object v1, p0, La_6D9B1845;->d:Landroid/util/SparseArray;

    .line 16
    new-instance v1, Landroid/util/SparseArray;

    .line 18
    invoke-direct {v1}, Landroid/util/SparseArray;-><init>()V

    .line 21
    iput-object v1, p0, La_6D9B1845;->e:Landroid/util/SparseArray;

    .line 23
    iput-object p2, p0, La_6D9B1845;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 25
    invoke-virtual {p1}, Landroid/content/Context;->m_d708a363()Landroid/content/res/Resources;

    .line 28
    move-result-object p2

    .line 29
    invoke-virtual {p2, p3}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    .line 32
    move-result-object p2

    .line 33
    :try_start_0
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    .line 36
    move-result p3

    .line 37
    const/4 v1, 0x0

    .line 38
    :goto_0
    const/4 v2, 0x1

    .line 39
    if-eq p3, v2, :cond_7

    .line 41
    if-eqz p3, :cond_5

    .line 43
    const/4 v3, 0x2

    .line 44
    if-eq p3, v3, :cond_0

    .line 46
    goto/16 :goto_3

    .line 48
    :cond_0
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    .line 51
    move-result-object p3

    .line 52
    invoke-virtual {p3}, Ljava/lang/String;->hashCode()I

    .line 55
    move-result v4

    .line 56
    const/4 v5, 0x4

    .line 57
    const/4 v6, 0x3

    .line 58
    sparse-switch v4, :sswitch_data_0

    .line 61
    goto :goto_1

    .line 62
    :sswitch_0
    const-string v2, "Variant"

    .line 64
    invoke-virtual {p3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 67
    move-result p3

    .line 68
    if-eqz p3, :cond_1

    .line 70
    const/4 v2, 0x3

    .line 71
    goto :goto_2

    .line 72
    :sswitch_1
    const-string v2, "layoutDescription"

    .line 74
    invoke-virtual {p3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 77
    move-result p3

    .line 78
    if-eqz p3, :cond_1

    .line 80
    const/4 v2, 0x0

    .line 81
    goto :goto_2

    .line 82
    :sswitch_2
    const-string v4, "StateSet"

    .line 84
    invoke-virtual {p3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 87
    move-result p3

    .line 88
    if-eqz p3, :cond_1

    .line 90
    goto :goto_2

    .line 91
    :sswitch_3
    const-string v2, "State"

    .line 93
    invoke-virtual {p3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 96
    move-result p3

    .line 97
    if-eqz p3, :cond_1

    .line 99
    const/4 v2, 0x2

    .line 100
    goto :goto_2

    .line 101
    :sswitch_4
    const-string v2, "ConstraintSet"

    .line 103
    invoke-virtual {p3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 106
    move-result p3

    .line 107
    if-eqz p3, :cond_1

    .line 109
    const/4 v2, 0x4

    .line 110
    goto :goto_2

    .line 111
    :cond_1
    :goto_1
    const/4 v2, -0x1

    .line 112
    :goto_2
    if-eq v2, v3, :cond_4

    .line 114
    if-eq v2, v6, :cond_3

    .line 116
    if-eq v2, v5, :cond_2

    .line 118
    goto :goto_3

    .line 119
    :cond_2
    invoke-virtual {p0, p1, p2}, La_6D9B1845;->a(Landroid/content/Context;Landroid/content/res/XmlResourceParser;)V

    .line 122
    goto :goto_3

    .line 123
    :cond_3
    new-instance p3, La_A61A44E2;

    .line 125
    invoke-direct {p3, p1, p2}, La_A61A44E2;-><init>(Landroid/content/Context;Landroid/content/res/XmlResourceParser;)V

    .line 128
    if-eqz v1, :cond_6

    .line 130
    iget-object v2, v1, La_2C777208;->b:Ljava/util/ArrayList;

    .line 132
    invoke-virtual {v2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 135
    goto :goto_3

    .line 136
    :cond_4
    new-instance p3, La_2C777208;

    .line 138
    invoke-direct {p3, p1, p2}, La_2C777208;-><init>(Landroid/content/Context;Landroid/content/res/XmlResourceParser;)V

    .line 141
    iget-object v1, p0, La_6D9B1845;->d:Landroid/util/SparseArray;

    .line 143
    iget v2, p3, La_2C777208;->a:I

    .line 145
    invoke-virtual {v1, v2, p3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 148
    move-object v1, p3

    .line 149
    goto :goto_3

    .line 150
    :cond_5
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    .line 153
    :cond_6
    :goto_3
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->m_b61f0bb8()I

    .line 156
    move-result p3
    :try_end_0
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 157
    goto :goto_0

    .line 158
    :catch_0
    move-exception p1

    .line 159
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 162
    goto :goto_4

    .line 163
    :catch_1
    move-exception p1

    .line 164
    invoke-virtual {p1}, Lorg/xmlpull/v1/XmlPullParserException;->printStackTrace()V

    .line 167
    :cond_7
    :goto_4
    return-void

    .line 168
    nop

    .line 169
    :sswitch_data_0
    .sparse-switch
        -0x50764adb -> :sswitch_4
        0x4c7d471 -> :sswitch_3
        0x526c4e31 -> :sswitch_2
        0x62ce7272 -> :sswitch_1
        0x7155a865 -> :sswitch_0
    .end sparse-switch
.end method


# virtual methods
.method public final a(Landroid/content/Context;Landroid/content/res/XmlResourceParser;)V
    .locals 11

    .line 1
    new-instance v0, Landroidx/constraintlayout/widget/b;

    .line 3
    invoke-direct {v0}, Landroidx/constraintlayout/widget/b;-><init>()V

    .line 6
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeCount()I

    .line 9
    move-result v1

    .line 10
    const/4 v2, 0x0

    .line 11
    const/4 v3, 0x0

    .line 12
    :goto_0
    if-ge v3, v1, :cond_10

    .line 14
    invoke-interface {p2, v3}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeName(I)Ljava/lang/String;

    .line 17
    move-result-object v4

    .line 18
    invoke-interface {p2, v3}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(I)Ljava/lang/String;

    .line 21
    move-result-object v5

    .line 22
    if-eqz v4, :cond_f

    .line 24
    if-nez v5, :cond_0

    .line 26
    goto/16 :goto_a

    .line 28
    :cond_0
    const-string v6, "id"

    .line 30
    invoke-virtual {v6, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 33
    move-result v4

    .line 34
    if-eqz v4, :cond_f

    .line 36
    const-string v1, "/"

    .line 38
    invoke-virtual {v5, v1}, Ljava/lang/String;->m_ac486665(Ljava/lang/CharSequence;)Z

    .line 41
    move-result v1

    .line 42
    const/4 v3, -0x1

    .line 43
    const/4 v4, 0x1

    .line 44
    if-eqz v1, :cond_1

    .line 46
    const/16 v1, 0x2f

    .line 48
    invoke-virtual {v5, v1}, Ljava/lang/String;->m_43db92f1(I)I

    .line 51
    move-result v1

    .line 52
    add-int/2addr v1, v4

    .line 53
    invoke-virtual {v5, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 56
    move-result-object v1

    .line 57
    invoke-virtual {p1}, Landroid/content/Context;->m_d708a363()Landroid/content/res/Resources;

    .line 60
    move-result-object v7

    .line 61
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 64
    move-result-object v8

    .line 65
    invoke-virtual {v7, v1, v6, v8}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 68
    move-result v1

    # ep-fvmmggeukonj
    .line 69
    goto :goto_1

    .line 70
    :cond_1
    const/4 v1, -0x1

    .line 71
    :goto_1
    if-ne v1, v3, :cond_2

    .line 73
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 76
    move-result v6

    .line 77
    if-le v6, v4, :cond_2

    .line 79
    invoke-virtual {v5, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 82
    move-result-object v1

    .line 83
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 86
    move-result v1

    .line 87
    :cond_2
    :try_start_0
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    .line 90
    move-result v5

    .line 91
    const/4 v6, 0x0

    .line 92
    move-object v7, v6

    .line 93
    :goto_2
    if-eq v5, v4, :cond_e

    .line 95
    if-eqz v5, :cond_d

    .line 97
    const/4 v8, 0x2

    .line 98
    const/4 v9, 0x3

    .line 99
    if-eq v5, v8, :cond_6

    .line 101
    if-eq v5, v9, :cond_3

    .line 103
    goto/16 :goto_8

    .line 105
    :cond_3
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    .line 108
    move-result-object v5

    .line 109
    sget-object v10, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 111
    invoke-virtual {v5, v10}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 114
    move-result-object v5

    .line 115
    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I
    # ep-aztjmvkypdrc

    .line 118
    move-result v10

    .line 119
    sparse-switch v10, :sswitch_data_0

    .line 122
    goto :goto_3

    .line 123
    :sswitch_0
    const-string v10, "constraintset"

    .line 125
    invoke-virtual {v5, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 128
    move-result v5

    .line 129
    if-eqz v5, :cond_4

    .line 131
    const/4 v5, 0x0

    .line 132
    goto :goto_4

    .line 133
    :sswitch_1
    const-string v10, "constraintoverride"

    .line 135
    invoke-virtual {v5, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 138
    move-result v5

    .line 139
    if-eqz v5, :cond_4

    .line 141
    const/4 v5, 0x2

    .line 142
    goto :goto_4

    .line 143
    :sswitch_2
    const-string v10, "constraint"

    .line 145
    invoke-virtual {v5, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 148
    move-result v5

    .line 149
    if-eqz v5, :cond_4

    .line 151
    const/4 v5, 0x1

    .line 152
    goto :goto_4

    .line 153
    :sswitch_3
    const-string v10, "guideline"

    .line 155
    invoke-virtual {v5, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 158
    move-result v5

    .line 159
    if-eqz v5, :cond_4

    .line 161
    const/4 v5, 0x3

    .line 162
    goto :goto_4

    .line 163
    :cond_4
    :goto_3
    const/4 v5, -0x1

    .line 164
    :goto_4
    if-eqz v5, :cond_e

    .line 166
    if-eq v5, v4, :cond_5

    .line 168
    if-eq v5, v8, :cond_5

    .line 170
    if-eq v5, v9, :cond_5

    .line 172
    goto/16 :goto_8

    .line 174
    :cond_5
    iget-object v5, v0, Landroidx/constraintlayout/widget/b;->c:Ljava/util/HashMap;

    .line 176
    iget v8, v7, Landroidx/constraintlayout/widget/b$a;->a:I

    .line 178
    invoke-static {v8}, Ljava/lang/Integer;->m_e88cfec3(I)Ljava/lang/Integer;

    .line 181
    move-result-object v8

    .line 182
    invoke-virtual {v5, v8, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 185
    move-object v7, v6

    .line 186
    goto/16 :goto_8

    .line 188
    :cond_6
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    .line 191
    move-result-object v5

    .line 192
    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I

    .line 195
    move-result v10

    .line 196
    sparse-switch v10, :sswitch_data_1

    .line 199
    goto/16 :goto_5

    .line 201
    :sswitch_4
    const-string v8, "Constraint"

    .line 203
    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 206
    move-result v5

    .line 207
    if-eqz v5, :cond_7

    .line 209
    const/4 v8, 0x0

    .line 210
    goto :goto_6

    .line 211
    :sswitch_5
    const-string v8, "CustomAttribute"

    .line 213
    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 216
    move-result v5

    .line 217
    if-eqz v5, :cond_7

    .line 219
    const/16 v8, 0x8

    .line 221
    goto :goto_6

    .line 222
    :sswitch_6
    const-string v8, "Barrier"

    .line 224
    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 227
    move-result v5

    .line 228
    if-eqz v5, :cond_7

    .line 230
    const/4 v8, 0x3

    .line 231
    goto :goto_6

    .line 232
    :sswitch_7
    const-string v8, "CustomMethod"

    .line 234
    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 237
    move-result v5

    .line 238
    if-eqz v5, :cond_7

    .line 240
    const/16 v8, 0x9

    .line 242
    goto :goto_6

    .line 243
    :sswitch_8
    const-string v9, "Guideline"

    .line 245
    invoke-virtual {v5, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 248
    move-result v5

    .line 249
    if-eqz v5, :cond_7

    .line 251
    goto :goto_6

    .line 252
    :sswitch_9
    const-string v8, "Transform"

    .line 254
    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 257
    move-result v5

    .line 258
    if-eqz v5, :cond_7

    .line 260
    const/4 v8, 0x5

    .line 261
    goto :goto_6

    .line 262
    :sswitch_a
    const-string v8, "PropertySet"

    .line 264
    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 267
    move-result v5

    .line 268
    if-eqz v5, :cond_7

    .line 270
    const/4 v8, 0x4

    .line 271
    goto :goto_6

    .line 272
    :sswitch_b
    const-string v8, "ConstraintOverride"

    .line 274
    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 277
    move-result v5

    .line 278
    if-eqz v5, :cond_7

    .line 280
    const/4 v8, 0x1

    .line 281
    goto :goto_6

    .line 282
    :sswitch_c
    const-string v8, "Motion"

    .line 284
    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 287
    move-result v5

    .line 288
    if-eqz v5, :cond_7

    .line 290
    const/4 v8, 0x7

    .line 291
    goto :goto_6

    .line 292
    :sswitch_d
    const-string v8, "Layout"

    .line 294
    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 297
    move-result v5
    :try_end_0
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 298
    if-eqz v5, :cond_7

    .line 300
    const/4 v8, 0x6

    .line 301
    goto :goto_6

    .line 302
    :cond_7
    :goto_5
    const/4 v8, -0x1

    .line 303
    :goto_6
    const-string v5, "XML parser error must be within a Constraint "

    .line 305
    packed-switch v8, :pswitch_data_0

    .line 308
    goto/16 :goto_8

    .line 310
    :pswitch_0
    if-eqz v7, :cond_8

    .line 312
    :try_start_1
    iget-object v5, v7, Landroidx/constraintlayout/widget/b$a;->f:Ljava/util/HashMap;

    .line 314
    invoke-static {p1, p2, v5}, La_6ABB224A;->a(Landroid/content/Context;Landroid/content/res/XmlResourceParser;Ljava/util/HashMap;)V

    .line 317
    goto/16 :goto_8

    .line 319
    :cond_8
    new-instance p1, Ljava/lang/RuntimeException;

    .line 321
    new-instance v2, Ljava/lang/StringBuilder;

    .line 323
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 326
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 329
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getLineNumber()I

    .line 332
    move-result p2

    .line 333
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 336
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 339
    move-result-object p2

    .line 340
    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 343
    throw p1

    .line 344
    :pswitch_1
    if-eqz v7, :cond_9

    .line 346
    iget-object v5, v7, Landroidx/constraintlayout/widget/b$a;->c:Landroidx/constraintlayout/widget/b$c;

    .line 348
    invoke-static {p2}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    .line 351
    move-result-object v8

    .line 352
    invoke-virtual {v5, p1, v8}, Landroidx/constraintlayout/widget/b$c;->a(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 355
    goto/16 :goto_8

    .line 357
    :cond_9
    new-instance p1, Ljava/lang/RuntimeException;

    .line 359
    new-instance v2, Ljava/lang/StringBuilder;

    .line 361
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 364
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 367
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getLineNumber()I

    .line 370
    move-result p2

    .line 371
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 374
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 377
    move-result-object p2

    .line 378
    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 381
    throw p1

    .line 382
    :pswitch_2
    if-eqz v7, :cond_a

    .line 384
    iget-object v5, v7, Landroidx/constraintlayout/widget/b$a;->d:Landroidx/constraintlayout/widget/b$b;

    .line 386
    invoke-static {p2}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    .line 389
    move-result-object v8

    .line 390
    invoke-virtual {v5, p1, v8}, Landroidx/constraintlayout/widget/b$b;->a(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 393
    goto/16 :goto_8

    .line 395
    :cond_a
    new-instance p1, Ljava/lang/RuntimeException;

    .line 397
    new-instance v2, Ljava/lang/StringBuilder;

    .line 399
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 402
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 405
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getLineNumber()I

    .line 408
    move-result p2

    .line 409
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 412
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 415
    move-result-object p2

    .line 416
    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 419
    throw p1

    .line 420
    :pswitch_3
    if-eqz v7, :cond_b

    .line 422
    iget-object v5, v7, Landroidx/constraintlayout/widget/b$a;->e:Landroidx/constraintlayout/widget/b$e;

    .line 424
    invoke-static {p2}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    .line 427
    move-result-object v8

    .line 428
    invoke-virtual {v5, p1, v8}, Landroidx/constraintlayout/widget/b$e;->a(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 431
    goto :goto_8

    .line 432
    :cond_b
    new-instance p1, Ljava/lang/RuntimeException;

    .line 434
    new-instance v2, Ljava/lang/StringBuilder;

    .line 436
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 439
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 442
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getLineNumber()I

    .line 445
    move-result p2

    .line 446
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 449
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 452
    move-result-object p2

    .line 453
    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 456
    throw p1

    .line 457
    :pswitch_4
    if-eqz v7, :cond_c

    .line 459
    iget-object v5, v7, Landroidx/constraintlayout/widget/b$a;->b:Landroidx/constraintlayout/widget/b$d;

    .line 461
    invoke-static {p2}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    .line 464
    move-result-object v8

    .line 465
    invoke-virtual {v5, p1, v8}, Landroidx/constraintlayout/widget/b$d;->a(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 468
    goto :goto_8

    .line 469
    :cond_c
    new-instance p1, Ljava/lang/RuntimeException;

    .line 471
    new-instance v2, Ljava/lang/StringBuilder;

    .line 473
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 476
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 479
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getLineNumber()I

    .line 482
    move-result p2

    .line 483
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 486
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 489
    move-result-object p2

    .line 490
    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 493
    throw p1

    .line 494
    :pswitch_5
    invoke-static {p2}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    .line 497
    move-result-object v5

    .line 498
    invoke-static {p1, v5, v2}, Landroidx/constraintlayout/widget/b;->d(Landroid/content/Context;Landroid/util/AttributeSet;Z)Landroidx/constraintlayout/widget/b$a;

    # ep-tbmiqzmautau
    .line 501
    move-result-object v5

    .line 502
    iget-object v7, v5, Landroidx/constraintlayout/widget/b$a;->d:Landroidx/constraintlayout/widget/b$b;

    .line 504
    iput v4, v7, Landroidx/constraintlayout/widget/b$b;->f_c68cf6ef:I

    .line 506
    goto :goto_7

    .line 507
    :pswitch_6
    invoke-static {p2}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    .line 510
    move-result-object v5

    .line 511
    invoke-static {p1, v5, v2}, Landroidx/constraintlayout/widget/b;->d(Landroid/content/Context;Landroid/util/AttributeSet;Z)Landroidx/constraintlayout/widget/b$a;

    .line 514
    move-result-object v5

    .line 515
    iget-object v7, v5, Landroidx/constraintlayout/widget/b$a;->d:Landroidx/constraintlayout/widget/b$b;

    .line 517
    iput-boolean v4, v7, Landroidx/constraintlayout/widget/b$b;->a:Z

    .line 519
    goto :goto_7

    .line 520
    :pswitch_7
    invoke-static {p2}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    .line 523
    move-result-object v5

    .line 524
    invoke-static {p1, v5, v4}, Landroidx/constraintlayout/widget/b;->d(Landroid/content/Context;Landroid/util/AttributeSet;Z)Landroidx/constraintlayout/widget/b$a;

    .line 527
    move-result-object v5

    .line 528
    goto :goto_7

    .line 529
    :pswitch_8
    invoke-static {p2}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    .line 532
    move-result-object v5

    .line 533
    invoke-static {p1, v5, v2}, Landroidx/constraintlayout/widget/b;->d(Landroid/content/Context;Landroid/util/AttributeSet;Z)Landroidx/constraintlayout/widget/b$a;

    .line 536
    move-result-object v5

    .line 537
    :goto_7
    move-object v7, v5

    .line 538
    goto :goto_8

    .line 539
    :cond_d
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    .line 542
    :goto_8
    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->m_b61f0bb8()I

    .line 545
    move-result v5
    :try_end_1
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    .line 546
    goto/16 :goto_2

    .line 548
    :catch_0
    move-exception p1

    .line 549
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 552
    goto :goto_9

    .line 553
    :catch_1
    move-exception p1

    .line 554
    invoke-virtual {p1}, Lorg/xmlpull/v1/XmlPullParserException;->printStackTrace()V

    .line 557
    :cond_e
    :goto_9
    iget-object p1, p0, La_6D9B1845;->e:Landroid/util/SparseArray;

    .line 559
    invoke-virtual {p1, v1, v0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 562
    goto :goto_b

    .line 563
    :cond_f
    :goto_a
    add-int/lit8 v3, v3, 0x1

    .line 565
    goto/16 :goto_0

    .line 567
    :cond_10
    :goto_b
    return-void

    .line 568
    nop

    .line 569
    :sswitch_data_0
    .sparse-switch
        -0x7bb8f310 -> :sswitch_3
        -0xb58ea23 -> :sswitch_2
        0x196d04a9 -> :sswitch_1
    # ep-aoqfbpzbrvfm
        0x7feafd65 -> :sswitch_0
    .end sparse-switch

    .line 587
    :sswitch_data_1
    .sparse-switch
        -0x78c018b6 -> :sswitch_d
        -0x7648542a -> :sswitch_c
        -0x74f4db17 -> :sswitch_b
        -0x4bab3dd3 -> :sswitch_a
        -0x49cf74b4 -> :sswitch_9
        -0x446d330 -> :sswitch_8
        0x15d883d2 -> :sswitch_7
        0x4f5d3b97 -> :sswitch_6
        0x6acd460b -> :sswitch_5
        0x6b78f1fd -> :sswitch_4
    .end sparse-switch

    .line 629
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method
