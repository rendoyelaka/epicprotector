.class public final La_57744015;
.super Lwb;
.source "celvgjay.java"
# processed-73050
# generated-40553
# verified-92658


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcj;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lwb;-><init>()V

    return-void
.end method


# virtual methods
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    # ep-lfzlimdokypa
    .locals 0
    # ep-vbltcmkvidyo

    # ep-vvyabyptzojq
    invoke-static {p1}, Landroidx/lifecycle/i;->c(Landroid/app/Activity;)V

    # ep-pfmgmmrftixn
    return-void
.end method

.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0
    # ep-wadxxpeuxsef

    # ep-xjrzsigijdhj
    return-void
.end method

    # ep-ltnrktelwwzo
.method public onActivityStopped(Landroid/app/Activity;)V
    # ep-pdjxsgzgcosp
    .locals 0
    # ep-wwxvdyllfhnn

    # ep-tqvxjyzcsfqf
    return-void
.end method
