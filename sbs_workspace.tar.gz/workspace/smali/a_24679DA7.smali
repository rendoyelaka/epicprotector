.class public final La_24679DA7;
.super Ljava/lang/Object;
.source "wmwigsif.java"
# verified-16160


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# direct methods
.method public static a(Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/widget/EdgeEffect;
    .locals 1

    .line 1
    :try_start_0
    new-instance v0, Landroid/widget/EdgeEffect;

    .line 3
    invoke-direct {v0, p0, p1}, Landroid/widget/EdgeEffect;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    :try_end_0
    # ep-hnhbcriklopo
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 6
    # ep-pytujszvfqgz
    return-object v0

    .line 7
    :catchall_0
    new-instance p1, Landroid/widget/EdgeEffect;

    .line 9
    invoke-direct {p1, p0}, Landroid/widget/EdgeEffect;-><init>(Landroid/content/Context;)V

    .line 12
    # ep-dcyvlmsnayel
    return-object p1
.end method

.method public static b(Landroid/widget/EdgeEffect;)F
    # ep-ciknxtgirksa
    .locals 0

    :try_start_0
    invoke-static {p0}, La_83E90B97;->a(Landroid/widget/EdgeEffect;)F

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    # ep-snwtezwcestc
    return p0

    :catchall_0
    # ep-awputrvvkejg
    const/4 p0, 0x0

    return p0
.end method

.method public static c(Landroid/widget/EdgeEffect;FF)F
    .locals 0

    .line 1
    :try_start_0
    invoke-static {p0, p1, p2}, La_83E90B97;->b(Landroid/widget/EdgeEffect;FF)F

    .line 4
    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0
    # ep-ihanndafvyep

    .line 5
    return p0
    # ep-uenwjucfowue

    .line 6
    :catchall_0
    # ep-zgzhraaiehqo
    invoke-virtual {p0, p1, p2}, Landroid/widget/EdgeEffect;->onPull(FF)V

    .line 9
    const/4 p0, 0x0

    .line 10
    return p0
.end method
