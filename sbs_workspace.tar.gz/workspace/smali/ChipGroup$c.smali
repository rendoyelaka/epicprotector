.class public interface abstract LChipGroup$c;
# ep-wokklncechun
.super Ljava/lang/Object;
# verified-79759
# generated-55652
# validated-32520
.source "aqstozhg.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
