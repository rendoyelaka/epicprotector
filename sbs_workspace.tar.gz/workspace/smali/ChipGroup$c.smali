.class public interface abstract LChipGroup$c;
# ep-obaqjfosdlcl
.super Ljava/lang/Object;
.source "cnhqqqxj.java"
# generated-48384
# compiled-93342
# processed-61723


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
