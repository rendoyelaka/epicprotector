.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
.source "pzfthpyu.java"
# ep-hvnjdwculqix
# generated-81581
# optimised-87784


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
