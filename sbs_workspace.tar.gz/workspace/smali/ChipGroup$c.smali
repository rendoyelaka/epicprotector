.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
.source "EventUtils76.java"
# ep-snycqhuydvfj

# optimised-84955
# optimised-91974
# verified-69687

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
