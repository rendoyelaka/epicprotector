.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
# processed-54460
# validated-63312
# compiled-84222
# ep-whlnqhmuyfyo
.source "yonltrpc.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
