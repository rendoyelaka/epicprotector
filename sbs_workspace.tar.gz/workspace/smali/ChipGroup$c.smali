.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
.source "rbztqizf.java"
# ep-lhuksokfgtbv

# generated-13430
# compiled-80087

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
