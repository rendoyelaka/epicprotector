.class public interface abstract LChipGroup$c;
# ep-ejaltcnrqoka
# processed-94317
# compiled-66728
.super Ljava/lang/Object;
.source "rxfwcdkj.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
