.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
# ep-rliymrdbfiku
.source "kopozyyl.java"
# optimised-58332
# generated-69071
# generated-85712


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
