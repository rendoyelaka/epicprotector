.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
# ep-cygfpztpagxk
.source "fgrpleph.java"
# generated-67884
# verified-56838
# compiled-10833


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
