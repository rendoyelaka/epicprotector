.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
# ep-grclzzroybpn
# validated-52997
# validated-24729
.source "dcvvealr.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
