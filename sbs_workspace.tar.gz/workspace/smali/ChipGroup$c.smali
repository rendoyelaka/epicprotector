.class public interface abstract LChipGroup$c;
# ep-jmqxlbluqeln
.super Ljava/lang/Object;
# compiled-56407
.source "LayoutUtils89.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
