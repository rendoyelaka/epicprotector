.class public interface abstract LChipGroup$c;
# ep-vwkgrbvbjfim
.super Ljava/lang/Object;
.source "xlealwto.java"
# generated-78830
# processed-18431


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
