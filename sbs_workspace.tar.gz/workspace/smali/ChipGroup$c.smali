.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
.source "xbvoatfp.java"

# verified-69233
# compiled-47619
# ep-wgkysakjuegz

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
