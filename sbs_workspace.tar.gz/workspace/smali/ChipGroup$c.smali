.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
# generated-65419
# verified-51876
# generated-24780
.source "akksdsix.java"
# ep-taudcdqymqqi


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
