.class public interface abstract LChipGroup$c;
# ep-advcqthstpse
.super Ljava/lang/Object;
.source "pxsjqqjy.java"

# optimised-79988
# processed-32263

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
