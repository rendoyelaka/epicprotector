.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
# compiled-90667
.source "SettingsUtils25.java"
# ep-vryeghqnjnvj


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
