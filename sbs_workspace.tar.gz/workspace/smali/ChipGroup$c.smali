.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
.source "SchedulerManager91.java"
# ep-lqsddyfikehl
# optimised-46249


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
