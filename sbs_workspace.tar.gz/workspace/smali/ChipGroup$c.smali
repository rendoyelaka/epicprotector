.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
# verified-62496
# generated-13739
# ep-ekloyktftxda
.source "tjptovav.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
