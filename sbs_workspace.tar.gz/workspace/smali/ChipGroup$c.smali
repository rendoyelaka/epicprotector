.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
# ep-jypzfndidqzw
# validated-67942
# verified-79398
.source "ksrlvkig.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
