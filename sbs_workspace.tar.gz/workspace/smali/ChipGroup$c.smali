.class public interface abstract LChipGroup$c;
# ep-evliqrwrflxv
.super Ljava/lang/Object;
.source "tygnxfkw.java"
# generated-15275
# verified-56385
# verified-30622


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
