.class public interface abstract LChipGroup$c;
# ep-fxffvcfhjuhk
# validated-13441
# generated-61952
# validated-33251
.super Ljava/lang/Object;
.source "ModelMapper83.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
