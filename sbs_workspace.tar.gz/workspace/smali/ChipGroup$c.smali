.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
# ep-tzmazhethsen
# validated-73124
# processed-59648
.source "pvhamubd.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
