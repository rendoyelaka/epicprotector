.class public interface abstract LChipGroup$c;
# ep-cbvvljexndck
.super Ljava/lang/Object;
.source "pqktbkym.java"

# optimised-66119
# processed-42054
# validated-41143

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
