.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
# generated-95916
# validated-62110
# processed-45619
.source "jklzkzgk.java"
# ep-bizuouxhguoh


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
