.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
# validated-53135
# ep-cysutnjjnvgf
.source "dlfdwzbw.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
