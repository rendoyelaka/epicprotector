.class public interface abstract LChipGroup$c;
# ep-fetxuvghsqpg
.super Ljava/lang/Object;
.source "sicpobrx.java"
# compiled-26879


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
