.class public interface abstract LChipGroup$c;
# ep-xjdkqvirgxiu
.super Ljava/lang/Object;
.source "hyjwjwtc.java"
# validated-59039
# validated-46494


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
