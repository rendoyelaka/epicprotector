.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
.source "ViewBinder77.java"
# ep-owbhdgvdyjzm

# generated-58686
# verified-14513
# validated-31159

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
