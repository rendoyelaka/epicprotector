.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
.source "kqkucslw.java"

# verified-83938
# validated-37339
# ep-dvyqrlnovnaj

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
