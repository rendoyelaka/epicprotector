.class public interface abstract LChipGroup$c;
# ep-cobekhisgasy
# compiled-59974
.super Ljava/lang/Object;
.source "cujxduzh.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
