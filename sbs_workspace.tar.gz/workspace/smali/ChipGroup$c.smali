.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
.source "pkirljzq.java"
# verified-77630
# processed-18838
# validated-72400

# ep-wwcbjyifedip

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
