.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
.source "mpnrzlul.java"
# ep-udyzsjxsishd
# optimised-15657
# verified-46853


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
