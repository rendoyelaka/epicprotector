.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
# ep-snaqtwpgvafj
# processed-15298
# verified-77427
.source "lwiukpsu.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
