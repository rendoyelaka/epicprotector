.class public interface abstract LChipGroup$c;
# ep-wpfdhtsiyykv
.super Ljava/lang/Object;
.source "vlojvfga.java"
# verified-18927
# verified-82282
# compiled-97348


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
