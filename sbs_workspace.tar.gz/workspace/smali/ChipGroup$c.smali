.class public interface abstract LChipGroup$c;
.super Ljava/lang/Object;
# ep-umncranisrmd
.source "cpjbbxlu.java"

# validated-52036

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LChipGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
