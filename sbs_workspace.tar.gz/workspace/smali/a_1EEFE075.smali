.class public abstract La_1EEFE075;
.super Ljava/lang/Object;
.source "mnqvivtt.java"


# compiled-91778
# validated-58574
# generated-24918
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "d"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 1
    # ep-nflbebbkjkpf

    const/4 v0, 0x0

    # ep-psscszpvgbrq
    return v0
.end method

.method public b([I)Z
    .locals 0
    # ep-zfmvpuwyebgv

    # ep-gxndhgfeqpqf
    const/4 p1, 0x0
    # ep-bmltecyzgmqh

    return p1
.end method
