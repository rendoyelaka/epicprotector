.class public final LSystemAlarmScheduler;
.super Ljava/lang/Object;
.source "drwenfkj.java"
# ep-runnpibsbnlp
# validated-26909
# generated-40267

# interfaces
.implements Lhr;


# instance fields
.field public final c:Landroid/content/Context;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "SystemAlarmScheduler"

    .line 3
    invoke-static {v0}, Ltj;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, LSystemAlarmScheduler;->c:Landroid/content/Context;

    .line 10
    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/String;)V
    .locals 3

    .line 1
    sget v0, Landroidx/work/impl/background/systemalarm/a;->f:I

    .line 3
    new-instance v0, Landroid/content/Intent;

    .line 5
    const-class v1, Landroidx/work/impl/background/systemalarm/SystemAlarmService;

    .line 7
    iget-object v2, p0, LSystemAlarmScheduler;->c:Landroid/content/Context;

    .line 9
    invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 12
    const-string v1, "ACTION_STOP_WORK"

    .line 14
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 17
    const-string v1, "KEY_WORKSPEC_ID"

    .line 19
    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 22
    invoke-virtual {v2, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 25
    return-void
.end method

.method public final varargs d([LWorkSpec;)V
    .locals 7

    .line 1
    array-length v0, p1

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x0

    .line 4
    :goto_0
    if-ge v2, v0, :cond_0

    .line 6
    aget-object v3, p1, v2

    .line 8
    invoke-static {}, Ltj;->c()Ltj;

    .line 11
    move-result-object v4

    .line 12
    const/4 v5, 0x1

    .line 13
    new-array v5, v5, [Ljava/lang/Object;

    .line 15
    iget-object v6, v3, LWorkSpec;->a:Ljava/lang/String;

    .line 17
    aput-object v6, v5, v1

    .line 19
    const-string v6, "Scheduling work with workSpecId %s"

    .line 21
    invoke-static {v6, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 24
    new-array v5, v1, [Ljava/lang/Throwable;

    .line 26
    invoke-virtual {v4, v5}, Ltj;->a([Ljava/lang/Throwable;)V

    .line 29
    iget-object v3, v3, LWorkSpec;->a:Ljava/lang/String;

    .line 31
    iget-object v4, p0, LSystemAlarmScheduler;->c:Landroid/content/Context;

    .line 33
    invoke-static {v4, v3}, Landroidx/work/impl/background/systemalarm/a;->c(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 36
    move-result-object v3

    .line 37
    invoke-virtual {v4, v3}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 40
    add-int/lit8 v2, v2, 0x1

    .line 42
    goto :goto_0

    .line 43
    :cond_0
    return-void
.end method

.method public final f()Z
    .locals 1

    const/4 v0, 0x1

    return v0
.end method
