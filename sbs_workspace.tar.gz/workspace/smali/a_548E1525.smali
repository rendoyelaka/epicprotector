.class public interface abstract La_548E1525;
.super Ljava/lang/Object;
# ep-meomkyxhfzhf
.source "zxiwqamz.java"

# validated-51678
# verified-79364
# processed-26750

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_43DFF6AC;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lfr;)V
.end method
