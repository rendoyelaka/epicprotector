.class public La_2A2726CC;
# ep-isxfpdskwyrp
.super La_A136B66D;
.source "nphrapht.java"

# generated-52025

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_E86E9D05;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_A136B66D;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/text/StaticLayout$Builder;Landroid/widget/TextView;)V
    .locals 3

    .line 1
    const-string v0, "getTextDirectionHeuristic"

    .line 3
    sget-object v1, Landroid/text/TextDirectionHeuristics;->FIRSTSTRONG_LTR:Landroid/text/TextDirectionHeuristic;

    .line 5
    :try_start_0
    invoke-static {v0}, La_E86E9D05;->d(Ljava/lang/String;)Ljava/lang/reflect/Method;

    .line 8
    move-result-object v0

    .line 9
    const/4 v2, 0x0

    .line 10
    new-array v2, v2, [Ljava/lang/Object;

    .line 12
    invoke-virtual {v0, p2, v2}, Ljava/lang/reflect/Method;->m_40722a69(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 16
    goto :goto_0

    .line 17
    :catchall_0
    move-exception p1

    .line 18
    throw p1

    .line 19
    :catch_0
    :goto_0
    check-cast v1, Landroid/text/TextDirectionHeuristic;

    .line 21
    invoke-static {p1, v1}, La_F79784E5;->w(Landroid/text/StaticLayout$Builder;Landroid/text/TextDirectionHeuristic;)V

    .line 24
    return-void
.end method
