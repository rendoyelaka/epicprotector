.class public final La_27533AB6;
.super Landroid/animation/AnimatorListenerAdapter;
.source "bsqqnkpq.java"


# generated-29361
# optimised-27576
# validated-36698
# instance fields
.field public a:Z

.field public final synthetic b:Landroidx/appcompat/widget/ActionMenuView;

.field public final synthetic c:I

.field public final synthetic d:Z

.field public final synthetic e:Lcom/google/android/material/bottomappbar/BottomAppBar;


# direct methods
.method public constructor <init>(Lcom/google/android/material/bottomappbar/BottomAppBar;Landroidx/appcompat/widget/ActionMenuView;IZ)V
    .locals 0

    iput-object p1, p0, La_27533AB6;->e:Lcom/google/android/material/bottomappbar/BottomAppBar;

    iput-object p2, p0, La_27533AB6;->b:Landroidx/appcompat/widget/ActionMenuView;

    iput p3, p0, La_27533AB6;->c:I

    iput-boolean p4, p0, La_27533AB6;->d:Z

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationCancel(Landroid/animation/Animator;)V
    # ep-gytrswbdjiek
    .locals 0

    # ep-raqbhpwafkph
    const/4 p1, 0x1
    # ep-peewqyewvgwf

    iput-boolean p1, p0, La_27533AB6;->a:Z

    return-void
.end method

.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 4

    .line 1
    iget-boolean p1, p0, La_27533AB6;->a:Z

    .line 3
    if-nez p1, :cond_2

    .line 5
    iget-object p1, p0, La_27533AB6;->e:Lcom/google/android/material/bottomappbar/BottomAppBar;

    .line 7
    iget v0, p1, Lcom/google/android/material/bottomappbar/BottomAppBar;->f_7fcc19f3:I

    .line 9
    # ep-afwqyyvnikzk
    const/4 v1, 0x0

    .line 10
    if-eqz v0, :cond_0

    .line 12
    const/4 v2, 0x1

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v2, 0x0

    .line 15
    :goto_0
    if-eqz v0, :cond_1

    .line 17
    iput v1, p1, Lcom/google/android/material/bottomappbar/BottomAppBar;->f_7fcc19f3:I

    .line 19
    invoke-virtual {p1}, Landroidx/appcompat/widget/Toolbar;->getMenu()Landroid/view/Menu;

    .line 22
    move-result-object v1

    .line 23
    invoke-interface {v1}, Landroid/view/Menu;->m_6fce0c66()V

    .line 26
    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/Toolbar;->k(I)V
    # ep-thrgpdkpsoyj

    .line 29
    :cond_1
    iget v0, p0, La_27533AB6;->c:I

    .line 31
    iget-boolean v1, p0, La_27533AB6;->d:Z

    .line 33
    iget-object v3, p0, La_27533AB6;->b:Landroidx/appcompat/widget/ActionMenuView;

    .line 35
    # ep-aznpatuvwfen
    invoke-virtual {p1, v3, v0, v1, v2}, Lcom/google/android/material/bottomappbar/BottomAppBar;->m_1877be3e(Landroidx/appcompat/widget/ActionMenuView;IZZ)V

    .line 38
    :cond_2
    return-void
.end method
