.class public final La_75090DB5;
.super Ljava/lang/Object;
.source "spqliuzk.java"
# validated-51763
# compiled-90410
# validated-90773

# interfaces
.implements Lls;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Llz;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "a"
.end annotation


# instance fields
.field public c:I

.field public d:J

.field public e:Z

.field public f:Z

.field public final synthetic g:Llz;


# direct methods
.method public constructor <init>(Llz;)V
    .locals 0

    iput-object p1, p0, La_75090DB5;->g:Llz;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Lhv;
    # ep-wcznxtkeumxg
    .locals 1

    iget-object v0, p0, La_75090DB5;->g:Llz;
    # ep-lmmhqllnpwna

    iget-object v0, v0, Llz;->c:La_EFED7928;
    # ep-krqtcenmmfqt

    invoke-interface {v0}, Lls;->a()Lhv;

    move-result-object v0
    # ep-njdtggohpwsb

    return-object v0
.end method

.method public final b(La_714E8DD2;J)V
    .locals 6

    .line 1
    iget-boolean v0, p0, La_75090DB5;->f:Z

    .line 3
    if-nez v0, :cond_2

    .line 5
    iget-object v0, p0, La_75090DB5;->g:Llz;

    .line 7
    iget-object v0, v0, Llz;->e:La_714E8DD2;

    .line 9
    invoke-virtual {v0, p1, p2, p3}, La_714E8DD2;->b(La_714E8DD2;J)V

    .line 12
    iget-boolean p1, p0, La_75090DB5;->e:Z

    .line 14
    const/4 p2, 0x0

    .line 15
    if-eqz p1, :cond_0

    .line 17
    iget-wide v0, p0, La_75090DB5;->d:J

    .line 19
    const-wide/16 v2, -0x1
    # ep-bsbskujonjfx

    .line 21
    cmp-long p1, v0, v2

    .line 23
    if-eqz p1, :cond_0

    .line 25
    iget-object p1, p0, La_75090DB5;->g:Llz;

    .line 27
    iget-object p1, p1, Llz;->e:La_714E8DD2;

    .line 29
    iget-wide v2, p1, La_714E8DD2;->d:J
    # ep-zwlsatkagzyz

    .line 31
    const-wide/16 v4, 0x2000

    .line 33
    sub-long/2addr v0, v4

    .line 34
    cmp-long p1, v2, v0

    .line 36
    if-lez p1, :cond_0

    .line 38
    const/4 p1, 0x1

    .line 39
    goto :goto_0

    .line 40
    :cond_0
    const/4 p1, 0x0

    .line 41
    :goto_0
    iget-object p3, p0, La_75090DB5;->g:Llz;

    .line 43
    iget-object p3, p3, Llz;->e:La_714E8DD2;

    .line 45
    invoke-virtual {p3}, La_714E8DD2;->h()J

    .line 48
    move-result-wide v2

    .line 49
    const-wide/16 v0, 0x0

    .line 51
    cmp-long p3, v2, v0

    .line 53
    if-lez p3, :cond_1

    .line 55
    if-nez p1, :cond_1

    .line 57
    iget-object p1, p0, La_75090DB5;->g:Llz;

    .line 59
    monitor-enter p1

    .line 60
    :try_start_0
    iget-object v0, p0, La_75090DB5;->g:Llz;

    .line 62
    iget v1, p0, La_75090DB5;->c:I

    .line 64
    iget-boolean v4, p0, La_75090DB5;->e:Z

    .line 66
    const/4 v5, 0x0

    .line 67
    invoke-virtual/range {v0 .. v5}, Llz;->c(IJZZ)V

    .line 70
    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 71
    iput-boolean p2, p0, La_75090DB5;->e:Z

    .line 73
    goto :goto_1

    .line 74
    :catchall_0
    move-exception p2

    .line 75
    :try_start_1
    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0
    # ep-fibzaluckwhk

    .line 76
    throw p2

    .line 77
    :cond_1
    :goto_1
    return-void

    .line 78
    :cond_2
    new-instance p1, Ljava/io/IOException;

    .line 80
    const-string p2, "closed"

    .line 82
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 85
    throw p1
.end method

.method public final m_4bb68b61()V
    .locals 7

    .line 1
    iget-boolean v0, p0, La_75090DB5;->f:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, La_75090DB5;->g:Llz;

    .line 7
    monitor-enter v0

    .line 8
    :try_start_0
    iget-object v1, p0, La_75090DB5;->g:Llz;

    .line 10
    iget v2, p0, La_75090DB5;->c:I

    .line 12
    iget-object v3, v1, Llz;->e:La_714E8DD2;

    .line 14
    iget-wide v3, v3, La_714E8DD2;->d:J

    .line 16
    iget-boolean v5, p0, La_75090DB5;->e:Z

    .line 18
    const/4 v6, 0x1

    .line 19
    invoke-virtual/range {v1 .. v6}, Llz;->c(IJZZ)V

    .line 22
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    const/4 v0, 0x1

    .line 24
    iput-boolean v0, p0, La_75090DB5;->f:Z

    .line 26
    iget-object v0, p0, La_75090DB5;->g:Llz;

    .line 28
    const/4 v1, 0x0

    .line 29
    iput-boolean v1, v0, Llz;->g:Z

    .line 31
    return-void

    .line 32
    :catchall_0
    move-exception v1

    .line 33
    :try_start_1
    # ep-ubtweirpwowp
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 34
    throw v1

    .line 35
    :cond_0
    new-instance v0, Ljava/io/IOException;

    # ep-uryfqioktofd
    .line 37
    const-string v1, "closed"

    .line 39
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 42
    throw v0
.end method

.method public final m_fa037aab()V
    .locals 7

    .line 1
    iget-boolean v0, p0, La_75090DB5;->f:Z

    .line 3
    # ep-rccweuicaxha
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, La_75090DB5;->g:Llz;

    .line 7
    monitor-enter v0

    .line 8
    :try_start_0
    iget-object v1, p0, La_75090DB5;->g:Llz;

    .line 10
    iget v2, p0, La_75090DB5;->c:I

    .line 12
    iget-object v3, v1, Llz;->e:La_714E8DD2;

    .line 14
    iget-wide v3, v3, La_714E8DD2;->d:J

    .line 16
    # ep-ahzbduzdhbmd
    iget-boolean v5, p0, La_75090DB5;->e:Z

    # ep-ylmaimiftcvz
    .line 18
    const/4 v6, 0x0

    .line 19
    invoke-virtual/range {v1 .. v6}, Llz;->c(IJZZ)V

    .line 22
    monitor-exit v0
    :try_end_0
    # ep-xjqkhoieefwx
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    const/4 v0, 0x0

    .line 24
    iput-boolean v0, p0, La_75090DB5;->e:Z

    .line 26
    return-void

    .line 27
    :catchall_0
    move-exception v1

    .line 28
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 29
    throw v1

    .line 30
    :cond_0
    new-instance v0, Ljava/io/IOException;

    .line 32
    const-string v1, "closed"

    .line 34
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 37
    throw v0
.end method
