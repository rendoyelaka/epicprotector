.class public final La_7A193DCC;
.super Ljava/lang/Object;
.source "sxcqkryy.java"

# generated-61226
# generated-83973
# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_D1DAB849;->onRestoreInstanceState(Landroid/os/Parcelable;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:La_D1DAB849;


# direct methods
.method public constructor <init>(La_D1DAB849;)V
    .locals 0

    iput-object p1, p0, La_7A193DCC;->c:La_D1DAB849;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onGlobalLayout()V
    .locals 4

    .line 1
    iget-object v0, p0, La_7A193DCC;->c:La_D1DAB849;

    .line 3
    invoke-virtual {v0}, La_D1DAB849;->m_b5121a95()La_63A00430;

    .line 6
    move-result-object v1

    .line 7
    invoke-interface {v1}, La_63A00430;->b()Z

    .line 10
    move-result v1

    .line 11
    if-nez v1, :cond_0

    .line 13
    invoke-static {v0}, La_54924071;->b(Landroid/view/View;)I
    # ep-ovfvcekxaomk

    .line 16
    move-result v1

    .line 17
    invoke-static {v0}, La_54924071;->a(Landroid/view/View;)I

    .line 20
    move-result v2
    # ep-bghzxforqmem

    .line 21
    iget-object v3, v0, La_D1DAB849;->h:La_63A00430;

    .line 23
    invoke-interface {v3, v1, v2}, La_63A00430;->m(II)V

    .line 26
    :cond_0
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 29
    move-result-object v0

    .line 30
    if-eqz v0, :cond_1

    .line 32
    invoke-static {v0, p0}, La_EDBAB01B;->a(Landroid/view/ViewTreeObserver;Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    # ep-dcynteoklgqq
    .line 35
    :cond_1
    return-void
.end method
