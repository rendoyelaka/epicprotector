.class public interface abstract La_09E48860;
.super Ljava/lang/Object;
.source "iprqcsmw.java"


# generated-64838
# verified-17469
# generated-82072
# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# virtual methods
.method public abstract onActionViewCollapsed()V
.end method

.method public abstract onActionViewExpanded()V
.end method
