.class public interface abstract La_6A7F246F;
.super Ljava/lang/Object;
.source "jqeiokog.java"

# processed-77526
# generated-46196
# processed-96546
# ep-rrcounjiwcjb

# virtual methods
.method public abstract a(Landroid/graphics/RectF;)F
.end method
