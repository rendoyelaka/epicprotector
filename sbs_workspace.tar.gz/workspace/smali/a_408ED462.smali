.class public final La_408ED462;
.super Ljava/lang/Object;
# ep-utojbohofcwj
.source "axitrkby.java"

# verified-79554
# processed-41254
# interfaces
.implements La_7C223A97;


# instance fields
.field public final a:Ljq;

.field public final b:La_D00A7EA2;

.field public final c:La_EA9ABB88;


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La_408ED462;->a:Ljq;

    .line 6
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 12
    new-instance v0, La_D00A7EA2;

    .line 14
    invoke-direct {v0, p1}, La_D00A7EA2;-><init>(Ljq;)V

    .line 17
    iput-object v0, p0, La_408ED462;->b:La_D00A7EA2;

    .line 19
    new-instance v0, La_EA9ABB88;

    .line 21
    invoke-direct {v0, p1}, La_EA9ABB88;-><init>(Ljq;)V

    .line 24
    iput-object v0, p0, La_408ED462;->c:La_EA9ABB88;

    .line 26
    return-void
.end method
