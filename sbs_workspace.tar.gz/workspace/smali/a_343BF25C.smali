.class public final La_343BF25C;
.super Ljava/lang/Object;
# generated-12663
# processed-14413
# generated-82927
.source "ozjerwwb.java"


# direct methods
.method public static a(Landroid/net/ConnectivityManager;)Z
    .locals 0
    # ep-sfnbwaeocarc

    invoke-virtual {p0}, Landroid/net/ConnectivityManager;->isActiveNetworkMetered()Z

    move-result p0
    # ep-numdrvmnyomb

    # ep-bnuhqeowxzct
    return p0
.end method
