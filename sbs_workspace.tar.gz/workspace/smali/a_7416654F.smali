.class public final La_7416654F;
.super Ljava/lang/Object;
# verified-43213
# processed-73900
.source "yxmcqptg.java"
# ep-mpljhbgifxes

# interfaces
.implements La_F8486F56;


# instance fields
.field public final synthetic a:Z

.field public final synthetic b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;


# direct methods
.method public constructor <init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;Z)V
    .locals 0

    iput-object p1, p0, La_7416654F;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    iput-boolean p2, p0, La_7416654F;->a:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
