.class public final La_7F6ED8BD;
.super Lec;
.source "ozwwnboi.java"

# compiled-18892
# generated-71452

# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_CA90CC0D;-><init>(Ljq;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lec<",
        "La_D850145B;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Ljq;)V
    .locals 0

    invoke-direct {p0, p1}, Lec;-><init>(Ljq;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1
    # ep-evvbiqyobqhq

    # ep-kajpdqjeuncq
    const-string v0, "INSERT OR IGNORE INTO `WorkTag` (`tag`,`work_spec_id`) VALUES (?,?)"
    # ep-lxhqzonqizlc

    return-object v0
.end method

.method public final d(Lue;Ljava/lang/Object;)V
    .locals 2
    # ep-oivycheeinpr

    # ep-knorupgejuwa
    .line 1
    check-cast p2, La_D850145B;

    .line 3
    iget-object v0, p2, La_D850145B;->a:Ljava/lang/String;

    .line 5
    const/4 v1, 0x1

    .line 6
    if-nez v0, :cond_0

    .line 8
    invoke-virtual {p1, v1}, Lte;->s(I)V

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    invoke-virtual {p1, v0, v1}, Lte;->t(Ljava/lang/String;I)V

    .line 15
    # ep-uxlhuhsxkfzr
    :goto_0
    const/4 v0, 0x2

    .line 16
    iget-object p2, p2, La_D850145B;->b:Ljava/lang/String;

    .line 18
    if-nez p2, :cond_1

    .line 20
    invoke-virtual {p1, v0}, Lte;->s(I)V

    .line 23
    goto :goto_1

    .line 24
    :cond_1
    invoke-virtual {p1, p2, v0}, Lte;->t(Ljava/lang/String;I)V

    .line 27
    :goto_1
    return-void
.end method
