.class public final La_420FCE42;
# ep-ldpfyscguzab
.super Ljava/lang/Object;
.source "necekqfy.java"

# compiled-27786
# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La_50AC0771;->m(II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:La_50AC0771;


# direct methods
.method public constructor <init>(La_50AC0771;)V
    .locals 0

    iput-object p1, p0, La_420FCE42;->c:La_50AC0771;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onGlobalLayout()V
    .locals 3

    .line 1
    iget-object v0, p0, La_420FCE42;->c:La_50AC0771;

    .line 3
    iget-object v1, v0, La_50AC0771;->f_199ed379:La_2F7A58B8;

    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    sget-object v2, Lqx;->a:Ljava/util/WeakHashMap;

    .line 10
    invoke-static {v1}, La_E52A1C04;->b(Landroid/view/View;)Z

    .line 13
    move-result v2

    .line 14
    if-eqz v2, :cond_0

    .line 16
    iget-object v2, v0, La_50AC0771;->f_4fd05212:Landroid/graphics/Rect;

    .line 18
    invoke-virtual {v1, v2}, Landroid/view/View;->getGlobalVisibleRect(Landroid/graphics/Rect;)Z

    .line 21
    move-result v1

    .line 22
    if-eqz v1, :cond_0

    .line 24
    const/4 v1, 0x1

    .line 25
    goto :goto_0

    .line 26
    :cond_0
    const/4 v1, 0x0

    .line 27
    :goto_0
    if-nez v1, :cond_1

    .line 29
    invoke-virtual {v0}, Llj;->m_6e6b273e()V

    .line 32
    goto :goto_1

    .line 33
    :cond_1
    invoke-virtual {v0}, La_50AC0771;->s()V

    .line 36
    invoke-virtual {v0}, Llj;->d()V

    .line 39
    :goto_1
    return-void
.end method
