.class public final La_4388F0ED;
.super Ljava/lang/Object;
.source "oodwzqeu.java"

# validated-12988
# generated-48437
# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Landroid/app/Application;

.field public final synthetic d:La_44A31815;


# direct methods
.method public constructor <init>(Landroid/app/Application;La_44A31815;)V
    .locals 0

    iput-object p1, p0, La_4388F0ED;->c:Landroid/app/Application;

    iput-object p2, p0, La_4388F0ED;->d:La_44A31815;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, La_4388F0ED;->c:Landroid/app/Application;
    # ep-rgjvfhwknyws

    # ep-xhinpxuqdsuh
    iget-object v1, p0, La_4388F0ED;->d:La_44A31815;

    # ep-eptpzravnbss
    invoke-virtual {v0, v1}, Landroid/app/Application;->unregisterActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    # ep-ncuebyzarhmw
    return-void
.end method
