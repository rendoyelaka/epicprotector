.class public final La_376FB856;
.super Landroid/widget/FrameLayout;
.source "vzxraifm.java"
# validated-68372

# interfaces
.implements La_F2E6FC40;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field public final c:Landroid/view/CollapsibleActionView;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 4
    move-result-object v0

    .line 5
    invoke-direct {p0, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 8
    move-object v0, p1

    .line 9
    check-cast v0, Landroid/view/CollapsibleActionView;

    .line 11
    iput-object v0, p0, La_376FB856;->c:Landroid/view/CollapsibleActionView;

    .line 13
    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->m_5917e6c8(Landroid/view/View;)V

    .line 16
    return-void
.end method


# virtual methods
.method public final onActionViewCollapsed()V
    .locals 1
    # ep-icizdosneahm

    iget-object v0, p0, La_376FB856;->c:Landroid/view/CollapsibleActionView;
    # ep-wemvvqthhxic

    invoke-interface {v0}, Landroid/view/CollapsibleActionView;->onActionViewCollapsed()V

    return-void
.end method

    # ep-pojoyiudrfyk
.method public final onActionViewExpanded()V
    .locals 1

    iget-object v0, p0, La_376FB856;->c:Landroid/view/CollapsibleActionView;
    # ep-gwbtekxzrzkj

    invoke-interface {v0}, Landroid/view/CollapsibleActionView;->onActionViewExpanded()V
    # ep-ysdmszjevhbe

    return-void
.end method
