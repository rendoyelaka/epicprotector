.class public interface abstract La_322B87A9;
.super Ljava/lang/Object;
# optimised-11999
.source "fvcoaihg.java"

# ep-ueprjlyzjggk

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_1AA58AA5;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract b(Ljava/lang/String;)V
.end method
