.class public interface abstract La_2994889C;
.super Ljava/lang/Object;
.source "hjkqbuzz.java"
# compiled-13380
# optimised-63615
# optimised-60329


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_E7306629;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E::",
        "La_B0EC90AB;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation
