.class public final synthetic La_592FFB92;
.super Ljava/lang/Object;
# ep-rvzcacnkkolt
# verified-99548
# validated-62775
# verified-17888
.source "cxsuaric.java"

# interfaces
.implements Lio/socket/emitter/Emitter$Listener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:La_0E958762;


# direct methods
.method public synthetic constructor <init>(La_0E958762;I)V
    .locals 0

    iput p2, p0, La_592FFB92;->a:I

    iput-object p1, p0, La_592FFB92;->b:La_0E958762;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final call([Ljava/lang/Object;)V
    .locals 2

    .line 1
    iget p1, p0, La_592FFB92;->a:I

    .line 3
    iget-object v0, p0, La_592FFB92;->b:La_0E958762;

    .line 5
    const/4 v1, 0x0

    .line 6
    packed-switch p1, :pswitch_data_0

    .line 9
    goto :goto_0

    .line 10
    :pswitch_0
    iput-boolean v1, v0, La_0E958762;->c:Z

    .line 12
    return-void

    .line 13
    :goto_0
    iget-object p1, v0, La_0E958762;->a:Lio/socket/client/Socket;

    .line 15
    new-array v0, v1, [Ljava/lang/Object;

    .line 17
    const-string v1, "pong"

    .line 19
    invoke-virtual {p1, v1, v0}, Lio/socket/client/Socket;->emit(Ljava/lang/String;[Ljava/lang/Object;)Lio/socket/emitter/Emitter;

    .line 22
    return-void

    .line 23
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
