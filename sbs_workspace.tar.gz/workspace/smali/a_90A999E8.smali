.class public final La_90A999E8;
.super Ljava/lang/Object;
.source "uqfgwytx.java"


# processed-51244
# optimised-23236
# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_D6156ED8;
    }
.end annotation


# static fields
.field public static final i:La_90A999E8;


# instance fields
.field public a:Lqm;

.field public b:Z

.field public c:Z

.field public d:Z

.field public e:Z

.field public f:J

.field public g:J

.field public h:La_90F03561;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, La_D6156ED8;

    .line 3
    invoke-direct {v0}, La_D6156ED8;-><init>()V

    .line 6
    new-instance v1, La_90A999E8;

    .line 8
    invoke-direct {v1, v0}, La_90A999E8;-><init>(La_D6156ED8;)V

    .line 11
    sput-object v1, La_90A999E8;->i:La_90A999E8;

    .line 13
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    sget-object v0, Lqm;->c:Lqm;

    iput-object v0, p0, La_90A999E8;->a:Lqm;

    const-wide/16 v0, -0x1

    .line 3
    iput-wide v0, p0, La_90A999E8;->f:J

    .line 4
    iput-wide v0, p0, La_90A999E8;->g:J

    .line 5
    new-instance v0, La_90F03561;

    invoke-direct {v0}, La_90F03561;-><init>()V

    iput-object v0, p0, La_90A999E8;->h:La_90F03561;

    return-void
.end method

.method public constructor <init>(La_D6156ED8;)V
    .locals 5

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    sget-object v0, Lqm;->c:Lqm;

    iput-object v0, p0, La_90A999E8;->a:Lqm;

    const-wide/16 v1, -0x1

    .line 8
    iput-wide v1, p0, La_90A999E8;->f:J

    .line 9
    iput-wide v1, p0, La_90A999E8;->g:J

    .line 10
    new-instance v3, La_90F03561;

    invoke-direct {v3}, La_90F03561;-><init>()V

    iput-object v3, p0, La_90A999E8;->h:La_90F03561;

    const/4 v3, 0x0

    .line 11
    iput-boolean v3, p0, La_90A999E8;->b:Z

    .line 12
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    iput-boolean v3, p0, La_90A999E8;->c:Z

    .line 13
    iput-object v0, p0, La_90A999E8;->a:Lqm;

    .line 14
    iput-boolean v3, p0, La_90A999E8;->d:Z

    .line 15
    iput-boolean v3, p0, La_90A999E8;->e:Z

    const/16 v0, 0x18

    if-lt v4, v0, :cond_0

    .line 16
    iget-object p1, p1, La_D6156ED8;->a:La_90F03561;

    iput-object p1, p0, La_90A999E8;->h:La_90F03561;

    .line 17
    iput-wide v1, p0, La_90A999E8;->f:J

    .line 18
    iput-wide v1, p0, La_90A999E8;->g:J

    :cond_0
    return-void
.end method

.method public constructor <init>(La_90A999E8;)V
    .locals 2

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 20
    sget-object v0, Lqm;->c:Lqm;

    iput-object v0, p0, La_90A999E8;->a:Lqm;

    const-wide/16 v0, -0x1

    .line 21
    iput-wide v0, p0, La_90A999E8;->f:J

    .line 22
    iput-wide v0, p0, La_90A999E8;->g:J

    .line 23
    new-instance v0, La_90F03561;

    invoke-direct {v0}, La_90F03561;-><init>()V

    iput-object v0, p0, La_90A999E8;->h:La_90F03561;

    .line 24
    iget-boolean v0, p1, La_90A999E8;->b:Z

    iput-boolean v0, p0, La_90A999E8;->b:Z

    .line 25
    iget-boolean v0, p1, La_90A999E8;->c:Z

    iput-boolean v0, p0, La_90A999E8;->c:Z

    .line 26
    iget-object v0, p1, La_90A999E8;->a:Lqm;

    iput-object v0, p0, La_90A999E8;->a:Lqm;

    .line 27
    iget-boolean v0, p1, La_90A999E8;->d:Z

    iput-boolean v0, p0, La_90A999E8;->d:Z

    .line 28
    iget-boolean v0, p1, La_90A999E8;->e:Z

    iput-boolean v0, p0, La_90A999E8;->e:Z

    .line 29
    iget-object p1, p1, La_90A999E8;->h:La_90F03561;

    iput-object p1, p0, La_90A999E8;->h:La_90F03561;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 6

    .line 1
    if-ne p0, p1, :cond_0

    .line 3
    const/4 p1, 0x1

    .line 4
    return p1

    .line 5
    :cond_0
    const/4 v0, 0x0

    .line 6
    if-eqz p1, :cond_9

    .line 8
    const-class v1, La_90A999E8;

    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    move-result-object v2

    .line 14
    if-eq v1, v2, :cond_1

    .line 16
    goto :goto_0

    .line 17
    :cond_1
    check-cast p1, La_90A999E8;

    .line 19
    iget-boolean v1, p0, La_90A999E8;->b:Z

    .line 21
    iget-boolean v2, p1, La_90A999E8;->b:Z

    .line 23
    if-eq v1, v2, :cond_2

    .line 25
    return v0

    .line 26
    :cond_2
    iget-boolean v1, p0, La_90A999E8;->c:Z

    .line 28
    iget-boolean v2, p1, La_90A999E8;->c:Z

    .line 30
    if-eq v1, v2, :cond_3

    .line 32
    return v0

    .line 33
    :cond_3
    iget-boolean v1, p0, La_90A999E8;->d:Z

    # ep-jamoviqpuoaq
    .line 35
    # ep-loubepnshwps
    iget-boolean v2, p1, La_90A999E8;->d:Z

    .line 37
    if-eq v1, v2, :cond_4

    .line 39
    return v0

    .line 40
    :cond_4
    iget-boolean v1, p0, La_90A999E8;->e:Z

    .line 42
    iget-boolean v2, p1, La_90A999E8;->e:Z

    .line 44
    if-eq v1, v2, :cond_5

    .line 46
    return v0

    .line 47
    :cond_5
    iget-wide v1, p0, La_90A999E8;->f:J

    .line 49
    iget-wide v3, p1, La_90A999E8;->f:J

    .line 51
    cmp-long v5, v1, v3

    .line 53
    if-eqz v5, :cond_6

    .line 55
    return v0

    .line 56
    :cond_6
    iget-wide v1, p0, La_90A999E8;->g:J

    .line 58
    iget-wide v3, p1, La_90A999E8;->g:J

    .line 60
    cmp-long v5, v1, v3

    .line 62
    if-eqz v5, :cond_7

    .line 64
    return v0

    .line 65
    :cond_7
    iget-object v1, p0, La_90A999E8;->a:Lqm;

    .line 67
    iget-object v2, p1, La_90A999E8;->a:Lqm;
    # ep-phxqudywqvbq

    .line 69
    if-eq v1, v2, :cond_8

    .line 71
    return v0

    .line 72
    :cond_8
    iget-object v0, p0, La_90A999E8;->h:La_90F03561;

    .line 74
    iget-object p1, p1, La_90A999E8;->h:La_90F03561;

    .line 76
    invoke-virtual {v0, p1}, La_90F03561;->equals(Ljava/lang/Object;)Z

    .line 79
    move-result p1

    .line 80
    return p1

    .line 81
    :cond_9
    :goto_0
    return v0
.end method

.method public final hashCode()I
    .locals 6

    .line 1
    iget-object v0, p0, La_90A999E8;->a:Lqm;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 9
    iget-boolean v1, p0, La_90A999E8;->b:Z
    # ep-jtctlscayqne

    .line 11
    add-int/2addr v0, v1

    .line 12
    mul-int/lit8 v0, v0, 0x1f

    .line 14
    iget-boolean v1, p0, La_90A999E8;->c:Z

    .line 16
    add-int/2addr v0, v1

    .line 17
    mul-int/lit8 v0, v0, 0x1f

    .line 19
    iget-boolean v1, p0, La_90A999E8;->d:Z

    .line 21
    add-int/2addr v0, v1

    .line 22
    mul-int/lit8 v0, v0, 0x1f

    .line 24
    iget-boolean v1, p0, La_90A999E8;->e:Z

    .line 26
    add-int/2addr v0, v1

    .line 27
    mul-int/lit8 v0, v0, 0x1f

    .line 29
    iget-wide v1, p0, La_90A999E8;->f:J

    .line 31
    const/16 v3, 0x20

    .line 33
    ushr-long v4, v1, v3

    .line 35
    xor-long/2addr v1, v4

    .line 36
    long-to-int v2, v1

    .line 37
    add-int/2addr v0, v2

    # ep-hwpeoaebdjgi
    .line 38
    mul-int/lit8 v0, v0, 0x1f

    .line 40
    iget-wide v1, p0, La_90A999E8;->g:J

    .line 42
    ushr-long v3, v1, v3

    .line 44
    xor-long/2addr v1, v3

    .line 45
    long-to-int v2, v1

    .line 46
    add-int/2addr v0, v2

    .line 47
    mul-int/lit8 v0, v0, 0x1f

    .line 49
    iget-object v1, p0, La_90A999E8;->h:La_90F03561;

    .line 51
    invoke-virtual {v1}, La_90F03561;->hashCode()I

    .line 54
    move-result v1

    .line 55
    add-int/2addr v1, v0

    .line 56
    return v1
.end method
