.class public final synthetic Lao;
.super Ljava/lang/Object;
# ep-zbsmlhbbisok
.source "xrvdpkwn.java"

# compiled-78487
# compiled-26603
# optimised-25934
# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# instance fields
.field public final synthetic c:Lbo;


# direct methods
.method public synthetic constructor <init>(Lbo;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lao;->c:Lbo;

    return-void
.end method


# virtual methods
.method public final onDismiss(Landroid/content/DialogInterface;)V
    .locals 1

    .line 1
    const/4 p1, 0x1

    .line 2
    iget-object v0, p0, Lao;->c:Lbo;

    .line 4
    iput-boolean p1, v0, Lbo;->e:Z

    .line 6
    const/4 p1, 0x0

    .line 7
    iput-object p1, v0, Lbo;->i:Landroid/app/AlertDialog;

    .line 9
    return-void
.end method
