.class public interface abstract La_3650BEB0;
.super Ljava/lang/Object;
.source "xknvvhsj.java"
