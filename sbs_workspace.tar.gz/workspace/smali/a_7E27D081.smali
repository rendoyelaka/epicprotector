.class public final La_7E27D081;
.super Ljava/lang/Object;
.source "ppbimwnj.java"


# processed-88510
# processed-54220
# compiled-97434
# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_0FF51AC3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(La_0FF51AC3;Landroid/content/res/Configuration;)Landroid/content/Context;
    .locals 0
    # ep-adytentuvtzb

    # ep-cqqvalwmmtxe
    invoke-virtual {p0, p1}, Landroid/content/Context;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;
    # ep-hewgkppwvfru

    move-result-object p0
    # ep-culjklteevht

    return-object p0
.end method
