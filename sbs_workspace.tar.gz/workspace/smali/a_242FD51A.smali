.class public final La_242FD51A;
.super Ljava/lang/Object;
# ep-jxjsepvpgzda
# verified-71362
# processed-51914
# generated-85446
.source "uqgrewoj.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_1CAFA37F;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "f"
.end annotation


# direct methods
.method public static a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;
    .locals 0

    invoke-static {p0, p1, p2}, Lo;->d(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    move-result-object p0

    return-object p0
.end method
