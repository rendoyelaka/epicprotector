.class public final Lcv;
.super Ljava/lang/Object;
# ep-jtsboctuaehp
.source "pnhyutfo.java"
# validated-15003
# processed-85292


# static fields
.field public static final a:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Lfc;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/ThreadLocal;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_769vv4gx
    goto :ep_s_769vv4gx
    :ep_d_769vv4gx
    nop
    :ep_s_769vv4gx
    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_ywc2cmpv
    goto :ep_s_ywc2cmpv
    :ep_d_ywc2cmpv
    nop
    :ep_s_ywc2cmpv
    sput-object v0, Lcv;->a:Ljava/lang/ThreadLocal;

    return-void
.end method
