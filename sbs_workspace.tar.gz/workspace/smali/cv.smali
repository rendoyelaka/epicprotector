.class public final Lcv;
# ep-kdkmonpzlnfj
.super Ljava/lang/Object;
.source "ViewBinder80.java"

# generated-54020

# static fields
.field public static final a:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Lfc;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/ThreadLocal;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    sput-object v0, Lcv;->a:Ljava/lang/ThreadLocal;

    return-void
.end method
