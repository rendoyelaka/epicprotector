.class public final Lcv;
# ep-ipzqeqwgfnrh
.super Ljava/lang/Object;
.source "VideoFactory66.java"

# optimised-44230

# static fields
.field public static final a:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Lfc;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/ThreadLocal;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    sput-object v0, Lcv;->a:Ljava/lang/ThreadLocal;

    return-void
.end method
