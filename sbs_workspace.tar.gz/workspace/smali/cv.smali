.class public final Lcv;
.super Ljava/lang/Object;
.source "rndeopqj.java"
# ep-jtjkemwbtfwb

# compiled-12339
# processed-96187

# static fields
.field public static final a:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Lfc;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/ThreadLocal;

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_krgcj8hs
    goto :ep_s_krgcj8hs
    :ep_d_krgcj8hs
    nop
    :ep_s_krgcj8hs
    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    const/4 v0, 0x1
    if-ne v0, v0, :ep_d_8ii3h2u6
    goto :ep_s_8ii3h2u6
    :ep_d_8ii3h2u6
    nop
    :ep_s_8ii3h2u6
    sput-object v0, Lcv;->a:Ljava/lang/ThreadLocal;

    return-void
.end method
