.class public final Lcv;
# binding-29951-utils
# listener-10668-callback
# layout-40535-layout
# ep-dyaxpdwwjple
.super Ljava/lang/Object;
.source "CallbackUtils41.java"

# optimised-95016
# compiled-99337

# static fields
.field public static final a:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Lfc;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/ThreadLocal;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    sput-object v0, Lcv;->a:Ljava/lang/ThreadLocal;

    return-void
.end method
