.class public final Lcv;
# ep-kteikuaqrmof
.super Ljava/lang/Object;
# compiled-26167
# compiled-69356
# generated-44850
.source "qynamfhs.java"


# static fields
.field public static final a:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Lfc;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/ThreadLocal;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    sput-object v0, Lcv;->a:Ljava/lang/ThreadLocal;

    return-void
.end method
