.class public final Lbp;
.super Ljava/lang/Object;
# ep-snwjdncvqrie
.source "ojhkyjtl.java"

# processed-90568
# interfaces
.implements Lu4;


# instance fields
.field public final c:Lt4;

.field public final d:Lls;

.field public e:Z


# direct methods
.method public constructor <init>(Lls;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Lt4;

    .line 6
    invoke-direct {v0}, Lt4;-><init>()V

    .line 9
    iput-object v0, p0, Lbp;->c:Lt4;

    .line 11
    if-eqz p1, :cond_0

    .line 13
    iput-object p1, p0, Lbp;->d:Lls;

    .line 15
    return-void

    .line 16
    :cond_0
    new-instance p1, Ljava/lang/NullPointerException;

    .line 18
    const-string v1, "1GWQ/KJV3ajj33S8"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 20
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 23
    throw p1
.end method


# virtual methods
.method public final a()Lhv;
    .locals 1

    iget-object v0, p0, Lbp;->d:Lls;

    invoke-interface {v0}, Lls;->a()Lhv;

    move-result-object v0

    return-object v0
.end method

.method public final b(Lt4;J)V
    .locals 2

    .line 1
    iget-boolean v0, p0, Lbp;->e:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, Lbp;->c:Lt4;

    .line 7
    invoke-virtual {v0, p1, p2, p3}, Lt4;->b(Lt4;J)V

    .line 10
    invoke-virtual {p0}, Lbp;->h()Lu4;

    .line 13
    return-void

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 16
    const-string v1, "xGCR5OcM"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p2

    .line 18
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 21
    throw p1
.end method

.method public final c(J)Lu4;
    .locals 2

    .line 1
    iget-boolean v0, p0, Lbp;->e:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, Lbp;->c:Lt4;

    .line 7
    invoke-virtual {v0, p1, p2}, Lt4;->B(J)Lt4;

    .line 10
    invoke-virtual {p0}, Lbp;->h()Lu4;

    .line 13
    return-object p0

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 16
    const-string v1, "xGCR5OcM"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p2

    .line 18
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 21
    throw p1
.end method

.method public final close()V
    .locals 7

    .line 1
    iget-object v0, p0, Lbp;->d:Lls;

    .line 3
    iget-boolean v1, p0, Lbp;->e:Z

    .line 5
    if-eqz v1, :cond_0

    .line 7
    return-void

    .line 8
    :cond_0
    :try_start_0
    iget-object v1, p0, Lbp;->c:Lt4;

    .line 10
    iget-wide v2, v1, Lt4;->d:J

    .line 12
    const-wide/16 v4, 0x0

    .line 14
    cmp-long v6, v2, v4

    .line 16
    if-lez v6, :cond_1

    .line 18
    invoke-interface {v0, v1, v2, v3}, Lls;->b(Lt4;J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 21
    :cond_1
    const/4 v1, 0x0

    .line 22
    goto :goto_0

    .line 23
    :catchall_0
    move-exception v1

    .line 24
    :goto_0
    :try_start_1
    invoke-interface {v0}, Lls;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 27
    goto :goto_1

    .line 28
    :catchall_1
    move-exception v0

    .line 29
    if-nez v1, :cond_2

    .line 31
    move-object v1, v0

    .line 32
    :cond_2
    :goto_1
    const/4 v0, 0x1

    .line 33
    iput-boolean v0, p0, Lbp;->e:Z

    .line 35
    if-nez v1, :cond_3

    .line 37
    return-void

    .line 38
    :cond_3
    sget-object v0, Ldx;->a:Ljava/nio/charset/Charset;

    .line 40
    throw v1
.end method

.method public final f()Lu4;
    .locals 7

    .line 1
    iget-boolean v0, p0, Lbp;->e:Z

    .line 3
    if-nez v0, :cond_1

    .line 5
    iget-object v0, p0, Lbp;->c:Lt4;

    .line 7
    iget-wide v1, v0, Lt4;->d:J

    .line 9
    const-wide/16 v3, 0x0

    .line 11
    cmp-long v5, v1, v3

    .line 13
    if-lez v5, :cond_0

    .line 15
    iget-object v3, p0, Lbp;->d:Lls;

    .line 17
    invoke-interface {v3, v0, v1, v2}, Lls;->b(Lt4;J)V

    .line 20
    :cond_0
    return-object p0

    .line 21
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 23
    const-string v6, "xGCR5OcM"
    invoke-static {v6}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 25
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 28
    throw v0
.end method

.method public final flush()V
    .locals 8

    .line 1
    iget-boolean v0, p0, Lbp;->e:Z

    .line 3
    if-nez v0, :cond_1

    .line 5
    iget-object v0, p0, Lbp;->c:Lt4;

    .line 7
    iget-wide v1, v0, Lt4;->d:J

    .line 9
    const-wide/16 v3, 0x0

    .line 11
    iget-object v5, p0, Lbp;->d:Lls;

    .line 13
    cmp-long v6, v1, v3

    .line 15
    if-lez v6, :cond_0

    .line 17
    invoke-interface {v5, v0, v1, v2}, Lls;->b(Lt4;J)V

    .line 20
    :cond_0
    invoke-interface {v5}, Lls;->flush()V

    .line 23
    return-void

    .line 24
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 26
    const-string v7, "xGCR5OcM"
    invoke-static {v7}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 28
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 31
    throw v0
.end method

.method public final h()Lu4;
    .locals 7

    .line 1
    iget-boolean v0, p0, Lbp;->e:Z

    .line 3
    if-nez v0, :cond_1

    .line 5
    iget-object v0, p0, Lbp;->c:Lt4;

    .line 7
    invoke-virtual {v0}, Lt4;->h()J

    .line 10
    move-result-wide v1

    .line 11
    const-wide/16 v3, 0x0

    .line 13
    cmp-long v5, v1, v3

    .line 15
    if-lez v5, :cond_0

    .line 17
    iget-object v3, p0, Lbp;->d:Lls;

    .line 19
    invoke-interface {v3, v0, v1, v2}, Lls;->b(Lt4;J)V

    .line 22
    :cond_0
    return-object p0

    .line 23
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 25
    const-string v6, "xGCR5OcM"
    invoke-static {v6}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    .line 27
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 30
    throw v0
.end method

.method public final m(Ljava/lang/String;)Lu4;
    .locals 4

    .line 1
    iget-boolean v0, p0, Lbp;->e:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, Lbp;->c:Lt4;

    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 13
    move-result v1

    .line 14
    const/4 v2, 0x0

    .line 15
    invoke-virtual {v0, v2, v1, p1}, Lt4;->F(IILjava/lang/String;)V

    .line 18
    invoke-virtual {p0}, Lbp;->h()Lu4;

    .line 21
    return-object p0

    .line 22
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 24
    const-string v3, "xGCR5OcM"
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 26
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 29
    throw p1
.end method

.method public final p(Lz4;)Lu4;
    .locals 2

    .line 1
    iget-boolean v0, p0, Lbp;->e:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, Lbp;->c:Lt4;

    .line 7
    invoke-virtual {v0, p1}, Lt4;->z(Lz4;)V

    .line 10
    invoke-virtual {p0}, Lbp;->h()Lu4;

    .line 13
    return-object p0

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 16
    const-string v1, "xGCR5OcM"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 21
    throw p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "xXmY8ecayA=="
    invoke-static {v2}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lbp;->d:Lls;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final write([B)Lu4;
    .locals 4

    .line 1
    iget-boolean v0, p0, Lbp;->e:Z

    if-nez v0, :cond_1

    .line 2
    iget-object v0, p0, Lbp;->c:Lt4;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    .line 3
    array-length v2, p1

    invoke-virtual {v0, p1, v1, v2}, Lt4;->write([BII)V

    .line 4
    invoke-virtual {p0}, Lbp;->h()Lu4;

    return-object p0

    .line 5
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v3, "1GOL5eENwLWwinalhaA="
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 6
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v3, "xGCR5OcM"
    invoke-static {v3}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final write([BII)Lu4;
    .locals 2

    .line 7
    iget-boolean v0, p0, Lbp;->e:Z

    if-nez v0, :cond_0

    .line 8
    iget-object v0, p0, Lbp;->c:Lt4;

    invoke-virtual {v0, p1, p2, p3}, Lt4;->write([BII)V

    .line 9
    invoke-virtual {p0}, Lbp;->h()Lu4;

    return-object p0

    .line 10
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v1, "xGCR5OcM"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final writeByte(I)Lu4;
    .locals 2

    .line 1
    iget-boolean v0, p0, Lbp;->e:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, Lbp;->c:Lt4;

    .line 7
    invoke-virtual {v0, p1}, Lt4;->A(I)V

    .line 10
    invoke-virtual {p0}, Lbp;->h()Lu4;

    .line 13
    return-object p0

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 16
    const-string v1, "xGCR5OcM"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 21
    throw p1
.end method

.method public final writeInt(I)Lu4;
    .locals 2

    .line 1
    iget-boolean v0, p0, Lbp;->e:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, Lbp;->c:Lt4;

    .line 7
    invoke-virtual {v0, p1}, Lt4;->C(I)V

    .line 10
    invoke-virtual {p0}, Lbp;->h()Lu4;

    .line 13
    return-object p0

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 16
    const-string v1, "xGCR5OcM"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 21
    throw p1
.end method

.method public final writeLong(J)Lu4;
    .locals 2

    .line 1
    iget-boolean v0, p0, Lbp;->e:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, Lbp;->c:Lt4;

    .line 7
    invoke-virtual {v0, p1, p2}, Lt4;->D(J)V

    .line 10
    invoke-virtual {p0}, Lbp;->h()Lu4;

    .line 13
    return-object p0

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 16
    const-string v1, "xGCR5OcM"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p2

    .line 18
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 21
    throw p1
.end method

.method public final writeShort(I)Lu4;
    .locals 2

    .line 1
    iget-boolean v0, p0, Lbp;->e:Z

    .line 3
    if-nez v0, :cond_0

    .line 5
    iget-object v0, p0, Lbp;->c:Lt4;

    .line 7
    invoke-virtual {v0, p1}, Lt4;->E(I)V

    .line 10
    invoke-virtual {p0}, Lbp;->h()Lu4;

    .line 13
    return-object p0

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 16
    const-string v1, "xGCR5OcM"
    invoke-static {v1}, Lcom/epicprotector/vault/EpicStringVault;->r(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0

    .line 18
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 21
    throw p1
.end method
