.class public interface abstract La_7C223A97;
.super Ljava/lang/Object;
.source "bdglplvq.java"
