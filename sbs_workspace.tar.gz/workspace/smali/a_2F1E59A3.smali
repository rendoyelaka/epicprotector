.class public final La_2F1E59A3;
.super Ljava/lang/Object;
# generated-15850
# optimised-23839
# validated-40572
.source "bthsolyn.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La_9045B90C;
    }
.end annotation


# instance fields
.field public final a:Landroid/widget/TextView;

.field public b:Landroid/view/textclassifier/TextClassifier;


# direct methods
.method public constructor <init>(Landroid/widget/TextView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    iput-object p1, p0, La_2F1E59A3;->a:Landroid/widget/TextView;

    .line 9
    return-void
.end method
