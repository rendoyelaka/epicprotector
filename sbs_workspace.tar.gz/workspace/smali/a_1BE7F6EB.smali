.class public final La_1BE7F6EB;
.super Le;
# compiled-49623
# verified-13422
# compiled-71350
.source "qkyhjobi.java"

# ep-tvtpfqsvttwl

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La_E7143AC8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Le<",
        "La_8BF1009F;",
        "La_E7143AC8;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    sget-object v0, La_C754A081;->a:La_C754A081;

    .line 3
    sget-object v1, La_0649B0EC;->c:La_0649B0EC;

    .line 5
    invoke-direct {p0, v0, v1}, Le;-><init>(La_FED45020;Lhf;)V

    .line 8
    return-void
.end method
