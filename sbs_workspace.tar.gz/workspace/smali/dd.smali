.class public final Ldd;
.super Ljava/lang/Object;
.source "ServiceClient14.java"
# ep-zllkhvmxiurt
# processed-17279
# compiled-79216
# processed-81031


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ldd$a;
    }
.end annotation


# static fields
.field public static final a:Lcd;


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcd;

    invoke-direct {v0}, Lcd;-><init>()V

    sput-object v0, Ldd;->a:Lcd;

    return-void
.end method

.method public static a(Landroid/content/Context;Led;)Lld;
    .locals 20

    .line 1
    move-object/from16 v0, p1

    .line 3
    const/4 v6, 0x0

    .line 4
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 7
    move-result-object v1

    .line 8
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 11
    move-result-object v2

    .line 12
    iget-object v3, v0, Led;->a:Ljava/lang/String;

    .line 14
    const/4 v7, 0x0

    .line 15
    invoke-virtual {v1, v3, v7}, Landroid/content/pm/PackageManager;->resolveContentProvider(Ljava/lang/String;I)Landroid/content/pm/ProviderInfo;

    .line 18
    move-result-object v4

    .line 19
    if-eqz v4, :cond_11

    .line 21
    iget-object v5, v4, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    .line 23
    iget-object v8, v0, Led;->b:Ljava/lang/String;

    .line 25
    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 28
    move-result v5

    .line 29
    if-eqz v5, :cond_10

    .line 31
    iget-object v3, v4, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    .line 33
    const/16 v5, 0x40

    .line 35
    invoke-virtual {v1, v3, v5}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 38
    move-result-object v1

    .line 39
    iget-object v1, v1, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    .line 41
    new-instance v3, Ljava/util/ArrayList;

    .line 43
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 46
    array-length v5, v1

    .line 47
    const/4 v8, 0x0

    .line 48
    :goto_0
    if-ge v8, v5, :cond_0

    .line 50
    aget-object v9, v1, v8

    .line 52
    invoke-virtual {v9}, Landroid/content/pm/Signature;->toByteArray()[B

    .line 55
    move-result-object v9

    .line 56
    invoke-virtual {v3, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 59
    add-int/lit8 v8, v8, 0x1

    .line 61
    goto :goto_0

    .line 62
    :cond_0
    sget-object v1, Ldd;->a:Lcd;

    .line 64
    invoke-static {v3, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 67
    iget-object v5, v0, Led;->d:Ljava/util/List;

    .line 69
    if-eqz v5, :cond_1

    .line 71
    goto :goto_1

    .line 72
    :cond_1
    invoke-static {v7, v2}, Lkd;->b(ILandroid/content/res/Resources;)Ljava/util/List;

    .line 75
    move-result-object v5

    .line 76
    :goto_1
    const/4 v2, 0x0

    .line 77
    :goto_2
    invoke-interface {v5}, Ljava/util/List;->size()I

    .line 80
    move-result v8

    .line 81
    const/4 v9, 0x1

    .line 82
    const/4 v10, 0x0

    .line 83
    if-ge v2, v8, :cond_6

    .line 85
    new-instance v8, Ljava/util/ArrayList;

    .line 87
    invoke-interface {v5, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 90
    move-result-object v11

    .line 91
    check-cast v11, Ljava/util/Collection;

    .line 93
    invoke-direct {v8, v11}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 96
    invoke-static {v8, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 99
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 102
    move-result v11

    .line 103
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 106
    move-result v12

    .line 107
    if-eq v11, v12, :cond_2

    .line 109
    goto :goto_4

    .line 110
    :cond_2
    const/4 v11, 0x0

    .line 111
    :goto_3
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 114
    move-result v12

    .line 115
    if-ge v11, v12, :cond_4

    .line 117
    invoke-virtual {v3, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 120
    move-result-object v12

    .line 121
    check-cast v12, [B

    .line 123
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 126
    move-result-object v13

    .line 127
    check-cast v13, [B

    .line 129
    invoke-static {v12, v13}, Ljava/util/Arrays;->equals([B[B)Z

    .line 132
    move-result v12

    .line 133
    if-nez v12, :cond_3

    .line 135
    :goto_4
    const/4 v8, 0x0

    .line 136
    goto :goto_5

    .line 137
    :cond_3
    add-int/lit8 v11, v11, 0x1

    .line 139
    goto :goto_3

    .line 140
    :cond_4
    const/4 v8, 0x1

    .line 141
    :goto_5
    if-eqz v8, :cond_5

    .line 143
    goto :goto_6

    .line 144
    :cond_5
    add-int/lit8 v2, v2, 0x1

    .line 146
    goto :goto_2

    .line 147
    :cond_6
    move-object v4, v10

    .line 148
    :goto_6
    if-nez v4, :cond_7

    .line 150
    new-instance v0, Lld;

    .line 152
    invoke-direct {v0, v9, v10}, Lld;-><init>(I[Lmd;)V

    .line 155
    return-object v0

    .line 156
    :cond_7
    iget-object v1, v4, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    .line 158
    new-instance v8, Ljava/util/ArrayList;

    .line 160
    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    .line 163
    new-instance v2, Landroid/net/Uri$Builder;

    .line 165
    invoke-direct {v2}, Landroid/net/Uri$Builder;-><init>()V

    .line 168
    const-string v3, "content"

    .line 170
    invoke-virtual {v2, v3}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 173
    move-result-object v2

    .line 174
    invoke-virtual {v2, v1}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 177
    move-result-object v2

    .line 178
    invoke-virtual {v2}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 181
    move-result-object v11

    .line 182
    new-instance v2, Landroid/net/Uri$Builder;

    .line 184
    invoke-direct {v2}, Landroid/net/Uri$Builder;-><init>()V

    .line 187
    invoke-virtual {v2, v3}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 190
    move-result-object v2

    .line 191
    invoke-virtual {v2, v1}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 194
    move-result-object v1

    .line 195
    const-string v2, "file"

    .line 197
    invoke-virtual {v1, v2}, Landroid/net/Uri$Builder;->appendPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 200
    move-result-object v1

    .line 201
    invoke-virtual {v1}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 204
    move-result-object v12

    .line 205
    :try_start_0
    const-string v13, "_id"

    .line 207
    const-string v14, "file_id"

    .line 209
    const-string v15, "font_ttc_index"

    .line 211
    const-string v16, "font_variation_settings"

    .line 213
    const-string v17, "font_weight"

    .line 215
    const-string v18, "font_italic"

    .line 217
    const-string v19, "result_code"

    .line 219
    filled-new-array/range {v13 .. v19}, [Ljava/lang/String;

    .line 222
    move-result-object v2

    .line 223
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 226
    move-result-object v1

    .line 227
    const-string v3, "query = ?"

    .line 229
    new-array v4, v9, [Ljava/lang/String;

    .line 231
    iget-object v0, v0, Led;->c:Ljava/lang/String;

    .line 233
    aput-object v0, v4, v7

    .line 235
    const/4 v5, 0x0

    .line 236
    move-object v0, v1

    .line 237
    move-object v1, v11

    .line 238
    invoke-static/range {v0 .. v6}, Ldd$a;->a(Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Landroid/database/Cursor;

    .line 241
    move-result-object v10

    .line 242
    if-eqz v10, :cond_d

    .line 244
    invoke-interface {v10}, Landroid/database/Cursor;->getCount()I

    .line 247
    move-result v0

    .line 248
    if-lez v0, :cond_d

    .line 250
    const-string v0, "result_code"

    .line 252
    invoke-interface {v10, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 255
    move-result v0

    .line 256
    new-instance v8, Ljava/util/ArrayList;

    .line 258
    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    .line 261
    const-string v1, "_id"

    .line 263
    invoke-interface {v10, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 266
    move-result v1

    .line 267
    const-string v2, "file_id"

    .line 269
    invoke-interface {v10, v2}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 272
    move-result v2

    .line 273
    const-string v3, "font_ttc_index"

    .line 275
    invoke-interface {v10, v3}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 278
    move-result v3

    .line 279
    const-string v4, "font_weight"

    .line 281
    invoke-interface {v10, v4}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 284
    move-result v4

    .line 285
    const-string v5, "font_italic"

    .line 287
    invoke-interface {v10, v5}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 290
    move-result v5

    .line 291
    :goto_7
    invoke-interface {v10}, Landroid/database/Cursor;->moveToNext()Z

    .line 294
    move-result v6

    .line 295
    if-eqz v6, :cond_d

    .line 297
    const/4 v6, -0x1

    .line 298
    if-eq v0, v6, :cond_8

    .line 300
    invoke-interface {v10, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 303
    move-result v13

    .line 304
    move/from16 v19, v13

    .line 306
    goto :goto_8

    .line 307
    :cond_8
    const/16 v19, 0x0

    .line 309
    :goto_8
    if-eq v3, v6, :cond_9

    .line 311
    invoke-interface {v10, v3}, Landroid/database/Cursor;->getInt(I)I

    .line 314
    move-result v13

    .line 315
    move/from16 v16, v13

    .line 317
    goto :goto_9

    .line 318
    :cond_9
    const/16 v16, 0x0

    .line 320
    :goto_9
    if-ne v2, v6, :cond_a

    .line 322
    invoke-interface {v10, v1}, Landroid/database/Cursor;->getLong(I)J

    .line 325
    move-result-wide v13

    .line 326
    invoke-static {v11, v13, v14}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    .line 329
    move-result-object v13

    .line 330
    goto :goto_a

    .line 331
    :cond_a
    invoke-interface {v10, v2}, Landroid/database/Cursor;->getLong(I)J

    .line 334
    move-result-wide v13

    .line 335
    invoke-static {v12, v13, v14}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    .line 338
    move-result-object v13

    .line 339
    :goto_a
    move-object v15, v13

    .line 340
    if-eq v4, v6, :cond_b

    .line 342
    invoke-interface {v10, v4}, Landroid/database/Cursor;->getInt(I)I

    .line 345
    move-result v13

    .line 346
    move/from16 v17, v13

    .line 348
    goto :goto_b

    .line 349
    :cond_b
    const/16 v13, 0x190

    .line 351
    const/16 v17, 0x190

    .line 353
    :goto_b
    if-eq v5, v6, :cond_c

    .line 355
    invoke-interface {v10, v5}, Landroid/database/Cursor;->getInt(I)I

    .line 358
    move-result v6

    .line 359
    if-ne v6, v9, :cond_c

    .line 361
    const/16 v18, 0x1

    .line 363
    goto :goto_c

    .line 364
    :cond_c
    const/16 v18, 0x0

    .line 366
    :goto_c
    new-instance v6, Lmd;

    .line 368
    move-object v14, v6

    .line 369
    invoke-direct/range {v14 .. v19}, Lmd;-><init>(Landroid/net/Uri;IIZI)V

    .line 372
    invoke-virtual {v8, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 375
    goto :goto_7

    .line 376
    :cond_d
    if-eqz v10, :cond_e

    .line 378
    invoke-interface {v10}, Landroid/database/Cursor;->close()V

    .line 381
    :cond_e
    new-array v0, v7, [Lmd;

    .line 383
    invoke-virtual {v8, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 386
    move-result-object v0

    .line 387
    check-cast v0, [Lmd;

    .line 389
    new-instance v1, Lld;

    .line 391
    invoke-direct {v1, v7, v0}, Lld;-><init>(I[Lmd;)V

    .line 394
    return-object v1

    .line 395
    :catchall_0
    move-exception v0

    .line 396
    if-eqz v10, :cond_f

    .line 398
    invoke-interface {v10}, Landroid/database/Cursor;->close()V

    .line 401
    :cond_f
    throw v0

    .line 402
    :cond_10
    new-instance v0, Landroid/content/pm/PackageManager$NameNotFoundException;

    .line 404
    new-instance v1, Ljava/lang/StringBuilder;

    .line 406
    const-string v2, "Found content provider "

    .line 408
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 411
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 414
    const-string v2, ", but package was not "

    .line 416
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 419
    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 422
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 425
    move-result-object v1

    .line 426
    invoke-direct {v0, v1}, Landroid/content/pm/PackageManager$NameNotFoundException;-><init>(Ljava/lang/String;)V

    .line 429
    throw v0

    .line 430
    :cond_11
    new-instance v0, Landroid/content/pm/PackageManager$NameNotFoundException;

    .line 432
    new-instance v1, Ljava/lang/StringBuilder;

    .line 434
    const-string v2, "No package found for authority: "

    .line 436
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 439
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 442
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 445
    move-result-object v1

    .line 446
    invoke-direct {v0, v1}, Landroid/content/pm/PackageManager$NameNotFoundException;-><init>(Ljava/lang/String;)V

    .line 449
    throw v0
.end method
