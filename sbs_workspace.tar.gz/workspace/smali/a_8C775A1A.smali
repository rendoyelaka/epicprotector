.class public final La_8C775A1A;
.super La_AD33B00A;
# ep-crfgxzrrojsb
.source "sfcnolkb.java"
# compiled-21000
# compiled-63572


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La_AD33B00A;"
    }
.end annotation


# instance fields
.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Landroidx/activity/result/a;


# direct methods
.method public constructor <init>(Landroidx/activity/result/a;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, La_8C775A1A;->d:Landroidx/activity/result/a;

    iput-object p2, p0, La_8C775A1A;->c:Ljava/lang/String;

    invoke-direct {p0}, La_AD33B00A;-><init>()V

    return-void
.end method
