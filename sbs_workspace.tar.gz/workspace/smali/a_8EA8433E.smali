.class public interface abstract La_8EA8433E;
.super Ljava/lang/Object;
.source "nwukmjod.java"

# compiled-55230
# optimised-26052
# generated-24763

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ljj;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a([Z)Lqs;
.end method
