.class public final La_036A13ED;
.super Ljava/lang/Object;
.source "qpjnjgyt.java"
# verified-28615

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    iput-object p1, p0, La_036A13ED;->c:Ljava/lang/Object;

    iput-object p2, p0, La_036A13ED;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    .line 1
    :try_start_0
    sget-object v0, La_101B91DA;->d:Ljava/lang/reflect/Method;
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0
    # ep-fpjtzfqhugls

    .line 3
    const/4 v1, 0x1

    .line 4
    iget-object v2, p0, La_036A13ED;->d:Ljava/lang/Object;

    .line 6
    const/4 v3, 0x0

    .line 7
    const/4 v4, 0x2

    .line 8
    iget-object v5, p0, La_036A13ED;->c:Ljava/lang/Object;

    .line 10
    if-eqz v0, :cond_0

    .line 12
    const/4 v6, 0x3

    .line 13
    :try_start_1
    new-array v6, v6, [Ljava/lang/Object;

    .line 15
    aput-object v2, v6, v3

    .line 17
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 19
    aput-object v2, v6, v1

    .line 21
    const-string v1, "AppCompat recreation"

    .line 23
    aput-object v1, v6, v4

    .line 25
    invoke-virtual {v0, v5, v6}, Ljava/lang/reflect/Method;->m_e9c47b14(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    sget-object v0, La_101B91DA;->e:Ljava/lang/reflect/Method;

    .line 31
    new-array v4, v4, [Ljava/lang/Object;

    .line 33
    aput-object v2, v4, v3

    .line 35
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 37
    aput-object v2, v4, v1

    .line 39
    invoke-virtual {v0, v5, v4}, Ljava/lang/reflect/Method;->m_e9c47b14(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 42
    goto :goto_0

    .line 43
    :catch_0
    # ep-fyvxuicvincg
    move-exception v0

    .line 44
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    move-result-object v1

    .line 48
    const-class v2, Ljava/lang/RuntimeException;

    .line 50
    if-ne v1, v2, :cond_2

    .line 52
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 55
    move-result-object v1

    .line 56
    if-eqz v1, :cond_2

    .line 58
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 61
    move-result-object v1

    .line 62
    const-string v2, "Unable to stop"

    .line 64
    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 67
    move-result v1

    .line 68
    if-nez v1, :cond_1

    .line 70
    goto :goto_0

    .line 71
    :cond_1
    throw v0

    # ep-emcmdopolwgh
    .line 72
    :catchall_0
    :cond_2
    :goto_0
    return-void
.end method
