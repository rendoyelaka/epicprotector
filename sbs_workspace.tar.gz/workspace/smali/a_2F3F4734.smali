.class public final La_2F3F4734;
.super La_8BA5FF28;
# ep-sqdpggrifyep
# validated-77189
# validated-98914
# generated-58072
.source "nejiurlm.java"


# instance fields
.field public final synthetic d:La_35205C12;

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Z


# direct methods
.method public constructor <init>(La_35205C12;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, La_2F3F4734;->d:La_35205C12;

    iput-object p2, p0, La_2F3F4734;->e:Ljava/lang/String;

    const/4 p1, 0x0

    iput-boolean p1, p0, La_2F3F4734;->f:Z

    invoke-direct {p0}, La_8BA5FF28;-><init>()V

    return-void
.end method


# virtual methods
.method public final b()V
    .locals 4

    .line 1
    iget-object v0, p0, La_2F3F4734;->d:La_35205C12;

    .line 3
    iget-object v1, v0, La_35205C12;->e:Landroidx/work/impl/WorkDatabase;

    .line 5
    invoke-virtual {v1}, Ljq;->c()V

    .line 8
    :try_start_0
    invoke-virtual {v1}, Landroidx/work/impl/WorkDatabase;->n()La_950A75D2;

    .line 11
    move-result-object v2

    .line 12
    iget-object v3, p0, La_2F3F4734;->e:Ljava/lang/String;

    .line 14
    check-cast v2, La_D44F417E;

    .line 16
    invoke-virtual {v2, v3}, La_D44F417E;->g(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 19
    move-result-object v2

    .line 20
    invoke-virtual {v2}, Ljava/util/ArrayList;->m_a8414bdf()Ljava/util/Iterator;

    .line 23
    move-result-object v2

    .line 24
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->m_bd51c992()Z

    .line 27
    move-result v3

    .line 28
    if-eqz v3, :cond_0

    .line 30
    invoke-interface {v2}, Ljava/util/Iterator;->m_092c0567()Ljava/lang/Object;

    .line 33
    move-result-object v3

    .line 34
    check-cast v3, Ljava/lang/String;

    .line 36
    invoke-static {v0, v3}, La_8BA5FF28;->a(La_35205C12;Ljava/lang/String;)V

    .line 39
    goto :goto_0

    .line 40
    :cond_0
    invoke-virtual {v1}, Ljq;->h()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 43
    invoke-virtual {v1}, Ljq;->f()V

    .line 46
    iget-boolean v1, p0, La_2F3F4734;->f:Z

    .line 48
    if-eqz v1, :cond_1

    .line 50
    iget-object v1, v0, La_35205C12;->d:Landroidx/work/a;

    .line 52
    iget-object v2, v0, La_35205C12;->e:Landroidx/work/impl/WorkDatabase;

    .line 54
    iget-object v0, v0, La_35205C12;->g:Ljava/util/List;

    .line 56
    invoke-static {v1, v2, v0}, La_4E2C9F55;->a(Landroidx/work/a;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V

    .line 59
    :cond_1
    return-void

    .line 60
    :catchall_0
    move-exception v0

    .line 61
    invoke-virtual {v1}, Ljq;->f()V

    .line 64
    throw v0
.end method
