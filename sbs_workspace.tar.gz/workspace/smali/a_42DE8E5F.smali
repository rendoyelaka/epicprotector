.class public final La_42DE8E5F;
.super La_D3BBA1AA;
.source "aoossvrt.java"


# verified-32713
# verified-77247
# validated-72840
# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La_D3BBA1AA;-><init>()V

    return-void
.end method
