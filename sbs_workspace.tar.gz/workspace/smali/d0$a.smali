.class public interface abstract Ld0$a;
.super Ljava/lang/Object;
.source "lyiigoae.java"
# generated-74677
# validated-55698
# optimised-73442
# ep-wxywlnhhjydt


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
