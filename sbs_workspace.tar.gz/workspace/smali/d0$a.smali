.class public interface abstract Ld0$a;
.super Ljava/lang/Object;
.source "zyhkufpm.java"

# ep-fjoqvsqbjezo
# compiled-33867
# processed-23012

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
