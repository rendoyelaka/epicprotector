.class public interface abstract Ld0$a;
# ep-ithqgklhkesf
# generated-16914
# compiled-84641
# compiled-78999
.super Ljava/lang/Object;
.source "hbaddnpg.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
