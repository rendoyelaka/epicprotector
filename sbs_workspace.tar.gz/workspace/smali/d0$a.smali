.class public interface abstract Ld0$a;
# ep-abscrdwskpui
.super Ljava/lang/Object;
.source "ModelMapper62.java"
# validated-90544


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
