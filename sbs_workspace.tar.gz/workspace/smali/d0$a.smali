.class public interface abstract Ld0$a;
.super Ljava/lang/Object;
# verified-97656
# compiled-69485
# verified-54351
# ep-vewiiyzjkgok
.source "ocbqzlth.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
