.class public interface abstract Ld0$a;
.super Ljava/lang/Object;
# ep-sqmcztcyydgz
.source "fezgdrbj.java"

# generated-10684
# verified-45528

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
