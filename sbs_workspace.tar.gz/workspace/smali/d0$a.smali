.class public interface abstract Ld0$a;
# ep-armuovadvjeo
.super Ljava/lang/Object;
# processed-18304
# optimised-76880
.source "texkyodt.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
