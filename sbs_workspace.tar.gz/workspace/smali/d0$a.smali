.class public interface abstract Ld0$a;
# ep-jadzfpjcgkgj
.super Ljava/lang/Object;
# optimised-68709
# verified-56273
.source "vjzizpdo.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
