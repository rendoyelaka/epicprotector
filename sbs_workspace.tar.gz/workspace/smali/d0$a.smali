.class public interface abstract Ld0$a;
# ep-nwsygbbmmrrr
.super Ljava/lang/Object;
.source "dnmxlmxg.java"

# verified-27301
# validated-61029

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
