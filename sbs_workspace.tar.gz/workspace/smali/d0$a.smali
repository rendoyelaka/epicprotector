.class public interface abstract Ld0$a;
.super Ljava/lang/Object;
# ep-qchzysaqkftj
.source "olsduady.java"

# validated-74516
# optimised-40978

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
