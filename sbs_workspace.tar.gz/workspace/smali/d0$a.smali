.class public interface abstract Ld0$a;
.super Ljava/lang/Object;
# validated-61971
# validated-59626
# ep-vtwujjmlvdma
.source "uexvwfnm.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
