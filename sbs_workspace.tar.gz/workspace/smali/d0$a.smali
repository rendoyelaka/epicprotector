.class public interface abstract Ld0$a;
.super Ljava/lang/Object;
.source "wpibejma.java"
# generated-46522
# compiled-44626
# processed-98347
# ep-hbykinjjyeeo


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
