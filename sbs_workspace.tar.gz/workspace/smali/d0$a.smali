.class public interface abstract Ld0$a;
.super Ljava/lang/Object;
# validated-77715
# verified-87711
# generated-29721
# ep-louubbqlydno
.source "wktktcwx.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
