.class public interface abstract Ld0$a;
# ep-pwaishohhftb
.super Ljava/lang/Object;
.source "gakekrwo.java"

# compiled-28889
# optimised-44287

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
