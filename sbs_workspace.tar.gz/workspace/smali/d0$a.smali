.class public interface abstract Ld0$a;
# ep-rmnelfnichpq
.super Ljava/lang/Object;
# optimised-26902
.source "CredentialManager33.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
