.class public interface abstract Ld0$a;
# ep-wyalaaciysau
.super Ljava/lang/Object;
.source "dijoigvo.java"

# processed-94487

# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
