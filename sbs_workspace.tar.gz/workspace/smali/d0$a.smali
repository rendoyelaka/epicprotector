.class public interface abstract Ld0$a;
# ep-fjuezvhausxs
.super Ljava/lang/Object;
# validated-74895
.source "exxhfmcx.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
